# 5. Margin & M2M  

**Source:** <https://zerodha.com/varsity/chapter/margin-m2m/>

---  

##  

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/01/M4-Ch5-title1.jpg)  

## 5.1 – Things you should know by now  

Margins are the secret sauce that lets you trade futures with a *tiny* pile of cash while playing with a *giant* notional. In other words, they’re the financial lever that turns a simple “buy‑sell” into a high‑octane futures agreement (unlike the bland spot market). Because of that, you *must* get cozy with every nuance of margin.  

Before we dive deeper, let’s do a quick “remember‑the‑basics” flash‑card session. These are the nuggets you’ve already seen in the first four chapters. If any of them feel fuzzy, hit the rewind button and refresh – you’ll thank yourself later.  

- **Future ≠ Forward** – Futures are the polished, exchange‑traded cousins of forwards.  
- **Structure inheritance** – Futures inherit the transactional skeleton of forwards (same payoff, but with a lot more plumbing).  
- **Directional edge** – If you’ve got a solid view on where an asset’s price is headed, a futures contract can turn that view into cash.  
- **Underlying tether** – A futures contract’s value is *derived* from the spot price of its underlying. Example: TCS Futures derive value from TCS shares in the spot market.  
- **Price isn’t identical** – Futures price and spot price differ because of the futures‑pricing formula (cost‑of‑carry, interest, dividends, etc.). We’ll dissect that later.  
- **Standardized contract** – Lot size and expiry are fixed when the contract is listed.  
  - *Lot size* = the smallest tradable quantity (e.g., 250 shares for Infosys).  
  - *Contract value* = Futures Price × Lot Size.  
  - *Expiry* = the last day you may keep the contract alive.  
- **Margin = tiny cash, huge exposure** – To open a futures position you only need to post a *percentage* of the contract value as margin. That tiny cash lets you control a massive notional.  
- **Digital handshake** – When you trade futures you sign a digital agreement with the counter‑party, binding you to settle on expiry.  
- **Futures are tradable** – You don’t have to sit on the contract until expiry; you can exit whenever your conviction flips.  
  - You could hold for minutes, days, or months.  
  - Example: Buy Infosys Futures at 1951 ₹ at 9:15 AM, sell at 1953 ₹ at 9:17 AM. With a lot size of 250, that’s a **₹500** profit in 2 minutes.  
- **Cash‑settled** – Equity futures settle in cash, not in physical shares.  
- **Leverage = amplified P&L** – A small move in the underlying creates a big swing in your profit or loss.  
- **Zero‑sum game** – One trader’s profit is the other’s loss; the total sum of money exchanged is zero.  
- **Higher leverage = higher risk** – The more you lever, the faster you can go from hero to zero.  
- **Linear payoff** – Futures P&L moves linearly with the underlying price (no caps, no floors).  
- **Regulated by SEBI** – The Securities and Exchange Board of India watches the market like a hawk, which is why you rarely hear about a counter‑party default in Indian futures.  

If those points look familiar, you’re cruising on the right lane. Got doubts? Pop back to the earlier chapters and tidy up the concepts.  

Now, with the basics under your belt, let’s zoom into the twin engines of futures trading: **Margins** and **Mark‑to‑Market (M2M)**.  

## 5.2 – Why are Margins charged?  

Rewind to the forward‑contract story in Chapter 1:  

> ABC Jewelers promises to buy **15 kg** of gold from XYZ Gold Dealers at **₹2,450/gram** three months from now.  

If gold shoots up, XYZ gets the short end of the stick (a loss) while ABC pockets a profit. If gold crashes, the tables turn. In a forward contract the whole thing runs on a gentleman’s promise – no middle‑man, no safety net.  

Imagine gold soaring; XYZ suddenly thinks, “Oops, I can’t pay!” – you’d be looking at a long‑drawn legal saga. The *incentive* to default is massive because there’s nothing standing between the two parties.  

Futures are the **smart upgrade** to forwards. The exchange steps in as the central guarantor, and the *margin* is the collateral that makes this guarantee possible.  

### How the exchange pulls off this magic  
1. **All trades flow through the exchange** – the exchange becomes the counter‑party to every trade.  
2. **Exchange guarantees settlement** – it promises you’ll get your money if you’re owed, and it makes sure the other side pays up.  
3. **Two tools to keep everyone honest**  
   - **Collecting margins** (the cash you lock up).  
   - **Mark‑to‑Market (M2M)** – the daily profit/loss settlement that keeps the balance sheet tidy.  

We gave you a teaser of **Margin** in the previous chapter, but tackling Margin *and* M2M simultaneously would be like trying to drink coffee and soup at the same time – messy. So let’s pause on margins, master M2M, then circle back to margins with fresh eyes.  

Keep these margin‑related facts in your mental pocket while we do the M2M walkthrough:  

- When you open a futures position, the exchange **blocks** a chunk of cash in your account – this is your **Initial Margin (IM)**.  
- **Initial Margin = SPAN Margin + Exposure Margin**.  
- The IM stays blocked **as long as the position lives**.  
- Because the futures price moves daily, the **IM amount changes daily** (it’s a % of the *current* contract value).  
- **Contract Value = Futures Price × Lot Size** (Lot size is fixed, price isn’t).  

That’s all you need for now. Let’s go meet M2M.  

## 5.3 – Mark‑to‑Market (M2M)  

Futures prices wiggle every day, and each wiggle either adds to your pocket or takes away. **Mark‑to‑Market (M2M)** is the daily accounting ritual that makes sure you and the counter‑party settle those wiggles *every* day, not just at expiry.  

### A quick‑fire example  

| Date | Action | Futures price | Lot size | Profit / Loss (₹) |
|------|--------|---------------|----------|-------------------|
| 1 Dec 2014, 11:30 AM | **Buy** Hindalco Futures | 165 | 2 000 | – |
| 4 Dec 2014, 2:15 PM | **Sell** Hindalco Futures | 170.10 | 2 000 | **+10 200** |

**Straight‑line profit:** (170.10 – 165) × 2 000 = ₹10,200.  

But we held the contract **four trading days**. Each day the exchange re‑calculates the P&L and moves money in/out of your account based on the *previous‑day* closing price.  

#### Day‑by‑day walk‑through  

| Day | Opening price (prev. close) | Closing price | Daily P&L | Cash flow to your account |
|-----|----------------------------|---------------|-----------|---------------------------|
| 1 (buy) | — | 168.30 | (168.30 – 165) × 2 000 = +₹6 600 | **+₹6 600** (credited) |
| 2 | 168.30 | 172.40 | (172.40 – 168.30) × 2 000 = +₹8 200 | **+₹8 200** |
| 3 | 172.40 | 171.60 | (171.60 – 172.40) × 2 000 = ‑₹1 600 | **‑₹1 600** (debited) |
| 4 (sell) | 171.60 | 170.10 (mid‑day exit) | (170.10 – 171.60) × 2 000 = ‑₹3 000 | **‑₹3 000** |

Notice the **buy price** for the next day is always the *previous day’s closing price* because the daily profit has already been settled. In accounting terms, the futures position is “re‑priced” each night.  

If you sum the daily cash flows:  

+6 600 + 8 200 – 1 600 – 3 000 = **₹10 200**, exactly the same as our straight‑line calculation.  

### Why bother with M2M?  

Think of M2M as the exchange’s **daily insurance check**. By moving gains and losses each day, the exchange makes sure neither party can run away with a huge unpaid balance. The risk of a default is dramatically trimmed because any loss is covered (or at least flagged) **today**, not “someday” at expiry.  

That’s the essence of M2M. Let’s now swing back to margins and see how the two dance together.  

## 5.4 – Margins, the bigger perspective  

We now re‑enter the world of **Initial Margin (IM)**, armed with the knowledge of daily M2M adjustments.  

- **Initial Margin** = **SPAN Margin** + **Exposure Margin**  
- **SPAN** (Standard Portfolio Analysis of Risk) is the *minimum* margin the exchange mandates. It’s also called the **Maintenance Margin** because you must keep at least this amount in the account for the position to survive overnight.  
- **Exposure Margin** is an extra buffer (usually **4 %‑5 %** of contract value) that brokers may require to absorb any sudden M2M losses.  

Both components are set by the exchange, not by you. The exchange calculates SPAN daily using a sophisticated algorithm that primarily looks at **volatility** – higher expected volatility → higher SPAN. (We’ll deep‑dive into volatility later.)  

### A concrete trade illustration  

Suppose you trade with Zerodha (they even have a handy **Margin Calculator**). You decide to buy **HDFC Bank Futures** on **10 Dec 2014** at **₹938.70** with a lot size of **250**.  

| Item | Calculation | Amount (₹) |
|------|-------------|------------|
| Contract Value (CV) | 938.70 × 250 | 234 675 |
| SPAN (7.5 % of CV) | 0.075 × 234 675 | 17 600 |
| Exposure (5 % of CV) | 0.05 × 234 675 | 11 734 |
| **Total Initial Margin** | SPAN + Exposure | **29 334** |

That **₹29 334** is blocked in your account as cash (the *initial* margin).  

Now let’s watch the day‑by‑day evolution, including M2M, SPAN, and Exposure.  

### Day 1 – 10 Dec 2014  

- **Closing price** = ₹940 → New CV = 940 × 250 = ₹235 000  
- **New total margin** (7.5 % + 5 %) = 12.5 % × 235 000 = ₹29 375 (just ₹41 more).  
- **M2M profit** = (940 – 938.70) × 250 = ₹325 → credited.  

**Cash balance** = Initial ₹29 334 + M2M ₹325 = ₹29 659, which comfortably exceeds the new margin requirement (₹29 375).  

**Reference price for tomorrow** = ₹940.  

### Day 2 – 11 Dec 2014  

- Price falls to **₹939** → M2M loss = (939 – 940) × 250 = ‑₹250.  
- New cash balance = 29 659 – 250 = ₹29 409.  
- New CV = 939 × 250 = ₹234 750 → New margin = 12.5 % × 234 750 = ₹29 344.  

Cash (₹29 409) > margin (₹29 344) → all good.  

**Reference price** = ₹939.  

### Day 3 – 12 Dec 2014  

- Price plunges **₹9** to **₹930** → M2M loss = (930 – 939) × 250 = ‑₹2 250.  
- Cash balance drops to 29 409 – 2 250 = ₹27 159.  
- New CV = 930 × 250 = ₹232 500 → New margin = 12.5 % × 232 500 = ₹29 063.  

Now **cash (₹27 159) < total margin (₹29 063)**, but remember the **SPAN** part is only **₹17 438** (7.5 % × 232 500). Since cash is still above SPAN, the broker won’t force‑close; you just get a **margin call** to top‑up the *excess* (if you want to stay extra safe). Most brokers let you ride as long as SPAN is satisfied.  

### Day 4‑…‑18 Dec 2014  

(We’ll skip the boring intermediate days – the pattern repeats: price moves → M2M adjusts → cash balance vs. margin re‑evaluated.)  

### Final Day – 19 Dec 2014  

- You decide to square off at **₹955**.  
- **M2M profit** for the day = (955 – 950?) Actually the reference price from 18 Dec was **₹938** (the previous close), so profit = (955 – 938) × 250 = ₹4 250.  
- Add to prior cash (₹29 159) → **Final cash balance = ₹33 409**.  

Now let’s verify the P&L with four different methods (they all line up, like a good joke hitting the punchline from every angle).  

| Method | Calculation | Result (₹) |
|--------|-------------|------------|
| 1. Sum of M2M | 325 – 250 – 2 250 + 4 250 – … (remaining days) = **4 075** | 4 075 |
| 2. Cash release | Final cash ₹33 409 – Initial margin ₹29 334 = **4 075** | 4 075 |
| 3. Contract value change | Final CV (955 × 250 = ₹238 750) – Initial CV (938.7 × 250 = ₹234 675) = **4 075** | 4 075 |
| 4. Futures price diff | (955 – 938.7) × 250 = **4 075** | 4 075 |

All roads lead to the same profit: **₹4 075**.  

### TL;DR on margins + M2M  

- **Initial Margin** = SPAN + Exposure, blocked upfront.  
- **M2M** moves money in/out every day based on *yesterday’s* close.  
- As long as your **cash balance ≥ SPAN**, you’re safe; if it falls below, the broker will shout *“Margin Call!”* (or auto‑liquidate).  
- The combination of daily cash‑flow (M2M) and collateral (margin) makes the futures market practically default‑proof.  

## 5.5 – An interesting case of ‘Margin Call’  

What if you *didn’t* exit on 19 Dec and let the trade ride into 20 Dec, where HDFC Bank tanks **8 %** to **₹880**? Let’s crunch the numbers.  

| Item | Calculation | Amount (₹) |
|------|-------------|------------|
| M2M loss (20 Dec) | (955 – 880) × 250 | **18 750** |
| Cash balance before loss | ₹33 409 | — |
| Cash after loss | 33 409 – 18 750 | **14 659** |
| New Contract Value | 880 × 250 | 220 000 |
| SPAN (7.5 %) | 0.075 × 220 000 | **16 500** |
| Exposure (5 %) | 0.05 × 220 000 | **11 000** |
| Total margin needed | 16 500 + 11 000 | **27 500** |

Now **cash (₹14 659) < SPAN (₹16 500)**.  

**What does the broker do?**  

- **Margin Call** – the broker will ping you (“Hey, we need more cash!”).  
- If you ignore it, many brokers will **auto‑close** the position once cash dips below SPAN, protecting both you and the exchange.  

That’s the safety net in action.  

### Key takeaways from this chapter  

- **Initial Margin** (blocked cash) is required for the whole life of a futures trade.  
- Both buyer *and* seller must post the same initial margin.  
- Margins give you **leverage** – a small cash outlay lets you control a large notional.  
- **M2M** is a daily accounting tweak: profit or loss for the day is *credited* or *debited* from your trading account.  
- The **previous day’s closing price** is the reference point for today’s M2M.  
- **SPAN Margin** = exchange‑mandated minimum (aka *Maintenance Margin*).  
- **Exposure Margin** = broker‑added cushion (typically 4‑5 % of contract value).  
- If your cash balance falls **below SPAN**, you’ll get a **Margin Call**; ignore it and the broker may liquidate the position.  
- The **margin + M2M** combo keeps the futures market virtually free of defaults.  

Now that you’ve wrangled both margins and M2M, you’re ready to trade futures with the confidence of someone who knows exactly why their broker might be texting them at 2 AM. Happy (and responsibly‑leveraged) trading!  