# 3. The Futures Trade  

**Source:** https://zerodha.com/varsity/chapter/futures-trade/  

---  

## 3.1 – Before the Trade  

In the previous chapter we geek‑out over the nitty‑gritty of futures – what they are, why they exist, and how they differ from plain‑old stocks. Remember, the whole point of hopping onto a futures contract is to make money, not just to collect dust. To do that you need a **directional view** – you must think the underlying asset will either climb like a cat up a curtain or tumble like my ego after a bad joke.  

Let’s ditch the shiny gold example and roll up our sleeves for a real‑world stock case.  

### The setup  

It’s **15 Dec 2014**. Tata Consultancy Services (TCS) – India’s tech‑giant and a frequent guest on the “how‑to‑make‑money‑fast” talk shows – just held an investor meet. The management dropped a “cautious about revenue growth for the December quarter” bomb. Markets hate caution from a tech‑behemoth the way cats hate water. The TCS share price immediately slid **over 3.6 %**.  

Below is a screenshot of the spot market quote (the blue highlight is the price per share, ignore the red – we’ll get to that later).  

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/01/Image1_TCS.png)  

### My brain‑wave  

I looked at that dip and thought, “Whoa, that’s a *dramatic* over‑reaction.” Why? Because anyone who’s ever stalked Indian IT stocks knows December is the **graveyard month** for revenue. The US – the biggest client base for Indian IT – closes its fiscal year and goes on holiday, so business slows down. The market already baked that slowdown into the price, so a 3.6 % plunge feels like a melodramatic soap‑opera twist.  

**Bottom line:** I see a buying opportunity. I’m **bullish** on TCS and expect the price to bounce back.  

Notice what just happened: my analysis gave me a **directional view** – I’m betting the underlying (TCS) will go **up** from today’s level.  

### Why futures instead of spot?  

Instead of sprinting to the spot market and buying shares outright, I decide to **buy TCS futures** (more on the “why” later). All I need now is the current futures price, which is posted on the NSE website. The link to the contract details is tucked right next to the spot quote (highlighted in red in the picture above).  

> *Quick refresher:* Futures prices usually **track** spot prices. If the spot falls, the futures should fall too – they’re like twins separated at birth but still finishing each other’s sentences.  

Here’s the NSE snapshot of the TCS futures price:  

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/01/Image2_TCS.png)  

As expected, futures are down too – **3.77 %** this time.  

You might be scratching your head and asking:

1. **Why isn’t the futures drop exactly the same as the spot (3.61 % vs 3.77 %)?**  
2. **Why is the futures price a tad higher (₹2 374.90) than the spot (₹2 362.35)?**  

Both are spot‑on questions. The answer lies in the **Futures Pricing Formula** (cost‑of‑carry, interest, dividends, etc.) – we’ll dissect that later. For now, just note that the futures moved **in the same direction** as the spot, which is the key takeaway.  

### Dissecting the contract  

Before we fire off a trade, let’s pull up the full contract and highlight the important bits.  

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/01/Image3_TCS.png)  

**Red box (top):**  
| Item | What it means |
|------|----------------|
| **Instrument Type** | “Stock Futures” – we’re dealing with a futures contract whose underlying is a share of a company. |
| **Symbol** | “TCS” – the ticker for Tata Consultancy Services. |
| **Expiry Date** | **24 Dec 2014** – the day this contract vanishes like my willpower on a diet. All Indian derivatives expire on the **last Thursday of the month** (more on expiry later). |

**Blue box:** Shows the current **Futures Price** (₹2 374.90).  

**Black box (bottom):**  
| Item | What it means |
|------|----------------|
| **Underlying Value** | The spot price of TCS at the moment of the screenshot – ₹2 359.95 (a few points lower than the earlier spot because the market kept moving). |
| **Market Lot (Lot Size)** | **125** shares. Futures are **standardised** – you can’t buy 1 share, you must buy in multiples of the lot size. In other words, one “lot” = 125 shares. |

### Contract value  

Recall from Chapter 2 we defined **Contract Value** = *Lot Size* × *Futures Price*. So for TCS:  

\[
\text{Contract Value} = 125 \times ₹2 374.90 = ₹296 862.50
\]

That’s the notional amount we’re “controlling” with a fraction of cash (thanks to margin).  

### A quick comparative glance – SBI  

To cement the idea, here’s a snapshot of a completely different futures contract – **State Bank of India (SBI)**.  

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/01/Image4_SBI.png)  

From this picture you should be able to answer (and maybe impress your friends at the bar):  

1. What’s the **instrument type**?  
2. What’s the **SBI futures price**?  
3. How does that price compare with the **spot price**?  
4. What’s the **expiry date**?  
5. What are the **lot size** and **contract value**?  

(Feel free to shout out the answers in the comments – we’ll check them later.)  

---  

## 3.2 – The Futures Trade  

Back to our TCS drama. I’m bullish, so I **buy** a TCS futures contract at **₹2 374.90** per share. Remember, the **minimum tradable unit** is 125 shares – that’s one **lot**.  

### How do I actually buy it?  

Two ways:  

1. **Phone a broker** and say, “Hey, give me 1 lot of TCS futures at ₹2 374.90.”  
2. **Do it yourself** via the broker’s trading terminal (my favorite).  

If you’re new to the terminal, skim the “Trading Terminal” chapter first – it’s like learning the cheat codes for a video game. Once the contract is in your **Market Watch**, hit **F1** (the “Buy” key).  

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/01/M4-Ch3-title.jpg)  

Pressing **F1** sets off a cascade of behind‑the‑scenes magic:  

| Step | What happens |
|------|--------------|
| **1️⃣ Margin Validation** | Futures require a **margin** – a token cash deposit (a percentage of the contract value). The system checks that you have enough cash in your account. No margin, no entry. |
| **2️⃣ Counter‑party Search** | The exchange is a **financial supermarket** where buyers meet sellers. The system finds a seller who thinks TCS will *fall* (the opposite of your view). |
| **3️⃣ Digital Sign‑off** | Both parties “sign” the contract electronically. It’s mostly symbolic, but it legally binds you to the agreement. |
| **4️⃣ Margin Block** | The required margin gets **blocked** in your account. It’s locked away until you close the position (or the contract expires). |

All four steps happen in a **blink‑of‑an‑eye** – a few milliseconds on a modern exchange.  

### What does “own 1 lot of TCS futures” really mean?  

It means: **On 15 Dec 2014, I entered a legal promise with a counter‑party** to *buy* 125 TCS shares from them **at ₹2 374.90 each** on **24 Dec 2014** (the expiry). I’ve got the right, not the obligation, to take those shares at that price.  

---  

## 3.3 – The 3 possible scenarios post the agreement  

Fast‑forward to **24 Dec 2014** (the contract’s expiration). Three things can happen – the price goes **up**, **down**, or stays **flat**. (We covered this back in Chapter 1, but let’s see the money‑math in action.)  

### Scenario 1 – TCS rockets up  

Assume TCS climbs from **₹2 374.90** to **₹2 450.00** by expiry. The futures price follows suit, so my contract gives me the right to buy at the old, lower price.  

- **Profit per share** = ₹2 450.00 – ₹2 374.90 = **₹75.10**  
- **Total profit** = ₹75.10 × 125 = **₹9 387.50**  

The seller, on the flip side, is forced to **sell** at ₹2 374.90 when the market pays ₹2 450.00 – a loss of the same amount.  

### Scenario 2 – TCS slides down  

Now imagine TCS drops to **₹2 300.00**. My contract still obliges me to buy at the higher price.  

- **Loss per share** = ₹2 374.90 – ₹2 300.00 = **₹74.90** (rounded to ₹75 for simplicity)  
- **Total loss** = ₹75 × 125 = **₹9 375.00**  

The seller wins the opposite of the first scenario – they sell cheap in the market and *receive* the higher contract price.  

### Scenario 3 – TCS stays put  

If the price sits exactly at **₹2 374.90**, neither side gains nor loses. It’s a financial “meh”.  

---  

## 3.3 – Exploiting a trading opportunity  

Let’s spice things up with a *real‑time* twist. I bought the TCS futures on **15 Dec 2014** at ₹2 374.90. The next day (**16 Dec 2014**) the price **spiked** to **₹2 460.00**.  

My profit at that moment:  

- **Per‑share profit** = ₹2 460.00 – ₹2 374.90 = **₹85.10**  
- **Total profit** = ₹85.10 × 125 = **₹10 637.50**  

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/01/Image5_TCS.png)  

### Do I have to sit on this profit until 24 Dec?  

Nope! Futures are **traded contracts**. You can exit (or “square‑off”) anytime before expiry.  

**Squaring off** = closing the open position by doing the opposite trade. I bought 1 lot, so I now **sell** 1 lot.  

When I click “sell” (or tell my broker), a few things happen:  

1. **Counter‑party Search** – The system finds someone who wants to **buy** my contract at the current market price (₹2 460). I’m essentially handing off my risk to them.  
2. **Trade Execution** – The sale occurs at the prevailing futures price.  
3. **Margin Release** – The blocked margin is freed up for other trades.  
4. **PnL Credit/Debit** – My account gets credited the ₹10 637.50 profit **the same evening** (assuming the market is still open).  

So, in a single day I turned a **₹2 374.90** entry into a **₹10 637.50** profit – not bad for a coffee‑break trade!  

### What if I’m still bullish?  

If I still think TCS will climb higher, I can simply **hold** the contract until expiry (or any later date). Here’s a snapshot taken on **23 Dec 2014** (one day before expiry):  

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/01/Image6_TCS.png)  

Now the futures price is **₹2 519.25**! Had I held the position, my profit would have been:  

- **Per‑share** = ₹2 519.25 – ₹2 374.90 = **₹144.35**  
- **Overall** = ₹144.35 × 125 = **₹18 043.75**  

### A thought experiment  

On **16 Dec** I sold (squared‑off) at ₹2 460. Someone else bought my contract at that price and held it till **23 Dec**.  

| Who | Entry price | Exit price | Per‑share P/L | Total P/L |
|-----|-------------|-----------|----------------|-----------|
| **Me** | ₹2 374.90 | ₹2 460.00 | **+₹85.10** | **+₹10 637.50** |
| **Counter‑party** | ₹2 460.00 | ₹2 519.25 | **+₹59.25** | **+₹7 406.25** |

Feel free to double‑check these numbers in the comments.  

---  

### Key takeaways from this chapter  

- **Directional view** → futures let you profit from a belief that an asset will move up **or** down.  
- **Margin** = a modest cash pledge (a fraction of the contract value) that lets you control a large position.  
- **Digital signature** = you and a counter‑party legally bind yourselves to the contract.  
- **Futures ≠ Spot** – the price gap comes from the **Futures Pricing Formula** (we’ll unpack that later).  
- **Lot size** = the minimum number of shares you must buy/sell (125 for TCS).  
- **No lock‑in** – you can exit a futures position **anytime** before expiry.  
- **Margin block** stays on hold only while the position is open; it’s released on square‑off or expiry.  
- **Square‑off** = you sell (or buy) the opposite side of your existing position, effectively handing the risk to someone else.  
- **Profit/Loss** is settled **the same day** the trade closes.  
- In a futures contract, **one party’s gain is the other’s loss** – it’s a zero‑sum game.  

Next up: **Margins** – the lifeblood that lets you play futures without needing the full contract value up front. Stay tuned, and keep those trading jokes coming! 🍻