# 10. The Futures Pricing  

**Source:** https://zerodha.com/varsity/chapter/futures-pricing/

---  

##  

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/02/M4-Ch10-title.jpg)  

## 10.1 – The Pricing Formula  

If you ever signed up for a “serious‑business” futures class, the professor would have slapped the futures‑pricing equation on the board **before** you even learned what a candle stick looks like. We deliberately *saved* it for later because—let’s be honest—most of you are probably using chart patterns, trendlines, and that “feel‑good” vibe to pick futures contracts. In that case you don’t *need* to know why the price is what it is, but it never hurts to have a cheat‑sheet in the back pocket (especially when you want to sound like a quant at a cocktail party).  

If you’re the type who wants to run Calendar Spreads, Index Arbitrage, or any other fancy‑sounding quantitative play, you **must** get cozy with the pricing formula. In fact, we’ll later devote an entire module to those strategies, and this chapter is the textbook you’ll be quoting while the rest of us are still guessing why the market moved.  

Remember those occasional asides in earlier chapters where we hinted at a “Futures Pricing Formula” being the reason the spot and futures don’t sit on the same chair at the dinner table? Time to pull back the curtain and let the math do the heavy lifting.  

A futures contract gets its mojo from the underlying asset. When the underlying goes up, the future goes up; when it drops, the future drops—*in sync*. Yet, they rarely match price‑for‑price. To illustrate, at the moment of writing, **Nifty Spot = 8,845.5** while the front‑month Nifty future is trading at **8,854.7**. That 9.2‑point gap is what the traders call the **basis** or **spread**.  

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/02/Image-1_Fut-Price.jpg)  

Why does that gap exist? It’s the manifestation of **Spot‑Future Parity**, the little arithmetic that accounts for interest rates, dividends, days to expiry, and a sprinkle of market friction. In plain English: it’s the equation that says “the future should be worth the spot plus the cost of holding it, minus any cash you’ll collect”.  

The textbook version of that equation looks like this:  

\[
\text{Futures Price} = \text{Spot price} \times (1 + r_f) - d
\]

where  

* **\(r_f\)** = risk‑free rate (the “you‑could‑have‑parked‑your‑cash‑in‑the‑bank” return)  
* **\(d\)** = dividend paid during the life of the contract  

A couple of practical notes: the risk‑free rate is quoted **annualised** (i.e., for a full 365‑day year). If your contract expires in, say, 45 days, you need to scale it down proportionally. The more *generic* version of the formula therefore becomes:  

\[
\text{Futures Price} = \text{Spot price} \times \Bigl[1 + r_f \times \frac{x}{365}\Bigr] - d
\]

where **\(x\)** is the number of days until expiry.  

> **Pro‑Tip:** In India the 91‑day RBI Treasury bill is a handy proxy for the short‑term risk‑free rate. You can grab the latest % on the RBI’s homepage (see screenshot below).  

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/02/Image-2_RBI.jpg)  

At the time of writing the RBI T‑Bill rate is **8.3528 %**. Let’s plug that into a real‑world example.  

**Scenario:** Infosys is sitting at a spot price of **2,280.5** and the contract expires in **7 days**. No dividend is expected in that tiny window (so **\(d = 0\)**).  

\[
\text{Futures Price} = 2,280.5 \times \Bigl[1 + 8.3528\% \times \frac{7}{365}\Bigr] - 0
\]  

Crunch the numbers and you get a *fair value* of roughly **2,283**. That’s the theoretical price where the future *should* sit if the market were a perfectly efficient robot.  

But the market is run by humans (and sometimes bots with a sense of humor). The actual trading price you’ll see on the screen is **2,284**. We call that the **Market Price**.  

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/02/Image-3_Infy.jpg)  

Why the 1‑point bump? Transaction costs, taxes, margin requirements, and the occasional “just‑because‑I‑feel‑like‑it” premium all add a little friction. The fair value, however, gives you a solid anchor: it tells you where the future *ought* to be given the prevailing risk‑free rate and days‑to‑expiry.  

### Let’s stretch the example out to longer expiries  

**Mid‑month contract** (expires 34 days from now, i.e., 26 Mar 2015)  

\[
\text{Futures Price} = 2,280.5 \times \Bigl[1 + 8.3528\% \times \frac{34}{365}\Bigr] = 2,299
\]  

**Far‑month contract** (expires 80 days from now, i.e., 30 Apr 2015)  

\[
\text{Futures Price} = 2,280.5 \times \Bigl[1 + 8.3528\% \times \frac{80}{365}\Bigr] = 2,322
\]  

Now, let’s see what the exchange is actually quoting.  

**Mid‑month snapshot**

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/02/Image-4_Infy.jpg)  

**Far‑month snapshot**

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/02/Image-5_Infy.jpg)  

Notice the gap between *theory* and *reality* widens as you move further out. That’s because the longer you wait, the more room there is for **costs** (margin, financing, etc.) and **expectations** (future dividends, earnings surprises) to creep in.  

---

### Premium vs. Discount (aka Contango vs. Backwardation)  

When the future trades **above** the spot, the market calls it a **premium** (or, in commodity‑speak, **contango**). It’s the “normal” state—think of it as the future saying, “I’m more expensive because I have to carry the cost of money until I’m delivered.”  

Conversely, when the future is **below** the spot, we say it’s at a **discount** (or **backwardation** for commodities). This usually happens when short‑term supply‑demand quirks make the spot pricey relative to the future.  

Here’s a chart that shows Nifty spot and its January‑2015 future, with the future perched nicely above the spot for the whole contract life.  

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/02/Image-6_Spread.jpg)  

A few take‑aways from that picture:  

* **Early in the series** (black arrow) the spread is *wide* because **\(x/365\)** is big—there’s a lot of time value left.  
* Throughout the series the future stays **premium** to the spot.  
* **Near expiry** (blue arrow) the two lines meet. No matter how wild the spread got, they *must* converge on the settlement day.  
* If you forget to close your position before the expiry, the exchange will automatically square you off at the spot price—because the future has turned into the spot, and the market doesn’t like dangling contracts.  

That convergence rule is a safety net: regardless of premium or discount, **Futures = Spot on expiry** (barring extreme corporate actions).  

---

## 10.2 – Practical Application  

Now that you’ve swallowed the math, let’s see how it can actually earn you some cash (or at least keep you from looking like a clueless bystander). The pricing formula becomes a **magnifying glass** for spotting mis‑priced contracts—gold for anyone who loves quantitative trading.  

> **Disclaimer:** This is just a teaser. Full‑blown strategy details will appear in the upcoming “Trading Strategies” module.  

### Example: Spot‑Future mismatch in Wipro  

* **Spot price (Wipro)** = 653  
* **Risk‑free rate** = 8.35 % (annual)  
* **Days to expiry** = 30  
* **Dividend** = 0  

Plug into the formula:  

\[
\text{Fair Futures} = 653 \times \Bigl[1 + 8.35\% \times \frac{30}{365}\Bigr] = 658\ (\text{approximately})
\]  

So, in a frictionless world you’d expect the Wipro future to hover around **658**.  

Now imagine the market is quoting **700** for that same contract. That’s a **42‑point** premium over the fair value—an *obviously* exploitable spread (ignoring transaction costs for a moment).  

### How to harvest that spread  

When the future is *expensive* relative to the spot, you **sell the future** and **buy the spot** (buy cheap, sell dear).  

| Action | Price | Qty (for illustration) |
|--------|------|------------------------|
| **Buy** Wipro Spot | 653 | 1 lot |
| **Sell** Wipro Future | 700 | 1 lot |

What happens on expiry? The future and the spot will *meet* at whatever price the market decides—let’s say 675, 645, or 715. No matter where they meet, you’ve locked in the **initial spread** of **700 – 653 = 47 points** (minus costs).  

In other words, you’ve created a **cash‑and‑carry arbitrage**: buy the cheap asset now, sell the overpriced derivative, and let the convergence do the rest. The profit is *synthetic* and independent of market direction—just the classic “long‑short” dance.  

> **Pro tip:** Close out the positions *just before* expiry to avoid the exchange’s automatic square‑off (which could bite you on slippage).  

---

## 10.3 – Calendar Spreads  

A **Calendar Spread** is basically the same idea as cash‑and‑carry, but instead of pairing a spot with a future, you pair **two futures** of the *same* underlying that expire at different times. Think of it as a “future‑for‑future” trade.  

Let’s reuse the Wipro numbers, but now with two contracts:  

| Contract | Days to expiry | Fair value (theory) | Market price |
|----------|----------------|---------------------|--------------|
| **Current month** | 30 | 658 | 700 |
| **Mid month** | 65 | 663 | 665 |

Observations:  

* The **current‑month** future is *way* above its theoretical value (700 vs. 658).  
* The **mid‑month** future is almost spot‑on (665 vs. 663).  

Assuming the mid‑month contract will stay close to its fair value, you can *sell* the overpriced current contract and *buy* the cheaper mid‑month contract.  

**Trade set‑up:**  

* **Sell** Current‑month Future @ **700**  
* **Buy** Mid‑month Future @ **665**  

Spread = **700 – 665 = 35 points**  

Because you’re dealing with the *same* underlying, the net market exposure is tiny, and the required margin is *much* lower than holding each leg separately (the positions hedge each other).  

### What happens at expiry?  

When the current‑month contract expires, it collapses onto the spot price. Meanwhile, the mid‑month contract still has time left, so its price will adjust accordingly. In practice you’ll usually **close both legs a few days before the first contract expires** to avoid the mechanical settlement process.  

Let’s run a couple of “what‑if” scenarios (just for fun):  

| Spot at expiry | P/L on sold current contract | P/L on bought mid contract | Net P/L |
|----------------|-----------------------------|---------------------------|----------|
| 680 | 700 – 680 = **+20** | 665 – 680 = **‑15** | **+5** |
| 640 | 700 – 640 = **+60** | 665 – 640 = **+25** | **+85** |
| 720 | 700 – 720 = **‑20** | 665 – 720 = **‑55** | **‑75** |

The exact numbers will differ because the mid‑month contract’s price will move as the market evolves, but the **core idea** remains: you lock in the *initial spread* and let time do the rest.  

> **Reality check:** The success of a calendar spread hinges on the assumption that the *near‑month* contract’s mispricing will correct faster than the *far‑month* one. Historically this works a lot, but not always—so always keep an eye on news, earnings, and the RBI’s rate moves.  

---

### Key takeaways from this chapter  

- **Futures Pricing Formula:** \(\displaystyle \text{Futures Price} = \text{Spot} \times \bigl[1 + r_f \times \frac{x}{365}\bigr] - d\)  
- **Basis / Spread** = Futures price – Spot price.  
- **Theoretical Fair Value** = price you get from the formula (what the future *should* be).  
- **Market Value** = the price you actually see on the exchange.  
- Fair value ≈ market value; deviations are mainly due to transaction costs, taxes, and margin requirements.  
- When futures > spot → **Premium** (aka **Contango** in commodities).  
- When futures < spot → **Discount** (aka **Backwardation** in commodities).  
- **Cash‑and‑carry arbitrage** = buy the cheap spot, sell the expensive future, collect the spread at expiry.  
- **Calendar spread** = sell an overpriced near‑month future, buy a fairly‑priced farther‑month future of the same underlying; margins are lower because the positions offset each other.  
- The **convergence rule**: on expiry, futures and spot *must* meet, regardless of premium/discount during the life of the contract.  

Armed with these equations and the intuition behind them, you can now read futures charts the way you read a good joke—spot the punchline (the spread), understand why it’s there, and decide whether to laugh *with* the market or *at* it. Cheers to smarter (and funnier) trading!