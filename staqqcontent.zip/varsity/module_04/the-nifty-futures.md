# 9. The Nifty Futures  

**Source:** <https://zerodha.com/varsity/chapter/nifty-futures/>

---  

## 9.1 – Basics of the Index Futures  

In the Indian derivatives playground, the **Nifty Futures** is the rock‑star‑the‑lead‑guitar‑solo‑of‑the‑market. It’s the most‑traded futures contract in India and, if you didn’t know, it also sneaks into the **top‑10 index futures** worldwide (yeah, it’s that cool).  

Once you’ve gotten the hang of futures –‑‑ and let’s be honest, most of us end up day‑trading them while sipping chai –‑‑ you’ll probably find yourself staring at the Nifty chart more often than your own bank balance. So, it makes perfect sense to give this instrument a proper, no‑fluff walkthrough.  

> **Quick reminder:** If you’ve already brushed up on what an *index* is (we covered that earlier *here*), feel free to skip that part. If not, go read it; otherwise you’ll be like “what’s a basket of 50 stocks?” while the market’s already moving on.

### What’s a futures contract, anyway?  

A futures contract is a **derivative** – a fancy word for “it gets its value from something else.” In the case of Nifty Futures, the *something else* is the **Nifty Index** itself. Think of it as a mirror: when the index climbs, the futures climb; when the index trips, the futures slip on the same banana peel.  

Here’s a quick snapshot of a Nifty Futures contract (taken from Zerodha’s UI – don’t worry, the colors are still as bright as a Bollywood dance number).  

![Image](https://zerodha.com/varsity/wp-content/uploads/2015/02/Screenshot_802.png)

A few things to notice (the red boxes are my personal “hey, look here!” highlights):  

| Item | What it means |
|------|---------------|
| **Expiry variants** | Current month, Mid‑month, Far‑month – basically “today’s pizza,” “tomorrow’s pizza,” and “next‑week’s pizza.” |
| **Futures price** | In the screenshot it was **₹ 11,484.9** per Nifty point. |
| **Spot (underlying) price** | **₹ 11,470.70** – the index you see on the news channel. |
| **Lot size** | **75** Nifty points per contract (yes, we’re still talking about points, not shares). |

Why isn’t the futures price exactly the same as the spot price? Because futures have a **pricing formula** that adds a little “carry cost” (think of it as a tiny interest‑like fee for promising to buy/sell later). We’ll dissect that formula in the next chapter.  

### Contract value in plain English  

The **contract value (CV)** tells you how much money is “on the line” for a single contract:

\[
\text{CV} = \text{Futures Price} \times \text{Lot Size}
\]

Plugging the numbers from our screenshot:

\[
\text{CV} = 11{,}484.90 \times 75 = \mathbf{₹ 861,367}
\]

That’s more than the price of a decent used car – but remember, you’re not actually paying that cash up front; you just need to post **margin**.

### Margin – the “security deposit” for traders  

Using Zerodha’s margin calculator (the same one that makes you feel like a financial wizard), you’ll see the required **initial margin** for a Nifty Futures contract is roughly **12‑15 %** of the contract value. In other words, you need about **₹ 100,000‑130,000** to control a ₹ 861k exposure. Compare that with many single‑stock futures that demand **45‑60 %** margin – the Nifty contract is the bargain‑bin item of the derivatives aisle.  

All of this underscores why Nifty Futures are so popular: **liquidity** (easy to buy/sell), **low margin**, and **tight spreads**. Let’s dig a little deeper into that liquidity thing next.  

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/02/M4-Ch9-title.jpg)

---

## 9.2 – Impact Cost  

*Updated 24 August 2021* – The NSE defines **Impact Cost** as the extra penny you pay (or lose) when you actually execute a trade, compared to the “ideal” price you *would* get if the market were a perfectly liquid lake. In plain English, it’s the price‑slippage you feel when you push a big order through the order book.  

Why do we care? Because **Impact Cost ≈ Liquidity**. Lower impact cost → more liquid → cheaper trading. It’s a more realistic measure than the simple bid‑ask spread, especially for big orders.  

### The formula (no PhD required)  

1. **Ideal Price** – the midpoint of the best bid and best ask:  

\[
\text{Ideal Price} = \frac{\text{Best Buy} + \text{Best Sell}}{2}
\]

2. **Actual Buy Price** – the volume‑weighted average price (VWAP) you actually paid:  

\[
\text{Actual Buy Price} = \frac{\sum (\text{Qty}_i \times \text{ExecPrice}_i)}{\sum \text{Qty}_i}
\]

3. **Impact Cost** – the percentage deviation from the ideal price:  

\[
\text{Impact Cost} = \frac{\text{Actual Buy Price} - \text{Ideal Price}}{\text{Ideal Price}} \times 100
\]

### Example: buying 350 shares of Infosys  

Here’s the order‑book snapshot we’ll use (courtesy of Zerodha):

![Image](https://zerodha.com/varsity/wp-content/uploads/2015/02/Infy_orderbook.png)

Assume you want **350** shares. The best buy (bid) is **₹ 1,657.95**, the best sell (ask) is **₹ 1,658.00**.  

* **Ideal Price**  

\[
\frac{1{,}657.95 + 1{,}658.00}{2} = 1{,}657.975 \approx \mathbf{₹ 1,657.98}
\]

* **Actual Buy Price** (we fill 15 shares at the ask, the remaining 335 at the next level **₹ 1,658.20**):  

\[
\frac{(15 \times 1{,}658) + (335 \times 1{,}658.20)}{350}
= \frac{24{,}870 + 555{,}247}{350}
= \frac{580{,}117}{350}
\approx \mathbf{₹ 1,658.19}
\]

* **Impact Cost**  

\[
\frac{1{,}658.19 - 1{,}657.98}{1{,}657.98} \times 100
\approx 0.012\%
\]

So you paid **0.012 %** more than the “fair” price – a tiny but real cost that would balloon if you tried to buy, say, 10,000 shares.  

### Key messages (in bar‑talk form)  

- **Impact cost = liquidity gauge.** The lower it is, the more “liquid” the security.  
- **Tight spreads → low impact cost.** Wide spreads mean you’re paying (or receiving) more slippage.  
- **Higher liquidity = lower volatility.** (Because lots of participants smooth out the bumps.)  
- **Avoid market orders on illiquid stocks.** Use limit orders, or you’ll get whacked by impact cost.  

Bottom line: If a security’s impact cost is **under 0.01 %**, you’re basically trading on a treadmill that never slips. Nifty Futures sit comfortably at around **0.0082 %**, which is why they’re the darling of day‑traders.

---

## 9.3 – Why Trading Nifty Makes Sense  

The **Nifty Index** is a basket of **50 of India’s biggest, shiniest stocks**, carefully chosen to represent the country’s economic kaleidoscope. Because it’s a *basket*, the index moves with the *overall* economy rather than the whims of a single company. That makes Nifty Futures a *safer* (relatively speaking) playground than single‑stock futures.  

Here’s a cheat‑sheet of why you should consider the Nifty as your go‑to derivative instrument:

| Reason | What it means for you |
|--------|----------------------|
| **Diversified** | Instead of betting on one horse (e.g., Infosys), you own a whole stable of 50 horses. If a few stumble, the rest keep you afloat. This wipes out **unsystematic risk** (company‑specific surprises) and leaves you with **systematic risk** (market‑wide moves). |
| **Hard to manipulate** | Moving the Nifty would require pulling the strings of *all* 50 top‑cap companies simultaneously – practically impossible. Remember the Satyam drama? That was a single‑stock circus, not a Nifty‑wide act. |
| **Highly liquid** | You can buy or sell *any* number of contracts without worrying about impact cost blowing up. The order book is as deep as a swimming pool, not a kiddie tub. |
| **Lower margins** | As we saw, you need only about **12‑15 %** margin versus **45‑60 %** for many stock futures. That means you can control more exposure with the same cash. |
| **Broad‑based economic call** | Trading Nifty is like saying “I think India’s economy will do X” instead of “I think Tata Motors will do X”. Macro calls are generally easier to form and often more reliable. |
| **Technical Analysis loves it** | TA thrives on clean price action. The Nifty’s huge volume makes price charts less noisy and patterns more trustworthy. |
| **Less volatile** | Annualised volatility for Nifty Futures hovers around **16‑17 %**, whereas a typical single stock (e.g., Infosys) can be **30 %+**. Lower volatility = tighter risk‑reward curves, which many traders adore. |

### TL;DR for the bar‑crowd  

- **Diversification = risk reduction** (you’re not putting all your eggs in one basket).  
- **Liquidity = cheap trades & less slippage** (you can enter/exit fast).  
- **Margin efficiency = more bang for your buck** (you can trade bigger positions).  
- **Macro view = easier to call** (you don’t need to read every quarterly report).  

---

### Key takeaways from this chapter  

- **Nifty Futures** derive their price from the **spot Nifty Index** (the underlying).  
- The current **lot size** is **75** points per contract.  
- It’s the **most liquid futures contract** in India (and up there globally).  
- Like any futures, Nifty contracts come in three expiry buckets: **Current month, Mid‑month, Far‑month**.  
- A **round‑trip trade** (buy‑then‑sell instantly at the best quotes) always yields a *tiny loss* due to the spread.  
- **Impact cost** quantifies that loss as a percentage of the mid‑price; the lower the number, the higher the liquidity.  
- Higher impact cost → lower liquidity (and vice‑versa).  
- Market orders can bite you with impact cost; limit orders are the safer bet on less‑liquid instruments.  
- Nifty’s impact cost is **≈ 0.0082 %**, making it essentially “free” in terms of slippage.  

Now that you’ve got the Nifty basics down, go ahead and practice a few paper trades. Remember: the market’s a marathon, not a sprint – except on the days when you’re trading futures, when it feels like a sprint with a treadmill that never stops. Happy trading!  