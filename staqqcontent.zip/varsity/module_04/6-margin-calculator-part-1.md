# 6. Margin Calculator (Part 1)

**Source:** <https://zerodha.com/varsity/chapter/margin-calculator-part-1/>

---  

##  

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/01/M4-Ch6-title.jpg)

## 6.1 – The Margin Calculator  

Welcome back, future‑margin‑magician! In the last chapter we dissected the *why* of margins; now it’s time to meet the *how*. Over the next two chapters we’ll tango with Zerodha’s Margin Calculator, sprinkle in a few side‑dish concepts, and come out the other side with a crystal‑clear picture of how much cash you need to lock up before you can shout “Buy!” at the exchange.  

Quick refresher: every futures contract carries its own **Initial Margin (IM)**, which is just the sum of **SPAN Margin** (the risk‑based component) and **Exposure Margin** (the safety‑net component). The exact numbers change from contract to contract because volatility is the mischievous gremlin that drives margin requirements. More volatility = more margin = more “keep‑your‑money‑in‑the‑bank” vibes.  

So, how do you actually find out the IM for, say, a particular IDEA Cellular futures? If you’re a Zerodha fan (and who isn’t these days?), you’ve probably spotted the shiny **Margin Calculator** button floating around the platform. It looks like a simple button, but underneath it hides a sophisticated engine that does the heavy lifting for you.  

In this chapter we’ll walk through a real‑world example, then tease the next module where we’ll unleash the calculator on options (because why stop at futures when you can have the whole buffet?).  

### Example: Buying IDEA Cellular Futures (exp 29 Jan 2015)  

1️⃣ **Open the calculator** – the URL is <https://zerodha.com/margin-calculator/SPAN/>. When you land there you’ll see a smorgasbord of options (highlighted in black below). For now, we’ll focus on the first two tabs: **SPAN** and **Equity Futures**. By default you’re dropped onto the SPAN sub‑page (the red highlight).  

   ![Image](http://zerodha.com/varsity/wp-content/uploads/2015/01/M4-Ch6-chart2.jpg)  

2️⃣ **Take a look at the layout** – the SPAN calculator is split into two main zones (see the screenshot). The red zone houses the three drop‑downs that let you tell the calculator *what* you want to trade.  

   ![Image](http://zerodha.com/varsity/wp-content/uploads/2015/01/M4-Ch6-chart3.jpg)  

3️⃣ **Set the drop‑downs**  

   - **Exchange** – pick where you’ll trade:  
     - **NFO** for NSE futures,  
     - **MCX** for commodity futures,  
     - **CDS** for currency derivatives.  
   - **Product** – choose **Futures** (or **Options** if you’re feeling adventurous).  
   - **Symbol** – finally, select the exact contract you want. In our demo we pick **IDEA Cellular Ltd., Jan 29 2015**.  

   ![Image](http://zerodha.com/varsity/wp-content/uploads/2015/01/M4-Ch6-chart4.jpg)  

4️⃣ **Quantity & direction** – As soon as you pick the contract, the **Net Quantity** field auto‑fills with the contract’s lot size (IDEA’s lot = 2,000 shares). Want more than one lot? Multiply: 3 lots → 6,000 shares. Then click **Buy** or **Sell** (depending on your market mood) and smash the big blue **Add** button.  

   ![Image](http://zerodha.com/varsity/wp-content/uploads/2015/01/M4-Ch6-chart5.jpg)  

5️⃣ **See the magic happen** – The calculator spits out a neat breakdown: SPAN margin, Exposure margin, and the total Initial margin. It’s highlighted in the red box below.  

   ![Image](http://zerodha.com/varsity/wp-content/uploads/2015/01/M4-Ch6-chart6.jpg)  

**Result (as of the snapshot):**  

| Component | Amount (₹) |
|-----------|------------|
| **SPAN Margin** | 22,160 |
| **Exposure Margin** | 14,730 |
| **Initial Margin (SPAN + Exp)** | **36,890** |

Boom! That’s the exact cash you need to park in your Zerodha account to open the IDEA futures position. Easy as pie… or at least as easy as figuring out how much you need to keep in the “rainy‑day” jar.

The next section of the calculator – **Equity Futures** – will be our playground in the next chapter. But before we jump there, let’s quickly get comfy with three side‑kicks that will make the equity‑futures tab less mystifying: **Expiry**, **Spreads**, and **Intraday order types**. Ready? Let’s roll.

## 6.2 – Expiry  

Remember the “expiry date” we brushed on in earlier chapters? It’s the day the contract says “Adios, I’m outta here!” – the last moment you can own that futures contract before it self‑destructs.  

Picture this: you buy IDEA Cellular futures at ₹149, expiring on **29 Jan 2015**, hoping it rockets to ₹155. If the price hits ₹155 **on or before** 29 Jan, you’re golden. If it only gets there **after** the expiry (say, 30 Jan), the contract has already vanished, and you can’t cash in. In other words, futures are like a date‑night reservation – you have to show up before the kitchen closes.  

### Can you be a little more flexible?  

Sure, if you’re clever about which contract you pick. Let’s say you’re eyeing the **February budget** (the Indian government’s big‑ticket event) and you think the **Make‑in‑India** push will give **Bharat Forge Ltd.** a turbo‑charge. The budget is slated for the **last week of February 2015**, but the nearest futures contract (the Jan 29 one) expires **mid‑January** – way too early for your budget‑bet.  

What do you do? Pick a later‑expiring contract!  

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/01/M4-Ch6-chart7.jpg)  

Bharat Forge’s **Jan 2015** futures are trading at ₹1,022, but you need exposure **beyond** that date. NSE lets you choose from three consecutive expiries at any point in time:

| Expiry | Nickname |
|--------|----------|
| 29 Jan 2015 | **Current month** (or “near month”) |
| 26 Feb 2015 | **Mid‑month** |
| 26 Mar 2015 | **Far month** |

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/01/M4-Ch6-chart8.jpg)  

You can pull the **expiry drop‑down** and pick the **Feb 2015** contract (the mid‑month) to stay in the game until after the budget.  

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/01/M4-Ch6-chart9.jpg)  

Notice the price bump:  

- **Jan contract** = ₹1,022.8  
- **Feb contract** = ₹1,032 (a bit pricier)  
- **Mar contract** = ₹1,037.4  

Longer time = higher futures price. Simple economics: the market tacks on a “time premium” for the extra days you’re holding the contract.  

#### How the contract roll‑over works  

When the **Jan 2015** contract expires at 3:30 PM on 29 Jan, it disappears from the order book. The next trading day (9:15 AM on 30 Jan) NSE rolls out a **new far‑month contract** – in this case, **Apr 2015**. The line‑up then looks like this:

| New “Current” | New “Mid” | New “Far” |
|---------------|-----------|-----------|
| Feb 2015 (was Mid) | Mar 2015 (was Far) | Apr 2015 (new) |

…and the cycle repeats each month.  

### The “rollover” trick  

Instead of jumping straight to the Feb contract, you could *roll* your Jan position into Feb when Jan is about to expire:  

1. Close the Jan contract a few minutes before 3:30 PM.  
2. Open a fresh Feb contract with the same direction (buy or sell).  

Why bother? Liquidity. The **current‑month contract** is usually the most liquid (lots of traders, tighter spreads). By rolling, you stay in the deep‑liquidity pool while still preserving your longer‑term view.  

TV anchors love to throw around “roll‑over data” near expiry. It’s basically a percentage of traders who moved their positions from the current month to the next. A high **long‑roll‑over** percentage is interpreted as bullish, while a high **short‑roll‑over** is seen as bearish. It’s a nifty sentiment gauge, but don’t treat it as a crystal ball.  

## 6.3 – Sneak Peek into Spreads  

Alright, strap in – we’re entering “spread‑land”. This part can feel a bit head‑spin‑y, but stick with me and you’ll see why spreads are the secret sauce of many professional traders.  

### Two contracts, one underlying  

Take the same underlying – **Bharat Forge Ltd.** – but look at two different expiries:

| Contract | Expiry |
|----------|--------|
| **Jan 2015** | 29 Jan 2015 |
| **Feb 2015** | 26 Feb 2015 |

Both react to the same spot price movements, but they trade at slightly different levels because of the time‑premium we discussed earlier.  

### Calendar spread = buy one month, sell another  

A **Calendar Spread** (aka **Time Spread**) is when you *simultaneously* go long on one expiry and short on another. Why do this? Because the risk profile changes dramatically – you’re essentially betting on the *shape* of the futures curve rather than the outright direction of the underlying.  

Let’s crunch some numbers to see the risk reduction in action.  

#### Scenario 1 – Pure long (January only)  

| Detail | Value |
|--------|-------|
| Spot price | ₹1,021 |
| Jan futures price (entry) | ₹1,023 |
| Lot size | 250 |
| After a 10‑point spot drop → futures ≈ ₹1,013 |
| P&L = (10 pts × 250) = **–₹2,500** loss |

#### Scenario 2 – Long Jan, Short Feb  

| Detail | Jan (Long) | Feb (Short) |
|--------|------------|-------------|
| Spot price (entry) | ₹1,021 | ₹1,021 |
| Jan futures (entry) | ₹1,023 | — |
| Feb futures (entry) | — | ₹1,033 |
| Lot size | 250 | 250 |
| After 10‑pt drop → Jan ≈ ₹1,013, Feb ≈ ₹1,023 |
| P&L Jan = –₹2,500 | P&L Feb = **+₹2,500** |
| **Net P&L = ₹0** |

#### Scenario 3 – Short Jan, Long Feb  

| Detail | Jan (Short) | Feb (Long) |
|--------|-------------|------------|
| Spot price (entry) | ₹1,021 | ₹1,021 |
| Jan futures (short) | ₹1,023 | — |
| Feb futures (long) | — | ₹1,033 |
| After 10‑pt rise → Jan ≈ ₹1,033, Feb ≈ ₹1,043 |
| P&L Jan = –₹2,500 | P&L Feb = **+₹2,500** |
| **Net P&L = ₹0** |

**Takeaway:** By being long one month and short another, the directional exposure cancels out, leaving you essentially *market‑neutral*. The only things left to worry about are **liquidity**, **volatility** and **execution slippage**.  

### What does this mean for margins?  

Lower risk → lower margin. Let’s see the actual numbers from Zerodha’s calculator (screenshots below).  

- **Only Jan contract (buy)** → **₹37,362** margin  
  ![Image](http://zerodha.com/varsity/wp-content/uploads/2015/01/M4-Ch6-chart10.jpg)  

- **Only Feb contract (sell)** → **₹37,629** margin  
  ![Image](http://zerodha.com/varsity/wp-content/uploads/2015/01/M4-Ch6-chart11.jpg)  

- **Calendar spread (buy Jan, sell Feb)** → **₹7,213** margin  
  ![Image](http://zerodha.com/varsity/wp-content/uploads/2015/01/M4-Ch6-chart12.jpg)  

Individually the two contracts would demand **₹74,991** in total. When you pair them in a spread, the required margin plummets to **₹7,213** – a **₹67,658** saving! That’s the “margin benefit” highlighted in black on the screenshot.  

But remember, you only get this sweet discount **when a genuine spread opportunity exists**. If the two legs are not meaningfully related (or the price differential is too wide), the spread isn’t worth the trade.  

### TL;DR on spreads  

- A **Calendar Spread** = buy one month, sell another, same underlying.  
- Directional risk is largely neutralised, so **margin requirements drop dramatically**.  
- Liquidity, volatility, and execution still matter – it’s not a free‑lunch.  

## Key Takeaways from this Chapter  

- Zerodha’s Margin Calculator is a no‑nonsense tool that tells you exactly how much cash you need to lock up for a futures trade.  
- The calculator splits the requirement into **SPAN** and **Exposure** components, giving you transparency.  
- NSE always lists **three consecutive contracts** (Current, Mid, Far month) for any liquid underlying, letting you pick the expiry that matches your view.  
- The **Current‑month contract** is the most liquid, the **Mid‑month** sits in the middle, and the **Far‑month** is the longest‑dated.  
- When a contract expires, a new far‑month contract is introduced, and the other two “graduate” to become the new current and mid contracts.  
- A **Calendar Spread** is a strategy that involves being long one expiry and short another simultaneously.  
- Because a spread drastically reduces directional risk, the **margin requirement** for a spread is **much lower** than the sum of the two single‑leg margins.  

Now that you’ve got the calculator under your belt, the next chapter will pull the **Equity Futures** tab into the spotlight. Spoiler: you’ll see how the same principles apply, plus a few extra tricks for equity‑specific nuances. Grab a coffee, keep those jokes handy, and let’s keep the margin‑math rolling!