# 12. Open Interest  

**Source:** <https://zerodha.com/varsity/chapter/open-interest/>

---  

##  

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/03/M4-Ch12-Title1.jpg)  

## 12.1 – Open Interest and its calculation  

Alright, before we close the **Futures Trading** chapter, let’s tackle the three‑word question that shows up on everyone’s cheat‑sheet:  

*“What the heck is Open Interest (OI)?”*  
*“How is it different from Volume?”*  
*“Can I actually use this stuff, or is it just market‑lore?”*  

Stick with me and, by the end of this section, you’ll be reading OI numbers the way a bartender reads a cocktail menu—instantly knowing which one will give you a buzz and which one will just leave you with a headache. (If you’re fuzzy on Volume, feel free to hit the refresher link [here](https://zerodha.com/varsity/chapter/volume/).)

**Open Interest** is simply a head‑count of how many futures (or options) contracts are **still alive** in the market. Think of it as the number of people still dancing at the club after the DJ’s first track—each dancer has a partner, so the total number of “pairs” is what OI counts.

Remember: every trade has two sides—a buyer (long) and a seller (short). If Alice sells one contract to Bob, Bob is **long** one, Alice is **short** one, and the OI goes up by **1** (because a brand‑new contract now exists).

### Let’s walk through a sitcom‑style saga

We’ll use five fictional characters who love NIFTY futures more than they love their morning coffee: **Arjun, Neha, Varun, John, and Vikram**. Grab some popcorn; the story gets a little long, but it’s worth it. (Patience is a virtue—just like waiting for the market to move in your favor.)

---

#### Monday  

- **Arjun** buys **6** contracts.  
- **Varun** buys **4** contracts.  
- **Neha** sells all **10** contracts (the exact amount Arjun + Varun just bought).  

Result: 10 contracts are “live” – 10 longs (6 + 4) and 10 shorts (all belonging to Neha).  
**Open Interest = 10**.

| Trader | Long | Short | Net |
|--------|------|-------|-----|
| Arjun  | 6    | 0     | +6 |
| Varun  | 4    | 0     | +4 |
| Neha   | 0    | 10    | –10|
| **Total** | **10** | **10** | **0** |

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/03/Image-1.jpg)

---

#### Tuesday  

Neha decides she’s had enough of the short‑side drama and wants to ditch **8** of her 10 short contracts. **John** strolls in, grabs those 8 shorts, and—voilà—no new contracts are created; it’s merely a hand‑off.

**Open Interest stays at 10** (the same 10 contracts, just a new owner).

| Trader | Long | Short | Net |
|--------|------|-------|-----|
| Neha   | 0    | 2     | –2 |
| John   | 0    | 8     | –8 |
| **Total** | **0** | **10** | **0** |

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/03/Image-2.jpg)

---

#### Wednesday  

- John feels a little *short‑ish* and adds **7** more shorts.  
- Arjun and Varun each decide to beef up their longs.  
- John sells **3** contracts to Arjun and **2** to Varun (that’s **5** brand‑new contracts).  
- Neha, tired of being short, goes **long** on **2** contracts, which effectively cancels 2 of her shorts. She’s now flat.

Now we have **15** longs (9 + 6) and **15** shorts, so **OI = 15**.

| Trader | Long | Short | Net |
|--------|------|-------|-----|
| Arjun  | 9    | 0     | +9 |
| Varun  | 6    | 0     | +6 |
| John   | 0    | 15    | –15|
| Neha   | 0    | 0     | 0  |
| **Total** | **15** | **15** | **0** |

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/03/Image-3.jpg)

---

#### Thursday  

Enter **Vikram**, the big‑shot who thinks “more contracts = more fun”. He dumps **25** contracts short onto the market.

- John, feeling a little guilty, buys back **10** of his shorts from Vikram (so those 10 disappear from OI).  
- Arjun scoops up another **10** contracts from Vikram.  
- Varun grabs the remaining **5**.

We’ve added **15** *new* contracts (the 25 Vikram introduced minus the 10 John bought back).  
**Open Interest jumps to 30**.

| Trader | Long | Short | Net |
|--------|------|-------|-----|
| Arjun  | 19   | 0     | +19 |
| Varun  | 11   | 0     | +11 |
| John   | 0    | 5     | –5 |
| Vikram | 0    | 30    | –30|
| **Total** | **30** | **30** | **0** |

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/03/Image-4.jpg)

---

#### Friday  

Vikram has a sudden epiphany: “Maybe I should close some positions.” He decides to square off **20** of his 25 shorts.

- He buys **10** contracts from Arjun and **10** from Varun. Those 20 contracts vanish from the market, shaving OI down by 20.

So **OI = 30 – 20 = 10** now.

| Trader | Long | Short | Net |
|--------|------|-------|-----|
| Arjun  | 9    | 0     | +9 |
| Varun  | 1    | 0     | +1 |
| John   | 0    | 5     | –5 |
| Vikram | 0    | 5     | –5 |
| **Total** | **10** | **10** | **0** |

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/03/Image-5.jpg)

---

That’s the gist of Open Interest: a simple count of “open” contracts. If you take the **Contracts Held** column, slap a “+” on every long, a “–” on every short, and add them up, you’ll always get **zero**. Why? Because every dollar (or rupee) that changes hands is a transfer between a buyer and a seller—no new wealth is conjured out of thin air. Derivatives, therefore, are the classic **zero‑sum game** (think of it like a poker table where the total chips stay the same; they just move around).

#### Real‑world snapshot  

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/03/Image-6.jpg)

*As of 4 Mar 2015:* Nifty futures OI ≈ **2.78 crore**. That means roughly 2.78 crore longs and 2.78 crore shorts are dancing together. In the same day, about **55,255** new contracts (≈ 0.2 % of the total) were added.  

A larger OI signals a **more liquid** market—think of a bustling bazaar where you can buy or sell without the price shouting “Whoa, that’s a lot!” Liquidity makes it easier to get in and out at tight bid/ask spreads.

---

## 12.2 – OI and Volume interpretation  

Now that you’ve got the OI party picture, let’s bring **Volume** onto the dance floor.

- **Open Interest** = *How many contracts are currently alive* (a stock‑like “open positions” count).  
- **Volume** = *How many contracts changed hands today* (a “turnover” count).

For every buy there’s a sell, so a day with **400 contracts bought and 400 sold** registers a **volume of 400**, **not 800**. Volume starts at zero each trading day and climbs as trades happen. It’s a *cumulative* counter for that session.

Open Interest, on the other hand, is *dynamic*: it goes up when new contracts are **created**, down when contracts are **closed**, and stays flat when contracts simply **change owners**. In other words, OI is like the number of people still standing on the dance floor, while volume is the number of steps taken during the song.

Let’s recap the Monday‑Friday saga in a tidy OI‑vs‑Volume table.

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/03/Image-7.jpg)

**Key observations**

1. **OI and volume move independently.** Today’s volume tells you nothing about tomorrow’s volume.  
2. **Both numbers are pretty boring on their own.** The magic happens when you pair them with **price action**.  

### How traders read the tea leaves  

| Change in Volume | Change in Price | What Traders Might Think |
|------------------|----------------|--------------------------|
| ↑ (rising)       | ↑ (rising)     | New money is flowing in; bullish strength. |
| ↑                | ↓ (falling)    | New money is flowing in; bearish strength. |
| ↓ (falling)      | ↑              | Old money exiting; bullish but weakening. |
| ↓                | ↓              | Old money exiting; bearish weakening. |

### How traders read OI together with price  

| Change in OI | Change in Price | Interpretation |
|--------------|----------------|----------------|
| ↑            | ↑              | New positions added on the **long** side → bullish conviction. |
| ↑            | ↓              | New positions added on the **short** side → bearish conviction. |
| ↓            | ↑              | Traders are **closing shorts** → bullish reversal. |
| ↓            | ↓              | Traders are **closing longs** → bearish reversal. |

**Cautionary note:** If you spot a **spike in OI** *plus* a **rapid price swing**, beware! That usually means a lot of leverage and euphoria are stacked in the market. In such a scenario, even a tiny trigger (think: a sneeze in a crowded elevator) can unleash a panic‑sell or a frenzied rally.

And that, dear reader, wraps up the Futures‑Trading module. I hope you’ve enjoyed the ride as much as I’ve enjoyed writing it—maybe even a little more, because I get to sprinkle jokes.  

Next stop: **Option Theory**—where the payoff diagrams look like roller‑coasters!

### Key takeaways from this chapter  

- **Open Interest (OI)** = number of contracts that are still *open* (i.e., not yet settled).  
- **OI rises** when fresh contracts are created; **OI falls** when contracts are squared‑off.  
- **OI is unchanged** when a contract simply changes hands (transfer from one trader to another).  
- Unlike Volume, OI is **continuous data**—it can go up, down, or stay flat depending on market activity.  
- On its own, **OI or Volume is dull**; always interpret them **alongside price movements** to extract meaning.  
- **Abnormally high OI** often signals heavy leverage—tread carefully, because a small catalyst can cause a big market wobble.  

*Updated : 24 Aug 2016* – If you plan to use intraday OI as a core signal in your strategy, **read this** before you start trading: <https://zerodha.com/varsity/chapter/intraday-open-interest/>.  

Happy trading, and may your OI always be on your side!  