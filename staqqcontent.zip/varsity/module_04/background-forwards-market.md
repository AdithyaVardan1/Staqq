# 1. Background – Forwards Market  

**Source:** <https://zerodha.com/varsity/chapter/background-forwards-market/>  

---  

##  

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/01/M4-Ch1-title.jpg)  

## 1.1 – Overview  

Welcome to the wild west of finance – the **Futures** arena, where contracts are the cowboys and the underlying assets are their trusty steeds. A *derivative* is simply a security whose value is “borrowed” from something else – the **underlying asset** – which can be a stock, a bond, a barrel of oil, a shiny coin, or even a slice of pizza (okay, maybe not pizza… yet).  

Derivatives aren’t some 21st‑century invention; they’ve been around longer than the pyramids. In India, the very first mention of a forward‑type deal is hidden in Kautilya’s *Arthashastra* (circa 320 BC). Legend has it that Kautilya offered farmers a lump‑sum payment for crops that hadn’t even sprouted yet – essentially the world’s first **forward contract**.  

Because forwards and futures are practically twins separated at birth, the easiest way to get you comfortable with futures is to first dissect the **forwards market**. Think of forwards as the grand‑parent of futures: they share the same DNA, but forwards are a bit more old‑school, handwritten, and, frankly, a little messy.  

A forward contract is the simplest derivative you can imagine. Picture it as the elder sibling of a futures contract – same basic idea (agree today on a price for a future transaction), but the forward is still used today mainly by big‑ticket players like heavy‑industry firms and banks. In this chapter we’ll:

1. Sketch out a textbook forward trade.  
2. Split it into its component parts.  
3. Weigh the pros and cons, so you’ll know when to hug a forward and when to swipe left.  

Grab a drink, settle in, and let’s roll.

## 1.2 – A simple Forwards example  

The forward market was born out of a farmer’s desperate wish to avoid the dreaded “price‑crash‑and‑burn” that can happen after a bumper harvest. In a forward deal, **buyer** and **seller** lock in a price *today* for a delivery *later*, and they do it face‑to‑face, without a middle‑man. That’s why we call it an **OTC (Over‑The‑Counter)** agreement – it’s like a secret handshake between two parties, not a noisy auction on an exchange floor.  

### Meet the characters  

- **ABC Jewelers** – the sparkly‑handed craftsman who needs gold to turn metal into bling.  
- **XYZ Gold Dealers** – the gold‑whisperer who sits on a mountain of bullion and sells it wholesale.  

On **9 Dec 2014**, ABC tells XYZ, “Hey, I’ll need **15 kg** of 999‑purity gold in three months (i.e., **9 Mar 2015**). Let’s lock the price at today’s market level: **₹2,450 per gram** (that’s **₹2,45,00,000 per kilogram**).”  

Do the math:  

\[
15\text{ kg}=15,000\text{ g} \\
15,000\text{ g}\times ₹2,450 = ₹36,750,000 \approx \text{₹3.675 crore}
\]

So, on **9 Mar 2015**, ABC must cough up **₹3.675 cr** and XYZ must deliver the shiny 15 kg of gold. Simple, right? That’s a **forward contract** (or **forward agreement**) in a nutshell.  

But why would either party sign up for this? Let’s peek inside their heads.  

- **ABC’s motivation**: They suspect gold will *rise* over the next three months. By locking today’s price, they dodge the pain of a potential price surge. In forward‑speak, ABC is the **Buyer of the Forward Contract**.  

- **XYZ’s motivation**: They think gold will *fall* soon, so they’d rather sell today’s high price and buy back cheaper later. XYZ is the **Seller of the Forward Contract**.  

Both have opposite crystal balls, and the contract is the legal bridge that lets each chase their own forecast.  

## 1.3 – 3 possible scenarios  

Fast forward (pun intended) to the settlement date, **9 Mar 2015**. Three worlds can materialise, depending on where gold’s price wanders.

### Scenario 1 – Gold goes *up*  

Suppose gold is now **₹2,700 per gram**. ABC’s hunch was right. The contract’s original value (₹3.675 cr) has swelled to:  

\[
15,000\text{ g}\times ₹2,700 = ₹40,500,000 \approx \text{₹4.05 crore}
\]

Because the forward price is locked at **₹2,450**, ABC still pays only **₹3.675 cr** and walks away with gold worth **₹4.05 cr** on the market. That’s a **₹0.375 cr (₹37.5 lakhs)** gain for ABC.  

XYZ, on the other hand, must buy gold at the market price (**₹2,700**) and sell it to ABC for **₹2,450**, swallowing a **₹0.375 cr** loss.  

### Scenario 2 – Gold goes *down*  

Now imagine gold has slid to **₹2,050 per gram**. XYZ’s crystal ball was spot‑on. The contract’s market value is now:  

\[
15,000\text{ g}\times ₹2,050 = ₹30,750,000 \approx \text{₹3.075 crore}
\]

ABC is still *obligated* to pay the pre‑agreed **₹3.675 cr** – a full **₹0.6 cr (₹60 lakhs)** more than the gold’s current market worth. ABC ends up overpaying, while XYZ pockets the extra **₹60 lakhs**.  

### Scenario 3 – Gold stays *flat*  

If gold sits stubbornly at **₹2,450 per gram**, neither party gains nor loses – it’s a perfectly neutral handshake.  

So, the forward contract is a **zero‑sum game**: one side’s win is the other side’s loss. The key is whose forecast is right.  

## 1.4 – 3 possible scenarios in one graph  

Visual learners, rejoice! Below is the classic line‑graph that shows ABC’s profit‑and‑loss (P&L) line as gold’s price moves.

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/01/M4-Ch1-chart1.jpg)  

- The **break‑even** point is at **₹2,450/g** – the contract price.  
- Anything **above** that line is a **profit** for ABC (and a loss for XYZ).  
- Anything **below** that line is a **loss** for ABC (and a profit for XYZ).  

Flip the perspective, and you get XYZ’s mirror image:

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/01/M4-Ch1-chart2.jpg)  

- At **₹2,450/g**, XYZ’s P&L is zero.  
- Higher prices hurt XYZ, lower prices make XYZ grin.  

These charts make it crystal clear: forwards turn price direction into pure cash flow for one side or the other.  

## 1.5 – A quick note on settlement  

Let’s say the market ends up at **₹2,700/g** (Scenario 1). The contract’s “fair value” is now **₹4.05 cr**, but the legal price is still **₹3.675 cr**. When settlement day rolls around, the parties have two ways to close the deal.

### 1️⃣ Physical settlement  

- **ABC** wires **₹3.675 cr** to XYZ.  
- **XYZ** goes to the spot market, buys 15 kg of gold for **₹4.05 cr**, and hands the bullion over to ABC.  

Result: ABC ends up with gold worth **₹4.05 cr**; XYZ is out **₹0.375 cr** (the difference).  

### 2️⃣ Cash settlement  

No gold changes hands. Instead, they simply exchange the **price differential**:  

\[
\text{Difference} = ₹4.05 cr - ₹3.675 cr = ₹0.375 cr = ₹37.5 lakhs
\]

XYZ pays **₹37.5 lakhs** to ABC, and the contract is dead. Both parties keep their original cash positions, but the net cash flow mirrors what the physical trade would have produced.  

In real‑world markets, cash settlement is far more common because it avoids the logistical nightmare of moving 15 kg of gold. We’ll dive deeper into settlement mechanics later, but for now remember: **forward contracts settle either physically (real asset) or cash‑wise (price gap)**.  

## 1.6 – What about the risk?  

Understanding the payoff is fun, but you also need to know what could go *wrong*. Forward contracts carry a handful of risks that futures contracts try to iron out.

| Risk type | What it looks like in our gold story |
|-----------|--------------------------------------|
| **Liquidity risk** | In our toy example we magically found XYZ with the exact opposite view. In reality, you may have to call an investment bank, pay a finder’s fee, and hope the market has a willing counter‑party. |
| **Default (counter‑party) risk** | Suppose gold spikes to **₹2,700** and XYZ suddenly disappears with the cash. ABC is left holding a contract that’s worth **₹4.05 cr** but has no gold to deliver. |
| **Regulatory risk** | Forwards live in the *wild west* of finance: no exchange, no clearing house, no regulator watching over the handshake. That lawlessness makes defaults more tempting. |
| **Rigidity (no early exit)** | The contract is a “set‑it‑and‑forget‑it” deal. If ABC’s forecast flips halfway through, they’re stuck until the maturity date – no “cancelling” the agreement without penalties. |

Because of these drawbacks, the market invented **futures contracts**, which are basically forwards that have been **standardised, cleared, and regulated**. Futures trade on exchanges, have daily mark‑to‑market, and involve a central clearinghouse that guarantees performance, dramatically cutting down the risks listed above.  

In India, the futures market is a bustling part of the broader derivatives ecosystem. Over the next few modules we’ll unpack futures, learn how to trade them, and see exactly how they tame the wildness of forwards.  

Ready to hit the road? Let’s keep the momentum going!  

### Key takeaways from this chapter  

- Forward contracts are the **foundation** upon which futures are built.  
- A **forward** is an **OTC derivative** – it never sees an exchange floor.  
- Because they’re private agreements, **terms can differ** from one forward to another.  
- The contract’s **structure is straightforward**: agree today on price, settle later.  
- The party that will **buy** the asset is called the **Buyer of the Forward Contract** (ABC in our story).  
- The party that will **sell** the asset is called the **Seller of the Forward Contract** (XYZ in our story).  
- Any **price movement** after signing creates a **profit for one side and a loss for the other**.  
- **Settlement** can be **physical** (real gold changes hands) or **cash‑settlement** (only the price difference is exchanged).  
- **Futures contracts** were created to **reduce the risks** inherent in forwards (liquidity, default, regulatory, rigidity).  
- **Core mechanics** of forwards and futures are the same; the difference lies in **standardisation and risk mitigation**.  

Happy forward‑thinking! 🚀