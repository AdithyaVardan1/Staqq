# 11.   Hedging with Futures  

**Source:** https://zerodha.com/varsity/chapter/hedging-futures/  

---  

##  

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/03/M4-Ch11-title.jpg)  

## 11.1 – Hedging, what is it?  

One of the slickest, most “real‑world‑trader” tricks in the futures toolbox is **hedging**.  
When the market decides to throw a tantrum, a hedge is your rain‑coat – it keeps you from getting soaked (or in finance‑speak, from taking a loss).  

Let’s paint a picture that even a non‑trader at a backyard BBQ could picture:  

You own a tiny, neglected patch of land just outside your house. Instead of letting it turn into a tumbleweed‑museum, you decide to spruce it up—lay down a nice lawn, plant some colourful flowers, water it like a plant‑parent on a caffeine binge. The garden blossoms, the neighbours start to notice, and soon a herd of stray cows decides your plot looks like an all‑you‑can‑eat buffet.  

You’re not exactly thrilled about bovine brunches ruining your roses, so you do the sensible thing: you put up a fence (maybe a wooden hedge—hey, the pun’s intentional). The fence keeps the cows out, the garden stays pristine, and you can keep admiring your handiwork.  

Now, swap the garden for a **portfolio** and the cows for **adverse market moves**:  

| Garden analogy | Market reality |
|---|---|
| **You nurture a plot** → you carefully pick stocks and build a portfolio. | **Your garden grows** → your portfolio value rises. |
| **Cows start grazing** → a market slump threatens your holdings. | **Cows (market decline)** → the market could chew up your gains. |
| **You raise a fence** → you create a futures‑based hedge. | **You raise a hedge** → you take a futures position that offsets the downside. |

That’s hedging in a nutshell: a protective barrier that lets your “garden” keep thriving, even if a herd of market‑cows tries to crash the party.  

*Pro tip*: Hedging isn’t just for a basket of stocks; you can also hedge a single stock (though a few rules apply).  

---  

## 11.2 – Hedge – But why?  

Every good trader has asked the same three‑word question: **“Why hedge?”**  
Picture this scenario: you bought a share at **₹100**. News breaks that the market might tumble, and so might your stock. You have three choices:  

1. **Do nothing** – hope the stock rebounds on its own.  
2. **Sell now** – lock in the loss, then try to buy back cheaper later.  
3. **Hedge** – protect yourself with a futures contract.  

### Option 1 – Sit tight  

If the share drops from **₹100 to ₹75**, that’s a **25 %** loss.  
Now, to get back to **₹100**, the stock has to climb **33.33 %** (because 25 % down is not the same as 25 % up). In practice, markets rarely give you a clean 33 % bounce unless you’re in a bull‑run on steroids.  

### Option 2 – Sell and time the market  

Selling and then re‑buying later means you have to *guess* the market’s future direction—a skill that even Nostradamus would find hard. Plus, frequent trading strips you of long‑term capital‑gains tax benefits and piles on brokerage fees.  

### Option 3 – Hedge (the sensible adult move)  

When you hedge, you’re essentially inoculating your position against a market flu. It’s like getting a vaccine: you won’t be completely immune, but you dramatically lower the chance of a nasty infection. Your portfolio becomes **indifferent** to whatever the market does, because any loss on the spot side is offset by a gain on the futures side (and vice‑versa).  

In short, hedging is the *insurance* that lets you sleep at night without counting every market tick.  

---  

## 11.3 – Risk  

Before we dive into “how,” let’s clarify **what** we’re actually trying to protect against. In finance, risk comes in two flavours:  

| Type | What it is | Example |
|---|---|---|
| **Systematic (market) risk** | Risks that affect **all** stocks simultaneously. | GDP contraction, interest‑rate hikes, inflation spikes, geopolitical turmoil. |
| **Unsystematic (specific) risk** | Risks that are unique to a single company. | A sudden drop in HCL’s revenue, a scandal at Tech Mahindra, a surprise product failure. |

### The unsystematic side  

If you dump all ₹100,000 into **HCL Technologies**, and HCL reports a revenue slump, you’ll see a hit. But **Tech Mahindra** or **Mindtree** won’t feel that pain—those are *company‑specific* shocks.  

The cure? **Diversify**.  

If you split the ₹100,000 into ₹50,000 of HCL and ₹50,000 of Karnataka Bank, a slump in HCL only hurts half your money. Adding more stocks further dilutes that single‑stock risk. Academic research shows that after about **21 stocks**, you’ve captured almost all the diversification benefit—adding the 22nd stock hardly moves the needle.  

*Graphical proof*: (the original chart showed the unsystematic risk curve flattening after ~20 stocks).  

### The systematic side  

Systematic risk is the “global” flu that hits *everyone*: a falling GDP, a rate‑hike, a sudden oil shock, etc. Even a perfectly diversified 21‑stock portfolio will wobble when the whole market shivers.  

**Key takeaway:**  
- **Diversify** to crush **unsystematic** risk.  
- **Hedge** (usually with index futures) to tame **systematic** risk.  

---  

## 11.4 – Hedging a single stock position  

Let’s start small: a single‑stock hedge.  

Suppose you bought **250 shares of Infosys at ₹2,284 each** → **₹571,000** of exposure (long spot). Earnings are due, and you fear a disappointing number could knock the price down.  

**The hedge:** go **short** the same number of shares via an Infosys futures contract.  

| Futures trade | Details |
|---|---|
| **Side** | Short |
| **Price** | ₹2,285 (close enough) |
| **Lot size** | 250 |
| **Contract value** | ₹571,250 |

Now you’re **long** Infosys in the spot market **and** **short** the same amount in the futures market. The two positions move in opposite directions, so overall you’re *market‑neutral*.  

### What happens if price moves?  

| Price move | Spot P&L | Futures P&L | Net |
|---|---|---|---|
| **Price rises** | + (gain) | – (loss) | ≈ 0 |
| **Price falls** | – (loss) | + (gain) | ≈ 0 |

The exact numbers differ by the tiny ₹1‑gap between spot and futures entry, but the net effect is a **frozen** position: you’re insulated from the market’s whims.  

#### When does this break?  

- **No futures contract** for the stock (e.g., South Indian Bank).  
- **Lot‑size mismatch** – if your spot position isn’t a multiple of the futures lot, you’ll get a *partial* hedge, leaving some residual exposure.  

We’ll tackle those edge‑cases later when we talk about portfolios.  

---  

## 11.5 – Understanding Beta (β)  

Beta (β) is the **Greek** that tells you how jittery a stock is relative to the market. Think of it as the stock’s “speedometer” compared to the market’s cruise control.  

| Stock β | Interpretation |
|---|---|
| **β = 1** | Moves lock‑step with the market. |
| **β > 1** | More volatile than the market (the drama‑queen). |
| **β < 1** | Less volatile (the chill‑pill). |
| **β < 0** | Moves opposite to the market (the contrarian). |

**Example**: BPCL’s β = **0.7**.  

- If **Nifty** goes **+1 %**, BPCL is expected to rise **+0.7 %**.  
- If **Nifty** drops **‑1 %**, BPCL should fall **‑0.7 %**.  

Because 0.7 % is **30 %** lower than the market’s 1 %, BPCL is *30 % less risky* than the market (i.e., it carries less systematic risk).  

If you compare BPCL (β 0.7) to HPCL (β 0.85), BPCL is *less volatile* and therefore *less risky* than HPCL.  

A quick snapshot of a few blue‑chip betas (as of Jan 2015):  

| Stock | β |
|---|---|
| HDFC Bank | 1.15 |
| Infosys | 0.92 |
| Reliance | 0.81 |
| … | … |

*(Numbers are for illustration; you can look up the latest values on any financial portal.)*  

---  

## 11.6 – Calculating beta in MS Excel  

Excel is your friendly side‑kick for beta. The built‑in **SLOPE** function does the heavy lifting. Here’s a step‑by‑step (with a dash of redundancy for emphasis—because we love clarity):  

1. **Grab data** – Download the last **6 months** of daily **closing prices** for **Nifty** and the stock you care about (e.g., TCS) from the NSE website.  
2. **Compute daily returns** for both series:  

   ```text
   Daily Return = (Today’s Close / Yesterday’s Close) – 1
   ```  

3. **Set up the SLOPE formula**. In a blank cell type:  

   ```excel
   =SLOPE(known_y’s, known_x’s)
   ```  

   - **known_y’s** = array of TCS daily returns.  
   - **known_x’s** = array of Nifty daily returns.  

4. Press **Enter** – the result is the **beta**. For TCS (3 Sept 2014 – 3 Mar 2015) the beta works out to **0.62**.  

That’s it! (If you’re a fan of copy‑paste, you can repeat steps 1‑3 for any other stock.)  

You can also download the **Excel sheet** we used for the demo – just follow the link in the original Varsity chapter.  

---  

## 11.7 – Hedging a stock Portfolio  

Now we go big: hedging an entire portfolio with **Nifty futures**. Why Nifty? Because systematic risk is a market‑wide phenomenon, and the **Nifty index** is the market’s representative.  

### Step 1 – Compute Portfolio Beta  

Portfolio beta = Σ ( **weight of each stock** × **stock’s beta** )  

**Weight** = (Amount invested in the stock) / (Total portfolio value).  

*Example portfolio (₹800,000 total):*  

| Stock | Amount (₹) | Weight | Stock β | Weighted β |
|---|---|---|---|---|
| Axis Bank | 125,000 | 125,000 / 800,000 = **15.6 %** | 1.40 | 0.15 × 1.40 = **0.21** |
| (… other stocks …) | … | … | … | … |
| **Total** | **800,000** | — | — | **Σ Weighted β = 1.223** |

So the **portfolio β = 1.223**. In plain English: if Nifty moves **+1 %**, the portfolio is expected to move **+1.223 %**; if Nifty drops **‑1 %**, the portfolio will drop **‑1.223 %**.  

### Step 2 – Compute Hedge Value  

**Hedge Value** = Portfolio β × Total portfolio value  

```
= 1.223 × 800,000
= ₹978,400
```  

Because the portfolio is “high‑beta” (more volatile than the market), you need a **larger** futures position than the portfolio’s nominal size.  

### Step 3 – Translate Hedge Value into Futures Lots  

Current **Nifty futures price** = **9,025**  
Lot size = **25** (i.e., each contract = 25 × index points).  

**Contract value per lot** = 9,025 × 25 = **₹225,625**  

**Number of lots needed** = Hedge Value ÷ Contract value  

```
= 978,400 / 225,625
≈ 4.33 lots
```  

You can’t trade 0.33 of a lot, so you’ll either go **4 lots (under‑hedged)** or **5 lots (over‑hedged)**. Most traders pick the nearest whole number and accept a tiny mismatch.  

### Quick “what‑if” – Nifty drops 500 points (≈ 5.5 %)  

Assume you could somehow trade the exact **4.33 lots** (just for the math).  

| Position | Entry | Move | P&L |
|---|---|---|---|
| **Short Nifty Futures** | 9,025 | –500 points | **+₹54,125** |
| **Long Portfolio** | ₹800,000 | –5.5 % × 1.223 = –6.78 % | **‑₹54,240** |

Net result ≈ **₹0** (tiny rounding error). Your loss on the portfolio is perfectly offset by the gain on the futures short. That’s the magic of a *perfect* hedge.  

In practice, using 4 or 5 lots will leave a small residual exposure, but it will still dramatically dampen the impact of market moves.  

### Edge Cases Re‑visited  

1. **Stocks without futures** (e.g., South Indian Bank).  
   - Compute **hedge value** = **Investment × Stock β**.  
   - For a **₹500,000** SBI exposure with **β = 0.75**:  

     ```
     Hedge value = 500,000 × 0.75 = ₹375,000
     ```  

   - Divide by Nifty contract value (₹225,625) → ≈ **1.66 lots** → round to 1 or 2 lots.  

2. **Very small positions** (₹50,000‑₹100,000).  
   - If the hedge value is **below one Nifty contract**, a futures hedge becomes uneconomical.  
   - Instead, you can use **options** (which have smaller notional exposure) or simply accept the residual risk.  

---  

### Key takeaways from this chapter  

- **Hedging** is a shield that offsets losses in the spot market with gains in the futures market.  
- **Systematic risk** (macro‑level) can be hedged; **unsystematic risk** (company‑specific) is best reduced via **diversification**.  
- Diversify up to **~21 stocks**; beyond that you get diminishing returns on risk reduction.  
- To **hedge a single stock**, take a **counter‑position** in its futures contract (long ↔ short). Lot‑size must match for a perfect hedge.  
- **Beta (β)** measures a stock’s sensitivity to the market; β = 1 for the market itself, β < 1 for low‑volatility stocks, β > 1 for high‑volatility ones.  
- **Excel’s SLOPE** function makes beta calculation a breeze (`=SLOPE(y‑range, x‑range)`).  
- **Portfolio hedging steps**:  

  1. Compute each stock’s **weight** in the portfolio.  
  2. Multiply weight by **stock β** → **weighted β**.  
  3. Sum weighted betas → **Portfolio β**.  
  4. Multiply **Portfolio β** by total portfolio value → **Hedge value**.  
  5. Divide **Hedge value** by **Nifty contract value** → **Number of lots**.  
  6. **Short** that many Nifty futures contracts.  

- A **perfect hedge** is rare because contracts are indivisible; you’ll usually be **slightly under‑ or over‑hedged**, which is acceptable in most real‑world scenarios.  
- For stocks lacking futures or for tiny exposures, turn to **index futures** (using beta) or **options** for a finer‑grained hedge.  

Stay savvy, keep that fence up, and let your portfolio flourish—cows (or market crashes) be damned!