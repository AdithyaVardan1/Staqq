# 8. All About Short‑selling  

**Source:** https://zerodha.com/varsity/chapter/shorting/

---  

##  

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/02/M4-Ch8-title1.jpg)

## 8.1 – Short‑selling in a nutshell  

We gave you a teaser about short‑selling back in Module 1. Now it’s time to pull the rug out and actually *show* you how it works. Short‑selling feels weird because, unlike everything else we do in life, you’re **selling before you own**.  

Picture this: you buy a flat today for ₹X, you sell it two years later for ₹X + Y, and you pocket the Y. Easy‑peasy. That’s the “buy‑first‑sell‑later” dance we all know.  

Now imagine doing the *reverse*: you shout, “I’m selling this flat now!” even though you don’t have the keys. Then, sometime later, you scramble to buy it back at a cheaper price. That’s short‑selling in a nutshell – you sell first, buy later.  

**Why would anyone want to sell something they don’t own?**  
Because you’re a *martyr* for the market’s mood swings. If you think a stock is going to drop, you sell it now (even if you borrowed it) and then buy it back cheaper later, pocketing the difference.  

Let’s break it down with a cricket‑match analogy, because who doesn’t love a little India‑Pakistan drama?  

- You and your buddy are glued to the TV.  
- You bet India will **win**; your friend bets India will **lose**.  
- If India wins, you collect the cash; if India loses, your friend does.  

Replace “India” with “XYZ Corp’s share price.”  
- You are **long** on XYZ (you profit if the price goes up).  
- Your friend is **short** on XYZ (he profits if the price goes down).  

If you’re new to short‑selling, just remember this golden nugget: **When you expect a price to fall, you can make money by short‑selling it** – sell first, buy later. The best way to truly *feel* short‑selling is to actually do it (preferably with a demo account first). In the pages that follow we’ll walk through everything you need to know before you start shouting “Sell!” in the market.

---

## 8.2 – Short‑selling stocks in the spot market  

Before we jump into futures, let’s see how short‑selling works in the **spot** market (the market where you actually buy and sell the underlying shares).  

### A hypothetical setup  

1. **Chart‑watching** – You scan the daily chart of **HCL Technologies Ltd.** and spot a bearish *marubozu* candle (a big, ominous, all‑body candle that says “I’m going down”).  
2. **Checklist check** – All the usual suspects line up:  
   - **Above‑average volume** (the market’s yelling “something’s happening”).  
   - **A strong resistance level** just above the current price.  
   - **Technical indicators** (RSI, MACD, etc.) all confirming bearishness.  
   - **Risk‑to‑Reward (R:R) ratio** that makes sense (say 1:2 or better).  
3. ** conviction** – You’re convinced HCL will slide **at least 2 %** tomorrow.

Armed with that conviction, you decide to *short* the stock at **₹1,990** per share.

### How you actually place a short order  

On most Indian trading platforms (Zerodha, Upstox, etc.) you:

1. Highlight the ticker (HCL).  
2. Hit **F2** – this pops up the *sell* order form (yes, you’re *selling* even though you don’t own the shares).  
3. Fill in the quantity, price, and any other parameters (like a stop‑loss).  
4. Click **Submit**.  

If the order gets filled, you now have a **short open position**. Congratulations—you just sold something you don’t own, just like a magician pulling a rabbit out of an empty hat.

### When does the short‑seller lose money?  

| Situation | What happens? |
|-----------|----------------|
| **Your view is correct** | Stock price **falls** → you later buy back cheaper → profit. |
| **Your view is wrong** | Stock price **rises** → you have to buy back at a higher price → loss. |

So the **directional expectation** for a short is *down*. The moment the price goes *up* you’re moving against yourself.

Because the loss direction is opposite to a long trade, **your stop‑loss** sits **above** your entry price. In our example:

- **Entry (sell) price:** ₹1,990  
- **Stop‑loss (buy‑back) price:** ₹2,000  

That’s a **₹10** cushion—if the market climbs to ₹2,000, the platform will automatically close your position to prevent a larger loss.

### Two “what‑if” scenarios  

#### Scenario 1 – Target hit at ₹1,950  

| Step | Action | P/L |
|------|--------|-----|
| 1️⃣  | Sell at ₹1,990 (you’re short) | — |
| 2️⃣  | Price drops to ₹1,950 | You **buy** back (cover) at ₹1,950 |
| 3️⃣  | Profit = ₹1,990 − ₹1,950 = **₹40 per share** | 🎉 |

From a “buy‑first‑sell‑later” perspective this is equivalent to **buying at ₹1,950 and selling at ₹1,990**—just the order of operations is flipped.

#### Scenario 2 – Stop‑loss hit at ₹2,000  

| Step | Action | P/L |
|------|--------|-----|
| 1️⃣  | Sell at ₹1,990 (short) | — |
| 2️⃣  | Price climbs to ₹2,000 | Your stop‑loss triggers; you **buy** at ₹2,000 |
| 3️⃣  | Loss = ₹2,000 − ₹1,990 = **₹10 per share** | 😬 |

Again, in the usual long‑trade world this looks like **buying at ₹2,000 and selling at ₹1,990**, just with the arrows reversed.

**Bottom line:** Short‑selling makes you money when the price falls and drains you when it rises. Simple, right? (Well, the math is simple; the psychology is where most people stumble.)

---

## 8.3 – Short‑selling in spot (the exchange’s point of view)  

The spot market has one hard‑nosed rule: **short‑selling must be intraday**. You can open a short any time during market hours, **but you must square off (buy back) before the bell rings**. No “carry‑overnight” allowed.  

### Why?  

When you push the *sell* button, the exchange’s back‑office immediately records that **shares have been sold**. From the exchange’s perspective, a sell order always creates a **delivery obligation**—you have to hand over those shares at the end of the settlement cycle (T+2 in India).  

If you truly owned the shares, the settlement would be a breeze. But because you **borrowed** them (short‑selling), the exchange still assumes you’ll deliver them the next day. It only checks this after the market closes.  

#### Imagine you decide to “wait it out”  

- You short at ₹1,990.  
- The price climbs instead of falling.  
- The day ends, and the exchange says, “Hey, you sold shares you don’t have—bring them in by tomorrow!”  

You have no shares in your DEMAT account, so you **default**. This is called a **“short delivery”**.  

The exchange then runs an **auction** to procure the missing shares, and you’re slapped with a **penalty** (often **~20 %** of the short price!).  

**Moral of the story:** Never let a short sit overnight in the spot market. Close it before the close, or you’ll be paying for a penalty that makes you wish you’d just bought a latte instead.

### The loophole – futures  

Because the spot market forces you to settle each day, many traders migrate to the **futures** segment where the short position lives on a contract, not the actual shares. In futures you *can* keep a short open for days, weeks, or even months (until the contract expires).  

---

## 8.4 – Short‑selling in the Futures market  

Futures are the **wild west** of short‑selling: no intraday‑only restriction, you can keep a bearish stance alive overnight, and the mechanics are almost identical to a long position—just the profit direction flips.  

### Margin basics  

Just like a long futures trade, a short futures trade requires **margin** (a good‑faith deposit). The **initial margin** and **maintenance margin** are the same whether you’re buying (going long) or selling (going short).  

### Mark‑to‑Market (M2M) example  

Let’s reuse HCL, but this time on the **futures** contract.  

- **Short entry price:** ₹1,990 per share  
- **Lot size:** 125 shares (standard for HCL futures)  

Assume the following daily settlement prices and compute the **M2M** (profit/loss added to your account each day):

| Day | Settlement price | M2M (₹) |
|-----|------------------|----------|
| 0 (entry) | 1,990 | — |
| 1 | 1,970 | + (1,990 − 1,970) × 125 = **+2,500** |
| 2 | 2,005 | – (2,005 − 1,990) × 125 = **‑1,875** |
| 3 | 1,985 | + (1,990 − 1,985) × 125 = **+625** |
| 4 | 2,020 | – (2,020 − 1,990) × 125 = **‑3,750** |
| 5 | 1,950 | + (1,990 − 1,950) × 125 = **+5,000** |
| 6 | 1,985 | + (1,990 − 1,985) × 125 = **+625** |

*Red rows* (days 2 and 4) are loss‑making days.

To get the **overall P/L**, just add up the daily M2M numbers:

```
+2,500 –1,875 +625 –3,750 +5,000 +625 = +₹3,125
```

Or you can do the classic **(Sell – Buy) × Lot size** calculation:

```
(1,990 – 1,950) × 125 = 40 × 125 = ₹5,000   (if you exit at 1,950)
```

In our example we closed at ₹1,950 on day 5, so the net profit is **₹3,125** after accounting for the interim losses.

### Takeaways  

- **Short‑selling futures works exactly like going long**, except you profit when the underlying price **falls**.  
- **Margins** are identical for long and short sides.  
- **M2M** (daily profit/loss) is computed the same way; the sign just flips based on price movement.  

---

## Key Takeaways  

| ✅ | What you should remember |
|---|---------------------------|
| 1 | **Short‑selling = sell first, buy later** (you’re basically “borrowing” shares and hoping the price drops). |
| 2 | Profit when **closing price < entry price**; loss when **closing price > entry price**. |
| 3 | **Stop‑loss** for a short sits **above** the entry price (e.g., entry ₹1,990, SL ₹2,000). |
| 4 | **Spot market shorts are intraday only** – square‑off before the market closes. |
| 5 | **No overnight carry** in spot; otherwise you incur a **short‑delivery** penalty (≈ 20 %). |
| 6 | **Futures shorts can be held overnight** (or longer) because you’re trading a contract, not the actual shares. |
| 7 | **Margin requirements** are the same for long and short futures positions. |
| 8 | **Mark‑to‑Market (M2M)** calculation is identical for both sides; just watch the sign of the price change. |

Now that you’ve gotten the low‑down on short‑selling, go ahead and practice on a **paper‑trading account** first. Remember: the market can be as moody as a cricket fan during an India‑Pakistan match—so keep your stop‑loss tight, your humor sharp, and never, ever let a short delivery haunt you after hours. Happy (short) trading!