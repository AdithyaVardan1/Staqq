# 2. Introducing Futures Contract  

**Source:** https://zerodha.com/varsity/chapter/introducing-futures-contract/  

---  

## 2.1 – Setting the context  

In the last chapter we played with a nice, tidy **Forward Contract** example: two parties shook hands, promised to swap cash for a barrel of oil (or a sack of gold, or whatever) at some future date, and then we watched what happened when the market price moved. We broke the deal down, saw who wins and who loses, and at the end we wrote down the four big‑bad wolves that haunt any forward agreement:  

| 🐺 Risk | What it means for you |
|--------|-----------------------|
| **Liquidity risk** | You might not find anyone to take the opposite side when you need to. |
| **Default risk** | Your buddy might run away with the cash before settlement. |
| **Regulatory risk** | Nobody’s watching, so shady stuff can creep in. |
| **Rigidity of the structure** | The contract is as flexible as a cement block. |

A **Futures Contract** was invented to chase those wolves away. Think of it as the forward contract’s cool‑cousin who went to finishing school, got a haircut, and now shows up in a shiny suit with airbags, seat‑belts, ABS and a built‑in GPS. The core job is still the same – get you from point *A* (today) to point *B* (future price), but the safety features are way better.

> **Quick analogy:** An old‑timer car’s only job was to move you from A to B. A modern car still does that, but it also keeps you alive if you slam the brakes. Futures are the modern car of the derivatives world.

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/01/M4-Ch2-title1.jpg)

---

## 2.2 – A sneak peek into the Futures Agreement  

Now that we’ve agreed the “engine” is the same, let’s pop the hood and see what makes Futures different from Forwards. We’ll glance at the quirks now and deep‑dive later—think of it as a trailer before the full‑blown movie.

### The “ABC Jeweller vs XYZ Gold Dealer” story, upgraded  

Remember our gold‑lover ABC who wanted to lock in a price with XYZ? Suppose ABC can’t find XYZ after endless LinkedIn stalking. Bad news: ABC has a view on gold, but no one to take the other side.  

Enter the **financial supermarket** – a place where dozens of traders line up, each ready to bet the opposite way. You shout, “I want gold futures for June!” and a bunch of strangers (or institutions) wave their hands and say, “Got you!” The supermarket isn’t just for gold; it stocks futures on silver, copper, crude oil, stocks, you name it.  

That supermarket is the **Exchange** (stock exchange, commodity exchange, etc.). It’s a regulated arena where anyone (including you, the humble retail trader) can walk in, place an order, and get matched instantly. No more hunting down a single counter‑party.

### How Futures dodge the forward‑contract pitfalls  

| Feature | Forward Contract | Futures Contract |
|---------|------------------|------------------|
| **Underlying link** | Directly tied to the physical asset. | Mirrors the asset’s *future* price (the “underlying”). |
| **Standardisation** | Negotiable quantities, dates, purity – you set the rules. | Every contract follows exchange‑defined specs (lot size, expiry, tick size). |
| **Tradeability** | Stuck until expiry; you can’t sell it mid‑way. | Fully tradable – you can close or roll over anytime. |
| **Regulation** | Private – little oversight, higher default risk. | Super‑regulated (SEBI in India, CFTC in the US, etc.) – defaults are rare. |
| **Time‑bound** | Usually a one‑off custom date. | Multiple expiries (monthly, weekly, daily) – you pick what fits. |
| **Settlement** | Often physical delivery of the asset. | Mostly cash‑settled – just the P&L moves between accounts. |

Let’s unpack those buzzwords a bit, because they’re the meat of why futures are the “new‑gen” version.

1. **Futures mimic the underlying** – If gold spot price jumps from ₹2,450/g to ₹2,600/g, the gold futures price will sprint up in lock‑step (ignoring small basis differences). Think of the underlying and the futures contract as Siamese twins: if one sneezes, the other does too.  

2. **Standardized contracts** – In the forward world, ABC could say “I want exactly 14.73 kg of 22‑karat gold.” In futures, the exchange says “One contract = 10 kg of 22‑karat gold, delivered in June, with a tick size of ₹0.5.” You can’t tweak it; you either take the standard or you don’t.  

3. **Tradability** – Suppose you entered a forward and then the market turned against you. You’re stuck, unless you find a willing buyer (hard!). With futures, you simply sell your contract on the exchange and walk away. It’s like having a “get‑out‑of‑jail” card in Monopoly.  

4. **Regulation** – In India the Securities and Exchange Board of India (SEBI) watches the futures playground like a hawk. They enforce margin requirements, position limits, and daily settlement (mark‑to‑market) so that a default is almost impossible.  

5. **Time‑bound & expiry** – Futures come with a built‑in calendar. If ABC wants a 3‑month horizon, he can pick the March contract; if he changes his mind after a month, he can roll into the April contract. The day a contract expires, the exchange rolls out the next one automatically.  

6. **Cash‑settled** – Most Indian futures (indices, currencies, most commodities) settle in cash. No trucks loading gold bars onto the broker’s roof. The exchange calculates the difference between the contract price and the final settlement price, and that amount changes hands instantly. Transparent, quick, and no logistics nightmare.  

### Quick visual: Forward vs Futures  

| **Aspect** | **Forward** | **Future** |
|------------|-------------|------------|
| Counter‑party | Private, bilateral | Centralised exchange |
| Margin | Usually none (or minimal) | Daily margin (initial + variation) |
| Liquidity | Low (depends on counterparties) | High (lots of market participants) |
| Settlement | Physical or cash (as agreed) | Mostly cash, daily mark‑to‑market |
| Flexibility | Very flexible (custom terms) | Fixed terms (standardised) |
| Regulation | Light | Heavy (SEBI, etc.) |

### Spot vs Futures price – a quick reality check  

- **Spot price** = price you’d pay if you bought the asset right now in the “regular” market.  
- **Futures price** = price agreed today for a transaction that will settle at a future date.  

In efficient markets the two move together (the “cost‑of‑carry” model explains the slight spread). If spot goes up, futures usually follow, because the market expects that trend to continue until expiry.  

---

## 2.3 – Before your first futures trade  

Alright, you’ve had the teaser, now let’s prep you for the main course. Think of this as the “pre‑flight checklist” before you board the futures jet. We’ll skim the essentials now and return later for a deep‑dive.

### 1. Lot size – the “minimum order” rule  

Every futures contract has a **lot size** set by the exchange. It’s the smallest chunk you can buy or sell. For example:  

| Asset | Lot size (approx.) |
|-------|-------------------|
| Gold (INR) | 1 kg |
| Nifty 50 Index | 75 points |
| Crude Oil (MCX) | 100 bars (≈ 1 kl) |
| USD/INR | 10,000 USD |

You can’t trade half a lot (unless you use a micro‑future, which some exchanges now offer). The lot size ensures enough liquidity and price discovery.

### 2. Contract value – “How big is the bet?”  

Contract value = **Lot size × Futures price**.  

Using our gold example:  

- Lot size = 1 kg (1,000 g)  
- Futures price = ₹2,500 per gram (just a round number)  

`Contract value = 1,000 g × ₹2,500/g = ₹25,00,000`  

So a single gold futures contract is worth 2.5 million rupees. That number matters because it determines how much margin you’ll need.

### 3. Margin – the “security deposit”  

Unlike a forward where you just trust each other’s word, futures demand **margin** up front. Think of it as a security deposit you leave with the broker so the exchange knows you can cover losses.  

- **Initial margin** – a percentage of the contract value (often 5‑15 % in India).  
- **Variation margin** – daily settlement adjustments (mark‑to‑market).  

If the contract value is ₹25 lakh and the initial margin is 10 %, you must have **₹2.5 lakh** in your trading account before you can open the position. The exchange will then adjust your balance each day based on price movements.  

> *Pro tip:* Treat margin like a “parking ticket.” If you don’t have enough cash in the account, the broker will auto‑liquidate your position to protect the exchange.

### 4. Expiry – the “deadline”  

Every futures contract has a **expiry date** (usually the last Thursday of the contract month for Indian indices, or the last business day for commodities). On expiry:  

- If it’s a cash‑settled contract, the final cash difference is exchanged, and the contract vanishes.  
- If it’s a physically settled contract (like gold), you either take delivery or roll over to the next month.  

Exchanges automatically list the next month’s contract a few days before the old one expires, so you can “roll over” by closing the near‑month and opening the next‑month contract.

### Putting it together – a quick example  

| Step | What you do | Numbers (illustrative) |
|------|--------------|------------------------|
| **Pick the asset** | Gold futures | |
| **Choose lot size** | 1 kg (exchange‑defined) | |
| **Check price** | ₹2,500 per gram → ₹2,500,000 per lot | |
| **Compute contract value** | 1 kg × ₹2,500/g = ₹25 lakh | |
| **Margin requirement** | 10 % of ₹25 lakh = ₹2.5 lakh | |
| **Enter trade** | Go long (buy) expecting price rise | |
| **Monitor daily** | Mark‑to‑market adjusts your cash balance | |
| **Expiry** | June 2026 (say) – either cash‑settle or roll | |

That’s the skeleton you need before you actually click “Buy” on the trading platform.

---

## Key takeaways from this chapter  

- **Both forwards and futures give you a payoff if your price view is right**, but futures add a whole safety‑net.  
- **Futures = forwards with a makeover** (standardised, regulated, tradable).  
- **Futures price shadows the underlying spot price** – they’re practically twins.  
- **You can trade a futures contract any time before expiry**; you’re not stuck until the due date.  
- **Standardisation means every contract has the same lot size, tick size, and expiry** – no haggling.  
- **Multiple expiries exist**, so you can pick a horizon that matches your view (1‑month, 2‑month, 3‑month, etc.).  
- **Most contracts settle in cash**, so no need to move physical gold, oil, or wheat around.  
- **SEBI (in India) watches the futures market like a mother‑goose**, making defaults virtually impossible.  
- **Lot size = the minimum you must trade** – think of it as the “minimum order” on an e‑commerce site.  
- **Contract value = Lot size × Futures price** – the total notional you’re controlling.  
- **Margin = a % of that contract value**, paid upfront and adjusted daily.  
- **Expiry ends the contract**; the old contract disappears and a fresh one appears on the exchange.  

Armed with this cheat‑sheet, you’re ready to step onto the futures floor (or, more realistically, the online trading screen) with confidence—and maybe a chuckle. Remember: futures are just forwards that went to college, got a job, and now earn a steady paycheck in the form of daily cash‑settlements. Happy trading!