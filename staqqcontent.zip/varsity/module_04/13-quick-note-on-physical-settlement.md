# 13. Quick Note on Physical Settlement  

**Source:** <https://zerodha.com/varsity/chapter/quick-note-on-physical-settlement/>

---  

## 13.1 – Overview  

Back in the day (read: “pre‑2018”), Indian equity futures‑and‑options were **cash‑settled**. In plain English: when your contract hit its expiry date, you didn’t have to haul any actual shares into your demat box; you just got (or paid) the difference in cash based on the settlement price.  

Then, on **April 11 , 2018**, SEBI dropped a circular that said, “Hey, folks, enough of the paper‑only gymnastics—let’s make you actually own the stock (or deliver it) for every stock‑F&O contract, and we’ll roll this out in phases.” The grand‑design? To choke off wild speculation that could turn a quiet‑trading stock into a roller‑coaster of volatility.  

Fast‑forward to the **October 2019 expiry**—that was the first batch where physical delivery became compulsory for **all** stock‑F&O contracts. If you still think you can dodge the paperwork, think again; the regulator has your back (and your broker’s back) to keep the market honest.

---

## 13.2 What is Physical Settlement?  

Physical settlement simply means: *at expiry, you either give or take the actual shares that underlie your contract*. No more “settle in cash” shortcuts.  

### A quick before‑and‑after picture  

*Before* (cash‑settlement):  
- You buy one lot of SBI futures that expires this month.  
- On the expiry date, the exchange computes a **settlement price** (say, Rs 210).  
- Your account is credited or debited the profit/loss in cash.  
- No shares ever touch your demat account.  

*After* (physical‑settlement):  
- You still buy that lot of SBI futures and *forget* to close or roll it over.  
- At expiry, you must **pay the full contract value** (Lot size × spot price) and the shares magically appear in your demat, or you have to deliver shares you already own (or have borrowed).  

We covered **marked‑to‑market** mechanics in an earlier chapter, but the key shift now is that the “paper” disappears and the “stock” shows up—if you’re on the long side—or vanishes from your holdings if you’re short.

---

## 13.3 Why is Physical Settlement Enforced?  

When contracts are cash‑settled, the only thing the exchange asks you to keep on the books is **margin** (the SPAN + exposure component). This low‑friction environment can tempt short‑sellers to pile up massive short positions right before expiry, deliberately pushing the price down to pocket a cheap settlement.  

Enter physical settlement, and the game changes:  

1. **You need the actual shares** (or you must borrow them on the **SLB**—securities‑lending‑by‑broker—market).  
2. **Buying in the spot market** or **borrowing** costs you money and carries risk.  
3. The cost of acquiring the shares acts as a natural brake on anyone trying to artificially crash the price.  

In short, the regulator forced the market to “put its money where its mouth is,” making it far harder to pull a price‑manipulation stunt just before the clock strikes zero.

---

## 13.4 How Are Positions Settled?  

On expiry, each F&O contract follows a simple rule‑book:

| Position type | What happens at expiry? |
|---------------|------------------------|
| **Long Futures** | **Take delivery** – the shares flow into your demat. |
| **Long ITM Call** | **Take delivery** – you’re effectively buying the shares at the strike. |
| **Short ITM Put** | **Take delivery** – you must **give** the shares to the option holder. |
| **Short Futures** | **Give delivery** – you must sell the shares you don’t (or have) to the buyer. |
| **Short ITM Call** | **Give delivery** – you’re forced to sell the shares at the strike. |
| **Long ITM Put** | **Give delivery** – you deliver the shares you own (or have borrowed) to the option writer. |

> **Only “in‑the‑money” (ITM) options trigger physical delivery.**  
> If an option expires **out‑of‑the‑money** (OTM), it just fizzles away like a bad punchline—no shares, no obligations.

---

## 13.5 Netted‑Off Positions (Sub‑category)  

Suppose you hold several contracts on the *same underlying* that expire on the same day and they happen to **hedge** each other. The exchange will **net** them off, sparing you from a double‑delivery nightmare.

**Example net‑off**  

| Position | Type | Strike (if option) |
|----------|------|--------------------|
| 1 | Long ITM Put | 200 |
| 2 | Short ITM Put | 200 |
| 3 | Short ITM Call | 210 |
| 4 | Short ITM Put | 190 |
| 5 | Long ITM Put | 190 |

If the net result of the above is a zero‑sum on the underlying shares, the exchange cancels the physical obligations.  

### Real‑world illustration  

- You own a **June SBI futures** contract (long) and also a **June SBI ITM Put** with a strike of **Rs 200** (spot is Rs 180).  
- The long futures says: “Give me the shares at expiry.”  
- The long put says: “I’ll **sell** you the shares at Rs 200 (i.e., I’ll give you the shares).”  

Because one contract forces you to **take delivery** and the other forces you to **give delivery**, they offset each other perfectly. The exchange nets them, and you walk away with **no actual share movement**—just a tidy accounting entry.

---

## 13.6 Margins  

### The pre‑physical‑settlement world  

| Instrument | Margin requirement |
|------------|-------------------|
| Futures (short) | Only **SPAN + Exposure** margin. |
| Short options | Same – you keep the margin buffer. |
| Long options | You pay **only the premium** (the price of the option). |

### After the physical‑settlement rule change  

- **Futures (long or short)** and **short‑option positions** now demand **100 % of the contract value** if you intend to hold them till expiry. In other words, you must have enough cash to buy the shares outright (or enough shares to deliver).  
- Brokers, anticipating the higher risk, typically **stack on an additional “expiry‑margin”** as the contract approaches its final day. Think of it as a safety net that says, “If you’re still here, we better make sure you can actually do the delivery.”  

Bottom line: the closer you get to expiry, the heavier the wallet‑weight.  

> Want the nitty‑gritty of Zerodha’s policy? Check it out [here](https://zerodha.com/varsity/chapter/quick-note-on-physical-settlement/).  

---

### TL;DR (in bar‑talk style)  

- **Cash‑settlement = money‑only.**  
- **Physical settlement = “Bring your own booze” (i.e., shares).**  
- **Why?** To stop traders from “short‑selling the market into oblivion” right before the buzzer.  
- **What you get:** Long futures & ITM calls = **receive** shares; short futures & ITM puts = **hand over** shares.  
- **Net‑off** saves you from double‑delivery when you have opposite bets on the same stock.  
- **Margins** balloon to the full contract value as expiry looms, with brokers tossing in extra buffers.  

Now you can sip your drink, stare at the ticker, and actually *own* the shares you’ve been flirting with for weeks—thanks to physical settlement. Cheers!