# 4. Leverage & Payoff  

**Source:** <https://zerodha.com/varsity/chapter/leverage-payoff/>

---  

## 4.1 – A quick recap  

Remember the TCS saga from the previous chapter? We walked you through a *full‑blown* futures trade: we went **long** on TCS futures because we thought the stock was being *undervalued* after the CEO’s pep‑talk. The plan was simple – buy the contract on Day 1, square‑off the next day, and watch the profit roll in.  

But before we got our happy‑dance on, we asked the *big* question (the one that keeps accountants up at night):  

> **If I think the price will rise, why not just buy the stock outright?**  

Why bother with futures at all?  

Here’s the deal: buying a futures contract is essentially signing a digital pinky‑promise with a counter‑party. The agreement is **time‑bound**, so your directional view must materialise **before the expiry** or you’ll be eating dust. By contrast, buying the stock and stashing it in your DEMAT account is a “set‑and‑forget” affair – no deadlines, no counterparties, just you and your shares.  

So why do traders still line up for futures? The answer lives in the **leverage** baked into derivatives. Leverage is the financial world’s version of a superhero cape – if you wear it right, you can fly; wear it wrong and you’ll crash spectacularly. Let’s rip the cape off and see why futures can be so tempting.  

---  

## 4.2 – Leverage in perspective  

Leverage isn’t just a finance term; you’ve probably used it in real life without even knowing it. Think of a **lever** you use to pry open a jam‑filled jar – a little push on the long end moves the heavy lid on the other side. Same idea with money: a tiny amount of cash can control a much larger position.  

### A real‑world illustration (the “my‑friend‑is‑a‑real‑estate‑guy” story)  

My buddy (let’s call him *Raj*) is a self‑proclaimed “real‑estate tycoon” who loves buying apartments, holding them like fine wine, and selling them later at a premium. He swears it’s safer than the stock market, but I’ll let you decide who’s right.

| **When** | **What happened** |
|----------|-------------------|
| **Nov 2013** | Prestige Builders announced a swanky new project in South Bangalore. Raj booked a 2‑BHK on the 9th floor for **₹10,000,000**. Because the project was *pre‑launch*, he only had to cough up **10 %** (₹1,000,000) as an **initial payment**. The remaining 90 % would be due as construction progressed. |
| **Dec 2014** | The market went crazy – property values in that area jumped **≈ 25 %**. Raj’s 9th‑floor flat was now worth **₹12,500,000**. He found a buyer and sealed the deal at that price. |

#### What makes this a classic “leveraged” deal?  

1. **Tiny cash, huge exposure** – ₹1 million gave Raj control over a ₹10 million asset (10 % margin = leverage).  
2. **The ₹1 million is the “initial margin”** – just like the margin you post for a futures contract.  
3. **Small price moves = massive ROI** – a 25 % rise in the property value translated into a **250 %** return on the cash he actually put down (₹1 million → ₹2.5 million profit).  
4. **It’s a leveraged transaction** – the same mechanics that turned Raj into a “real‑estate hero” also apply to futures.  

Keep this example in mind; you’ll see it re‑appear when we swing back to the TCS trade.  

![Leverage illustration](http://zerodha.com/varsity/wp-content/uploads/2015/01/M4-Ch4-title.jpg)  

---  

## 4.3 – The Leverage (TCS style)  

Let’s rewind the TCS story, now with the numbers **spelled out** so you don’t have to do mental gymnastics.

| **Assumption** | **Value** |
|----------------|-----------|
| Date you buy | 15 Dec 2014 |
| Futures price (and spot, for simplicity) | **₹2,362** per share |
| Date you exit | 23 Dec 2014 |
| Futures sell price | **₹2,519** per share |
| Cash you have to play with | **₹100,000** |

You have two routes to the promised land:

### Option 1 – Walk the Spot‑Market Road  

1. **How many shares can you actually buy?**  

   \[
   \text{Shares} = \frac{₹100,000}{₹2,362} \approx 42 \text{ shares}
   \]

2. **What’s the value on exit?**  

   \[
   42 \times ₹2,519 = ₹105,798
   \]

3. **Profit & % return**  

   \[
   \text{Profit} = ₹105,798 - ₹100,000 = ₹5,798 \\
   \text{Return} = \frac{₹5,798}{₹100,000}\times100 \approx 5.79\%
   \]

A **5.79 %** gain in **9 days** looks decent. Annualised (just for bragging rights) that’s roughly **235 %** – enough to make your non‑trading friends jealous.  

**But** there are a few quirks:

- **T+2 settlement** – you can’t sell the shares the very next day; you have to wait two business days for them to appear in your DEMAT.  
- **Capital bound** – you’re stuck at whatever cash you have; you can’t magically buy more than ₹100,000 worth of stock.  
- **No time pressure** – you can hold those 42 shares for months, years, or even a decade.  

### Option 2 – Jump onto the Futures Train  

First, let’s talk *lot size*. For TCS, the minimum tradable block is **125 shares**. That means the **contract value** at the entry price is:

\[
\text{Contract value} = 125 \times ₹2,362 = ₹295,250
\]

**Do you need ₹295,250 cash?** Nope! Futures are the *“pay only a fraction”* club. The exchange requires a **margin** – roughly **14 %** of the contract value for TCS.  

\[
\text{Margin per lot} = 0.14 \times ₹295,250 = ₹41,335
\]

You have ₹100,000, so you could theoretically buy **2 lots**:

| **Metric** | **Value** |
|------------|-----------|
| Lots bought | 2 |
| Shares controlled | 125 × 2 = **250** |
| Total margin needed | 2 × ₹41,335 = **₹82,670** |
| Cash left unused | ₹100,000 – ₹82,670 = **₹17,330** |

You can’t do anything with the leftover cash (unless you open another position), so we’ll leave it in the bank doing nothing.

Now, let’s see the P&L:

| **Stage** | **Calculation** | **Result** |
|-----------|----------------|------------|
| **Buy contract value** | 125 × 2 × ₹2,362 | **₹590,500** |
| **Sell contract value** | 125 × 2 × ₹2,519 | **₹629,750** |
| **Profit** | ₹629,750 – ₹590,500 | **₹39,250** |

**Whoa!** That’s a **₹39,250** profit on a **₹82,670** margin outlay, which is:

\[
\frac{₹39,250}{₹82,670}\times100 \approx 47\%
\]

All in **9 days**! Annualised, that’s a mind‑blowing **≈ 1,925 %**. No wonder day‑traders drool over futures.  

**Key take‑aways from the comparison**

| **Metric** | **Spot (42 shares)** | **Futures (2 lots)** |
|------------|----------------------|----------------------|
| Capital deployed | ₹100,000 | ₹82,670 (margin) |
| Shares exposed | 42 | 250 |
| Profit (9 days) | ₹5,798 | ₹39,250 |
| % Return (9 days) | 5.79 % | 47 % |
| Leverage factor | 1× (no leverage) | ≈ 7.14× (₹590,500/₹82,670) |

Futures let you **amplify** a small price move into a *much* bigger wallet‑impact – thanks to **leverage**. But remember, leverage is a double‑edged sword: it can turn a modest gain into a windfall **or** a tiny slip into a wipe‑out.  

Below is a quick visual recap (the original Varsity image, reproduced for reference):

![Spot vs Futures payoff](http://zerodha.com/varsity/wp-content/uploads/2015/01/M4-Ch4-Chart11.png)  

---  

## 4.4 – Leverage Calculation  

When someone asks, “**How leveraged are we?**” the answer is a simple ratio:

\[
\text{Leverage} = \frac{\text{Contract Value}}{\text{Margin Deposited}}
\]

For our TCS trade:

\[
\text{Leverage} = \frac{₹295,250}{₹41,335} \approx 7.14\ \text{times}
\]

That reads as **7.14×** or **1 : 7.14**. In plain English: *Every rupee you put down controls about ₹7.14 of the underlying.*  

### What does 7.14× mean for risk?  

If the underlying price drops **14 %** (the inverse of 7.14), you’d lose **all** your margin. Quick math:

\[
\frac{1}{7.14} \approx 0.14 \;\;(14\%)
\]

#### What if the margin were even lower?  

Suppose the exchange only demanded **₹7,000** margin for the same contract (just for argument’s sake). Leverage would skyrocket:

\[
\text{Leverage} = \frac{₹295,250}{₹7,000} \approx 42.2\ \text{times}
\]

Now a **2.3 %** move against you (1 / 42.2) would wipe you out. Conversely, a 2.3 % move **in your favour** would *double* your money. That’s why I keep my leverage in the **1 : 10–1 : 12** sweet‑spot and avoid the “high‑octane” zone.  

---  

## 4.5 – The Futures payoff  

Picture this: you bought TCS futures at **₹2,362**, hoping the price would climb. If it does, you pocket the difference. If it drops, your pocket gets lighter. The **payoff diagram** is simply a line that tells you exactly how much you’ll make (or lose) for any possible closing price.

Let’s build a tiny table (the numbers are illustrative, not exhaustive):

| **Closing price on 23 Dec** | **Profit / Loss per share** |
|------------------------------|-----------------------------|
| ₹2,160 | –₹202 |
| ₹2,300 | –₹62 |
| ₹2,362 (break‑even) | ₹0 |
| ₹2,500 | +₹138 |
| ₹2,600 | +₹238 |
| ₹2,700 | +₹338 |

**How to read it:**  
If the market ends up at **₹2,160**, you lose **₹202** per share (because you bought at ₹2,362). If it’s **₹2,600**, you’re up **₹238** per share. Multiply by the number of shares you control (250 in our two‑lot example) to get the total P&L.  

Remember the fundamental truth of a **zero‑sum game**: every rupee you gain is a rupee someone else loses. The buyer’s profit = seller’s loss, and vice‑versa. Futures don’t create money out of thin air; they simply **redistribute** it.  

### Plotting the payoff  

If you draw the price on the horizontal axis and the P&L on the vertical axis, you get a **straight line** that passes through the origin (break‑even point). The slope is **+₹250 per point** for a long position (because we control 250 shares). A 1‑point rise → ₹250 profit; a 1‑point fall → ₹250 loss. This **linear** relationship is what makes futures a *linear payoff instrument*.  

---  

### Key takeaways from this chapter  

- **Leverage** is the engine that makes futures attractive; a small cash outlay can control a large notional.  
- **Margins** are just a percentage of the contract value – they’re the “ticket price” to ride the leverage train.  
- Spot‑market trades are **unleveraged** – you can only buy as much as your cash permits.  
- Because of leverage, a modest move in the underlying can explode your P&L (both up and down).  
- In a futures contract, **the buyer’s profit = the seller’s loss** – it’s a classic “zero‑sum” showdown.  
- The higher the leverage, the higher the risk **and** the higher the upside potential.  
- Futures let you *transfer* money from one pocket to another; they don’t **create** wealth out of thin air.  
- The payoff diagram of a futures contract is a **straight line** (linear), making it easy to visualise gains and losses.  

Now that you’ve seen the power (and peril) of leverage, you’re ready to decide whether you want to be the hero who rides the lever or the cautious observer who prefers the slower, steadier spot market. Choose wisely, and may your margins be ever in your favour!