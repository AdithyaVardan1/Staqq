# 7. Margin Calculator (Part 2)

**Source:** <https://zerodha.com/varsity/chapter/margin-calculator-part-2/>

---  

## 7.1 – The trade information  

Alright, let’s kick this off with the same old brain‑teaser: *Why do brokers yank margins from our accounts?*  
Before you roll your eyes and chase me with a coffee‑cup, here’s the straight‑up answer.

Margins are a **risk‑management** tool. Think of them as the broker’s “just‑in‑case‑the‑counter‑party‑does‑a‑no‑show” safety net. The heavy‑lifting is done by the **RMS** (Risk Management System) – a fancy name for a computer program that decides whether your order can go to the exchange. The moment you click “Buy”, the RMS does a micro‑second sanity check, then either gives you a thumbs‑up or says “nah, you don’t have enough skin in the game”. Meanwhile, humans in the back‑office are watching the whole circus to make sure nobody’s cheating.

When you fire off a futures order (say, you want to go long on TCS futures), you’re basically handing the RMS three pieces of data:

| What you tell RMS | Example |
|-------------------|---------|
| **Contract** you want – e.g. TCS, IDEA, etc. | “TCS‑Feb‑2025” |
| **Quantity** – how many lots | “2 lots” |
| **Price** – market or limit | “Market price” |

That’s the *basic* packet. What you *don’t* normally spill is:

- **How long you plan to hold it** – intraday only, or “I’ll keep it till expiry (or at least a few days)?”
- **Your stop‑loss** – “If it falls to X, I’ll cut my losses and exit”.

### What if you did tell the RMS those extra bits?  

Picture the RMS as a nosy roommate. The more you reveal about your schedule and quirks, the better it can decide how much “security deposit” (margin) you need to leave.

**Trade duration** tells the RMS how much volatility you’ll be exposed to.  
- **Intraday** = you only survive one day’s price swings.  
- **Multi‑day** = you’re gambling on several days of movement **plus** the dreaded *overnight risk*.

*Overnight risk* is the nightmare you get when you hold a position through the night and the market does a back‑flip. Example: you’re long BPCL futures. Overnight, crude oil jumps +5 %. BPCL’s input cost spikes, the futures price drops, and your mark‑to‑market (M2M) goes negative. That’s why the RMS treats a longer holding period as *more risky* and asks for a bigger cushion.

**Stop‑loss** is the other secret sauce. If you never tell the RMS your exit point, it assumes you’re okay with an *unlimited* loss. Say you buy BPCL at ₹649 and don’t set a stop‑loss – the RMS will imagine you could lose the whole lot, so it demands a huge margin. Put a stop‑loss at ₹640 (₹9 below entry) and the RMS now knows the worst you’re willing to lose is ₹9 per share, so it can relax the margin a bit.

**Bottom line:** the clearer you are about *how long* you’ll be in the trade *and* *where you’ll bail out*, the **less margin** the RMS will lock up.  

### A quick analogy (don’t roll your eyes)  

Imagine you’re at a consumer‑electronics store eyeing a 55‑inch TV.  

- **You ask for the price** → the salesman gives you the “regular customer” price.  
- **You say you’ll buy 50 TVs** → price drops dramatically.  
- **You pull out a wad of cash and promise to pay on the spot** → the salesman practically gives it to you for free.

The more information you hand over, the better the deal. Same story with margins.

![Cartoon about margins](http://zerodha.com/varsity/wp-content/uploads/2015/02/M4-Ch7-cartoon.jpg)  

---

## 7.2 – Product types  

We’ve established that feeding the RMS more risk data = lower margin. How do you actually feed it? By picking the right **product type** when you place the order. Different product types whisper different things to the RMS. Brokers may use different names, but the concepts stay the same. Below is Zerodha’s nomenclature (if you’re with another broker, ask them which label they use).

### NRML – “Normal” (or “I’ll hold it till I’m dead”)  

![NRML product type screenshot](http://zerodha.com/varsity/wp-content/uploads/2015/02/Image1_Product-Type.jpg)

*NRML* is the default, “buy‑and‑hold‑as‑long‑as‑you‑like” product.  
- **No trade‑length info** – the RMS assumes you could keep the contract till expiry.  
- **No stop‑loss info** – you might never tell it where you’ll exit.  

Result? The RMS plays it safe and slaps the **full** margin (SPAN + Exposure) on you. Use NRML when you truly intend to stay overnight (or longer). You *can* still use it for intraday, but you’ll be paying more than necessary.

### MIS – “Margin Intraday Square‑off” (aka “I’m a day‑trader”)  

![MIS product type screenshot](http://zerodha.com/varsity/wp-content/uploads/2015/02/Image2_MIS.jpg)

MIS tells the RMS, “I’ll be in and out before the market closes.”  
- You **must** square‑off by 3:20 PM; otherwise the RMS auto‑closes for you.  
- Because the RMS now knows you only face **one day’s** volatility, the margin is **lower** than NRML.

### Cover Order (CO) – “Intraday + Stop‑loss”  

![Cover order screenshot](http://zerodha.com/varsity/wp-content/uploads/2015/02/Image3_CO.jpg)

A CO is basically an MIS with an **explicit stop‑loss** field. When you place a CO you give the RMS:

1. **Intraday** (so it knows it’s a one‑day bet)  
2. **Your stop‑loss price** (so it knows the max loss you’ll tolerate)

Because you’ve handed over *both* pieces of info, the margin drops **even further**—often noticeably lower than plain MIS.

> *Pro tip:* The black‑highlighted box in the screenshot is where you type the stop‑loss. If you’re curious how to actually fire a CO from the terminal, Zerodha’s “Z‑Connect” article has the step‑by‑step.

### Bracket Order (BO) – “Intraday + SL + Target (+ optional trailing)”

![Bracket order screenshot](http://zerodha.com/varsity/wp-content/uploads/2015/02/Image4_BO.jpg)

A BO is the *Swiss‑army‑knife* of intraday orders. It inherits everything CO has **and** adds:

- **Target price** – where you want to lock profits.  
- **Trailing stop‑loss** (optional) – a dynamic SL that drags behind the market as it moves in your favor.  

All three (SL, target, trailing) are sent to the exchange in one go, sparing you the hassle of manually tweaking orders. The RMS, however, only cares about **risk**, not reward, so the margin for a BO is *identical* to a CO.

That wraps up the product‑type parade. Next, let’s see how the calculator lets you play with these choices.

---

## 7.3 – Back to the Margin Calculator  

### Quick refresher  

In Chapter 6 we introduced Zerodha’s **margin calculator** – a nifty tool that tells you how much cash you need to lock up for any futures contract. We also covered expiry, rollover, and spread margins. Now that we understand how risk information (duration, stop‑loss) influences the RMS, we’ll revisit the calculator’s other tabs: **Equity Futures** and **BO & CO** (highlighted in red on the UI).

![Margin calculator screenshot](http://zerodha.com/varsity/wp-content/uploads/2015/02/Image5_MC.jpg)

### Equity Futures tab  

This is your *one‑stop shop* for:

- **NRML margin** for a given contract  
- **MIS margin** for the same contract  
- **How many lots** you can afford with the cash sitting in your account  

As of Jan 2015 the list contains **~475 contracts** – enough to keep anyone busy.

#### Task 1 – “Can I afford both ACC and Infosys?”  

> **Scenario:**  
> *You have ₹80,000 in your account.*  
> *You want to go long ACC Cement futures (expiry 26‑Feb‑2015) and hold for **3 trading days**.*  
> *You also want to scalp Infosys Jan futures intraday.*  
> *Do you have enough cash?*

**Solution – Step‑by‑step**

1. **ACC (multi‑day)** → Look under the **NRML** column because you’re holding for >1 day.  
   - Scroll (or search) until you spot **ACC Feb 2015**. The calculator shows a **NRML margin of ₹48,686** (highlighted in the black vertical box).

2. **Infosys (intraday)** → Switch to the **MIS** column (or just note both values).  
   - Search “Infy”.  
   - **NRML margin:** ₹67,698 (just for reference)  
   - **MIS margin:** **₹27,079** (red arrow).  

   Since you’re intraday, pick the MIS margin.

3. **Add ‘em up:**  
   - ACC NRML = ₹48,686  
   - Infosys MIS = ₹27,079  
   - **Total required margin = ₹75,765**  

4. **Compare with cash:**  
   - You have ₹80,000 → **Enough** to open **both** positions.

*Takeaway:* By using the correct product type (NRML for multi‑day, MIS for intraday) you saved a chunk of cash compared to using NRML for everything.

#### Task 2 – “How many Wipro lots can I swing?”  

> **Scenario:**  
> *You have ₹120,000.*  
> *You want to know the max lots you can buy intraday **and** on a multi‑day basis.*

**Solution**

1. Search **Wipro** in the Equity Futures tab.  
2. Beside the **MIS** margin column you’ll see a **“Calculate”** button (green arrow). Click it.

![Calculate button screenshot](http://zerodha.com/varsity/wp-content/uploads/2015/02/Image8_EQ.jpg)

3. A pop‑up form appears; it already fills in the **current contract price**. Just make sure the **Cash** field reads ₹120,000 (the default is ₹100,000).

![Form screenshot](http://zerodha.com/varsity/wp-content/uploads/2015/02/Image9_EQ.jpg)

4. **Results:**  

   - **NRML** (multi‑day) margin per lot = **₹36,806** → you can afford **3 lots** (3 × 36,806 = ₹110,418).  
   - **MIS** (intraday) margin per lot = **₹14,722** → you can afford **8 lots** (8 × 14,722 = ₹117,776).  

That’s it – the calculator tells you exactly how many contracts you can open under each product type.

### BO & CO calculator – now we get to the “fancy” orders  

Both **Bracket Orders** and **Cover Orders** share the same margin formula (remember, the RMS only cares about risk). The BO & CO calculator works much like the SPAN calculator.

1. Pick a contract – e.g., **Biocon Futures Feb 2015**.  
2. Fill in the usual fields (price, quantity, etc.) **but leave the stop‑loss blank** for a moment.  

![BO/CO calculator without SL](http://zerodha.com/varsity/wp-content/uploads/2015/02/Image10_BOCO.jpg)

3. Hit **Calculate**. The tool will auto‑pick a **default stop‑loss** (the smallest allowed) and spit out a margin.  
4. Now *enter your own stop‑loss* (say ₹403) and recalculate.

![BO/CO calculator with SL](http://zerodha.com/varsity/wp-content/uploads/2015/02/Image11_Boco.jpg)

Result: **Margin = ₹9,062**. Compare that with the plain **NRML margin of ₹26,135** and the **MIS margin of ₹11,545** – you’re paying *much* less because you told the RMS exactly where you’d exit.

---

## 7.5 – The trailing stop‑loss  

Before we call it a night, let’s chat about the **trailing stop‑loss** (TSL). It lives inside the **Bracket Order** but is useful to know even if you’re using plain CO’s.

**Scenario you’ve all lived:**  

- You buy a stock at **₹250**, target **₹270**.  
- You set a static stop‑loss at **₹240**.  
- The price rockets to **₹265** (nice! 🎉) but then volatility drags it back, hitting your stop‑loss at **₹240**.  
- You end up with a loss despite the market having moved in your favor for a while.

**Enter the trailing stop‑loss.** Instead of a fixed exit, you let the stop‑loss **chase** the price as it moves favorably, locking in gains while still giving the trade room to breathe.

### How it works (simple math)

1. **Entry:** Long at **₹2,175**.  
2. **Initial SL:** **₹2,150** (25 points below).  
3. **Trail rule:** Every time the price moves **15 points** in your favor, raise the SL by the same 15 points.

| Price moves to | New SL (after trailing) | Profit locked (vs. entry) |
|----------------|------------------------|---------------------------|
| 2,190          | 2,165                  | +15                       |
| 2,205          | 2,190                  | +30                       |
| 2,220          | 2,205                  | +45                       |
| …              | …                      | …                         |

(See the table in the original chapter for a visual.)

In the example, the **original target** was **₹2,220**. By trailing, you may actually **exit at a higher price** because you’re constantly tightening the stop‑loss as the market climbs. The key is picking a *reasonable* trail amount – 15 points in this case, but you could use 5, 10, 30, or even a percentage, depending on the instrument’s volatility.

**Why it matters:**  
- Prevents “stop‑out” on normal intra‑day jitters.  
- Lets you ride a strong trend longer while still protecting profits.  
- No magic formula; you decide the trail size that matches your risk tolerance and the asset’s price action.

---

### Key take‑aways (the cheat‑sheet you’ll actually read)

- **More risk info → lower margin.** Tell the RMS *when* you’ll exit and *how far* you’ll let it go.  
- **NRML** = “hold forever” → highest margin (SPAN + Exposure). Use it when you genuinely plan to stay overnight or longer.  
- **MIS** = pure intraday → lower margin (only time risk). No stop‑loss info, so margin sits between NRML and CO.  
- **Cover Order (CO)** = MIS + explicit stop‑loss → *lowest* margin among intraday products.  
- **Bracket Order (BO)** = CO + target (and optional trailing). Margin identical to CO because the RMS ignores the reward side.  
- **Trailing stop‑loss** = dynamic SL that moves with the price, helping you lock profit while staying in a winning trade. No one‑size‑fits‑all rule – pick a trail that feels right for the market you’re trading.  

Now you’ve got the whole toolbox: pick the right product, feed the RMS the right intel, and watch those margin requirements shrink. Go forth, trade smarter, and may your stop‑losses be tight and your profits be trailing! 🚀  