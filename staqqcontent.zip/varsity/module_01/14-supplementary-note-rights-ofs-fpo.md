# 14. Supplementary note – Rights, OFS, FPO  

**Source:** <https://zerodha.com/varsity/chapter/supplementary-note-ipo-ofs-fpo/>

---  

##  

![Image](https://zerodha.com/varsity/wp-content/uploads/2017/09/Ch5-title.jpg)

## IPO, OFS, and FPO – How are they different?  

### IPO  

*Initial Public Offering* – think of it as the corporate equivalent of a debutante ball. A private company decides to throw its first shindig on a public stock‑exchange and invites the world to buy a slice of the pie.  

In an IPO the promoters (the people who started the party) slice off a certain percentage of the total equity and hand it to the public. Why do they do this? Two main reasons, both of which sound like a dad‑joke:  

1. **Raise cash** to fund expansion, buy new toys, or pay the early‑stage investors who want to cash out.  
2. **Gain credibility** – being listed is like getting a “Verified” badge on Instagram; it tells the market “Hey, we’re legit!”  

The mechanics of the IPO (how you price, how you file, how you get listed) are covered in depth in Chapters 4 and 5.  

Once the shares start trading in the secondary market, the company may still be thirsty for more money. The promoters have three classic “after‑party” tricks up their sleeves: **Rights Issue**, **Offer for Sale (OFS)** and **Follow‑on Public Offer (FPO)**. Let’s break each one down, one cocktail at a time.

### Rights Issue  

A Rights Issue is the corporate version of “Hey, you already own a piece of the cake, want a bigger slice at a discount?”  

The promoters go back to the existing shareholders and say, “We’ll create brand‑new shares and sell them to you at a price **lower than today’s market price**.” The discount is the sweetener that makes shareholders think, “Why not? I’m already in.”  

**How it works**  
- New shares are offered **in proportion** to the shares you already hold.  
- Example: a **1:4 Rights Issue** means for every **four** shares you own, you get the right to buy **one** extra share.  
- Because the offer is limited to current owners, the pool of capital is capped by how many of those shareholders actually bite.  

**Side‑effect:** New shares dilute the value of the old ones (think of adding more water to a jug of orange juice – each sip is a little less orange).  

**Real‑world example:**  
South Indian Bank announced a **1:3 Rights Issue** (one extra share for every three you already own) at **₹14** per share. The market price on the record date (17 Feb 2017) was **₹20**, so the discount was a tidy **30 %**. The bank offered **45.07 lakh** new shares to its existing shareholders.  

All the nitty‑gritty of Rights Issues – from entitlement ratios to renunciation – is explored in Chapter 11 under “Corporate Actions”.

### OFS  

*Offer for Sale* is the corporate equivalent of “I’m moving out of the house, anyone want to buy my room?”  

Instead of targeting only the current owners, the promoters open the door to **anybody** in the market. The exchange sets up a special “OFS window” that brokers use to channel the sale. The main motives are:  

1. **Promoters want to cash out** some of their stake.  
2. **Meet statutory public‑shareholding requirements** (e.g., government‑run PSUs must keep **≥ 25 %** of shares in the public hands).  

**Key mechanics**  
- The company sets a **floor price** – the lowest price it will accept.  
- Retail and non‑retail investors place bids **at or above** this floor.  
- The exchange aggregates all bids, determines a **cut‑off price**, and allocates shares to the highest bidders.  
- Settlement happens **T+1** (i.e., shares appear in the buyer’s demat account the next business day).  

**Real‑world example:**  
NTPC Limited launched an OFS of **46.35 million** shares with a floor price of **₹168**. The offer was **fully subscribed** within two days. The OFS ran on **29 August 2017** for non‑retail investors and on **30 August 2017** for retail investors.  

### FPO  

A *Follow‑on Public Offer* is basically an IPO’s older sibling. The company is already listed, but it wants to **raise fresh capital** (or occasionally, to let promoters sell a chunk, though that’s rarer now).  

There are two ways an FPO can add shares:  

1. **Dilution** – create brand‑new shares and sprinkle them into the market.  
2. **Secondary issue** – existing shareholders sell some of their holdings (this looks a lot like OFS, but the regulatory path is longer).  

**Process (the “old‑school” way):**  

1. **Mandate a merchant banker** to draft a **Draft Red Herring Prospectus (DRHP)**.  
2. **SEBI** (the market watchdog) reviews and approves the DRHP.  
3. The company announces a **price band** (e.g., ₹145‑₹150).  
4. Investors bid through **ASBA** (Application Supported by Blocked Amount) – either online via internet banking or offline at a bank branch.  
5. After a **book‑building window** of 3‑5 days, the **cut‑off price** is declared based on demand.  
6. Shares are allotted, listed, and start trading.  

Because OFS was introduced in **2012**, the FPO route has become a bit of a dinosaur – it’s slower, requires more paperwork, and costs more. Still, for big‑ticket projects it remains an option.  

**Real‑world example:**  
Engineers India Ltd launched an FPO in **February 2014** with a price band of **₹145‑₹150**. The issue was **oversubscribed 3‑times**. On the first day of trading, the shares were quoted at **₹151.1**, while the lower band represented a **4.2 %** discount to the market price at that moment.  

### Difference between OFS and FPO  

| Aspect | OFS (Offer for Sale) | FPO (Follow‑on Public Offer) |
|--------|----------------------|-------------------------------|
| **Primary purpose** | Promoters dump their own shares (cash‑out) | Raise fresh capital for new projects (or occasional secondary sale) |
| **Dilution** | No new shares are created → **no dilution** of existing shareholders | New shares can be issued → **dilution** possible, altering shareholding structure |
| **Impact on authorized share capital** | None – the total authorized shares stay the same | Can increase authorized/share capital if fresh shares are issued |
| **Eligibility (size of company)** | Only companies with **market‑cap ≥ ₹1,000 crore** (≈ $120 million) can use OFS | **All listed companies**, regardless of market cap, may opt for an FPO |
| **Regulatory timeline** | Simpler, faster – just a floor price and bid window | Lengthier – DRHP, SEBI approval, book‑building, cut‑off price determination |
| **Trend since SEBI’s OFS launch** | OFS usage has surged; many firms prefer this route | FPO frequency has dropped because OFS is quicker and cheaper |

In short, think of **OFS** as “sell your existing pizza slices to the crowd” and **FPO** as “bake a bigger pizza and hand out new slices”. Both get money onto the company’s table, but they do it in very different culinary styles. Cheers to that!