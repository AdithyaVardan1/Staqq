# 7. Stock market index explained: Sensex, Nifty & how they work  

**Source:** https://zerodha.com/varsity/chapter/the-stock-markets-index/  

---  

## 7.1 – Overview  

Alright, picture this: I ask you for a **real‑time traffic report** of your hometown. Do you pull out a map, count every single lane, and stare at every traffic light?  Nope. You’d probably glance at the main arteries—the highway, the central boulevard, that notorious “Five‑Way” intersection—and form a quick mental picture. If those key roads are snarled, you’ll declare “city‑wide gridlock.” If they’re cruising, you’ll say “smooth sailing.”  

Those **critical roads** act like a *barometer* for the whole city’s traffic health.  

Now swap cars for stocks. If I say, “How’s the Indian market today?” you could theoretically scan the **~5,000 companies listed on the Bombay Stock Exchange (BSE)** and the **~2,000 firms on the National Stock Exchange (NSE)**, tally who’s up, who’s down, and then hand me a dissertation. Sounds exhausting, right?  

Instead, you’d pick a handful of heavyweight names from a spread of sectors—say, a bank, a pharma, an IT firm, a metal player, and maybe a consumer‑goods giant. If most of those are climbing, you’ll answer “the market’s up.” If they’re all tumbling, you’ll say “down.” If they’re doing a cha‑cha, you’ll call it “flat/sideways.”  

Those **representative stocks** you’ve cherry‑picked together form what we call a **stock market index**.  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/08/Ch-7-title.jpg)  

---  

## 7.2 – The Index  

Good news: you don’t have to keep a spreadsheet of every “representative” stock on your phone. The exchanges already bundle those key companies into a single, continuously‑updated figure called a **stock market index**.  

India’s marquee indices are:  

* **S&P BSE Sensex** – the pulse of the Bombay Stock Exchange.  
* **Nifty 50** – the NSE’s flagship, tracking the 50 most‑traded stocks on the National Stock Exchange.  
* **Bank Nifty** – a specialist gauge of the banking sector (think of it as the “Finance‑only” version of the Nifty).  

A quick side‑note: the “S&P” tag comes from **Standard & Poor’s**, the global credit‑rating powerhouse that designed the methodology and licensed it to the BSE. NSE, on the other hand, runs its own suite of indices through a subsidiary called **NSE Indices Limited**.  

The Nifty 50 isn’t a random grab‑bag; it’s built on a transparent methodology that we’ll unpack later. In essence, an **ideal index** is a live, accurate snapshot of market sentiment. When the index climbs, participants collectively think “the future looks shiny.” When it slides, the vibe is more “doom‑and‑gloom.”  

---  

## 7.3 – Practical uses of the Index  

### 1. Information – The market’s mood ring  

An index is the **economy’s selfie**—a quick visual of how investors feel. A rising index signals optimism; a falling one hints at pessimism.  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/08/info.png)  

**Example:** On **21 Nov 2022**, the Nifty 50 stood at **18,150**. Six months earlier it was **15,820**. That’s a jump of **2,300 points** or roughly **14.75 %**—a clear bullish vibe. In plain English, investors were collectively humming “the future’s bright.”  

But indices can swing faster than a cat on a hot tin roof. The same day at **9:30 am** the Nifty was **18,140**, and an hour later it slipped to **18,099**—a **40‑point dip** in 60 minutes, hinting at short‑term nerves.  

### 2. Benchmarking – Your performance yardstick  

Imagine you plunked **₹100,000** into a portfolio and, a year later, it’s worth **₹120,000**. That’s a **20 %** gain—sounds sweet, right?  

Now check the Nifty 50’s journey over the same period. If the index surged **30 %**, you’ve actually *under‑performed* the market.  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/08/benchmark.png)  

In other words, without an index you’re flying blind; the index is the **baseline** against which you can judge whether you’re a market‑beating wizard or just an average Joe.  

### 3. Trading – Riding the index wave  

A lot of traders treat the index itself as the star of their playbook. Instead of picking individual stocks, they take a **broad‑brush view** of the economy and trade accordingly, usually on a short‑term horizon.  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/08/trade.png)  

**Scenario:** It’s **10:30 am**, the Finance Minister is about to unveil the budget. The Nifty sits at **18,150**. You’ve read the pre‑budget hype and think it’ll be a *budget‑boost*. Expecting the index to jump, you buy the Nifty futures at **18,150**. The budget lands, sentiment turns rosy, the index ticks up to **18,450**—you’ve just pocketed a **300‑point** profit. (Yes, you can actually trade the index via **derivatives**—futures and options—but that’s a whole other episode.)  

### 4. Portfolio Hedging – Insurance for your stock stash  

Most long‑term investors hold a diversified basket of **15–20 stocks**. Even a well‑balanced basket can get battered in a prolonged market downturn (think 2008‑09). By taking an opposite position in the index—say, selling Nifty futures—you can **offset** the losses in your portfolio. We’ll dive deeper into this hedging magic in the futures module.  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/08/portfolio.png)  

---  

## 7.4 – Index construction methodology  

If you want to become an **index‑trading guru**, you need to know how the index gets its ingredients and weightings.  

1. **Selection** – A stock must meet a set of eligibility rules (e.g., liquidity, market‑cap thresholds) to join the index. If it falls out of those bounds later, it gets swapped out for a more deserving peer.  

2. **Weightage** – Not all stocks are equal; each gets a **weight** that reflects its influence on the index’s movement.  

   *Example:* **ITC Ltd.** carries a **3.85 %** weight in the Nifty 50. In simple terms, **3.85 %** of the index’s rise or fall can be traced back to ITC’s price swings. (You can see the full weight list **[here](https://www.nseindia.com/market-data/live-market-indices)**.)  

3. **Free‑float market‑capitalisation** – India adopts this method. A stock’s **free‑float market cap** = **(Number of shares that are actually tradable) × (Current price)**. The larger the free‑float cap, the bigger the weight.  

   *Illustration:* Company **ABC** has **100** shares floating in the market, each priced at **₹50**. Its free‑float market cap = **100 × 50 = ₹5,000**.  

4. **Rebalancing** – The index committee reviews the basket periodically (usually quarterly) and tweaks the composition to keep the index representative.  

### Top 10 Nifty 50 heavyweights (as of writing)  

| Rank | Company | Approx. Weight |
|------|---------|----------------|
| 1 | Reliance Industries Ltd. | 12‑13 % |
| 2 | HDFC Bank | 8‑9 % |
| 3 | Infosys | 7‑8 % |
| … | … | … |

*(Exact percentages shift daily; Reliance remains the heavyweight, meaning the Nifty is most sensitive to its price moves.)*  

---  

## 7.5 – Sector‑specific indices  

Beyond the broad‑brush Sensex and Nifty, there are **sectoral indices** that zoom in on particular slices of the economy.  

* **Bank Nifty** – captures the collective mood of the banking sector.  
* **CNX IT** – tracks the performance of all listed IT stocks.  

Both BSE and NSE maintain such **sector‑specific** gauges, and their construction follows the same free‑float cap methodology as the flagship indices.  

---  

### Key takeaways from this chapter  

- An index is essentially a **barometer** for the whole economy.  
- When the index climbs, market participants are **optimistic**; when it falls, they’re **pessimistic**.  
- India’s two marquee indices are the **BSE Sensex** and the **NSE Nifty 50**.  
- Indices serve multiple purposes: **information, benchmarking, trading, and hedging**.  
- **Index trading** (via futures/options) is arguably the most popular way to play the market.  
- Construction follows the **free‑float market‑capitalisation** method—bigger, more tradable companies get bigger weights.  
- **Sector‑specific indices** (like Bank Nifty, CNX IT) let you gauge the sentiment of individual industries.  

Now you’ve got the toolbox, the thermometer, and the cheat sheet—go forth and impress your friends at the next cocktail party with your newfound index swagger! 🍸🚀