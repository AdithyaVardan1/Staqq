# 4. The IPO Markets (Part 1)

**Source:** https://zerodha.com/varsity/chapter/the-ipo-markets-part-1/

---  

## 4.1 – Overview  

*Last refreshed on 15 Nov 2022. You might spot a stray comment or two in the Q&A box—pretend they’re leftover confetti from a birthday party. The meat of the chapter is untouched.*  

The first three chapters gave you the 101 on how markets tick. Now it’s time to ask the big, inevitable question that haunts every founder after the first cup of coffee: **Why do companies go public?** Getting a grip on this will be the bedrock for everything that follows.  

In this chapter (and the one that follows) we’ll walk through the motivations for an IPO, and along the way we’ll pick up a handful of juicy finance concepts that will make you sound smarter than the bartender at happy hour.

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/07/Ch4-title.jpg)

---

## 4.2 – Origin of a Business  

Before we start dissecting the IPO beast, let’s rewind and watch a typical startup’s origin story unfold like a Netflix mini‑series. We’ll split the tale into bite‑size “scenes” so you can see how the business, the money, and the characters evolve until the big public debut.

### Scene 1 – The Angels  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/07/A.png)

Meet our protagonist: a wide‑eyed entrepreneur who’s convinced the world needs **organic, runway‑ready cotton tees**. The designs are fresh, the cotton is buttery soft, and the price tag is friendly enough to make a college student gasp.  

But—plot twist—he/she has **zero cash**. No venture capital, no bank loan, just a head full of ideas and a heart full of optimism. What does a broke founder do? Call Mom, Dad, and the cousin who still lives in the family’s basement.  

Enter the **angel investors**—two trusty friends who hand over cash because they love the founder (or maybe because they love free drinks at the launch party). Angel money isn’t a loan; it’s an *investment* that buys a slice of the pie.  

Let’s say the founder, plus the two angels, pool **₹5 crore**. This cash injection is the **seed fund**—sometimes dubbed the “Friends & Family round.” Note: the money goes straight into the **company’s** bank account, not the founder’s personal stash (otherwise the taxman would be very, very unhappy).  

Professional angels also exist—think of them as the “angel investors with résumés.” They scout startups the way a talent agent scouts actors.  

In exchange for the seed cash, the three of them receive **share certificates**, which are essentially tiny pieces of ownership. At this point the only asset the company owns is the cash itself, so the **valuation** equals the cash on hand: **₹5 crore**. (You could argue that the brilliant t‑shirt idea adds intangible value, but let’s keep the math clean.)  

Shares are a breeze to issue. Suppose the company decides each share has a **face value (FV)** of **₹10**. With **₹5 crore** of share capital, you get **50 lakh shares** (5 crore ÷ 10). If the FV were ₹5, you’d double the share count to 1 crore, and so on. SEBI’s DIB guidelines keep the FV in a reasonable range—no one wants a ₹1‑lakh‑face‑value share that would scare off investors.  

Armed with seed money, the founder opens a modest factory and a single storefront, hires a few passionate workers, and begins cranking out those coveted tees.

---

### Scene 2 – The Venture Capitalist  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/07/V1.png)

Fast‑forward two years. The t‑shirts are a hit, revenue streams in, and the business finally **breaks even**. Our founder is no longer a greenhorn; he/she now knows which cotton supplier never delivers late‑night “surprises.”  

Buoyed by confidence, the founder wants to **scale**: add another factory, open more stores, and basically become the “Zara of organic tees.” The expansion plan needs **₹7 crore**.  

Because the company now has a proven revenue track record, it can attract a **Venture Capitalist (VC)**. VC money typically shows up as **Series A funding**.  

Here’s what happens when the VC drops the ₹7 crore:  

- **Dilution** – the founder’s slice of the pie shrinks a bit because new shares are issued to the VC.  
- **Valuation bump** – the company’s notional worth goes up (the VC’s money acts like a stamp of credibility).  
- **Notional profit for early backers** – the angels see a paper‑gain on their original investment, even though they haven’t sold a share yet.  

The VC’s cash fuels the new factory and extra stores. Sales climb, the brand gets buzz, and the management team becomes a little more “corporate‑suit‑ready,” which in turn lifts profit margins.  

---

### Scene 3 – The Banker  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/07/B.png)

Three more years fly by. The company now dominates its niche and dreams of **nation‑wide retail**—think three new cities, each with flagship stores. To make this happen, they need **₹40 crore** of **CAPEX** (capital expenditure).  

How does a growing firm raise that kind of cash? Three classic routes:  

1. **Internal accruals** – plow back a chunk of the profit (the business already earns enough to self‑fund part of the expansion).  
2. **Series B equity** – invite another VC or a growth‑stage fund to buy fresh shares.  
3. **Debt** – walk into a bank and ask for a loan (the bank is happy because the firm has a solid track record).  

Let’s say the company goes all‑in:  

- **₹15 crore** from retained earnings,  
- **₹10 crore** from a new Series B round,  
- **₹15 crore** as a bank loan (debt).  

The fresh equity injection lifts the **valuation** again, giving early investors even bigger paper‑profits. The debt, meanwhile, adds a **finance‑charge** (interest) that will shave off a slice of future profits—but that’s a story for the **Fundamental Analysis** chapter.  

Real‑world analogues? Think **Infosys**, **Titan**, **Bajaj Finserv**, **HDFC Bank**, or the global giants **Google**, **Apple**, **Amazon**—all followed similar stepping‑stone financing paths.

---

### Scene 4 – The Private Equity  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/07/PE.png)

Eight years into the journey, the business is a household name and wants to **diversify** into accessories, cosmetics, and perfumes. The new ambition demands a **₹60 crore** CAPEX infusion.  

Debt is getting pricey—interest is the corporate version of a leaky roof. Instead, the firm looks for **Series C** funding, but ordinary VCs typically write checks in the **₹1‑₹10 crore** range. Enter the **Private Equity (PE)** firm, the big‑brother of venture capital.  

Key differences between **VCs** and **PEs**:  

| VC | PE |
|---|---|
| Writes smaller cheques (₹1‑₹10 cr) | Writes **big** cheques (₹10‑₹100 cr or more) |
| Loves early‑stage, high‑risk startups | Prefers mature, cash‑generating businesses |
| Usually takes a **minority** stake | Often takes **significant** ownership and a **board seat** |
| Exits within 5‑7 years via IPO or sale | Looks for **strategic exits** after 3‑5 years, sometimes via IPO |  

PE firms are seasoned professionals with Ivy‑League résumés and a keen eye for operational efficiencies. They inject capital, send a few of their own people onto the board, and watch the company execute its growth plan.  

Because PE money is meant for large‑scale CAPEX, the deployment period can span a few years. In our story, the PE infusion fuels the diversification and nationwide rollout.

---

### Scene 5 – The IPO  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/07/IPO.png)

Five years after the PE boost, the firm is a **national powerhouse** with a diversified portfolio, steady profits, and a loyal fan base. Yet the founder still has **big dreams**—think **global expansion**: two stores in every major world city.  

The new CAPEX bill? A whopping **₹200 crore**. The board now has a menu of financing options:  

- **Retained earnings** (use whatever profit you’ve built up)  
- **Series D** from another PE fund  
- **More debt** from banks  
- **Bond issuance** (another flavor of debt)  
- **Initial Public Offering (IPO)** – sell shares to the public for the first time  
- **A mix** of any of the above  

For the sake of illustration, let’s say the company decides to **combine internal accruals with an IPO**.  

When a firm files for an IPO, it **offers its shares to the general public** for the first time. Retail investors, institutions, and anyone with a brokerage account can subscribe at the set **issue price**. This first‑time public sale is why we call it **“Initial Public Offer”**—the company’s debut on the stock‑exchange runway.  

Now the story pauses for a Q&A session (the kind you’d hear from a curious friend at a bar):  

1. **Why go public now?**  
2. **Why not IPO during Series A‑C?**  
3. **What happens to existing shareholders after the IPO?**  
4. **What does the crowd look for before buying those fresh shares?**  
5. **How does the IPO process actually roll out?**  
6. **Which financial middle‑men get involved?**  
7. **What life looks like for the company once it’s public?**  

We’ll unpack each of those questions (and a few extra nuggets) in the next chapter, giving you the full backstage pass to the IPO arena. By the end, you should be able to **visualize the financing timeline** that nudges a private firm into the public spotlight.

---

### Key takeaways from this chapter  

- Before you can answer *“Why go public?”* you need to grasp **how a business is born and grows**.  
- Money that shows up **pre‑revenue** comes from **Angel Investors**—the earliest believers.  
- Angels shoulder **the highest risk** (they’re essentially betting on a dream).  
- The cash angels provide is called the **seed fund**.  
- Angel investments are usually **small** relative to later rounds.  
- **Valuation** = what the market thinks the whole company (assets, liabilities, future growth) is worth.  
- **Face value** (or **nominal value**) is the arbitrary “original price” of a share, e.g., ₹10 per share.  
- Money spent on scaling the business is **CAPEX** (capital expenditure).  
- **Series A, B, C** are sequential equity rounds; each typically comes with a **higher valuation**.  
- When a company outgrows the appetite of VCs, it turns to **Private Equity (PE)** for bigger cheques.  
- **PE funds** invest large sums in relatively mature firms and take **board seats** to steer strategy.  
- **Risk appetite**: Angels > VCs > PE (the later the stage, the lower the risk).  
- As revenue and profits climb, the **valuation swells**, creating paper‑wealth for early backers.  
- An **IPO** is the mechanism for a company to raise cash **from the public**—money that can fund CAPEX, retire debt, reward shareholders, or any other legitimate purpose.  

That’s the curtain‑call for Part 1. Grab a drink, let the concepts settle, and get ready for the deep‑dive into the **IPO process** in the next chapter!