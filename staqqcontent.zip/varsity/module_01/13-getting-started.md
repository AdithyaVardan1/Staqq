# 13. Getting started  

**Source:** https://zerodha.com/varsity/chapter/getting-started/

---  

## 13.1 – Dig deeper  

First off, **congrats, you crazy data‑junkie!** If you’ve managed to slog through every single chapter, wade through the endless comment threads, and still haven’t fallen asleep, then you’re not just a casual onlooker – you’re a bona‑fide market‑enthusiast who actually wants to *make* money, not just collect trivia about ticker symbols.  

That means you’re warmed up, caffeinated, and ready to dig deeper than a mole on a caffeine binge.  

The goal of this opening module is simple: give you a **hands‑on, no‑fluff intro** to how stock markets work. We’ve cherry‑picked the concepts you *must* know if you’re brand‑new to the arena. If you’re still coming away with a bunch of unanswered questions, that’s a good sign – it means the material is actually making you think. Your brain‑cells will find the missing pieces in the modules that follow.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2019/09/Ch-13title.jpg)

Before we sprint ahead, let’s take a quick detour to explain **why we have so many modules** and how they fit together like pieces of a massive financial jigsaw puzzle. Below is a taste of the topics we’ll cover in the Varsity curriculum (and yes, we’ll keep adding more as the market evolves).  

- **Introduction to Stock Markets**  
- **Technical Analysis**  
- **Fundamental Analysis**  
- **Futures Trading**  
- **Option Theory**  
- **Option Strategies**  
- **Markets & Taxation**  
- **Currency, Commodity, and Govt Securities**  
- **Risk Management & Trading Philosophy**  
- **Trading Systems**  
- **Personal Finance (Mutual Funds)**  
- **Integrated Financial Modelling**  

*In other words, we’ve got a whole buffet of market knowledge. Come hungry.*  

---

## 13.2 – So many modules, how are they interrelated?  

Think of **Varsity at Zerodha** as a massive, well‑curated library of market education. Each big‑topic (Fundamentals, Technicals, Derivatives, etc.) is a *module*—think of a module as a **book** and the individual lessons inside as **chapters**.  

You might be wondering: *“How the heck do all these books fit on the same shelf?”* Let’s break it down with a little thought experiment.  

> **Question:** What’s the single most important factor for success in the markets?  

If you’re like most traders, you’ll shout out “risk management,” “discipline,” “timing,” or “inside information.” Those are all vital, but there’s an even more foundational piece: **your Point‑of‑View (POV).**  

### What’s a POV, anyway?  

A POV is simply the **direction you think a stock or index will move**.  
- **Bullish POV** → you expect the price to rise → you go *long* (buy).  
- **Bearish POV** → you expect the price to fall → you go *short* (sell).  

Without a POV, you’re basically standing on the trading floor with a blank stare, waiting for the market to hand you a “Buy” or “Sell” sign. You can’t execute a trade if you don’t know *what* you’re trying to achieve.  

Once you have a POV, you can start layering in the nice‑to‑have ingredients: risk controls, timing tweaks, macro‑economic context, etc. But the POV is the **base sauce**; everything else is just garnish.  

### How do you cook up a POV?  

You need a **systematic approach** to sift through the noise and land on a view you can trust. Here are the main “flavors” traders use:  

1. **Fundamental Analysis (FA)** – Dig into earnings, revenue growth, balance‑sheet health, etc.  
2. **Technical Analysis (TA)** – Read price charts, patterns, and indicators.  
3. **Quantitative Analysis (QA)** – Apply statistical models, probability distributions, and factor‑based screens.  
4. **Outside Views** – Opinions from analysts, news, or the guy at the bar (use with caution).  

#### Sample POVs from each method  

| Method | Sample Thought Process | Resulting POV |
|--------|-----------------------|--------------|
| **FA‑based** | “Q2 numbers show 25 % revenue growth, 15 % net‑profit growth, and the guidance is upbeat.” | **Bullish → BUY** |
| **TA‑based** | “MACD crossed above signal, a bullish engulfing candle formed at support. Short‑term momentum is green.” | **Bullish → BUY** |
| **QA‑based** | “The stock’s PE is now 3 standard deviations above its historical mean. The odds of staying that high are ~1 %.” | **Bearish → SELL** |
| **Outside view** | “TV analyst says ‘Buy!’ (and he’s wearing a snazzy tie).” | **Bullish → BUY** (but beware of the tie‑bias) |

**Pro tip:** Always let *your own* analysis drive the POV. Acting on an outside view is like ordering a drink you’ve never tried because the bartender swears it’s “the best thing since sliced bread.” You might love it, or you might be choking on regret.  

### From POV to actual trade – the instrument selection maze  

Got a POV? Great! Now you have to decide **how** to act on it. This is where the market turns from a simple “yes/no” into a choose‑your‑own‑adventure novel.  

If you’re **bullish**, you have a menu of options:  

- **Buy the stock outright** in the spot (cash) market – classic “buy and hold.”  
- **Enter the derivatives arena**:  
  - **Futures** – a contract to buy the stock later at a pre‑agreed price. Great for short‑term, high‑leverage bets.  
  - **Options** – you can buy **calls** (right to buy) or **puts** (right to sell). By mixing calls and puts you can craft “synthetic” long positions, hedged bets, or even “zero‑cost” strategies.  

(You might have noticed we repeated some lines in the original – that was a copy‑paste glitch. We’ll keep the list tidy here.)  

### Matching POV horizon to the right tool  

| POV Horizon | Recommended Instrument | Why? |
|-------------|-----------------------|------|
| **Long‑term (≥ 1 year)** | **Delivery (spot) purchase** | You’ll hold the shares, collect dividends, and let compounding work its magic. |
| **Short‑term (days‑to‑weeks)** | **Futures** | Leverage lets you amplify small moves; you can exit quickly without worrying about settlement. |
| **Bullish but risk‑averse** | **Options (long calls or spreads)** | You pay a premium, limiting loss to that premium, while keeping upside potential. |

In short, **the right instrument amplifies the strength of your POV** and keeps your risk in check. Think of it as pairing the right wine with a steak – the steak (your POV) is already delicious, but the wine (the instrument) makes the whole experience unforgettable.  

### The big picture  

By now you should have a feel for why every module in Varsity matters. Each one teaches you a piece of the puzzle that helps you **form a solid POV** *and* **pick the proper vehicle** to express it.  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/09/M1-ch13-chart.png)

Keep that mental map in your back pocket, then dive into the next chapters.  

---

## What’s coming up next?  

The **next two modules** will deep‑dive into the two most popular POV‑building methods:  

1. **Technical Analysis** – charts, candlesticks, indicators, and the art of reading price action like a fortune‑teller with a spreadsheet.  
2. **Fundamental Analysis** – the “numbers game” that looks at earnings, cash flow, and why some companies can grow faster than a rabbit on a carrot diet.  

After you’ve absorbed those, you’ll be able to **craft a POV** on any security. Later modules will walk you through **which instrument** (spot, futures, options, etc.) best fits each POV, and we’ll sprinkle in **risk‑management techniques** so your account doesn’t go from “green” to “red” faster than a traffic light on a busy street.  

Ready to roll? Grab a coffee, put on your favorite playlist, and let’s start turning those market mysteries into your next payday.  

**Let’s roll!**  