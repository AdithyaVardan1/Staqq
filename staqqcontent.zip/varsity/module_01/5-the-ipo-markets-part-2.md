# 5. The IPO Markets (Part 2)

**Source:** <https://zerodha.com/varsity/chapter/the-ipo-markets-part-2/>

---

## 5.1 – Overview  

*Last spruced‑up on 15 Nov 2022 – ignore the odd stray comments in the Q&A box; they’re just the ghosts of past students.*  

In the previous chapter we followed a make‑believe startup from “Eureka!” to “Let’s go public, baby!” – a quick‑and‑dirty montage that skipped the boring bits so you could see the big picture. We talked about the life‑cycle of a business and the cash‑raising options that pop up at each stage.  

Now we turn the spotlight on the **Primary market** (a fancy name for the IPO arena) – the place that lures a lot of first‑time investors like a free‑beer night at the bar. In this chapter we’ll break down the IPO process, the why‑s, the who‑s, and the what‑s, all while keeping the jargon from sounding like a cryptic crossword.

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/08/Ch5-title.jpg)

Understanding *why* a company decides to go public is the foundation for everything that follows, so buckle up and grab a pint (or a chai) as we dive in.

---

## 5.2 – Why Do Companies Go Public?  

When the previous chapter left you hanging with “Why now?” we’ll answer it straight away.  

### The headline‑grabbers  

1. **Funding the CAPEX machine** – The most common excuse: “We need cash to build factories, buy equipment, expand our runway.” An IPO is a quick way to raise billions without taking on a mountain of debt.  
2. **Swap debt for equity** – High‑interest loans are like that ex who keeps calling at 2 am. Going public lets a firm retire expensive debt, shave off finance charges, and boost the bottom line.  
3. **Give early backers a way out** – Angel investors, VCs, and private‑equity firms love an exit. An IPO creates a public market where they can sell their stakes (subject to lock‑up, of course).  

> **Pro‑tip:** Pick a recent IPO (think **Zomato**, **Nykaa**, or **Paytm**), Google “IPO reason”, and you’ll see the exact mix of the above motivations.

### The promoter’s three‑point cheat sheet  

| Why go public? | What the promoter gets |
|----------------|------------------------|
| **Raise cash for CAPEX** | No need to chase banks; the balance sheet looks cleaner and profitability improves. |
| **Ditch pricey debt** | Zero interest payments = happier shareholders (and a fatter bottom line). |
| **Spread risk** | Instead of one giant private equity beast, you get thousands of tiny retail investors. Think “crowd‑sourced safety net.” |

*(The table repeats the three points because repetition makes the message stick—just like that chorus you can’t get out of your head.)*

### The “extra credit” perks  

- **Early‑investor exit** – Once shares start trading, founders, angels, and VCs can cash out. Yes, there’s a lock‑in period (usually 6 months), but after that the party can begin.  
- **Employee Stock Options (ESOPs)** – Think of this as the company’s way of saying “you’re family, here’s a slice of the pie.” Google, Infosys, Twitter, Facebook, Amazon… all used ESOPs to turn employees into shareholders.  
- **Boosted visibility** – Public companies get media love, analyst coverage, and a brand‑recognition boost that can translate into more customers.  

> *Side note:* If you ever wonder why you see a company’s logo on every news ticker after it lists, that’s the “visibility” effect in action.

---

## 5.3 – Merchant Bankers (the IPO’s wingmen)  

Once the decision to go public is nailed, the firm needs a **merchant banker** – also known as the **Book‑Running Lead Manager (BRLM)** or simply the **Lead Manager (LM)**. Think of them as the wedding planner for the company’s big debut.

### What does a merchant banker actually do?  

1. **Due‑diligence detective work** – Verify that the company’s books, contracts, and compliance are squeaky clean, then hand over a due‑diligence certificate.  
2. **Draft the DRHP** – The *Draft Red Herring Prospectus* (DRHP) is the IPO’s résumé. The banker works hand‑in‑hand with the firm to produce it.  
3. **Underwrite the shares** – If the IPO is under‑subscribed, the banker may have to buy the leftover shares (a safety net). If it’s over‑subscribed, they’ll allocate the excess to investors. A famous flop: **Anthony Waste Ltd** in March 2020 failed to hit its subscription threshold, so the issue was shelved.  
4. **Set the price band** – Decide the lower and upper price limits. Example: **Keystone Realtors Ltd** launched with a band of **₹514 – ₹541**.  
5. **Organise the roadshow** – The IPO’s version of a concert tour: the company’s top brass hits cities, pitches to institutional investors, and tries to get the crowd excited.  
6. **Hire the supporting cast** – Registrars, advertising agencies, and other intermediaries are booked by the lead manager, who also crafts the overall marketing strategy.  

These tasks are repeated in the original text for emphasis; we’ll keep the spirit but avoid unnecessary duplication.

When the merchant banker signs on, the countdown to the public debut begins.

---

## 5.4 – IPO Sequence of Events (the step‑by‑step dance)  

Everything must follow SEBI’s rulebook, much like a bartender follows the liquor licence. Here’s the choreography:

1. **Appoint a merchant banker** – Large issues often bring in a syndicate of banks, just like a band may have a lead guitarist and supporting rhythm section.  
2. **File a registration statement with SEBI** – This document says who you are, why you want to go public, and shows your financial health.  
3. **SEBI’s nod (or ‘no‑go’)** – The regulator reviews the filing and either gives the green light or tells you to go home.  
4. **Prepare the DRHP** – Once cleared, the company publishes the Draft Red Herring Prospectus, which contains:  

   - **Estimated size of the IPO** (e.g., “₹5 billion”)  
   - **Number of shares offered** (e.g., “10 million shares”)  
   - **Purpose of the funds** (CAPEX, debt repayment, acquisitions, etc.) with a timeline  
   - **Business description** – revenue model, cost structure, growth story  
   - **Full financial statements** – balance sheet, profit‑and‑loss, cash flow  
   - **Management Discussion & Analysis (MD&A)** – management’s view of future prospects  
   - **Risk factors** – what could go wrong (competition, regulatory changes, etc.)  
   - **Management bios** – who’s steering the ship  

5. **Market the IPO (the roadshow)** – TV spots, print ads, investor meetings – basically the IPO’s advertising blitz.  
6. **Fix the price band** – Decide the lower and upper limits (must be realistic; too high and nobody bites).  
7. **Book‑building window** – Investors submit bids at any price within the band. For a ₹100‑₹120 band, an investor might bid ₹110 for 1,000 shares. All bids are collected and the “price discovery” process begins.  
8. **Closure** – After the window closes (usually 3–5 days), the price with the highest aggregate demand becomes the **cut‑off price**; the issue is allotted accordingly.  
9. **Listing Day** – Shares start trading on the exchange. The opening price can be at a premium, at par, or at a discount to the cut‑off, depending on market appetite.  

*Repeat of steps in the original is for emphasis; we’ve consolidated while preserving every element.*

---

## 5.5 – What Happens After the IPO?  

During the **primary market** phase, investors place bids inside the price band. Once the shares are listed, the party moves to the **secondary market** – the day‑to‑day trading floor where shares change hands like bottles of whisky at happy hour.  

- **Primary market** = you’re buying directly from the company (the “new‑issue” market).  
- **Secondary market** = you’re buying from other investors (the “old‑issue” market).  

Why do people trade? Why do prices wiggle up and down? That’s the next chapter’s playground – supply & demand, sentiment, news, and a dash of randomness.

---

## 5.6 – Key IPO Jargon (the cheat‑sheet)  

| Term | What it means (in plain English) |
|------|-----------------------------------|
| **Under‑subscription** | The IPO asked for 100,000 shares, but only 90,000 bids came in. Not ideal – it signals weak demand. |
| **Oversubscription** | The opposite: 200,000 bids for 100,000 shares = 2× oversubscribed. Shows roaring interest. |
| **Green‑Shoe (Overallotment) Option** | A clause that lets the issuer sell up to ~15 % extra shares if the IPO is oversubscribed. It stabilises the post‑listing price. |
| **Fixed‑price IPO** | No price band; the company sets a single price (e.g., ₹150 per share) and everyone pays that amount. |
| **Price band & Cut‑off price** | Band = the allowed range (e.g., ₹100‑₹130). The cut‑off is the final price at which the issue gets allocated (e.g., ₹125). |

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/08/glossary.png)

---

## 5.7 – Recent IPOs in India  

Below is a quick‑look table of some of the hot IPOs that have hit the Indian market in the last couple of years. With the background you now have, reading this should feel like flipping through a sports scorecard.

| Company | Issue Size (₹ cr) | Price Band (₹) | Subscription (×) | Listing Date |
|---------|-------------------|----------------|------------------|--------------|
| **Zomato Ltd** | 5,000 | 70‑75 | 5.5× | 14 Jul 2021 |
| **Nykaa Ltd** | 2,000 | 2,850‑3,000 | 2.5× | 22 Oct 2021 |
| **Paytm (One97 Communications)** | 3,800 | 2,250‑2,350 | 3.9× | 27 Nov 2021 |
| **LIC Housing Finance** | 4,200 | 1,150‑1,250 | 3.2× | 28 Oct 2022 |
| **Reliance Industries (Jio Platforms)** | 20,000 | 1,500‑1,650 | 10× | 16 Aug 2021 |

*(Numbers are illustrative; always double‑check the prospectus for the exact figures.)*

---

### Key Take‑aways  

- **Why go public?** To raise capital, give early investors an exit, reward staff with ESOPs, and crank up brand visibility.  
- **Merchant banker** – The indispensable partner that steers the IPO from due‑diligence to roadshow.  
- **SEBI** – The ultimate gatekeeper; if they say “no”, the IPO stays in the basement.  
- **DRHP** – Your pre‑IPO bible. Read it like a detective reads a case file.  
- **Book‑building** – The most common price‑discovery method in India; it decides the final issue price.  

In the next chapter we’ll swing over to the **secondary market**, where the real roller‑coaster of buying, selling, and price swings begins. Grab your popcorn – the fun is just getting started!