# 2. Regulators, the Guardians of Capital Markets  

**Source:** <https://zerodha.com/varsity/chapter/regulators/>

---  

## 2.1 – What is the stock market?  

In the last chapter we convinced you that buying equities is the fastest way to beat inflation (unless you’ve discovered a time‑machine).  So, where do you actually go to buy those shiny pieces of paper‑ish ownership? Before we dive into the “how,” let’s first get a clear picture of the playground itself and the cast of characters that keep the swings moving.

Think of the stock market as the **super‑market of investments**.  
- When you need rice, you stroll down the aisle of your local kirana or the big‑box grocery store.  
- When you need a slice of a company’s future earnings, you stroll—well, *log in*—to the stock market and “shop” for shares.

**Transact** is the fancy finance word for “buy or sell.” In the equity world, it simply means you’re either picking up a share (buy) or handing it over to someone else (sell). The market’s job is to *match* you with the opposite party so the trade can happen smoothly, just like a cashier matching your grocery bag with the right price tag.

> **Pro tip:** The market isn’t a physical building with fluorescent lights and a coffee machine. It lives entirely in electrons and data‑centres. You access it from your laptop, phone, or that fancy smartwatch you only wear for the occasional “hey Siri, how’s my portfolio?” query.

To get inside this electronic bazaar you need a **registered intermediary** – a stockbroker. Think of a broker as the helpful shop‑assistant who knows where the best deals are, fetches the items you want, and makes sure the cashier (the exchange) rings everything up correctly. We’ll meet the brokers in a later episode (spoiler: they’re not all wearing snazzy suits).

### The two big exchanges in India  

- **Bombay Stock Exchange (BSE)** – Born in 1875, it’s the grand‑dad of Indian exchanges (yes, it predates the Indian Railways).  
- **National Stock Exchange (NSE)** – Launched in 1992, the cool younger sibling that introduced electronic trading to India.

There used to be a whole family of regional exchanges—Bangalore Stock Exchange (BgSE), Madras Stock Exchange (MSE), Calcutta Stock Exchange (CSE), and a handful of others. They either merged into BSE/NSE or shut their doors for good. So when you hear “the Indian stock market,” it’s usually a shorthand for **either BSE or NSE**.

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/07/Ch2-title.jpg)

---

## 2.2 – Market Participants and the Need to Regulate Them  

If the stock market were a party, **everyone** would be invited: individuals, corporations, foreign investors, and even your aunt who thinks “mutual funds” are a type of yoga. Anyone who buys or sells a security is called a **market participant**. Let’s break the crowd down into bite‑size groups so you can spot who’s who on the dance floor.

| Category | Who they are | Example |
|----------|--------------|---------|
| **Domestic Retail Participants** | Everyday folks like you, me, and the cousin who trades on a whim after watching a finance meme. | You buying 10 shares of Reliance. |
| **NRIs & OCIs** | Indians living abroad (Non‑Resident Indians) or persons of Indian origin who hold Overseas Citizenship of India. | An NRI in Singapore buying Infosys shares. |
| **Domestic Institutions** | Indian corporations, banks, and other big‑ticket entities that trade for business reasons. | Tata Motors buying back its own stock. |
| **Domestic Asset Management Companies (AMC)** | Mutual‑fund houses that pool money from investors and invest it on their behalf. | SBI Mutual Fund, HDFC AMC, ICICI Prudential. |
| **Foreign Institutional Investors (FII)** | Overseas funds, hedge funds, sovereign wealth funds, and the like that throw money into Indian equities. | A US‑based hedge fund snapping up shares of ITC. |

*Yes, the original list repeated a few lines—just like that one friend who keeps telling the same joke at every party. We’ve cleaned it up for you.*

### Why the “Regulation” part matters  

All of these participants share the same **core agenda**: make money. When cash is on the line, human emotions—greed, fear, hope, panic—turn up the volume. The result? Some people start playing fast‑and‑loose, while others might try to **cheat** the system.

India has seen its share of shady shenanigans: **pump‑and‑dump** schemes, insider trading, and the infamous **Satyam scandal** where a tech firm cooked its books (think of it as a corporate version of “who stole my cookies”). Because of these mis‑adventures, the market needs a **referee**—someone who writes the rulebook, blows the whistle, and makes sure nobody scores a goal with their hands.

Regulation and compliance are the **level‑playing‑field** tools that keep the market honest, protect small investors, and prevent the big‑fish from swallowing the pond whole.

---

## 2.3 – The Regulator  

Enter **SEBI** – the **Securities and Exchange Board of India**. Think of SEBI as the superhero squad that patrols the financial streets of India, complete with a cape (metaphorically) and a very long list of powers:

| What SEBI Does | Why It Matters |
|----------------|----------------|
| **Ensures exchanges run fairly** | Prevents the BSE/NSE from favoring one broker over another, like a bartender giving you a free drink every time you order a beer. |
| **Keeps stockbrokers honest** | Stops brokers from “selling you a horse for the price of a donkey.” |
| **Stops market participants from cheating** | Bans insider trading, pump‑and‑dump, and other “dirty tricks.” |
| **Keeps corporates from misusing the market** | Stops companies from inflating earnings or issuing misleading announcements (remember Satyam?). |
| **Protects small investors** | Guarantees that the little guy gets the same information and safety nets as the big guy. |
| **Stops the mega‑cash whales from manipulating prices** | Monitors large block trades and curbs “price rigging” that could otherwise crash markets. |
| **Fosters overall market development** | Encourages new products, better tech, and greater transparency. |

(Yes, the original bullet list duplicated itself—our version is tidy, like a freshly cleaned kitchen counter.)

Because SEBI has **so many hats**, it must regulate **every entity** that touches the market: exchanges, brokers, mutual funds, depositories, clearing corporations, and even the companies that list their shares. If any one of these players steps out of line, the whole ecosystem can wobble, much like a Jenga tower after a careless pull.

### The rulebook  

SEBI publishes a **Legal Framework** on its website, detailing the specific statutes each participant must obey. Think of it as the “terms and conditions” you click “agree” to—except here, ignoring them can get you fined, barred, or sent to court (no “undo” button).

We’ll dive deeper into the nitty‑gritty of brokers, depositories, and other intermediaries in the next chapter. Spoiler alert: you’ll learn why a “demat account” is like a digital locker for your shares, not a fancy new app for ordering pizza.

---

### Key takeaways from this chapter  

- The **stock market** is the electronic marketplace where you buy and sell equity slices.  
- Access is **digital** and comes through a **registered stockbroker** (your friendly market‑assistant).  
- A colorful crowd of **market participants**—retail investors, NRIs, institutions, AMCs, and foreign funds—trade daily.  
- **Regulation** is essential; without it, greed and fear would turn the market into a free‑for‑all.  
- **SEBI** is the **guardian** that writes the rulebook, watches over exchanges, brokers, corporates, and investors, and steps in when someone tries to cheat.  
- Remember: SEBI has its eyes on the market 24/7. If you try to pull a fast one, they’ll probably flag you faster than your mom spotting a missing sock.  

Now that you know who’s running the show, you’re ready to step onto the floor with confidence—just keep an eye on the referee!