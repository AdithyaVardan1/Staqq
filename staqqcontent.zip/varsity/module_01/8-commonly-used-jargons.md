# 8. Commonly Used Jargons  

**Source:** https://zerodha.com/varsity/chapter/commonly-used-jargons/  

---  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/08/Ch-8-title.jpg)  

This chapter is your “cheat‑sheet for market‑speak” – the buzzwords you’ll hear on trading floors, in Discord groups, and when your uncle tries to sound sophisticated at family dinners. Grab a coffee (or a cocktail) and let’s decode them, one witty bite at a time.  

---  

## Bull Market (Bullish)  

If you think a stock’s price is about to go on a joy‑ride upward, you’re **bullish** on it. On a macro level, when the major indices (Nifty, Sensex, etc.) keep climbing over a stretch of time, the whole market is said to be in a **bull market**.  

*Example:* “From mid‑2020 to early‑2022 the market was bullish – it was basically a runway for rockets, not a roller‑coaster.”  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/08/glossary.png)  

---  

## Bear Market (Bearish)  

Flip the coin: when you expect prices to tumble, you’re **bearish**. A **bear market** is what we call a prolonged dip in the index – think of it as the market taking a nap on the floor.  

*Example:* “Early‑2008 to late‑2009 was a classic bear market; the indices were basically on a diet.”  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/08/glossary.png)  

---  

## Trend  

“Trend” is the market’s mood‑swing. If prices are sprinting down, the trend is **bearish**; if they’re marching up, it’s **bullish**. When the market just yawns and stays flat, we call it a **sideways** or **range‑bound** trend.  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/08/glossary.png)  

---  

## Face Value of a Stock  

The **face value (FV)** – also called *par value* – is the nominal amount stamped on each share when it’s issued. It matters when companies do corporate actions (dividends, splits, bonuses).  

*Example:* Infosys has an FV of **₹5**. If it declares a dividend of **₹63 per share**, the dividend payout works out to **63 ÷ 5 = 12.6 → 1260 %** of the face value. (Yes, 1260 % – not a typo; it’s a percentage of the nominal ₹5, not the market price.)  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/08/glossary.png)  

---  

## 52‑Week High / Low  

- **52‑week high:** the highest price a stock has traded in the last 365 days.  
- **52‑week low:** the lowest price in the same period.  

These two numbers give you a quick sense of the stock’s yearly “comfort zone”. Many traders treat a breakout above the 52‑week high as a bullish signal, and a dip below the 52‑week low as a bearish omen.  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/08/glossary.png)  

---  

## All‑Time High / Low  

Same idea as the 52‑week range, but now we’re talking about the **entire history** of the security since its IPO. The **all‑time high** is the record peak ever, and the **all‑time low** is the record trough.  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/08/glossary.png)  

---  

## Upper and Lower Circuit  

Exchanges slap a **price band** on every security each trading day to curb wild swings.  
- **Upper circuit:** the ceiling (e.g., +2 %, +5 %, +10 % or +20 % from the previous close).  
- **Lower circuit:** the floor (the same percentage drop).  

If a stock hits its circuit, trading is paused for a bit to let nerves settle. Derivatives have their own, often tighter, limits.  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/08/glossary.png)  

---  

## Long Position  

“Going **long**” simply means you own (or intend to own) the asset, hoping its price will rise. Buy a share, hold it, and smile when it climbs.  

*Examples:*  
- Buying Biocon shares → you’re **long Biocon**.  
- Buying the Nifty index expecting a rally → you have a **long Nifty**.  

Long = bullish.  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/08/glossary.png)  

---  

## Short Position  

Shorting is the market’s equivalent of “selling a sandwich you haven’t baked yet”. It sounds weird, so here’s a story that (hopefully) makes it click.  

> **The Mi 3 Phone Saga (circa 2014)**  
> 
> I registered for Xiaomi’s exclusive Mi 3 launch on Flipkart, priced at **₹14,000**. My buddy Rajesh missed the deadline, so he begged me to sell him the phone for **₹16,500**. I obliged, pocketed the cash, and then thought, “Whoa, I just sold a phone I don’t own!”  
> 
> The next day the phone was still **₹14,000** on Flipkart. I bought it, handed it over to Rajesh, and walked away with **₹2,500** profit (₹16,500 – ₹14,000).  
> 
> In market‑speak, that’s a **short trade**: sell first, buy later at a lower price.  

In stocks, it works the same way. Suppose Wipro trades at **₹425** today and you think it will slide back to **₹405**. You **sell** (short) at ₹425, wait, then **buy back** at ₹405, pocketing the ₹20 difference per share.  

A few housekeeping notes:  

- In the cash (spot) market, you must **square‑off** the short before the market closes – it’s an intraday‑only game.  
- In the derivatives arena you can keep a short position open for days, but that’s a whole other chapter.  

**Bottom line:**  
- Short = bearish view.  
- Profit when price falls; lose when it rises.  
- In cash‑segment, close the short before the bell rings.  
- Click “Sell” to initiate; click “Buy” later to close.  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/08/glossary.png)  

---  

## Square Off  

**Square‑off** = “I’m done with this trade, let’s close it.”  

- If you’re **long**, squaring off means **selling** the shares you own. This isn’t a new short – it’s just the exit leg of your long position.  
- If you’re **short**, squaring off means **buying** the shares back to cover your earlier sale. Again, you’re not turning bullish; you’re simply closing the book.  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/08/glossary.png)  

---  

## Intraday Position  

An **intraday** trade is one you intend to open **and** close within the same trading session. All cash‑market shorts fall under this bucket, because the exchange forces you to square‑off before the close.  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/08/glossary.png)  

---  

## OHLC  

OHLC stands for **Open, High, Low, Close** – the four‑point snapshot of a day’s price action.  

- **Open:** price at the start of the session.  
- **High:** highest price reached that day.  
- **Low:** lowest price reached that day.  
- **Close:** price at the end of the session.  

*Example:* ACC on 17 June: Open = 1486, High = 1511, Low = 1467, Close = 1499.  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/08/glossary.png)  

---  

## Volume  

**Volume** is the total number of shares that changed hands during a session (buy + sell). It’s the market’s “cheering crowd” – the louder the volume, the more conviction behind the price move.  

*Example:* ACC on 17 June saw **5,33,819** shares traded.  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/08/glossary.png)  

---  

## Market Segment  

A **market segment** groups financial instruments that share similar risk‑reward characteristics. Indian exchanges currently run four main segments:  

1. **Capital Market (CM)** – Stocks, ETFs, and the spot‑cash market. Buying or shorting a share lives here.  
2. **Futures and Options (FO)** – The equity‑derivative playground where you can lever up, go long or short, and hold positions overnight.  
3. **Currency Derivatives (CDS)** – Futures and options on currency pairs (USD/INR, EUR/INR, JPY/INR, etc.).  
4. **Wholesale Debt Market (WDM)** – Fixed‑income instruments: government bonds, treasury bills, corporate bonds, debentures, and the like.  

These segments are like the different rooms at a party: each has its own vibe, dress code, and conversation topics.  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/08/glossary.png)  

---  

## TL;DR (Long & Short Recap)  

- **Long** = buy first, sell later → bullish outlook.  
- **Short** = sell first, buy later → bearish outlook (intraday in cash market).  
- **Square off** = close whatever position you have, without changing your market view.  
- **Intraday** = open and close the same day.  

---  

That’s a whirlwind tour of the market lingo you’ll bump into on charts, newsfeeds, and that chat group where everyone’s shouting “buy the dip!” Feel free to drop any other puzzling terms in the comments; I’ll decode them faster than you can say “margin call.” Happy trading!  