# 6. The Stock Markets  

**Source:** https://zerodha.com/varsity/chapter/the-stock-markets/  

---  

## 6.1 – Public Limited Company  

Now that you’ve survived the roller‑coaster of IPOs and know why a firm might decide to sell a slice of itself to the public, it’s time to stroll into the real party: the stock market.  

When a company goes “public,” it basically says, “Hey world, I’m an open book now. Bring your questions (and your money).” That means every quarter it has to spill the beans – earnings, board changes, whether the CEO finally got a haircut, everything. Its shares start bouncing around on the exchange every trading day, and a whole ecosystem of characters (retail investors, hedge funds, algorithmic bots, your neighbour’s cousin who thinks he’s a day‑trader) start buying and selling for their own reasons. In this chapter we’ll unpack why people actually bother to trade stocks, and why those reasons matter.  

---  

## 6.2 – What Is the Stock Market?  

Think of the stock market as a giant, ultra‑fast e‑bay for company slices. Buyers and sellers shout their opinions into the void (well, into a computer network) and the exchange matches the loudest “I want to buy at ₹3,000” with the loudest “I’ll sell at ₹3,000.”  

**Mini‑drama:**  
Infosys, the Indian IT heavyweight, is currently dealing with a leadership vacuum – several senior execs are exiting, and the board is scrambling for a new CEO. The market got jittery and the share price slid from ₹3,500 to ₹3,000.  

Enter two traders:  

* **Trader A** looks at the news and thinks, “Yikes, a new boss is hard to find. The stock will keep tumbling.” A’s logical move = **sell**.  

* **Trader B** sees the same headline and says, “The market overreacted. A great CEO will show up, and the price will rebound.” B’s logical move = **buy**.  

At ₹3,000, A becomes the seller, B the buyer. Both fire off orders through their brokers, the brokers push the orders to the exchange, and the exchange does its magic, pairing them up. That pairing – that “match‑making” – is the core job of a stock market: it lets opposite‑sided opinions find each other and turn into actual trades.  

In short, a stock market is a digital arena where anyone can take a stance on any listed company – *as long as there’s someone on the other side of the trade.* Different opinions = a lively market.  

---  

## 6.3 – What Moves the Stock?  

Let’s keep riding the Infosys saga to see what actually makes a price wiggle.  

### 10:00 AM – Good news arrives  
Infosys announces it has finally hired a new CEO who “will steer the ship to greater heights.”  

**Question 1:** What happens to the price?  
**Answer:** Positive news = buying pressure. Traders who were short (like A) start scrambling to cover, while bullish folks (like B) pile in. The price ticks up.  

In a bullish snap, buyers are happy to meet any seller’s price, so the market climbs. In our little demo, the price jumps ₹16 in five minutes – a tiny but realistic move that illustrates the “good‑news‑drives‑price‑up” rule.  

**Why does it rise?** Two reasons: (1) the leadership vacuum is filled, and (2) the market expects the new CEO to deliver strong performance.  

**Your move?** Buy, because the news is good.  

### 12:30 PM – Industry‑wide gloom  
A few hours later, NASSCOM (the Indian IT trade body) warns that the sector’s IT spend is expected to shrink by 15 %. That’s a pretty ominous cloud over every IT stock.  

**Question 2:** How does this affect Infosys?  
**Answer:** Mixed feelings. The earlier CEO‑news was upbeat, but a 15 % cut in revenue prospects is serious. Most traders will start selling, pushing the price down.  

If you were to act at the new price of ₹3,030, the sensible play is **sell**.  

**Question 3:** What about the rest of the IT crowd?  
**Answer:** The same selling pressure spreads to peers (TCS, Wipro, etc.) because the macro‑signal hits the whole industry, not just Infosys.  

So, news (company‑specific or sector‑wide) feeds the market’s emotion engine, which in turn moves the price.  

### No News? No Problem.  

What if the ticker is just sitting there with no headlines?  

* **Reliance Industries Ltd.** – Even without a fresh announcement, the sheer size, liquidity, and constant speculation keep the share price bouncing every second.  

* **Shree Lakshmi Sugar Mills** – A relatively obscure name with little analyst coverage may sit still for days unless a surprise event (say, a sugar price surge) jolts it.  

Bottom line: Prices move because *expectations* move. Those expectations can be sparked by company news, industry data, macro‑economic events (e.g., a new prime minister), or simply the tug‑of‑war between buyers and sellers.  

---  

## 6.4 – How Does a Stock Get Traded?  

Imagine you’ve decided to buy **200 shares of Infosys at ₹3,030** and hold them for a year. How does the magic happen?  

1. **Log in** to your broker’s trading platform (the digital front‑door to the exchange).  
2. **Enter the order** – you tell the system:  
   * “Buy 200 shares”  
   * “Price = ₹3,030 (or market price, if you’re impatient)”  
3. **Broker checks your cash** – if you have enough rupees, the order is green‑lit; if not, you get a polite “Insufficient funds” bounce.  
4. **Order hits the exchange** – the exchange’s matching engine looks for a seller willing to part with 200 shares at ₹3,030. The seller could be a single entity, or a mash‑up of many little sellers; the engine doesn’t care, it just cares that the total matches.  
5. **Trade execution** – once a match is found, the transaction is confirmed.  
6. **Dematerialisation** – the 200 shares are instantly credited to your **DEMAT** account, while the seller’s DEMAT account is debited. No paper certificates, just bits and bytes.  

All of this happens in a blink (often sub‑second), giving you the illusion that you’ve “bought” the stock the instant you clicked “Buy.”  

---  

## 6.5 – What Happens After You Own Stock?  

Your shares now sit snugly in your DEMAT account, and you’ve officially become a tiny part‑owner of Infosys. With 200 shares you own roughly **0.000035 %** of the company (yes, that’s a *lot* of zeros).  

Being a shareholder comes with a few perks:  

* **Dividends** – cash payouts when the board decides the company has excess cash.  
* **Stock splits** – more shares, same total value (your slice gets thinner but you get more pieces).  
* **Bonuses / Rights issues** – extra shares offered at a discount, often to reward loyal owners.  
* **Voting rights** – you can cast a vote at the AGM (usually “yes” or “no” on big decisions).  

We’ll dive deeper into each of those goodies later, but for now, enjoy the feeling of being part‑owner of a ₹15‑lakh‑crore behemoth.  

---  

## 6.6 – A Note on the Holding Period  

“How long should I keep a stock?” you ask. The answer: **anywhere from a few seconds to forever.**  

Warren Buffett famously says his favorite holding period is “forever.” Meanwhile, a high‑frequency trader might own a share for a nanosecond.  

Recall our earlier example: Infosys jumped from ₹3,000 to ₹3,016 in just five minutes – that’s a **0.53 %** gain in a coffee‑break. If you liked that little pop, you could close the trade and hunt for the next opportunity.  

In real markets, such short‑term spikes happen all the time when news hits or when a large order walks the order book. So don’t feel guilty if your “holding period” is measured in minutes; it’s a legitimate strategy as long as you understand the risk.  

---  

## 6.7 – How to Calculate Returns?  

All the excitement in the market boils down to one number you love to brag about: **the rate of return**.  

### 1️⃣ Absolute Return  
This is the simple “what‑did‑I‑make‑in‑percentage” for a given trade.  

*Buy @ ₹3,030, sell @ ₹3,550*  

\[
\text{Absolute Return} = \Big(\frac{3,550}{3,030} - 1\Big) \times 100 = 17.16\%
\]  

A 17 % gain in a few months feels like a victory dance, right?  

### 2️⃣ Compounded Annual Growth Rate (CAGR)  
When you compare investments over different time‑frames, absolute return can be misleading. CAGR normalises the growth to an annual rate.  

Formula:  

\[
\text{CAGR} = \bigg(\frac{\text{Ending Value}}{\text{Beginning Value}}\bigg)^{\frac{1}{n}} - 1
\]  

where **n** = number of years.  

*Example:* Bought at ₹3,030, held for **2 years**, sold at ₹3,550.  

\[
\text{CAGR} = \bigg(\frac{3,550}{3,030}\bigg)^{\frac{1}{2}} - 1 = 8.2\%
\]  

That 8.2 % annualised growth beats a typical bank Fixed Deposit (≈5.5 % today) while still protecting your capital.  

**When to use which?**  

* **Absolute return** – when the holding period is ≤ 1 year (or you just want a quick snapshot).  
* **CAGR** – when you’re looking at multi‑year performance, or comparing two investments with different horizons.  

*Bonus tip:* If you made that 17.16 % gain in **six months**, double‑it (≈34 % annualised) to see how impressive it looks on a yearly basis.  

---  

## 6.8 – Where Do You Fit In?  

Every market participant falls somewhere on a spectrum defined by **time horizon** and **risk appetite**. Broadly you’re either a **trader** (short‑term, active) or an **investor** (long‑term, patient).  

### The Trader’s Playground  

A trader spots a price inefficiency, jumps in, and exits as soon as the profit target or stop‑loss hits. They’re constantly glued to the screen, ready to react to any news tick.  

Common trader archetypes:  

| Type | Typical Holding | Example Play | Personality |
|------|----------------|--------------|-------------|
| **Day Trader** | Intraday (open‑close) | Buy 100 TCS @ ₹2,212 at 9:15 am, sell @ ₹2,220 at 3:20 pm → ₹800 profit | “I don’t like overnight risk; I’m basically a caffeine‑powered squirrel.” |
| **Scalper** (a sub‑type of day trader) | Seconds‑to‑minutes | Buy 10,000 TCS @ ₹2,212, sell @ ₹2,212.10 a minute later → ₹1,000 profit | “Speed is my middle name; I love tiny, quick wins.” |
| **Swing Trader** | Days‑to‑weeks | Buy 100 TCS @ ₹2,212 on June 12, sell @ ₹2,214 on June 19 → ₹200 profit | “I ride short‑term trends, like a surfer on a wave that lasts a week.” |

Famous traders you might have heard of: George Soros, Ed Seykota, Paul Tudor, Michael Steinhardt, Van K. Tharp, Stanley Druckenmiller, and the late Rakesh Jhunjhunwala.  

### The Investor’s Lounge  

An investor buys with the expectation that the company’s intrinsic value will rise over years. Patience is the key ingredient.  

Two main investor styles:  

| Type | Goal | Classic Indian Example |
|------|------|------------------------|
| **Growth Investor** | Find companies poised for massive expansion (new markets, disruptive tech) | Buying Hindustan Unilever, Infosys, or Gillette India in the early‑90s and watching them explode. |
| **Value Investor** | Hunt for solid businesses that are temporarily cheap (often after a market panic) | Picking up beaten‑down blue‑chips during the March 2020 Covid crash, then riding the V‑shaped recovery. |

Legendary investors you might aspire to emulate: Charlie Munger, Peter Lynch, Benjamin Graham, Thomas Rowe, Warren Buffett, John C. Bogle, Sir John Templeton, Mohnish Pabrai.  

**So, what’s your flavor?** Do you prefer the adrenaline rush of a 5‑minute scalp, or the calm satisfaction of watching a company grow for decades? The market has room for both, and for everyone in between.  

---  

### Key Takeaways  

- A **stock market** is a digital arena where buyers and sellers meet, match, and trade shares.  
- Different **opinions** (bullish vs. bearish) create the market’s liquidity.  
- **News, events, and expectations** are the primary drivers of price movements.  
- Even without news, **supply‑demand imbalances** keep prices wiggling, especially for heavily traded giants like Reliance.  
- Once you own a share, you’re entitled to **dividends, voting rights, bonuses, splits, and rights issues**.  
- **Holding period** can be as short as a few seconds or as long as forever – choose what suits your style.  
- Use **Absolute Return** for ≤ 1‑year horizons; use **CAGR** to compare multi‑year performance.  
- **Traders** chase short‑term moves (day‑trading, scalping, swing‑trading); **Investors** look for long‑term appreciation (growth or value).  

Pick your lane, keep learning, and remember: the market is a giant, noisy cocktail party – you’re just one guest with a drink, trying to make the best conversation (or trade) you can. Cheers!  