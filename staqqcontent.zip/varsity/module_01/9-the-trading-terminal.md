# 9. The Trading Terminal  

**Source:** <https://zerodha.com/varsity/chapter/the-trading-terminal/>

---  

## 9.1 – Trading Terminal  

After binge‑studying the previous chapters you’ve probably become a mini‑stock‑market guru (or at least you can recite the difference between a bull and a bear without looking it up). Now it’s time to find out *how* you actually get your hands on those shiny pieces of paper (or, you know, digital equivalents).  

You have three ways to shout “I want this stock, give it to me!” to the market:  

- **Call & Trade** – Pick up the phone, dial your broker’s central support line, and tell a human you’d like to buy or sell. Think of it as the “old‑school” Tinder swipe, but for stocks.  
- **Web application** – Log in on a browser and click‑click‑click.  
- **Mobile application** – Do the same thing on your phone, because who doesn’t love checking their portfolio while waiting for coffee?  

Whichever route you choose, you’re essentially opening a *gateway* to the market. This gateway lets you:  

- Execute trades (buy/sell)  
- Keep tabs on your profit‑and‑loss (P&L)  
- Watch market movements in real time  
- Manage cash and margin  
- Pull up charts that look like modern art  
- Play with a toolbox of order‑types and indicators  

All of that lives inside what we call a **trading terminal**. In this tutorial I’ll walk you through Zerodha’s terminal, **Kite**. If you’re with a different broker, the UI might have a different haircut, but the core muscles are the same.  

---  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/09/Ch-9-title.jpg)  

You can launch the terminal by typing its URL into any browser. For Kite it’s `kite.zerodha.com`. Of course you need a live trading account with the broker first—no account, no party. A good terminal is like a Swiss Army knife: it does a bit of everything, and it looks slick while doing it.  

Let’s set two simple, beginner‑friendly missions and solve them live in the terminal:  

1. **Buy one share of ITC**  
2. **Keep an eye on the price of Infosys**  

By the time we’ve nailed those, you’ll have touched on most of the day‑to‑day features a trader uses.  

---  

## 9.2 – The login process  

Your trading terminal is the digital vault that stores every share you own, every rupee you have, and every secret wish you’ve ever whispered to the market. Because of that, the regulator SEBI (the market’s version of a nosy neighbour) has forced brokers to lock it down tighter than Fort Knox.  

The login dance goes like this:  

1. **Enter your broker‑provided User ID** – In Kite it’s called the **Kite ID**.  
2. **Enter your password** – Pick something you can remember but hackers can’t guess (no “password123”).  
3. **Enter a TOTP** – That’s a **T**ime‑based **O**ne‑Time **P**assword. It changes every 30 seconds, like a digital mood ring. You generate it with Google Authenticator, Authy, or any other 2FA app.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2022/11/M1C9_loginupdated-300x162.png)  

Once the TOTP checks out, you’re in. If you’re curious about why the extra step exists, read the linked article on TOTP security (hint: it’s to keep your hard‑earned money from getting pilfered).  

---  

## 9.3 – The Market watch  

After you’ve successfully logged in, the first thing you’ll see is a blank slate called the **Market Watch**. Think of it as a whiteboard where you can stick sticky notes for the stocks you care about.  

Here’s the empty view you get right after login:  

![Image](https://zerodha.com/varsity/wp-content/uploads/2014/09/Screenshot_127-1-1024x499.png)  

The numbers under **Equity** (₹600.2) and **Commodities** (₹136.75) are your cash balances. In other words, you have ₹600.20 ready to buy shares and ₹136.75 for commodities like gold or crude oil. You can top up or withdraw funds by clicking the **Funds** tab at the top.  

### Step 1: Add ITC to the watchlist  

1. Click the search bar and type **ITC**.  
2. A dropdown shows the same ticker on different exchanges (NSE, BSE). Make sure you pick the plain‑vanilla **ITC**—the ones with extra letters (ITC‑BE, ITC‑BL, etc.) are different instruments, like flavors of ice‑cream you haven’t tried yet.  
3. Hit **Add Symbol**.  

Your watchlist now shows something like this:  

![Image](https://zerodha.com/varsity/wp-content/uploads/2014/09/Screenshot_7-1-300x149.png)  

- **LTP (Last Traded Price)** – The price at which the most recent trade happened.  
- **% Change** – How the LTP compares to yesterday’s close, expressed as a percentage.  

A few other handy data points you’ll see when you hover over the ticker:  

- **Previous Close** – Yesterday’s final price.  
- **OHLC** – Open, High, Low, Close for the current session (you already met these in an earlier chapter).  
- **Volume** – How many shares have changed hands so far today.  

All of these sit under the **Market Depth** window. Hover over the stock name, click **Market Depth**, and you’ll see a ladder of bid and ask prices plus the stats above.  

Here’s a screenshot of the depth for ITC:  

![Image](https://zerodha.com/varsity/wp-content/uploads/2014/09/Screenshot_131-268x300.png)  

At the time of writing, ITC’s LTP is **₹262.25**, down **0.40 %** from the previous close of **₹263.30**. The day’s **Open** was **₹265.90**, the **High** **₹265.90**, the **Low** **₹262.15**, and the **Volume** hovers around **2.7 million** shares.  

---  

## 9.4 – Buying stock through the trading terminal  

Now that ITC is chilling on your watchlist, let’s actually buy a share.  

1. **Hover over ITC** and click the **Buy** icon (the big “B”).  
2. The **Buy Order Form** pops up, pre‑filled with the current price and a default quantity of 1.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2014/09/Screenshot_133.png)  

### Tweak the order form  

- **Exchange** – Default is NSE; you can switch to BSE if you prefer the other playground.  
- **Order Type** – Click the dropdown; you’ll see four choices:  

  1. **Limit** – You set the maximum price you’re willing to pay.  
  2. **Market** – You say “take whatever you’ve got right now.”  
  3. **SL (Stop‑Loss)** – You set a price at which the order becomes a market order to limit losses.  
  4. **SL‑Market** – A hybrid where the trigger is a stop‑loss but the execution is at market price.  

#### Limit order example  

Suppose ITC is at **₹262.25** but you only want to pay **₹261.00** (that’s 25 paisa cheaper). Choose **Limit**, type **261** in the price box, and you’re good. If the market never dips to ₹261, your order sits idle until the market closes at 3:30 PM, then it disappears.  

#### Market order example  

If you’re impatient (or you just trust the market to be fair) pick **Market**. Your order will be filled at the best available ask price(s). If the best ask at that instant is **₹262.30**, you’ll pay that; if it jumps to **₹265** by the time the order reaches the exchange, you’ll pay **₹265**. Market orders guarantee execution but not price.  

#### Stop‑Loss (SL) order example  

You buy ITC at **₹262.25** expecting it to climb to **₹275**. If it instead slides, you might want to cut your losses at **₹255**. Set the **SL** price to **₹255**; once the market price hits that level, the order becomes a market order and you’re out.  

- **Trigger price** – Usually equal to or higher than the SL price (for a buy‑side SL). It’s the price that tells the system “hey, start the SL now.”  

### Other fields  

- **Quantity** – Type **1** because we only want a single share.  
- **Product type** –  

  - **CNC** (Cash‑and‑Carry) for delivery (shares sit in your DEMAT).  
  - **MIS** (Margin Intraday Square‑off) for intraday trades that you’ll close before the market ends.  

When you’re happy with all the inputs, hit **Submit**. The system spits out a unique **order ticket number** and sends the order to the exchange. If the price ever reaches your limit (₹261), you’ll be the proud owner of a single ITC share.  

---  

## 9.5 – The order book and Trade book  

Think of the **Order Book** as your shopping cart on an e‑commerce site, and the **Trade Book** as the receipt you get after you click “Buy.”  

- **Order Book** – Lists every order you’ve sent (pending, partially filled, completed, or rejected).  
- **Trade Book** – Shows the trades that actually executed, complete with execution price and quantity.  

You can reach the Order Book by clicking the **Orders** tab:  

![Image](https://zerodha.com/varsity/wp-content/uploads/2014/09/Screenshot_134-1024x503.png)  

In the Order Book you can:  

- **Double‑check** the details (price, quantity, order‑type, product).  
- **Modify** an open order (e.g., change the limit from ₹261 to ₹259).  
- **Cancel** an order that you no longer want.  
- **Monitor status** –  

  - **Open** = still waiting to be filled (or partially filled).  
  - **Completed** = fully executed.  
  - **Rejected** = exchange didn’t like it; hover for the reason.  

If you hover over an open order you’ll see **Modify** and **Cancel** icons:  

![Image](https://zerodha.com/varsity/wp-content/uploads/2014/09/Screenshot_137.png)  

Click **Modify** and the order form re‑appears, letting you tweak the price or quantity.  

Once the exchange fills the order, the trade shows up in the **Trade Book**, located just below the Order Book:  

![Image](https://zerodha.com/varsity/wp-content/uploads/2014/09/Screenshot_138.png)  

Notice the unique **exchange order number** – that’s the official proof that you bought one ITC share at **₹262.20** (or whatever the final price was). Congrats, you now own a piece of an Indian conglomerate!  

---  

## 9.6 – The Bid and Offer Price  

When you buy, you’re taking the **offer** (also called **ask**) price from a seller. When you sell, you’re taking the **bid** price from a buyer. In Kite the **offer** is highlighted in **red**, the **bid** in **blue**.  

By default the **Market Depth** window shows the top 5 levels on each side. Here’s a quick look at the ask side for a hypothetical stock:  

| Offer Price (₹) | Qty | Offer Price (₹) | Qty |
|----------------|-----|----------------|-----|
| 3294.80 | 2 | 3295.00 | 8 |
| 3294.85 | 4 | 3295.05 | 5 |
| … | … | … | … |

- The **best offer** (lowest ask) is **₹3294.80** for 2 shares.  
- The next best is **₹3294.85** for 4 shares, and so on.  

If you place a **market order** for 10 shares, the engine will eat through the ladder:  

1. 2 shares @ ₹3294.80  
2. 4 shares @ ₹3294.85  
3. 4 shares @ ₹3295.00  

Your average price becomes a blend of those three levels, and the LTP (last traded price) will jump to the last price you actually bought at (₹3295.00).  

On the **bid** side (the buyers), the best price you can sell into is the highest bid, shown in blue. Example:  

| Bid Price (₹) | Qty |
|---------------|-----|
| 3294.75 | 10 |
| 3294.20 | 6 |
| 3294.15 | 1 |
| 3293.85 | 3 |

If you sell 20 shares at market price, you’ll fill the top levels until you’ve sold all 20:  

- 10 @ ₹3294.75  
- 6 @ ₹3294.20  
- 1 @ ₹3294.15  
- 3 @ ₹3293.85  

That’s why the bid‑ask spread (the gap between the best bid and best ask) matters: a tight spread means less slippage for market orders.  

You can expand the depth to the **top 20** levels by clicking the “20‑depth” button – handy when you’re trading high‑volume stocks or need to gauge market liquidity.  

---  

## 9.7 – Conclusion  

Your trading terminal is the front door to the bustling bazaar of Indian equities. It houses everything you need: watchlists, order entry, order & trade books, market depth, charts, and a few hidden Easter eggs for the curious.  

Over the next modules we’ll peel back more layers (advanced charting, derivatives, algo‑trading, etc.), but at this point you should be comfortable with:  

- Adding symbols to a market watch.  
- Reading LTP, % change, OHLC and volume.  
- Pulling up the **Buy** (B) and **Sell** (S) order forms.  
- Choosing between **Limit**, **Market**, **SL**, and **SL‑Market** order types.  
- Selecting **CNC** (delivery) vs **MIS** (intraday) product types.  
- Monitoring and modifying orders via the **Order Book**.  
- Verifying fills in the **Trade Book**.  
- Interpreting the bid‑offer ladder in **Market Depth**.  

The UI may get a facelift in a few years (maybe neon colors, maybe holograms), but the core concepts—order book, trade book, limit vs market, bid‑ask—are timeless.  

### Key takeaways from this chapter  

- A **trading terminal** is your market gateway; mastering its basics is essential for any active trader.  
- Load the stocks you care about onto a **Market Watch** to see live LTP, % change, OHLC, and volume.  
- Hit **B** to bring up a **Buy** order form; hit **S** for a **Sell** form.  
- Use a **Limit** order when you care about price; use a **Market** order when you care about getting filled.  
- Choose **CNC** for delivery (long‑term holding) and **MIS** for intraday margin trades.  
- The **Order Book** shows every order you’ve placed; you can modify or cancel open orders from there.  
- The **Trade Book** confirms what actually got executed, complete with exchange order numbers.  
- The **Market Depth** window displays the top‑5 (or top‑20) **Bid** (blue) and **Offer** (red) prices, helping you gauge liquidity and potential slippage.  

Now go forth, add a few tickers, place a couple of orders, and watch the numbers dance. And remember—if the market ever feels too serious, just imagine the stocks as tiny party guests who’ll either buy you a drink (bid) or ask you to buy them one (ask). Cheers!