# 10. Clearing and Settlement Process  

**Source:** <https://zerodha.com/varsity/chapter/clearing-and-settlement-process/>

---  

## 10.1 – Market structure  

Alright, picture this: you’ve just clicked “Buy 100 Marico shares” and the little digital *ka‑chink* tells you the order is in. What you *don’t* see is the backstage hustle that moves money from your pocket to the exchange and, a split‑second later, slides those shiny certificates into your Demat account.  

If you’ve never peeked behind the curtain, the whole clearing‑and‑settlement thing can feel like a magician’s trick—*now you see the shares, now you see the cash*. Miss a beat, and you might wonder why your cash is still on hold or why the shares haven’t shown up. That’s why we’re going to walk you through the exact sequence from the moment you press **Buy** to the moment the shares finally take up residence in your Demat “home”.  

We’ll keep it practical, jargon‑light, and peppered with jokes (because finance is *fun* when you’re not crying over fees).  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/09/Ch10title.jpg)

---

## 10.2 – What happens when you buy a stock?  

### Day 1 – The trade (T‑Day), Monday  

Suppose it’s a sunny Monday and you decide to buy **100 shares of Reliance Industries** at **₹1,000** each. Quick math:  

- **Trade value** = 100 × ₹1,000 = **₹1,00,000**  

The moment you hit *Buy*, your broker does a lightning‑fast “do‑you‑have‑the‑cash?” check. If you’ve got ₹1,00,000 (plus a few rupees for fees) sitting in your trading account, the order sails through; if not, you get the dreaded “insufficient funds” bounce‑back.  

Assuming you’re using Zerodha, the fee breakdown looks roughly like this (these are the rates as of the time of writing – they can change, so always double‑check the broker’s calculator):  

| Charge | Approx. % / amount | How it’s applied |
|--------|-------------------|------------------|
| Brokerage | 0 % (free for equity) | – |
| Securities Transaction Tax (STT) | 0.1 % of turnover (buy side) | ₹100 |
| Exchange Transaction Charge | ~0.0033 % | ₹3.30 |
| SEBI Turnover Charge | 0.0001 % (capped) | negligible |
| GST on charges | 18 % of total charges | ~₹21.60 |
| Stamp Duty | 0.015 % on buy side | **₹15.00** |
| **Total charges** | — | **≈ ₹119.19** |

So you need **₹1,00,119.19** *blocked* in your account. “Blocked” means the money is earmarked for this trade, but the shares haven’t yet jumped into your Demat wallet.  

On the same day the exchange spits out a **contract note** and shoots it to your registered email. Think of the contract note as your receipt‑like “hey, you just bought 100 Reliance at ₹1,000 each, here’s the fee breakup, here’s the trade reference”. Keep it; you’ll thank yourself when you need to prove anything later.  

### Day 2 – Trade + 1 (T+1), Tuesday  

India made headlines in **January 2023** by becoming the *first* country to go full‑tilt **T+1 settlement** for all listed securities. Before that, if you bought on Monday, you’d have to wait until **Wednesday** (T+2) to see the shares in your Demat. Now, the magic happens the *next* day.  

On **T+1** the following chain reaction unfolds:  

1. **Clearing corporation** pulls the ₹1,00,000 from *your* broker’s “client pool” account.  
2. The same amount gets deposited into the *seller’s* broker’s pool.  
3. Simultaneously, the 100 Reliance shares flow from the seller’s Demat, through the clearing house, and land in **your** Demat account.  

Result? By Tuesday, you can actually *see* those 100 Reliance shares under your holdings, and the seller’s cash sits safely in their broker’s account. Simple, right? (Well, there’s a lot of file‑swapping behind the scenes, but you don’t need to know the file names.)  

---

## 10.3 – What happens when you sell a stock?  

Selling is basically the mirror image of buying, but with a few quirky twists. The day you hit **Sell** is again called **T‑Day**. Here’s the play‑by‑play:  

1. **Block the shares** – As soon as you click Sell, the 100 Reliance shares in your Demat are *blocked* (think of a “Do Not Touch” sign). By the end of T‑Day, they’re earmarked for settlement.  
2. **Earmarking** – We’ll dive deeper in the next section, but for now, know that the shares are *reserved* for the buyer, not actually moved yet.  
3. **Settlement (T+1)** – On the next business day:  
   * The blocked shares are debited from your Demat and handed over to the clearing corporation.  
   * In exchange, the buyer’s broker’s pool account sends you the cash *minus* all applicable charges (STT on the sell side, brokerage, GST, etc.).  

A fun fact: **80 % of the sale proceeds hit your bank account on the same T‑Day**, while the remaining **20 % arrives on T+1**. This staggered credit is a legacy artifact, but the net effect is you’re fully settled by T+1 – just like the buyer.  

Between T and T+1, a flurry of data files flies between four players: your broker, the clearing corporation, the depository (NSDL or CDSL), and the stock exchange. They each upload their “I have the shares” or “I have the money” statements, reconcile, and then—*voilà*—the trade is settled.  

Bottom line for you, the everyday trader: **Equity trades settle on a T+1 basis**. If you’re buying, you get the shares tomorrow; if you’re selling, the money lands in your account tomorrow.  

---

## 10.4 – What is earmarking?  

Before November 2022, the settlement workflow looked a bit like a game of hot‑potato. When you sold shares, the broker would **debit** them from your Demat **immediately**, park them in the broker’s own “pool” account, and only later (on T+2) forward them to the clearing corporation.  

Why was that a problem? While those shares sat in the broker’s pool, they were technically *the broker’s* – a loophole that could be (and occasionally was) abused. Regulators (thanks, SEBI!) called this out as a risk to investors.  

Enter **earmarking**:  

- **Earmarking** = *“Put a sticky note on those shares saying ‘Do not touch, they belong to a pending sale’.”*  
- Instead of moving the shares out of your Demat on T‑Day, the broker simply flags them as **reserved** for the upcoming settlement.  
- On the actual settlement day (T+1), the shares are *then* transferred straight from your Demat to the clearing corporation.  

The advantage? No more “broker‑held” client securities, which eliminates the chance of the broker misusing them. It’s a tighter, safer system, and it’s now **mandatory** for all equity sells in India.  

---

### Key takeaways from this chapter  

- **T‑Day** = the day you place the order (buy or sell).  
- A **contract note** must land in your inbox by the end of T‑Day – it’s your official receipt.  
- **Buy side**: shares appear in your Demat **by T+1** (the next business day).  
- **Sell side**: shares are blocked instantly; cash (80 % today, 20 % tomorrow) lands in your bank **by T+1**.  
- All equity settlements in India now run on a **T+1** cycle (thanks, January 2023 reform).  
- **Earmarking** safeguards your securities by keeping them in your Demat until the moment they’re officially transferred, eliminating the broker’s old‑school “pool” holding.  

Now that you’ve got the backstage pass, go ahead and trade with confidence—knowing exactly where your money and shares travel on the grand tour of clearing and settlement. Cheers to smoother trades! 🍻