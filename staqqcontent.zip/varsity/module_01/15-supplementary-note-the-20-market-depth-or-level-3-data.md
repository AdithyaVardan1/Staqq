# 15. Supplementary note – The 20 market depth or level 3 data  

**Source:** <https://zerodha.com/varsity/chapter/supplementary-note-the-20-market-depth/>

---  

## The 20 Market Depth (level 3 data) Window  

Picture this: you’ve been driving the same old hatchback for years, and every time you “upgraded” you actually just slapped a new paint job on it. Then one day you get a slick sedan with a rear‑camera that actually *shows* the empty space behind you. Suddenly you’re no longer doing the classic “head‑out‑the‑window, wave‑your‑hands‑like‑a‑mad‑man” maneuver every time you try to parallel‑park. The camera does the heavy lifting, and you glide into the spot like a ballerina on roller‑skates.  

That rear‑camera is the **parking‑assist** of trading – the *level 3* or **20‑depth** market window. It hands you a panoramic view of the order book that most retail traders have never seen because, let’s be honest, it was hidden behind a wall of “institution‑only” doors until Zerodha decided to throw the keys to the kingdom to everyday folks.  

If you’ve ever spent a night on a trading floor staring at a sea of numbers that only showed you the best five bids and asks, you’ll understand why this is a game‑changer. The purpose of this note is to pull back the curtain, show you why the 20‑depth window is worth more than a weekend at a spa, and give you a few starter ideas on how to weave it into a strategy.  

If the term “level 3 data” still sounds like a secret government project, skim through this quick primer first: *[what is level 3 data?]*. Assuming you’re already in the know, keep reading – we’ll dive into the many ways this feature can make you feel like the Sherlock Holmes of order‑book sleuthing.

---

## Contract availability  

When you trade options, the biggest headache is often *liquidity*: “Are there enough contracts out there for me to get in and out without slashing my profit into oblivion?” The 20‑depth order book acts like an X‑ray, revealing the hidden piles of contracts that the ordinary depth (top‑5) keeps under the rug.  

Take the Nifty 13000 CE that expires in January 2020. The ordinary depth looks like this:  

![Image](https://zerodha.com/varsity/wp-content/uploads/2019/11/Image-11_opt-300x217.png)  

Only a thin line of bids on the left and a slightly better ask on the right. If you were eye‑balling a few lots, you might think, “Hmm, maybe I should stay away from this ghost town.”  

Now crank open the level 3 view:  

![Image](https://zerodha.com/varsity/wp-content/uploads/2019/11/image-12_opt.png)  

Boom! A whole trench of contracts appears, stacked well below the top‑5 rows. The bulk of the liquidity is lurking in the “8‑throw” zone (i.e., eight rows down from the best bid/ask). Suddenly the contract looks far less spooky – you can now gauge whether your strategy (buy‑the‑dip, sell‑the‑rally, or simply market‑make) has enough meat to chew on.  

The same principle applies to futures, especially those thin‑traded contracts that usually make you feel like you’re trying to sell a snow‑cone in a desert. The 20‑depth window just hands you the map to the hidden oasis.

---

## Execution control  

Scalping is the high‑octane sport of the trading world: you buy and sell huge blocks in a flash, hoping to pocket a few ticks of profit before anyone else blinks. Because the trades are lightning‑fast, most scalpers rely on **market orders** – you shout “BUY!” and hope the market hears you.  

But shouting into the void without knowing where the echo lands can be disastrous. Let’s walk through a real‑world example with Hindustan Zinc. You want to buy (and later sell) **5,000 shares**. The regular depth shows you only the top‑5 levels:  

![Image](https://zerodha.com/varsity/wp-content/uploads/2019/11/Image-1_-reg.png)  

You see a couple of price points, but no clue how the 5,000 shares will be sliced up. Will you end up paying 210.5 for 1,000 shares and 213 for the rest? Who knows.  

Open the 20‑depth window:  

![Image](https://zerodha.com/varsity/wp-content/uploads/2019/11/Image-2_20.png)  

Now you get a full menu: the order book from **210.5 – 211.25** is thick enough to swallow your entire order. At the 211‑price level alone, there are **2,425 shares** waiting to be bought, meaning the *average* fill price will hover around **211**.  

Armed with that intel, you can decide: “If I expect the price to pop to 211.5 or higher, I’m good; otherwise I’ll sit this one out.” And if you want exact breakeven after brokerage, just pop the numbers into a broker‑fee calculator – the math is the same, only now you actually know the *price* side of the equation.

---

## Position sizing  

Liquidity isn’t just about getting in; it’s about staying in long enough to let your idea breathe. The 20‑depth view is like a personal trainer for position sizing – it tells you how many reps (shares) you can realistically do without breaking the market’s back.  

Let’s say you’ve got a **Siemens** (ticker: SIE) trade in mind. You predict the stock will march from **1,675** to **1,690** over the next hour. Capital isn’t a constraint (maybe you’ve just won the lottery), so the question is: *how many shares should you actually buy?*  

**Regular depth:**  

![Image](https://zerodha.com/varsity/wp-content/uploads/2019/11/Image-3_sie.png)  

Looks like you could only scoop up about **175 shares** before you start eating into the ask side.  

**20‑depth:**  

![Image](https://zerodha.com/varsity/wp-content/uploads/2019/11/Image-4_sie20.png)  

Whoa, the hidden layers below the top five are brimming with liquidity. If you wanted **1,500 shares**, the book shows you can get them for an average price somewhere between **1,675.5 – 1,678**, a spread of only **0.149 %**. In other words, the impact cost is tiny, and you can go “all‑in” without fearing a price avalanche.  

So the 20‑depth view lets you size up aggressively (or conservatively) with confidence, turning a vague “I think I can buy a lot” into a data‑backed “I can buy *exactly* this many”.

---

## Order placement  

Now let’s take that sizing power a step further and talk **stop‑loss** and **target** placement. Suppose you’re long **VST Tillers** at **1,313.8**. Where do you set the safety net?  

First, glance at the regular depth:  

![Image](https://zerodha.com/varsity/wp-content/uploads/2019/11/Image-5_buy.png)  

It’s a decent snapshot, but it doesn’t reveal where the crowd of sellers is congregating below your entry.  

Pop open the 20‑depth for VST Tillers:  

![Image](https://zerodha.com/varsity/wp-content/uploads/2019/11/Image-6_vst.png)  

Notice the **cluster of bids around 1,290** – not only is the price level tight, but the *order count* spikes to **35**, the highest in that band. That’s the market’s collective “I think price will hover here” vote.  

A sensible trader would place the stop‑loss **just below** that cluster, say at **1,287** (giving a few ticks of breathing room). By the same token, the opposite side (where the offers pile up) suggests a logical target near **1,340** (or a tidy **1,338.8** for a round number).  

So the 20‑depth window becomes your personal GPS for risk management: it points out where the traffic is dense, letting you park your stop‑loss where the road is least likely to crash.

---

## Validate the support and resistance level  

The previous example hinted at a deeper truth: the **order‑book concentrations** often line up with **chart‑based support/resistance** zones. In the VST Tillers case, the heavy bid cluster at **1,290** hinted that the price would find a floor around there. Does the chart agree?  

Here’s the candlestick chart:  

![Image](https://zerodha.com/varsity/wp-content/uploads/2019/11/Image-7_vst-chart-1024x668.png)  

Sure enough, you can see a little price‑action drama around **1,296** – a handful of wicks touching that area, a couple of small reversals, the whole shebang. Remember, support and resistance are *zones*, not single numbers. So you can comfortably call **1,290 – 1,300** the intraday support zone for VST Tillers.  

The workflow is simple:  

1. **Identify** a potential S&R zone on your chart (via pivots, moving averages, or that gut feeling).  
2. **Flip** to the 20‑depth window and see if there’s a concentration of bids (for support) or offers (for resistance) in that range.  

If the two line up, you have a **high‑probability** area to set stops, targets, or even to place a new entry.  

---

## Bottom line  

By now you should be feeling the **immense value** that the 20‑depth order book adds to your trading toolbox. Whether you’re a technical analyst, a quantitative wizard, or a pure‑play “I just follow the price” trader, everything ultimately boils down to *price* and *how the market behaves at that price*.  

The 20‑depth window is essentially your **VIP pass** to verify whether the price action you see on a chart is backed by real‑world buying and selling pressure. Use it wisely, and you’ll avoid a lot of those “I thought the market would do X, but it did Y” moments.  

Got a creative way you plan to use the 20‑depth data? Drop a comment below – we love hearing about fresh strategies, quirky hacks, or even the funny mishaps that taught you a lesson.  

Good luck, and may the depth be ever in your favor!  