# 1. The Need to Invest  

**Source:** https://zerodha.com/varsity/chapter/the-need-to-invest/  

---  

## 1.1 – Why should I invest?  

Before we start throwing fancy graphs at you, let’s picture the “no‑invest” scenario. You pull in **₹50,000** a month, spend **₹30,000** on the usual suspects – rent, biryani, Uber, Netflix, doctor visits, the whole circus. That leaves you with a **₹20,000** surplus each month.  

> *We’ll ignore taxes here – because who reads the fine print when they’re thirsty for a good story?*  

### The “nice‑guy” assumptions  

- Your boss is a saint and bumps your salary by **10 %** every year.  
- The cost of living inflates at **8 %** per annum (because pizza doesn’t get cheaper).  
- You’re **30** today and plan to hang up your work shoes at **50** – that’s **20** solid years of grinding.  
- After 50 you’ll be a full‑time retiree (no side‑hustles, no “just one more project”).  
- Your lifestyle expenses are frozen in time – no surprise trips to Bali or a sudden love for vintage cars.  
- The **₹20,000** you save each month sits in a mattress (or a piggy‑bank) as hard cash.  

*(Yep, we listed the same bullet points a few times in the original – we’ll keep the spirit, not the redundancy.)*  

### What the numbers say when you **don’t** invest  

If you just let that cash gather dust for 20 years, you’ll end up with roughly **₹1.7 crore**. Sounds nice, right?  

But hold the celebratory dance:  

- Your expenses are still climbing at **8 %** per year, so that ₹1.7 crore only funds about **8 years** of post‑retirement life.  
- After the 8th year you’ll be staring at an empty bank balance, wondering whether to sell your collection of novelty mugs for cash.  

So the big question: *What do you do when the money runs out?*  

### What changes when you **do** invest?  

Now imagine you’re a little smarter and you park that ₹20,000 a month in something that actually **grows** – say **12 %** p.a. (a modest return for a decent equity‑balanced fund).  

Year 1 you have **₹240,000** saved. Let it compound for the remaining 19 years:  

\[
\text{Future Value} = 240{,}000 \times (1+0.12)^{19} \approx ₹2{,}067{,}063
\]

Do the math later – we’ll get to the “how” in later chapters.  

If you keep feeding the same ₹20,000 each month into that 12 % vehicle, your corpus after 20 years swells to **≈ ₹4.26 crore**. That’s **2.4×** the “no‑invest” pile. Suddenly you’ve got enough to fund **≈ 20 years** of retirement (inflation‑adjusted), plus a few extra trips to that Bali you pretended you didn’t want.  

### Bottom line – Why bother?  

| Reason | What it means for you |
|--------|-----------------------|
| **Fight Inflation** | Your money keeps up with the ever‑rising price of a chai. |
| **Create Wealth** | Bigger corpus = bigger dreams (college, house, cruise, you name it). |
| **Better Life** | You’re not just surviving; you’re thriving, with a safety net that actually works. |

So yes, investing is the superhero cape you need to beat the villain called “inflation” and to build the future you’ve been day‑dreaming about.  

---

## 1.2 – Where to invest?  

Now that you’re sold on the “why,” let’s tackle the “where.” Think of asset classes as different rides at an amusement park – some are gentle ferris wheels, some are roller‑coasters that make your stomach drop. Your ticket (risk tolerance) decides which you can hop on.  

### The big four (plus a side‑show)  

1. **Fixed‑Income Instruments**  
2. **Equity**  
3. **Real Estate**  
4. **Commodities (Gold & Silver)**  

Below we’ll give you a quick tour of each, complete with a few jokes and the numbers you actually care about.  

### Fixed‑Income Instruments  

![Fixed‑Income Icon](http://zerodha.com/varsity/wp-content/uploads/2014/07/fixed-inst-icon.png)  

These are the “sleep‑well‑at‑night” options. You hand over cash, they promise to give you interest, and at the end they give you your principal back – like a loan to a very responsible friend.  

Typical players:  

- **Bank Fixed Deposits** – the grand‑dad of FDs, interest paid quarterly/half‑yearly/yearly.  
- **Govt Bonds** (G‑Sec, Treasury Bills) – the “government can’t run away” guarantee.  
- **Agency Bonds** (GAIL, HUDCO, NHAI) – semi‑government, a tad more risk.  
- **Corporate Bonds** (Tata, Reliance, Adani, etc.) – higher yield, higher chance the issuer defaults (yes, even big names have stumbled).  

**Current yields (Oct 2022)**  

| Instrument | Approx. Yield |
|------------|---------------|
| Bank FD | 5 % – 6 % |
| Govt Bond | ~5.5 % |
| Good Corporate Bond | 9 % – 10 % |

Why the spread? Risk, my friend. The government is less likely to “forget” paying you back, whereas a corporate could go belly‑up (remember the 2008 crisis?).

### Equity  

![Equity Icon](http://zerodha.com/varsity/wp-content/uploads/2014/07/equity-icon1.png)  

Equities = owning a sliver of a company. If the company wins, you win; if it tanks, you’re stuck with a paper‑cut. No capital guarantee, but the upside can be spectacular.  

- **Historical CAGR (10‑15 years)**: **≈ 12 %** per annum.  
- **Best‑in‑class Indian stocks** have delivered **20 %+ CAGR** over the long haul.  

Finding those gems is a mix of research, patience, and not getting spooked by daily market noise.  

### Real Estate  

![Real Estate Icon](http://zerodha.com/varsity/wp-content/uploads/2014/07/real-estate-icon.png)  

Buying land, apartments, or commercial space. Two ways to make money:  

1. **Rental Income** – usually **2‑3 %** annual yield (not exactly a fireworks show).  
2. **Capital Appreciation** – only in “hot” pockets; not uniform across the country.  

Downsides: huge upfront cash, legal paperwork that feels like a maze, and liquidity that’s about as fast as a snail on a Sunday stroll.  

### Commodity – Bullion  

![Commodity Icon](http://zerodha.com/varsity/wp-content/uploads/2014/07/commodity-icon.png)  

Gold and silver: the classic “store of value” that’s been around since your grandma’s grandma.  

- **20‑year CAGR**: **≈ 5‑8 %**.  
- Ways to invest: jewelry (sparkles but high markup), ETFs, **Sovereign Gold Bonds (SGBs)** (government‑backed, less hassle).  

### What happens if you stick the ₹20,000 surplus into each of these for 20 years?  

| Asset Class | Assumed Avg. Return | Corpus after 20 years |
|-------------|--------------------|-----------------------|
| Fixed‑Income (9 % corporate bond) | 9 % | **≈ ₹3.3 crore** |
| Equity (15 % average) | 15 % | **≈ ₹5.4 crore** |
| Bullion (8 % average) | 8 % | **≈ ₹3.09 crore** |

**Equities** win the marathon when you have a multi‑year horizon, but remember – higher returns come with higher volatility.  

#### Quick note on Crypto  

You might wonder why crypto isn’t in the table. The short answer: **regulation = safety**. Crypto is still a wild west with limited investor protection. Until the government builds a proper fence, we recommend staying clear (or at least limiting exposure to a tiny “spice” portion).  

#### Asset Allocation – The “balanced diet” of investing  

A smart investor mixes the four (or more) assets to spread risk. A typical rule‑of‑thumb for a **young professional**:  

- **60 %** in equities  
- **20 %** in precious metals (gold/silver)  
- **20 %** in fixed‑income  

For a **retiree**, the tilt flips:  

- **80 %** in safe fixed‑income (govt bonds)  
- **10 %** in equities (for a little growth)  
- **10 %** in metals  

Your exact mix depends on age, risk appetite, and personal goals – we’ll unpack “asset allocation” in a later chapter.  

---

## 1.3 – Things to note before investing  

Investing isn’t a “set‑and‑forget” vending machine; there are a few ground rules you should keep in mind.  

1. **Risk‑Return Trade‑off** – The higher the risk, the higher the potential reward. Conversely, low‑risk assets give you modest returns.  
   - *Fixed‑Income*: Good for protecting principal, but may **lose** purchasing power if inflation outpaces the interest rate (e.g., 9 % interest vs. 10 % inflation → **‑1 % real return**).  
   - *Equities*: Historically beat inflation with **≈ 14‑15 %** long‑run returns, but they can swing wildly in the short term.  
   - *Real Estate*: Requires big cash, low liquidity, and the returns vary wildly by location.  
   - *Gold/Silver*: Safer than a crypto meme coin, but historically lower returns than equities.  

2. **Inflation is the silent thief** – Even a 6 % return is meaningless if inflation is 7 %. That’s why you need assets that *outpace* inflation (equities, some corporate bonds, real estate in hot zones).  

3. **Liquidity matters** – Can you cash out quickly? Fixed‑income and equities are generally liquid; real estate and some bonds are not.  

4. **Time horizon** – The longer you can keep money invested, the more you can ride out market bumps and let compounding work its magic.  

5. **Diversify, diversify, diversify** – Never put all your eggs in one basket; spread across asset classes, sectors, and geographies.  

You can download the Excel sheet used in the original chapter to play with these numbers yourself – it’s a great way to see how a 1 % change in assumed return can swing the final corpus dramatically.  

### Key takeaways from this chapter  

- **You must invest** if you want a financially secure future; hoarding cash is like keeping a hamster on a wheel – it looks busy but goes nowhere.  
- **Small changes in expected returns** have huge effects on the end corpus – a 1 % bump can mean tens of crores over a 20‑year horizon.  
- **Match the instrument to your risk appetite** – don’t buy a motorcycle if you’re scared of traffic.  
- **Equities are essential** for beating inflation over the long run – they’re the high‑octane fuel for your wealth engine.  
- **A balanced portfolio** (mix of equity, fixed‑income, and metals) is the prudent way to grow and protect your money.  

Now go forth, grab a calculator, and start plotting that wealth‑building roadmap – the sooner you start, the sooner your future self can thank you (maybe over a glass of wine). Cheers!  