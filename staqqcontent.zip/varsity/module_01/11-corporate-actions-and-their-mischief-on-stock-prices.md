# 11. Corporate Actions and Their Mischief on Stock Prices  

**Source:** https://zerodha.com/varsity/chapter/five-corporate-actions-and-its-impact-on-stock-prices/  

---  

##  

![Image](https://zerodha.com/varsity/wp-content/uploads/2014/09/Ch11title.jpg)  

## 11.1 – Corporate Actions  

Think of corporate actions as the company’s way of pulling a *prank* on its shareholders – sometimes a harmless joke, sometimes a full‑blown party. In plain English, a corporate action is any official move a firm makes that ends up shaking its share price. The board of directors proposes the move, the shareholders give a thumbs‑up (or a sigh), and the market reacts.  

Why should you care? Because every time the company decides to dish out cash, create new shares, or gobble up its own stock, it leaves a breadcrumb trail that tells you how healthy (or thirsty) the business is. Mastering these five headline‑grabbing actions will let you spot a genuine value play from a “let‑me‑look‑pretty‑on‑your‑balance‑sheet” stunt.  

---  

## 11.2 – Dividends  

![Image](https://zerodha.com/varsity/wp-content/uploads/2014/09/dividend1.png)  

Dividends are the corporate equivalent of “thanks for hanging out with us” – a slice of the profit pie sent straight to the pockets of anyone who owns the stock. They’re quoted **per share**.  

> **Example:** Infosys announced a dividend of **₹42 per share**. Own 100 shares? You pocket `100 × 42 = ₹4,200`. The money is credited to the bank account linked to your Demat, so you can instantly picture yourself buying a fancy dinner (or a whole pizza, depending on your appetite).  

Dividends are also expressed as a **percentage of face value**. Infosys’s face value is ₹5, so the payout is `42 / 5 = 8.4 × 100 = 840%`. Yes, you read that right – 840% of the nominal ₹5, not of the market price.  

### To pay or not to pay?  

Dividends aren’t a legal obligation every year. If management thinks the cash can earn a higher return by funding a new project, they’ll *retain* it. Fast‑growing, “young” firms (think SaaS start‑ups) usually skip dividends, plowing earnings back into the business to fuel growth.  

When growth slows or the balance sheet gets a little too fat, the board may decide to share the love. After all, cash sitting idle on the company’s books is about as exciting as a stale bagel. Handing it to shareholders is often the most efficient way to create value.  

### Losses don’t necessarily block dividends  

A firm can still pay dividends even if it posted a net loss, as long as it has enough **cash reserves**. The legal requirement is *cash*, not profit.  

### Who decides?  

The **Annual General Meeting (AGM)** is where the board puts the dividend proposal on the table and shareholders vote. Once approved, the company follows a set schedule – you don’t get the cash the instant they shout “Dividend declared!” because the market needs to sort out who actually owns the shares on the record date.  

#### The dividend calendar (in plain English)

| Milestone | What it means | Typical timing |
|-----------|---------------|----------------|
| **Dividend Declaration Date** | AGM day – board says “Yes, we’ll pay” | Day 0 |
| **Record Date** | Company checks its shareholder register to decide who’s eligible | Usually ~30 days after declaration |
| **Ex‑Date / Ex‑Dividend Date** | The first day you **won’t** get the dividend if you buy the stock | Same day as record date in India (T+1 settlement) |
| **Dividend Payout Date** | Money lands in your bank account | Usually 30‑45 days after record date |
| **Cum‑Dividend** | Shares still carry the right to dividend (i.e., you bought before the ex‑date) | Until the ex‑date |

**Key rule of thumb:** If you want the cash, *own the shares before the ex‑dividend date*. After that, you’re just a spectator.  

### Price reaction  

When a stock goes ex‑dividend, the price typically **drops by roughly the dividend amount**. Example: ITC trades at ₹335 and announces a ₹15 dividend. On the ex‑date you’ll often see it dip to around `₹335 − ₹15 = ₹320`. Why? The cash has left the company’s balance sheet, so the equity value shrinks accordingly.  

That said, the drop isn’t always a perfect one‑for‑one, especially for high‑volume stocks where market forces smooth things out.  

#### Special dividends  

Occasionally a firm throws a **special dividend** – a one‑off, usually hefty payout. The price adjustment can be more pronounced, but remember: you’re getting cash, not a “price correction”. Think of it as a birthday gift from the board.  

#### Interim vs. final  

- **Interim dividend:** Paid **mid‑year** (usually after the half‑yearly results).  
- **Final dividend:** Paid **after the fiscal year ends**, after the full accounts are out.  

---  

## 11.3 – Bonus Issue  

![Image](https://zerodha.com/varsity/wp-content/uploads/2014/09/bonus-issue.png)  

A **bonus issue** (aka *stock dividend*) is the company’s way of saying “Thanks for staying with us – here’s some more shares, on the house.” Instead of cash, you receive **additional shares** drawn from the company’s reserves.  

### How it works  

The issue follows a **ratio** such as 1:1, 2:1, 3:1, etc.  
- **1:1** → For every share you own, you get one extra share.  
- **2:1** → For every share, you receive two extra shares (so you end up with three).  

**Example:** You own 100 shares and the board announces a **2:1 bonus**. You’ll receive `100 × 2 = 200` new shares, ending up with **300 shares** in total.  

Your **total investment value stays the same** (ignoring market moves) because the share price adjusts downward proportionally.  

### Numerical illustration  

| Bonus Ratio | Pre‑bonus price (₹) | Shares owned | Pre‑bonus value (₹) | Post‑bonus shares | Post‑bonus price (₹) | Post‑bonus value (₹) |
|------------|-------------------|--------------|--------------------|-------------------|----------------------|----------------------|
| 1:1 | 200 | 100 | 20,000 | 200 | 100 | 20,000 |
| 3:1 | 200 | 100 | 20,000 | 400 | 50 | 20,000 |
| 5:1 | 200 | 100 | 20,000 | 600 | ≈33.33 | 20,000 |

*(All numbers rounded for clarity.)*  

### Timeline  

The **announcement date**, **ex‑bonus date**, and **record date** mirror the dividend schedule. The only twist: you must own the shares **before the ex‑bonus date** to be eligible for the free stock.  

### Why bother?  

Companies use bonus issues for a few practical reasons:  

1. **Make the stock more affordable** – When the per‑share price is astronomically high, retail investors feel intimidated. A bonus issue chops the price (while preserving market cap), inviting broader participation.  

2. **Boost retail enthusiasm** – More shares in the hands of the public can improve liquidity and create a sense of “ownership”.  

Consider **MRF Ltd.**, trading around **₹90,000** per share. A small investor with ₹25,000 can’t even buy a single share. If MRF were to issue a 1:1 bonus, the price would halve to roughly ₹45,000, still pricey, but the psychological barrier lowers a bit.  

Why hasn’t MRF split its shares? That’s a board decision—maybe they like the exclusivity, or maybe they just haven’t gotten around to filing the paperwork. 🤷‍♂️  

---  

## 11.4 – Stock Split  

![Image](https://zerodha.com/varsity/wp-content/uploads/2014/09/stocksplit.png)  

A **stock split** is the corporate equivalent of “cutting a pizza into more slices”. The **total pie (market cap)** stays the same; you just end up with more, smaller pieces.  

### Bonus vs. Split – the key difference  

| Feature | Bonus Issue | Stock Split |
|---------|-------------|-------------|
| **Face value** | Stays the same | Changes (usually halves, quarters, etc.) |
| **Reason** | Reward shareholders, improve affordability | Primarily improve liquidity & price perception |
| **Accounting** | Shares issued from reserves, no cash flow | Shares re‑denominated; capital remains unchanged |

**Example:** A stock with **₹10 face value** declares a **1:2 split**. Post‑split, each share’s face value becomes **₹5**, and every pre‑split share becomes **2 shares**. If you held 50 shares before, you’ll have **100 shares** after, each priced roughly half of the pre‑split price (again, ignoring market fluctuations).  

The **timeline** (announcement, ex‑date, record date, etc.) follows the same pattern as dividends and bonus issues.  

### Why split?  

- **Make the stock look cheaper** – Retail investors love round numbers like ₹500 more than ₹1,000.  
- **Boost trading volume** – More shares floating can improve liquidity, tightening bid‑ask spreads.  

---  

## 11.5 – Rights Issue  

![Image](https://zerodha.com/varsity/wp-content/uploads/2014/09/rightissue1.png)  

A **rights issue** is essentially a *private IPO* for existing shareholders. The company needs fresh capital but prefers to give its current owners the first dibs, usually at a **discount** to the market price.  

### How it works  

- **Subscription ratio** – e.g., **1:4** means you can buy **1 new share** for every **4 shares** you already hold.  
- **Discount** – If the market price is ₹500, the rights might be offered at **20 % off** → ₹400.  

**Example:** You own 200 shares. With a 1:4 rights issue, you’re entitled to purchase `200 ÷ 4 = 50` new shares at ₹400 each. If you exercise the rights, you’ll pay `50 × 400 = ₹20,000`.  

### Caveats & strategy  

- **Don’t chase the discount blindly.** A rights issue can be a *red flag* if the company is desperate for cash because of operational troubles.  
- **Compare the subscription price with the market price** on the ex‑rights date. If the market price falls below the subscription price, you’re better off buying the shares on the open market rather than exercising your rights.  
- **Dilution risk** – If you *don’t* participate, your ownership percentage shrinks because new shares are added to the pool.  

### Bottom line  

Treat a rights issue like any other investment decision: do the homework, understand why the company needs the money, and decide if the discounted price justifies the risk.  

---  

## 11.6 – Buyback of Shares  

![Image](https://zerodha.com/varsity/wp-content/uploads/2014/09/buyback.png)  

A **share buyback** is the corporate equivalent of “I love my own kids, so I’ll adopt a few of them back.” The company goes to the market, buys its own shares, and retires (or holds) them.  

### Why do companies buy back?  

1. **Boost per‑share earnings** – Fewer shares mean earnings are spread over a smaller base, often lifting EPS.  
2. **Consolidate promoter stake** – Buying back can increase the promoters’ ownership percentage without issuing new shares.  
3. **Defend against take‑overs** – Fewer free‑floating shares make hostile bids harder.  
4. **Signal confidence** – Management essentially says, “We think our stock is undervalued, so we’ll spend cash to support it.”  
5. **Support the price** – The extra demand from the buyback can provide a short‑term price floor.  

### Market reaction  

Generally, a buyback announcement is **positive** for the stock because it shows confidence and improves financial ratios. However, as always, look at the *why*: a buyback funded by *excess cash* is healthier than one financed by *heavy borrowing*.  

---  

### Key Takeaways  

- **Corporate actions move the price** – Whether it’s cash (dividends), extra shares (bonus/split), or cash outflows (buybacks), each action reshapes the equity value.  
- **Dividends** are quoted as a % of **face value**, not the market price. You must own the stock **before the ex‑dividend date** to snag the cash.  
- **Bonus issues** give you free shares; the total value stays the same, but the price per share drops proportionally.  
- **Stock splits** change the **face value** (e.g., ₹10 → ₹5) while also increasing the share count.  
- **Rights issues** raise fresh capital from existing owners at a discount. Only subscribe if you truly believe in the company’s future; otherwise you risk dilution.  
- **Buybacks** are the company’s love‑letter to its shareholders, often boosting EPS and signaling confidence—just verify the financing.  

Armed with this toolbox, you’ll be able to read corporate announcements like a bartender reads a cocktail menu: know what’s being poured, why it matters, and whether it’ll leave a pleasant after‑taste in your portfolio. Cheers!