# 12. Key Events and Their Impact on Markets  

**Source:** <https://zerodha.com/varsity/chapter/key-events-and-their-impact-on-markets/>

---  

##  

![Image](https://zerodha.com/varsity/wp-content/uploads/2021/08/Ch12title1.jpg)  

## 12.1 – Events  

If you think “buy‑the‑stock‑because‑the‑CEO‑wears‑a‑cool‑jacket” is enough, you’re missing the bigger picture.  The market is a giant cocktail party where **everything** that happens outside the company can make the price wobble—think macro‑economics, politics, natural disasters, or that viral TikTok dance that makes a brand go “whoops, we didn’t see that coming.”  

In this chapter we’ll walk through the most common “party crashers” and see how the market usually reacts when they show up.  

## 12.2 – Monetary Policy  

Monetary policy is the RBI’s (Reserve Bank of India’s) way of playing DJ at the economy‑dance‑floor. By turning the interest‑rate knobs up or down, the RBI decides how much cash will be swirling around. Every nation has its own “DJ”: the European Central Bank in the Euro‑zone, the Federal Reserve in the U.S., the Bank of England in the UK, and so on.  

### Why the RBI fusses with rates  
- **High rates** = borrowing gets pricey.  Corporations think twice before taking a loan, growth slows, and the economy can feel a bit like a sluggish Monday morning.  
- **Low rates** = cheap money, so firms and consumers go on a shopping spree.  More spending = higher demand → sellers raise prices → inflation starts to creep in.  

If you need a visual, check out my YouTube crash‑course on what fuels inflation and how the RBI tries to put it out:  

<https://www.youtube.com/watch?v=Qx3YMdcLTZo&list=PLX2SHiKfualEyD05J9JsklEq1JFGbG6qJ&index=2>  

Balancing growth and inflation is a tightrope act.  Slip‑ups can send the economy tumbling, so the RBI watches a handful of “key rates” like a hawk.  

| Rate | What it is | Market vibe when it moves |
|------|------------|---------------------------|
| **Repo Rate** | The rate at which banks *borrow* money from the RBI (think of it as the RBI’s “pay‑me‑back‑with‑interest” price). | Higher repo → borrowing gets expensive → growth fears → markets cringe. |
| **Reverse Repo Rate** | The rate at which the RBI *lends* money to banks for the cash they park with it (a.k.a. the RBI’s “savings account” for banks). | Higher reverse repo pulls cash out of the economy → tighter money supply → markets get nervous. |
| **Cash Reserve Ratio (CRR)** | The % of deposits banks must keep with the RBI as a safety cushion. | Raise CRR → more money stuck with the RBI → less liquidity for loans → market gloom. |

The Monetary‑Policy Committee (MPC) meets regularly, decides on these levers, and then the market reacts—first and fastest in interest‑rate‑sensitive sectors like banks, auto makers, housing finance, real estate, and metals.  

## 12.3 – Inflation  

Inflation = the silent thief that steals the buying power of your rupee, one onion at a time.  If a kilo of onions jumps from ₹15 to ₹20, that ₹5 difference is the price of “inflation” (plus a side of tears for the chef).  

A little inflation is normal—think of it as a gentle nudge that keeps the economy moving.  Too much, however, is like a runaway train: it scares investors, erodes savings, and makes everyone wonder whether their salary will ever keep up with the price of pizza.  

### Two ways India measures price‑rise  
| Index | What it tracks | Why you care |
|-------|----------------|--------------|
| **Wholesale Price Index (WPI)** | Prices at the wholesale (big‑lot) level. | Good for seeing pressure on producers, but it can miss what you actually pay at the checkout. |
| **Consumer Price Index (CPI)** | Prices that consumers pay for everyday goods—food, fuel, clothing, etc. | This is the “real‑life” inflation number that affects your pocket. |

The CPI is a massive statistical beast.  MOSPI (Ministry of Statistics and Programme Implementation) gathers data from urban & rural households, classifies spending into dozens of categories, builds sub‑indices, and then blends them into the headline CPI.  The numbers drop roughly in the second week of every month.  

The RBI’s dilemma: **low rates = cheap money = higher inflation**; **high rates = expensive money = lower inflation**.  The art (or science) of monetary policy is to keep the two in a comfortable dance without stepping on each other’s toes.  

## 12.4 – Index of Industrial Production (IIP)  

Think of the IIP as the “muscle‑meter” for India’s factories, mines, and utilities.  Every month MOSPI collects production numbers from about 15 major industries, stitches them together, and reports a single index.  The base year is 2004‑05, so a reading of **120** means the economy is producing 20 % more than it did in the base year.  

- **Rising IIP** → factories are humming, orders are flowing, the economy looks healthy → markets get a happy buzz.  
- **Falling IIP** → production slowdown, factories idling, investors worry → markets get a little shaky.  

When the IIP dips, the RBI often feels pressure to **cut rates** to make credit cheaper for manufacturers. Conversely, a robust IIP can give the RBI confidence to keep rates steady or even hike them a smidge.  

## 12.5 – Purchasing Managers Index (PMI)  

The PMI is basically a “mood‑ring” for the country’s business leaders.  Survey‑based, it asks purchasing managers (the folks who decide how much raw material to buy) about new orders, output, employment, inventories, and expectations.  Two separate surveys feed into a single number—one for manufacturing, one for services.  

- **PMI > 50** → the economy is expanding (the mood‑ring glows green).  
- **PMI < 50** → contraction (the mood‑ring turns red).  
- **PMI ≈ 50** → business as usual, no major change.  

Because the survey is released ahead of most official data, traders love it as an early‑warning system for growth trends.  

## 12.6 – Budget  

The Budget is India’s grand fiscal fireworks show, delivered every year (usually the last week of February) by the Finance Minister.  It’s a 30‑minute (or sometimes longer) marathon of tax proposals, expenditure plans, and policy reforms—think of it as the government’s “state of the union” but with more spreadsheets.  

### How a single line can move markets  
Take the 2023 budget’s decision to **raise excise duty on cigarettes**:  

1. **Higher price** → smokers think twice (or keep smoking and sigh).  
2. **ITC’s profit** → expected to fall because each pack now nets less.  
3. **Investors** → start dumping ITC shares.  
4. **Market impact** → ITC is a heavyweight in the NIFTY; its decline drags the whole index down.  

Indeed, ITC slid **≈ 3.5 %** right after the announcement.  

If a new government forms or a major crisis hits, the budget can be delayed—so keep an eye on the political calendar as well.  

## 12.7 – Corporate Earnings Announcement  

Earnings season is the quarterly “report‑card” for listed companies.  Every three months, firms must disclose:  

- **Revenue growth**  
- **Expense trends**  
- **Finance charges**  
- **Profitability**  
- **Project updates**  
- **Industry‑specific trends**  

Most importantly, they give **guidance**—their own forecast for the next quarter or year.  

The first blue‑chip to spill the beans each season is usually **Infosys**.  Analysts and traders watch its guidance like a weather forecast: a bright outlook can lift sentiment across the market, while a gloomy one can send chills down the spine of even unrelated stocks.  

### Street expectations vs. reality  
- **Beat expectations** → stock jumps (the market loves pleasant surprises).  
- **Miss expectations** → stock slides (nobody likes a bad report card).  
- **Match expectations** → the stock often drifts sideways, sometimes with a slight negative bias because “meh, nothing exciting happened.”  

Remember: India’s fiscal year starts **1 April**, so the “Q1” results cover Jan‑Mar, “Q2” covers Apr‑Jun, and so on.  

## 12.8 – Non‑Financial Events  

Not everything that moves markets is about money.  Some events are more… *extraterrestrial*.  

- **COVID‑19 (2020)** turned the world upside down, snarling supply chains, spiking inflation, and catapulting online‑service firms into the stratosphere.  
- **Russia‑Ukraine war** throttles natural‑gas and crude‑oil supplies, especially hurting Europe’s energy bills and causing ripple effects in commodity markets worldwide.  
- **China‑Taiwan tensions** can shake tech supply chains, given Taiwan’s dominance in semiconductor manufacturing.  

These geopolitical shocks can cause **cross‑border contagion**—a ripple that travels from one market to another.  

Conversely, **local events** such as **Indian general elections** primarily affect the Indian economy, influencing voter‑driven policy expectations and sector‑specific sentiment (e.g., infrastructure, defence, consumer goods).  

Bottom line: a savvy trader treats the news feed like a radar screen—spotting both the big storms and the tiny gusts that could tilt a stock’s trajectory.  

---

## Key Takeaways  

- **Markets love drama.** Every piece of news—big or small—can trigger price moves, so stay tuned.  
- **Monetary policy** is the headline act; watch repo, reverse repo, and CRR changes for early market clues.  
- **Interest rates & inflation** are a seesaw: raise rates → curb inflation; lower rates → fuel inflation.  
- **CPI** (consumer‑price index) is the inflation number that matters to your wallet; MOSPI releases it monthly.  
- **IIP** gauges industrial vigor—up is good news, down is a warning sign.  
- **PMI** is a sentiment gauge; > 50 = expansion, < 50 = contraction.  
- **Budget** is the yearly policy fireworks; expect big moves in tax‑sensitive stocks and sectors.  
- **Corporate earnings** drive short‑term volatility—compare actuals vs. the “street expectation.”  
- **Non‑financial events** (pandemics, wars, elections) can swing markets dramatically; never ignore them.  

Keep your eyes on the calendar, your ears on the news, and your brain on the numbers—then you’ll be ready to surf any market wave that comes your way. Happy trading!  