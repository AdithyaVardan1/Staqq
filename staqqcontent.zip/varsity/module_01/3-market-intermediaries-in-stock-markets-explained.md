# 3. Market Intermediaries in Stock Markets explained  

**Source:** https://zerodha.com/varsity/chapter/financial-intermediaries/  

---  

## 3.1 – Overview  

Think of the stock market as a giant party. You’re the guest who wants to grab a slice of the cake (or a share of a company). But you can’t just walk up to the kitchen, grab a fork and start munching. Somewhere behind the curtains, a whole crew of party‑planners—*market intermediaries*—are making sure the buffet stays stocked, the lights stay on, and the DJ (aka the exchange) doesn’t play the same song twice.  

From the moment you fire up your trading app, click “Buy” and wait for those shiny certificates to pop into your DEMAT account, dozens of invisible hands are pulling levers, stamping paperwork (digitally, of course) and whispering “All good, buddy!” to SEBI so that the whole thing stays legal, smooth and drama‑free.  

These folks are collectively known as **Financial Intermediaries** or **Market Intermediaries**. They depend on each other like a well‑rehearsed improv troupe—if one flubs, the whole show could collapse. Below we’ll meet the main characters, give them a quick intro, and explain why you should thank (or at least not hate) each of them.  

---  

## 3.2 – The Stock Broker  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/07/broker3.png)  

If the market were a theme park, the **stock broker** would be your ticket‑counter attendant, the person who hands you the wristband and points you toward the roller‑coaster of stocks, bonds, ETFs and mutual funds.  

A stock broker is a corporate entity that has **registered as a trading member** with an exchange and holds a SEBI‑granted brokerage licence. SEBI does a background check, makes sure the broker isn’t a fraudster, and then says “You may now charge people for letting them play the market.”  

### How you pick a broker (a.k.a. the “dating” phase)  

- **Platform simplicity** – Is the UI as smooth as a fresh jar of peanut butter, or does it feel like you’re navigating a 1990s dial‑up site?  
- **Support efficiency** – When you’re in a panic because your order went “stale,” does the support team answer faster than your mother‑in‑law’s gossip?  
- **Ready‑made reports** – Profit‑&‑Loss statements, tradebooks, tax‑ready P&L – think of them as the “nutrition facts” on your trading diet.  
- **Broker’s net‑worth** – You don’t want to hitch a ride with a broker who’s on the verge of bankruptcy; a healthy balance sheet is a good sign they can actually settle your trades.  
- **Education initiatives** – Free webinars, blogs, mock‑trading contests… because a broker who teaches you to fish (or trade) is worth its weight in gold.  

> *Pro tip:* Many people end up copying the same five‑point list over and over. That’s fine—just remember you’re looking for a broker that fits **your** style, not the market’s generic template.  

### Getting down to business – ways to talk to your broker  

1. **Phone‑order** – Dial the broker, quote your client code, shout “Buy 10 shares of TCS at market price!” The dealer on the other end clicks a few buttons, confirms the execution, and you’re done while still on the call. (Old‑school, but still alive in some circles.)  
2. **Self‑service (the most popular)** – Log into the broker’s **trading terminal** (Zerodha calls theirs “Kite”). You see live quotes, place orders, watch the order book, and feel like a Wall Street wizard.  
3. **Programmatic access** – For the code‑savvy, some brokers sell you an API (often for a modest fee). You can write a bot that trades while you nap, though you’ll need to watch out for “algo‑fatigue.”  

### Core services a broker must provide (the “must‑have” menu)  

- **Market access** – The literal gateway that lets you buy or sell. Without it, you’re just looking at a pretty chart.  
- **Margin facilities** – (We’ll unpack this later; think of it as borrowing money to amplify your bets.)  
- **Support & education** – Call‑center help, webinars, FAQs—your lifeline when the market decides to act like a teenage mood swing.  
- **Contract notes** – A written receipt for every trade, like a receipt after buying a coffee, but with numbers and legal jargon.  
- **Fund‑transfer facilitation** – Moving cash between your bank and your trading account, smoother than a magician’s sleight of hand.  
- **Back‑office portal** – A dashboard (Zerodha’s “Console”) where you can pull reports, check positions, and stare at numbers that make you feel sophisticated.  
- **Brokerage charges** – The fee you pay for all the above. It can be a flat ₹20 per order, a percentage of turnover, or a combination. Hunt for a broker whose fees align with the services you actually need.  

> *Remember:* A cheap broker might skimp on support; a premium broker might charge more but also give you a personal “trading coach.” Choose what feels right for your wallet and your temperament.  

---  

## 3.3 – Depository and Depository Participants  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/07/broker3.png)  

Imagine buying a house. The deed (paper) proves you own it, and you lock that deed in a safe. Shares work the same way, only the “deed” is a **share certificate**. Before 1996, those certificates were literal paper—think of them as the 1990s version of a Pokémon card.  

### From paper to pixels – the DEMAT revolution  

In 1992, the infamous **Harshad Mehta scam** exposed how fragile paper certificates were (spoiler: they got forged, lost, and caused a national panic). The fallout pushed regulators to digitize everything, birthing the **Dematerialisation (DEMAT)** process.  

A DEMAT account is a **digital vault** where your electronic share certificates live. The vault is run by a **Depository**, a specialised financial intermediary that keeps the ledger clean, safe, and instantly accessible.  

- **National Securities Depository Limited (NSDL)**  
- **Central Depository Services (India) Limited (CDSL)**  

Both operate under SEBI’s watchful eye, and for most investors they’re indistinguishable—like two coffee shops that both serve a decent latte.  

### Who opens the vault for you?  

You can’t stroll into the NSE office and say “I want a DEMAT account.” Instead, you approach a **Depository Participant (DP)**—the middle‑man that links you to the depository. Think of a DP as the friendly clerk at the bank who helps you set up your safe deposit box.  

- **Zerodha** is a DP for **CDSL**, meaning when you open a DEMAT account through Zerodha, Zerodha talks to CDSL on your behalf.  

### How the trading‑account‑DEMAT dance works  

1. **Buy side** – You log into your broker’s trading platform, click “Buy 100 shares of Infosys.” The order gets executed, the cash leaves your trading account, and the shares appear *automatically* in your DEMAT account. No extra steps, just a digital “ping.”  
2. **Sell side** – You decide to sell those Infosys shares. You place the sell order in the trading terminal. The system checks your DEMAT account, debits the 100 shares, credits the cash to your trading account, and you’re done.  

It’s a seamless loop, thanks to the tight integration between broker, DP, and depository.  

---  

## 3.4 – Banks  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/07/broker3.png)  

Banks are the **cash‑cows** of the ecosystem. Their job is simple (but vital): move money in and out of your trading world.  

- **Linking** – Your broker verifies your bank account (via micro‑deposit or IFSC check) and then creates a digital bridge between the two.  
- **Multiple accounts** – You can attach several bank accounts to a single trading account, but only **one** can be the **Primary** for withdrawals. Think of it as the “home base” where all the loot ends up.  
- **Primary vs. Secondary** – At Zerodha you can have **1 primary** and up to **2 secondary** accounts. You can fund any of them, but cash‑out only goes to the primary.  
- **Dividends & buy‑backs** – When you earn a dividend or a company buys back shares, the money lands straight into that primary bank account.  

So, your three main electronic personas—trading account (broker), DEMAT account (depository/DP), and bank account—are all interlinked, giving you a frictionless experience that feels like a single‑click magic trick.  

---  

## 3.5 – NSE Clearing Limited and ICCL  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/07/broker3.png)  

**NSE Clearing Limited** (for the National Stock Exchange) and **Indian Clearing Corporation Limited (ICCL)** (for the BSE) are the **settlement super‑heroes** of the market. They are wholly owned subsidiaries of their respective exchanges, and their mission is to make sure that every trade you make actually settles—no one gets short‑changed.  

### What does “clearing” actually mean?  

Suppose you buy 1 share of Biocon at **₹446**. Someone else must sell that same share at ₹446. The clearing corporation does three things:  

1. **Match buyer and seller** – It pairs the debit (your ₹446) with the credit (seller’s ₹446).  
2. **Guarantee settlement** – It stands in the middle as a guarantee, so the seller can’t suddenly say “Oops, I changed my mind!” and the buyer can’t back out either.  
3. **Prevent defaults** – If either party fails to deliver cash or shares, the clearing house steps in, uses margins (the safety‑net cash you’ve pre‑deposited), and makes everything whole.  

### Why you probably won’t meet them in person  

As an everyday trader or investor, you don’t interact directly with NSE Clearing or ICCL. They work behind the scenes, much like the backstage crew at a concert. Their processes are heavily regulated, audited, and designed to keep the market’s gears greased.  

They also handle **margining** for derivatives (futures & options). That’s a whole other rabbit hole we’ll dive into later, but for now just remember: they keep the market’s promises enforceable.  

---  

### The key takeaway from this chapter  

- The market ecosystem is a **cluster of financial intermediaries**, each playing a distinct but inter‑dependent role.  
- **Stockbrokers** give you the doorway to trade; pick one that matches your style, tech comfort, and budget.  
- A broker provides a **trading account** for all your buy‑sell actions.  
- A **Depository** (NSDL or CDSL) holds your shares **electronically** in a DEMAT account—your digital vault.  
- To open a DEMAT account you must go through a **Depository Participant (DP)**, which acts as the depository’s agent (Zerodha = CDSL DP).  
- **Clearing corporations** (NSE Clearing, ICCL) guarantee that every trade settles smoothly and that nobody defaults.  
- **Banks** move the cash in and out, with a single **primary bank account** handling withdrawals and dividend payouts.  

When all these pieces click together, you get the sleek, almost‑instant experience of buying a share with a few clicks and watching it appear in your DEMAT vault—no paperwork, no drama, just pure market magic. Cheers to the unsung heroes behind the curtain!