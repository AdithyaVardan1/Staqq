# 6. Equity Curve  

**Source:** https://zerodha.com/varsity/chapter/equity-curve/

---  

## 6.1 – Overview  

Alright, grab a coffee (or a chai, if you’re feeling fancy) because we’re about to take a little detour from the textbook‑ish grind. This isn’t just another dry chapter – it’s the one I wrote while perched on a mist‑cloaked hilltop at the ungodly hour of 6:15 AM. Picture this: 360° of fog‑kissed peaks, a lone shack humming Bob Marley’s *Redemption Song*, and me, a lone trader‑in‑the‑making, typing away. Could life get any more cinematic? Not for me, at least. 🙂  

![Image](http://zerodha.com/varsity/wp-content/uploads/2017/04/M9-C6-Cartoon.png)  

Back to the classroom (or “the bar” if you prefer a more… spirited setting).  

In the previous chapter we wrestled with **Portfolio Variance**. Calculating it was fun, but like buying a fancy espresso machine and never using it, it’s pointless unless you put it to work. Over the next two chapters we’ll do exactly that. Here’s the game plan:  

- Unpack the **Equity Curve** and learn an alternate route to compute portfolio variance.  
- Project the portfolio’s expected return for the next 12 months.  
- Tweak the weights to **optimise** for the sweet spot: max return, min variance.  

⚠️ **Heads‑up:** This chapter leans heavily on the concepts we covered earlier. If you jumped straight here without reading the previous bits, you might feel like you walked into a movie halfway through. Go back, binge‑read the earlier chapters, and then return for the grand finale.

## 6.2 – Equity Curve  

Time to roll up our sleeves and build an **Equity Curve** for the 5‑stock portfolio we’ve been toying with. In the layperson’s lingo, an equity curve is a simple line graph that shows how a *Rs. 100* investment would have performed over a chosen period. Think of it as the “Instagram filter” for portfolio performance – it normalises everything to a tidy 100 so you can compare apples to apples (or Nifty 50 to BSE Sensex, whichever you prefer).

Why bother? Because the curve lets you eyeball a handful of handy metrics (more on those later) and benchmark your strategy against the market’s heavyweights.

### The stocks and their random weights  

First, a quick reminder of the five stocks and the (totally random) weights we slapped on them:

| Stock | Weight |
|-------|--------|
| Cipla | 7 % |
| Alkem Labs | 22 % |
| Idea | 16 % |
| Wonderla | 25 % |
| … (the rest) | … |

*What does “investment weight” actually mean?*  
It’s simply the slice of your total capital you allocate to each ticker. For a **Rs. 100 000** portfolio, a 7 % weight means **Rs. 7 000** goes into Cipla, 22 % means **Rs. 22 000** into Alkem Labs, and so on.

### Normalising to Rs. 100  

When we draw an equity curve we usually **normalise** the whole thing to a starting capital of **Rs. 100**. That way the curve always starts at the 100‑point line and any rise or fall is instantly visible. I’ve baked this normalisation straight into the Excel sheet (the same workbook we used in the previous chapter – continuity is sexy).

Take a peek at the screenshot below:

![Image](http://zerodha.com/varsity/wp-content/uploads/2017/04/Image-2_wt.png)

You’ll notice two brand‑new columns:

1. **Starting Value (pegged at 100)** – This is our pretend Rs. 100 that we’ll watch grow (or shrink).  
2. **Total Weight (100 %)** – A sanity‑check column to make sure the percentages really do add up to 100 %.

#### How the numbers work  

Suppose we start with **Rs. 100**. With the weights above, we’re effectively putting **Rs. 7** into Cipla, **Rs. 16** into Idea, **Rs. 25** into Wonderla, etc. If you sum the individual weights you’ll get exactly 100 % – meaning the whole Rs. 100 is fully deployed.

Now let’s zoom in on **Cipla** to see the mechanics. Cipla’s weight is 7 %, so we start with **Rs. 7** in that stock. Every day the price of Cipla moves, that Rs. 7 either grows or shrinks. Crucially, the next day’s starting point is **the new amount**, not the original Rs. 7. In other words, we’re compounding daily.

Here’s the Excel view for Cipla:

![Image](http://zerodha.com/varsity/wp-content/uploads/2017/04/Image-3_daily-change.png)

On **1 Sept**, Cipla closed at **₹579.15**. We pretend we bought a fraction of a share worth exactly Rs. 7 (yes, it’s a fantasy trade, but it keeps the math clean). The next day, 2 Sept, the closing price is **₹577.95**, a dip of **‑0.21 %**. So our Rs. 7 becomes **₹6.985** (7 × 0.9989). Fast‑forward to **6 Sept**, the stock jumps **+0.11 %**, turning Rs. 6.985 into **₹6.993** (6.985 × 1.0011). And we keep repeating this for every trading day.

I did the same for each of the other four stocks. The resulting table looks like this:

![Image](http://zerodha.com/varsity/wp-content/uploads/2017/04/Image-4_wt-daily-change.png)

You’ll notice the daily change for each stock is highlighted in blue – a little visual cue for the data‑junkie in you.

### Adding up the pieces  

Now, imagine we’ve literally **split Rs. 100** across the five stocks. If we add the daily percentage change of each stock (weighted by its share of the Rs. 100), we obtain the **overall daily change of the whole portfolio**. In Excel, that’s just a row‑wise sum.

The summed‑up daily portfolio values look like this:

![Image](http://zerodha.com/varsity/wp-content/uploads/2017/04/Image-5_port-eq.png)

And the resulting time‑series (the daily “balance” of our Rs. 100) appears as:

![Image](http://zerodha.com/varsity/wp-content/uploads/2017/04/Image-6_port-all-values.png)

### Plotting the Equity Curve  

If you chart that last column (the rolling Rs. 100 balance) you get the **Equity Curve** – a line that shows exactly how our pretend Rs. 100 grew over the six‑month window.

Here’s the curve:

![Image](http://zerodha.com/varsity/wp-content/uploads/2017/04/Image-7_Eq-curve.png)

Boom! As simple as a pizza slice, right? The curve is a favorite visual tool for traders because it instantly tells you the **cumulative return**. In our example we started at **100** and ended at **113.84** after six months – a tidy **13.84 %** gain.

Check the final snapshot:

![Image](http://zerodha.com/varsity/wp-content/uploads/2017/04/Image-8_end-value.png)

So, without any fancy calculus, we can say: *“Hey, we made roughly 13.8 % in half a year.”* (Assuming we ignored transaction costs, slippage, and the fact that you can’t actually buy a fraction of a share for Rs. 7. 😉)

## 6.3 – Portfolio as a Whole  

Let’s take a step back and look at the **portfolio itself** as if it were a single stock. Remember in the previous chapter we computed **portfolio variance** by building a covariance matrix and multiplying it with the weight vector? That was mathematically elegant, but a bit like solving a Rubik’s cube blindfolded.

When we built the equity curve we already have a **daily value series** for the whole portfolio (the Rs. 100 line). That means we can also compute its **daily returns**—exactly the same way we did for the individual stocks.

### From daily returns to volatility  

Standard deviation (σ) of daily returns is the market’s favorite shorthand for **volatility** (i.e., risk). In Excel we used `=STDEV()` on each stock’s daily returns earlier. Why not apply the same function to the portfolio’s daily returns?

If we do that, the resulting σ should match (or be extremely close to) the **portfolio standard deviation** we derived via matrix algebra earlier. In other words, we have two completely different routes that lead to the same destination – a nice sanity check.

Here’s the portfolio variance we calculated earlier (via matrix math):

![Image](http://zerodha.com/varsity/wp-content/uploads/2017/04/Image-9_port-var.png)

Now, let’s compute the daily returns for the normalised portfolio (the Rs. 100 series). I added a fresh column next to the daily portfolio value:

![Image](http://zerodha.com/varsity/wp-content/uploads/2017/04/Image-10_port-varisd.png)

With those returns in hand, I fired up Excel’s `=STDEV()`:

![Image](http://zerodha.com/varsity/wp-content/uploads/2017/04/Image-11_sd.png)

Ta‑da! The standard deviation matches the previous variance number almost exactly. That’s the magic of the equity curve: it gives you a **quick, spreadsheet‑friendly** way to verify your risk calculations.

You can download the exact Excel workbook we used (it’s the same file you’ve been tweaking all along). In the next chapter we’ll take this portfolio variance and plug it into the **expected‑return formula** and then run an optimisation to see how we can nudge those weights for a better risk‑return trade‑off.

### Quick task (because I love homework)  

We started with **random weights**. Now, change the weight percentages—maybe give Wonderla a bigger slice or shrink Cipla’s share. Re‑run the equity‑curve steps and watch how the final return and volatility move. Post your findings in the comment section; I’m curious to see who can crank the return up to 20 % without blowing up the variance.

---

### Key takeaways from this chapter  

- An **equity curve** is the go‑to visual for tracking a portfolio’s performance over time.  
- The industry norm is to **normalise** the starting capital to **Rs. 100**, making comparisons painless.  
- **Weights** dictate how much of that Rs. 100 is allocated to each stock (e.g., 7 % → Rs. 7).  
- For each stock we compute the **daily change** in its allocated amount.  
- Summing the weighted daily changes across all holdings yields the **portfolio’s daily change**.  
- Plotting that daily series produces the **equity curve**.  
- Treating the whole portfolio as a single “stock” lets us compute its **standard deviation** with `=STDEV()`.  
- That standard deviation is essentially the **portfolio variance** we derived earlier via matrix algebra.  

Now go forth, play with weights, draw curves, and remember: the market may be serious business, but your spreadsheet can still have a sense of humor. 🍻