# 7. Expected Returns  

**Source:** https://zerodha.com/varsity/chapter/expected-returns/  

---  

## 7.1 – Expected returns  

![Image](http://zerodha.com/varsity/wp-content/uploads/2017/05/M9-C7-cartoon.png)  

Alright, future “Portfolio Wizards”, buckle up. The next two chapters are the financial equivalent of discovering a secret cocktail recipe that only the high‑falutin hedge‑fund gurus were supposed to know. We’ll waltz into the **expected‑return framework** and then onto **portfolio optimisation** – think of it as a magic wand that tells you exactly how much of each stock to pour into your cauldron so you get the best possible mix of risk and reward.  

> *Spoiler alert*: The finance elite have been hoarding this magic, but we’re about to pull the curtain back and share it with the rest of humanity (or at least with you, dear reader).  

> **Heads‑up** – If you skimmed the previous chapters faster than a bar‑tab on happy hour, hit pause and read those first. The concepts we’ll use now build on that foundation, and the Excel sheet we’ll be playing with is a continuation of the one you’ve already seen.  

Assuming you’ve got your coffee (or a good bourbon) and your brain is primed, let’s put that portfolio variance we calculated earlier to good use.  

### The variance we already have  

![Image](http://zerodha.com/varsity/wp-content/uploads/2017/05/Image-1_port-var.png)  

**What does 1.11 % actually mean?**  

It’s the daily “wiggle‑room” of your portfolio – the amount of risk you’re taking on each trading day. Remember, we were looking at daily price data, so that 1.11 % is a *daily* variance, not yearly.  

Think of risk/variance/volatility as a two‑sided coin: one side is the *downside* (the part that makes you lose sleep), the other side is the *upside* (the part that makes you do a happy dance). In a few moments we’ll use that variance to draw a **confidence band** around where we expect the portfolio to wander over a year. If you’ve already dabbled in the Options module, you know where we’re headed – it’s the land of normal distributions and “how likely is this to happen?”  

---

### First, we need the **expected return**  

The expected return of a portfolio is just the weighted sum of each stock’s average return, annualised. In plain English:  

\[
\text{Expected Return} = \Big(\sum_i w_i \times \bar r_i\Big) \times 252
\]

*252* is the number of trading days in a typical year, so we’re scaling daily averages up to an annual figure and then weighting them by how much of the portfolio each stock occupies.  

Let’s see the numbers in action.  

![Image](http://zerodha.com/varsity/wp-content/uploads/2017/05/Image-2_exp-return.png)  

*Columns 1‑3* are self‑explanatory (stock name, daily avg. return, weight). The **fourth column** is just “daily avg. return × 252” – that’s the annualised return for each stock.  

**Example** – Cipla:  

- Daily avg. return = **0.06 %**  
- Annualised = 0.06 % × 252 = **15.49 %**  

Interpretation: If you dumped your entire capital into Cipla (100 % weight), you could *expect* about a 15.49 % return over the next year.  

But you’re not an all‑in‑Cipla fan; you only gave Cipla a **7 %** slice of the pie. So its contribution to the portfolio’s expected return is:  

\[
\text{Weight} \times \text{Annualised Return}=0.07 \times 15.49\% = 1.08\%
\]

---

### Portfolio‑level expected return  

The same logic applies to every stock, then you just add ’em up.  

![Image](http://zerodha.com/varsity/wp-content/uploads/2017/05/Image-2_exp-return.png)  

Where  

- **\(w_i\)** = weight of stock *i* in the portfolio  
- **\(R_i\)** = expected annual return of stock *i*  

Applying the formula to our 5‑stock cocktail yields:  

![Image](http://zerodha.com/varsity/wp-content/uploads/2017/05/Image-3_port-ret.png)  

> **Bottom line**:  
> - **Expected portfolio return = 55.14 %**  
> - **Portfolio variance (daily) = 1.11 %**  

Now let’s turn that daily variance into an **annual variance**. Because variance (or standard deviation) scales with the square‑root of time, we multiply by √252:  

\[
\text{Annual variance} = 1.11\% \times \sqrt{252} \approx 17.64\%
\]

We’ll keep these two superheroes—55.14 % expected return and 17.64 % annual variance—right beside us.  

---

### Normal distribution – the bartender’s secret sauce  

If you skimmed the Options chapter, you’ll remember the **Dalton board experiment** (the one with the ping‑pong balls that form a bell curve). That experiment teaches us that many natural phenomena—including daily portfolio returns—tend to follow a **normal (Gaussian) distribution**.  

If you plotted the histogram of our portfolio’s daily returns, you’d most likely see a nice bell‑shaped curve. Assuming normality, we can now talk about **confidence intervals**:  

| Confidence Level | Standard Deviations (σ) | Approx. Probability |
|------------------|------------------------|---------------------|
| 68 %             | 1σ                     | One‑sigma band      |
| 95 %             | 2σ                     | Two‑sigma band      |
| 99 %             | 3σ                     | Three‑sigma band    |

Since our **annualised variance** of 17.64 % is actually the *first* standard deviation (σ), we can instantly compute the higher‑sigma bands:  

- **2σ** = 2 × 17.64 % = **35.28 %**  
- **3σ** = 3 × 17.64 % = **52.92 %**  

If that feels like a lot of math, think of it as “how far the cocktail can swing” at different confidence levels.  

---

## 7.2 – Estimating the portfolio range  

Armed with an expected return of **55.14 %** and a **1σ variance of 17.64 %**, we can now sketch the range where the portfolio is likely to land after one year.  

### 1‑σ (≈68 % confidence)  

- **Upper bound** = 55.14 % + 17.64 % = **72.78 %**  
- **Lower bound** = 55.14 % – 17.64 % = **37.50 %**  

> **Interpretation**: In about two‑thirds of the possible worlds, a one‑year hold of this five‑stock mix will earn you somewhere between **+37.5 %** and **+72.8 %**.  

### Common questions that pop up (and why they’re worth a chuckle)

1. **“Wait, the range never goes negative—how can I possibly lose money?”**  
   Good catch. The math is based on a *bullish* period (April–May 2017) and on a relatively short data window, so the numbers are positively biased. If you fed the model a full year (or more) of data that includes bear phases, the lower bound would dip lower—maybe even negative.  

2. **“What does 68 % confidence really mean?”**  
   It means that if you repeated this experiment (the same portfolio, same market conditions) 100 times, about 68 of those years would see the return land inside the 37.5 %–72.8 % band.  

3. **“I want to be more certain. Can I crank the confidence up?”**  
   Absolutely—just move to higher sigma levels.  

### 2‑σ (≈95 % confidence)  

- **Upper bound** = 55.14 % + 35.28 % = **90.42 %**  
- **Lower bound** = 55.14 % – 35.28 % = **19.86 %**  

Now we’re saying “There’s a 95 % chance the return will fall somewhere between roughly **+20 %** and **+90 %**.”  

### 3‑σ (≈99 % confidence)  

- **Upper bound** = 55.14 % + 52.92 % = **108.06 %**  
- **Lower bound** = 55.14 % – 52.92 % = **2.22 %**  

With a 99 % confidence level, the band widens dramatically: **+2 %** to **+108 %**. As you can see, higher confidence means a *broader* (and more conservative) range.  

> **Takeaway**: The more certainty you demand, the larger the interval you have to accept.  

---

### Your homework (because learning never stops at the bar)

1. **Plot the frequency distribution** of the 5‑stock portfolio returns. Do you see a bell curve? If not, investigate why.  
2. **Resize the horizon**: What would the confidence interval look like for a 3‑month or a 3‑week holding period? Hint: Scale the variance by √(time‑fraction).  
3. **Comment**: Share your findings, surprises, or existential dread in the comment box below.  

Feel free to **download the Excel sheet** used in this chapter and play around.  

---

### Key takeaways from this chapter  

- The portfolio’s return is a weighted sum of its constituent stocks’ returns.  
- To gauge a single stock’s contribution, multiply its average return by its portfolio weight.  
- Expected portfolio return = Σ (weight × annualised stock return).  
- Convert daily variance to annual variance by multiplying by √252.  
- The calculated variance is the **first standard deviation** (σ).  
- Second and third σ are simply 2×σ and 3×σ, respectively.  
- Expected return can be expressed as a *range* around the mean by adding/subtracting σ‑multiples.  
- Each σ‑band corresponds to a confidence level (68 %, 95 %, 99 %).  
- Higher confidence → wider range, because you’re being more conservative about where the returns could land.  

Enjoy the numbers, respect the risk, and may your portfolios always be as smooth as a perfectly poured pint. Cheers!