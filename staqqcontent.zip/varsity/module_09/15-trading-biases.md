# 15. Trading Biases  

**Source:** <https://zerodha.com/varsity/chapter/trading-biases/>  

---  

## 15.1 – Mind games  

If you ever wander into a WhatsApp group that lives and breathes stock‑market gossip, you’ve probably seen that legendary clip that circulates like a meme‑ish “funny cat video” but with more numbers.  

**No time to watch?** No worries, I’ll give you the TL;DR: a caller on a live‑call‑in show asks the host how to turn 20,000 physical MRF Ltd. certificates (yes, paper‑stock, the kind you’d keep in a shoebox) into a DEMAT entry. The host, after walking him through the boring paperwork, drops the bomb‑shell value of those shares in today’s market.  

- Current MRF price ≈ **₹64,000** per share.  
- 20,000 shares × ₹64,000 = **₹1,280,000,000**  
- That’s **₹128 crore** – i.e. **ONE HUNDRED TWENTY‑EIGHT CRORE**.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2017/10/M9-C15.png)

I was left staring at the screen like a kid who just discovered the candy aisle. My brain shouted, “Who in their right mind bought MRF 25 years ago? And why didn’t they cash out after the first 2‑3 times the price doubled?”  

A “regular” investor, in my humble opinion, would have sold once the trade showed a **50 %**, **100 %** or maybe a **200 %** gain. This granddad, however, let his paper‑shares sit in the attic for a quarter of a century, watching the stock multiply by **≈ 20 times** (that’s a **2,000 %** return!).  

### What’s really happening?  

When I replayed the clip a few more times (and pretended I was a detective on a true‑crime show), the story unfolded like this:  

| Observation | What it tells us |
|-------------|-----------------|
| Grandfather bought the shares in the 90s and then **forgot** about them. | He wasn’t tracking the market, so he never felt the urge to sell. |
| The grandson finally discovers the dusty certificates and calls the show. | The knowledge of the holding is *new* to the family. |
| The grandson wants to dematerialise them ASAP. | He’ll probably **sell** the moment they appear in his DEMAT account. |

From this little drama we can draw a few solid conclusions:  

1. **Forgetting = free‑lunch profit** – Granddad didn’t watch the price, didn’t feel fear or greed, and thus let the asset sit.  
2. **If he’d been reminded** (daily broker alerts, a nosy neighbour, a chat‑bot that says “Hey, MRF just hit ₹64k!”) he *might* have sold long before the ₹128 crore milestone.  
3. **Human nature loves a good story** – we tend to imagine we’d act rationally, but the truth is our brains are wired with shortcuts (aka *biases*).  

So the moral of the story: **Sometimes ignorance is bliss, and in investing, it can be *very* profitable**.  

Now picture the opposite scenario: a well‑meaning broker calls every morning, “Your MRF is up 5 % today, you should consider taking profit!” Would our granddad have let that ride? Highly unlikely. He would have probably sold at a modest **100 %** gain, missing out on the **2,000 %** ride.  

That, my friends, is the perfect segue into the next section. The mind‑games we play (or don’t play) are the *biases* that either make us rich or keep us flat‑broke. In the next couple of chapters we’ll dissect a few of the most common ones and, more importantly, learn how to dodge them like a seasoned ninja‑trader.  

---  

## 15.2 – Illusion of Control  

Let’s start with a bias that haunts every technical‑analysis‑addict like a ghost in a haunted house. Picture the most cluttered chart you’ve ever seen on a trader’s screen:  

- Candlesticks showing price swings  
- Bollinger Bands (the “wiggle‑room” indicator)  
- Fibonacci retracements (the “golden ratio” of traders)  
- Pivot points (support & resistance – the market’s traffic lights)  
- Volume histogram (how loud the market is shouting)  
- ATR (Average True Range – a fancy way of saying “how volatile are we?”)  
- Stochastic oscillator (the market’s mood swings)  

If you’ve ever sat at a desk with **eight or more** of those gadgets flashing, you’ll know the feeling: you look at the screen and *feel* like you’re the wizard of Wall Street, conjuring spells from a cauldron of numbers.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2017/10/Image-1_ioc.png)

Each widget whispers a “secret” to you, but there’s a sneaky side‑effect. Because the chart is so dense, our brain tells us:  

> “I’m looking at a **complex** system, therefore I must be **in control**.”  

That’s the **Illusion of Control** – a bias that makes traders think they’ve tamed the wild beast of the market simply by loading a dozen indicators. You’ll hear people brag, “The stock can’t go past **₹500**,” or, more dramatically, “Buy the puts, I’m 99 % sure it’ll crash!” and when you ask *why*, they’ll fire back with a wall of technical jargon.  

### Why does this happen?  

1. **Complexity feels powerful** – Humans love to feel smart. If you can read a chart that looks like a spaceship’s control panel, you instantly feel superior to the guy who only watches the price line.  
2. **Confirmation bias** – You’ll latch onto the few indicators that *agree* with your gut feeling and ignore the rest, reinforcing the belief that you’ve cracked the code.  
3. **The “I’m the only one who gets it” high** – When everyone else sees a mess and you see order, it’s a ego boost.  

But the truth is simple: **No amount of lines, colors, or numbers can guarantee you’ll predict the next market move**. Markets are stochastic (that’s a fancy word for “random”), and for every scenario you model, there are dozens of alternative outcomes you haven’t considered.  

### How to kick the illusion to the curb  

- **Focus on results, not inputs.** If you have a trading system, measure its *win‑rate*, *average profit*, *drawdown*, and *expectancy*. Those are the real numbers that matter.  
- **Embrace simplicity.** A single‑moving‑average crossover or a well‑back‑tested breakout rule often outperforms a chart that looks like a NASA flight deck.  
- **Stay humble.** Remind yourself daily that the market can be irrational, and that you’re only one participant among millions.  

Bottom line: **Complex ≠ Better**. Your edge will come from a **data‑driven, statistically sound** approach, not from the sheer volume of indicators you can cram onto a screen.  

---  

## 15.3 – Recency Bias  

Here’s another bias that creeps into even the most seasoned trader’s brain like a sneaky cat. No matter how many years you’ve been in the game, you’ll eventually fall victim to it. Let me give you a fresh, juicy example.  

### The CCD saga  

If you’ve been following **Café Coffee Day Enterprises (CCD)**, you know the drama: the Income Tax Department raided the company for alleged tax evasion and “hoarding of undisclosed income.” A couple of days ago, *The Economic Times* ran a front‑page story that read (paraphrased):  

> “CCD under scanner for massive tax evasion, authorities seize documents.”  

![Image](https://zerodha.com/varsity/wp-content/uploads/2017/10/image-2_raid.png)

My personal rule of thumb is simple: **If a company’s corporate governance is sketchy, stay away**, even if the valuation looks like a bargain. History shows that such stocks eventually implode.  

Now, imagine you already own CCD and that headline pops up. Assuming the story is accurate, the logical move is **exit immediately**, regardless of the paper profit or loss you’d incur.  

A good family friend called me two days after the news, asking for advice. By then the hype had settled a bit, but the scandal was still fresh. I told him to sell. He pulled up the latest price chart:  

![Image](https://zerodha.com/varsity/wp-content/uploads/2017/10/Image-3_ccd.png)

Notice the **green candle** right after the steep drop? It looks like a few buyers are trying to “bottom‑fish.”  

He said, “Maybe I’ll hang on a few more days; the price might bounce higher.” I didn’t argue further; I just let him make his own call.  

### Why did he cling to the stock?  

Because that **recent green candle** made him think the worst was over. He let the newest data point **override** the much older, but far more important, fact that the company might be hiding money.  

That’s **Recency Bias** in action: we overweight the latest information and under‑weight the historical context.  

- **Recent event:** a small uptick, a bullish news flash, a hot‑off‑the‑press analyst note.  
- **Historical event:** a massive fraud, a broken business model, a long‑term regulatory risk.  

Our brains love the *shiny new thing* and tend to discount the *dusty old truth*. In my friend’s case, the fresh candle gave him false confidence that a rally was imminent, even though the underlying corporate problem remained.  

### How to dodge this bias  

1. **Step back and zoom out.** Look at the company’s five‑year track record, governance score, and fundamentals, not just the last day’s candle.  
2. **Create a checklist.** Before you act on any new piece of information, ask: “Does this fundamentally change the business, or is it just a market reaction?”  
3. **Stick to a thesis.** If you invested because you believed the business was sound, a single news flash can’t overturn that unless it changes the core economics.  

In short, **don’t let the latest headline rewrite the entire story**.  

---  

## Key takeaways from this chapter  

- **Complex markets don’t require complex charts.** Simplicity often wins.  
- **Over‑loading a chart feeds the illusion of control.** More lines ≠ more power.  
- **Illusion of control wastes time** on analysis that doesn’t improve your edge.  
- **Quantity ≠ quality.** One well‑chosen indicator can beat ten noisy ones.  
- **Recency bias blinds you to past facts** that may have a larger impact on price.  
- **Adopt a big‑picture view** – keep the long‑term narrative in front of you, and you’ll be less likely to chase every shiny new candle.  

Stay aware, stay humble, and let the data (not your ego) call the shots. Happy (and bias‑free) trading!  