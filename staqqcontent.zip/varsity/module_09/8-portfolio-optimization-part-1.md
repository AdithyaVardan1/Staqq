# 8. Portfolio Optimization (Part 1)

**Source:** https://zerodha.com/varsity/chapter/port-opt/

---  

##  

![Image](https://zerodha.com/varsity/wp-content/uploads/2017/06/M9-C8-Cartoon.png)

## 8.1 – A Tale of 2 Stocks  

We’ve already been knee‑deep in the swamp of portfolio risk, and now it’s time to climb out on the other side and talk about **portfolio optimization**. Think of it as giving your portfolio a personal trainer: “Hey, let’s get those numbers in shape!”  

Before we dive in, a quick brain‑teaser: *What’s the expected return of a portfolio that’s half‑Infy, half‑Biocon?* (Infy = Infosys, Biocon = Biocon Ltd.) Assume Infosys is expected to give you **22 %** and Biocon **15 %**.  

I know, sounds like a typical MBA pop‑quiz, but you’ll need this for the next round of drinks.  

Since the portfolio is **equally weighted**, we simply do the weighted‑average dance:

\[
\text{Portfolio Return}=0.5\times22\%+0.5\times15\%
\]

\[
=11\%+7.5\%=18.5\%
\]

So, with a 50/50 split you’d be looking at **18.5 %** annual return. Not bad—your future self will thank you for the extra chai money.  

Now, what if we mess with the weights?  
*Case 1*: 30 % Infosys, 70 % Biocon  

\[
0.3\times22\%+0.7\times15\% = 6.6\%+10.5\% = 17.1\%
\]

*Case 2*: 70 % Infosys, 30 % Biocon  

\[
0.7\times22\%+0.3\times15\% = 15.4\%+4.5\% = 19.9\%
\]

**Bottom line:** Shift the weights, shift the returns.  

Below is a tiny cheat‑sheet of other weight combos (yes, we actually made a table in the original, but the image does the heavy lifting):

![Image](https://zerodha.com/varsity/wp-content/uploads/2017/06/Image-1_wt.png)

You can see the pattern: 40 % Infosys / 60 % Biocon gives **17.8 %**, while 60 % Infosys / 40 % Biocon bumps you up to **19.2 %**—a neat **2 %** extra just by swapping a few rupees around.  

That brings us to a *golden* conclusion: **Changing the weights changes both return *and* risk**. Each weight set is a different portfolio with its own risk‑return personality.  

Now picture this: you have a portfolio with *n* stocks, and you could magically look at the historic data, run a few equations, and spit out the “perfect” allocation that gives you the *best* possible return.  

That’s **portfolio optimization** in a nutshell. In practice you can tell the optimizer to:

- **Maximise return** for a given set of stocks, *or*  
- **Minimise risk** (variance) for the same set.

Sounds like wizardry? Stick around, we’ll demystify it together.  

## 8.2 – Caution! Jargon Ahead  

By now you should be sold on why we need to optimise—no more “let’s just throw money at everything” talk. Let’s get acquainted with the fancy‑sounding terms you’ll bump into in the next few pages.

### Minimum‑Variance Portfolio  
Imagine you have **10** different stocks. You can shuffle the weights around like a DJ remixing a track. Each remix (i.e., each set of weights) produces a **unique** risk‑return profile.  

One of those remixes will have the **lowest possible variance**—the **Minimum‑Variance Portfolio (MVP)**. It’s the *safest* version of your basket. If you’re the kind of investor who flinches at the sight of a 1 % dip, the MVP is your best friend.

### Maximum‑Return Portfolio  
Flip the script. The **Maximum‑Return Portfolio** is the remix that cranks the expected return up to the roof, but—spoiler alert—it also usually pumps up the risk. Think of it as the “go big or go home” cocktail.

### Fixed‑Variance, Multiple Portfolios  
Not a jargon, just a concept that will become clearer later. The idea is: **for a given level of risk (variance), you can have more than one portfolio**. One will give you the *highest* return at that risk level, another the *lowest*.  

A quick illustration (totally made‑up numbers):  

- Target variance = **15 %**  
- Portfolio A can deliver **30 %** return (the *best* you can do with that risk)  
- Portfolio B might only manage **12 %** return (the *worst* you can do with that risk)  

In between those two, a whole family of portfolios lives, each with a different return but the same 15 % risk.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2017/06/Risk-Return-diagram.png)

We’ll revisit this “risk‑return frontier” later, but keep it in the back of your mind like a catchy chorus you can’t shake off.  

## 8.3 – Portfolio Optimisation (Steps)

Alright, time to roll up our sleeves and actually **optimise** the portfolio we’ve been tinkering with. Here’s a quick reminder of the stocks and the *random* weights we slapped on earlier (no, we didn’t use a magic 8‑ball).

![Image](https://zerodha.com/varsity/wp-content/uploads/2017/06/Image-2_port.png)

Those arbitrary weights gave us an **annual variance of 17.64 %** and an **expected return of 55.14 %**—pretty flashy, but not necessarily optimal.  

### Getting Solver on Board  
To do any serious optimisation in Excel you’ll need the **Solver** add‑in (it lives under the *Data* ribbon). If you don’t see it, follow these steps:

1. Click **File** → **Options** → **Add‑ins**.  
2. At the bottom, pick **Solver Add‑in** and click **Go**.  
3. Check the box for **Solver Add‑in**, hit **OK**, and maybe give Excel a quick reboot.  
4. Return to the *Data* tab; Solver should now be chilling there.

### Step 1 – Organise Your Data  
Solver is a bit like a neat‑freak roommate: it loves tidy, linked cells and hates hard‑coded numbers. Lay out your spreadsheet so that:

- The **weight cells** (top section) are ready to be changed.  
- The **expected‑return** and **portfolio‑variance** formulas (second section) reference those weight cells.

Here’s a snapshot of how it should look:

![Image](https://zerodha.com/varsity/wp-content/uploads/2017/06/Image-4_organize.png)

Notice the two highlighted blocks? Those are the ones we’ll be playing with.  

### Step 2 – Tell Solver What to Do  

#### What is an “objective”?  
Think of the objective as the goal‑post you set for Solver. It’s a single cell whose value you either **minimise**, **maximise**, or **hit a target** for, by tweaking *variables* (in our case, the weights).  

For a **minimum‑variance** run, the objective is the cell that contains **annual portfolio variance**.  

#### Setting it up  

1. Click **Data** → **Solver**.  
2. In the **Set Objective** box, click the cell that holds the variance.  
3. Choose **Min** (we want the smallest possible variance).  

![Image](https://zerodha.com/varsity/wp-content/uploads/2017/06/Image-5_invok-solver.png)

4. In **By Changing Variable Cells**, select the whole column of weight cells.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2017/06/Image-6_port-var.png)

5. Now add a **constraint** so that the sum of all weights equals **100 %** (we want to invest all our cash, not keep a pile of dust under the mattress).  

   - Click **Add…**  
   - For **Cell Reference**, pick the cell that sums the weights.  
   - Set the relationship to **=** and type **100%**.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2017/06/Image-8_constraint.png)

6. Your final Solver window should look something like this:

![Image](https://zerodha.com/varsity/wp-content/uploads/2017/06/Image-10_solver.png)

All set! Hit **Solve** and watch Solver do its magic.  

### What Solver Gives You  

After a few milliseconds (or a few minutes if your computer is still on dial‑up), Solver pops up with a new set of weights:

![Image](https://zerodha.com/varsity/wp-content/uploads/2017/06/Image-11_solved.png)

A quick read‑out:  

- **Cipla** jumps from **7 %** to **29.58 %**.  
- **Idea** drops from **16 %** to **5.22 %**.  
- The **minimum achievable variance** for this five‑stock basket is now **15.57 %** (down from 17.64 %).  
- The **expected return** slides down to **36.25 %** (from the flashy 55.14 %).  

In plain English: you can’t shave the risk below **15.57 %** if you insist on holding exactly these five stocks. The trade‑off is a lower expected return—nothing in finance is free, right?  

That’s the crux of optimisation: you pick the point on the risk‑return spectrum that feels right for your nerves and your wallet.

I’ll leave you here to sip your coffee and let the numbers settle. In the next chapter we’ll crank the optimizer for a few more scenarios and finally draw the legendary **Efficient Frontier**—the “sweet spot” where you get the most bang for your buck.

Feel free to **download the Excel sheet** used in this demo (it already contains the minimum‑variance weights).  

### Key Takeaways  

- **Portfolio returns move in lockstep with the weights you assign** to each stock.  
- The **Minimum‑Variance Portfolio (MVP)** is the weight combo that gives you the *least* possible risk for the chosen basket.  
- The **Maximum‑Return Portfolio** pushes expected returns up, usually at the cost of higher risk.  
- **Fixing the variance** (risk) yields at least two distinct portfolios: one with the *highest* possible return at that risk, and another with the *lowest*.  
- Excel’s **Solver** is a handy tool to optimise a portfolio with any number of stocks—just make sure your spreadsheet is tidy and all cells are linked, not hard‑coded.  
- Always **apply constraints** (like “weights sum to 100 %”) so Solver doesn’t hand you a nonsensical solution (e.g., “invest -5 % in a stock”).  

Now go forth, play with weights, and may the variance be ever in your favour!  