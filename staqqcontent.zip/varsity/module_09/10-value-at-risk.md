# 10. Value at Risk  

**Source:** https://zerodha.com/varsity/chapter/var/  

---  

## 10.1 – Black Monday  

Alright, buckle up, time‑travelers. Picture the 1970s: bell‑bottoms, disco balls, and the kind of rock anthems that made you want to grow a mustache. While the world was busy “stayin’ alive,” Wall Street was having a mid‑life crisis.  

The oil shock of the ’70s turned the U.S. economy into a sluggish, inflation‑cooking pot, and unemployment rose faster than a pop‑up concert ticket price. (Maybe that’s why everyone started writing songs about heartbreak—​they were just *really* feeling the heat.) By the late ’70s the economy finally inhaled a sigh of relief, the Fed turned the knobs in the right direction, and the early ’80s saw the market doing a victory lap.  

From the early ’80s up to mid‑1987 the Dow strutted its stuff, hitting an all‑time high of **2,722** in August ’87 – a sweet **≈44 %** gain over 1986. Traders called it “the dream bull run.” Then, just as the market was polishing its trophy, the economy started to take a “soft landing” (i.e., a polite nap).  

**Enter the drama:**  
- **Aug‑Oct 1987:** The market was stuck in a “hold‑my‑beer” limbo. Every tiny dip sparked a fresh wave of leveraged longs, while equally eager shorts were being unwound. The result? A market that was neither a rally nor a correction – it was basically a very indecisive teenager.  
- **Mid‑October:** While the U.S. was busy watching its own roller‑coaster, the Middle East was staging a fireworks show of its own. Iran launched a Silkworm missile at an American super‑tanker near Kuwait’s oil port.  

Now, let’s roll out the red‑carpet timeline of the most chaotic week ever:

| Date | What Happened? |
|------|----------------|
| **14 Oct 1987 (Wed)** | Dow slid **≈4 %** – a record‑breaking nosedive for that era. |
| **15 Oct 1987 (Thu)** | Another **2.5 %** drop. The Dow was now **≈12 %** below its August peak. Across the globe, the missile strike added a side of geopolitical terror. |
| **16 Oct 1987 (Fri)** | London got hit by a 175 km/h storm that blacked out the financial district. The city’s market shut its doors. The Dow opened weak, then **crashed ~5 %**, prompting the Treasury Secretary to sound the economic alarm. |
| **19 Oct 1987 (Mon) – “Black Monday”** | The panic spread like a bad Wi‑Fi signal: Hong Kong trembled first, then London, and finally the U.S. The Dow closed **508 points** lower – a **22.61 %** plunge in a single day. Hence, “Black Monday.” |

Nobody had seen a crash of that magnitude. It was the financial world’s first taste of a true **Black Swan** (the term would be coined later, but you get the idea). When the dust settled, a new breed of Wall Street nerds emerged, proudly calling themselves **“Quants.”**  

![Cartoon of the 1987 crash](https://zerodha.com/varsity/wp-content/uploads/2017/07/M9-C10-cartoon.png)  

---  

## 10.2 – The Rise of Quants  

The October‑1987 carnage left regulators clutching their pearls and asking, “How on earth do we survive a repeat?” Financial firms realized they needed a crystal ball to gauge the probability of a **firm‑wide survival** if another catastrophe struck.  

Remember: the textbook said a crash like 1987 was *practically impossible*, yet it happened. So, banks started asking themselves, “What if the next Black Swan decides to wear a tuxedo?”  

Enter the **Quants**—a motley crew of PhDs in statistics, physics, mathematics, and old‑school finance. Their mission? Build razor‑sharp models that could monitor every position in real time, like a hawk on a caffeine binge. Risk management was promoted from the basement to the **middle office**, and suddenly “risk” became a buzzword that could earn you a fancy title.  

The crown jewel of this era was the **4:15 PM report** at JP Morgan. CEO Dennis Weatherstone demanded a one‑page snapshot of the firm’s total risk **exactly 15 minutes after market close**. It became the holy grail of risk‑management, so much so that JP Morgan published the methodology and handed the underlying parameters to rival banks.  

Later, JP Morgan spun off the team as **Risk Metrics Group**, which was eventually snapped up by MSCI.  

What did that magical one‑pager contain? The **Value at Risk (VaR)** metric – the “what‑if‑the‑worst‑thing‑ever‑happens‑tomorrow” number.  

From here on, this chapter is all about **VaR for your portfolio**. Grab a drink, we’re about to demystify it.  

---  

## 10.3 – Normal Distribution  

The heart‑and‑soul of VaR is the **normal (bell‑curve) distribution**. We’ve already flirted with it in earlier Varsity chapters, so I won’t re‑teach you calculus. Assume you know the classic “68‑95‑99.7 rule.”  

In plain English, VaR is a **quick‑and‑dirty** way to gauge the worst‑case loss for a “buy‑and‑hold” equity portfolio. It answers two simple questions:  

1. **If a Black Swan shows up tomorrow, how deep could my portfolio dip?**  
2. **What’s the probability attached to that dip?**  

Here’s the cheat‑sheet for calculating portfolio VaR:  

1. **Identify** the distribution of portfolio returns.  
2. **Map** it – verify the returns look “normally distributed.”  
3. **Sort** returns from lowest (most negative) to highest.  
4. **Pick** the observation at the 95 % cutoff (i.e., the 5 % worst).  
5. That value is your **Portfolio VaR**.  
6. **Average** the bottom 5 % of observations to get **Conditional VaR (CVaR)**.  

Now, let’s walk through this with the same portfolio we’ve been toying with all semester.  

---  

## 10.4 – Distribution of Portfolio Returns  

We’ll tackle steps 1 and 2 from the list above: figuring out what kind of distribution our portfolio returns follow. You can use **normalized returns** (the same ones we plotted in the “equity curve” earlier).  

Below is a snapshot of those daily returns (you’ll find them in the sheet named **“EQ Curve”**):  

![Daily returns chart](https://zerodha.com/varsity/wp-content/uploads/2017/07/Image-1_daily-rts.png)  

For the tutorial, I copied those numbers into a fresh sheet to keep things tidy:  

![Raw data in Excel](https://zerodha.com/varsity/wp-content/uploads/2017/07/Image-2_raw-data.png)  

**Goal:** Determine the distribution type (hint: we’re hoping for a bell).  

### Step 1 – Find max & min return  

Use Excel’s `=MAX()` and `=MIN()` functions:  

![Max/min in Excel](https://zerodha.com/varsity/wp-content/uploads/2017/07/Image-3_maxmin.png)  

### Step 2 – Count data points  

`=COUNT()` tells us how many observations we have. In this demo we have **126** daily returns (roughly six months). Ideally you’d use a full year, but this will do for illustration.  

![Count in Excel](https://zerodha.com/varsity/wp-content/uploads/2017/07/Image-4_count.png)  

### Step 3 – Compute bin width  

We’ll bucket returns into **25** bins (a rule‑of‑thumb for ~100‑ish points).  

```
Bin width = (Max – Min) / 25
          = (3.26 % – (‑2.82 %)) / 25
          = 0.002431  (≈0.243 %)
```  

### Step 4 – Build the bin array  

Start at the minimum return and keep adding the bin width until you hit the maximum. For example:  

- Bin 1 = –2.82 %  
- Bin 2 = –2.82 % + 0.002431 = –2.58 %  
- …continue until you reach 3.26 %  

The resulting table looks like this (truncated for brevity):  

![Bin array (partial)](https://zerodha.com/varsity/wp-content/uploads/2017/07/Image-5_Bin-array.png)  

And the full list:  

![Full bin list](https://zerodha.com/varsity/wp-content/uploads/2017/07/Image-6_Bin-array-list.png)  

### Step 5 – Frequency of returns per bin  

Now we ask, “How many days did we see a return that falls into each bin?” Excel’s `=FREQUENCY()` does the heavy lifting. The output (again, trimmed) looks like:  

![Frequency output](https://zerodha.com/varsity/wp-content/uploads/2017/07/Image-7_freq.png)  

Interpretation: out of 126 days, **1** observation landed exactly at –2.82 %; **0** days fell between –2.82 % and –2.58 %; **13** days were between 0.34 % and 0.58 %, and so on.  

To generate the frequencies, select the cells next to the bin array, type `=FREQUENCY(`, feed the two ranges, and press **Ctrl + Shift + Enter** (the magic array‑formula combo).  

![Formula bar entry](https://zerodha.com/varsity/wp-content/uploads/2017/07/Image-8_freq-data.png)  

### Step 6 – Plot the distribution  

Select the frequency column and insert a **column (bar) chart**.  

![Bell‑shaped chart](https://zerodha.com/varsity/wp-content/uploads/2017/07/Image-9_bell.png)  

Boom! A nice, symmetric bell curve appears, suggesting our returns are **approximately normally distributed**. That’s the green light to move on to VaR calculations.  

---  

## 10.5 – Value at Risk  

Now that we’ve confirmed the bell‑shape, let’s compute VaR. The trick is to **sort** the returns from the most negative to the most positive.  

![Sorted returns](https://zerodha.com/varsity/wp-content/uploads/2017/07/Image-10_reordered.png)  

Excel’s **Sort** function does the job in seconds.  

### Portfolio VaR  

- **Total observations:** 126  
- **95 % of 126 ≈ 120** (round down).  

The **Portfolio VaR** is the **120th‑largest (i.e., the 6th‑most‑negative)** return – the “worst loss you’d expect 95 % of the time.” In our data that number is **‑1.48 %**.  

### Conditional VaR (CVaR)  

Take the **average** of the bottom **5 %** (the last 6 observations). That yields a **CVaR of ‑2.39 %**.  

#### Quick FAQ (served with a side of sarcasm)

| Q | A |
|---|---|
| **Why plot the frequency distribution?** | To prove the returns look bell‑shaped. If they looked like a J‑shape, we’d be in trouble. |
| **Why care about “normal” distribution?** | Because normality gives us handy shortcuts (68‑95‑99.7 rule) and lets us use VaR formulas with confidence. |
| **What are the key traits of a normal curve?** | Roughly 68 % inside 1 σ, 95 % inside 2 σ, 99.7 % inside 3 σ. (Read the “Normal Distribution” chapter for the nerdy proofs.) |
| **Why sort the data?** | Sorting isolates the tail – the part we actually care about when we fear a crash. |
| **Why only the worst 5 %?** | The 95 % confidence interval says “I’m comfortable that the loss won’t be worse than this 5 % of the time.” |
| **What does a VaR of –1.48 % mean?** | With 95 % confidence, you won’t lose more than 1.48 % of your portfolio in a single day. |
| **Can the loss be worse than –1.48 %?** | Absolutely. That’s what **CVaR** captures – on the *worst* 5 % of days, you might lose about **‑2.39 %** on average. |
| **Can we lose even more than –2.39 %?** | Yes, but the odds drop off sharply. Think of it as the “once‑in‑a‑blue‑moon” scenario. |
| **Is VaR a crystal ball?** | No, it’s a statistical estimate. Treat it like a weather forecast: useful, but bring an umbrella just in case. |

> **TL;DR:** VaR tells you the *maximum* daily loss you’re **95 % confident** you won’t exceed; CVaR tells you the *average* loss *if* you do end up in that nasty tail.  

Apply this on your own equity portfolio (or that crypto stash you keep under the mattress) and you’ll get a much clearer picture of how much you could be burned if the market decides to throw a tantrum.  

> **Next stop:** risk analysis for individual **trading positions** (because a portfolio is only as strong as its weakest trade).  

Download the Excel workbook used in this chapter to follow along step‑by‑step.  

---  

### Key takeaways from this chapter  

- **Black‑Swan events** are low‑probability, high‑impact market crashes (think “the universe just tripped over its own shoelace”).  
- When a Black Swan hits, portfolios can suffer outsized losses.  
- **Value at Risk (VaR)** estimates the worst‑case daily loss at a chosen confidence level (commonly 95 %).  
- You obtain VaR by **studying the distribution** of portfolio returns and locating the appropriate percentile.  
- The **average of the worst 5 %** of observations gives you the **Conditional VaR (CVaR)**, a more conservative risk measure.  

Now go forth, crunch those numbers, and may your VaR be low and your coffee be strong. Cheers!  