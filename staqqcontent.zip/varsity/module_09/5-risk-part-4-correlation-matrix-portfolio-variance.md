# 5.    Risk (Part 4) – Correlation Matrix & Portfolio Variance  

**Source:** <https://zerodha.com/varsity/chapter/risk-part-4-correlation-matrix-portfolio-variance/>

---  

## 5.1 – Correlation Matrix  

![Image](http://zerodha.com/varsity/wp-content/uploads/2017/04/M9-C5-cartoon.png)  

In the last chapter we wrestled with the variance‑covariance matrix and emerged with a table of numbers that looked like the output of a sci‑fi calculator—tiny, cryptic, and frankly, not very “Instagram‑able.”  
The good news? Once you have the variance‑covariance matrix, whipping up a **correlation matrix** is as easy as adding a splash of lemon to a martini. It makes the numbers human‑readable, lets you spot which stocks move together, and saves you from the “what‑the‑heck‑is‑this?” stare.

### How do we actually compute the correlation between two stocks?  

If you kept your notes from the previous chapter, you’ll remember the classic formula:  

![Image](http://zerodha.com/varsity/wp-content/uploads/2017/04/Correlation-Formula.png)  

where  

* **Cov(x, y)** = covariance between the two stocks  
* **σₓ** = standard deviation of stock **x**  
* **σᵧ** = standard deviation of stock **y**  

That works fine for a two‑stock cocktail, but our portfolio is a five‑drink happy hour, so we need a *matrix* (read: “n by n” where *n* = 5) to keep track of every possible pair.

### From variance‑covariance to correlation  

First, a quick refresher: here’s the variance‑covariance matrix we already built (you might recall the blood‑sweat‑tears you poured into it).  

![Image](http://zerodha.com/varsity/wp-content/uploads/2017/04/Image-1_covar.png)  

That matrix gives us the **numerator** of the correlation formula for every pair. All that’s left is the **denominator**—the product of the two standard deviations for each pair.  

If we have five stocks, there are 5 × 5 = 25 possible combinations (including each stock with itself). We’ll get those products by multiplying the **standard‑deviation vector** by its own transpose.

### Step‑by‑step in Excel (or any spreadsheet that pretends to be a wizard)  

1. **Calculate each stock’s standard deviation** – use `=STDEV()` on the daily‑return column. I already did it, and here’s the snapshot:  

   ![Image](http://zerodha.com/varsity/wp-content/uploads/2017/04/Image-2_stdev.png)  

2. **Create the “SD‑by‑SD” matrix** – select a 5 × 5 range, type `=MMULT(TRANSPOSE(SD_range),SD_range)`, then slam **Ctrl + Shift + Enter** (the secret handshake for array formulas).  

   The skeleton before you hit the keys looks like this (all cells highlighted for dramatic effect):  

   ![Image](http://zerodha.com/varsity/wp-content/uploads/2017/04/Image-3_product-of-sd.png)  

   After the magic?  

   ![Image](http://zerodha.com/varsity/wp-content/uploads/2017/04/Image-4_SDS.png)  

   And finally the result:  

   ![Image](http://zerodha.com/varsity/wp-content/uploads/2017/04/Image-5_sd-calculated.png)  

3. **Divide the variance‑covariance matrix by the SD‑product matrix** – another array division, so again **Ctrl + Shift + Enter**.  

   The formula (for those who love to see the ugly):  

   ![Image](http://zerodha.com/varsity/wp-content/uploads/2017/04/Correlation-Formula.png)  

   Numerator = covariance matrix (see image below).  

   ![Image](http://zerodha.com/varsity/wp-content/uploads/2017/04/Image-6_covar.png)  

   Denominator = the SD‑product matrix we just built.  

   ![Image](http://zerodha.com/varsity/wp-content/uploads/2017/04/Image-7_division.png)  

4. **Voilà – the correlation matrix!**  

   ![Image](http://zerodha.com/varsity/wp-content/uploads/2017/04/Image-8_correl-mat.png)  

   What does it tell us? Pick any two stocks, say **Cipla** and **Alkem**, and read the intersecting cell. You have two ways to get there:  

   * Scan the **Cipla** row until you hit the **Alkem** column.  
   * Or scan the **Alkem** row until you hit the **Cipla** column.  

   Both roads lead to the same destination: **0.2285**. That’s because correlation is symmetric – the love (or hatred) that Cipla feels for Alkem is reciprocated. The matrix is therefore mirrored around the diagonal, a bit like a perfectly balanced seesaw.

   I’ve highlighted that pair for you:  

   ![Image](http://zerodha.com/varsity/wp-content/uploads/2017/04/Image-9_Cipla.png)  

   **Key observations**  

   * The **diagonal** entries are always **1** – a stock is perfectly correlated with itself (obviously!). Those golden 1’s are highlighted in yellow in the original screenshot.  
   * Values above the diagonal are a carbon copy of those below it—symmetry galore.  

That’s the correlation matrix in a nutshell (or in a cocktail glass, if you prefer).  

## 5.2 – Portfolio Variance  

Now that we can see how each pair of stocks dances together, it’s time to answer the big question: **How risky is the whole party?** In other words, what’s the **portfolio variance**? Knowing this tells us whether our portfolio is a calm yoga class or a roller‑coaster at midnight.

### Step 1 – Assign weights  

A *weight* is simply the slice of your cash pie you allocate to each stock. Think of it as the “drink order” at the bar:  

* 100 % = All cash into one stock (the “shot” approach).  
* 50 % + 20 % + 30 % = A mixed‑drink (more balanced, fewer hangovers).  

For this demo I’ve arbitrarily handed out the following percentages (no fancy algorithm, just a random splash):  

| Stock | Weight |
|-------|--------|
| Cipla | **7 %** |
| Idea  | **16 %** |
| Wonderla | **25 %** |
| PVR   | **30 %** |
| Alkem | **22 %** |

Total = **100 %** (the universe loves balance).

### Step 2 – Compute weighted standard deviations  

A **weighted standard deviation** is just the stock’s own σ multiplied by its weight. Example:  

* Cipla’s σ = **1.49 %**  
* Weighted σ = **7 % × 1.49 % = 0.1043 %** (≈ 0.10 %).  

Do the same for all five stocks and you get:

![Image](http://zerodha.com/varsity/wp-content/uploads/2017/04/Image-10_wt.png)  

Notice the sum of the weights is still 100 %—otherwise you’d be drinking more than you have money for.

### Step 3 – The magic formula  

The portfolio variance (actually the **variance**, not the standard deviation yet) comes from a tidy matrix expression:

\[
\text{Portfolio Variance} = \sqrt{ \bigl( \mathbf{w}\sigma \bigr)^{\!\!T} \; \mathbf{C} \; \bigl( \mathbf{w}\sigma \bigr) }
\]

where  

* \(\mathbf{w}\sigma\) = column vector of **weighted** standard deviations (the “what‑if‑you‑had‑that‑much‑cash” version).  
* \(\mathbf{C}\) = correlation matrix we just built.  

In plain English: **transpose the weighted‑SD vector, multiply by the correlation matrix, then multiply by the original weighted‑SD vector, and finally take the square root**.

We’ll do this in three Excel‑friendly steps.

#### 3‑a – Row‑matrix M1  

Create a 1 × 5 row vector **M1** that equals the transpose of the weighted‑SD vector times the correlation matrix.

![Image](http://zerodha.com/varsity/wp-content/uploads/2017/04/Image-11_M1.png)  

Remember the **Ctrl + Shift + Enter** dance to lock it in as an array formula.

#### 3‑b – Scalar M2  

Now multiply **M1** (a row) by the original weighted‑SD column vector. The result is a single number we’ll call **M2**.

![Image](http://zerodha.com/varsity/wp-content/uploads/2017/04/Image-12_M2.png)  

The spreadsheet spits out **0.000123542**.

#### 3‑c – Square‑root → Portfolio variance  

Take the square root of **M2**:

![Image](http://zerodha.com/varsity/wp-content/uploads/2017/04/Image-13_port-var.png)  

The outcome is **1.11 %**. That’s the **portfolio standard deviation** (sometimes loosely called “portfolio variance” in casual conversation). In other words, the whole five‑stock cocktail is expected to swing about ±1.11 % around its average return on any given day.

> **Phew!** 🎉  
> That’s a lot of matrix gymnastics for a single number, but now you have a solid sense of how “wiggly” your basket of stocks really is.

---

### What’s next?  

Take a short break, sip water, and let the numbers settle. In the next chapter we’ll turn this variance into **Value‑at‑Risk**, **Sharpe ratios**, and maybe even a few *fun* risk‑adjusted performance metrics.  

**Download** the Excel workbook we used throughout this lesson: *(link on the original page)*.

## Key takeaways  

- The **correlation matrix** tells you the pairwise correlation between every two stocks in your portfolio.  
- Correlation is symmetric: Corr(A, B) = Corr(B, A).  
- Every stock’s correlation with itself is exactly **1**, which lives on the matrix diagonal.  
- The matrix is mirrored above and below the diagonal (think of a butterfly’s wings).  
- Portfolio variance is derived by sandwiching the correlation matrix between the **transpose of the weighted‑SD vector** and the **weighted‑SD vector** itself, then taking the square root.  

Now you’re equipped to stare at a sea of numbers and actually *know* what they mean—no more squinting at cryptic tables while the bar’s music blares. Cheers to smarter risk‑taking! 🍻