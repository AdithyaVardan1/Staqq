# 11. Position Sizing for the Active Trader  

**Source:** <https://zerodha.com/varsity/chapter/position-sizing/>

---  

##  

![Image](https://zerodha.com/varsity/wp-content/uploads/2017/07/M9-C11-cartoon.png)

## 11.1 – Poker Face  

Last month I got an invite to a poker night with a few old buddies. I hadn’t touched a deck in six years, so I was buzzing like a bee on espresso. The buy‑in? A modest **₹1,000**. (For the uninitiated, poker is that card game where you need a pinch of skill, a dash of luck, and a healthy serving of nerves of steel.)

The cards were dealt, the first betting round began and I tossed **₹200** into the pot. *Poof* – it vanished faster than my Wi‑Fi when I’m streaming a movie. Round two, another **₹200**. Same story. By the third round I thought, “Hey, I can claw my way back!” So I upped the ante to **₹600**. Guess what? The cards laughed at me and my stack disappeared again. In ten minutes I’d blown the entire **₹1,000** buy‑in. In trader‑speak that’s the equivalent of **blowing up your whole account** in the time it takes to make a latte.

Did I throw in the towel? Not a chance. I reminded myself that poker and trading are practically siblings – both love odds, psychology, and a good dose of ego‑checking. I added another **₹1,000** and dove back in, this time staying at the table for about fifteen minutes. Still, nothing changed. My memory of playing poker six years ago tells me I used to hang on longer and even snag a few wins. So why was I now getting steam‑rolled?

I was baffled, a little ashamed, and definitely not ready to accept that I’d just “wiped my account twice in twenty‑five minutes.” So I did the only logical thing a gambler does: **bought in again for another ₹1,000** – my **third buy‑in**. In the trading world that’s the same as topping up a busted account for the third time after two spectacular wipe‑outs.

*What would you tell someone who’s blown his trading account twice?*  
Probably, “Get out of the markets, stat!” Right? But the gambler’s fallacy had already hijacked my brain, and I tossed another **₹1,000** into the pot.

> **Gambler’s fallacy 101** – If you’re on a long losing streak, your mind convinces you that a win is *due* any second. You start upping the bet, hoping the next hand will be the magic one. Spoiler alert: that’s the fastest lane to a busted account.

Back to the poker table: after the third buy‑in I’d already lost **₹2,000** and was now playing with another **₹1,000**. I told myself I’d recover, maybe even make a profit, and restore my bruised pride. The other players, however, spotted the “sucker” and gladly set the trap. In the next seven minutes they **wiped me out clean**. That was it – I threw in the towel, pocketed the **₹3,000** loss, and headed home.

Post‑mortem time. The answer was glaringly simple:

- I ignored the **real odds** of the hand I was dealt.  
- I didn’t **position size** my bets – they were wild, random, and completely irrational.

A few weeks later I got another invite. I’d already built a reputation as “the guy who gives away free money,” so this round I resolved to do things differently: **size my bets properly**.

I bought in for **₹1,000** again, but this time each hand started with a quick mental check of my **probability of winning**. If the odds looked decent, I bet *that* amount – nothing more, nothing less. In trader‑land this is just a **systematic trading plan backed by proper position sizing**. The payoff?  

- I won a handful of hands.  
- At one point my bankroll swelled to roughly **₹4,000**.  
- I survived the entire session and actually **had fun** (yes, you can enjoy a game when you’re not constantly panicking).  
- I gave up a bit of the upside near the end, but I walked away **happy** because a few simple rules had turned a disaster into a decent night.

**Moral of the story:** Position sizing is the difference between “I’m a fool” and “I’m a disciplined player.” In poker you’re playing for kicks, but in trading you’re deploying real capital for a serious, life‑changing goal. So pay attention to the concepts we’ll unpack in the coming chapters – they’ll likely be the biggest boost your trading career ever gets.

*Side note:* I first learned about position sizing from **Van Tharp** – the grandmaster who popularized the concept for traders. Grab a few of his books if you want to go deeper; they’re worth the read.

---

## 11.2 – Gambler’s Fallacy  

We brushed on the gambler’s fallacy earlier, but let’s give it the spotlight it deserves, especially because markets love to masquerade as a casino.

Take a look at this chart:

![Image](https://zerodha.com/varsity/wp-content/uploads/2017/07/Image-1_Nifty.png)

It’s the **Nifty** hitting the magical **10,000** mark on **25 July 2017**. As a trader, what’s your first thought?

- **All‑time high** – the psychological level that makes many folks want to lock in profits.  
- **No obvious resistance** – after all, 10K is a fresh ceiling.  
- **Strong uptrend** over the past weeks – the market’s been on a winning streak.  
- Possible **consolidation** around this level?  
- Maybe a **2‑3 % correction** before the next rally?

All of those points are perfectly reasonable. You could decide to go **short** (or buy puts) based on that analysis, or you could build a sophisticated model using time‑series statistics or machine learning. Either way, **certainty is a unicorn** – it simply doesn’t exist in markets. The draws are essentially random. Good analysis improves your **edge**, but it never turns the odds into a guarantee.

Now picture this: you run a top‑notch analysis, place a trade on Nifty, and **the stop‑loss hits**. You’re not discouraged; you flip the switch and open another trade, only to get stopped out again. Rinse and repeat for **four more trades**.  

Your analysis? Spot‑on. Your conviction? Unshakable. Your bankroll? Still has some life left. At this point you face three tempting choices:

1. **Quit** the whole thing.  
2. **Risk the same amount** again, hoping the next trade will finally work.  
3. **Increase the stake** to recoup the prior losses **plus** a profit (the classic “double‑down” move).

Which one would you pick? Take a second and be honest.

Having lived this scenario and spoken to countless traders, the answer is almost always **option 3**. Why? Because traders **believe** that after a long losing streak the odds will “reset” and the next trade will be a winner. That’s the **gambler’s fallacy** in full swing.

The reality? In a random draw, the probability of **winning** on trade 7 is **exactly the same** as it was on trade 1. Past losses give you **no advantage** for the next bet.

The gambler’s fallacy wrecks **position sizing**. You end up **inflating** your stake without any improvement in edge, and that’s a recipe for blowing up your account.

The reverse side works the same way. Imagine you’ve just enjoyed a **10‑trade winning streak**. You’re now on trade 11 and you have four possible reactions:

- **Walk away** – you’ve taken enough profit.  
- **Risk the same amount** – you’re still feeling confident.  
- **Increase the size** – “let’s ride this wave!”  
- **Play it safe** – protect the gains by **reducing** the stake.

Most seasoned traders (the sensible ones) pick **option 4** – they shrink the position to safeguard what they’ve earned. Yet this is also a subtle form of gambler’s fallacy: the belief that after a long winning run the next trade is *more likely* to be a loss, so you **under‑size**. The odds, however, remain unchanged.

That’s why some traders, even after finding a profitable groove, end up making **tiny** money – they keep shrinking positions out of fear, or they over‑inflate after a loss out of greed.  

**The antidote?** Good, disciplined **position sizing**.

---

## 11.3 – Recovery Trauma  

Think of your trading capital as the **raw material** for any profit‑making operation. No capital → no business. So, protecting both **profits** *and* **principal** is non‑negotiable.

If you **risk too much** on a single trade, you expose yourself to a **capital‑burn** scenario. Lose a big chunk, and you’re left with a shrunken bankroll that makes every subsequent trade feel like walking a tightrope. Climbing back to where you started becomes a **Herculean** effort.

Below is a simple illustration. Suppose you start with **₹100,000**. The table (taken from the original chapter) shows how the required recovery percentage balloons as losses deepen.

![Image](https://zerodha.com/varsity/wp-content/uploads/2017/07/Image-2_Rt.png)

*You can download the Excel sheet [here](https://zerodha.com/varsity/wp-content/uploads/2017/07/Image-2_Rt.png).*

- Lose **5 %** → ₹5,000 gone, new capital = **₹95,000**. To get back to the original ₹100,000 you need a **5.3 %** return (just 0.3 % more than you lost).  
- Lose **10 %** → capital = **₹90,000**. Recovery now requires **11.1 %** (again, more than double the loss).  
- Lose **60 %** → you’re staring at a **150 %** bounce‑back target just to break even.

The deeper the hole, the steeper the climb. This phenomenon is what we call **recovery trauma**, and it hits **small‑account traders** the hardest.  

Picture a trader with **₹50,000** capital. He hears legends of Rakesh Jhunjhunwala turning **₹10,000** into **₹15 crore** and thinks, “I’ll be the next tiger!” Realistically, turning **₹50,000** into **₹60,000** in a year (a tidy **20 %** return) is already a solid achievement. But “20 %” sounds boring compared to a “10‑crore” fantasy, so the trader **over‑leverages** – risking larger slices of the bankroll to chase those “big wins.” When the market turns, the **recovery trauma** kicks in, and the trader is left scrambling to rebuild a depleted account.

Hence the golden rule: **Never risk too much on any single trade, especially with a small account.** The longer you can stay **in the game**, the higher your chances of compounding modest gains into something meaningful. Consistency > fireworks.

To sum it up:  

- Proper **position sizing** lets you survive the inevitable losing streaks.  
- It preserves enough capital to keep playing the long game.  
- It protects you from the emotional impulse to “win it all back” in one reckless bet.

I’ll close this chapter with a nugget from **Larry Hite**, a legend who built a fortune by letting his position‑size math do the heavy lifting:

![Image](https://zerodha.com/varsity/wp-content/uploads/2017/07/Larry-Hite-quote.png)

In the next few chapters we’ll dig deeper into **position‑sizing techniques** that actually work.

### Key takeaways from this chapter  

- **Position sizing** is the cornerstone of any robust trading system.  
- **Gambler’s fallacy** is a pervasive bias that convinces traders a streak will “break” – leading to oversized bets.  
- In a series of random draws, the odds of profit or loss on the *N*‑th trade are **identical** to those on the 1st trade.  
- **Recovering capital** after a loss is far tougher than it looks; the deeper the loss, the steeper the required bounce‑back.  
- Traders with **small accounts** tend to take **larger bets** to chase big returns – a habit that must be avoided for long‑term survival.  

Stay disciplined, size your positions, and let the odds do the heavy lifting while you enjoy the ride (and maybe a beer or two after a good session). Cheers!  