# 9. Portfolio Optimization (Part 2)

**Source:** <https://zerodha.com/varsity/chapter/po2/>

---  

##  

![Cartoon – “What if my portfolio could talk?”](https://zerodha.com/varsity/wp-content/uploads/2017/06/M9-C9-Cartoon.png)

## 9.1 – Working with the Weights  

Last time we cracked open Excel’s **Solver** like a bartender opening a fresh keg, and we brewed a *minimum‑variance* portfolio.  That was fun, but it was only the first sip.  Now we’ll stir the pot a little more and chase the ever‑elusive **Efficient Frontier** – the financial equivalent of the “perfect foam” on a cappuccino.

**Quick flash‑back:**  
In the previous chapter we learned that a *single* level of risk (i.e. a fixed portfolio variance) can spawn **many** different return streams, depending on how you shuffle the weights of the individual stocks.  Think of it like swapping the ingredients in a cocktail – same amount of alcohol, wildly different taste.

We had already run Solver to find the **minimum‑variance** mix.  The resulting weights looked something like this (you’ll recognise the numbers from the screenshot below):

| Stock | Weight |
|-------|--------|
| … | … |

And the resulting **expected portfolio return** and **portfolio variance** were:

* **Return:** 36.35 %  
* **Variance (risk):** 15.57 %

> **The twist:**  That was only the *lowest‑risk* cocktail.  For any given risk level you can brew a whole **range** of drinks – some bitter, some sweet.  In the next few pages we’ll taste them all.

Let’s say we’re feeling a bit adventurous and want to bump the risk up to **17 %** (just because 17 sounds like a lucky number, not because we’re gambling).  Our mission: find the **highest** and **lowest** possible returns that can live with that 17 % variance.  In other words, “what’s the best‑case and worst‑case scenario if I’m willing to tolerate this specific amount of volatility?”  

---

## 9.2 – More Optimization  

### The game plan  

1. **Start point:** Minimum risk = 15.57 %, giving us a 36.35 % return.  
2. **Step up the risk** – e.g., 17 %, then 18 %, 19 %, 21 % – and at each step capture the *max* and *min* returns **and** the accompanying weight‑vectors.  
3. **Plot them** on a scatter‑chart.  The shape that emerges is the star of the show: the **Efficient Frontier**.

That’s it.  Simple as ordering pizza, but with more math and fewer toppings.

### Let’s lock in 17 % risk  

> *“Why 17 %? Because it felt right.  It could have been 16 % or 18 % – we just picked a number that looks cool on a chart.”*

#### Step 1 – Fire up Solver  

![Invoke Solver](https://zerodha.com/varsity/wp-content/uploads/2017/06/Image-1_invoke.png)

Just like we did before, we click the **Data** ribbon → **Solver**.  The “minimum‑variance” weights we found earlier are still highlighted – they’re there for reference, like a bartender’s note on a classic recipe.

#### Step 2 – Set the objective (max‑return mode)  

We tell Solver, “Hey, make me the **biggest** possible portfolio return while staying at 17 % risk.”  Highlight the cell that holds the **expected portfolio return** and set it to **Max**.

![Set objective to maximize return](https://zerodha.com/varsity/wp-content/uploads/2017/06/Image-2_set.png)

#### Step 3 – Choose the variables (the weights)  

Select all the weight cells – those are the “ingredients” Solver can tweak.

![Select variable cells (weights)](https://zerodha.com/varsity/wp-content/uploads/2017/06/Image-3_vary.png)

#### Step 4 – Lay down the constraints  

Two simple rules keep our experiment from turning into a circus:

| Constraint | Reason |
|------------|--------|
| **Sum of weights = 100 %** | You can’t invest more than you have (unless you’re a magician). |
| **Portfolio variance = 17 %** | This pins the risk level we’re testing. |

Enter them like so:

![Constraints panel](https://zerodha.com/varsity/wp-content/uploads/2017/06/Image-4_contr.png)

Hit **Solve** and let the spreadsheet do the heavy lifting.

#### Result – Max return at 17 % risk  

![Solver result – max return](https://zerodha.com/varsity/wp-content/uploads/2017/06/Image-5_opti.png)

Boom!  Solver tells us the **maximum achievable return** with 17 % variance is **55.87 %**.  The weight‑distribution looks a bit different from the minimum‑variance mix (you’ll notice a few stocks have taken the front row, while others are hanging out in the back).

Now, let’s flip the switch and ask Solver to **minimize** the return – because we’re curious about the *worst* possible cocktail at that same risk level.

### Minimum return for the same 17 % risk  

We’ll keep everything else identical, but change the objective from **Max** to **Min**.

![Solver set to minimize return](https://zerodha.com/varsity/wp-content/uploads/2017/06/Image-7_min-risk.png)

Solver spits out:

* **Return:** **18.35 %** (the absolute low‑ball at 17 % risk)  
* **Weights:** a whole new blend (see screenshot)

So, at a fixed risk of 17 %, the **return spectrum** stretches from **18.35 %** (the party pooper) up to **55.87 %** (the life of the party).  Anything in between is possible, but it will sit *below* the line connecting these two extremes – and that line is what we’ll later call “inefficient”.

#### Recap of the three portfolios we’ve built so far  

| Portfolio | What it is | Risk (σ) | Return (μ) |
|-----------|------------|----------|------------|
| **P1** | Minimum‑variance (the “baseline”) | 15.57 % | 36.35 % |
| **P2** | Max return at 17 % risk | 17 % | 55.87 % |
| **P3** | Min return at 17 % risk | 17 % | 18.35 % |

![Three portfolios side‑by‑side](https://zerodha.com/varsity/wp-content/uploads/2017/06/Image-9_port3.png)

---

## 9.3 – Efficient Frontier  

Now that we have a couple of risk levels under our belt, we crank the risk knob a little higher: **18 %**, **19 %**, **21 %**, etc.  For each level we repeat the “max‑return” and “min‑return” dance, jotting down the resulting weights and returns.  The table below (rounded for readability) shows the final collection:

![Table of risk‑return points for each portfolio](https://zerodha.com/varsity/wp-content/uploads/2017/06/Image-10_uniq.png)

> *Pro tip:*  Rounding makes the table look pretty, but the underlying numbers are still as exact as a laser‑cut spreadsheet.

### Plotting the scatter chart  

Select the two columns (risk, return) and hit **Insert → Scatter**.  Voilà:

![Scatter plot of risk vs return](https://zerodha.com/varsity/wp-content/uploads/2017/06/Image-11_sp.png)

We tidy it up a bit (add axis titles, maybe a splash of colour) and we get the **Efficient Frontier**:

![Efficient Frontier curve](https://zerodha.com/varsity/wp-content/uploads/2017/06/Image-12_ef.png)

#### What the curve is whispering to you  

1. **Axes 101** – X‑axis = **Risk** (standard deviation), Y‑axis = **Return** (expected %).  
2. **Left‑most dot** – The lonely outlier is the **minimum‑variance portfolio** (15.57 % risk, 36.35 % return).  It’s the “safe‑seat” on the couch.  
3. **The 17 % vertical line** – You’ll see two dots:  
   * **55.87 %** (the party‑animal, max return)  
   * **18.35 %** (the wallflower, min return)  

   The space between them represents *all* other portfolios you could build at 17 % risk.  Those interior points are **inefficient** – you’re basically paying extra risk for less reward.

4. **Same story repeats** for 18 %, 19 %, 21 % – each risk level gets its own high‑and‑low dots, and the line that stitches together the *best* of each pair is the **Efficient Frontier**.  

5. **The magic line** – The frontier sits **above** the minimum‑variance point, forming a convex curve.  Any portfolio that falls **below** that line is “sub‑optimal” – you could shift weight around and get a better return for the same risk.

#### Bottom line for you, dear investor  

- **Aim for the frontier.**  It’s the set of portfolios that give you the *most* return for a given amount of risk.  
- **Don’t settle for the interior.**  Those are just “nice‑to‑have” mixes that waste your risk budget.  
- **All you need is a weight‑reallocation.**  The Solver outputs tell you exactly how to tilt your holdings to land on the frontier.

Think of it like ordering a custom drink: you tell the bartender (Solver) your “risk limit” (how strong you want it), and the bartender hands you two options – the *most* potent cocktail and the *least* potent one.  Anything in between is just watered‑down, and you’d be better off asking for the stronger version (or the weaker one if you’re a lightweight).  

In the next chapter we’ll dip our toes into **Value at Risk (VaR)** – a risk‑metric that tells you how much you could *lose* in a bad day, and then we’ll flip the perspective to look at risk from a **trader’s** point of view.

You can **download the Excel sheet** we used for all this wizardry from the original Zerodha Varsity page.

---

### Key takeaways (the “cheat sheet” you can actually use)

- **A portfolio is defined by the weight you assign to each stock** – change the weights and you get a brand‑new portfolio.  
- **Fix a risk level** (e.g., 17 %) → Solver can give you the **minimum‑return** and **maximum‑return** portfolios for that risk.  
- **Between those extremes lie countless other portfolios**, all of which are *inefficient* because they offer less return for the same risk.  
- **Plotting risk vs. return yields the Efficient Frontier**, a curve that separates the *good* portfolios (on the curve) from the *bad* ones (below it).  
- **Your goal:** pick a portfolio that lives on the frontier – you’re getting the best possible return for the risk you’re comfortable with.  

Now go forth, shuffle those weights, and may your frontier always be efficient!  



---  



*Disclaimer: The jokes are for entertainment; the numbers are exact (unless we’ve rounded for readability).  Always double‑check your own Solver settings before making real money moves.*