# Junior  

**Source:** https://zerodha.com/varsity/chapter/episode-1-ideas-by-the-lake/  

---  

https://www.youtube.com/watch?v=9155SZc96kk  

*(Grab a cold drink, hit the link, and let the “ideas by the lake” vibes wash over you – it’s like a financial swim lesson, but you won’t get wet!)*