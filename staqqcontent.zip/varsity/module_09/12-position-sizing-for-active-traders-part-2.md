# 12. Position Sizing for Active Traders (Part 2)

**Source:** https://zerodha.com/varsity/chapter/position-sizing-active-traders-part-2/

---  

## 12.1 – Defining Equity Capital  

In the previous chapter we already sang the praises of position sizing—so loud that even the neighbours complained. The takeaway? If you’re not putting position sizing at the heart of every trade, you’re basically trying to bake a cake without flour.  

**Position sizing** is the art (and a little bit of science) of deciding **how much** of your trading bankroll you’ll actually **expose** to a single idea. The most famous rule of thumb is the “5 % rule.” It says: *don’t risk more than 5 % of your total capital on any one trade.*  

> **Example:** You have ₹100,000 in your account. 5 % of that is ₹5,000, so the most you’d let slip away on a single ticket is ₹5,000.  
> 
> In that scenario, the **₹5,000** is your *exposure* (the money you could lose), while the **₹100,000** is your *equity capital* (the pool you draw from).  

There isn’t a one‑size‑fits‑all playbook. Different traders swear by different formulas, and that’s fine—just like how some people swear by pineapple on pizza. You’ll have to tinker, test, and eventually adopt the method that feels as comfortable as your favorite pair of slippers.  

Regardless of the rule you adopt, you’ll inevitably need to **estimate your equity capital** first. So before we dive into the juicy position‑sizing techniques, let’s demystify what “equity capital” actually means.

### What on earth is equity capital?  

Think of equity capital as the **cash‑in‑the‑bank** you base all your sizing decisions on. It sounds simple, but in practice it can feel like trying to measure a cloud with a ruler.  

Imagine you start with **₹500,000** and you’re following a 10 % rule (i.e., you’ll never expose more than 10 % of your capital to a single trade). You decide to go long a position worth **₹50,000**.  

Now, after that first trade, what do you consider your “equity capital” for the **next** trade?

- Is it **₹450,000** (the original minus the money you’ve put to work)?
- Or do you still count it as **₹500,000**, because that ₹50,000 is merely “tied up” and not gone?
- Or perhaps you think it should be **₹450,000 + ₹50,000 ± the unrealized P&L** that’s floating around?

Each of those answers could be right in a different context, which is why pinning down equity capital is a bit of a brain‑twister. Getting this step right is the foundation for every sizing formula we’ll discuss later.

![Cartoon](https://zerodha.com/varsity/wp-content/uploads/2017/08/M9C12-cartoon.png)  

---  

## 12.2 – Estimating Equity Capital  

Enter **Van Tharp**, the guru who spent more time with spreadsheets than most of us spend with our families. He distilled the chaos into **three** relatively sane models:

1. **Core Equity Model**  
2. **Total Equity Model**  
3. **Reduced‑Total‑Equity Model**  

Let’s break each one down, sprinkle in a joke or two, and see which one might suit your trading personality.

### 1️⃣ Core Equity Model – “Take it out of the pot, then cook the next dish”

The Core Equity Model is the minimalist’s dream: **subtract the cash you’ve already allocated** from your current capital, and then recompute the 10 % (or whatever rule you use) on the *new* balance.  

**Example:**  
- Starting equity: **₹50,000**  
- Rule: 10 % exposure per trade  

| Trade # | Capital before trade | 10 % exposure | Capital **after** deducting exposure |
|--------|---------------------|--------------|--------------------------------------|
| 1 | ₹50,000 | ₹5,000 | **₹45,000** |
| 2 | ₹45,000 | ₹4,500 | **₹40,500** |
| 3 | ₹40,500 | ₹4,050 | **₹36,450** |
| … | … | … | … |

(You can download the Excel sheet [here](#) if you love tabular torture.)  

What’s happening? Every time you “spend” money on a trade, you pretend it’s vanished from the pot, so the next slice you take is smaller. This is a **conservative** approach—your exposure shrinks as you pile on more positions.  

*Pros*: Easy to calculate; forces you to think “I’ve already used X rupees, what’s left?”  

*Cons*: If your 5th trade turns out to be a blockbuster winner, you’ve already capped yourself at a tiny slice of the pie.  

I like it because it’s straightforward: once you lock money into a trade, you “pretend it’s gone” and move on to the next one with whatever is left.

### 2️⃣ Total Equity Model – “Everything’s on the table, even the crumbs”

The Total Equity Model is the *all‑in* approach: you add together **free cash**, **margin blocked** for every open position, and the **unrealized P&L** of those positions. It gives you a *big, glossy* picture of what you *could* trade with.

**Example:**  

| Item | Amount |
|------|--------|
| Free cash | ₹50,000 |
| Margin blocked – Trade 1 | ₹75,000 |
| P&L – Trade 1 | +₹2,000 |
| Margin blocked – Trade 2 | ₹115,000 |
| P&L – Trade 2 | +₹7,000 |
| Margin blocked – Trade 3 | ₹55,000 |
| P&L – Trade 3 | –₹4,000 |
| **Total Equity** | **₹300,000** |

Now, if your rule says “expose 10 % of total equity,” you can swing **₹30,000** on a new trade. If your free cash can’t cover that, you simply wait for an existing position to close (or, if you’re a daredevil, you could borrow from a friend—don’t do that).

**Why I’m skeptical:** This model treats *paper gains* the same as actual cash, which is like counting the eggs **before** they hatch. Markets love to surprise you, so relying on unrealized P&L can be a bit risky.

### 3️⃣ Reduced‑Total‑Equity Model – “Best of both worlds, with a dash of prudence”

The Reduced‑Total‑Equity Model tries to marry the conservatism of the Core model with the comprehensiveness of the Total model—**but only the *locked‑in* profits, not the floating ones.**  

**Step‑by‑step example:**  

1. **Start capital:** ₹500,000  
2. **Rule:** Max 20 % per trade → ₹100,000 ceiling  
3. **First trade:** Go long ACC futures at 1,800, margin required ≈ ₹90,000 (well under the ₹100k limit).  

   After this trade, the amount you could use for **Trade 2** under the reduced model is:

   \[
   20\% \times (500,000 - 90,000) = 20\% \times 410,000 = ₹82,000
   \]

   So the exposure drops from ₹100,000 to ₹82,000—exactly like the Core model so far.

4. **Market moves:** ACC jumps 25 points to 1,850. Lot size = 400. Paper profit =  

   \[
   400 \times 50 = ₹20,000
   \]

5. **Lock‑in some profit:** You decide to trail stop at 1,825, guaranteeing a **₹10,000** profit (half of the move).  

6. **Add locked‑in profit to equity:**  

   \[
   410,000 + 10,000 = ₹420,000
   \]

7. **Re‑calculate exposure for Trade 3:**  

   \[
   20\% \times 420,000 = ₹84,000
   \]

   Notice the exposure **increased** by ₹2,000 because you safely pocketed some profit.

**Why I like it:** It forces you to *actually lock* profits before you count them, encouraging disciplined stop‑loss usage. It’s a bit like letting the cat out of the bag **only after you’ve fed it**—you don’t pretend you have money you haven’t earned yet.

---

## 12.3 – Putting It All Together  

We’ve now covered three ways to **estimate** the amount of equity you can safely allocate. The next logical step (which we’ll explore in the following chapter) is to pick **one** of these methods and then apply a concrete position‑sizing technique—think of it as choosing a cooking style once you’ve decided whether you have a full pantry, a half‑empty fridge, or just a single egg.

### TL;DR (Key takeaways)

- **Equity capital** is the foundation; without a clear definition you’ll end up sizing positions on a shaky floor.  
- **Core Equity Model** – subtract the cash you’ve already tied up; exposure shrinks with each new trade.  
- **Total Equity Model** – add free cash, blocked margins, and **all** unrealized P&L; gives a big number but can be overly optimistic.  
- **Reduced‑Total‑Equity Model** – like the Core model, but you also add *locked‑in* profits; a balanced, disciplined approach.  

Now go grab a coffee, open your spreadsheet, and decide which model feels right for you. In the next chapter we’ll actually **size** those positions, because a model without an execution plan is just a nice bedtime story. Happy trading!  