# 13. Position Sizing for Active Traders (Part 3)

**Source:** https://zerodha.com/varsity/chapter/position-sizing-active-traders-part-3/  

---  

##  

![Image](https://zerodha.com/varsity/wp-content/uploads/2017/09/M9C13-Cartoon.png)

## 13.1 – Choose Your Path  

In the previous chapter we cracked the “Equity‑estimation” puzzle by looking at three different models. Each model, on its own, forces you to be a little bit disciplined about how many contracts you can hold – but let’s be honest, it’s like putting a tiny “Do Not Touch” sticker on a plate of nachos; it doesn’t stop you from loading up.  

What you really need is a **stand‑alone** rule that tells you *how many* contracts to actually take once you’ve decided *what* you can afford. Enter the world of **Van Tharp’s position‑sizing techniques** – the three‑point belt that keeps you from getting ripped apart.

The three core methods we’ll chew over are:

1. **Unit‑per‑fixed‑amount**  
2. **Percentage margin**  
3. **Percentage of volatility**

A quick disclaimer: these babies are **asset‑agnostic** and **time‑frame‑agnostic**. In plain English, you can slap them on a Nifty future, a Tata Motors stock, a copper contract, or a EUR/INR pair, and you can use them for 5‑minute scalps, swing‑trades that last weeks, or even a multi‑month position.  

**Pro‑tip:** Grab a simple trading system (the classic moving‑average crossover works fine), write down the exact entry/exit rules, and back‑test it **without** any sizing first. Then, re‑run the same trades with each of the three sizing methods. You’ll almost certainly see a noticeable boost in both P&L and stability – it’s like adding a shock absorber to a cheap bike.

### How messy it can get  

- You have a moving‑average crossover system.  
- You want to throw cash at every signal it spits out.  
- You have three ways to define equity (the models from the last chapter).  
- You also have three basic sizing methods (the ones we’re about to dissect).  

That’s **3 × 3 = 9** distinct ways to allocate the same dollar amount to the exact same signal, and each will generate a *different* profit‑and‑loss curve.  

From my battle‑tested experience, keep it simple: pick **one** equity‑estimation method and **one** (maybe two) meaningful sizing technique. Adding more layers just adds complexity, and complex does **not** equal better – it’s like adding extra toppings to a pizza that already tastes great; you just make it harder to finish.

So, based on your temperament (are you a cautious tortoise or a reckless hare?), decide which path feels right. Let’s dive into the three core sizing tools.

---

## 13.2 – Unit per Fixed Amount  

First up: the **Unit‑per‑Fixed‑Amount** model. It’s the “starter kit” of position sizing – the first thing every rookie trader tries because it’s as easy as saying “I’ll buy one pizza for every $20 I have”.

**How it works:**  
You decide beforehand how many shares (or futures lots) you’ll take for a *fixed* chunk of capital. Example:

- Account size: **₹200,000**  
- Universe of five futures: Nifty, SBI, HDFC, Tata Motors, Infosys  
- Rule: **≤ 1 lot per ₹100,000** of capital for any instrument  

Now a Nifty signal pops up. With ₹2 L in the account you could buy **one** lot (₹100 k worth) or **two** lots (₹200 k worth) – the rule lets you pick the latter because you have enough “chunks”.

### Why it feels cozy  

- **Zero math** – just a mental check: “Do I have at least one chunk of cash for this?”  
- **Fast execution** – no need to calculate volatility, margin, or anything else.

### But there are potholes  

1. **Equal weight, unequal risk** – Suppose the system also tells you to buy Tata Motors Futures at the same time. You take 1 lot of each because you have two chunks of cash. However, at the time of writing, **Nifty Futures need ≈₹60 k margin** while **Tata Motors Futures need ≈₹72 k**. The rule ignores the fact that **Tata Motors is ~40 % more volatile** (annualized) than Nifty (~14 %). You’re effectively loading more risk on the portfolio without realizing it.

2. **Scalability ceiling** – Imagine your system is a winner and you rack up a string of profitable trades. With a ₹2 L account the *most* you can ever own at one time is **2 lots** (because the rule caps you at 1 lot per ₹100 k). To increase the position you must either **double your capital** or wait for your account balance to double from profits. In other words, the method puts a ceiling on how big a winning system can grow.

3. **Opportunity filter** – The rule may keep you out of the most lucrative setups simply because they need a larger margin. If a trade requires a ₹105 k margin (say ICICI Futures) you’ll have to **skip** it until you grow your account, even if the risk‑reward looks perfect.

Because of these drawbacks I’m not a huge fan of the fixed‑unit method. **But** don’t take my word as gospel – try it on paper, see how your temperament reacts, and decide whether you want this as a *backup* rule or toss it entirely.

---

## 13.3 – Percentage Margin  

Next on the menu is the **Percentage‑Margin** technique. Think of it as “I’ll only risk X % of my bankroll as margin on any single trade.” It feels a bit more *engineered* than the fixed‑unit approach and is especially handy for intraday warriors who juggle many positions a day.

### The mechanics  

1. Choose a **percentage** of your capital to allocate as *margin* for a single trade (commonly 10‑20 %).  
2. Convert that to a **cash amount** and compare it to the margin requirement of the instrument you want to trade.

**Example:**  

- Capital: **₹500,000**  
- Margin‑percentage: **20 %** → **₹100,000** per trade  

Now the market offers:

| Instrument | Margin Required |
|------------|-----------------|
| Nifty Futures | ≈₹60,000 |
| ICICI Futures | ≈₹105,000 |
| ACC Futures | ≈₹90,000 |

- **Nifty** fits comfortably (₹60 k < ₹100 k).  
- **ICICI** is **out of bounds** (₹105 k > ₹100 k) until you grow your bankroll.  
- **ACC** sits right on the edge; whether you can take it depends on how you *re‑estimate* equity after each trade.

### The equity‑estimation twist  

There are two ways to treat the leftover cash after you lock margin:

| Approach | How you compute the next “available” capital |
|----------|---------------------------------------------|
| **Total‑Equity Model** | Keep the original ₹500 k as the base; you still have ₹100 k of margin capacity for each new trade, regardless of how much is already tied up. |
| **Reduced‑Total‑Equity Model** | Subtract the margin you’ve already blocked. For example, after buying Nifty (₹60 k margin): <br>Remaining capital = ₹500 k – ₹60 k = **₹440 k**. <br>Now 20 % of ₹440 k = **₹88 k** available for the next trade, which is just shy of ACC’s ₹90 k margin – so you’d have to skip ACC. |

The choice of equity model dramatically changes how many trades you can stack at once, so pick the one that matches your risk‑management philosophy.

### Pros & Cons  

- **Pros:**  
  - Guarantees you never over‑leverage beyond a pre‑set fraction of your bankroll.  
  - Simple to compute on the fly – just a quick percentage.  

- **Cons:**  
  - It **ignores volatility**. Two contracts with the same margin can have wildly different price swings, meaning you could still end up with an unbalanced risk profile.  

That’s where the **percentage‑volatility** method steps in to smooth out the risk.

---

## 13.4 – Percentage Volatility  

The **Percentage‑Volatility** technique is the *Goldilocks* of sizing: it tailors each position to the *actual* price‑movement risk of the underlying, not just the margin or a flat lot count. Van Tharp coined it as “don’t let your portfolio’s volatility exceed a certain % of your equity”.

### What “volatility” means here  

We’re not talking about the fancy‑math standard deviation of returns. In practice we use the **Average True Range (ATR)** – a measure that captures the *daily price range* (including gaps).  

Simple illustration:  

- SBI daily OHLC: High = 279, Low = 274 → **Daily range = 5 points**  

If you compute this over the last *n* days and average it, you get an estimate of the typical daily swing. The ATR smooths out spikes caused by gaps, giving a more reliable gauge.

### Setting the rule  

1. Choose a **max‑volatility‑percentage** of your capital (e.g., 2 %).  
2. Convert that to a **cash amount**: 2 % of ₹500,000 = **₹10,000**. This is the *maximum* amount of *daily volatility* you’re willing to tolerate across the whole portfolio.  
3. For each candidate instrument, compute:  

\[
\text{Shares you can buy} = \frac{\text{Volatility budget}}{\text{ATR per share}}
\]

### Walk‑through with Piramal Enterprises Ltd (PEL)  

- **14‑day ATR** = **₹76** per share.  
- Volatility budget = **₹10,000** (2 % of ₹500,000).  

\[
\text{Shares allowed} = \frac{10,000}{76} \approx 131.6 \;\Rightarrow\; 131\text{ shares}
\]

- Current price ≈ **₹2,700** → **Position size = 131 × 2,700 ≈ ₹353,700**.  

Now, if you adopt the **Reduced‑Total‑Equity** view, you treat the ₹353,700 as *used* capital, leaving **₹146,300** for subsequent trades.  

Your *volatility budget* for the next trade stays at **₹10,000** (2 % of the original capital), so you’ll again compute the number of shares based on the new instrument’s ATR. In other words, the *cash* you allocate may shrink, but the *volatility exposure* stays constant.

### Why it matters  

Suppose you decide that the **total volatility** you could stomach in a single day is **15 %** of your bankroll. On a ₹5 L account that’s **₹75,000**. If every position you open moves against you, the worst‑case loss for the day is ₹75k – a figure you can visualize. If that makes your stomach flip, dial the percentage down.  

**Bottom line:** The method equal‑weights *risk* rather than *capital*. You’ll own fewer shares of a jittery stock (high ATR) and more of a placid one, keeping the portfolio’s overall “wiggle room” in check.

---

### Key Takeaways from This Chapter  

- **Equity estimation** is the foundation of any sizing rule.  
- With *3* equity models and *4* sizing approaches you could theoretically craft **12** different combinations.  
- **Unit‑per‑fixed‑amount** is easy to remember but **ignores risk** and caps scalability.  
- **Percentage‑margin** ties each trade to a slice of your capital, yet still **ignores volatility**.  
- **Percentage‑volatility** (using ATR) balances each position by its *actual* price swing, giving you a more *risk‑aligned* portfolio.  
- Whichever method you adopt, keep it **simple**, keep it **consistent**, and, most importantly, keep it **aligned with your temperament** – otherwise you’ll end up with a strategy that feels as uncomfortable as a tuxedo at a beach party.

In the next chapter we’ll peel back a few more layers before diving into the ever‑interesting world of **trading biases**. Grab a drink, stay curious, and happy sizing!