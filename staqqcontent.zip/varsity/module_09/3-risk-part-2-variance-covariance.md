# 3.   Risk (Part 2) – Variance & Covariance  

**Source:** <https://zerodha.com/varsity/chapter/risk-part-2-variance-covariance/>

---  

## 3.1 – Variance  

![Cartoon about variance](http://zerodha.com/varsity/wp-content/uploads/2017/03/M9-C3-cartoon.png)  

In the last episode we flirted with **expected return**. Now it’s time to bring the **portfolio‑level risk** onto the dance floor and meet its partner: **variance**. If you’ve already been chummy with **standard deviation** (the old reliable risk‑meter we’ve been quoting since Module 5, chapter 15), great – you’re basically already speaking the language of variance.  

Why do we need a new beast? Because measuring the risk of a single stock with a simple σ (standard deviation) is like checking the temperature of a single cup of coffee. Building a portfolio is more like trying to guess the climate of an entire city – you have to think about how the individual “cups” interact with each other. This chapter will give you the tools to estimate that city‑wide risk.

But before we dive into the fancy portfolio‑variance formula, we must first get cozy with two statistical side‑kicks: **variance** and **covariance**. Let’s start with variance.

### What *is* variance?  

Think of variance as the “spread‑ometer” for a stock’s daily returns. It tells you how far each day’s return wanders from the average daily return. The math is painless:

\[
\sigma^{2}= \frac{\sum_{i=1}^{N}(X_i-\mu)^{2}}{N}
\]

| Symbol | Meaning |
|--------|---------|
| **σ²** | Variance (read “sigma‑squared”) |
| **X** | Daily return of the stock |
| **μ** | Mean (average) daily return |
| **N** | Number of observations (days) |

*Why σ² and not σ?*  The square makes the math behave nicely (it gets rid of negative signs and plays well with calculus). We won’t go down that rabbit hole now – just remember: **variance = sigma squared**.

### A quick‑and‑dirty example  

Suppose a stock’s daily returns for five consecutive days are:

| Day | Return |
|-----|--------|
| 1 | **+0.75 %** |
| 2 | **+1.25 %** |
| 3 | **‑0.55 %** |
| 4 | **‑0.75 %** |
| 5 | **+0.80 %** |

First, compute the average (μ):

\[
\mu = \frac{0.75+1.25-0.55-0.75+0.80}{5}=+0.30\%
\]

Next, find each day’s *deviation* from the mean, square it, and add them up:

| Day | \(X_i-\mu\) | \((X_i-\mu)^2\) |
|-----|--------------|----------------|
| 1 | 0.75‑0.30 = 0.45 % | 0.45² = 0.2025 |
| 2 | 1.25‑0.30 = 0.95 % | 0.95² = 0.9025 |
| 3 | -0.55‑0.30 = -0.85 %| 0.85² = 0.7225 |
| 4 | -0.75‑0.30 = -1.05 %| 1.05² = 1.1025 |
| 5 | 0.80‑0.30 = 0.50 % | 0.50² = 0.2500 |
| **Sum** | – | **3.1800** |

Now divide by **N = 5**:

\[
\sigma^{2}= \frac{3.1800}{5}=0.6360\%
\]

(If you keep the units as “percent‑squared”, you’ll see the same 0.0063600 % written in the original text – just a different notation.)

#### What does 0.636 % (or 0.00636 % as a variance) tell us?  

It quantifies how wildly the daily returns bounce around the average. A **big variance** = a jittery, high‑risk stock. A **tiny variance** = a placid, low‑risk one. With only five data points, the number looks a bit “high‑octane”, but the idea is clear.

### From variance to the more familiar **standard deviation**  

Variance and standard deviation are BFFs. The relationship is as simple as **√(variance) = σ**.

\[
\sigma = \sqrt{0.00636\%}\approx 0.0797\% \;\;(\text{≈ 0.08 %})
\]

That 0.08 % is the **volatility** (standard deviation) for the five‑day window. In everyday talk we’d say the stock’s price wobbles around its mean by roughly eight‑hundredths of a percent each day.

So now you’ve got variance under your belt. In the next section we’ll pair it with **covariance** to build the full‑blown portfolio‑variance monster.

---

## 3.2 – Covariance  

If variance is the “how much” of a single stock’s wobble, **covariance** is the “how together” of *two* stocks’ wobbles. It tells you whether the returns of two assets tend to move in the same direction (positive covariance) or opposite directions (negative covariance).

> **Quick note:** Covariance ≠ Correlation. Correlation is the *standardised* version of covariance (we’ll meet it later). Think of covariance as raw chemistry, correlation as the *percentage* of that chemistry.

### Covariance formula (the not‑so‑scary version)

\[
\operatorname{Cov}(S_1,S_2)=\frac{\sum_{t=1}^{n}(R_{t,S1}-\overline{R_{S1}})(R_{t,S2}-\overline{R_{S2}})}{n-1}
\]

| Symbol | Meaning |
|--------|---------|
| \(R_{t,S1}\) | Return of Stock 1 on day *t* |
| \(\overline{R_{S1}}\) | Average return of Stock 1 over the period |
| \(R_{t,S2}\) | Return of Stock 2 on day *t* |
| \(\overline{R_{S2}}\) | Average return of Stock 2 |
| *n* | Number of observations (days) |

In plain English: **Take each day’s deviation from its own mean, multiply the two deviations together, add up all those products, and then divide by (n‑1).**  

Sounds like a math‑class nightmare? Stick with me – we’ll walk through a real‑world example.

### Covariance in action: Cipla vs. Idea  

Imagine we pick two big‑cap Indian names that sit in totally different sectors:

| Stock | Sector |
|-------|--------|
| **Cipla Ltd.** | Pharmaceuticals |
| **Idea Cellular Ltd.** | Telecom |

Even though they’re both heavyweight corporates, they don’t share a business model, so you might expect a *small* covariance. Let’s see.

#### Step‑by‑step (Excel style)  

1. **Download 6‑months of daily closing prices** for both stocks.  
   ![Daily price data](http://zerodha.com/varsity/wp-content/uploads/2017/03/Image-1_daily-data.png)

2. **Compute daily returns**: \(\displaystyle \text{Return}_t = \frac{P_t}{P_{t-1}}-1\).  
   ![Daily returns](http://zerodha.com/varsity/wp-content/uploads/2017/03/Image-2_daily-rt.png)

3. **Find the average return** for each stock.  
   ![Average returns](http://zerodha.com/varsity/wp-content/uploads/2017/03/Image-3_avg-rt.png)

4. **Subtract the average from each day’s return** (center the data).  
   ![Deviation from mean](http://zerodha.com/varsity/wp-content/uploads/2017/03/Image-4_rt-minus-avg.png)

5. **Multiply the two deviation columns** (one from Cipla, one from Idea).  
   ![Product of deviations](http://zerodha.com/varsity/wp-content/uploads/2017/03/Image-5_rt12.png)

6. **Sum the product column** and count how many observations you have (Excel’s `COUNT`). In our case we have 127 trading days.  
   ![Sum and count](http://zerodha.com/varsity/wp-content/uploads/2017/03/Image-6_sum.png)

7. **Divide the sum by (n‑1)** – i.e., 127‑1 = 126. The summed product was 0.006642, so:

\[
\text{Covariance}= \frac{0.006642}{126}=0.00005230
\]

   ![Covariance result](http://zerodha.com/varsity/wp-content/uploads/2017/03/Image-7_cov.png)

You can download the Excel sheet if you want to follow along.

#### Interpreting the number  

The raw covariance is tiny (0.0000523). The magnitude isn’t what matters here – what **does** matter is the sign. It’s **positive**, meaning Cipla and Idea tend to move in the same direction on any given day.  

But how *strong* is that relationship? That’s where **correlation** steps in. For these two stocks the correlation comes out to **0.106**, a pretty weak link despite the positive covariance.

### Correlation – the normalised cousin  

Correlation squeezes covariance into a -1 to +1 range:

\[
\rho_{xy}= \frac{\operatorname{Cov}(x,y)}{\sigma_x \sigma_y}
\]

| Symbol | Meaning |
|--------|---------|
| \(\operatorname{Cov}(x,y)\) | Covariance between assets *x* and *y* |
| \(\sigma_x\) | Standard deviation of *x* |
| \(\sigma_y\) | Standard deviation of *y* |

Because \(\sigma_x\) and \(\sigma_y\) are just the square‑roots of the respective variances, you can compute correlation by plugging the numbers you already have. Try it yourself – the answer should match the Excel `=CORREL()` output.

### Covariance in a portfolio context  

When you’re building a portfolio, do you *want* stocks that move together (positive covariance) or opposite each other (negative covariance)? The answer is a resounding **no** to the former. Portfolio managers hunt for **negative covariance** because it acts like a built‑in insurance: when one stock dips, the other may hold steady or even rise, softening the overall swing.

#### Scaling up: more than two stocks  

Real portfolios rarely consist of just a pair; a sensible diversified basket might hold **12‑15** names. How do you keep track of every pairwise relationship? By building a **variance‑covariance matrix**.  

For a four‑stock example (ABB, Cipla, Idea, Wipro) you’d need the covariances for each unique pair:

| Pair | Needed? |
|------|---------|
| ABB‑Cipla | ✅ |
| ABB‑Idea | ✅ |
| ABB‑Wipro | ✅ |
| Cipla‑Idea | ✅ |
| Cipla‑Wipro | ✅ |
| Idea‑Wipro | ✅ |

That’s **6** distinct covariances (remember, Cov(A,B) = Cov(B,A)). With 15 stocks you’d be looking at \(\frac{15\times14}{2}=105\) covariances – enough to make anyone’s head spin. The matrix format neatly arranges them in a table, and the portfolio‑variance formula later in the course will consume that matrix like a power‑lunch.

That’s all for today. Next time we’ll unpack the variance‑covariance matrix and show you how to feed it into the full portfolio‑risk equation. Stay tuned, keep those spreadsheets warm, and remember: **risk is just math that’s trying to tell you a story – you just have to learn the language**.  

---  

### Key take‑aways  

- **Variance** quantifies how far a stock’s returns stray from its own mean.  
- **Higher variance → higher risk** (and vice‑versa).  
- **Standard deviation** = √(variance).  
- **Covariance** measures the joint movement of two assets’ returns.  
- **Positive covariance** = returns tend to move together; **negative covariance** = they move opposite.  
- **Correlation** standardises covariance, telling you *how strong* the co‑movement is (‑1 to +1).  
- Correlation = Covariance ÷ (σ₁ × σ₂).  
- For portfolios with >2 stocks, we roll everything into a **variance‑covariance matrix**.  

Now go forth and crunch those numbers – the market is waiting for your newly‑honed statistical swagger!