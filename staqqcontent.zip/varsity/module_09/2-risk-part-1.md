# 2. Risk (Part 1)

**Source:** <https://zerodha.com/varsity/chapter/risk-part-1/>

---  

## 2.1 – Warming up to risk  

Picture a seesaw in a playground. Every rupee of profit that a trader pockets is balanced by a rupee that *some* other trader drops. If a small crew of traders keeps climbing up the profit side, there’s inevitably a larger crowd sliding down on the loss side. In practice the “profit‑club” is usually tiny; the “loss‑club” is massive.  

Why? Because the two groups differ in one crucial habit: **how they treat risk and money‑management**. Mark Douglas put it nicely in *The Disciplined Trader*:  

> “Successful trading is **80 % money‑management and 20 % strategy**.”  

I’ve nodded so hard at that quote my neck hurts. Money‑management is nothing but risk assessment dressed up in a suit, so getting cozy with the many flavors of risk is the first step to stop bleeding money.

### What does “risk” actually mean?  

The lay‑person’s dictionary says: *“the probability of losing money.”*  
When you buy a share, you’re automatically signing up for that probability—whether you love the company’s logo or not. At a bird’s‑eye level, risk splits into two families:

| Risk type | What it means |
|-----------|----------------|
| **Systemic (market) risk** | Forces that shake *all* stocks together—think GDP slump, interest‑rate hikes, wars. |
| **Unsystemic (idiosyncratic) risk** | Hazards that only a single company (or a narrow sector) faces—bad earnings, fraud, a CEO’s bad haircut. |

You’re exposed to **both** the moment you own a share.

### What can drag a stock’s price down?  

Give me a few minutes and I’ll hand you a grocery list of doom:

- Deteriorating business prospects  
- Shrinking margins (the profit‑pie gets smaller)  
- Management misconduct (the “oops‑I‑did‑it‑again” of corporate life)  
- Competition gobbling up market share  

All of those are **company‑specific** risks. Let’s do a quick thought experiment.  

Suppose you have **₹1,00,000** to deploy and you go all‑in on **HCL Technologies**. A few months later HCL announces a dip in revenue. The stock wobbles, your portfolio wobbles, and you lose money. The same news, however, leaves **Mindtree** and **Wipro** untouched—they keep on marching to their own beat. That’s the hallmark of unsystemic risk: it lives inside the firm, not the market.

#### A real‑world drama: the Satyam scandal  

If you were watching the markets on the morning of **7 January 2009**, you probably remember the collective gasp that rippled through Indian bourses. Satyam Computers had been cooking its books for years, inflating revenues, and siphoning cash like a kid with a candy jar. Then Chairman **Ramalinga Raju** mailed a confession to investors, regulators, and the whole nation, saying “I’m sorry, we cheated.”

The market reaction was spectacular:

- **The Satyam share price** plummeted faster than a stone off a cliff, eventually hitting single‑digit rupees.  
- **Other stocks** (look at the scrolling ticker) barely flinched—no contagion.  
- **Broad indices** (Sensex, Nifty) dipped, but nowhere near Satyam’s free‑fall.

The takeaway? The crash was **purely company‑specific**—the classic textbook example of **unsystemic risk**.

![Unsystemic risk cartoon](http://zerodha.com/varsity/wp-content/uploads/2017/03/M9-C2-cartoon.png)

### Diversify or die (well, lose money)  

Unsystemic risk is *diversifiable*. Instead of parking the whole **₹1,00,000** in HCL, you could split it:

- **₹50,000** in HCL  
- **₹50,000** in Karnataka Bank  

If HCL tanks, only half your capital feels the pain; the bank may be sailing smoothly. Push the idea further—add 5, 10, or even 20 stocks from different sectors. The rule of thumb from academic research is:

> **Around 21 stocks** give you the sweet spot where unsystemic risk is essentially “washed out.” Adding more beyond that yields diminishing returns.

I personally juggle about **15 stocks**, which keeps my portfolio lively without turning me into a data‑entry clerk.

#### The math picture  

Below is a classic graph (courtesy of Zerodha) that shows the unsystemic‑risk curve flattening after roughly 20‑odd stocks.

![Diversification graph](http://zerodha.com/varsity/wp-content/uploads/2017/03/Image-1_risk.png)

Notice how the curve drops sharply at first (each new stock knocks out a chunk of idiosyncratic risk) and then levels off—by the time you hit the 20‑stock mark, you’re mostly left with **systemic risk**, the stubborn residue that refuses to be diversified away.

### Systemic risk – the market’s “common cold”  

Systemic risk is the collective malaise that hits every stock at once. It stems from macro‑level forces such as:

- **GDP contraction** (the economy’s “snooze” button)  
- **Interest‑rate tightening** (the central bank’s way of saying “stop borrowing”)  
- **Inflation** (your money’s losing weight)  
- **Fiscal deficits** (government overspending)  
- **Geopolitical tensions** (war, elections, trade wars)  

If you own a well‑diversified basket of 20 stocks, a GDP slowdown will still drag **all** of them down, because the whole market is riding the same economic tide. Unlike unsystemic risk, you cannot “diversify” systemic risk away—it’s baked into the system.

#### Hedging: the umbrella for a rainy market  

You *can* mitigate systemic risk, but you need a different tool: **hedging**. Think of hedging as the trusty umbrella you pull out when the clouds gather. It won’t stop the rain, but it keeps you from getting drenched.

A common hedge for Indian equity exposure is buying **index futures** or **options** that move opposite to your portfolio. When the market slides, the hedge gains, offsetting part of your loss. Remember:

- **Diversification** = **minimize unsystemic risk**  
- **Hedging** = **minimize systemic risk**  

Both are useful, but neither makes you *immune*—there’s always a sliver of risk left, like that one rogue drop that finds its way through the umbrella’s seam.

> **Bottom line:** No strategy makes you invincible; it only reduces the odds of a catastrophic wipe‑out.

---

## 2.2 – Expected Return  

Now that we’ve got risk under the microscope, let’s talk about the other side of the coin: **expected return**.  

In plain English, *expected return* is the percentage you *think* you’ll earn on an investment. If you buy **Infosys** today and say, “I’m hoping for **20 %** next year,” then **20 %** is your expected return.

### Why does it matter?  

Because that number is the engine behind almost every financial formula you’ll ever see—portfolio optimization, the Capital Asset Pricing Model (CAPM), even a simple equity‑curve projection. In other words, a realistic expected return is the compass that keeps your investment ship from sailing straight into an iceberg.

### Portfolio arithmetic: mixing apples and oranges  

Suppose you split **₹50,000** into two equal pots:

| Asset | Amount | Expected return |
|-------|--------|-----------------|
| Infosys (INFY) | ₹25,000 | 20 % |
| Reliance Industries (RELI) | ₹25,000 | 15 % |

What’s the **portfolio’s** expected return? It’s **not** 20 % (the higher one) nor 15 % (the lower one). It’s a weighted average:

\[
E(R_P) = w_1 R_1 + w_2 R_2
\]

Where  

- \(w_i\) = weight of each asset (here 0.5 each)  
- \(R_i\) = expected return of each asset  

Plugging in:

\[
E(R_P) = 0.5 \times 20\% + 0.5 \times 15\% = 10\% + 7.5\% = \boxed{17.5\%}
\]

That 17.5 % is the number you’d use for any further calculations (e.g., Sharpe ratio, Monte‑Carlo simulation). The same formula scales to any number of assets, be it 2, 10, or 100.

### A quick reality check  

Remember, **expected return ≠ guaranteed return**. It’s a *probabilistic* forecast, not a promise. Franco Modigliani (the Nobel‑winning economist) phrased it beautifully in his paper *“An introduction to risk and return concepts.”* In short: the future is uncertain, and your expected return is just the best guess based on current information.

Once you’re comfortable with expected return, you’ll be ready to dive into **variance**, **covariance**, and the other statistical beasts that help you measure *how much* that return might wobble. That’s the topic for the next chapter.

---

### Key takeaways from this chapter  

- Buying a share exposes you to **both unsystemic and systemic risk**.  
- **Unsystemic risk** (company‑specific) affects only the individual stock, not its peers.  
- You can **dilute unsystemic risk** through **diversification**—hold a basket of unrelated stocks.  
- Research suggests **≈ 21 stocks** are enough to wipe out most unsystemic risk; beyond that, the benefit tapers off.  
- **Systemic risk** is the market‑wide “common cold” that hits every security (GDP slowdown, rate hikes, inflation, fiscal deficits, geopolitics).  
- You **cannot diversify away** systemic risk, but you can **hedge** it (e.g., index futures, options).  
- Hedging ≠ diversification; both are tools with different objectives.  
- No hedge is perfect—some residual risk always lurks.  
- **Expected return** is the probabilistic forecast of profit, not a guarantee.  
- For a multi‑asset portfolio, compute expected return as a **weighted average**:  

\[
E(R_P) = \sum_{i=1}^{n} w_i R_i
\]

- Understanding both risk and expected return is the foundation for any serious investment strategy.  

Now go forth, diversify wisely, hedge when the clouds gather, and always keep your expected‑return calculator handy—just don’t forget your umbrella!