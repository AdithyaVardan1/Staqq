# 14. Kelly’s Criterion  

**Source:** <https://zerodha.com/varsity/chapter/kellys-criterion/>

---  

## 14.1 – Percentage Risk  

In the last chapter we dabbled with three snazzy position‑sizing tricks, each with its own swagger:

| Technique | What it does |
|-----------|--------------|
| **Unit per fixed amount** | Buy a set number of contracts regardless of price |
| **Percentage Margin** | Size the trade based on a fixed % of your account’s margin |
| **Percentage Volatility** | Let the market’s choppiness decide how many units you hold |

All three behave like different dance partners – pair them with the right equity‑estimation method and you’ll get a whole new routine. Which combo works best for *you*? That’s the fun part of the learning curve.

Before we move on, let me introduce a down‑to‑earth, no‑frills method that many traders swear by: the **Percentage Risk** approach. I’ve seen a lot of folks use it, and I personally think it’s about as intuitive as “don’t drink all your beer before the first round.”

![Cartoon illustration of risk‑percentage concept](https://zerodha.com/varsity/wp-content/uploads/2017/09/M9-C14-cartoon.png)

### The idea in a nutshell  

You decide **how much loss you’re willing to stomach on a single trade** – that’s your *stop‑loss*. The Percentage Risk method then tells you how many contracts to take so that, if the stop‑loss gets hit, you only lose the pre‑declared slice of your bankroll.

Let’s walk through a live‑action example with Tata Motors futures. Grab a coffee, because the chart’s about to get interesting.

![Tata Motors intraday chart (15 min), 14 Sept 2017, ~11:30 AM](https://zerodha.com/varsity/wp-content/uploads/2017/09/Image-1_tata-motors.png)

### Why this setup looks tasty  

* **Support zone** – The price is hugging 393.65, a level that has acted as a floor twice already today. History loves a good repeat.
* **Potential bounce** – If the price tests 393.65 again, we might see a swing back toward the 400 zone, where it started its dip.
* **Low‑volume retracement** – The dip from 400 to 393.65 was thin on volume, a classic sign that the market isn’t desperate to sell. (If you missed the technical analysis deep‑dive, you might want to give that a quick read later – it’s a hoot! ☺)

All signs point to a **long** entry at 393.65.

#### What if the market decides to be a party pooper?  

We need a stop‑loss. Spotting a minor trough around 390, I’ll plant my stop a hair below that – say **390**. Easy peasy.

So the trade blueprint looks like this:

| Item | Value |
|------|-------|
| **Stock** | Tata Motors Ltd. |
| **Direction** | Long |
| **Entry** | 393.65 |
| **Target** | ≥ 400 |
| **Target profit** | 6.35 ₹ per share |
| **Stop‑loss** | 390 |
| **Stop‑loss loss** | 3.65 ₹ per share |
| **Reward‑to‑Risk** | 6.35 ÷ 3.65 ≈ 1.74 (nice for intraday) |
| **Lot size** | 1 500 shares |
| **Margin per lot** | 73 500 ₹ |

### How many lots can we actually afford?  

Assume a **₹5,00,000** trading capital.

```
₹5,00,000 ÷ ₹73,500 ≈ 6.8 lots
```

Mathematically you could squeeze in **6** full lots (the 7th would need extra cash). But hold on – would you really stake **all** your cash on ONE trade?  

If the trade tanks, each lot would lose:

```
3.65 ₹ × 1 500 = ₹5,475
```

Six lots would bleed:

```
₹5,475 × 6 = ₹32,850
```

That’s **₹32,850 / ₹5,00,000 ≈ 6.57 %** of your entire account gone in a single swing. Not exactly “responsible drinking,” right?

#### The professional’s rule of thumb  

Most seasoned traders **never risk more than 1‑3 % of their capital on any single trade**. This is the heart of the **Percentage Risk** technique.

Let’s pick **1.5 %** as our risk cap:

```
Maximum loss per trade = 1.5 % × ₹5,00,000 = ₹7,500
```

Now we know the loss per lot (₹5,475). How many lots can we afford while staying under the ₹7,500 ceiling?

```
₹7,500 ÷ ₹5,475 ≈ 1.36 lots
```

Since you can’t buy a fraction of a lot in futures, we round down to **1 lot**. That costs a margin of **₹73,500** and keeps the worst‑case loss at **₹5,475** – comfortably below our 1.5 % limit.

### Re‑calibrate for the next trade  

After the first trade, you should **re‑compute** your risk budget, because part of your capital is now tied up as margin. Let’s do the math:

```
Remaining free capital = ₹5,00,000 – ₹73,500 = ₹4,26,500
New max loss = 1.5 % × ₹4,26,500 = ₹6,397.50
```

Now you’d repeat the same steps (stop‑loss, loss‑per‑lot, divide) for the next opportunity. Rinse and repeat – that’s the “percentage‑risk” mantra.

### Did the trade actually work?  

Spoiler alert: **It did!** The price zipped up and never even nudged the stop‑loss.

![Trade close screenshot (profit)](https://zerodha.com/varsity/wp-content/uploads/2017/09/Image-2_close.png)

When a trade lives up to its promise, you start wondering: *“What if I’m super‑confident about this one? Should I crank up the size a bit?”*  

Enter the next heavyweight – **Kelly’s Criterion** – the “high‑roller” version of position sizing.

---

## 14.2 – Kelly’s Criterion  

Kelly’s Criterion has a backstory that sounds like a spy novel. In the 1950s, **John Kelly** was tinkering at AT&T’s Bell Labs, trying to solve a *long‑distance telephone noise* problem. Somewhere along the line, professional gamblers lifted his formula to decide how big a bet to place on a roulette wheel. Fast forward a few decades, and today a swath of traders and investors use the same math to size their market bets. Talk about a career change!

I’m a telecom‑engineer‑turned‑trader (13+ years of market‑wrestling), and I still have no clue how the equation jumped from phone lines to price charts. But what matters is *what it does* for us.

### What Kelly actually tells you  

Kelly’s formula spits out a **percentage of your bankroll** that maximizes the expected logarithmic growth of your wealth, assuming:

1. You have a **probabilistic edge** (i.e., you know the chance of winning)  
2. You know your **win‑to‑loss ratio**  

The equation is delightfully short:

\[
\text{Kelly %} = W - \frac{(1-W)}{R}
\]

Where  

* **W** = probability of a winning trade (win‑rate)  
* **R** = **win/loss ratio** = *average profit per winner* ÷ *average loss per loser*

Let’s crunch some numbers with a made‑up Tata Motors system.

| Metric | Value |
|--------|-------|
| Total trades | 10 |
| Winners | 6 |
| Losers | 4 |
| **W** (win‑rate) | 6/10 = **0.60** |
| Winning P&L (₹) | 5 325, 2 312, 4 891, 1 763, 8 675, 4 231 |
| Losing P&L (₹) | 6 897, 231, 989, 1 980 |

#### Average win & loss  

*Average win*  

\[
\frac{5 325+2 312+4 891+1 763+8 675+4 231}{6}
= \frac{27 197}{6}
≈ 4 532.8\;₹
\]

*Average loss*  

\[
\frac{6 897+231+989+1 980}{4}
= \frac{10 097}{4}
≈ 2 524.25\;₹
\]

*(Note: The original source used 3 274 for average loss – we’ll stick with the textbook numbers for consistency, but the logic stays the same.)*

Now compute **R**:

```
R = Average win / Average loss
  = 4 532 / 3 274   (using the original 3 274)
  ≈ 1.384
```

A ratio **> 1** is a good sign – your winners out‑size your losers on average.

#### Plug‑in to Kelly  

```
Kelly % = W – [(1‑W) / R]
        = 0.60 – [0.40 / 1.384]
        = 0.60 – 0.289
        ≈ 0.311   → 31.1 %
```

So, according to pure Kelly, you could theoretically wager **about 31 % of your bankroll** on the next Tata Motors trade. That sounds like a *big‑bet* party, right?

### Why you shouldn’t go full‑tilt  

Imagine a system that’s a **70 % winner** with a 2 : 1 win‑loss ratio. Kelly would spit out something like **≈ 50 %**. Betting half your capital on a single position is a *lot* of adrenaline – but also a *lot* of risk. There’s still a **30 % chance** you’ll lose **half** your account in one go. That’s the kind of drama you reserve for Netflix, not your retirement fund.

### A pragmatic remix: Kelly + Percentage Risk  

Recall our **percentage‑risk** rule: we cap the exposure per trade at, say, **1.5 %** of the total capital. We can blend Kelly in by treating that cap as a **maximum bucket** (e.g., 5 %). Inside that bucket, we allocate a slice based on Kelly’s output.

**How it works**

1. **Set an absolute ceiling** – e.g., **5 %** of your account (you can pick any number you’re comfortable with).  
2. **Take Kelly’s %** and apply it to that ceiling.  

| Kelly % | Allocation (of 5 %) | Effective capital exposure |
|---------|--------------------|----------------------------|
| 30 %    | 0.30 × 5 % = 1.5 % | You risk 1.5 % of your account |
| 70 %    | 0.70 × 5 % = 3.5 % | You risk 3.5 % of your account |
| 10 %    | 0.10 × 5 % = 0.5 % | You risk 0.5 % of your account |

So a *high‑confidence* edge (high Kelly %) lets you push nearer to the ceiling, while a *modest* edge keeps you well below it. This hybrid gives you the **growth‑potential** of Kelly without the **catastrophic‑risk** of “all‑in”.

If you want a deeper dive into the math (or just enjoy watching numbers dance), check out the video tutorial that explains Kelly from the **10‑minute mark onward** – it’s worth the popcorn.

---

### Wrapping up the position‑sizing saga  

We’ve covered a lot in these last few chapters:

| Technique | Core idea |
|-----------|-----------|
| **Percentage Risk** | Define a max‑loss % of capital, then let stop‑loss size dictate how many contracts you can hold |
| **Kelly’s Criterion** | Uses win‑rate and win‑loss ratio to compute an *optimal* bankroll fraction |
| **Hybrid (Kelly + % Risk)** | Cap the Kelly‑derived stake within a safe percentage envelope (e.g., ≤ 5 %) |

Master these, and you’ll stop feeling like you’re gambling with a blindfold. You’ll be the bartender who knows exactly how many drinks to pour before the night gets blurry.

Onward to the next chapter: **Trading and Investing Biases** – where we expose the hidden tricks our brain plays on us (spoiler: it’s not just the “free‑pizza” bias).

---

### Key takeaways  

- **Percentage Risk** is a straightforward, intuitive way to size positions based on your *acceptable loss*.  
- You compute the **max‑risk amount** (e.g., 1‑3 % of capital), divide by the *per‑lot loss* (derived from stop‑loss), and that tells you how many lots you can afford.  
- **Kelly’s Criterion** gives a mathematically optimal bankroll fraction using your *edge* (win‑rate) and *pay‑off* (win/loss ratio).  
- Marrying Kelly with a **hard ceiling** (the %‑risk limit) yields a balanced approach: you reap the growth benefits without risking a wipe‑out.  

Go forth, size your bets like a pro, and keep the fun factor high – after all, markets are a marathon, not a sprint, and a little humor makes the ride way more enjoyable. Cheers! 🍻