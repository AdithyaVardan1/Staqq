# 4.   Risk (Part 3) – Variance & Covariance Matrix  

**Source:** https://zerodha.com/varsity/chapter/risk-part-3-_variance-covariance-matrix/  

---  

## 4.1 – A quick recap  

Alright, let’s hit the “rewind” button and jog our memory before we dive back into the deep end.  

We kicked off this whole saga by meeting the two mischievous twins that haunt every market participant: **systematic risk** (the market‑wide gremlin that you can’t dodge) and **unsystematic risk** (the stock‑specific hiccup you can actually diversify away). After we got the difference between the two clear enough to write on a napkin, we turned our attention to *portfolio* risk – because you don’t own a single stock forever, right?  

When you look at a basket of stocks, the key players are **variance** and **covariance**.  

* **Variance** = how wildly a single stock’s returns bounce around its own average – think of it as that one friend who always shows up either way too early or way too late.  
* **Covariance** = how two stocks move together (or apart) – basically, are they the “dynamic duo” or the “oil‑and‑water” pair?  

We illustrated those ideas with a two‑stock portfolio, but then we all had that “aha!” moment: real‑world equity portfolios usually have *more* than two stocks. To wrangle the variance‑covariance‑correlation circus for a multi‑stock portfolio, we need to summon the magic of **matrix algebra**.  

So, where are we now?  

*We’ve mastered the basics of systematic vs. unsystematic risk, we’ve seen variance and covariance for a duo of stocks, and we’ve realized we need matrices to handle a full‑blown portfolio.*  

In this chapter we’ll:

1. **Scale up** the variance‑covariance calculation to many stocks (yes, matrices, matrix multiplication, and a sprinkle of linear‑algebra wizardry).  
2. Turn that boring‑looking variance‑covariance matrix into a **correlation matrix** – the friendlier cousin that actually tells a story.  
3. Use the correlation matrix to finally compute **portfolio variance**, the ultimate metric that whispers “this is how much risk you’re signing up for”.  

Remember, our endgame is **portfolio variance** – the number that tells you how shaky (or steady) your collection of stocks really is.  

While we’re at it, we’ll also peek at **asset allocation** (because where you put the money matters just as much as how much you put) and sprinkle in a quick intro to **Value‑at‑Risk (VaR)** – the “what‑if‑the‑worst‑happens” scenario.  

And because traders love a good drama, we’ll finish with a trader‑centric view of risk: how to spot trading risk and, more importantly, how to kick it to the curb.  

> ![Cartoon](http://zerodha.com/varsity/wp-content/uploads/2017/03/M9C4-cartoon.png)  

---

## 4.2 – Variance‑Covariance matrix  

Before we start juggling numbers, let’s clear up a common brain‑fart: **Is it “variance‑covariance matrix”, a “variance matrix plus a covariance matrix”, or a single mystical matrix?**  

It’s **one single matrix** that packs both the variances *and* the covariances into a tidy grid. Picture five stocks in a room. The matrix tells you each stock’s own mood swings (variance) **and** how each pair of stocks gossip with each other (covariance).  

If you have **5 stocks**, the matrix is a **5 × 5** table: every row is a stock, every column is a stock, and the intersecting cell is either the variance (when row = column) or the covariance (when they differ).  

> **Pro‑tip:** If you’re not comfortable with matrix math, hit the “Khan Academy” rabbit hole and watch the **matrix multiplication** video. It’s like learning to dance – you stumble at first, but then you’re the star of the floor.  

Now, let’s roll up our sleeves and actually **build** a variance‑covariance matrix for a modest‑sized portfolio. In theory a “real” diversified portfolio might hold 10‑15 stocks, but trying to type that into Excel is like trying to fit a circus elephant into a Mini Cooper. So we’ll keep it to **5 stocks** (enough to be interesting, short enough to be painless).  

### The five‑stock lineup  

| Ticker | Company |
|--------|----------|
| **CIPLA** | Cipla Ltd. |
| **IDEA** | Idea Cellular Ltd. |
| **WON** | Wonderla Resorts Ltd. |
| **PVR** | PVR Ltd. |
| **ALKEM** | Alkem Laboratories Ltd. |

A 5‑stock portfolio → **5 × 5** variance‑covariance matrix (in general, a **k × k** matrix for *k* stocks).  

### The formula (the “cheat sheet”)  

\[
\text{Var‑Cov} \;=\; \frac{X^{\!T}X}{n}
\]

where  

* **k** = number of stocks in the portfolio (here, 5).  
* **n** = number of observations (how many daily returns you have).  
* **X** = the **n × k** **excess‑return matrix** (more on that in a sec).  
* **Xᵀ** = transpose of **X** (rows become columns, columns become rows).  

**What’s happening?**  

1. Compute the excess‑return matrix **X** (each row = a day, each column = a stock’s excess return).  
2. Multiply its transpose **Xᵀ** (now a **k × n** matrix) by **X** (the original **n × k**). The product **XᵀX** is a **k × k** matrix.  
3. Divide every element of **XᵀX** by **n** (the number of observations). Voilà – you have the variance‑covariance matrix.  

That’s just one arithmetic step away from the **correlation matrix**, which we’ll turn into next.  

### Let’s do it in Excel (step‑by‑step, with screenshots)  

#### Step 1 – Pull daily closing prices & compute daily returns  

Grab the last 6 months of daily closing data for the five tickers (≈ 127 trading days). Then compute daily simple returns:  

\[
r_{t} = \frac{P_{t} - P_{t-1}}{P_{t-1}}
\]

(If you’re unsure, just copy the formula from the screenshot – it’s `=(Current‑Close‑Previous‑Close)/Previous‑Close`).  

> ![Daily returns snapshot](http://zerodha.com/varsity/wp-content/uploads/2017/03/Image-2_rt.png)  

#### Step 2 – Average daily return for each stock  

Use Excel’s `=AVERAGE(range)` to get the mean return for every column.  

> ![Average returns screenshot](http://zerodha.com/varsity/wp-content/uploads/2017/03/Image-3_avg.png)  

#### Step 3 – Build the **excess‑return matrix (X)**  

Excess return = **daily return – its own average**. In other words, each cell tells you how that day’s return deviated from the stock’s “typical” day.  

> ![Excess‑return matrix](http://zerodha.com/varsity/wp-content/uploads/2017/03/Image-4_excess-rt.png)  

Now **X** is a **127 × 5** matrix (n = 127, k = 5).  

#### Step 4 – Compute **XᵀX** (the raw product)  

1. List your tickers across the top **and** down the side of a blank 5 × 5 block (so you have a grid ready to receive the product).  

   > ![Labelled grid](http://zerodha.com/varsity/wp-content/uploads/2017/03/Image-5_Xt.png)  

2. Highlight the entire 5 × 5 block, type the array formula:  

   ```excel
   =MMULT(TRANSPOSE(X_range), X_range)
   ```  

   Replace `X_range` with the actual range of your excess‑return matrix (e.g., `B2:F128`).  

3. Instead of just pressing **Enter**, press **Ctrl + Shift + Enter** (that’s the secret handshake for Excel array formulas).  

   > ![MMULT result](http://zerodha.com/varsity/wp-content/uploads/2017/03/Image-6_mmult.png)  

You’ll now see a nicely populated **5 × 5** matrix – that’s **XᵀX**.  

> ![XᵀX complete](http://zerodha.com/varsity/wp-content/uploads/2017/03/Image-7_xtx-complete.png)  

#### Step 5 – Divide by **n** to get the **variance‑covariance matrix**  

1. Keep the same 5 × 5 block selected.  
2. In the formula bar, type:  

   ```excel
   =MMULT(TRANSPOSE(X_range), X_range) / n
   ```  

   (again, finish with **Ctrl + Shift + Enter**).  

   > ![Layout for division](http://zerodha.com/varsity/wp-content/uploads/2017/03/Image-9_lay.png)  

3. Excel will spit out the final matrix, with tiny numbers (don’t panic – that’s normal).  

> ![Variance‑covariance matrix](http://zerodha.com/varsity/wp-content/uploads/2017/03/Image-11_complete.png)  

#### Interpreting the matrix  

* **Diagonal cells** (e.g., Cipla‑Cipla) = **variance** of that stock.  
* **Off‑diagonal cells** (e.g., Wonderla‑PVR) = **covariance** between the two stocks.  

Let’s locate a specific covariance:  

*Find the row “Wonderla” and the column “PVR” – the intersecting cell shows **0.000034**.*  

> ![Covariance highlighted](http://zerodha.com/varsity/wp-content/uploads/2017/03/Image-12_covar-1.png)  

That same value appears symmetrically at **PVR‑Wonderla** (the matrix is symmetric, like a perfectly balanced seesaw).  

Now look at the **blue‑highlighted** diagonal for **Cipla‑Cipla**. That number is the **variance of Cipla**. Remember, variance is just a special case of covariance where the two assets are the *same* thing.  

> **Bottom line:** This table is called a **Variance‑Covariance Matrix** because it holds both variances (the diagonal) **and** covariances (the off‑diagonals).  

#### The bitter pill  

All those tiny decimals are great for feeding into formulas, but on their own they’re about as exciting as plain oatmeal. To get something we can actually *talk* about, we need to convert them into **correlations** – a scale from -1 to +1 that tells you the *strength* and *direction* of the relationship, not just the raw magnitude.  

We’ll whip up that **correlation matrix** in the next chapter, then plug everything into the **portfolio variance** equation (the grand finale).  

### Your homework (yes, we love homework)  

1. **Data hunt:** Download a full year of daily closing prices for *any* five (or more) stocks you like.  
2. **Build it:** Replicate the variance‑covariance matrix using the steps above.  
3. **Check yourself:** Pick one stock, compute its variance with Excel’s `=VAR.P(range_of_returns)` (or `=VAR.S` for sample variance) and verify it matches the diagonal entry you got from the matrix.  

*(You can grab the exact Excel workbook we used from the Zerodha Varsity site if you want to cheat a little.)*  

---

### Key Takeaways from this chapter  

| ✅ | What you should now know |
|---|---|
| **X** = excess‑return matrix (daily return minus its own mean). |
| **Excess‑return matrix** size = **n × k** (observations × stocks). |
| **Xᵀ** = transpose of **X** (rows ↔ columns). |
| **n** = number of observations (e.g., 127 for ~6 months, 252 for 1 year). |
| **Variance‑Covariance matrix** = \(\frac{X^{\!T}X}{n}\) → size **k × k**. |
| **Diagonal entries** = variance of each stock; **off‑diagonal** = covariances. |
| The matrix is symmetric (covariance AB = covariance BA). |
| This matrix is the stepping‑stone to the **correlation matrix**, which we’ll need to finally compute **portfolio variance**. |

That’s a lot, but you’ve just turned a chaotic wall of daily returns into a clean, interpretable grid. Next stop: correlation‑land and the grand calculation of how risky your whole portfolio really is. Stay tuned, and keep those Excel fingers limbered up! 🚀