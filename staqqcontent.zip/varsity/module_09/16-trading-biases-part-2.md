# 16. Trading Biases (Part 2)

**Source:** https://zerodha.com/varsity/chapter/tradingbiases-p2/

---  

##  

![Image](https://zerodha.com/varsity/wp-content/uploads/2017/10/M9-C16-cartoon.png)

## 16.1 – Anchoring Bias  

I’ve been glued to the Indian stock‑market roller‑coaster for **about 13 years** now. In that time I’ve worn more hats than a milliner – trader, investor, broker, money‑manager, analyst, you name it. I’ve tasted the sweet‑victory fizz of a big win, swallowed the sour regret of a whopper loss, and learned a ton (and still keep learning). One thing I’ve discovered is that our feelings don’t always line up neatly with the actual result of a trade. You feel euphoric when a position makes money, miserable when it bleeds, and sometimes you get a **“what‑the‑heck‑did‑I‑just‑miss‑out‑on?”** feeling even for trades you never placed. Let me spill the beans on the *biggest* regret of my market life.

Back in **August/September 2013** the market was a bargain‑basement wonderland. Great businesses were trading at prices that made you wonder if the sellers were trying to give them away. I was hustling to build a long‑term equity portfolio from scratch. The problem? **Too many good ideas.** A bear market does that – it throws a buffet of cheap stocks at you and says “pick whatever you like”.  

I finally locked in a handful of names (still in my book) and **walked away** from many others, including MRF, Bajaj Finserv, etc. Those two have since turned into fireworks, but I’m not crying over spilt milk – I made a conscious choice and I’m happy with it.  

What *does* make my heart ache is the one I let slip: **Sundaram Clayton Limited (SCL).**  

![Image](https://zerodha.com/varsity/wp-content/uploads/2017/10/Image-1_SC.png)

I did the usual deep‑dive, crunched the numbers, and was convinced SCL was a *great* buy. My mental price target? Roughly **₹270 per share**. In a bear market I was a bit of a price‑snob – “If I’m going to buy, I’ll wait for the “right” price, or better.”  

The stock ticked up to ₹280, I held my breath. Then to ₹290 – still no action. A few days later it popped to ₹310, and I told myself, “It’ll retrace back to ₹270; after all, this is a bear market, right?” I wasn’t ready to pay a **15 % “premium”** over my magical number.  

Spoiler alert: **₹270 never came back.** I missed the entry, and the stock kept climbing.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2017/10/Image-2_Screg.png)

I’ve circled the dreaded ₹270 again for you – that was my *price anchor*, the mental fence that kept me from acting.  

In plain English, I missed possibly one of the **biggest** investment chances of my life because my brain was stuck on a single number. That’s the classic **Anchoring Bias** (also called *Focalism*). Anchoring sits under the umbrella of **Cognitive Biases** – systematic errors in the way we think that skew decisions and judgments.

**How anchoring works:**  
When you first see a piece of information, it becomes a *reference point* (the anchor). Everything that follows gets judged relative to that anchor, even if the anchor is totally arbitrary. In my case, the first quote I saw – ₹270 – became the “only acceptable” price.  

Think about your own trading story. How many times have you stared at a chart, told yourself “I’ll only buy if it hits exactly this level,” and then watched the price dance past that level, later realizing you could have been in on the upside? Usually the gap is just a few rupees, but our brains treat it like a **mountain of lava** that we can’t cross.

Is there a magic cure? No. The best antidote is **awareness** plus a pinch of critical thinking. Spot the anchor, question whether it truly matters, and give yourself permission to act when the market presents a *reasonable* price, not just the *exact* price you imagined.

---

## 16.2 – Functional Fixedness  

Another brain‑trick that doesn’t get enough airtime on trading podcasts, but it sneaks into the lives of anyone who ever tried to be a “derivatives wizard”.

First, a quick, everyday illustration. I’m a regular at a juice stall near my office. One rainy afternoon I asked for my usual orange juice, only to see the guy wrestling with a loose mixer‑jar handle. He was hunting for a **screwdriver** and could’t find one – the poor lad looked like a deer in headlights.  

Enter his colleague, who spotted a **spoon** on the counter. He flipped it, used the flat end as a makeshift screwdriver, tightened the handle, and voila – juice served!  

That moment is **Functional Fixedness** in action. It’s the mental block that tells us “a spoon is for eating, a screwdriver is for screws”. We cling to the *conventional* use of objects and ignore creative alternatives. In the trading world, that rigidity can cost us real money.

### How it hurts a trader  

Imagine you have **₹100,000** in your trading account. You spot a promising **Nifty** move that you plan to hold for 2‑3 days, so you go **NRML** (the “overnight” product type). The margin requirement for that position is about **₹65,000**.  

You open the trade at 3:20 PM, carry it overnight, and at the end of the day you have:

* **₹65,000** locked as NRML margin  
* **₹35,000** still free (actually ₹45,000 in the original story – we’ll keep that figure)  

Next morning the market opens, Nifty is moving your way, you’re smiling. Then you spot a hot **TCS Futures (MIS)** opportunity that needs **₹60,000** of margin. You look at your free cash – **₹45,000** – and think, “I’m short ₹15,000, can’t take it”.  

**Enter Functional Fixedness:** you treat the NRML margin as an *immutable* block that sits there, untouchable, until you square off the position. But the market gives us a nifty (pun intended) tool: we can *convert* that NRML position to **MIS** for the same underlying, freeing up margin.

#### The out‑of‑the‑box fix  

1. **Start of day:** ₹45,000 free, need ₹15,000 more.  
2. **Convert** the overnight Nifty NRML trade to **MIS**. The margin drops from ₹65,000 to roughly **₹26,000**, releasing **≈₹39,000** back into your free pool.  
3. **Now you have:** ₹45,000 + ₹39,000 = **₹84,000** available.  
4. **Place** the TCS MIS trade (₹60,000 margin). You’re left with **₹24,000** cushion.  
5. **End of day:** Square off the TCS MIS trade. Your free margin returns to **₹84,000**.  
6. **Convert back** the Nifty MIS position to NRML for the next overnight hold.

Boom – you’ve squeezed extra buying power without adding any cash, simply by refusing to see the NRML margin as a *fixed* brick.

The screenshot below (from Kite) shows exactly how the conversion looks.

![Image](https://zerodha.com/varsity/wp-content/uploads/2017/10/Image-3_ff.png)

So, the moral: **don’t let functional fixedness lock you into one way of using your capital.** A little creativity (and a spoon‑like mindset) can unlock hidden margin.

---

## 16.3 – Confirmation Bias  

Let’s dissect a real chart. Here’s **Tata Motors** (TM) as of today.

![Image](https://zerodha.com/varsity/wp-content/uploads/2017/10/Image-4_tm.png)

I’ve drawn a few clues for you:

* The current price sits around **₹430**.  
* Historically, ₹430 has acted like a **price‑action zone** – the stock tends to bounce or reverse there.  
* In early August the price *breached* ₹430, slid to **₹370**, and then formed a nice **double‑/triple‑bottom** around that level.  
* Since that bottom, it’s been on a steady climb right back up to the **₹430** area.

Put those facts together and you might think: “Hey, the stock is primed for a fresh upside move.”  

Now, imagine you see this headline this morning:

![Image](https://zerodha.com/varsity/wp-content/uploads/2017/10/Image-5_tm.png)

Your brain, already primed with the chart analysis, instantly treats the news as **the catalyst** that will launch TM higher. You start nodding, “Exactly! This is why I should buy.”  

But here’s the kicker: the news may be **neutral** or even **negative** in the grand scheme. It might not have the firepower to push the price up. Yet, because you’ve already formed a *belief* (the stock is about to rise), your mind starts **filtering** information – it grabs anything that supports the belief and discards the rest. That’s **Confirmation Bias**.

In plain English: *once you have an opinion, you become a detective looking for clues that prove you right, while ignoring evidence that says “nah, maybe not.”*  

**How to beat it?** Play the devil’s advocate in your own head. When you get a strong hunch, ask yourself **“So what? What would make this hypothesis wrong?”** Write down the contrary arguments, and treat them with equal weight. Critical reasoning is the antidote.

---

## 16.4 – Attribution Bias  

This one is a little *comic* – and a lot of us have lived it.

Picture this: you buy a call option, it **doubles** in a day, you’re on cloud nine. “Wow, I’m a trading guru! My analysis was spot‑on.” You pat yourself on the back, maybe even brag to the group chat.  

Now flip the script. You buy a stock, it tanks **20 %** and you watch your paper loss grow. Suddenly the world is a hostile place. You start blaming **everyone else**:

* “My broker’s platform lagged, so my order never got in on time.”  
* “The charts were glitchy, I couldn’t see the real trend.”  
* “The news feed was delayed – that’s why I missed the exit.”  

In short, you **attribute** the loss to external factors (the broker, the technology) instead of acknowledging that maybe your analysis was off. This is the classic **Attribution Bias** – the tendency to give successes to *yourself* and failures to *others*.

Why do we do it? Because admitting a mistake hurts our ego. It’s easier to say “the broker screwed me” than “I mis‑read the market”.

**Cure?** Keep a **trading journal**. Every trade gets two entries:

1. **Why you entered** – the hypothesis, the data points, the rationale.  
2. **Why you exited** – the profit target, stop‑loss, or the change in market condition that made you close.

Over time the journal becomes a mirror that shows you the *real* cause of each outcome, stripping away the “blame‑the‑broker” narrative. When you can see a pattern of mis‑analysis, you’ll be more motivated to improve, and your ego will get a healthy workout.

---

## 16.5 – And it’s a wrap!  

There are **dozens** of cognitive biases out there; the list is practically endless. Covering every single one would be a *never‑ending* saga (and would make this page taller than the Burj Khalifa). Instead, I’ll leave this chapter **open‑ended** and keep adding fresh biases as I stumble upon them in my own market adventures. ☺  

With this final note, we close the **Risk & Trading Psychology** module. As always, I hope you enjoyed the read as much as I enjoyed writing it (and sprinkling a few jokes along the way). Keep those comments, anecdotes, and “I‑just‑had‑the‑same‑problem” stories coming – they’re the fuel for the next chapter!

### Key takeaways from this chapter  

| Bias | What it does | How it hurts you | Quick fix |
|------|--------------|------------------|-----------|
| **Anchoring Bias** | Locks you onto the first price/info you see (the “anchor”). | You may miss great entries/exits because you wait for that exact number. | Stay flexible; treat the anchor as a *guide*, not a rule. |
| **Functional Fixedness** | Makes you think tools (or margin) have only one purpose. | You leave capital idle, thinking it’s “blocked” forever. | Re‑frame: convert margins, repurpose capital, think like a kitchen‑saver using a spoon as a screwdriver. |
| **Confirmation Bias** | Filters information to only what backs your pre‑existing view. | You ignore red‑flags and chase false signals. | Actively seek disconfirming evidence; ask “so what if I’m wrong?” |
| **Attribution Bias** | Takes credit for wins, blames others for losses. | You never learn from mistakes because you externalise them. | Keep a disciplined journal documenting reasons for entry/exit. |

Happy trading, stay curious, and remember – the market is a mirror. It shows you who you are, biases and all. Cheers!