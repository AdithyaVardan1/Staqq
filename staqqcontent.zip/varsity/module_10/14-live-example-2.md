# 14. Live Example – 2  

**Source:** https://zerodha.com/varsity/chapter/live-example-2/  

---  

## 14.1 – Position Sizing  

Alright, I know we promised to close the pair‑trading saga in the last chapter, but before we hang up our lab coats I’ve got a little “special‑case” story to tell. I’ll keep it short enough that you don’t need a coffee break (but feel free to grab one anyway).  

### The trade that showed up on my screen  

I fired up the pair‑trading algorithm on the evening of **28 May** and the numbers looked like a postcard from “Perfect Pair‑Land”. Here’s the regression output that made me raise an eyebrow (in a good way):  

| Parameter | Value |
|-----------|-------|
| **Stock X** | ICICI Bank |
| **Stock Y** | HDFC Bank |
| **ADF** | **0.048** |
| **Beta** | **0.79** |
| **Intercept** | **1 626** |
| **Std_err** | **2.67** |

Two of the biggest private‑sector banks, same regulatory playground (RBI), similar balance‑sheet DNA… you’d think they were twins separated at birth, right?  

- **ADF = 0.048** → only a 4.8 % chance the residual series is non‑stationary, i.e. **≈ 95 % confidence** that we have a stationary spread. That’s the statistical equivalent of a “thumbs‑up” from the universe.  
- **Std_err = 2.67** → the spread is sitting a tidy 2.67 standard deviations away from its mean, a sweet spot to start a short‑pair (short HDFC, long ICICI).  

### But how many contracts do we actually trade?  

We can’t just throw one lot of each ticker at the market like we did with Tata Motors vs. Tata Motors DVR. The lot‑size mismatch would wreck our beta‑neutrality. Let’s pull out the numbers:  

| Symbol | Futures price | Lot size |
|--------|--------------|----------|
| **HDFC** (Y) | 2 024.8 | 500 |
| **ICICI** (X) | 298.8 | 2 750 |

Remember the beta‑neutral rule from the previous chapter?  

\[
\text{Shares of }X = \beta \times \text{Shares of }Y
\]

Since **β = 0.79**, one share of HDFC needs only 0.79 shares of ICICI to keep the trade market‑neutral. However, the lot sizes force us to think in chunks of 500 (HDFC) and 2 750 (ICICI).  

If we bought **1 lot of ICICI (2 750 shares)**, the “beta‑required” number of HDFC shares would be  

\[
\frac{2 750}{0.79} \approx 3 481.01\text{ shares}
\]

But HDFC only trades in multiples of **500**. The nearest multiple that covers the 3 481‑share requirement is **3 500 shares**, i.e. **7 lots** of HDFC.  

So the practical, beta‑neutral recipe is:

- **1 lot of ICICI** (2 750 shares)  
- **7 lots of HDFC** (3 500 shares)  

That way the weighted exposure lines up nicely and we stay neutral to the market’s overall drift.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2018/05/M10-C14-Cartoon-1.png)  

### Quick sanity check  

If we tried to go “one‑lot‑each” like we did in the Tata example, the exposure ratio would be  

\[
\frac{500}{2 750} \approx 0.182 \neq \beta=0.79
\]

—‑ a disastrous beta mismatch that would leave us exposed to the market’s mood swings. Bottom line: always respect the lot‑size arithmetic, or you’ll end up trading a “pair” that isn’t really a pair at all.  

---

## 14.2 – Intercept  

Now that we’ve nailed the contract counts, the next question is the classic: **“Do I actually take this trade?”**  

On paper everything shines:  

- ADF = 0.048 (stationary spread)  
- Std_err = 2.67 (nice deviation)  
- Two banks that practically share a family reunion every quarter  

Sounds like a “buy‑the‑dip” of a lifetime, right? Well, let’s peek at the **intercept** for the cold, hard truth.  

### What the intercept is really saying  

The regression we ran is:  

\[
y = \beta \, x + \text{Intercept} + \varepsilon
\]

where  

- **y** = price of HDFC (our “Y”)  
- **x** = price of ICICI (our “X”)  
- **β** = 0.79 (the slope)  
- **Intercept** = 1 626  
- **ε** = residual (the random noise)  

Think of the intercept as the “baseline” part of HDFC’s price that **the model cannot explain** using ICICI’s price. In other words, it’s the amount of HDFC’s value that lives outside the linear relationship.  

In our case:  

- **HDFC price** = 2 024 per share  
- **Intercept** = 1 626  

So the model explains only  

\[
\frac{2 024 - 1 626}{2 024} \approx \frac{398}{2 024} \approx 19.7\%
\]

or **roughly 20 %** of HDFC’s price. Conversely, **≈ 80 %** (1 626 / 2 024) of HDFC’s price is just hanging out in the intercept, untouched by ICICI’s movements.  

### Why that matters  

If you trade the pair, you’re essentially **betting on the 20 % that moves together** while ignoring the 80 % that wanders off on its own. It’s like trying to win a dance competition by only mastering the first two steps of a ten‑step routine—there’s a huge chance you’ll trip over the rest.  

From a risk‑management perspective, that’s a red flag. You could end up with a position that looks tidy on the spread chart but is actually **exposed to a massive, unexplained drift** in HDFC’s price.  

### My personal take  

I’d probably **skip** this particular spread and keep hunting for a pair where the intercept is a smaller slice of the pie—say, under 30 % of the dependent stock’s price. That way the regression captures a larger chunk of the price action, and my bet is on something more statistically meaningful.  

Of course, some traders love high‑risk, high‑reward scenarios and might still jump in, especially if they have a separate hedge for that “intercept” portion. But for a casual, risk‑aware investor (or a friend who’s learning the ropes at the bar), I’d advise you to let this one go and wait for a cleaner, more “explained” spread.  

Good luck, and may your betas always be neutral!  

---  

**Download Pair Datasheet**   (link unchanged)  