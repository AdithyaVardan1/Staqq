# 9. PTM2, C2 – Linear Regression  

**Source:** <https://zerodha.com/varsity/chapter/linear-regression/>

---  

## 9.1 – Introduction to Linear Regression  

In the last chapter we flirted with the good‑old straight‑line equation, pulling a “two‑variables‑walk‑into‑a‑bar” story to show how *X* can tease *Y*. The numbers we chose were so friendly that even a lazy glance would whisper, “Hey, they’re related!”  

Fast‑forward to the end of that chapter where we dumped two rag‑tag arrays into a table and asked: *Is there a hidden romance between these two sets?* If yes, can we write it down as a line—*y = mx + c*—and, more importantly, can we name the mysterious **intercept** and **slope**?  

Spoiler: you’ll need more than a squint and a cup of coffee. The table we gave you (re‑posted below for the love‑of‑convenience) looks about as revealing as a cryptic text from a secret admirer.

> ![Image](https://zerodha.com/varsity/wp-content/uploads/2018/02/M10-C9.png)

When you stare at it, nothing screams “relationship” – unless you’re a mutant with X‑ray vision. For us ordinary mortals, we call in the statistical superhero **Linear Regression**. This technique takes two columns of numbers and spits out a buffet of stats, the most prized of which are the intercept (aka “c”) and the slope (aka “m”).  

We’ll harness the ancient power of **Excel** (because why reinvent the wheel when you can just add a plug‑in?). Buckle up: we’re about to embark on a screenshot‑heavy, step‑by‑step adventure. ☺  

### Step 1 – Install the Plugin  

1. Open a brand‑new Excel workbook. Toss the *X* and *Y* values into two columns exactly as the original table did. My version looks like this:  

   > ![Image](https://zerodha.com/varsity/wp-content/uploads/2018/02/Image-1_table.png)

   *Y* is the **dependent** variable (it listens to *X*), while *X* is the independent one (the boss). Both will be fed to the regression engine.  

2. Click the **Data** ribbon (the red‑highlighted tab in the picture).  

   > ![Image](https://zerodha.com/varsity/wp-content/uploads/2018/02/Image-2_data-ribbon.png)

   You should now see a shiny **Data Analysis** button (blue‑highlighted). If it’s playing hide‑and‑seek, don’t panic – we’ll coax it out.  

3. Hit **File** →  

   > ![Image](https://zerodha.com/varsity/wp-content/uploads/2018/02/Image-3_file.png)

4. In the left sidebar, click **Options**.  

   > ![Image](https://zerodha.com/varsity/wp-content/uploads/2018/02/Image-4_option.png)

5. The Options window pops up. Choose **Add‑Ins** on the left, then locate **Analysis ToolPak** in the list, click **Go…**, tick the box, and slam **OK**.  

   > ![Image](https://zerodha.com/varsity/wp-content/uploads/2018/02/Image-5_addin.png)

6. Close Excel, give your computer a quick reboot (or a dramatic sigh), and reopen the workbook. The **Data Analysis** button should now be grinning at you from the Data ribbon.  

### Step 2 – Enter the Values  

Assuming the Add‑In is now your best Excel buddy, let’s actually run the regression:  

1. On the **Data** ribbon, click **Data Analysis**. A pop‑up with a menu of statistical tricks appears. Choose **Regression** and click **OK**.  

   > ![Image](https://zerodha.com/varsity/wp-content/uploads/2018/02/Image-6_data-analysis.png)

2. A new dialog box shows a slew of fields. Focus on the **Input Y Range** and **Input X Range** – they’re the feeding tubes for your data.  

   > ![Image](https://zerodha.com/varsity/wp-content/uploads/2018/02/Image-7_reg.png)

3. Click the little selector button next to **Input Y Range**, then highlight the *Y* column (including the header “Y”). Do the same for **Input X Range** (select the *X* column).  

   > ![Image](https://zerodha.com/varsity/wp-content/uploads/2018/02/Image-8_input.png)  
   > ![Image](https://zerodha.com/varsity/wp-content/uploads/2018/02/Image-9_label.png)

   *Pro tip:* Tick the **Labels** checkbox so Excel knows the first row holds titles, not data.  

4. Down in the **Output Options** section, pick **New Worksheet Ply** (or “New worksheet”). This tells Excel to dump the results onto a fresh tab – nice and tidy. Also, check **Residuals** and **Standardized Residuals**; we’ll talk about those love‑children later.  

   > ![Image](https://zerodha.com/varsity/wp-content/uploads/2018/02/Image-10_output.png)

5. Hit the **OK** button in the top‑right corner. Excel rolls up its sleeves, crunches numbers, and spits out a brand‑new sheet with the regression report.  

## 9.2 – Linear Regression Output  

Voilà! The fresh sheet looks a bit like a financial wizard’s spellbook. The top‑most block is the **Regression Statistics** table (scary at first glance, but we’ll tame it).  

> ![Image](https://zerodha.com/varsity/wp-content/uploads/2018/02/Image-11_summary.png)

Don’t let the avalanche of R‑squared, F‑statistics, and p‑values intimidate you. For now, we only need the **Coefficients** table, which hides the two numbers we’ve been chasing: the slope and the intercept.  

> ![Image](https://zerodha.com/varsity/wp-content/uploads/2018/02/Image-12_coefficient.png)

In the red‑highlighted rows you’ll see:  

| Coefficient | Value |  
|-------------|-------|  
| Intercept (Constant) | **‑7.859813** |  
| X (Slope) | **1.885** |

Why does Excel call the slope “X” instead of the more familiar “M”? Because the developers apparently thought “X” looked cooler, even if it makes our brains do a tiny somersault.  

### Putting the line to work  

Our regression equation is now:  

\[
y = 1.885 \times x \;-\; 7.859813
\]

Let’s test it with a brand‑new *x* value – say **15** (because 15 is the new 10).  

\[
\begin{aligned}
y &= 1.885 \times 15 \;-\; 7.859813\\
  &= 28.275 \;-\; 7.859813\\
  &= 20.415187\;\approx\;20.42
\end{aligned}
\]

So, if *x* = 15, the model predicts *y* ≈ **20.42**.  

### How close is “close enough”?  

Predictions are never perfect; they’re more like polite guesses. Let’s compare with a real data point: when *x* = **18**, the actual *y* in our table is **22**. Plugging 18 into the line gives:  

\[
\begin{aligned}
y_{\text{pred}} &= 1.885 \times 18 \;-\; 7.859813\\
                &= 33.93 \;-\; 7.859813\\
                &= 26.070187
\end{aligned}
\]

The model says **26.07**, but reality says **22**. The gap between them is the **residual**:  

\[
\text{Residual} = y_{\text{pred}} - y_{\text{actual}} = 26.070187 - 22 = 4.070187
\]

Excel’s output even lists this residual for every observation. In the screenshot below, the residual for *x* = 18 is highlighted.  

> ![Image](https://zerodha.com/varsity/wp-content/uploads/2018/02/Image-13_residuals.png)

Why do we care? Because the whole **relative‑value** trading trick we’ll explore later hinges on those residuals – they tell us where the line is over‑ or under‑shooting, and that’s where trading opportunities hide. Keep that in mind and stay tuned!  

You can grab the companion Excel workbook **[here]**(download‑link‑placeholder).  

### Key takeaways from this chapter  

- **Linear regression** is a statistical wizard that turns two columns of numbers into a straight‑line equation.  
- Excel can do the heavy lifting, but you must first summon the **Analysis ToolPak** add‑in.  
- Among the many outputs, the **slope** (X) and **intercept** (Constant) are the stars you need to write the line.  
- With slope + intercept, you can **forecast** the dependent variable *y* for any new *x*.  
- The **residual** = actual y – predicted y tells you how far off the model is for each observation.  
- Those residuals aren’t just footnotes; they become the main actors in the **relative‑value trading** drama we’ll act out next.  

Enjoy the regression ride, and remember: if the numbers start talking, make sure you’re listening with both ears and a sense of humor. 🍻  