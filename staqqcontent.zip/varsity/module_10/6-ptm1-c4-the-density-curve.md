# 6. PTM1, C4 – The Density Curve  

**Source:** <https://zerodha.com/varsity/chapter/the-density-curve/>

---  

## 6.1 – A quick recap  

Alright, before we dive into the mystical world of density curves, let’s make sure we’re all standing on the same financial treadmill (and not one of those wobbly ones that tip over when you sneeze). Grab a coffee, skim this recap, and promise me you won’t fall asleep—otherwise the pair‑trading fairy might turn you into a spreadsheet.  

- **Comparable companies = same vibe.** Two stocks are “comparable” when they come from a similar business background – think of them as cousins at a family reunion rather than strangers on a blind date.  
- **Business background = daily‑life drivers.** Things like industry, market size, regulatory environment, and product mix shape how the business runs day‑to‑day.  
- **Similar background ⇒ similar price swings.** If the cousins have the same DNA, their share‑price moves will often look like they’re dancing to the same song.  
- **Joint moves → tight correlation.** When the daily returns of the two stocks jiggle together, the correlation coefficient usually leans toward the “close‑friend” zone (think > 0.7).  
- **Local events = the plot twist.** A sudden policy change, a new product launch, or a CEO’s eyebrow‑raising tweet can make one cousin stray, giving you a pair‑trading opening.  
- **Three ways to measure the relationship:** spread, differential, **or** ratio. Pick your weapon; they’re just different lenses on the same romance.  
- **Normal‑distribution assumption.** We assume those variables (spread, differential, ratio) are *approximately* normally distributed, so we can talk about mean, median, mode, and—most importantly—standard deviation (SD).  
- **SD cheat‑sheet.** Most textbooks hand you a table that goes out to the 3rd SD on either side of the mean (that’s 99.7 % of the data, give or take a rounding error).  
- **Where we are in the story.** We’ve been cruising through Paul Whistler’s classic pair‑trading method; soon we’ll step into a slightly more sophisticated version.  

So, buckle up. This chapter is where the **density curve** makes its debut, and where the “trigger” for a pair trade finally gets a face.  

---  

## 6.2 – Selecting the variable  

Now that we’ve got our two cousins identified, we need to decide which of the three possible “relationship metrics” we’ll actually follow. **Spread**, **differential**, or **ratio**—which one gets the spotlight?  

Why not just run all three at once, you ask? Because trying to listen to three DJs at the same time will leave you with a headache and no clear beat to dance to. Sticking to a single metric keeps our trading regime clean, avoids contradictory signals, and—most importantly—makes our lives less confusing.  

I threw all three out there to prove that you have options. The choice is yours, like picking a favorite pizza topping. My personal favorite? **The ratio**. Here’s why:  

1. **Valuation‑centric.** The ratio implicitly captures market valuation because it uses the *latest* prices of both stocks.  
2. **Position‑sizing shortcut.** It tells you, in one glance, how many shares of Stock 2 you need to hedge one share of Stock 1.  

**Quick example:**  

- Stock 1 price = ₹190  
- Stock 2 price = ₹80  

\[
\text{Ratio} = \frac{190}{80} = 2.375
\]

Interpretation: for every 1 share of Stock 1 you hold (or short), you should hold 2.375 shares of Stock 2 (long or short, depending on the direction of the trade). We’ll dive into the nitty‑gritty later, but you get the gist.  

Feel free to swing the other way—use spread or differential if that makes your heart sing. For the rest of this chapter, though, we’ll keep the ratio as our trusty sidekick.  

---  

## 6.3 – The trade trigger  

Okay, picture this: a pair is just two stocks, but you can treat the pair as *one* tradable instrument—like a cocktail you sip instead of two separate drinks. We haven’t yet explained how to actually buy or sell the pair (that’s coming up), but imagine you can place a single order that simultaneously goes long on one and short on the other.  

Your decision to go long or short hinges on the variable you’re tracking—in our case, the **ratio**. The ratio is a living, breathing number that changes every time the underlying stock prices change (which, spoiler alert, is *every* trading day). Most days it wiggles inside a “comfort zone” around its average. Occasionally, it spikes out of that zone, and those spikes are where the pair‑trading magic happens.  

### The chart that sparked a revelation  

![Image](https://zerodha.com/varsity/wp-content/uploads/2018/01/Image-1_Ratio-daily-change.png)

A casual glance gives us two nuggets of wisdom:  

- **Mean hover zone.** The ratio spends most of its time dancing between roughly **1.8 and 2.0**—that green line is the mean (or at least a close approximation).  
- **Oscillation.** The ratio flutters above and below that mean on a day‑to‑day basis, like a pendulum with a caffeine habit.  

Pause. Think. This is the “aha!” moment in pair trading. If you’ve soaked up everything up to now, the rest is almost as easy as ordering a round of drinks.  

The ratio, by definition, is **Stock 1 ÷ Stock 2**. Because both stocks move, the ratio moves. Plot the daily ratio changes, and you’ll notice a *mean* (the average value) and a cloud of points scattered around it. No matter whether the ratio sits **above** or **below** the mean today, there’s a *good chance* it will drift back toward the mean in the near future.  

That “good chance” isn’t just a hunch; it’s a statistical probability you can actually **measure**.  

### Mean reversion – the old faithful  

In finance‑speak, this comeback‑to‑average behavior is called **mean reversion**. Look at the chart below (red circles added for drama):  

- The **first red circle** marks a point where the ratio shot **above** the mean.  
- The **second red circle** marks a point where the ratio dipped **below** the mean.  

In both cases, the ratio later *reverted* to the mean, like a boomerang that refuses to stay away.  

**Trading implication:**  

- When the ratio spikes **high**, you could **short** it (sell the ratio now, buy it back when it slides down).  
- When the ratio plunges **low**, you could **go long** (buy now, sell when it climbs back).  

Think of the ratio as a stand‑alone security—its directional move is *predictable enough* that you can place bets on it, just like you would on a stock or a futures contract.  

**Quick sanity check:**  

- **Above the mean?** Expect a pull‑back → **short** the ratio.  
- **Below the mean?** Expect a bounce‑back → **long** the ratio.  

Sounds simple, right? Yet a couple of eyebrows‑raising questions pop up:  

1. **Is there always a trade?** The ratio is *always* either above or below the mean—does that mean we have a perpetual trading opportunity?  
2. **When exactly to jump in?** The chart shows many peaks and troughs—how do we know which one is the *right* one?  

The secret sauce to answering those questions is the **Density Curve**. Let’s crack it open.  

---  

## 6.3 – The Density Curve  

Feast your eyes on this next illustration:  

![Image](https://zerodha.com/varsity/wp-content/uploads/2018/01/Image-2_DC.png)

Four red circles highlight moments when the ratio was **above** the mean. Suppose you were staring at the chart right when the **first** circle lit up. Would you immediately slam the brakes on a short trade just because the ratio is high? The answer is a resounding **“maybe not.”**  

Why? Because not every excursion above (or below) the mean is a *high‑probability* mean‑reversion event. We want to pull the trigger **only when the odds are heavily stacked** in our favor—think of a tiger waiting for the perfect pounce, not leaping at the first rustle of leaves.  

### Enter the Normal (Gaussian) Distribution  

We’ll lean on the old friend **Normal distribution** (the bell curve that makes statisticians swoon). If you’ve been paying attention in earlier chapters, you’ll recall these golden rules:  

| SD band | Approx. % of observations |
|--------|---------------------------|
| ±1 SD  | 68 %                     |
| ±2 SD  | 95 %                     |
| ±3 SD  | 99.7 %                   |

These percentages tell us how *rare* it is for a value to land far from the mean.  

### Applying SD to our ratio  

- Every ratio value can be expressed in **standard‑deviation units** away from its mean.  
- **0.5 SD** away? That’s a casual stroll—nothing special.  
- **2 SD** away? According to the bell‑curve rule, only **5 %** of observations go that extreme. In other words, there’s a **95 %** chance the ratio will swing back toward the mean.  
- **3 SD** away? The odds of going even farther are a microscopic **0.3 %**, meaning a **99.7 %** chance of mean reversion.  

So, by watching **how many SDs** the ratio is from its mean, we can *filter* the noisy, low‑confidence spikes and keep only the high‑probability, high‑reward moments.  

**Key insight:** The trigger isn’t just “ratio > mean” or “ratio < mean”; it’s also **how far** the ratio is from the mean, measured in SDs.  

### Tracking the Density Curve instead of raw ratio  

Because the SD‑adjusted view is so powerful, many traders monitor the **Density Curve** of the ratio directly. The density curve is a **non‑negative number between 0 and 1** that tells you the *probability density* of the observed ratio value given its normal distribution. Think of it as a “confidence meter” that slides toward 0 when the ratio is far out in the tails (high confidence of reversion) and hovers around 0.5 when the ratio is near the mean (low urgency).  

You can compute this in Excel with the built‑in **NORM.DIST** function (or **NORMDIST** in older versions). The syntax needs four arguments:  

1. **X** – the daily ratio value you’re evaluating.  
2. **Mean** – the historic average of the ratio (you can pull this from your earlier descriptive stats).  
3. **Standard Deviation** – the historic SD of the ratio.  
4. **Cumulative** – set to **TRUE** (the default) to get the cumulative distribution value (the density we want).  

Here’s a snapshot of the Excel layout we used:  

![Image](https://zerodha.com/varsity/wp-content/uploads/2018/01/Image-3_DC.png)

And the resulting table after applying **NORM.DIST** to every day’s ratio:  

![Image](https://zerodha.com/varsity/wp-content/uploads/2018/01/Image-4_DCall.png)

Now you have a neat column of numbers between 0 and 1 that tells you, at a glance, *how “deep” into the tail* each observation sits.  

That’s all for this chapter—take a breather, maybe pour yourself another coffee, and get ready for the next part where we’ll turn those density‑curve values into actual **long and short pair‑trade signals**.  

**Download the Excel sheet** used in this walkthrough if you want to play with the numbers yourself.  

---  

### Key takeaways from this chapter  

- **Ratio reigns supreme** as a variable because it blends price information with valuation intuition.  
- The ratio *oscillates* around a mean, just like most financial time‑series.  
- When the ratio wanders away from its mean, it tends to **revert**—that’s the essence of mean reversion.  
- The **probability** of reversion can be quantified using the **Normal distribution** (standard‑deviation bands).  
- The **Density Curve** converts that probability into a tidy 0‑to‑1 metric you can track in Excel with `NORM.DIST`.  
- By focusing on points where the density curve is **very low** (i.e., ratio deep in the tails), you increase the odds that your trade will be a success.  

Stay tuned for the next chapter, where we’ll turn those low‑density signals into actual buy‑and‑sell orders, and you’ll finally get to watch the tiger pounce on its prey! 🚀  