# 8. Pair‑Trade Method 2, Chapter 1 (PTM2, C1) – The Straight‑Line Equation  

**Source:** <https://zerodha.com/varsity/chapter/straight-line-equation/>

---  

## 8.1 – A straight relationship  

It’s February 14th, the day when every café, chocolatier and florist suddenly becomes a love‑temple. People are busy posting heart‑shaped emojis, swapping roses, and debating whether “love at first sight” is a myth or a clever marketing ploy. I, on the other hand, am sipping a *single* espresso and thinking: “Valentine’s Day is just a big‑ticket sales event for the romance industry.”  

Since the universe (or at least my calendar) is already serving up a love‑fest, why not use the occasion to talk about… relationships? Don’t worry, I won’t launch into a cheesy rom‑com plot or hand you a “10‑step guide to keeping the spark alive.” Instead, we’ll look at **two sets of numbers** and ask the age‑old question: *Do they have a relationship?*  

In doing so, I’ll drag you—reluctantly, I know—back to the dusty halls of high‑school math, where the most exciting thing was figuring out whether the line on the graph would pass through the cafeteria. If you’ve survived chapters 1‑7 of this module, you already know a basic pair‑trade trick (thanks, Mark Whistler).  From now on we crank the gear up a notch and step into the world of **Statistical Arbitrage**, also known as **Relative‑Value Trading (RVT)**.  

### A quick flash‑back to the good‑old straight‑line  

Do you remember the day your math teacher introduced the equation of a straight line?  If you were anything like me, you stared out the window, imagined the teacher as a bored robot, and wondered when this would ever help you buy a cheap stock.  Had the teacher whispered, *“Learn this and you’ll make money someday,”* we might have all been scribbling notes like there was no tomorrow.  

![Cartoon of a bored student staring out a window](https://zerodha.com/varsity/wp-content/uploads/2018/02/M10-C8-Cartoon.png)  

Second chances are a thing, so let’s give the line another look—this time with the promise of profit in the background.  

The generic straight‑line formula looks like this:  

\[
\boxed{Y = mX + \varepsilon}
\]

> **Y** – dependent variable (the one that *follows* the other)  
> **X** – independent variable (the one that *leads*)  
> **m** – slope (how steeply Y changes when X moves)  
> **\(\varepsilon\)** – intercept (the value of Y when X = 0)  

In plain English: *Take X, multiply it by the slope, then add a constant, and you’ve got Y.*  

Sounds like wizardry?  Stick with me; the magic becomes useful pretty quickly.

### Example #1 – The gym‑bros  

Meet **FF1** and **FF2**, two gym‑rats who treat the squat rack like a holy altar.  FF2 is the “go‑hard‑or‑go‑home” type: whatever FF1 does, FF2 does *twice* as many.  Here’s their weekly push‑up log:

| Day       | FF1 (push‑ups) | FF2 (push‑ups) |
|-----------|----------------|----------------|
| Monday    | 5              | 10 |
| Tuesday   | 8              | 16 |
| Wednesday | 12             | 24 |
| Thursday  | 15             | 30 |
| Friday    | 20             | 40 |
| Saturday  | **15**         | **?** |

If you eyeball the table, you’ll guess FF2 will do **30** push‑ups on Saturday (2 × 15).  That’s because **FF2** depends on **FF1**.  FF1 is the *independent* variable (X), FF2 is the *dependent* variable (Y).  

Plugging the numbers into the line equation:

\[
\text{FF2} = m \times \text{FF1} + \varepsilon
\]

We already know the pattern: each FF2 count is exactly twice the FF1 count, and there’s no “extra” push‑ups.  So  

* slope \(m = 2\)  
* intercept \(\varepsilon = 0\)  

Thus the relationship is simply  

\[
\boxed{\text{FF2} = 2 \times \text{FF1} + 0}
\]

A one‑liner that tells you, “Whatever FF1 does, double it, and you’ve got FF2.”

### Example #2 – The paratha‑hounds  

Now let’s swap dumbbells for dough.  Meet **H1** and **H2**, two starving fellows who treat parathas like a cash‑cow.  H2 always eats *twice* what H1 eats **plus** an extra 1.5 parathas—no matter how full H2 feels.  

| Day       | H1 (parathas) | H2 (parathas) |
|-----------|---------------|---------------|
| Monday    | 2             | 5.5 (= 2×2 + 1.5) |
| Tuesday   | 3             | 7.5 |
| Wednesday | 1.5           | 4.5 |
| Thursday  | 4             | 9.5 |
| Friday    | 2.5           | 6.5 |
| Saturday  | **4**         | **?** |

Again, the pattern is crystal clear:  

\[
\text{H2} = 2 \times \text{H1} + 1.5
\]

* Slope \(m = 2\) (double the base)  
* Intercept \(\varepsilon = 1.5\) (the “always‑extra” bite)  

On Saturday H2 will gobble **9.5** parathas (4 × 2 + 1.5).  The line tells us exactly how greedy H2 is.

### Example #3 – The diet‑conscious skeptic  

What if Y never cares about X?  Imagine **Y**, a monk‑like eater who consumes a *fixed* 1.5 parathas each day, regardless of how many X eats.  

| Day | X (parathas) | Y (parathas) |
|-----|--------------|--------------|
| 1   | 3            | 1.5 |
| 2   | 5            | 1.5 |
| 3   | 2.5          | 1.5 |
| 4   | 7            | 1.5 |

Here the line collapses to  

\[
Y = 0 \times X + 1.5
\]

Slope \(m = 0\) → Y is **independent** of X, and the intercept \(\varepsilon = 1.5\) is the constant diet.  In other words, “Y doesn’t care, I’ll just eat my 1.5 every day.”

### When the pattern isn’t obvious  

Let’s drop the gym, the parathas, and the monks, and throw a random pair of number series at you:

| X | Y |
|---|---|
| 1 | 4 |
| 2 | 5 |
| 3 | 8 |
| 4 | 7 |
| 5 | 10 |
| 6 | 12 |

Just by glancing, you might think “huh, there’s no straight line here.”  That *doesn’t* mean there’s no relationship—it just isn’t obvious to the naked eye.  To uncover the hidden line (if any) we need a tool that can **fit** the best possible straight line through the scatter of points.  

Enter **linear regression**.  It crunches the data, minimizes the sum of squared errors, and spits out the optimal slope \(m\) and intercept \(\varepsilon\).  In the next chapter we’ll meet this statistical match‑maker and see how it becomes the engine behind statistical arbitrage.

---

## Key takeaways from this chapter  

- A straight‑line equation (\(Y = mX + \varepsilon\)) can capture the relationship between two numeric variables.  
- One variable is **dependent** (Y) – it “follows” the other; the other is **independent** (X) – it “leads.”  
- The **slope** \(m\) tells you how many units Y changes for a one‑unit change in X.  
- The **intercept** \(\varepsilon\) is the value of Y when X = 0 (the “baseline”).  
- If the slope is zero, Y is a constant: \(Y = \varepsilon\).  
- Real‑world data often hide relationships that are not visually obvious.  
- **Linear regression** is the statistical technique that uncovers the best‑fit line, giving you the slope and intercept you need for relative‑value (pair‑trade) analysis.  

Now that you’ve refreshed your high‑school romance with lines, stay tuned—next we’ll let the numbers do the flirting and actually **fit** the line! 🚀