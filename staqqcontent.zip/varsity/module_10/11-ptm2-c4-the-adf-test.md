# 11.  PTM2, C4 – The ADF test  

**Source:** <https://zerodha.com/varsity/chapter/the-adf-test/>

---  

## 11.1 – Co‑Integration of two‑time series  

Alright, buckle up, because we’re about to dip our toes into a pond that’s a little deeper than the usual “price‑vs‑price” splash. We’ll skim the surface of some high‑falutin statistical theory, but I promise to keep the jargon to a minimum and the practical bits front‑and‑center. Think of it as a “pair‑trading cocktail” – a dash of theory, a splash of regression, and a garnish of intuition.

Before we go any further, let’s do a quick “re‑tour” of everything we’ve learned so far, just to make sure the foundations are still standing (and not wobbling like a drunk bartender).

- **Chapters 1‑7** gave you the basics of a *pair trade* – the kind of “buy‑this‑stock, sell‑that‑stock” you’d do after a couple of beers.  The purpose? To build a rock‑solid base for the more sophisticated *relative‑value* trade.
- The *relative‑value* trade leans heavily on **linear regression** – the statistical version of “if X goes up, Y goes down… or maybe the other way around.”
- In a regression, we pick an **independent variable (X)** and a **dependent variable (Y)** and then we let the algorithm do the heavy lifting.
- The outputs we care about are the **intercept**, **slope (beta)**, **residuals**, **standard error**, and the **standard error of the intercept** – basically the five amigos of regression.
- Deciding which stock should be X and which should be Y isn’t a guess‑work lottery. We flip‑flop the two stocks, compute an **error ratio**, and the arrangement with the *lowest* error ratio wins the “X‑or‑Y” crown.

If any of that feels fuzzy, hit the rewind button, reread those chapters, and come back refreshed.  

Remember the *residuals* we talked about in the previous chapter?  They’re the unsung heroes of pair‑trading – the little leftovers after the regression line does its thing.  From now on, they’ll be the main character, and we’ll see whether they behave like a well‑trained circus animal (stationary) or a wild bull (non‑stationary).  

Two new buzz‑words will pop up on our radar: **Cointegration** and **Stationarity**.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2018/04/M10-C11-cartoon.png)

### What does “cointegrated” actually mean?  

Picture two stocks – let’s call them **Stock X** and **Stock Y** – that usually dance together in perfect sync.  If they ever step on each other’s toes (i.e., drift apart), it’s only temporary – maybe a stray news event or a market hiccup.  Soon enough they find each other’s rhythm again and continue moving as a pair.  

That’s exactly what we crave in pair‑trading: a duo that *re‑converges* after a deviation.  In statistical parlance, we say the two series are **cointegrated**.  

So, how do we check if two stocks are truly a “peanut butter‑and‑jelly” combo?

1. **Run a linear regression** between the two series.  
2. **Grab the residuals** from that regression.  
3. **Test whether those residuals are stationary** (more on that in a moment).  

If the residuals are stationary, the stocks are cointegrated, and you’ve got yourself a pair‑trading candidate that’s indifferent to overall market direction – a true market‑neutral setup.  

Think of it this way: any regression will spit out a line, but if the leftover wiggle‑room (the residuals) keeps wandering off to infinity, that line is about as useful as a chocolate teapot.  Stationarity is the litmus test that tells us “Hey, this line actually means something.”

Thus, the whole quest reduces to answering a single question: **Are the residuals stationary?**  

You could jump straight to the answer by using the **ADF test** (augmented Dickey‑Fuller), but before we do that, let’s unpack what “stationarity” really means – without pulling out a PhD‑level textbook.

---

## 11.2  Stationary and non‑stationary series  

A time series is **stationary** when it respects three simple rules.  If it follows **all three**, we call it *strictly stationary*.  If it follows **two** (or one), we call it *weakly* stationary – basically “almost there.”  If it follows **none**, it’s a *non‑stationary* mess, the statistical equivalent of a toddler on a sugar high.

### The three golden rules  

1. **Mean stays put** – the average value doesn’t drift around like a lost tourist.  
2. **Standard deviation stays in a tight band** – volatility isn’t a roller‑coaster that spikes and crashes randomly.  
3. **No autocorrelation** – a value at time *t* doesn’t depend on values at earlier times (i.e., the series has no memory).  

When we’re pair‑trading, we only want pairs that satisfy **all three**.  Anything less, and we’re flirting with a false signal.

Let’s walk through a hands‑on example so you can see these rules in action.  

We have two synthetic series, each with **9,000** data points, named **Series A** and **Series B**.  We’ll test each series against the three conditions.

---

### Condition 1 – The mean should be the same (or within a tight range)  

We slice each series into three equal chunks and compute the mean of each chunk.  If the three means are roughly the same, the overall series mean is stable.

#### Series A – Means across three chunks  

![Image](https://zerodha.com/varsity/wp-content/uploads/2018/04/Image-1_Mean.png)

Look at that!  All three chunk‑means huddle together like friends at a coffee shop – a clear sign that the overall mean is steady.

#### Series B – Means across three chunks  

![Image](https://zerodha.com/varsity/wp-content/uploads/2018/04/Image-2_mean-seriesb.png)

Uh‑oh.  Series B’s means are doing the cha‑cha‑cha across the board, swinging wildly.  That’s a red flag for stationarity.

---

### Condition 2 – Standard deviation stays in a narrow band  

Again we split the series and compute the **standard deviation (σ)** for each slice.

#### Series A – σ across three chunks  

![Image](https://zerodha.com/varsity/wp-content/uploads/2018/04/Image-3_sda.png)

The σ values hover between **14 %** and **19 %** – a tight, well‑behaved range.  Good for us.

#### Series B – σ across three chunks  

![Image](https://zerodha.com/varsity/wp-content/uploads/2018/04/Image-4_sdb.png)

Series B’s σ is all over the place, like a DJ who can’t decide on a beat.  Another non‑stationary sign.

---

### Condition 3 – No autocorrelation (the series has no memory)  

In plain English, **autocorrelation** means “the past is haunting the present.”  If the 9th value is 29, a strong autocorrelation would imply that value 29 is heavily influenced by values 1‑8.  For a stationary series, we want that influence to be *near zero*.

#### How to test it quickly  

1. Take the first *n‑1* points → call it **Series X**.  
2. Take the last *n‑1* points (starting one step later) → call it **Series Y**.  
3. Compute the correlation between X and Y – this is the **1‑lag correlation**.  
4. Repeat for 2‑lag, 3‑lag, etc.  

If each lag‑correlation is close to **0**, we’re good.

#### Series A – 2‑lag correlation  

![Image](https://zerodha.com/varsity/wp-content/uploads/2018/04/Image-6_2lag.png)

Correlation ≈ 0 → Series A looks memory‑less. ✅

#### Series B – 2‑lag correlation  

![Image](https://zerodha.com/varsity/wp-content/uploads/2018/04/Image-7_2lag.png)

Correlation ≈ 1 → Series B is practically a diary of its own past. ❌

---

**Bottom line:**  
- **Series A** passes all three tests → **stationary**.  
- **Series B** fails multiple tests → **non‑stationary**.

I know this “split‑into‑three‑chunks” dance looks a bit unorthodox, and you’re probably thinking “Where are the scary equations?”  I deliberately kept the math out of the way because our ultimate goal is to *trade*, not to earn a PhD in econometrics.  

In reality, you **don’t need** to run all those manual checks yourself.  The **ADF test** does the heavy lifting for you – it packages the three conditions into a single p‑value.  Let’s see how that works.

---

## 11.3  The ADF test  

The **augmented Dickey‑Fuller (ADF) test** is the Swiss‑army‑knife of stationarity testing.  It checks the mean, variance, and autocorrelation (including multiple lags) in one go, and spits out a **p‑value**.  

### Interpreting the p‑value  

- **p‑value = 0.25** → 25 % chance the series is *non‑stationary* (i.e., 75 % chance it **is** stationary).  
- **p‑value ≤ 0.05** → We’re 95 % confident the series is stationary – the gold standard for “yes, go ahead and trade.”  

*Important:* The ADF test never says “Yes, it’s stationary.” It only tells you **how confident** you can be about that claim.

### How to run it  

Running the ADF test isn’t exactly a one‑click “Google it” affair.  

- **Python fans:** The `statsmodels.tsa.stattools` module ships a ready‑made `adfuller` function.  
- **Excel users:** You need a special add‑in (e.g., the *XLSTAT* or *Analyse-it* plugin) – unfortunately, those are usually paid.  

I wish there was a free, no‑code solution, but for now you either code it yourself or wait for my next “Pair Data” spreadsheet.

### The “Pair Data” sheet (coming soon)  

Every 10‑15 days I’ll drop a spreadsheet that contains:

- The **X** and **Y** designations for each pair (so you don’t have to guess).  
- The **intercept** and **beta** (the regression line).  
- The **p‑value** from the ADF test on the residuals.  

The look‑back window is **200 trading days**, and for now I’m focusing on **banking stocks** (because banks love to move together like a herd of cows).  

Here’s a sneak peek of the latest sheet:

![Image](https://zerodha.com/varsity/wp-content/uploads/2018/04/Image-8_pd.png)

- **Federal Bank (Y) vs. PNB (X)** has a p‑value of **0.365** → only a 63.5 % chance the residuals are stationary.  Not a trade‑worthy pair.  
- **Kotak vs. PNB** shows a p‑value of **0.01** → 99 % confidence it’s stationary.  Bingo!  
- **HDFC vs. PNB** has a p‑value of **0.037** → also solid.  

P‑values don’t swing wildly day‑to‑day, so a fortnightly refresh is sufficient.

---

## Quick recap – what you should walk away with  

- **Pair‑trading premise:** Buy the undervalued leg, sell the overvalued leg, profit from convergence.  
- **Linear regression basics:** X (independent) vs. Y (dependent); intercept, slope, residuals, standard errors.  
- **Error‑ratio trick:** Swap X and Y, compute error ratios, pick the arrangement with the lower ratio.  
- **Residuals = the truth serum:** If they’re stationary, the two stocks are **cointegrated** and thus move together.  
- **Stationarity = constant mean, constant σ, no autocorrelation.**  
- **ADF test = the all‑in‑one stationarity checker**; look for a **p‑value ≤ 0.05**.  

If any of the bullets still look hazy, go back to **Chapter 7** (the regression refresher) and give it another spin.

Next up, we’ll walk through a *real* pair‑trade from start to finish, so you can see the theory in action.

You can download the **Pair Datasheet (updated 11 April 2018)** from the link in the original article.

---

### Shout‑out  

This chapter wouldn’t exist without my long‑time buddy **Prakash Lekkala**, who supplied the brain‑fuel and a few late‑night coffee runs.  Thanks, Prakash! 😊  

---

### Key take‑aways (the “cheat‑sheet” version)  

- **Cointegrated stocks move together** – perfect for market‑neutral pair trades.  
- **Residuals must be stationary** for the cointegration claim to hold.  
- A **stationary series** has a **constant mean**, **constant standard deviation**, and **no autocorrelation**.  
- The **ADF test** gives you a **p‑value**; aim for **≤ 0.05** (5 % or lower) to deem the series stationary.  

Now go forth, test those pairs, and may your residuals always be stationary! 🎉