# 1. What to expect?

**Source:** https://zerodha.com/varsity/chapter/what-to-expect/

---  

##  

![Image](https://zerodha.com/varsity/wp-content/uploads/2017/10/M10C1-Cartoon.png)

## What is a trading system?

Welcome, future market‑wizard! It’s a bright, sunny day to kick off this module, and the markets have already handed us a headline that looks like it was ripped from a Bollywood blockbuster.

![Image](https://zerodha.com/varsity/wp-content/uploads/2017/10/Image-1_news.png)

On **24 Oct 2017** (yes, that’s the day we all pretended we’d remember), the Finance Minister announced a **₹210,000 crore** infusion into the public‑sector banking system. In plain English: the government decided to give the PSU banks a massive “pep‑talk” (and a lot of cash) to rescue them from the nightmare of ever‑growing NPAs (Non‑Performing Assets).

### How did the PSU banks react?

If you ever wondered what a PSU bank does when it suddenly gets a financial hug, picture a kid in a candy store who just discovered the “Buy One, Get One Free” aisle. They went **jubilant**, as you’d expect.

![Image](https://zerodha.com/varsity/wp-content/uploads/2017/10/Image-2_index.png)

Just look at that chart: the PSU Bank index **spiked 27.75 %** right at the open. That’s the kind of jump that makes traders’ hearts beat faster than a double‑espresso on a Monday morning.

### The real show‑stopper

Some of those PSU‑related options went absolutely **steroid‑fueled**. The star of the day? None other than Punjab National Bank (PNB).

![Image](https://zerodha.com/varsity/wp-content/uploads/2017/10/Image-3_pnb.png)

PNB’s **₹160 Call** expiring on **26 Oct 2017** surged an eye‑popping **20,600 %** overnight! Let’s do the math for the fun of it: if you’d bought **₹1 lac** of that option on 24 Oct, you’d be looking at roughly **₹2.02 cr** the next morning. (That’s 202 times your original cash—enough to buy a small island or a very fancy sofa.)

So, yes—there was definitely a party happening on the market floor.

---

## The “Eureka” Moment (and a tiny strangle)

Later that same day, my colleague and I were sipping chai, watching the market dance, and hunting for a sweet spot to slip a trade into. The **Bank Nifty** decided to join the fiesta, climbing about **3 %** (see the sectoral indices above). Sounds great, right? Hold that thought.

Remember, **PSU banks only make up about 10 %** of the Bank Nifty basket. If you glance at the index constituents and their weightings, you’ll see that a 3 % surge in a sub‑segment that’s barely a tenth of the whole is a bit… **suspicious**.

![Image](https://zerodha.com/varsity/wp-content/uploads/2017/10/Image-4_banknifty.png)

Because of that oddity, we hatched a **short strangle** on Bank Nifty, collecting roughly **253 points per lot** in premium. Our logic? “If the volatility fizzles out, those premiums will shrink and we’ll pocket the difference.” Simple, right? I’m not here to debate whether the trade was genius or a gamble—just hoping it turned out sweet (☺).

### The real lesson: systematic deduction

What matters here isn’t the profit (though we love profit), but the **thought process** behind the trade. We arrived at the idea via what I call **“systematic deduction.”** In plain terms: ask the market what it’s doing, question the obvious, and sometimes take the *contrarian* route—just like ordering the weirdest dish on the menu because you trust your gut.

**Systematic deduction** is a favorite among traders, but it isn’t a magic wand. You can still fall prey to biases and make systematic **mistakes**. Still, it’s one of the core techniques, alongside some… *ahem*… less‑formal methods such as:

- Trade because your gut says “buy now, sell later.”
- Trade because your buddy swears he saw the next big thing.
- Trade because the guy on TV is shouting “Buy! Buy! Buy!”
- Trade because your broker whispered “Don’t miss this!”

None of these, including systematic deduction, is a **process** you can write in stone, let alone back‑test. In trading‑lore, anything that can’t be defined, quantified, or back‑tested is **not a trading system**—it’s just a hunch wrapped in a napkin.

---

## So, what *is* a trading system?

If you can **spell out the steps**, **measure the inputs**, and **quantify the outcomes**, you’ve got a **trading system**. That’s the focus of this whole module. Think of it as a recipe: you list the ingredients (inputs), describe the cooking method (logic), and decide whether the final dish (output) is tasty enough to serve.

### Quick visual recap

![Image](https://zerodha.com/varsity/wp-content/uploads/2017/10/M10C1-Trading-System.png)

Notice the flow?

1. **You** feed the system with data (prices, volumes, volatility, whatever you like).  
2. **You** design the logic (rules, thresholds, filters).  
3. **You** decide—based on the system’s output—whether to hit the “execute” button.

In short, the *money‑making* part still lives in your hands. The beauty of a system? You only need to craft the logic **once** and then let it do the heavy lifting—like hiring a robot bartender who never forgets the recipe.

I’ve deliberately stripped the journey down to the basics here, just to give you a mental picture before we dive into the nitty‑gritty.

---

## 1.3 What to expect from this module?

By the time you finish this chapter, you’ll have **complete** trading systems at your fingertips—each system will include:

- **The core logic** (the brain of the system)  
- **Input parameters** (the data you’ll feed it)  
- **How to interpret the output** (what the system tells you)  
- **The trade decision** (go or no‑go)

### The four star‑studded systems we’ll unpack

1. **Pair trading** – two‑stock tango, where one goes up, the other goes down, and you profit from the spread.  
2. **Volatility‑based Delta hedging** – a fancy way of saying “let’s keep the portfolio’s price swings under control.”  
3. **Calendar spreads** – buying and selling options with different expiries, hoping time decay works in our favor.  
4. **Momentum strategy (Portfolio approach)** – riding the wave of stocks that keep moving in the same direction.

#### Pair trading—two flavors

We’ll explore **two** techniques for pair trading:  

- A **simple** correlation‑based method (think “if these two stocks usually move together, let’s exploit when they don’t”).  
- A **slightly more sophisticated** statistical version (involving means, standard deviations, and the occasional “what‑the‑heck‑is‑this?”).

Feel free to suggest other systems as we go; I’m happy to add them if they’re tasty enough.

### No back‑testing? (Don’t panic, you’re still the hero)

This module **won’t** walk you through the back‑testing code. That’s on **you**, the aspiring quant. Your mission: take the rule‑set, run it on historical data, and see how often it would have made you money—plus what the profit curve looks like.

Why skip the code? I’m not a programming wizard, and I didn’t want to drown you in lines of Python that look like alien hieroglyphs. When I originally built these systems, I had a buddy who could code, and together we got some solid insights. The systems proved competent back then, and I suspect they still have life in them—provided you give them a fresh back‑test under today’s market conditions.

Remember: **no trading system is complete without back‑testing results**. Think of back‑testing as the “taste‑test” before you serve the dish to your customers (i.e., your bank account).

### The grand purpose

The aim here is to **showcase** a variety of systems, demystify how they’re built, and (hopefully) spark that creative fire inside you. Maybe you’ll tweak one of these, combine a couple, or invent something entirely new that becomes your personal money‑making machine.

So, buckle up, keep a notebook handy, and let’s march toward **Pair Trading**—the first stop on our tour of systematic awesomeness!

**PS:** The short strangle on Bank Nifty? It turned out **just fine** (☺). Cheers to small wins and big ideas!