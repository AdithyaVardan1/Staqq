# 12. Trade Identification  

**Source:** <https://zerodha.com/varsity/chapter/trade-identification/>

---  

## 12.1 – Trading the equation  

Alright, strap on your thinking cap (or your party hat – we’re still at a bar, after all) because we’ve finally gathered every morsel of background knowledge you need to start *pair‑trading* without looking like a clueless intern. The time has come to stitch those snippets together and actually see how the pieces dance when you put a real‑world trade on the table.  

First things first – let’s pull out the **good‑old linear equation** that keeps popping up like that one song you can’t get out of your head. You’ve seen it before, you’ve probably scribbled it on a napkin, but now we’re going to stare at it through the eyes of a trader instead of a math‑nerd. The goal? Spot the hidden opportunities that lie between the lines.  

\[
y = M \times x + c
\]

![Cartoon of the equation](https://zerodha.com/varsity/wp-content/uploads/2018/05/M10-C12-cartoon.png)  

### Two ways to read the same line  

You can treat this line like a **statistician** or a **trader** – think of it as the same cocktail, just served in a different glass.

| Perspective | What you see |
|-------------|--------------|
| **Statistician** | *“Hey, the price of stock **y** (the dependent variable) is being explained by the price of stock **x** (the independent variable). The slope **M** (aka beta) and the intercept **c** are the magic numbers that make the story work.”* |
| **Trader** | *“Cool, so **M** tells me how many shares of **x** I need to match one share of **y**. If I can lock that ratio, I can hedge my directional exposure. Let’s see where the profit hides.”* |

#### The statistician’s view  

In a perfect universe (where everyone has a crystal‑ball and zero transaction costs), the price of **y** would be exactly **M·x + c**. Reality, however, loves to throw curveballs. The *residual* (also called the error term) captures the gap between the **actual** price of **y** and the **predicted** price from our tidy line.

Adding the residual gives us the full picture:

\[
y = M \times x + c + \varepsilon
\]

Here **ε** is the error term – the part we can’t explain with a straight line. If you remember Chapter 10, we already proved that this residual series is **stationary**, which means it doesn’t wander off to infinity like a drunken sailor; it tends to stick around a mean. That property is the holy grail for traders.

#### The trader’s view  

Let’s dissect that same equation piece by piece, but with a martini in hand.

1. **\(y = M \times x\)** – This says: *“The price of my dependent stock **y** equals the price of **x** multiplied by the slope **M**.”* In plain English, **M** (the beta) tells you **how many shares of X you need to equal one share of Y**.

2. **Intercept \(c\)** – The y‑intercept is the little offset that makes the line cross the Y‑axis. In trading terms, it’s a constant “drift” we’d rather ignore because we don’t actually trade it.

3. **Residual \( \varepsilon\)** – The wild card, the mis‑fit, the part that wiggles around the mean. Since we already showed it’s stationary, we can treat it almost like a mean‑reverting Ornstein‑Uhlenbeck process – perfect for statistical arbitrage.

---

### A concrete example – HDFC vs ICICI  

Here’s a real‑world snapshot that will make the math feel less like a horror movie and more like a sitcom episode.

**Linear regression output (HDFC Bank = y, ICICI Bank = x)**  

![Regression output](https://zerodha.com/varsity/wp-content/uploads/2018/05/Image-1_slope.png)  

**Current prices**  

![Price snapshot](https://zerodha.com/varsity/wp-content/uploads/2018/05/Image-2_bank-300x78.png)  

According to the regression, the slope (**M**) is roughly **7.61**. That means—*if* the line were perfect—one share of HDFC would be worth the price of **7.61** shares of ICICI.  

\[
1914 \approx 291 \times 7.61
\]

(And no, that math doesn’t balance perfectly; we’re not in a perfect world, remember?)

**What does that imply?**  

- **7.61 shares of ICICI ≈ 1 share of HDFC** – That’s the *hedge ratio*.  
- If you go **long** one share of HDFC **and short** 7.61 shares of ICICI, you’ve effectively neutralised the *directional* exposure of the pair. You’re now betting on the *relationship* between the two, not on whether the whole market goes up or down.  

Since we deliberately pick **co‑integrated** stocks (they move together in the long run), this hedge should stay reasonably tight.

---

### Back to the full equation  

\[
y = M \times x + c + \varepsilon
\]

If the line held true, the **\(M \times x\)** part would perfectly offset the price of **y**, leaving us with just the intercept **c** and the residual **ε** to worry about.  

#### Intercept – the “we‑don’t‑trade‑this” part  

Recall the **Error Ratio** from Chapter 10:

\[
\text{Error Ratio} = \frac{\text{Standard Error of Intercept}}{\text{Standard Error of Slope}}
\]

A **low error ratio** is desirable because it means the intercept is small and precisely estimated. In pair trading we **don’t hedge the intercept** (there’s no “c‑stock” to trade), so we’d rather have it as close to zero as possible. In practice, we pick pairs where the standard error of the intercept is low, keeping **c** out of the way.

#### Residual – the star of the show  

The residual **ε** is a *time‑series* that we have already confirmed to be **stationary**. Because it’s stationary, it behaves roughly like a normal distribution: it spends most of its time near the mean and only occasionally wanders out to the tails. That’s where the money lives.

**Trading rule of thumb**  

- **Go long the pair** (buy **y**, sell **x**) when the residual drops to **‑2 σ** (two standard deviations below the mean).  
- **Go short the pair** (sell **y**, buy **x**) when the residual spikes to **+2 σ** (two standard deviations above the mean).  

Why ±2 σ? Think of it as the “sweet spot” where the odds of a mean‑reversion are high enough to justify the trade, but the move isn’t so extreme that you’re just chasing a freak outlier.

**Stop‑loss (SL)** – Put it at **±3 σ** for both long and short legs. If the residual wanders beyond three standard deviations, you’ve probably entered a regime where the relationship has broken down, and it’s time to cut losses.

In the next chapter we’ll walk through a live example, but for now remember: **the trade is entirely about the residual**. We hedge the price of **y** with **x** (using the beta), we keep the intercept tiny, and we ride the stationary residual back to its mean.

---

### TL;DR – Key take‑aways from this chapter  

- The **pair‑trading equation** \(y = Mx + c + \varepsilon\) is the *actual* trade you execute.  
- Every component—**beta (M)**, **intercept (c)**, **error term (ε)**—gets its own spotlight.  
- **Beta** tells you **how many shares of X** you need to hedge **one share of Y** (e.g., 7.61 ICICI per HDFC).  
- The **error‑ratio** (low standard error of intercept) ensures **c** stays small, because we don’t trade the intercept.  
- The **residual ε** is the *trading signal*; it’s stationary, so its moves are statistically predictable.  
- **Long the pair**: buy **Y**, sell **X** when ε ≤ **‑2 σ**.  
- **Short the pair**: sell **Y**, buy **X** when ε ≥ **+2 σ**.  
- Hold the position until the residual reverts to its mean.  
- Set a **stop‑loss at ±3 σ** for both long and short legs.  

That’s it! You now have a trader‑centric lens on the equation, know exactly *what* you’re hedging, and understand *when* to jump in and out based on the residual’s dance. In the next chapter we’ll roll up our sleeves, fire up a live chart, and watch the magic happen in real time. Cheers to profitable pair‑trading! 🍻