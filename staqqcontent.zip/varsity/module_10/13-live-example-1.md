# 13. Live Example – 1  

**Source:** https://zerodha.com/varsity/chapter/live-example/  

---  

## 13.1 – Tracking the pair data  

![Image](https://zerodha.com/varsity/wp-content/uploads/2018/05/M10-C13-cartoon.png)  

Ladies and gentlemen, the moment we’ve all been salivating for is finally here: the curtain is about to rise on the *real‑world* side of pair trading. 🎭 After slogging through regression formulas, cointegration theory, and a handful of ADF tests, you’re now ready to watch the numbers dance on a live chart.  

### Quick pre‑trade refresher (because nobody likes a brain‑fart mid‑trade)

| What we learned | Why it matters (in plain English) |
|-----------------|------------------------------------|
| **Linear regression** – regress an independent variable **X** against a dependent variable **Y** | Think of X as the “side‑kick” and Y as the “hero”. We need to know how the side‑kick follows the hero. |
| **Regression output** – intercept, slope (beta), residuals, standard error of residuals, and standard error of the intercept | These are the stats‑guru’s version of the hero’s back‑story. |
| **Error‑ratio** = (SE of intercept) / (SE of residual) | The lower the ratio, the more harmonious the X‑Y relationship. |
| **Choosing X vs Y** – swap X and Y, compute error‑ratio for both combos; the combo with the *lowest* error‑ratio wins | It’s like trying on shoes; you keep the pair that fits best. |
| **Stationarity of residuals** → cointegration → stocks move together | If the residuals wobble around a constant mean, the two stocks are basically “married”. |
| **ADF test** – Augmented Dickey‑Fuller | If the p‑value (or ADF‑stat) is **< 0.05**, we can call the residuals stationary. |
| **Trading signals** – residual hits –2 SD → *long* the pair (buy Y, sell X); residual hits +2 SD → *short* the pair (sell Y, buy X) | It’s the classic “mean‑reversion” cue: when the spread gets too skinny or too fat, we bet it will snap back. |
| **My personal sweet spot** – I usually wait until the residual hits **≈ ±2.5 SD** before jumping in. Stop‑loss is set at **±3 SD**, target at **±1 SD**. | In other words, I like a little extra drama before I get on stage. |

Bottom line: find two stocks in the same sector, run the regression, pick the X/Y combo with the smallest error‑ratio, verify the ADF is < 0.05, and then monitor the residuals daily for those ±2 SD “enter‑the‑arena” cues.

---

## 13.2 – Note for the programmers  

Back in Chapter 11 we introduced the **Pair Data** sheet – the spreadsheet that spits out everything you need to decide whether a pair is worth your precious CPU cycles. If you love automating boring stuff, here’s what the Pair‑Trading Algo actually does, step by step (and yes, you can code this in Python, R, or even a spreadsheet macro if you’re feeling nostalgic).

| Step | What the algo does | Why it matters |
|------|-------------------|----------------|
| **1️⃣** | Pull the last **200‑day** closing prices for every stock you care about (NSE bhavcopy is a goldmine). | Gives you enough history to compute a reliable regression without over‑fitting. |
| **2️⃣** | The stock‑sector mapping is already baked in, so the download is tidy. | No need to manually filter for “all the banks” or “all the auto makers”. |
| **3️⃣** | Run **two regressions** for each pair: (A as X, B as Y) and (B as X, A as Y). Compute the **error‑ratio** for both. | Whichever combo yields the **lowest error‑ratio** wins the “X‑vs‑Y” crown. |
| **4️⃣** | Run an **ADF test** on the residuals of the winning combo. | Confirms the spread is stationary (i.e., mean‑reverting). |
| **5️⃣** | Dump everything into the **Pair Data** sheet: intercept, beta, ADF, standard error, and sigma. | This is the cheat‑sheet you’ll stare at every morning, coffee in hand. |

If you’re a coder, treat this table as a **specification**. Build the pipeline, schedule it nightly, and you’ll have a fresh list of “trade‑ready” pairs every sunrise.

### Peeking at the Pair Data sheet  

Here’s a screenshot of the Excel output (don’t worry, the picture is just for illustration – you’ll generate your own).

![Image](https://zerodha.com/varsity/wp-content/uploads/2018/05/Image-1_pd.png)

The highlighted row says:

| Symbol (Y) | Symbol (X) | Intercept | Beta | ADF | Std_err | Sigma |
|------------|------------|-----------|------|-----|---------|-------|
| **Bajaj Auto** | **TVS** | 1172.72 | 2.804 | 0.012 | –0.77 | 103.94 |

**What’s the story?**  
Because this row survived the algorithm’s pruning, the **Bajaj = Y / TVS = X** combo has the *lower* error‑ratio. The opposite combo (Bajaj as X, TVS as Y) was too noisy, so it didn’t make the cut.

The first three columns (Intercept, Beta, ADF) you already know – they’re the usual suspects. Let’s unpack the last two:

### Standard Error (Std_err) – the “today‑vs‑usual” gauge  

In the report, **Std_err** is actually:

\[
\text{Std\_err} = \frac{\text{Today’s residual}}{\text{Standard error of the residuals}}
\]

There are **two** “standard errors” floating around, which can feel like a math‑class nightmare:

1. **Standard error of the regression residuals** – this is a single number that comes out of the regression summary (think of it as the average “wiggle‑room” of the spread).  
2. **Std_err** in the Pair Data sheet – a *ratio* that tells you *where* today’s residual sits relative to that average wiggle‑room.

#### Example time  

Take the regression of **Yes Bank** vs **South Indian Bank** (the screenshot below).  

![Image](https://zerodha.com/varsity/wp-content/uploads/2018/05/Image-2_SE.png)

* Highlight 1: **Standard error = 22.776** (this is the “average wiggle”).  
* Highlight 2: **Residual = 20.914** (today’s actual spread deviation).

Now compute:

\[
\text{Std\_err} = \frac{20.914}{22.776} \approx 0.918
\]

So the spread is **~0.92** standard‑error units away from the mean – well within the usual noise, not a trade trigger yet.  

When this ratio drifts to **–2.5** (or **+2.5** for a short), you’ve got a *signal*. Stop‑loss sits at **±3**, and the target at **±1**. Because the ratio updates every trading day, you’ll be checking it like you check the weather forecast – *“Is it going to rain residuals today?”* 🌧️

### Sigma – the “raw” standard error  

**Sigma** is simply the **standard error of the residuals** (the 22.776 in our example). It’s the denominator in the Std_err ratio, and it stays constant for a given regression period.

Now you should be able to read any row in the Pair Data sheet like a seasoned bartender reads a cocktail menu: **Intercept** tells you the baseline spread, **Beta** tells you the slope (how much X moves when Y moves), **ADF** confirms stationarity, **Std_err** is your *live* signal gauge, and **Sigma** is the *background* volatility.

Alright, enough theory – let’s go live! ☺  

---

## 13.3 – Live example  

After letting the algorithm run its nightly marathon, it spit out a promising pair on **10 May 2018**. Below is the pair‑data snapshot (you can download the full sheet at the end of this chapter). Remember, the algorithm used *closing prices* from that very day.

![Image](https://zerodha.com/varsity/wp-content/uploads/2018/05/Image-3_trade.png)

**Red‑highlighted row** tells the story:

| Y (Dependent) | X (Independent) | Intercept | Beta | ADF | Std_err |
|---------------|-----------------|-----------|------|-----|----------|
| **Tata Motors Ltd** | **Tata Motors DVR** | 0.0 (rounded) | 1.59 | **0.0179** | **–2.54** |

* **ADF = 0.0179** – comfortably below the 0.05 threshold, confirming the spread is stationary.  
* **Std_err = –2.54** – the residual is **2.54 σ** below the mean, a classic **long‑signal** (buy Y, sell X).  

My plan was to jump in the next morning (11 May, a Friday), but fate (or my inbox) kept me from placing the order. I finally entered on **14 May (Monday)** at a slightly worse price – but that’s irrelevant; the point is to illustrate the mechanics, not to chase a perfect P&L.

### Trade execution snapshot  

![Image](https://zerodha.com/varsity/wp-content/uploads/2018/05/Image-4_trade-execute.png)

You’re probably raising a couple of eyebrows now. Let’s tackle them.

#### Q1: *“Did you really just click ‘buy’ and ‘sell’ without glancing at price charts, support/resistance, RSI, etc.?”*  

**A:** Nope. In pair trading the *price* of each leg is secondary. All that matters is the **residual** (or Z‑score) you just saw. If the residual tells you “I’m way off the mean”, you act. The individual price levels, candle patterns, and fancy oscillators are **noise** for this strategy.

#### Q2: *“Why only 1 lot each? Why not 2 lots of TM and 3 lots of TMD?”*  

**A:** That’s where **beta neutrality** enters the stage. The goal is to keep the *overall market exposure* of the position near zero. The rule is:

\[
\text{Shares of X} = \beta \times \text{Shares of Y}
\]

For our pair, **β = 1.59**. One futures lot of Tata Motors (Y) equals **1500 shares**. Multiply:

\[
1500 \times 1.59 = 2385 \text{ shares of TMD}
\]

The nearest lot size for Tata Motors DVR (X) is **2400 shares**, which is close enough. Hence **1 lot each** gives us a roughly beta‑neutral stance (a tiny long bias because 2400 > 2385, i.e., ~115 extra shares).  

If the beta were **negative**, we’d have a problem – you can’t have a negative number of shares, so that pair would be impractical to trade (unless you flip the long/short side, but that defeats the purpose).

### Holding the trade  

We entered at **Std_err = –2.54**. From there, the plan is simple:

| Action | Trigger |
|--------|---------|
| **Target** | Std_err reaches **–1** (for a long) |
| **Stop‑loss** | Std_err hits **–3** (for a long) |

Until one of those thresholds is breached, we just *wait*. It’s like watching a pot of water – the steam (residual) tells you when it’s about to boil.

#### The “Excel‑only” tracker  

Because I’m not a full‑blown quant wizard, I built a **plain‑vanilla Excel tracker** to compute the daily Z‑score and P&L. If you’re a coder, feel free to replace it with a Python dashboard or a shiny R Shiny app. Here’s a sneak peek:

![Image](https://zerodha.com/varsity/wp-content/uploads/2018/05/Image-5_pt.png)

The sheet works like this:

1. **Enter today’s closing prices** for X and Y.  
2. The spreadsheet automatically computes the **residual**, divides by **Sigma** to get the **Z‑score (Std_err)**, and updates the **P&L** based on the lot sizes.  

Play with it, mess up a few cells, and you’ll learn faster than any textbook.

### Daily logs – the “watch‑list”  

My colleague Faisal dutifully logged the residuals (except for 14 May and 15 May when we were busy sipping chai). Here’s the log table:

![Image](https://zerodha.com/varsity/wp-content/uploads/2018/05/Image-6_logs.png)

Notice how the **Z‑score** is recalculated multiple times per session. The trade stayed **open for ~7 trading days** – a typical horizon for pair trades. I’ve even held positions for **22‑25 days** when the spread was stubborn. Patience (and a reliable internet connection) is a trader’s best friend.

### The grand exit – 23 May  

On the morning of **23 May**, the Z‑score finally drifted back to **–1** (our target). I closed both legs at the same time:

![Image](https://zerodha.com/varsity/wp-content/uploads/2018/05/Image-7_exit.png)

Key observation: the **Tata Motors DVR leg** made a *much larger* profit than the loss on the Tata Motors leg. That’s the nature of pair trading – you never know which side will be the “breadwinner”. The magic is that the *difference* between the two will, on average, revert to the mean.

The final day’s tracker looked like this:

![Image](https://zerodha.com/varsity/wp-content/uploads/2018/05/Image-8_close.png)

**Result:** Roughly **₹ 14,000** profit on a low‑risk, market‑neutral setup. Not bad for a strategy that only cares about the spread, not the market’s mood swings. ☺  

---

## 13.4 – Final words on Pair Trading  

Phew! We’ve trekked through 13 chapters, from regression basics to a full‑blown live trade. Pair trading feels a bit like being a bartender who mixes two drinks that *always* balance each other out – you’re less worried about the overall bar price and more about the **ratio** of the two ingredients.

### Risks to keep in mind  

* **Divergence risk** – sometimes the spread keeps widening instead of snapping back, turning your “mean‑reversion” bet into a loss.  
* **Margin pressure** – you’re holding *two* futures contracts, so the **initial margin** is roughly double a single‑leg trade. Keep a cushion for daily MTM (mark‑to‑market) swings.  
* **Spot‑market adjustments** – Occasionally you’ll need to top‑up one leg in the cash market because the lot sizes don’t line up perfectly (see the Allahabad‑Union Bank example below).  

#### Spot‑market example (23 May)  

A signal popped up for **short Allahabad Bank (Y)** and **long Union Bank (X)**:  

* Z‑score = **+2.64** (short‑signal)  
* β = **0.437**  

Beta‑neutrality says:

\[
\text{Shares of X} = 0.437 \times \text{Shares of Y}
\]

*Lot size Y (Allahabad Bank) = 10 000 shares* → required X shares = **4 378**.  

But Union Bank’s lot size = **4 000**. So I bought the remaining **378 shares** in the spot market to keep the ratio tidy.

![Image](https://zerodha.com/varsity/wp-content/uploads/2018/05/Image-9_AU.png)

### What’s next?  

* **Pair‑data sheet** – we’re working on delivering a fresh sheet every day so you can start hunting pairs right away.  
* **DIY** – If you love coding, build the algorithm yourself. If not, find a friend who codes, convince them that “there’s money in it”, and you’ll be golden. (I did exactly that! ☺)  

### A teaser for the future  

> *“We run a linear regression of Stock A with Stock B to check for cointegration. What if Stock A is cointegrated *not* with Stock B alone, but with the *combined* price of Stock B + Stock C?”*  

That’s the realm of **multivariate regression** – a whole new playground where you juggle three or more instruments at once. It’s not for the faint‑hearted, but mastering it will make you feel like a wizard who can conjure profits from a matrix of stocks.

---

## 📥 Downloads  

| File | Description |
|------|-------------|
| **[Download Position Tracker (Excel)](#)** | Plug‑in today’s X & Y prices, get Z‑score and P&L instantly. |
| **[Download Pair Data Sheet (Excel)](#)** | Fresh list of viable X‑Y combos with intercept, beta, ADF, sigma, etc. |

---

### Key takeaways from this chapter  

* **Residual value (Std_err / Z‑score)** is the *only* trigger you need to start a pair trade.  
* **Beta neutrality** tells you how many shares/lots of X versus Y to keep market exposure near zero.  
* A **negative beta** makes a pair practically un‑tradeable (you’d need a negative number of shares!).  
* Once you’re in, **monitor the Z‑score** – the futures price itself is irrelevant; it’s the spread that matters.  
* **Margin** is higher because you hold two contracts, and you may occasionally need a spot‑market fill when lot sizes don’t match.  

That’s it, folks! Go forth, run regressions, hunt residuals, and may your spreads always revert in your favor. 🍻  