# 16. Momentum Portfolios  

**Source:** https://zerodha.com/varsity/chapter/momentum-portfolios/  

---  

##  

![Image](https://zerodha.com/varsity/wp-content/uploads/2019/03/M10-C16-Cartoon.png)  

## 16.1 – Defining Momentum  

If you’ve ever spent any decent chunk of time staring at price charts, you’ve probably heard the word **momentum** tossed around like a bartender’s shaker. Most of us start sprinkling it into our conversations without really knowing whether we’re talking about physics or finance. I’m guilty of that too – I’ll say “the stock has great momentum” while still thinking it’s just a fancy synonym for “it’s moving fast.”  

So, what *actually* is momentum in the market?  

In plain‑English, traders often say momentum is “how quickly a market is moving.” That’s a decent first‑order approximation, but there’s more to the story.  

In physics, **momentum** = mass × velocity. It measures the *quantity of motion* an object possesses. Swap “object” for “stock or index,” and you’ve got the financial analogue: the **rate of change of returns**. If a stock’s returns are changing rapidly, its momentum is high; if returns are barely twitching, momentum is low.  

### What does “rate of change of returns” even mean?  

Think of a return as the profit (or loss) you earn between two points in time. The *rate* of that change is simply how fast those returns are shifting from one day to the next. For our discussion we’ll stick to **daily‑close‑to‑close** returns – i.e., the speed at which a stock’s daily return wiggles.  

#### Example time – Stock A vs. Stock B  

![Image](https://zerodha.com/varsity/wp-content/uploads/2019/03/Image-1_stock-a.png)  

Two observations:  

1. Prices climb every day.  
2. The day‑to‑day percentage move is **≥ 0.5 %**.  

Now look at this other chart:  

![Image](https://zerodha.com/varsity/wp-content/uploads/2019/03/Image-2_stock-b.png)  

Again, two things pop out:  

1. Prices are also on an upward march.  
2. The daily percentage move is **≥ 1.5 %**.  

**Questions:**  

- Which stock’s *daily‑return* is changing faster?  
- Which one has the higher momentum?  

If you eyeball the raw rupee change, Stock A looks flashier because its price level is higher, so a ₹10 move feels bigger than a ₹2 move in Stock B. That’s a trap: absolute price moves are biased toward high‑priced stocks.  

Momentum cares about **percentage** change, not raw rupees. In our case, Stock B’s 1.5 % daily swing beats Stock A’s 0.5 %, so **Stock B has the higher momentum**.  

#### Consistency matters  

![Image](https://zerodha.com/varsity/wp-content/uploads/2019/03/Image-3_total-change.png)  

Here Stock A climbs a little every day, while Stock B snoozes for five days and then rockets the last two. Over the full seven‑day window both deliver nearly the same total % gain, but which one feels “more momentum‑y”?  

The answer: **Stock A**. Its returns are *steady* and *continuous*, which is the hallmark of true momentum.  

If you switch the measurement window from “daily” to “7‑day,” both stocks suddenly qualify as momentum stocks because you’re now looking at a longer slice where the big two‑day jump dominates.  

The moral: **Momentum can be measured on any time‑frame** – daily, weekly, monthly, or even minute‑by‑minute for high‑frequency traders. The strategy we’ll later explore uses a *larger* window than a single day, but the concept stays the same.  

By now you should have a gut feeling that momentum is *the speed of return change* and that you can look at it over any horizon you fancy.  

---  

## 16.2 – Momentum Strategy  

Among the buffet of trading ideas out there, the momentum play is the one most people keep coming back for seconds. The basic recipe is the same no matter who cooks it:  

1. **Measure momentum** (however you like).  
2. **Spot the fastest‑moving stocks**.  
3. **Ride the wave** until it fizzles out.  

You can apply this recipe to a single stock, an entire sector, or a full‑blown portfolio.  

*Single‑stock momentum* – Scan every ticker you watch, rank them by their momentum score, and go long the hot ones and short the cold ones.  

*Sector‑specific momentum* – First pick a sector that’s sprinting (say, the pharma index), then cherry‑pick the individual stocks inside that sector that are leading the charge.  

*Portfolio‑wide momentum* – Build a basket of **n** stocks, each of which is showing strong momentum. This gives you the best of both worlds: the “trend‑catching” power of momentum plus the safety net of diversification.  

Below we’ll walk through a concrete example: a **10‑stock (or 12‑stock) momentum basket** that you hold until the momentum fades, then rebalance.  

---  

## 16.3 – Momentum Portfolio  

Before we dive into the step‑by‑step, a few housekeeping notes:  

- **There’s no single “right” way** to assemble a momentum portfolio. Think of this as one tasty recipe among many.  
- **You’ll need some code** (Python, Pine, or even Excel macros). If you’re not a developer, buddy up with someone who can turn your spreadsheet wizardry into a script.  
- **Back‑test everything**. Treat it like a Tinder date – swipe right only after you’ve checked the profile (historical performance).  

Below is a systematic, “cook‑book” style guide to building your own momentum portfolio.  

### Step 1 – Define your stock universe  

India’s exchanges host roughly **4,000** BSE‑listed and **1,800** NSE‑listed equities, ranging from the mega‑caps like TCS to the “Z‑category” penny‑stocks that barely make a blip on the radar. Do you really want to monitor *all* of them?  

**Short answer:** No.  

Create a **tracking universe** – a manageable subset of stocks that you’ll evaluate for momentum. Think of it as the “favorite malls” you frequent when you’re shopping for a new jacket. Out of the dozens of malls in a city, you probably only hit 2‑3 regularly; those become your go‑to spots, just as your tracking universe becomes the pool from which you pick portfolio constituents.  

A simple choice is the **Nifty 50** (or the broader **BSE 500**) – they already filter out the tiniest, most illiquid issues. If you’re feeling adventurous, you can craft a custom universe using filters such as:

- Market‑cap ≥ ₹1,000 cr  
- Stock price ≤ ₹2,000  
- Average daily volume ≥ 100,000 shares  

Feel free to mix‑and‑match any criteria that align with your style. The key is to end up with **at least 150‑200 stocks** if you plan to eventually pick a 12‑15‑stock momentum basket.  

### Step 2 – Set up the data  

Now that you have your universe, you need clean, corporate‑action‑adjusted **closing prices** for each ticker. Adjustments for bonuses, splits, special dividends, etc., are non‑negotiable – otherwise you’ll be comparing apples to oranges.  

**Where to get it?** Free sources include the NSE/BSE websites, Yahoo Finance, or Quandl.  

**How much history?** For the strategy we’ll illustrate, **one year** of daily close data suffices. Example: if today is 2 Mar 2024, pull data from 2 Mar 2023 through 2 Mar 2024.  

Once you have the first year, set up an automated daily pull so your data frame stays current.  

### Step 3 – Calculate returns  

This is the heart of the method. For each stock, compute its **return over the chosen look‑back window**. While the tutorial sticks to **12‑month (annual) returns**, you can experiment with half‑year, monthly, or even fortnightly returns – the math is identical, only the window changes.  

The generic formula for a *periodic* return is:  

\[
\text{Return} = \frac{\text{Ending Price}}{\text{Starting Price}} - 1
\]

For a concrete example, let’s look at ABB (one of our ten‑stock demo universe):  

\[
\text{Return}_{\text{ABB}} = \frac{1244.55}{1435.55} - 1 = -0.1331 \; \text{or} \; -13.31\%
\]

That’s it – a simple division and subtraction.  

Below is a snapshot of a tiny universe (10 stocks) with a full year of close prices and the resulting 12‑month returns:  

![Image](https://zerodha.com/varsity/wp-content/uploads/2019/03/image-4_tu.png)  

![Image](https://zerodha.com/varsity/wp-content/uploads/2019/03/image-5_rets.png)  

### Step 4 – Rank the returns  

Now we turn those raw percentages into a leaderboard. Sort the stocks from **highest return (rank 1)** to **lowest return (rank N)**. In our demo:

- **Asian Paints** → +25.87 % → Rank 1  
- **HDFC Bank** → +22.43 % → Rank 2  
- …  
- **Infosys** → ‑35.98 % → Rank 10  

The ranking table looks like this:  

![Image](https://zerodha.com/varsity/wp-content/uploads/2019/03/Image-6_rank.png)  

Why are most returns negative? Because we happened to be in a deep correction when we grabbed the data – a reminder that markets are cyclical, not static.  

The ranking simply tells you **who the past year’s over‑achievers and under‑performers are** within your universe.  

### Step 5 – Create the portfolio  

With a ranked list in hand, it’s time to pick the **top k** stocks. Most practitioners pick **10‑15** names; more than that dilutes the “pure momentum” edge, fewer than that can make the portfolio overly concentrated.  

Assume we go for **12 stocks**. Our momentum basket becomes the stocks occupying ranks 1 through 12. In our tiny example (if we were building a 5‑stock basket) the picks would be:  

- Asian Paints  
- HDFC Bank  
- Biocon  
- ACC  
- Ultratech  

**Why this works (the theory)**: If a stock has generated the best returns over the past 12 months, the market has given it a lot of “push.” The hope is that the same push continues into the next month, letting you capture the tail end of the trend.  

I’m not claiming a crystal‑ball guarantee; it’s a **statistical tendency** that has held up in many back‑tests I’ve run.  

**Capital allocation** – The simplest approach is **equal weighting**: with ₹200,000 capital and 12 stocks, you buy ₹16,666 worth of each.  

If you love tinkering, you can skew the weights. Some ideas:  

- **50 %** to the top 5, **50 %** to the remaining 7.  
- **40 %** to the top 3, **60 %** across the rest.  
- **Contrarian tilt** – allocate more to the lower‑ranked stocks if your back‑test shows they rebound.  

Whatever you do, let the **back‑test dictate the weighting scheme** – otherwise you’re just guessing.  

### Step 6 – Rebalance the portfolio  

So far we’ve:  

1. Defined a universe.  
2. Collected a year of clean close data.  
3. Computed 12‑month returns.  
4. Ranked the stocks.  
5. Bought the top k stocks (equal‑weighted, for simplicity).  

Now comes the **maintenance** part.  

**Assumptions:**  

- The basket is constructed **on the first trading day of each month**.  
- All calculations (ranking, selection) are performed **after market close on the last day of the prior month**.  
- You hold the basket **through the entire month**.  

**Month‑end routine:**  

1. Pull the latest close data, recompute each stock’s **most recent 12‑month return** (the window always “slides” forward).  
2. Rerank the entire universe.  
3. Identify the **new top k** stocks.  
4. Sell any stocks that fell out of the top k and buy any newcomers that entered.  

In practice, you’ll find that **only a handful of stocks change** each month – the core of the basket remains stable, which keeps turnover (and transaction costs) modest.  

Repeat this process month after month, and you’ve built a **dynamic, momentum‑driven portfolio** that constantly chases the strongest recent performers.  

---  

## 16.4 – Momentum Portfolio variations  

The “12‑month return, 1‑month hold” combo is just the baseline. Feel free to remix the parameters:  

| Return window | Holding period | Example |
|---------------|----------------|---------|
| **Monthly**   | 1 month        | Rank stocks by *last‑month* return, hold for the next month. |
| **Fortnightly**| 15 days       | Use a 2‑week return to pick stocks, rebalance every 15 days. |
| **Weekly**    | 1 week         | Compute 7‑day returns, trade a new basket each Monday. |
| **Daily**     | Intraday       | Compute yesterday’s return, go long/short for the trading day. |

The sky’s the limit – you can even go **intraday**, measuring momentum every hour or minute if you have high‑frequency data.  

### Fundamental‑driven momentum  

So far we’ve focused on *price* momentum. You can also ride the wave of **fundamental momentum**:  

1. Build a universe of financially sound stocks (e.g., positive EBIT, low debt).  
2. Grab a fundamental metric – quarterly sales growth, EPS acceleration, EBITDA margin expansion, etc.  
3. Compute the **percentage change** of that metric quarter‑over‑quarter.  
4. Rank and pick the top performers, then **rebalance at quarter‑end**.  

Because fundamental data is released on a schedule (quarterly), the turnover will be lower, and the back‑test will be cleaner.  

---  

## 16.5 – Word of caution  

Price‑based momentum shines **when markets are trending upward**. In a choppy, sideways market, the strategy can whiplash you, and during steep downtrends the portfolio can lose *more* than the broader index.  

Think of momentum as a **surfboard** – it works great when there’s a solid wave, but you’ll tumble if the sea is flat or you ride a rogue wave that crashes.  

My own experience: I rode the momentum wave nicely in 2009‑10, only to get wiped out in the turbulent 2011 session. The lesson? **Never launch a strategy without rigorous back‑testing across multiple market regimes**.  

When applied in the right market environment (up‑trend, moderate volatility), a well‑constructed price‑momentum portfolio can **outperform the broad market** with a relatively simple rule set.  

Good luck, happy surfing, and may your returns stay as swift as the momentum you chase!  

### Key takeaways from this chapter  

- **Momentum** = rate of change of returns; can be measured over any horizon (daily, weekly, monthly, etc.).  
- A **price‑based momentum portfolio** holds the stocks with the strongest recent returns within a defined universe.  
- Choose a **tracking universe** that is large enough (150‑200+ stocks) but manageable; BSE 500 or Nifty 50 are solid starting points.  
- **Calculate** the chosen‑period returns for every stock in the universe.  
- **Rank** the stocks from highest to lowest return.  
- The **momentum basket** is simply the top k stocks (typically 10‑15).  
- The underlying belief: past high returns signal *continuing* momentum into the next holding period.  
- **Capital allocation** can be equal‑weight (simple and robust) or skewed – let back‑tests decide the weighting scheme.  
- Momentum can also be built on **fundamental metrics** (sales growth, EPS acceleration, EBITDA margin, etc.).  
- **Price‑momentum works best in upward‑trending markets**; it struggles in sideways or down markets, so always test across cycles.  