# 10.   PTM2, C3 – The Error Ratio  

**Source:** <https://zerodha.com/varsity/chapter/the-error-ratio/>  

---  

##  

![Image](https://zerodha.com/varsity/wp-content/uploads/2018/03/M10-C10-Cartoon.png)  

## 10.1 – Who is X and who is Y?  

Alright, strap on your thinking cap (or that ridiculous party hat you wear on Friday nights) because we’re about to turn two boring‑old stock symbols into the stars of a math‑drama.  

In the last chapter we flirted with **linear regression** – the statistical equivalent of “if you give me X, I’ll tell you Y, but don’t hold me to it”.  You learned how to pull the regression magic out of Excel, so now we can actually **talk about X and Y as real things**, not just letters you scribble on a napkin.  

- **X** = the *independent* variable (the one that does the heavy lifting).  
- **Y** = the *dependent* variable (the one that follows X’s lead, like a junior partner at a law firm).  

If you’ve been chewing on that definition, you’ve probably guessed that our X and Y will end up being **two different stocks**.  

Let’s pick a pair that even your grandma might recognize: **HDFC Bank** and **ICICI Bank**. We’ll run a regression on their price series and see what the universe (or at least Excel) tells us.  

> **Quick data housekeeping checklist**  
> - Adjust for stock splits, bonus issues, and any corporate shenanigans.  
> - Align the dates perfectly. In my demo the data runs from **4 Dec 2015 to 4 Dec 2017** for both banks.  

Here’s a sneak‑peek of the raw price data (yes, the numbers are as pretty as they look).  

![Image](https://zerodha.com/varsity/wp-content/uploads/2018/03/Image-1_data-1.png)  

Now, fire up Excel’s *Data Analysis → Regression* wizard (or the “I‑don’t‑know‑what‑I‑am‑doing‑but‑it‑works” add‑in) and run the regression **on the price series**, **not** on returns.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2018/03/Image-2_on-price-1.png)  

The output looks like a bunch of numbers with tiny fonts – typical analyst vibe.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2018/03/Image-3_IH-1.png)  

Since we told Excel that **ICICI is X** (the independent) and **HDFC is Y** (the dependent), the fitted line reads:  

\[
\textbf{HDFC} = 7.613 \times \text{ICICI} \;-\; 663.677
\]  

If you’re still scratching your head, the equation simply says: “Given the price of ICICI, I’ll *guess* the price of HDFC”.  

Now let’s do the *reverse* – make **HDFC** the independent variable and **ICICI** the dependent one.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2018/03/Image-4_HI-1.png)  

The new line becomes:  

\[
\textbf{ICICI} = 0.09 \times \text{HDFC} \;+\; 142.4677
\]  

**Moral of the story:** You can always flip the script and run the regression both ways. The only real puzzle left is **which way makes sense?**  

### The tri‑factor decision rule  

Choosing X vs. Y isn’t a “rock‑paper‑scissors” game; it’s based on three statistical buddies:  

1. **Standard Error (SE) of the regression** – the spread of the residuals.  
2. **Standard Error of the Intercept (SE\_int)** – how shaky the intercept estimate is.  
3. **The ratio**:  

\[
\textbf{Error Ratio} = \frac{\text{SE\_int}}{\text{SE}}
\]  

(Yes, we repeat the two components because the ratio is the star of the show.)  

Why do we care? The regression line is basically a **story** that tries to explain the price moves of the dependent stock using the independent stock as a reference. No story is perfect – if it were 100 % accurate, there would be no profit opportunity left for us clever traders.  

What we *do* want is a story that **explains as much variation as possible** while keeping the independent variable in the picture. The tighter the story, the more useful it is.  

Enter the **Error Ratio**: a low ratio tells us the intercept estimate is relatively stable compared to the overall noise (the SE). That stability is a good hint that we’ve picked the right “dependent” stock.  

So, the next obvious question is **how to compute that ratio**? Let’s dig into the residuals first.  

## 10.2 – Back to residuals  

Recall the first regression (ICICI = X, HDFC = Y):  

\[
\textbf{HDFC} = 7.613 \times \text{ICICI} \;-\; 663.677
\]  

If you plug today’s ICICI price into that line, you get a **predicted** HDFC price. The **residual** is the difference between the *actual* HDFC price and the *predicted* one.  

Here’s what the residuals look like when we keep ICICI as the independent variable:  

![Image](https://zerodha.com/varsity/wp-content/uploads/2018/03/Image-5_residuals.png)  

> **Common gripe:** “Why bother with a model that never gets the price exactly right? Isn’t that useless?”  

Valid point. The residuals swing from about **‑288** to **+548**, so using the line to forecast a single price would be, frankly, a joke.  

But the whole point of a pair‑trade isn’t to predict a *single* price; it’s to **study the behavior of the residuals**. If those residuals follow a repeatable pattern, you can devise a trade that exploits the *mis‑pricing* between the two stocks – buy one, sell the other, and pocket the convergence.  

We’ll deep‑dive into that pattern later. For now, let’s focus on the **standard error**, the denominator in our Error Ratio.  

### What is Standard Error?  

When you run a regression, Excel (or any statistical engine) spits out a **Standard Error (SE)** value. It’s simply the **standard deviation of the residuals**. Think of the residuals as a time‑series of “mistakes”; the SE tells you how big those mistakes typically are.  

Here’s the output snippet showing the SE:  

![Image](https://zerodha.com/varsity/wp-content/uploads/2018/03/Image-6_se.png)  

If you want to see the math yourself, just compute the standard deviation of the residual column. I did that for X = ICICI, Y = HDFC:  

![Image](https://zerodha.com/varsity/wp-content/uploads/2018/03/Image-7_se-1.png)  

Excel reports a **standard deviation of 152.665**, while the regression summary lists **SE = 152.819** – close enough that the tiny rounding difference can be ignored.  

### Standard Error of the Intercept (SE_int)  

Now, the **intercept** (the “‑663.677” in our equation) is also an estimate, not a hard‑coded number. Its precision is captured by the **Standard Error of the Intercept**.  

Here’s the line from the regression output that shows it:  

![Image](https://zerodha.com/varsity/wp-content/uploads/2018/03/Image-8_sei.png)  

Why does it matter? Both the **slope (M)** and **intercept (C)** are derived from historical data that may contain noise, outliers, or occasional market tantrums. Consequently, they are subject to sampling error. The SE\_int tells us **how much the intercept could wiggle** if we re‑ran the regression on a slightly different sample.  

In short:  

- **Standard Error of Intercept** → variance (or uncertainty) of the intercept estimate.  
- **Standard Error** → variance of the residuals (the overall “noise” around the regression line).  

### Introducing the **Error Ratio**  

I coined the term *Error Ratio* just to make the concept stick in your brain (no, it’s not an official textbook term). It’s simply:  

\[
\boxed{\text{Error Ratio} = \frac{\text{SE\_int}}{\text{SE}}}
\]  

Let’s compute it for both possible orientations of our bank pair:  

| Orientation | SE\_int | SE | Error Ratio |
|------------|---------|----|--------------|
| **ICICI (X) → HDFC (Y)** | 61.31 | 152.82 | **0.401** |
| **HDFC (X) → ICICI (Y)** | 30.74 | 135.28 | **0.227** |

*(Numbers are rounded to three decimals for readability.)*  

**Interpretation:** The **lower the error ratio, the more stable the intercept relative to the overall noise**, which suggests that the chosen dependent variable is the better fit for a pair‑trade model.  

Since the **HDFC‑as‑X / ICICI‑as‑Y** orientation yields the smaller ratio (**0.227**), we’ll treat **HDFC** as the **independent** stock (X) and **ICICI** as the **dependent** stock (Y) for the rest of our analysis.  

I could launch into a full‑blown exposition on *why* this works, but I’ll save that drama for the chapter where we actually build a pair‑trade strategy. For now, just remember: **run the regression both ways, calculate the error ratio, and pick the side with the lower number**.  

You can grab the Excel workbook I used for this demo [here](#).  

## Key takeaways from this chapter  

- **X** = independent (lead) stock, **Y** = dependent (follower) stock.  
- Deciding which stock plays X vs. Y hinges on the **Error Ratio** (SE\_int ÷ SE).  
- Both **slope** and **intercept** in a regression are *estimates* with their own uncertainty.  
- **Error Ratio** = **Standard Error of Intercept** ÷ **Standard Error**.  
- **Standard Error** = standard deviation of the residuals (the “mistakes” of the model).  
- **Standard Error of Intercept** tells you how much the intercept could wiggle across samples.  
- Always run **Stock A vs. Stock B** *and* **Stock B vs. Stock A**; the orientation with the *lower* error ratio decides X and Y.  
- Residuals aren’t just noise – they have structure. Studying that structure is the secret sauce behind successful **pair‑trading**.  

Now go forth, compute those ratios, and may your pair‑trades be ever profitable! 🍻  