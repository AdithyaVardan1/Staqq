# 5.   PTM1, C3 – Pre‑trade setup  

**Source:** https://zerodha.com/varsity/chapter/pre-trade-setup/  

---  

##  

![Image](https://zerodha.com/varsity/wp-content/uploads/2017/12/M10C5-Cartoon.png)  

## 5.1 – Revisiting the Normal Distribution  

If you’ve been scrolling through Varsity like a Netflix binge‑watcher, you’ll already have met the Normal Distribution in the Options module. If not, grab a coffee and give that chapter a read – it’s worth it.  

Why the fuss? Because we’ll be leaning on the Normal curve for **both** pair‑trading tricks we’ll cover: Mark Whistler’s Pair Trading method **and** the second technique we’ll unveil later in this module. It’s the statistical glue that holds the whole thing together, so treat it like the secret sauce in grandma’s biryani: a little goes a long way, but you need to know what it is.  

Here’s the quick‑fire refresher for those who already speak “bell‑curve” fluently, and a gentle nudge for the newbies (don’t let the math scare you away from the Normal Distribution page).  

**Key take‑aways you must have on your cheat‑sheet:**  

| Standard‑deviation “band” | Approx. % of observations inside |
|---------------------------|----------------------------------|
| 1 σ (±1)                  | 68 %                             |
| 2 σ (±2)                  | 95 %                             |
| 3 σ (±3)                  | 99.7 %                           |

![Image](https://zerodha.com/varsity/wp-content/uploads/2017/12/Image-1_ND.png)  

(If you’re thinking “what about uniform, binomial, exponential…?” – yup, they exist too, but they’re not the stars of today’s show.)  

---

## 5.2 – Descriptive Statistics  

In the previous chapter we met three statistical old‑friends: **Mean**, **Median**, and **Mode**. Now we’ll ask them to mingle with our pair‑data – the differential, spread, and ratio we cooked up earlier. The kitchen tool of choice? Good‑old Excel.  

> **Pro‑tip:** The workbook we’re tweaking lives on the download link at the end of this chapter. Feel free to pull it fresh; no need to reinvent the wheel.  

### Sheet layout (so you know where the magic happens)  

![Image](https://zerodha.com/varsity/wp-content/uploads/2017/12/Image-2_setup.png)  

### Excel one‑liners  

| Metric | Formula in Excel |
|--------|------------------|
| Mean   | `=AVERAGE()` |
| Median | `=MEDIAN()` |
| Mode   | `=MODE.MULT()` |

The resulting numbers look like this:  

![Image](https://zerodha.com/varsity/wp-content/uploads/2017/12/Image-3_stast.png)  

(You’ll also see the correlation values we calculated in the previous chapter – keep those in mind.)  

Now we throw a new character into the cast: **Standard Deviation**. If you’re fuzzy on SD, check out the dedicated Varsity page (it’s a quick read). Here’s the TL;DR:  

> **Standard Deviation (σ)** = “how far, on average, the data points wander away from the mean.”  
> In textbook speak: *“In statistics, the standard deviation (SD, also represented by the Greek letter sigma, σ) is a measure that is used to quantify the amount of variation or dispersion of a set of data values.”*  

In plain English, SD tells us whether our data points are tight‑knit like a close‑friend group or spread out like strangers at a concert.  

### What does that look like for our pair‑data?  

Our **differential** series (the first‑order difference between the two stocks) contains **496** observations. Its average (mean) is **228.52**.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2017/12/Image-4_diffdata.png)  

**Question:** “How much do these 496 points bounce around that 228.52 average?”  

**Answer:** By measuring their variability with SD. Why? Because without a sense of spread we can’t tell if a new data point (say the 498th) is a routine foot‑traffic or a wild outlier. And that distinction is the beating heart of pair‑trading decisions.  

Some traders love SD; others also like to keep a side‑dish called **Absolute Deviation** (aka Mean Absolute Deviation). Both gauge variability, but they treat the data differently.  

Here’s a tidy quote I lifted from Investopedia (credit where credit’s due):  

> “While there are many different ways to measure variability within a set of data, two of the most popular are standard deviation and average deviation. Though very similar, the calculation and interpretation of these two differ in some key ways. Determining range and volatility is especially important in the finance industry, so professionals in areas such as accounting, investing and economics should be very familiar with both concepts.  
>   
> **Standard deviation** is the most common measure of variability and is frequently used to determine the volatility of stock markets or other investments. To calculate the standard deviation, you must first determine the variance. This is done by subtracting the mean from each data point and then squaring, summing and averaging the differences. Variance in itself is an excellent measure of variability and range, as a larger variance reflects a greater spread in the underlying data. The standard deviation is simply the square root of the variance. Squaring the differences between each point and the mean avoids the issue of negative differences for values below the mean, but it means the variance is no longer in the same unit of measure as the original data. Taking the root of the variance means the standard deviation returns to the original unit of measure and is easier to interpret and utilize in further calculations.  
>   
> **The average deviation**, also called the mean absolute deviation, is another measure of variability. However, average deviation utilizes absolute values instead of squares to circumvent the issue of negative differences between data and the mean. To calculate the average deviation, simply subtract the mean from each value, then sum and average the absolute values of the differences. The mean absolute value is used less frequently because the use of absolute values makes further calculations more complicated and unwieldy than using the simple standard deviation.”  

Now, let’s compute **both** SD and Absolute Deviation for our three pair metrics (Differential, Ratio, Spread).  

> *Side note:* I’m swapping the axes around – Y‑axis will be Mean/Median/Mode, X‑axis will be Differential/Ratio/Spread. Hence the screenshots you see below will look a tad different from the earlier ones. Apologies for my “creative” data‑layout skills.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2017/12/Image-5_stdev.png)  

**Excel formulas**  

| Metric | Excel function |
|--------|----------------|
| Standard Deviation (population) | `=STDEV.P()` |
| Absolute Deviation | `=AVEDEV()` |

Together, Mean, Median, Mode, Standard Deviation, and Absolute Deviation form the **basic descriptive statistics** toolbox.  

---

## 5.3 – The Standard‑Deviation Table  

We’ve got SD numbers, but let’s turn them into a decision‑making dashboard. Think of it as a “how far are we from the party?” ruler. By converting SD into concrete upper‑ and lower‑bounds, we can instantly spot whether a fresh data point is a wall‑flower or the life of the party.  

### Why bother?  

Suppose the 498th differential comes out at **315**. Is that a modest bump or a red‑flag? If we know where 315 lands on the SD scale, we can decide whether to **go long** (buy) or **short** (sell) the pair – the actual trade logic will appear later, but the intuition starts here.  

### Building the table  

The layout looks like this:  

![Image](https://zerodha.com/varsity/wp-content/uploads/2017/12/Image-6_sd.png)  

For each metric (Spread, Differential, Ratio) we’ll compute:  

* Mean ± 1 σ  
* Mean ± 2 σ  
* Mean ± 3 σ  

Let’s walk through the **Spread** as a worked example.  

* **Mean of Spread** = **0.064** (yes, that tiny number is the average of the spread series).  
* **SD of Spread** = **8.075**  

Now the arithmetic:  

| Band | Calculation | Result |
|------|-------------|--------|
| +1 σ | 0.064 + 8.075 | **8.139** |
| +2 σ | 0.064 + 2 × 8.075 | **16.123** |
| +3 σ | 0.064 + 3 × 8.075 | **24.288** |
| –1 σ | 0.064 – 8.075 | **‑8.011** |
| –2 σ | 0.064 – 2 × 8.075 | **‑16.086** |
| –3 σ | 0.064 – 3 × 8.075 | **‑24.160** |

We repeat the same arithmetic for **Differential** and **Ratio**, and the full table pops out like this:  

![Image](https://zerodha.com/varsity/wp-content/uploads/2017/12/Image-7_sdcalculated.png)  

Now, if tomorrow’s 498th differential reads **315**, we instantly recognise it sits around **+2 σ**. Statistically, that lands us in the 95 % confidence zone – there’s only about a 5 % chance the next point will be even higher. Handy, right?  

At this point we’ve gathered almost every piece we need to assess whether the pair is ripe for a trade. In the next chapter we’ll put the table to work, and I’ll start with a quick recap so we’re all on the same page (no one likes missing the plot twist).  

You can grab the Excel workbook used here **[download it here]**.  

Signing off with a festive shout‑out: Happy Christmas, a joyous New Year, and may 2018 (or whatever year you’re reading this in) bring you wisdom, wealth, and peace. 🍾  

### Key takeaways from this chapter  

- Normal distribution is the statistical backbone of pair trading.  
- 1 σ ≈ 68 % of observations, 2 σ ≈ 95 %, 3 σ ≈ 99.7 %.  
- Standard deviation and absolute deviation both measure data variability (SD is more common).  
- A “standard‑deviation table” translates variability into concrete upper/lower bounds.  
- Those bounds tell us whether the current data point is an outlier – the cue to go **long** or **short** the pair.  