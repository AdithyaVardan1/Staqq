# 4. PTM1, C2 – Pair stats  

**Source:** <https://zerodha.com/varsity/chapter/pair-stats/>  

---  

##  

![Image](https://zerodha.com/varsity/wp-content/uploads/2017/12/M10-C4-cartoon.png)  

## 4.1 – Correlation and its types  

Alright, before we dive into the juicy bits, a quick shout‑out to the book that got me hooked on pair trading: *Trading Pairs* by Mark Whistler. It’s the financial equivalent of that first beer that makes you love the taste of a bar—once you’ve had it, you’ll keep coming back for more. I’ll spill the beans on Mark’s original ideas, then later sprinkle in a few of my own mischief‑filled twists.  

In the previous chapter we flirted with the idea of **correlation**—that mysterious number that tells you whether two stocks are best buddies or sworn enemies. Now we’ll roll up our sleeves, fire up Excel, and actually **calculate** that number for a real‑world pair. Spoiler alert: the correlation is the holy grail of pair trading.  

### Picking a pair (the “obvious” ones)  

For demo‑purposes I grabbed **Axis Bank** and **ICICI Bank**. Both are private‑sector banks, they both love money, and our gut tells us they should waltz together like twins.  

I downloaded their daily **closing prices** from **4 Dec 2015** to **4 Dec 2017** – roughly two years, which gives us about **496 data points** (yes, we counted the weekends that the market was closed).  

#### Quick data‑cleaning checklist (the “don’t be that guy” list)  

- **Same number of rows** – If Stock A has 400 points, Stock B must also have 400 points for the *exact same dates*. Think of it like a synchronized dance; you can’t have one partner missing a step.  
- **Adjust for corporate actions** – Bonuses, splits, spin‑offs… basically anything that changes the share count or price without reflecting true market movement.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2017/12/Image-1_Data.png)  

Besides our two banks, I also snatched data for **BPCL, HPCL, and HDFC Bank**. Feel free to mess around with those later and see what other pair‑lovey‑dovey stories they tell.  

### From prices to returns (the “daily drama”)  

All we have right now are dates and closing prices. The next step is to turn those prices into **daily returns**, because returns tell us *how much* a stock moved, not just *where* it sits.  

The classic return formula is:  

\[
\text{Daily Return} = \frac{\text{Today’s Close}}{\text{Yesterday’s Close}} - 1
\]

I ran this for both Axis and ICICI and got this tidy table:  

![Image](https://zerodha.com/varsity/wp-content/uploads/2017/12/Image-2_daily-return.png)  

### Correlation: price vs. return  

You can compute correlation on **two different series**:  

1. **Closing‑price series** – raw price numbers.  
2. **Return series** – the percentage moves we just calculated.  

I’m not a huge fan of the first method (prices are like comparing the heights of two strangers; returns are the *behaviour*), but let’s do it for completeness.  

#### 1️⃣ Correlation on closing prices  

In Excel, just type `=CORREL(array1, array2)`. I set up a fresh sheet called **“Pair Data”** and punched the numbers in.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2017/12/Image-3_close-correl.png)  

Result? **0.51**. Not exactly a love‑song, more like a polite “hey, you’re okay”. Remember, we thought the banks would be 0.9‑plus twins, but the market had other plans.  

#### 2️⃣ Correlation on daily % returns  

Same formula, just feed it the return columns.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2017/12/Image-4_percentage.png)  

Again, the number isn’t screaming “perfect pair”. That’s fine—pair trading tolerates imperfection; it just needs *some* relationship.  

#### 3️⃣ Correlation on absolute price changes (the “raw‑meat” method)  

Some traders like to take `Today’s Price – Yesterday’s Price` (the absolute delta) and correlate those. I’m not sold on it, but let’s throw it in for completeness.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2017/12/Image-5_abs-change.png)  

### Symmetry of correlation  

Notice that whether I compute **Axis vs. ICICI** or **ICICI vs. Axis**, the result is identical. Correlation is symmetric:  

\[
\rho_{A,B} = \rho_{B,A}
\]

In the “sacred‑pair” world we’re building, a **correlation above 0.75** is the holy grail. Our 0.51 falls short, but—just like a first‑date conversation—there’s still potential.  

## 4.2 – Setting up the datasheet  

Recall Chapter 3’s three key pair‑trading variables:  

- **Spread** (the price gap)  
- **Differential** (the percentage gap)  
- **Ratio** (price ÷ price)  

We’ll compute those on a **new sheet** in the same workbook, calling it **“Data Sheet”**. Here’s a quick peek:  

![Image](https://zerodha.com/varsity/wp-content/uploads/2017/12/Image-6_pairdata.png)  

The math is exactly what we covered before—no rocket science, just a few Excel formulas.  

Because we’re keeping things “basic‑stats‑only” for this edition, we’ll focus on three elementary statistical measures that every trader (and cricket‑obsessed math‑nerd) should know.  

## 4.3 – Basic stats  

Let’s break down three statistical staples that pop up all over pair trading. If you survived high‑school math, you’ve already met these; if not, no worries—think of them as the **B‑team** of analytics: solid, dependable, and occasionally surprising.  

### Mean – the arithmetic average  

Imagine a batsman’s scores over ten innings:  

`23, 34, 44, 51, 55, 65, 72, 82, 100, 100`  

**Mean** = (Sum of all scores) ÷ (Number of scores)  

\[
\text{Mean} = \frac{23+34+44+51+55+65+72+82+100+100}{10}
           = \frac{626}{10}
           = 62.6
\]

In Excel, just type `=AVERAGE(range)`.  

### Median – the middle child  

Sort the data from smallest to largest (as we did above). With an **even** count (10), the median is the average of the two middle numbers.  

Middle numbers = **55** and **65**  

\[
\text{Median} = \frac{55+65}{2} = 60
\]

Excel’s shortcut: `=MEDIAN(range)`.  

When you line up mean **and** median, you get a quick sense of skewness: if mean > median, the distribution leans right (a few big scores pulling the average up); if median > mean, the opposite.  

### Mode – the most‑repeated score  

The **mode** is simply the value that appears most often. In our list, **100** shows up twice, while every other number appears once, so **100** is the mode.  

Excel function: `=MODE.SNGL(range)` (or `=MODE.MULT` for multiple modes).  

These three numbers—mean, median, mode—are the “trifecta” that will later help us spot whether a pair’s spread is behaving normally or pulling a prank.  

> **Download the Excel sheet used in this chapter [here]**. (Link omitted for brevity.)  

Stay tuned; the next chapter will show you how to plug these stats into a live pair‑trading model.  

### Key takeaways from this chapter  

- **Data hygiene** matters: always align dates, remove corporate‑action noise, and keep the rows equal.  
- **Close‑price correlation** = correlation computed on raw closing prices.  
- **Return‑correlation** = correlation computed on daily percentage returns (the preferred metric).  
- **Mean** = arithmetic average (`=AVERAGE`).  
- **Median** = middle value (or average of two middles for even counts) (`=MEDIAN`).  
- **Mode** = most‑frequent value (`=MODE.SNGL`).  
- When the **mean** and **median** diverge, they whisper clues about the data’s skewness.  
- A solid pair‑trading setup usually wants a **correlation > 0.75**, but anything above 0.5 can be a workable starting point.  

That’s it for now—clean data, compute those basics, and you’ll be ready to tango with pairs like a pro (or at least not step on anyone’s toes). Cheers!