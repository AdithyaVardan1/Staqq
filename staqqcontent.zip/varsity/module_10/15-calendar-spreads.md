# 15. Calendar Spreads  

**Source:** <https://zerodha.com/varsity/chapter/calendar-spreads/>

---  

## 15.1 – The classic approach  

Alright, let’s roll back the tape a bit. In Chapter 10 of the Futures Trading module we gave you a teaser on calendar spreads – think of it as the “first sip of a good whiskey”. The old‑school way treats them as a **price‑based** game. Here’s the three‑step cheat sheet you’d normally scribble on a napkin:

1. **Fair‑value the current‑month contract** – that’s the one that’s about to say “see ya” soon.  
2. **Fair‑value the next‑month (or “mid‑month”) contract** – the one that still has a few weeks to go.  
3. **Spot the relative mis‑pricing** between the two.  

Once you’ve got the mis‑pricing, you either:  

* **Buy the near month** and **sell the next month**, **or**  
* **Sell the near month** and **buy the next month**.  

That’s it – a classic calendar spread in a nutshell.  

**Example (just to keep the math‑nerd happy):**  

| Action | Instrument | Expiry | Price |
|--------|------------|--------|-------|
| **Buy** | TCS Futures | 28 Jun 2018 | **1846** |
| **Sell**| TCS Futures | 28 Jul 2018 | **1851** |

So you’re long the June contract, short the July contract, both on the same stock. The *spread* – the 5‑point gap – is where the magic (or the modest profit) lives.  

Why does this sound like a “low‑risk” cocktail? Because you’re simultaneously long **and** short the *same* underlying, which wipes out most of the directional risk. The trade‑off? The profit‑potential is also tiny – think “extra‑large fries without the extra‑large price”. If you’re the kind of trader who flinches at the thought of a 10 % swing, this strategy is right up your alley.  

The classic method is solid enough for most beginners, but if you haven’t read Chapter 10 yet, you might feel like you’re watching a movie with the subtitles turned off. Give it a skim – it lays the groundwork for the fancier variants we’ll explore later.  

Ready? Let’s dive in.  

---  

## 15.2 – Calendar spread logic  

If you survived the pair‑trading crash‑course, the calendar‑spread logic will feel like a déjà‑vu. The premise is simple: **the current futures price already reflects everything the market knows** – news, earnings, corporate actions, the whole gossip column.  

![Cartoon](https://zerodha.com/varsity/wp-content/uploads/2018/06/M10-C15-Cartoon.png)  

So, if the market is an all‑knowing oracle, why not let the **price itself** be the trigger? It’s like letting the bartender decide when you’ve had enough – you just follow the signal.  

A few things to keep in mind:  

* **Low‑risk, low‑reward** – don’t expect to buy a yacht after a single spread.  
* **Direction‑neutral** – because you’re buying and selling the same asset, the market’s up‑or‑down moves mostly cancel out. That lets you crank up leverage a tad (but don’t go full‑blown “rocket scientist” on it).  
* **Ultra‑short‑term** – many calendar spreads close **the same day** or within a day or two. Think of it as a day‑trader’s version of a “quick coffee break”.  

**How to actually do it (step‑by‑step, no magic):**  

1. **Download** the continuous futures close prices for both the near‑month and the next‑month contracts.  
2. **Compute the daily historic difference** (near‑month price minus next‑month price) and build a time‑series.  
3. **Calculate the mean** and **standard deviation** (SD) of that difference series.  
4. **Define the trading range**:  
   * Upper bound = **Mean + 1 × SD**  
   * Lower bound = **Mean – 1 × SD**  
5. **Signal**: when the spread breaches either bound, you open a position.  
6. **Exit**: when the spread collapses back toward the mean, you close it.  

Got it? You’ve just turned a spreadsheet into a mini‑prop‑shop. 😊  

---  

## 15.3 – Calendar spread example  

Time to get our hands dirty with a real‑world case: **State Bank of India (SBIN)**. I pulled the continuous futures data from Zerodha Pi (the desktop app that makes you feel like a Wall Street wizard) for the last **200 trading days**. Here’s a screenshot of the raw close‑price dump (yeah, that Excel sheet is the hero of this story).  

![Data snapshot](https://zerodha.com/varsity/wp-content/uploads/2018/06/Image-1_data.png)  

**Step 1: Build the spread**  
Subtract the *near‑month* price from the *current‑month* price. Why this order? Because, all else equal, the near‑month contract usually trades **higher** than the older one – the classic “cost‑of‑carry” effect (see Chapter 10 for the full textbook treatment).  

**Step 2: Plot the spread series**  

![Spread series](https://zerodha.com/varsity/wp-content/uploads/2018/06/Image-2_difference.png)  

**Step 3: Compute the stats**  

| Statistic | Value |
|-----------|-------|
| Mean      | **1.227** |
| Std‑Dev   | **0.4935** |

You can get these numbers in Excel with `=AVERAGE(range)` and `=STDEV.P(range)` (or `=STDEV.S` if you’re dealing with a sample).  

The **mean of 1.227** tells us that, on a normal day, the price gap between the two contracts hovers around **1.227 points**. Anything sitting comfortably near that number is just market noise – not a trade‑worthy signal.  

Now we use the **standard deviation** to carve out a “reasonable‑range” (the **vicinity** you asked for earlier).  

* **Upper range** = 1.227 + 0.4935 = **1.7205**  
* **Lower range** = 1.227 – 0.4935 = **0.7335**  

If the spread wanders **outside** this corridor, we have a potential play.  

* **Spread > 1.7205** → near‑month is *expensive* (or current‑month is *cheap*). Rule of thumb: **buy cheap, sell dear** → **Buy the current‑month contract, sell the near‑month**.  
* **Spread < 0.7335** → near‑month is *cheap* (or current‑month is *expensive*). → **Sell the current‑month, buy the near‑month**.  

That’s the whole logic in a nutshell. Now let’s see whether SBIN gave us any such “out‑of‑bounds” moments over those 200 days.  

---  

## 15.4 – Spotting opportunities  

Armed with the two thresholds, we translate them into actionable rules:  

| Situation | Action | What you actually do |
|-----------|--------|----------------------|
| **Spread > 1.7205** | **Sell the spread** | *Sell* the near‑month contract **and** *buy* the current‑month contract |
| **Spread < 0.7335** | **Buy the spread** | *Buy* the near‑month contract **and** *sell* the current‑month contract |

If you’re still tangled up on “sell the spread vs. sell the near month”, just remember: **focus on the near‑month contract**. “Sell spread” = **sell near‑month** (so you’re buying the current‑month). “Buy spread” = **buy near‑month** (so you’re selling the current‑month).  

### Hunting the short‑spread trades (sell‑spread)  

In Excel, I filtered the spread column for any value **> 1.7205**. The result? Six occasions where the spread blew past the upper bound.  

![Sell‑spread list](https://zerodha.com/varsity/wp-content/uploads/2018/06/Image-4_sell.png)  

A quick glance tells a story: most of these spikes happen **around month‑end**, likely because of expiry‑related roll‑overs. Every one of those six trades **closed the next day** with a modest profit.  

### Hunting the long‑spread trades (buy‑spread)  

Now filter for **< 0.7335**. This time we get **≈ 28** rows – a lot more opportunities, but also a few duds.  

![Buy‑spread list](https://zerodha.com/varsity/wp-content/uploads/2018/06/Image-5_buy.png)  

Not every trade was a winner, but the losers were tiny – often smaller than the winners. If you’re curious, pop open the sheet and sum the P&L column; you’ll see the net result is still **positive** (though not as clean as the short side).  

### What did we learn?  

* **Calendar spreads are simple** – you just need price data, a calculator, and a dash of common sense.  
* **Profit & loss are modest** – think of it as pocket‑change, not a windfall.  
* **Directional risk is essentially gone**, which means you can safely crank up leverage (but remember, leverage is a double‑edged sword).  
* **In SBIN’s case, short‑spread trades were all winners**, while the long side was mixed. That tells us: *maybe* SBIN’s futures are better suited for short‑spread opportunities. In practice, you’d back‑test each ticker to see which side works best.  
* **Low transaction costs matter** – the slimmer the profit, the more you need a discount broker like Zerodha to keep the cost‑to‑profit ratio healthy.  
* **Most trades close in 1‑2 days**, often triggered by expiry dynamics.  

If you could run this same back‑test across the whole universe of equity and commodity futures, you’d probably end up with **at least a signal or two every single day**. That’s the secret sauce of calendar spreads: a tiny, repeatable edge that compounds over time.  

---  

### Key take‑aways (the TL;DR for the lazy)  

1. **Expected P&L is small** – treat it like a side‑hustle, not a main gig.  
2. **Directional risk is neutralized**, so you can push leverage (within reason).  
3. **Back‑test each contract** – SBIN showed us that short‑spread trades were reliable, long‑spread trades less so. Your results may differ.  
4. **Keep costs low** – a high‑fee broker will eat the tiny profits faster than a mouse on cheese.  
5. **Trades are usually intraday or 1‑2‑day affairs**.  
6. **Expiry‑related spikes are the usual culprits** – keep an eye on the calendar (pun intended).  

Imagine running this across all stocks and commodities – you’d have a constant stream of micro‑arb opportunities. That’s the allure of calendar spreads: **simple, systematic, and (almost) boring – which is exactly why they work**.  

Got questions? Hit me up in the comments.  

**Download the Excel sheet** (yes, it’s still available).  

*P.S.* I won’t be cranking out brand‑new chapters for a while, but don’t worry – I’m cooking up a different format that’ll be *even* more exciting (think interactive dashboards, live demos, maybe a meme or two). Stay tuned! 😊  