# Junior  

**Source:** https://zerodha.com/varsity/chapter/episode-1-ideas-by-the-lake/  

---

Grab a drink, kick back, and click the link below – it’s the “Ideas by the Lake” episode from Zerodha’s Varsity series. Think of it as a laid‑back brainstorming session where the only thing you’ll be fishing for are solid trading ideas (no actual lakes involved, unless you count the sea of charts).  

https://www.youtube.com/watch?v=9155SZc96kk   🪙💡   *(Spoiler: there’s no actual lake, just a lot of brain‑waves and charts.)*