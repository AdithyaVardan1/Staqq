# 7. PTM1, C5 – The Pair Trade  

**Source:** <https://zerodha.com/varsity/chapter/the-pair-trade/>  

---  

## 7.1 – Quick Reminder  

We capped the last chapter with a quick chat about the **density curve** and how its number can point us to a juicy pair‑trading setup. In this chapter we’ll actually **pick a trade, put it on the board, and see what other quirks a pair‑trade brings along**.  

A little housekeeping first: everything we’ve covered from chapter 1 through 7 comes straight out of *Trading Pair* by **Mark Whistler**. The beauty of Whistler’s method is its **beautiful simplicity**—so simple, in fact, that sometimes it feels a bit…‑​*naïve*. Over the years I’ve tweaked the approach (you’ll see the upgrades in the next chapter).  

You might wonder, “Why not jump straight to the 2ⁿᵈ method?” – because Whistler’s technique builds a **rock‑solid foundation**. Once you’re comfortable with the basics, the more sophisticated version suddenly makes sense (instead of looking like a foreign language). So let’s finish Whistler’s recipe first, then we’ll spice things up.  

Since the next method is more of a “big‑picture” beast, I’ll keep the nitty‑gritty trade‑setup light and focus on the **overall architecture**. Ready? Let’s roll.  

---  

## 7.2 – Digging into the Density Curve  

The density curve is our **early‑warning siren** for a pair‑trade. Keep an eye on two ingredients:  

1. **What we feed it** – It’s built from the *time‑series* of the **ratio** (stock A ÷ stock B). Remember the three pillars from the previous chapter?  
   * Ratio series  
   * Ratio’s mean  
   * Ratio’s standard deviation  

2. **What it spits out** – A number between **0 and 1** that tells us the *probability* the ratio will snap back to its mean.  

That second line can sound like a cryptic fortune‑cookie, so stash it in your brain for now; the “aha!” moment will hit later.  

### A quick (and slightly cheesy) refresher on the normal distribution  

The ratio series, like most things in finance, has an **average** (or *mean*). In our demo the mean was **1.87** (we crunched that in chapter 6). Most of the time the ratio hangs around that mean. When it strays—say it jumps to **2.5**—the market tends to **pull it back** toward 1.87, just like a rubber band.  

**Question:** *If the ratio has wandered off, how likely is it to boomerang back?*  
Is it a 10 % chance? 20 %? 90 %?  

Enter the **density curve**. Its value tells us **how many standard deviations** the current ratio sits away from the mean, and each deviation carries an associated probability.  

#### Mini‑example  

| Item | Value |
|------|-------|
| Latest ratio | **2.87** |
| Ratio mean   | **1.87** |
| Density curve| **0.92** |

A density‑curve reading of **0.92** means the ratio is **roughly at the 2nd standard‑deviation** away from the mean. In a normal distribution, that translates to about a **95 % probability** that the ratio will drift back toward 1.87.  

How do we know that 0.92 ≈ “2 σ”? The curve is *mapped* to the cumulative normal distribution:  

| Density‑curve value | Where you sit on the bell curve |
|---------------------|----------------------------------|
| **0.16** | –1 σ (one standard deviation **below** the mean) |
| **0.84** | +1 σ (one standard deviation **above** the mean) |
| **0.997**| +3 σ (three standard deviations above) |

So once you have the curve number, you instantly know both the **σ‑level** and the **probability** of a mean‑reversion.  

> **Pro tip:** Keep a cheat‑sheet of common curve‑to‑σ mappings handy. For instance, a curve of **0.19** ≈ –1 σ → ~65 % chance of reverting, while **0.999** ≈ +3 σ → ~99.9 % chance.  

That’s all the math you really need; the rest is just a table you can stare at while sipping coffee.  

![Cartoon illustration of density curve magic](https://zerodha.com/varsity/wp-content/uploads/2018/02/M10-C7-Cartoon.png)  

---  

## 7.3 – The First Pair Trade  

Alright, the moment you’ve been waiting for: **our inaugural pair‑trade**. Quick recap of the mechanics:  

| Item | What it means |
|------|----------------|
| **Ratio** | Stock A ÷ Stock B (here: **Axis Bank / ICICI Bank**) |
| **Daily dance** | Ratio wiggles each day as the two share prices move |
| **Density curve** | Re‑computed every day to see how far the ratio has strayed |

### The trading intuition  

1. **Two similar businesses → similar price moves** – Axis and ICICI are both Indian banking giants, so their stocks usually march together.  
2. **A market shock hits one more than the other** → the ratio deviates.  
3. **Spot the deviation** → you have a trade opportunity.  

So the pair‑trader’s job is simple: **monitor the ratio and its density‑curve value**. When the ratio wanders “far enough” from its historic mean, you jump in.  

### How far is “far enough”?  

A **rule of thumb** (borrowed from Whistler) is:  

*Enter a trade when the ratio sits between the **2nd and 3rd standard deviation** (i.e., density‑curve between roughly **0.025 – 0.975**).  
*Exit (or “square‑off”) when the ratio slides back **below the 2nd‑σ line** (density‑curve around 0.16 or 0.84, depending on direction).  

The closer you get to the mean, the fatter your profit slice.  

### Let’s walk through a **long** trade  

Grab the Excel sheet from the end of chapter 6 (or just imagine a spreadsheet that does the heavy lifting).  

| Date | Density curve | Ratio | What it suggests |
|------|---------------|-------|------------------|
| **25 Oct 2017** | **0.05234** | **1.54** | Nice long‑pair candidate (though a tad shy of the 0.025‑0.003 sweet‑spot) |

Because we defined the ratio as **Axis / ICICI**, a **long** trade means:  

* **Buy Axis Bank** (the numerator)  
* **Sell ICICI Bank** (the denominator)  

Numbers on that day:  

* **Axis Bank @ ₹473** – Lot size = **1,200** → **₹567,600** contract value  
* **ICICI Bank @ ₹305.7** – Lot size = **2,750** → **₹840,675** contract value  

Ideally you’d make the two legs *Rupee‑neutral* (same dollar exposure on both sides). We’ll postpone that nuance for the next method.  

Now we sit tight, waiting for the ratio to swing back. The *perfect* scenario would be catching it near the **3σ** level and watching it glide toward the mean—though that can take weeks and your MTM (mark‑to‑market) may look scary. If you’re not a deep‑pocketed trader, you’ll want to close earlier.  

Fast‑forward to **31 Oct 2017**:  

* Ratio has drifted up to **1.743**  
* Density curve = **0.26103** (roughly the target exit zone)  

We close:  

* **Sell Axis @ ₹523**  
* **Buy back ICICI @ ₹300.1**  

Result? The bulk of the profit came from Axis – it was the stock that over‑reacted and then corrected. Not bad for a first go‑round, right?  

### Now a **short** trade  

| Date | Density curve | Ratio | What it suggests |
|------|---------------|-------|------------------|
| **9 Aug 2016** | **0.99063156** | **≈2.34** | Short‑pair signal (close to 3σ on the upper side) |

Remember the rule: **numerator = dominating stock**. In a short‑pair you **short the numerator** and **go long the denominator**.  

So we:  

* **Short Axis @ ₹574.1**  
* **Buy ICICI @ ₹245.35**  

Fast‑forward to **8 Sept 2016** (about a month later):  

* **Buy Axis back @ ₹571**  
* **Sell ICICI @ ₹276.33**  

The density curve has fallen to **0.979182** – still high, but we chose to exit to avoid excessive MTM pain.  

Profit again comes mainly from one leg (this time ICICI), confirming that it was the outlier that corrected.  

> **Side note:** Both examples stray a little from the textbook 2‑σ/3‑σ entry‑exit bands. That’s fine – treat the table as a *guide*, not a law. The real skill is learning when to bend the rules.  

Feel free to hunt for other Axis‑ICICI combos (different dates, different ratios) and see what the numbers whisper.  

### TL;DR of the whole saga  

* We’ve only scratched the surface – roughly **25 %** of the full pair‑trading toolbox.  
* The first seven chapters give you a **basic, no‑frills framework**.  
* We haven’t talked about strict **stop‑losses, targets, or rupee neutrality** yet – those are coming.  
* Risk, margin requirements, and the fact that *pair‑trading guzzles cash* will be covered later.  
* Expect **2‑3 solid signals per pair per year**; to stay busy you’ll need to monitor several pairs.  

Hope the little profit demo above has lit a fire under you. I’ll stop here so you can let it all soak in. When you’re ready, download the Excel sheet and start playing detective with ratios!  

---  

### Key takeaways from this chapter  

- The **density curve** is the primary trigger for entering a pair trade.  
- **Enter** when the ratio lives between the **2nd and 3rd standard deviations** (density‑curve ≈ 0.025‑0.975).  
- **Exit** when the ratio drifts back toward the **mean** (density‑curve drops below the 2nd‑σ line).  
- **Long pair** → **Buy** the numerator, **Sell** the denominator.  
- **Short pair** → **Sell** the numerator, **Buy** the denominator.  
- Most of the **P&L** usually comes from the stock that deviated the most.  
- Trades can sit open for weeks; the payoff often justifies the patience.  
- Pair trading is a **margin‑intensive** game, so keep cash on hand.  

Enjoy the hunt, and may your density curves always point you toward sweet mean‑reversions!  