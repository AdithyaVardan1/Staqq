# 3. Pair Trading, Method 1, Chapter 1 (PTM1, C1) – Tracking Pairs  

**Source:** <https://zerodha.com/varsity/chapter/tracking-pairs/>

---  

## 3.1 – Getting you familiar with Jargons  

Alright, strap in, because before we start slinging pairs like a seasoned bartender tossing cocktail shakers, we need to learn the lingo. In the previous chapter we hinted at two ways to do pair‑trading. The one we’ll dive into first is the **correlation‑based** technique – the “standard‑issue” method that most newbies use to get their first taste of pair‑trading. Think of it as the starter beer before you move on to the fancy craft brews.

> ![Cartoon illustration of a trader holding a “pair‑trading” sign](https://zerodha.com/varsity/wp-content/uploads/2017/11/M10-C3-Cartoon.png)  

Below are the buzzwords you’ll hear (and occasionally mutter under your breath) when we talk about **tracking pairs**. I’ll give you the definition, a quick example, and a dash of humor to keep you awake.

### Spread – The Swiss‑army knife of trading jargon  

“Spread” is a word that wears many hats.  

* **Scalpers** think of it as the rupee gap between the *bid* and the *ask*.  
* **Arbitrageurs** see it as the price difference for the *same* asset on two different exchanges.  
* **Pair traders** (the crowd we care about) define it as the **difference between the closing prices of two stocks**.

The formula is as simple as a two‑line poem:

\[
\text{Spread} = \text{Closing price of Stock 1} \;-\; \text{Closing price of Stock 2}
\]

#### Example time  

Imagine Stock 1 = **GICRE**, Stock 2 = **ICICIGI**. Yesterday they closed with the following *price changes* (i.e., how much they moved from the previous close):

* GICRE: **+6.1**  
* ICICIGI: **+3.85**

Plug‑in:

\[
\text{Spread} = 6.1 - 3.85 = 2.25
\]

Both numbers are positive, so the spread is a modest 2.25 points.  

Now, let’s flip the script and pretend ICICIGI actually fell **‑3.85** (a negative move). The spread balloons:

\[
6.1 - (-3.85) = 6.1 + 3.85 = 9.95
\]

Boom! The spread has expanded dramatically because the two stocks moved in opposite directions.

I crunched the spread for the last few trading days and plotted it. Since I’m using daily closing values, traders call this the **historical spread**.

> ![Spreadsheet of historical spread values for GICRE and ICICIGI](https://zerodha.com/varsity/wp-content/uploads/2017/11/Image-2_spreadexcel.png)  

**What you’ll notice:**  

| Situation | Effect on Spread |
|-----------|-------------------|
| Stock 1 ↑, Stock 2 ↓ (or negative) | **Expands** (gets wider) |
| Stock 1 ↑, Stock 2 ↑ (both positive) | **Contracts** (gets tighter) |

There are, of course, other combos (both down, one up/one flat, etc.) that either stretch or squeeze the spread. We’ll revisit those later.

### Differential – The “absolute‑difference” cousin  

If spread is the cool, multi‑purpose tool, differential is the *no‑nonsense* sibling that only cares about **absolute** price differences, not about whether the numbers are positive or negative.

\[
\text{Differential} = \bigl| \text{Closing price of Stock 1} \;-\; \text{Closing price of Stock 2} \bigr|
\]

In practice we drop the absolute‑value bars and just remember that a negative result means “stock 2 is higher”.

**Example:**  

* Stock 1 closes at **₹175**  
* Stock 2 closes at **₹232**

\[
\text{Differential} = 175 - 232 = -57
\]

So the differential is –57 points, indicating Stock 2 is ₹57 above Stock 1.

I plotted the daily differential for our GICRE/ICICIGI pair:

> ![Differential time‑series chart](https://zerodha.com/varsity/wp-content/uploads/2017/11/Image_diff.png)  

**Key insight:**  
*Spreads* can be used intraday (you can watch them tick by tick). *Differentials* are a bit more “end‑of‑day” friendly because they’re noisy during the session. In short, use spreads for real‑time tracking; keep differentials for daily sanity checks.

### Ratio – Division, but make it interesting  

The **ratio** is simply the price of one stock divided by the price of the other. It can be either direction, but you’ll usually pick the one that yields a number around 1 (makes the chart easier on the eyes).

\[
\text{Ratio} = \frac{\text{Price of Stock 1}}{\text{Price of Stock 2}}
\]

For our two‑stock example:

> ![Ratio spreadsheet for GICRE/ICICIGI](https://zerodha.com/varsity/wp-content/uploads/2017/11/Image-3_ratio.png)  

When you run the ratio through time, it tends to look smoother than raw spreads, because the denominator scales the numerator.

I threw all three metrics (spread, differential, ratio) on a single graph to see how they behave relative to each other:

> ![Combined graph of spread, differential, and ratio](https://zerodha.com/varsity/wp-content/uploads/2017/11/Image-4_graphs.png)  

#### Quick recap of the three  

| Metric | What it measures | Typical use |
|--------|------------------|--------------|
| **Spread** | Closing‑price *difference* (Δ) | Intraday tracking |
| **Differential** | Absolute price gap (|Δ|) | End‑of‑day sanity check |
| **Ratio** | Relative price (Stock 1 / Stock 2) | Trend‑smoothing, long‑term view |

### Divergence & Convergence – The “push‑pull” dance  

Now that we have numbers that change over time, we need to interpret **how** they move.

* **Divergence** – When you *expect* the metric (spread, ratio, etc.) to **grow wider** (i.e., the two stocks drift apart). If you’re right, you can set up a *divergence trade* to profit from that widening. Think of it like betting that two friends at a party will end up in opposite corners.

* **Convergence** – The opposite: you anticipate the metric to **shrink** (the two stocks come back together). A *convergence trade* profits when the gap closes. It’s like betting that the two friends will eventually sit back down at the same table.

> “When do you decide whether to expect a divergence or a convergence?” you ask. Great question! The answer lies in **correlation**—the statistical glue that tells you how tightly two stocks are coupled.

### Correlation – The glue (or the rubber band)  

Correlation is the old‑school statistical measure that quantifies the *co‑movement* of two variables. Its value lives in the interval **‑1 to +1**.

| Correlation value | What it means |
|-------------------|----------------|
| **+1** | Perfect positive co‑movement (they rise and fall together like synchronized swimmers). |
| **‑1** | Perfect negative co‑movement (when one goes up, the other goes down like a seesaw). |
| **0** | No linear relationship (they’re strangers at the party). |
| **+0.75** (example) | Strong positive relationship, but not perfect. |

**Interpretation of +0.75**  

* The plus sign tells you the direction is *positive*: both stocks tend to move the **same way**.  
* The magnitude (0.75) tells you the *strength*: the closer to 1, the tighter the dance.  

**Important nuance:** Correlation tells you **direction**, not **size**. If Stock A jumps 3 % and the correlation is +0.75, you can’t claim Stock B will also jump 3 %. All you know is that Stock B is likely to go **up** (or down) *in the same direction* as Stock A.

A more practical way to think about it:  

*Suppose* Stock A’s average daily return is **0.9 %** and Stock B’s is **1.2 %**. With a correlation of **+0.75**, on a day when Stock A exceeds its 0.9 % average, Stock B is *also* likely to beat its 1.2 % average. Conversely, if Stock A underperforms, Stock B will probably underperform too.

**Negative correlation example** – If correlation = **‑0.75**, a 2.5 % rise in Stock A suggests Stock B will *likely* fall, but the exact magnitude is unknown.

#### Stationarity – The “stay‑close‑to‑average” rule  

For correlation numbers to be meaningful, the underlying data series should be **stationary around the mean**—meaning the values hover around a stable average rather than drifting away over time. Think of it like a pendulum that keeps swinging around a central point; if the pendulum gradually drifts, you can’t trust its period anymore.

Keep “stationary around the mean” in your back pocket; you’ll hear it again when we discuss the *second* pair‑trading technique later in this module.

### Putting it all together  

We now have a toolbox:

* **Spread** – daily difference, good for intraday monitoring.  
* **Differential** – absolute price gap, best for EOD checks.  
* **Ratio** – relative price, smoother visual.  
* **Divergence / Convergence** – the trade ideas based on whether the chosen metric is widening or tightening.  
* **Correlation** – the statistical test that tells us whether two stocks are even worth treating as a pair.

In the next chapter we’ll dive into *how* to calculate two flavors of correlation and then move on to setting up actual trades. For now, make sure you can recite the definitions above without looking at your phone (or at least without Googling every term while you’re on a coffee break).

> **Download the Excel sheet used in this chapter** [here](#). (Spoiler: it contains the spread, differential, and ratio calculations we just walked through.)

---

### Key takeaways from this chapter  

- **Spread** measures the *difference* between the closing values of two stocks (useful intraday).  
- **Differential** measures the *absolute* price gap (best for end‑of‑day).  
- **Ratio** is simply Stock 1 ÷ Stock 2 and often looks smoother over time.  
- **Divergence** = you expect the metric to *expand* (stocks move apart).  
- **Convergence** = you expect the metric to *contract* (stocks move together).  
- **Correlation** is the statistical “glue” (‑1 to +1) that tells you how tightly two stocks move together; keep an eye on stationarity for reliable numbers.  

Now go grab a drink, plot those charts, and get comfortable with the lingo—your future pair‑trading self will thank you. 🍻  