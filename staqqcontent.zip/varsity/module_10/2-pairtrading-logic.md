# 2. Pair‑Trading Logic  

**Source:** https://zerodha.com/varsity/chapter/pair-trading-basics/  

---  

## 2.1 – The Idea  

Picture yourself cruising down an Indian interstate. You’ve got the main carriageway where the big trucks roar by, and on either side a skinny **service road** (the “local‑express lane”) that lets you reach the little shops, farms, and that mysterious “road‑side dhaba” you never remember the name of. The two lanes run side‑by‑side for miles, mimicking each other’s ups and downs.

Now imagine the city council decides to build a brand‑new highway **and** its service road from scratch. Mid‑construction the crew spots a tiny tree sticking out of the ground on the service‑road side. Instead of chopping it down, the foreman says, “Let’s just swerve around it and then get back on track.”  

![Image](https://zerodha.com/varsity/wp-content/uploads/2017/11/M10-C2-Cartoon2.png)  

The road is finished, traffic starts flowing, and everything looks normal—except for that little detour around the tree.  

**What does that tell us?**  

- **Entities** – the main highway and the service road.  
- **Relationship** – they’re parallel; whatever the highway does (climbs a hill, dips into a valley, splashes through a river) the service road does the same, almost like a synchronized swimmer.  
- **Anomaly** – the tree forces the service road to “wiggle” for a brief moment, breaking the perfect parallelism.  
- **Effect** – the wobble is short‑lived; once the tree is past, the two lanes snap back into step.  

Sounds like a weird road‑trip metaphor, right? Stick with me. If you can picture those two almost‑identical roads and the rogue tree, you’ve just visualised the *philosophy* behind **pair trading**.

### From Roads to Stocks  

Swap the asphalt for equities. Think of two companies that are practically twins in the corporate world. In India the classic textbook example—Coca‑Cola vs. Pepsi—doesn’t trade on our exchanges, so let’s roll with **HDFC Bank** and **ICICI Bank**.

| Feature | HDFC Bank | ICICI Bank |
|---------|-----------|------------|
| Sector | Private‑sector bank | Private‑sector bank |
| Product suite | Savings, loans, credit cards, etc. | Same |
| Client base | Retail, SME, corporate | Same |
| Geographic footprint | Nationwide | Same |
| Regulatory headwinds | RBI rules, Basel norms | Same |
| Business challenges | Asset quality, digitisation, … | Same |

Because they share almost every attribute, any macro‑event that nudges one should nudge the other in the *same direction*. Example: RBI hikes repo rates → both banks see margin pressure → both stock prices dip.  

From this we can deduce:

- **Entities** – HDFC & ICICI.  
- **Relationship** – a tight, business‑environment‑driven correlation.  

And then the *obvious* (but powerful) conclusion:

- Since the businesses are twins, **their share‑price movements should be twins too**.  
- If HDFC jumps 2 % today, ICICI should also climb roughly 2 % (give or take slippage).  
- If HDFC slides 1 %, ICICI should slide similarly.  

**General rule:** When two stocks have a well‑established relationship, *ceteris paribus* (all else equal) they move together. If they diverge, you might have spotted a trading opportunity.

#### A Tiny Divergence Example  

Suppose on a Monday ICICI rallies 1.5 % on strong earnings, but HDFC barely moves (0 %). The relationship tells us HDFC *should* have risen about 1 % as well. The fact it didn’t means **ICICI is “expensive” relative to HDFC, and HDFC is “cheap.”**  

In arbitrage‑speak: **Buy the cheap stock (HDFC) and sell the expensive one (ICICI).**  

That’s the crux of *pair trading*.

### The Tree Re‑appears  

Remember that tree that forced the service road to swerve? In the stock world the “tree” is any **local event** that temporarily breaks the parallelism between two otherwise‑linked securities.

Typical culprits:

- **Earnings surprise** – HDFC releases a blockbuster quarter, causing its price to jump while ICICI lags.  
- **Management shake‑up** – The CEO of ICICI resigns; the market overreacts, pulling ICICI down more than HDFC.  
- **Speculative frenzy** – Retail traders go gaga for one bank’s stock, inflating its price relative to its twin.  

These anomalies are usually *local*: they affect only one member of the pair. The relationship itself (the “parallel rule”) stays intact; it’s just being temporarily bent.

### What Pair Traders Actually Do  

Because the relationship defines the *rules of the road*, most of the work in pair trading is about:

1. **Spotting the relationship** – finding two securities that historically move together.  
2. **Quantifying it** – measuring how tight the bond is (e.g., correlation, cointegration).  
3. **Monitoring daily** – watching the spread or ratio to see if it’s drifting.  
4. **Detecting anomalies** – spotting when the spread widens or narrows beyond its “normal” band.  

Two popular ways to do steps 2 & 3 are:

- **Price spreads / ratios** (simple subtraction or division).  
- **Linear regression** (the statistical “best‑fit line” that tells you how one price predicts the other).  

Both methods have their own quirks and will get a deeper dive later in the Varsity series.

### A Quick History Lesson (Because Who Doesn’t Love a Good Origin Story?)  

- **Early 1980s** – Morgan Stanley’s Gerry Bamberger allegedly invented the first pair trade, keeping it secret like a magician’s trick.  
- **Mid‑1980s** – Nunzio Tartaglia, also at Morgan Stanley and a Wall‑Street “quant hero,” blew the lid off the idea, making it the talk of the trading floor.  
- **Late‑1980s** – The legendary hedge fund **D. E. Shaw** adopted pair trading as a core part of its nascent quantitative arsenal.  

So the next time you hear “pair trading,” you can picture a shady 80’s trader sneaking around a tree‑filled service road with a spreadsheet in his pocket.

## 2.2 – A Few Closing Thoughts  

If you’ve been nodding along, you might think pair trading is a *market‑neutral* strategy because you’re simultaneously long **and** short. Not quite. “Market‑neutral” means you are long **and** short the **same underlying** (think a calendar spread where you buy a June contract and sell a July contract on the same futures).  

In pair trading you’re long one **stock** and short a **different** stock. The market can still move up or down; you’ll just be exposed to the *relative* move between the two.  

Hence, **don’t label pair trading as market‑neutral**. It’s better thought of as a **relative‑value** play: you profit from the *price differential* between two correlated assets.

In its purest form, a pair trade is an **arbitrage**: you buy the undervalued security and sell the overvalued one. That’s why many traders call it **Statistical Arbitrage**—the “statistics” part being the math you use to decide who’s cheap and who’s dear.

The next chapter will show you exactly how to *measure* undervaluation and overvaluation (spreads, Z‑scores, regression residuals, etc.) so you can start spotting those tree‑induced anomalies with confidence.

### Key Takeaways  

- Two companies with nearly identical business models tend to **move together** in the market.  
- Their price relationship can be expressed via **spreads, ratios, or regression coefficients**.  
- A *local event* that hits only one of the pair creates a **temporary anomaly**.  
- When the anomaly widens beyond its historical norm, a **trade opportunity** appears.  
- Pair trading = **Buy the cheap stock, sell the expensive stock** (relative‑value or statistical arbitrage).  
- It is **not** a market‑neutral strategy in the strict sense; it’s a bet on **relative** price movements.  

Now go grab a coffee, picture that tree, and get ready to hunt for those mis‑aligned pairs! 🚗💨📈  