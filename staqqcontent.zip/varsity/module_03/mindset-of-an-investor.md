# 2. Mindset of an Investor  

**Source:** https://zerodha.com/varsity/chapter/mindset-investor/  

---  

## 2.1 – Speculator vs Trader vs Investor  

How you want to play the market determines whether you’ll be a **speculator**, a **trader**, or an **investor**.  They’re not interchangeable – each label comes with its own set of expectations, risk‑tolerance, and, most importantly, impact on your P&L.  Getting crystal‑clear on which hat you’re wearing saves you from later‑night panic attacks when the market does its usual “let‑me‑confuse‑you‑again” trick.  

Below is a little dramatization to help you spot the differences.  Think of it as a sitcom episode starring three very different characters.

### The set‑up  

The RBI is about to meet in two days to announce the next monetary‑policy decision.  Inflation has been as sticky as a bad haircut, and the central bank has already hiked rates in the last **four** policy meetings.  Higher rates usually mean corporates have to pay more to borrow, which squeezes earnings.  

Enter three market participants: **Sunil**, **Tarun**, and **Girish**.  They all hear the same news, but each reacts as if the script were written for a different genre.  

*(A quick disclaimer: I’ll dip my toe into options here just for illustration.  We’ll dive deeper into derivatives later, so no need to panic if you’re not a “Greek‑guru” yet.)*  

---

### Sunil – The “I‑know‑what‑the‑RBI‑will‑do” Speculator  

| Sunil’s mental checklist | What he actually does |
|---|---|
| **Rates are sky‑high** – “Too high to stay that way forever.” | ✅ |
| **High rates = corporate slowdown** – “Earnings will get a nose‑bleed.” | ✅ |
| **RBI can’t keep breaking records** – “They’ll have to pause or cut soon.” | ✅ |
| **TV analysts nod along** – “Hey, I’m not the only lunatic.” | ✅ |
| **Conclusion** – “Markets will rally once the cut is announced.” | ✅ |
| **Action** – Buys **SBI call options** (because why not bet on a bounce?). | ✅ |

Sunil is basically shouting, “I’ve read the tea leaves, the RBI is about to cut rates, so I’m buying a ticket to the moon!”  He’s got *confidence* – the kind that makes you think you can predict the weather on Mars.  In reality, central banks are about as predictable as a cat on a hot tin roof, so Sunil’s bet is pure **speculation** – a gamble based on faith rather than a repeatable edge.  

---

### Tarun – The “Vol‑Play” Trader  

| Tarun’s mental checklist | What he actually does |
|---|---|
| **RBI’s next move?** – “That’s a crystal‑ball question. Let’s not answer.” | ✅ |
| **Current volatility = high** – “Option premiums are inflated like a hot‑air balloon.” | ✅ |
| **History lesson:** Back‑testing shows volatility usually *drops* sharply right after an RBI announcement. | ✅ |
| **Conclusion** – “I’ll sell premium now, buy it back when the dust settles.” | ✅ |
| **Action** – Sells **5 lots of Nifty call options** and plans to square‑off around the announcement. | ✅ |

Tarun isn’t trying to guess the policy direction; he’s simply exploiting a *price* inefficiency.  He’s built a **trading plan** based on statistical evidence (the volatility drop).  That’s the hallmark of a **trader**: a systematic approach, not a wishful‑thinking prophecy.  

---

### Girish – The “Let‑It‑Ride” Investor  

| Girish’s mental checklist | What he actually does |
|---|---|
| **Portfolio:** 12 stocks held for **2+ years**. | ✅ |
| **RBI news?** – “Just another blip; I’m not losing sleep over it.” | ✅ |
| **Time horizon:** Long‑term, so short‑run noise is irrelevant. | ✅ |
| **If the market overreacts?** – “I’ll buy more at the discount.” | ✅ |
| **Action** – Mostly **does nothing**, but keeps cash handy for opportunistic buying. | ✅ |

Girish treats the RBI announcement like a passing cloud – it might shade the market for a day, but his horizon spans years, not minutes.  He’s the classic **investor**: patient, focused on fundamentals, and ready to add to positions when sentiment drives prices below intrinsic value.  

---

#### Bottom line of the sketch  

* **Sunil** = **Speculator** – high conviction, low analysis, betting on a single outcome.  
* **Tarun** = **Trader** – systematic, volatility‑focused, trades the *price* of risk, not the *direction* of the market.  
* **Girish** = **Investor** – long‑term, fundamentals‑driven, comfortable with short‑term noise.  

The story isn’t about who wins or loses (though you can imagine a dramatic “who gets the last slice of pizza” finale).  It’s about recognizing the **mindset** that drives each market participant’s actions.  

---

## 2.2 – The Compounding Effect  

Why does Girish stay planted while Sunil and Tarun are busy shouting at the market?  Because **compounding** is the silent superhero that turns modest returns into a fortune over time.  

### A quick math‑demo (with a dash of drama)  

*You start with* **₹100** *and expect a 20 % annual return (CAGR).*  

| Year | Balance if you **re‑invest** the profit | Balance if you **withdraw** the profit |
|---|---|---|
| 0 (start) | ₹100 | ₹100 |
| 1 | ₹120 (₹100 × 1.20) | ₹120 (you take out ₹20) |
| 2 | ₹144 (₹120 × 1.20) | ₹140 (₹120 + ₹20) |
| 3 | **₹173.28** (₹144 × 1.20) | **₹160** (₹140 + ₹20) |

After three years, **re‑investing** gives you **₹173.28**, a **₹13.28** (≈21.7 %) *extra* compared to the *₹160* you’d have if you kept pocketing the ₹20 each year.  That extra chunk is the **compounding effect** – earnings on earnings, not just earnings on your original capital.  

### The visual proof  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M3-Ch2-Chart1.jpg)  

The graph shows a ₹100 seed growing at 20 % per year for ten years.  The first six years take you from ₹100 to ₹300 (a 200 % increase).  The **next ₹300** is generated **in just four years** (years 7‑10).  The longer you let the money stay in the market, the *faster* it accelerates – a phenomenon sometimes called the “**snowball effect**.”  

That’s exactly why Girish loves the “luxury of time.”  He isn’t looking for a quick buck; he’s letting his capital **snowball** while the market does its thing.  

**Takeaway:** If you have a decent, repeatable edge (say, a 12‑15 % annual CAGR), the *only* thing you can do to boost absolute returns is **stay invested** and let compounding do the heavy lifting.  

---

## 2.3 – Does “Invest” Actually Work?  

Think of a sapling.  Give it water, fertilizer, and a little sunlight, and it will eventually become a towering tree.  The same principle applies to a **good business**:  

* **Strong sales** → cash flow  
* **Healthy margins** → profitability  
* **Innovative products** → competitive moat  
* **Ethical management** → sustainability  

When these ingredients line up, the share price **tends** to rise—sometimes slowly (remember the Eicher Motors lag you saw earlier) and sometimes quickly.  History is littered with examples where quality companies *always* outperformed the market over long horizons, across continents and eras.  

The catch? Short‑term volatility can feel like a roller‑coaster that makes you want to scream.  An investor must develop the **appetite** to swallow those dips, because the underlying business fundamentals keep pulling the price upward in the long run.  

---

## 2.4 – Investable‑Grade Attributes – What’s the Checklist?  

In the previous chapter we brushed on what makes a company “investable.”  Let’s dive deeper, because a **fundamental analysis** is a two‑sided coin: **Qualitative** *and* **Quantitative**.  (If you’re like me, you give the qualitative side a smidge more love, because numbers can lie if you ignore the story behind them.)  

### The Qualitative Side – The “Non‑Numeric” Detective Work  

| Area | What to look for (and why it matters) |
|---|---|
| **Management background** | Education, track‑record, any criminal cases?  A captain who can’t steer the ship is a red flag. |
| **Business ethics** | Scams, bribery, or shady deals?  Unethical practices can bite you later. |
| **Corporate governance** | Board composition, transparency, audit quality – good governance = lower agency risk. |
| **Minority‑shareholder treatment** | Do they protect minority rights or steamroll them?  Fair treatment signals confidence. |
| **Insider share transactions** | Are promoters buying (a vote of confidence) or selling heavily (possible trouble)? |
| **Related‑party transactions** | Favoritism or “pay‑to‑play” deals can erode shareholder value. |
| **Promoter salaries** | Excessive pay cuts into profits; check if it’s a reasonable percentage. |
| **Unusual stock‑price moves around promoter trades** | Could hint at insider information or market manipulation. |
| **Shareholder structure** | Concentrated ownership may be good (aligned interests) or bad (control risk). |
| **Political affiliations** | Over‑reliance on a party can make the firm vulnerable to regime change. |
| **Promoter lifestyle** | Flashy lifestyles sometimes mask cash‑flow problems; ask “where does the money come from?” |

If any of these boxes raise a **red flag**, even a company with stellar margins may be a **time bomb**.  Markets eventually price in governance failures, and the stock can take a nosedive.  

**How to uncover these?**  
Read the annual report, watch earnings calls, skim reputable news, and, if you’re feeling adventurous, browse the Ministry of Corporate Affairs filings.  It’s a bit of detective work, but the payoff is worth the extra caffeine.  

### The Quantitative Side – The Numbers Playground  

Quantitative analysis is the **hard‑core math** that backs up (or contradicts) your qualitative impressions.  Some metrics are straightforward, others need a little elbow grease.  

| Core metrics (applicable to *most* firms) | Why they matter |
|---|---|
| **Revenue & growth** | Top‑line health – are sales expanding? |
| **Profitability (EBIT, net profit) & margins** | How efficiently does the firm turn revenue into profit? |
| **Earnings per Share (EPS) & EPS growth** | Direct impact on shareholder value. |
| **Expense trends** | Rising costs can erode margins; watch for economies of scale. |
| **Operating efficiency (ROCE, ROE)** | Capital usage efficiency. |
| **Pricing power** | Ability to raise prices without losing customers. |
| **Tax burden** | High effective tax rates can choke cash flow. |
| **Dividend payout ratio** | Signal of cash generation and management confidence. |
| **Cash‑flow from operations** | The real money‑making engine (vs. accounting profit). |
| **Debt profile (short‑term & long‑term)** | Leverage risk; watch interest coverage. |
| **Working‑capital management** | Liquidity health – inventory days, receivables, payables. |
| **Asset growth & capex** | Investment in future growth vs. maintenance. |
| **Investment returns (IRR, NPV of projects)** | Whether the firm is allocating capital wisely. |
| **Financial ratios (P/E, P/BV, EV/EBITDA, etc.)** | Relative valuation against peers. |

Each **sector** adds its own flavor of metrics.  For instance:  

*Retail*: Store count, sales per sq. ft., franchise‑vs‑company‑owned ratio.  
*Oil & Gas*: Oil‑to‑gas revenue split, exploration cost per barrel, proven‑reserves growth.  

We’ll spend the next few chapters learning to **read financial statements** (Balance Sheet, P&L, Cash‑Flow) because they’re the primary source for all the quantitative goodies.  

---

### Key Takeaways from This Chapter  

- **Speculators, traders, and investors wear different hats** – know which one you’re putting on.  
- **Investors need an investment mindset**: long‑term, fundamentals‑first, patience‑driven.  
- **Compounding is the magic that turns a modest CAGR into a fortune** – the longer you stay, the faster the money doubles.  
- **Time is the market’s most generous luxury**; use it wisely.  
- **Every company must be assessed on two pillars**:  
  - **Qualitative** – the story, governance, ethics, and people behind the numbers.  
  - **Quantitative** – the hard data you extract from financial statements.  
- **Qualitative factors are subtle** but can make or break a business; dig into annual reports, news, and management interviews.  
- **Quantitative analysis provides the numeric backbone**; learn to compute and interpret the key ratios and growth metrics.  

In short, if you want to be the **Girish** of your own portfolio, grab a coffee, read the footnotes, let your money sit for a while, and enjoy the slow‑burn joy of compounding.  The market will throw you a few curveballs, but with the right mindset you’ll be the one laughing at the end of the episode. 🍻