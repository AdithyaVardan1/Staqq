# 15. Equity Research (Part 2)

**Source:** https://zerodha.com/varsity/chapter/equity-research-part-2/

---  

## 15.1 – Getting started with the DCF Analysis  

In the last chapter we fell head‑first into **Net Present Value (NPV)** – the wizardry that lets us turn future money into today’s dollars. NPV is the beating heart of a **Discounted Cash Flow (DCF)** model, and now that you’ve got the pulse, it’s time to add a few more organs.  

We’ll walk through the whole shebang by building a DCF for **Amara Raja Batteries Limited (ARBL)**. That will wrap up the third stage of equity research – *the Valuation*.  

Remember the pizza‑machine example? We imagined the cash that the machine would throw our way in the years to come, discounted each slice back to the present, and added them up to get the NPV. At the end we asked, “What if that pizza‑machine were actually a share of a company?” The answer is simple: if we can forecast the company’s future cash streams, we can price the share the same way.  

But **which cash flow** are we talking about? And **how on earth do we project it** for a real‑world firm?  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/12/M3-Ch15-title1.jpg)  

---  

## 15.1 – The Free Cash Flow (FCF)  

The DCF model lives off **Free Cash Flow (FCF)** – the cash a business has left over after it pays the bills *and* pays for the stuff it needs to stay in business (land, factories, machines, the occasional coffee machine). In other words, FCF is the cash that finally makes its way to the shareholders after the company has taken care of all its capital‑expenditure cravings.  

A healthy firm is one that can consistently generate a healthy FCF. Investors sniff out companies with **high or rising free cash flow** because, like a good wine, they expect the share price to eventually catch up to the cash reality.  

> **Bottom line:** FCF tells you whether a firm truly *earned* cash in a given year, not just accounting profit. So always glance at FCF alongside earnings when you’re sizing up a company’s financial fitness.  

### How to compute FCF  

The formula is delightfully simple:  

\[
\text{FCF} = \text{Cash from Operating Activities} \;-\; \text{Capital Expenditures}
\]

Let’s roll up our sleeves and compute ARBL’s FCF for the last three financial years. Grab the FY‑14 annual report snapshot below:  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/12/M3-ch15-chart1.jpg)  

*Note:* The **Net cash from operating activities** is already net of income tax (highlighted in green). The **Capital expenditures** appear in red.  

> **You might be thinking:** “Why bother calculating historical FCF when we ultimately need *future* FCF?”  
>   
> Good question! The industry standard is to **anchor future projections to historical averages**. By understanding what the company has actually generated, we can grow that baseline forward at a sensible rate.  

### Step‑by‑step: From historic to forward‑looking FCF  

**Step 1 – Estimate the average free cash flow**  
Take the last three years (209.7 Cr, 262.99 Cr, –51.6 Cr) and average them:  

\[
\frac{209.7 + 262.99 + (-51.6)}{3} = \mathbf{Rs.\,140.36\;Cr}
\]

Why average? It smooths out outliers (that nasty negative year) and respects the business’s cyclical nature.  

**Step 2 – Pick a growth rate**  
We like to be **conservative** (the same way we’re conservative about drinking the last drop of whiskey). I split the forecast into two 5‑year blocks:  

* Years 1‑5: **18 %** annual growth  
* Years 6‑10: **10 %** annual growth  

If the firm were a mature large‑cap, I’d dial it down to 15 % then 10 %. The idea is to avoid “growth‑inflation”.  

**Step 3 – Project the cash flows**  

| Year | Calculation | FCF (Rs. Cr) |
|------|-------------|--------------|
| 0 (base) | 140.36 | 140.36 |
| 1 | 140.36 × (1 + 0.18) | 165.62 |
| 2 | 165.62 × (1 + 0.18) | 195.43 |
| 3 | 195.43 × (1 + 0.18) | 230.61 |
| 4 | 230.61 × (1 + 0.18) | 272.12 |
| 5 | 272.12 × (1 + 0.18) | 321.10 |
| 6 | 321.10 × (1 + 0.10) | 353.21 |
| 7 | 353.21 × (1 + 0.10) | 388.53 |
| 8 | 388.53 × (1 + 0.10) | 427.38 |
| 9 | 427.38 × (1 + 0.10) | 470.12 |
| 10| 470.12 × (1 + 0.10) | 517.13 |

(Values rounded to two decimals.)  

These are **estimates**, not crystal‑ball predictions. The art of valuation lies in keeping the growth assumptions modest, which is why we stuck with 18 % and 10 % – numbers that are generous yet believable for a well‑run, expanding battery maker.  

---  

## 15.2 – The Terminal Value  

We’ve projected free cash flow for ten years, but what happens after year 10? Does the company magically disappear like your Wi‑Fi when you step outside the house? Nope – a business is assumed to be a **going concern**, i.e., it will keep churning cash forever (or at least until the sun burns out).  

Beyond the explicit forecast horizon, cash flow growth slows down to a **Terminal Growth Rate** (TGR). In practice, analysts keep TGR **below 5 %**; I personally stick to a **3‑4 %** band and never venture higher.  

### Calculating Terminal Value (TV)  

The **Terminal Value** is the present value of **all cash flows from year 11 to infinity**. The formula looks like a superhero’s secret identity:  

\[
\text{TV} = \frac{\text{FCF}_{10} \times (1 + \text{TGR})}{\text{Discount Rate} - \text{TGR}}
\]

Where **FCF₁₀** is the cash flow in the 10th year (our last explicit projection).  

Plugging in ARBL numbers (FCF₁₀ = 517.12 Cr, Discount Rate = 9 %, TGR = 3.5 %):  

\[
\text{TV} = \frac{517.12 \times (1 + 0.035)}{0.09 - 0.035}
          = \frac{517.12 \times 1.035}{0.055}
          \approx \mathbf{Rs.\,9,731.25\;Cr}
\]

That’s the “forever‑value” of ARBL after the ten‑year runway.  

---  

## 15.3 – The Net Present Value (NPV)  

Now we have two ingredients:  

1. **Projected cash flows for years 1‑10**  
2. **Terminal Value (the infinite tail)**  

The next step is to **discount** each of these back to today’s rupees using our chosen discount rate (9 %). The discounted numbers are the **Present Values (PV)**.  

### Discounting the 10‑year cash stream  

\[
\text{PV}_{t} = \frac{\text{FCF}_{t}}{(1 + r)^{t}}
\]

A quick example for Year 2 (which is FY 2015‑16, i.e., two years out):  

\[
\text{PV}_{2} = \frac{195.29}{(1 + 0.09)^{2}} = \mathbf{Rs.\,164.37\;Cr}
\]

Do this for each year and sum them up – you’ll get a total **PV of the forecast cash flows**:  

\[
\text{PV}_{\text{10‑yr}} = \mathbf{Rs.\,1,968.14\;Cr}
\]

### Discounting the Terminal Value  

\[
\text{PV}_{\text{TV}} = \frac{9,731.25}{(1 + 0.09)^{10}}
                     = \mathbf{Rs.\,4,110.69\;Cr}
\]

### Adding them together – the **NPV**  

\[
\text{NPV} = \text{PV}_{\text{10‑yr}} + \text{PV}_{\text{TV}}
          = 1,968.14 + 4,110.69
          = \mathbf{Rs.\,6,078.83\;Cr}
\]

Interpretation: If you sat on today’s sofa with a crystal ball, you’d expect ARBL to generate **Rs 6,078.83 Cr** of free cash over the rest of its life, all of which belongs to the shareholders.  

---  

## 15.4 – The Share Price  

We’ve got a **total firm value** (the NPV). To turn that into a **per‑share price**, we need two more ingredients:  

1. **Net Debt** (debt minus cash) from the balance sheet  
2. **Number of shares outstanding**  

### Net Debt  

\[
\text{Net Debt} = \text{Total Debt} - \text{Cash\&Cash Equivalents}
\]

ARBL’s FY‑14 balance sheet shows:  

* Total Debt = Rs 75.94 Cr  
* Cash = Rs 294.5 Cr  

\[
\text{Net Debt} = 75.94 - 294.5 = \mathbf{-Rs.\,218.6\;Cr}
\]

A negative net debt means the company is **net cash‑rich** – a nice cushion you add to the firm value.  

### Adjusted firm value  

\[
\text{Adjusted Value} = 6,078.83 - (-218.6) = 6,297.43\; \text{Cr}
\]

### Per‑share intrinsic value  

Outstanding shares = 17.081 Cr  

\[
\text{Intrinsic Share Price} = \frac{6,297.43}{17.081}
                            \approx \mathbf{Rs.\,368\;per\;share}
\]

That’s the **DCF‑derived fair price** for ARBL.  

---  

## 15.5 – Modeling Error & the Intrinsic‑Value Band  

Even the best‑crafted DCF is a **model**, not a prophecy. Every assumption (growth rates, discount rate, terminal growth) injects a little uncertainty. Think of it as the “margin of error” you give yourself when you guess the weight of a watermelon without a scale.  

A pragmatic way to handle this is to create a **±10 % band** around the intrinsic price.  

* **Lower bound:** 368 × (1 – 0.10) = **Rs 331**  
* **Upper bound:** 368 × (1 + 0.10) = **Rs 405**  

So instead of saying “ARBL is worth exactly Rs 368”, we say **“the fair‑value range is Rs 331‑Rs 405”**.  

### How to use the band  

| Market price vs. band | Interpretation | Action |
|-----------------------|----------------|--------|
| **Below Rs 331** | Undervalued | Consider buying |
| **Between Rs 331‑Rs 405** | Fairly valued | Hold (no fresh buy) |
| **Above Rs 405** | Overvalued | Take profits or stay out |

#### Real‑world check (2 Dec 2014)  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/12/M3-ch15-chart2.jpg)  

The stock was trading at **Rs 726.70** – way above the upper band. Buying at that price would have been like paying premium for a used car that still has the original paint.  

---  

## 15.6 – Spotting Buying Opportunities  

Think of **long‑term investing** as a slow, scenic train ride, while **active trading** is a high‑speed bullet train that darts in and out of stations. When a genuine value gap appears, it lingers like a gentle hill on the long‑term route – it doesn’t vanish instantly.  

Back in 2013, ARBL’s intrinsic‑value band (Rs 331‑Rs 405) comfortably encompassed the market price for about **five months**. If you had bought any time during that window and held on, the returns would have rolled in nicely.  

That’s why folks say **“bear markets create value.”** In 2013 the market was bearish, giving disciplined investors a chance to scoop up quality stocks at discounts.  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/12/M3-ch15-chart31.jpg)  

The blue highlight on the chart shows the sweet spot where ARBL was trading inside the intrinsic‑value band.  

---  

## 15.7 – Conclusion  

Over the last three chapters we’ve marched through the three pillars of equity research:  

| Stage | What we did |
|-------|-------------|
| **Stage 1 – Qualitative** | Dug into the **who, what, when, how, and why** of the business. If the story didn’t vibe, we stopped. |
| **Stage 2 – Checklist** | Ran a **quantitative health‑check** (the checklist you built or borrowed). Only firms that passed both the narrative and the numbers moved forward. |
| **Stage 3 – Valuation** | Applied the **DCF** to derive an intrinsic price, compared it to market price, and decided whether to buy, hold, or avoid. |

When a stock clears all three stages and the intrinsic‑value band looks inviting, you have the **conviction** to own it. Then sit tight, ignore the daily noise (the market’s version of background music), and let compounding do the heavy lifting.  

> **Pro tip:** I’ve attached the Excel DCF model I built for ARBL. Feel free to download it, plug in the numbers for your own favorite company, and start playing “valuation‑Jenga”.  

---  

### Key Takeaways  

- **Free Cash Flow (FCF)** = Cash from Operations – Capital Expenditures.  
- FCF reveals the cash that actually reaches investors after all spending.  
- The most recent year’s FCF serves as the base for projecting future cash flows.  
- Use **conservative** growth rates (e.g., 18 % → 10 % for a 10‑year horizon).  
- **Terminal Growth Rate** is the modest, long‑run growth assumed after the explicit forecast (usually 3‑4 %).  
- **Terminal Value** = FCF₁₀ × (1 + TGR) ÷ (Discount – TGR); it captures cash to infinity.  
- Discount all cash flows (including TV) back to today using the discount rate to get **NPV**.  
- Adjust NPV for **Net Debt** (debt – cash) and divide by shares outstanding to obtain the **per‑share intrinsic value**.  
- Add a **±10 % band** around the intrinsic price to accommodate modelling errors → the **intrinsic‑value band**.  
- Stock **below** the lower band → potential buy; **within** the band → fair value; **above** the upper band → likely overvalued.  
- Long‑term wealth is built by patiently holding **undervalued** stocks.  
- The DCF framework equips you to judge whether a stock’s current market price is justified.  

Happy modeling, and may your future cash flows always be free (and plentiful)!  