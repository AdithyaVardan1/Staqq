# Junior  

**Source:** https://zerodha.com/varsity/chapter/episode-1-ideas-by-the-lake/  

*(Yep, that’s the exact URL—no typo, no secret discount code hidden in there. If you’re looking for a treasure map, you’ll be disappointed, but you’ll get solid stock‑market basics instead.)*  

**Watch it while sipping your favorite brew:** https://www.youtube.com/watch?v=9155SZc96kk  

*(Pro tip: pause whenever the presenter mentions “lake” and picture a rubber ducky doing day‑trading. It makes the concepts stick better. 🦆💹)*  