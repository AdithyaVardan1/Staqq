# 13. Equity Research (Part 1)

**Source:** https://zerodha.com/varsity/chapter/equity-research-part-1/

---  

## 13.1 – What to expect?

Alright, strap on your detective hat – we’ve already set the stage in the previous chapter, and now it’s time to roll up our sleeves and build a **“limited‑resource” equity‑research playbook**.  

Why *limited*? Because, as a retail investor, your toolbox usually looks like:

| Retail‑investor toolkit | Institutional‑investor toolkit |
|------------------------|--------------------------------|
| 🌐 Internet (Google, YouTube, Reddit) | 👩‍💼 Dedicated analyst teams |
| 📄 Company annual reports (PDFs) | 📊 Bloomberg, Reuters, FactSet, etc. |
| 📊 MS Excel (or Google Sheets) | 🗂️ Industry research reports, management meetings |

You don’t have a private‑equity‑firm‑size data warehouse, but you do have a laptop, a bit of curiosity, and the internet—enough to become a competent Sherlock of the stock market. The endgame? **Deciding whether to buy the stock or not** (yes, we’re still keeping it simple).

Just like a good three‑course meal, we’ll chew through the equity‑research process in **three stages**:

1. **Understanding the Business** – the appetizer; get a feel for what the company actually does.
2. **Application of the Checklist** – the main course; crunch the numbers and see if the business backs up its story.
3. **Intrinsic‑Value Estimation (Valuation)** – dessert; figure out if the price is tasty enough to bite into.

Each stage contains several sub‑steps, and **there are no shortcuts**. Skipping a step is like ordering a steak without checking if it’s cooked – you might end up with a nasty surprise.  

---

## 13.2 – Stock Price vs Business Fundamentals

When you first pick a stock, the reflex for many is to stare at the price chart like it’s a magic eight‑ball. That works if you’re a day‑trader looking for a quick fling, but for **long‑term investing**, you need to fall in love with the *business* first.

**Why?** Simple math: the more you know a company, the higher your conviction to hold it through the inevitable roller‑coaster rides (aka bear markets). Remember, **bear markets move prices, not fundamentals**. If you truly understand why a business is solid, you’ll be able to explain to yourself (and maybe to a skeptical friend at the bar) why you’re *not* selling when everyone else is freaking out.

Think of it this way: bear markets are like **discount seasons** for the wise shopper. If you love the product, you buy more when the price drops. If you’re convinced the company is a good one, a market dip is a buying opportunity, not a panic button.

The **best intel** on a company’s business comes from:

* The company’s own website (product pages, investor presentations, press releases).  
* The **annual report** – especially the last **five years** to see how the firm has weathered past cycles.

Grab those PDFs, pour yourself a coffee, and start reading. (Pro tip: use “Ctrl+F” to hunt for keywords like “segment”, “risk”, “growth”.)

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/12/M3-Ch13-title.jpg)

---

## 13.3 – Understanding the Business

**Step 1:** Write down a list of questions. Think of yourself as a journalist on a deadline, and the annual report is your source material. The answers are all in there – you just have to hunt them down.

Below is a **starter pack of questions** (feel free to add your own spicy ones). After each question, I’ll sprinkle a quick “why we care” note.

| Question | Why it matters |
|----------|----------------|
| **What does the company actually sell?** | Avoid buying a “mystery box” stock. |
| **Who are its main customers and how sticky are they?** | High‑margin, recurring revenue = happy investors. |
| **What is the competitive landscape?** | Is the company a market leader, a niche player, or a copycat? |
| **How does it make money (revenue streams, pricing power)?** | Understanding cash‑cow vs. cash‑leak. |
| **What are the key risks listed in the MD&A?** | Red flags often hide in the footnotes. |
| **How has the business evolved over the past 5‑years?** | Look for growth, pivots, or stagnation. |
| **What are the major capital expenditures (CapEx) and why?** | Are they investing to grow or just patching holes? |
| **Who runs the show (management pedigree)?** | Bad CEOs are like bad bartenders – they ruin the experience. |
| **What is the company’s ESG (environmental, social, governance) stance?** | Increasingly, ESG impacts valuation. |
| **How does the firm handle debt and liquidity?** | Debt is fine, but only if you can pay the interest. |

These questions are **thought‑starters**. As you dig into the report, you’ll uncover new details that spark fresh queries. That’s the beauty of the Q&A method: the deeper you go, the richer your mental model becomes.

> **Pro tip:** If you hit a *red flag* (e.g., a shady related‑party transaction, an unexplained dip in cash flow), **stop right there**. No amount of shiny growth numbers can justify a fundamentally broken business.

From my own experience, **Stage 1 (Understanding the Business)** typically gobbles up **about 15 hours** of reading, note‑taking, and coffee‑refilling. Once you finish, **condense your findings onto a single sheet** (think of it as a cheat‑sheet for the next steps). If you can’t summarise it succinctly, you probably haven’t grasped the company fully.

When you’ve nailed Stage 1, you move to **Stage 2 – Application of the Checklist**. The stages are sequential, like a Netflix series – you don’t skip the middle episode and expect the plot to make sense.

> **Side note:** Throughout the rest of this chapter we’ll illustrate the checklist on **Amara Raja Batteries Limited (ARBL)**. The numbers belong to ARBL, but the framework works for any ticker you fancy.

---

## 13.4 – Application of the Checklist

Stage 1 gave us the “who, what, where, why” of the business. Now we need to ask **“how good are the numbers?”** – the classic “proof of the pudding” test. Even the most exciting business will look dull if the financials scream *danger*.

Below is the **checklist** we introduced in the previous chapter (quick reference for the lazy among us). We’ll run each item through ARBL’s data, but you can plug in any company’s numbers.

### 1. Revenue & PAT Growth

Growth is the lifeblood of any investable company. We look at two perspectives:

| Perspective | What it tells you |
|-------------|-------------------|
| **Year‑on‑Year (YoY) growth** | Short‑term momentum; watch out for industry‑wide cycles. |
| **Compounded Annual Growth Rate (CAGR)** | Long‑term trend across business cycles. A healthy CAGR usually signals a resilient business. |

> **My rule of thumb:** I’m comfortable with **≥ 15 % CAGR** on both revenue and PAT (profit after tax). Anything lower, I investigate the slowdown.

**ARBL numbers:**  
*5‑year revenue CAGR = **18.6 %**.*  
*5‑year PAT CAGR = **17.01 %**.*  

Both comfortably beat the 15 % threshold – a promising sign, but we still have to vet the rest of the checklist.

### 2. Earnings Per Share (EPS)

EPS is profit on a per‑share basis. If **EPS** grows at roughly the same pace as **PAT**, it means the company isn’t *diluting* shareholders by issuing a flood of new shares.

**ARBL EPS CAGR (FY 14‑FY 18)** = **1.90 %**.  
A modest rise – not spectacular, but at least it’s not shrinking, indicating limited dilution.

### 3. Gross‑Profit Margin (GPM)

> **Formula:** `Gross Profit / Net Sales`  

*Gross Profit = Net Sales – Cost of Goods Sold (COGS).*

A healthy GPM signals **pricing power** or **operational efficiency**.

**ARBL’s GPM:** consistently **> 20 %** (the checklist minimum).  
What does that imply?

* The firm likely enjoys a **premium position** – maybe few rivals or a differentiated product.  
* Management seems to be **running a lean operation**, keeping COGS under control.

### 4. Debt Level – Balance‑Sheet Check

High debt equals high leverage, which can turn a growth story into a **financial horror** if earnings wobble. We look at two things:

1. **Absolute debt** (in INR crores).  
2. **Debt/EBIT ratio** – a quick gauge of how many earnings it takes to cover debt.

**ARBL debt:** hovering around **₹85 cr** (stable and actually lower than FY 09‑10).  
**Debt/EBIT:** has been **declining**, indicating improving leverage.

Bottom line: ARBL is **managing its borrowings responsibly**.

### 5. Inventory Check (Manufacturing‑Only)

Inventory turns into cash when you sell it, so we monitor:

* **Inventory days** – how long items sit on the shelves.  
* **Inventory growth vs. PAT growth** – a rising inventory with stagnant profit may hint at over‑stocking.

**ARBL:** inventory days are **stable, slightly decreasing**. Both inventory and PAT are growing together – a healthy sign of operational sync.

### 6. Sales vs. Receivables

If sales are ballooning but receivables (money owed by customers) are also ballooning, you might be **selling on credit** without getting cash – a red flag.

**ARBL:** Receivables as a % of net sales **decline** over the period, suggesting the firm is **collecting cash efficiently**. Good news for cash flow.

### 7. Cash Flow from Operations (CFO)

CFO is the **real‑world proof** that the business generates cash, not just accounting profit.

**ARBL’s CFO:** a bit volatile but **positive for each of the last five years**. Even a shaky CFO is better than a negative one; it means the core business isn’t burning cash.

### 8. Return on Equity (ROE)

ROE measures how well a company turns shareholders’ equity into profit. High ROE (> 20 %) often indicates **strong management** and **efficient capital use**.

**ARBL’s ROE** over the last five years: **well above 20 %** each year. Coupled with low debt, these numbers look **extraordinary**.

---

## Conclusion

We’ve just breezed through **Stage 2** of the equity‑research workflow, using ARBL as our test subject. The company **checks almost every box** on the checklist, which is a strong green light *provided* the business fundamentals (Stage 1) also hold up.

**But** – before you throw cash at ARBL (or any stock), you still have **Stage 3**: **valuation**. That’s where you compare the *intrinsic* value you compute with the *market* price. If the price is sufficiently discounted, you have a potential winner; if it’s overpriced, you walk away.

---

### Key takeaways from this chapter

- **Limited‑resource equity research** can be done in three sequential stages:  
  1. **Understanding the Business**  
  2. **Application of the Checklist**  
  3. **Valuations (Intrinsic‑value estimation)**
- **Stage 1** is all about gathering information – the Q&A method (asking simple, direct questions) is a proven way to extract everything you need from annual reports and the company website.
- If you hit a **red flag** while answering Stage 1 questions, **stop** – don’t waste time on a potentially toxic company.
- By the end of Stage 1 you should be able to **summarise the entire business on a single sheet**; if you can’t, you probably haven’t dug deep enough.
- Most of the answers for Stage 1 live in the **annual report and the corporate website** – no fancy Bloomberg terminal required.
- Conviction built in Stage 1 is what helps you **stay calm during bear markets**; you’ll know why you’re not selling when everyone else is panicking.
- **Stage 2** tests whether the numbers back up the story. You evaluate revenue/PAT growth, EPS, gross‑profit margins, debt, inventory, receivables, operating cash flow, and ROE.
- Only after a company **passes both Stage 1 and Stage 2** do you move to **Stage 3**, where you decide if the **price is right**.
- Remember the checklist items (re‑listed for quick reference):
  * Revenue & PAT growth (YoY & CAGR)  
  * EPS growth (avoid dilution)  
  * Gross‑profit margin ≥ 20 %  
  * Manageable debt (stable/declining Debt/EBIT)  
  * Reasonable inventory days (and inventory‑PAT sync)  
  * Receivables % of sales trending down  
  * Positive, preferably stable, operating cash flow  
  * ROE > 20 % (without excessive leverage)

Follow these steps, keep a sense of humor, and you’ll turn those limited resources into a **powerful research engine** that even the Wall Street pros would tip their hats to. Happy hunting! 🚀