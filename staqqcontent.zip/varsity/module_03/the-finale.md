# 16. The Finale  

**Source:** https://zerodha.com/varsity/chapter/finale/  

---  

##  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/12/M3-Ch16-title.jpg)  

## 16.1 – The Follies of DCF Analysis  

Alright, strap in – we’ve just survived the wild ride of Discounted Cash‑Flow (DCF) modelling, the financial equivalent of trying to predict the weather a decade from now while standing on a rocking boat. The DCF is the gold‑standard for estimating a stock’s intrinsic value, but like any shiny tool, it has its quirks. The model only works as well as the guesses (a.k.a. assumptions) you feed it. Slip up on those, and you’ll end up with a “fair” value that’s about as reliable as a horoscope.  

**Why DCF can feel like a bad first date:**  

- **Forecast‑or‑fortune‑telling required** – You have to project future cash flows and business cycles. Even the CEO’s crystal ball would have a hard time here, let alone a regular analyst who’s still learning to read the income statement.  
- **Terminal growth rate = the butterfly effect** – A teeny‑tiny tweak in the terminal growth rate blows up the final per‑share value. In our ARBL example, a 3.5 % terminal growth gave a price of **₹368**. Bump it up just 0.5 % (that’s 50 basis points) to **4.0 %** and the model shouts **₹394**. That’s a ₹26 swing for a whisper of a change.  
- **Constant babysitting** – Once you’ve built the spreadsheet, you can’t set it and forget it. Every quarterly or annual update means you have to revisit the inputs and assumptions, or else your valuation will drift faster than a drunk sailor.  
- **Long‑term tunnel vision** – DCF is built for the marathon, not the sprint. If you’re looking to flip a stock in a year, the model will give you about as much guidance as a fortune cookie.  

All this rigidity can make you blind to off‑the‑radar opportunities that don’t fit the neat boxes of the model.  

### How to Tame the Beast  

The antidote? Play it **conservatively**. Here are my “don’t‑be‑a‑reckless‑cowboy” rules:  

- **Free‑Cash‑Flow (FCF) growth rate ≈ 20 %** – Most mature firms can’t sustainably push FCF beyond ~20 % YoY. Young, hyper‑growing startups might flirt with that number, but anything higher is usually fantasyland.  
- **Projection horizon** – The longer you stretch the model, the more room for error. I like a **10‑year, two‑stage** DCF. It’s long enough to capture the bulk of value but short enough to keep the guesswork honest.  
- **Two‑stage DCF** – Split the timeline. In Stage 1 you grow FCF at a higher, realistic rate (the “growth‑phase”). In Stage 2 you dial it back to a slower, more sustainable pace (the “steady‑state” phase). This mirrors how most companies actually behave.  
- **Terminal growth rate ≈ ≤ 4 %** – Keep it low. Think of it as the “interest‑rate‑on‑the‑infinite‑future” – you don’t want it to be a rocket‑ship. I never let it creep past 4 %.  

Stick to these guardrails, and your DCF will be a lot less likely to take you on a roller‑coaster ride you didn’t buy a ticket for.  

## 16.2 – Margin of Safety  

Even with ultra‑conservative assumptions, the universe can still throw a banana peel in your path. That’s where Benjamin Graham’s **Margin of Safety** swoops in like a financial superhero in a tweed jacket. In plain English: buy only when the market price is *well* below your intrinsic‑value estimate. It won’t guarantee you’ll always win, but it gives you a cushion against bad math, bad luck, or a sudden market tantrum.  

### My personal safety‑net recipe  

Take **Amara Raja Batteries Ltd. (ARBL)** as a demo. Our DCF spits out an intrinsic value of **₹368** per share.  

1. **Model‑error band (10 %)** – To hedge against the inevitable “oops‑I‑forgot‑to‑adjust‑for‑inflation” mistake, I carve out a 10 % lower bound:  
   \[
   ₹368 \times (1-0.10) = ₹331
   \]  
2. **Additional safety discount (≈ 30 %)** – Why stop there? I shave another 30 % off the already‑conservative number. Think of it as the “just‑in‑case‑the‑universe‑decides‑to‑play‑hard‑ball” buffer:  
   \[
   ₹331 \times (1-0.30) \approx ₹230
   \]  

So, if ARBL is trading near **₹230**, I’m ready to throw in my cash with a grin.  

**Why go extra‑conservative?**  
Because when you’re looking at a stock that *looks* like a bargain at ₹100, seeing it at ₹70 makes you feel like you’ve just discovered a hidden speakeasy. That extra discount is the difference between “nice trade” and “holy‑cow‑I‑just‑found‑gold”.  

A quick recap of the numbers for ARBL:  

| Step | Value (₹) | Reason |
|------|-----------|--------|
| DCF intrinsic value | 368 | Base case |
| 10 % model‑error band | 331 | Accounting for estimation wiggle‑room |
| Further 30 % safety discount | ~230 | Margin of safety buffer |

When a high‑quality company slides far below its intrinsic worth, value hunters (a.k.a. the patient, slightly obsessive investors) swoop in. Bear markets are the best shopping season – just make sure you have cash on hand, otherwise you’ll be staring at the “out‑of‑stock” sign.  

## 16.3 – When to Sell?  

We’ve spent most of this course talking about **buying** – like a kid in a candy store. But every sweet eventually runs out, and you need to know when to put the stock back on the shelf.  

Imagine you bought ARBL at **₹250** and it’s now flirting with **₹730**. That’s a **192 %** gain (yes, you read that right – almost double your money, not counting taxes). Should you cash out? Not necessarily.  

### The “investible‑grade attributes” rule  

Your decision to own a stock should be anchored to *fundamentals*, not price swings. The moment you bought ARBL, it met a checklist of **investible‑grade attributes** (strong moat, solid cash flow, capable management, etc.). As long as those attributes stay intact, you keep the position, regardless of the market price.  

Only when **one or more** of those core attributes start to crumble (e.g., earnings slump, management scandal, loss of competitive edge) should you consider exiting. In short: **Hold as long as the business still looks like a winner; sell when the business stops being a winner.**  

## 16.4 – How Many Stocks in the Portfolio?  

Diversification vs. concentration is the age‑old debate that keeps economists up at night (and gives us a reason to quote famous investors). Here’s what the legends say:  

| Investor | Recommended # of Stocks |
|----------|--------------------------|
| **Seth Klarman** | 10 – 15 |
| **Warren Buffett** | 5 – 10 |
| **Benjamin Graham** | 10 – 30 |
| **John Maynard Keynes** | 2 – 3 |

Personally, I’m comfortable juggling **13** names and would feel like a circus clown with more than **15**. Anything beyond **20** feels like trying to keep track of a soccer league’s roster – you’ll lose focus on the fundamentals that matter.  

## 16.5 – Final Conclusion  

We’ve trekked through 16 chapters, covering everything from balance‑sheet basics to DCF wizardry. Before we part ways, let me leave you with a handful of take‑aways you can actually apply while sipping a cold brew.  

| # | Insight | Why it matters |
|---|----------|----------------|
| **1** | **Be reasonable** – Markets are a roller‑coaster, not a straight‑line highway. If you can stay seated through the loops, a **15‑18 % CAGR** over the long haul is a realistic, respectable reward. Don’t chase the occasional 50‑100 % flash‑in‑the‑pan returns; they’re usually short‑lived and stress‑inducing. |
| **2** | **Think long‑term** – Compounding is the universe’s favorite trick. The longer you stay invested, the more that magical snowball rolls. |
| **3** | **Investible‑grade attributes** – Keep a checklist. As long as the company checks the boxes (strong moat, healthy cash flow, honest promoters), stay the course. Exit when the boxes start to disappear. |
| **4** | **Respect qualitative research** – Numbers can be faked; character cannot. Look for promoters and management who act like they’ve read *The Prince* and *The Good Samaritan* at the same time. |
| **5** | **Ignore the noise** – TV analysts love drama. Stick to your own checklist; if it doesn’t pass, don’t buy, no matter how loud the hype. |
| **6** | **Margin of safety** – It’s your financial parachute. The larger the gap between price and intrinsic value, the softer your landing if things go sideways. |
| **7** | **Stay away from most IPOs** – They’re often priced like a first‑date dinner at a five‑star restaurant – you’ll overpay. If you *must* join the IPO crowd, run it through the same three‑stage equity‑research process you use for any other stock. |
| **8** | **Never stop learning** – Markets evolve, new industries pop up, and your brain needs a workout. Keep reading, keep questioning, keep refining. |

### Four books to turn you into a (slightly) smarter investor  

1. **The Essays of Warren Buffett: Lessons for Investors & Managers** – Buffett’s own words, distilled.  
2. **The Little Book That Beats the Market** – Joel Greenblatt’s “magic formula” for the impatient (and the patient).  
3. **The Little Book of Valuations** – Aswath Damodaran’s playground for anyone who loves numbers and a good challenge.  
4. **The Little Book That Builds Wealth** – Pat Dorsey’s guide to moats (the kind you don’t have to dig).  

That’s it, folks! I hope you had as much fun reading this as I had writing it (and as much fun as a cat watching a laser pointer). Keep your calculators close, your checklists tighter, and your coffee strong. Happy investing!  