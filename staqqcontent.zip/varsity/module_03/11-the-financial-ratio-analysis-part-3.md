# 11. The Financial Ratio Analysis (Part 3)

**Source:** https://zerodha.com/varsity/chapter/financial-ratios-part-3/  

---  

## 11.1 – The Valuation Ratio  

*Valuation* is just a posh‑sounding way of asking, “How much is this thing worth?” In the stock‑universe, that “thing” is a single share of a company. No matter how many fireworks a business puts on, the real gate‑keeper is the price you have to cough up for the ticket – that’s the valuation. Sometimes a plain‑Jane firm sold for a song can be a sweeter deal than a glittery unicorn priced like a private jet.

Valuation ratios are our cheat‑codes for spying on how the market values a stock. They let us line‑up the **price you’d pay** against the **real goodies you actually own**. And, as with every other ratio we’ve dissected, you should always compare a firm with its peers before you start shouting “BUY!” at the top of the bar.

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/11/M3-Ch11-title.jpg)  

In a nutshell, a valuation ratio = **Share price ÷ some measure of the company’s performance**. We’ll walk through the three heavy‑hitters that show up on most analysts’ cheat‑sheets:

1. **Price‑to‑Sales (P/S) Ratio**  
2. **Price‑to‑Book‑Value (P/BV) Ratio**  
3. **Price‑to‑Earnings (P/E) Ratio**  

Our test‑pilot for the whole ride is **Amara Raja Batteries Limited (ARBL)**. As of **28 Oct 2014** the share was trading at **₹ 661**.  

We also need the total share count – we already crunched this in Chapter 6: **17,08,12,500 shares** (≈ 17.081 cr).  

### Price‑to‑Sales (P/S) Ratio  

Earnings can be as reliable as a monsoon forecast – they swing wildly, sometimes disappear because of one‑off write‑offs, and often get dressed up in accounting wizardry. That’s why a lot of value‑hunters adore the **P/S ratio**: it leans on *sales* instead of *earnings*.

#### Formula  

\[
\text{P/S} = \frac{\text{Current Share Price}}{\text{Sales per Share}}
\]

#### Step 1 – Get Sales per Share  

\[
\text{Sales per Share} = \frac{\text{Total Revenue}}{\text{Number of Shares}}
\]

For ARBL:  

- **Total Revenue** = **₹ 3 482 Cr**  
- **Shares** = **17.081 Cr**  

\[
\text{Sales per Share}= \frac{3 482}{17.081}=₹ 203.86
\]

So each share “produces” roughly **₹ 203.86** of top‑line sales.  

#### Step 2 – Compute P/S  

\[
\text{P/S}= \frac{₹ 661}{₹ 203.86}=3.24\times
\]

A **P/S of 3.24×** tells us the market is paying **₹ 3.24** for every **₹ 1** of sales. The higher the multiple, the pricier the stock – but the real magic is in benchmarking it against peers.

> **Quick‑brain‑tickler:**  
> Imagine two firms, A and B, both selling ₹ 1 000 of goods. A nets **₹ 250** profit (25 % margin); B nets **₹ 150** (15 %). Even if both sport the same P/S, A’s sales are *more valuable* because a larger slice of each rupee ends up as profit. So, when you see a lofty P/S, glance at the profit margin to see if the premium is justified.  

---

### Price‑to‑Book‑Value (P/BV) Ratio  

Before we dive into the ratio, let’s decode **Book Value**. Picture the company packing up its stuff, hosting a massive yard‑sale, and paying off every single debt. What’s left on the table? That leftover cash is the **Book Value** – the “salvage value” of the firm.

If the whole company’s book value is **₹ 200 Cr**, that’s the cash you’d pocket after liquidation. Analysts usually slice this figure **per share**, because you’re buying a single slice of the pie, not the whole bakery.

#### Book Value per Share  

\[
\text{BV per share}= \frac{\text{Share Capital} + \text{Reserves (ex‑revaluation)}}{\text{Total Shares}}
\]

*ARBL’s balance sheet gives us:*  

- **Share Capital** = **₹ 17.1 Cr**  
- **Reserves** = **₹ 1 345.6 Cr**  
- **Revaluation Reserves** = **₹ 0**  
- **Shares** = **17.081 Cr**  

\[
\text{BV per share}= \frac{17.1+1 345.6}{17.081}=₹ 79.8
\]

So if ARBL went on a liquidation binge, each share would fetch **₹ 79.8**.  

#### P/BV Ratio  

\[
\text{P/BV}= \frac{\text{Market Price}}{\text{Book Value per Share}} = \frac{₹ 661}{₹ 79.8}=8.3\times
\]

An **8.3×** multiple means the market is valuing the company **8.3 times** its net‑asset base. A high P/BV can scream “over‑valued”; a low one can whisper “bargain”. As always, compare with industry norms before you start writing love letters to the stock.

---

### Price‑to‑Earnings (P/E) Ratio  

The **P/E** is the rock‑star of valuation ratios – everybody watches it like a reality‑TV drama. It tells us how many rupees investors are willing to pay for each rupee of earnings.

#### EPS (Earnings‑per‑Share) first  

\[
\text{EPS}= \frac{\text{Profit After Tax (PAT)}}{\text{Number of Shares}}
\]

ARBL’s numbers:  

- **PAT** = **₹ 367 Cr**  
- **Shares** = **17.081 Cr**  

\[
\text{EPS}= \frac{367}{17.081}=₹ 21.49
\]

#### Now, P/E  

\[
\text{P/E}= \frac{₹ 661}{₹ 21.49}=30.76\times
\]

Interpretation: for every **₹ 1** of profit ARBL makes, the market is ready to cough up **₹ 30.76**.  

**What if the price jumps to ₹ 750 while EPS stays at ₹ 21.49?**  

\[
\text{New P/E}= \frac{₹ 750}{₹ 21.49}=34.9\times
\]

The P/E climbs because the **price** rose – usually a sign that investors are getting more optimistic about future growth (or that someone spilled coffee on the spreadsheet).

#### Quick‑check‑list for P/E  

| ✅ | What to eyeball |
|---|-----------------|
| **High P/E = high price relative to earnings** | As a rule of thumb, I stay away from stocks priced above **25‑30× earnings**, no matter how shiny the sector. |
| **Earnings can be tweaked** | Look out for frequent accounting‑policy changes – they’re the financial equivalent of seasoning a dish every five minutes. |
| **Depreciation tricks** | Lower depreciation can artificially inflate earnings. |
| **Rising earnings without matching cash flow or sales?** | Red flag! You might be chasing phantom profit. |

---

## 11.2 – The Index Valuation  

Just like individual stocks, whole‑market indices (think **BSE Sensex**, **CNX Nifty 50**) have their own P/E, P/B and dividend‑yield numbers. The NSE publishes these daily, giving us a macro‑temperature check: “Is the market cheap, dear, or is it a pricey cocktail?”

### How Nifty‑50 P/E is built  

\[
\text{Nifty P/E}= \frac{\displaystyle\sum_{i=1}^{50}\text{Market‑Cap}_i}{\displaystyle\sum_{i=1}^{50}\text{Earnings}_i}
\]

In other words, you add up the market‑caps of the 50 constituents, add up their earnings, and divide. Tracking this figure over time shows the market’s mood swings. Below is a historical chart (source: Creytheon).

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/11/M3-Ch11-chart11.jpg)  

#### Key take‑aways from the chart  

| Observation | What it Means |
|-------------|---------------|
| **Peak at 28× (early 2008)** | Market was frothing; the crash that followed proved it was over‑heated. |
| **Drop to ~11× (late 2008‑early 2009)** | The market hit rock‑bottom – a classic buying opportunity in hindsight. |
| **Typical range 16‑20×, average ≈ 18×** | Think of this as the “comfort zone”. |
| **Current (2014) ≈ 22×** | Slightly above average – a caution flag. |

**Practical implications:**  

- When the market’s P/E nudges **above 22×**, tread carefully – you might be buying at a premium.  
- Historically, the sweetest entry points have been when the index hovers **≤ 16×**.  

### How to fetch today’s index valuation  

1. Hop onto the **NSE** website.  
2. Navigate: **Products → Indices → Historical Data → P/E, P/B & Div → Search**.  
3. Pop in today’s date; the latest numbers appear (the NSE updates around **6 pm**).  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/11/M3-Ch11-chart2.jpg)  

As of **13 Nov 2014**, the Indian market was flirting with the higher end of its historic P/E band – a gentle reminder to keep your eyes peeled and your wallet tight.

---

### Key take‑aways from this chapter  

- **Valuation** = estimate of an asset’s “worth”.  
- Valuation ratios pull data from both the **P&L** (income statement) **and** the **Balance Sheet**.  
- **Price‑to‑Sales (P/S)** compares market price with **sales per share** (sales ÷ shares).  
- Higher profit margins make a company’s sales *more valuable* than a low‑margin peer’s sales.  
- In a liquidation scenario, **Book Value** = what’s left after all debts are paid.  
- Book value is usually quoted **per share**.  
- **Price‑to‑Book (P/BV)** tells how many times the market price exceeds the net‑asset value.  
- **EPS** = profit per share; the higher, the better for shareholders.  
- **P/E** gauges how much investors are willing to pay for each rupee of earnings.  
- Watch out for earnings manipulation (policy changes, depreciation tricks, cash‑flow mismatches).  
- Indices have their own valuation metrics (P/E, P/B, Dividend Yield).  
- When an index trades **≥ 22×**, exercise caution.  
- The most attractive entry points are when the index is **≤ 16×**.  
- The **NSE** updates index valuations daily – a handy free tool for the savvy investor.  

*And remember: “Sales per share is simply the Sales divided by the Number of shares.” – repeated for emphasis, because good things (like good ratios) deserve a second toast. 🍻*