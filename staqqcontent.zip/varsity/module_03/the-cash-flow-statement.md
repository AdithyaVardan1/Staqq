# 8. The Cash‑Flow Statement  

**Source:** <https://zerodha.com/varsity/chapter/cash-flow-statement/>

---  

## 8.1 – Overview  

The cash‑flow statement is the unsung hero of the three‑statement cast. It tells you how much *real* cash a business is pulling in – not just the accounting‑magic that lives on the P&L.  
“Isn’t that already in the profit‑and‑loss?” you ask. The answer is a polite “yes…and no.”

### A coffee‑shop vs. a laptop‑store (the classic “cash‑vs‑credit” showdown)

Picture a tiny coffee shack that sells espresso and samosas. All sales are cash‑only: a customer wants a latte? He better have a rupee in his pocket.  
One bustling day the shop rakes in  

* **Coffee sales:** ₹2,500  
* **Snack sales:** ₹3,000  

Total revenue = **₹5,500** – this shows up crystal‑clear on the P&L. No mysteries there.

Now, imagine a sleek laptop boutique that only sells one model for a tidy **₹25,000** each. On a given day it ships out 20 units.  

* **Gross sales:** 20 × ₹25,000 = ₹500,000  

But five of those laptops are sold *on credit* (the buyer takes the machine now, pays later). Break it down:  

| Sale type | Units | Amount |
|-----------|------|--------|
| Cash sale | 15   | ₹375,000 |
| Credit sale| 5   | ₹125,000 |
| **Total** | **20**| **₹500,000** |

The P&L will proudly flaunt a ₹500,000 top‑line. Yet the bank balance only reflects the cash sales – **₹375,000**. Throw in a looming loan repayment of **₹400,000** and you’ve got a classic cash crunch: the company looks rich on paper but can’t meet its debt.

Enter the cash‑flow statement. It forces the firm to spell out exactly how much cash actually entered or left the vaults. Regulators demand it as part of the complete financial‑statement package because it reveals the *true* liquidity picture.

**Bottom line:** A firm’s health isn’t measured solely by profit; it’s measured by cash that can pay the rent, the salaries, and the late‑night pizza orders.

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M3-Ch8-title.jpg)

---

## 8.2 – Activities of a Company  

Before we can read the cash‑flow statement, we need to know *what* the company is doing. Think of a business as a busy bee with three distinct hives of activity.

### The three baskets (a.k.a. the three cash‑flow sections)

1. **Operating Activities (OA)** – The day‑to‑day hustle: sales, marketing, production, staff salaries, tech upgrades, etc.  
2. **Investing Activities (IA)** – The “future‑making” moves: buying equipment, investing in other firms, parking cash in term deposits, purchasing land or buildings.  
3. **Financing Activities (FA)** – The money‑raising and money‑paying side: issuing debt, paying dividends, repurchasing shares, taking on new loans, etc.

All legitimate corporate actions fall neatly into one of these three categories.

### A concrete example: a fitness‑centre chain  

Let’s pretend we run a well‑known gym (think Talwalkars or Gold’s Gym). Below is a random grab‑bag of things it might do:

| Activity | Which basket? |
|----------|---------------|
| Run ads on billboards to lure new members | OA |
| Hire personal trainers to keep members sweating | OA |
| Replace old treadmills with brand‑new ones | OA |
| Take a short‑term bank loan for cash‑flow smoothing | FA |
| Issue a Certificate of Deposit (CD) to raise funds | FA |
| Give a few friends preferential shares for expansion | FA |
| Put money into a startup that’s inventing VR workouts | IA |
| Stash excess cash in a fixed‑deposit account | IA |
| Buy a plot for a new gym location under construction | IA |
| Upgrade the sound system for a pumped‑up workout vibe | OA |

### Cash‑flow impact in a nutshell  

Every line above either *spends* cash (negative impact) or *brings in* cash (positive impact). For instance, buying a new sound system means cash flows **out**, but you also gain a new asset on the balance sheet.

Below is a colour‑coded cheat‑sheet (just like the original, but we’ll describe it in words):

* **Blue** – cash inflow (increase)  
* **Red** – cash outflow (decrease)  
* **Green** – asset side of the balance sheet  
* **Purple** – liability side of the balance sheet  

From that table you can deduce two golden rules:

| Rule | What happens |
|------|---------------|
| **Liabilities ↑ ⇒ Cash ↑** | When you borrow money (liability rises), cash in the bank rises. Conversely, when you repay debt, cash falls. |
| **Assets ↑ ⇒ Cash ↓** | Buying a treadmill (asset rises) means cash leaves the bank. Selling an asset (asset falls) pumps cash back in. |

These relationships are the backbone of constructing a cash‑flow statement. Every activity, whether operating, investing or financing, will either **add** to cash (net increase) or **subtract** from cash (net decrease). Summing the three sections gives you the **total cash flow** for the period.

---

## 8.3 – The Cash‑Flow Statement  

Armed with the activity‑type knowledge, let’s peek at a real‑world cash‑flow statement. Companies usually break it into the three sections we just discussed, showing exactly how much cash each bucket generated (or consumed).

### A quick look at Amara Raja Batteries Ltd. (ARBL)

Below is ARBL’s cash‑flow statement (FY 2013‑14). I’ll spare you the line‑by‑line drill – most rows are self‑explanatory – and focus on the headline numbers.

#### Operating Activities  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M3-Ch8-Chart1.jpg)

ARBL generated **₹278.7 cr** from its core operations. A positive operating cash flow is the healthiest sign; it means the business can fund itself without constantly tapping external sources.

#### Investing Activities  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M3-Ch8-Chart2.jpg)

Here the company **spent ₹344.8 cr** on investments – think new factories, equipment, or equity stakes. Investing usually *uses* cash, which is fine as long as it’s for growth. How much is “healthy” varies by industry and stage; we’ll get to that later.

#### Financing Activities  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M3-Ch8-Chart3.jpg)

Financing saw a **cash outflow of ₹53.1 cr**, largely due to dividend payouts. If ARBL had taken on fresh debt, you’d see a cash inflow here (remember: liabilities ↑ ⇒ cash ↑). The balance sheet confirms no new borrowings were made.

#### Putting it all together  

Summing the three sections, ARBL **used ₹119.19 cr** of cash in FY 2013‑14. That looks like a drain, but we need to consider the opening cash balance.

#### Opening vs. Closing Cash  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M3-Ch8-Chart4.jpg)

The green‑highlighted line shows an **opening cash balance of ₹409.46 cr** – this is simply the previous year’s closing cash. Add the current year’s net cash movement (‑₹119.19 cr) and a tiny foreign‑exchange tweak of **₹2.58 cr**, and you end up with a **closing cash balance of ₹292.86 cr**.

So, even though ARBL “guzzled” cash this year, it still sits on a comfortable cushion thanks to the cash it carried over from the prior year.

Next year’s opening balance will be that ₹292.86 cr, so keep an eye on the next cash‑flow statement to see whether the trend is upward or downward.

#### Quick FAQ  

| Question | Answer |
|----------|--------|
| **What does ₹292.86 cr actually represent?** | The total cash and cash‑equivalents sitting in ARBL’s bank accounts. |
| **What is “cash” in accounting terms?** | Physical cash + demand‑deposit balances – the most liquid asset a firm can have. |
| **What are “liquid assets”?** | Anything that can be turned into cash quickly without a big price hit (e.g., marketable securities, treasury bills). |
| **Are liquid assets the same as “current items” on the balance sheet?** | Yes, essentially. They sit under the “Current Assets” heading. |
| **Should cash appear on the balance sheet?** | Absolutely – as a current asset. The cash‑flow statement tells you *how* that cash got there. |

Here’s the balance‑sheet excerpt that shows cash under current assets:

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M3-Ch8-Chart5.jpg)

The take‑away? The cash‑flow statement and the balance sheet are like two best friends at a party – they constantly reference each other. All three financial statements (P&L, Balance Sheet, Cash‑Flow) are intertwined.

---

## 8.4 – A Brief on the Financial Statements  

Over the past few chapters we’ve dissected the **three** core statements:

| Statement | Primary focus |
|-----------|----------------|
| **Profit & Loss (P&L)** | Revenues vs. expenses for the period; yields net profit, retained earnings, depreciation, etc. |
| **Balance Sheet** | Snapshot of assets, liabilities, and equity at a point in time. Assets = Liabilities + Equity. Cash & cash equivalents (from the cash‑flow) sit here as a current asset. |
| **Cash‑Flow Statement** | Historical cash movements, split into operating, investing, and financing activities; ends with the cash balance that feeds the Balance Sheet. |

The P&L and Cash‑Flow are **periodic** (they cover a fiscal year), while the Balance Sheet is **as‑of‑date** (a snapshot). The P&L feeds retained earnings into the Balance Sheet, and depreciation from the P&L also appears on the Balance Sheet. Meanwhile, the cash‑flow statement supplies the cash figure that appears on the Balance Sheet.

We’ve now learned *what* each statement tells us, but we haven’t yet tackled *how* to analyze them. That’s where financial ratios come in – the next set of chapters will dive deep into ratio analysis.

---

### Key Takeaways from This Chapter  

- The cash‑flow statement reveals the *real* cash position, cutting through accounting‑style profit figures.  
- Every legitimate firm’s activities fall into **Operating**, **Investing**, or **Financing** categories.  
- Each activity either **generates** cash (net increase) or **drains** cash (net decrease).  
- Net cash flow = Cash from Operating + Cash from Investing + Cash from Financing.  
- Investors should pay special attention to **cash flow from operating activities** – it’s the engine that keeps the lights on.  
- **Liabilities ↑ → Cash ↑** (borrowing adds cash; repaying removes it).  
- **Assets ↑ → Cash ↓** (buying assets uses cash; selling assets frees cash).  
- The final cash‑flow figure feeds straight into the **Balance Sheet’s cash line**.  
- The cash‑flow statement is the unsung side‑kick that rounds out the trio of financial statements, giving a complete picture of a company’s performance.

Now that you’ve got the cash‑flow basics down, go forth and stare at those statements with the confidence of a bartender who knows every cocktail recipe by heart. Cheers!