# 6. Understanding Balance Sheet Statement (Part 1)

**Source:** https://zerodha.com/varsity/chapter/understanding-balance-sheet-statement-part-1/

---  

##  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M3-Ch6-title2.jpg)

## 6.1 – The balance sheet equation  

The profit‑and‑loss (P&L) statement is the “movie” that tells you whether the company made money **this** year – think of it as the box‑office report for the latest blockbuster. The balance sheet, on the other hand, is the **static snapshot** of the firm’s financial skeleton at a point in time. It lists what the company **owns** (assets), what it **owes** (liabilities) and what’s left for the owners (shareholders’ equity).  

Why the difference? The P&L runs on a **flow basis** – it covers a 12‑month period, then rolls over to the next year. The balance sheet, however, is **cumulative**: it carries forward everything from day one of the firm’s existence up to the reporting date. In short, the P&L says “how did we perform this year?”, while the balance sheet whispers “where do we stand after all the years of hustle?”.

Take a peek at Amara Raja Batteries Limited (ARBL)’s balance sheet:  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M3-Ch6-Chart1.jpg)

You’ll see three big buckets – **Assets**, **Liabilities** and **Equity**.  

### Assets  
We already brushed on assets in the previous chapter. In plain English, an asset is anything the company controls that will bring cash (or cash‑equivalents) in the future. Think of factories, machines, cash in the bank, brand value, patents, that shiny office coffee machine you love – all of it. Assets split into two families: **current** (easily turned into cash within a year) and **non‑current** (long‑term stuff). We’ll meet those later.

### Liabilities  
Liabilities are the flip side – the obligations the firm has taken on because it *believes* they’ll generate value later. In everyday language, it’s the company’s debt. Short‑term borrowings, long‑term loans, unpaid bills – all of that lives here. Like assets, liabilities are also split into **current** (due within 12 months) and **non‑current** (due later).

### The magic equation  

In a “normal” balance sheet the totals must line up perfectly:

\[
\text{Assets} = \text{Liabilities} + \text{Shareholders’ Equity}
\]

That’s the **balance‑sheet equation** (aka the **accounting equation**). It’s called “balance” for a reason – the two sides always balance because every rupee of assets is funded either by a creditor (liability) or by the owners (equity).  

Re‑arrange the formula and you get the owners’ claim on the business, commonly called **shareholders’ equity** or **net worth**:

\[
\text{Shareholders’ Equity} = \text{Assets} - \text{Liabilities}
\]

That’s the leftover slice of the pie after you’ve paid everyone else.  

---

## 6.2 – A quick note on shareholders’ funds  

Balance sheets have **two** major sections – assets on the left, liabilities **plus** shareholders’ funds on the right. The term *shareholders’ funds* often trips people up because it lives on the **liabilities** side, even though it sounds like an asset.  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M3-Ch6-Chart2.jpg)

Why? Imagine the company as a person who runs a lemonade stand. The stand (the business) needs money to buy lemons, sugar, a cart, etc. Those funds come from two sources:

1. **Borrowed money** (liabilities) – you owe the bank a slice of your future lemonade profits.  
2. **Owner’s money** (shareholders’ funds) – the cash you and your friends invested.  

From the *stand’s* point of view, the money you (the owners) put in isn’t really theirs to spend freely; it’s **obligation** to return the capital (or its value) when the stand is liquidated. Hence, it’s reported on the liabilities side as an **obligation to the shareholders**.  

So, shareholders’ funds are essentially the **company’s duty to its owners** – a claim rather than a resource.  

---

## 6.3 – The liability side of the balance sheet  

The right‑hand side of the balance sheet groups everything the company owes. It’s split into three sub‑sections:

1. **Shareholders’ funds** (equity)  
2. **Non‑current liabilities** (long‑term debt)  
3. **Current liabilities** (short‑term obligations)  

### Shareholders’ funds  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M3-Ch6-Chart3.jpg)

#### Share capital  
Picture a brand‑new company, “ABC Enterprises”. It decides to issue **1 000 shares** with a **face value** of **₹10** each. Simple math:

\[
\text{Share Capital} = 1\,000 \times ₹10 = ₹10\,000
\]

ARBL’s balance sheet shows a share capital of **₹17.081 cr** (₹1 face value). From the NSE website we get the face value, then back‑solve for the number of shares:

\[
\text{Number of shares} = \frac{\text{Share Capital}}{\text{Face Value}} = \frac{₹17.08\,10\,000}{₹1} = 17,08,10,000 \text{ shares}
\]

#### Reserves and surplus  

The next line is **Reserves & Surplus**. “Reserves” are earmarked cash for specific purposes; “Surplus” is the profit that’s been retained (i.e., not paid out as dividend). ARBL’s reserves & surplus total **₹1 345.6 cr**. Let’s break it down (note 3 in the annual report):

- **Capital reserve** – money set aside for long‑term projects. ARBL’s amount is tiny, and it can’t be distributed as dividend.  
- **Securities premium reserve** – the premium received over the face value when shares were issued. ARBL has **₹31.18 cr** here.  
- **General reserve** – the “rainy‑day” pot of undistributed profits. ARBL holds **₹218.4 cr**.  

#### Surplus (the profit pot)  

- FY13 closing surplus = **₹829.8 cr** (opening balance for FY14).  
- FY14 profit = **₹367.4 cr**. Add the two, and you get **₹1 197.2 cr**.  
- From that, ARBL transfers **₹36.7 cr** to general reserve (to beef up the buffer).  
- Then it pays **₹55.1 cr** in dividends, plus **₹9.3 cr** tax on those dividends.  

After all the shuffling, the **closing surplus** ends up at **₹1 095.9 cr**, which becomes the opening surplus for FY15.

Putting it together:

\[
\text{Total Reserves & Surplus} = \text{Capital Reserve} + \text{Securities Premium} + \text{General Reserve} + \text{Surplus}
\]

For FY14 this equals **₹1 345.6 cr**, up from **₹1 042.7 cr** in FY13.

Finally, **Shareholders’ Funds** = **Share Capital** + **Reserves & Surplus**. This is the “equity” section of the balance sheet.

---

## 6.4 – Non‑Current Liabilities  

Non‑current liabilities are the **long‑term** obligations that won’t be paid off within the next 12 months. Think of them as the company’s “mortgage” and other multi‑year promises.

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M3-Ch6-Chart7.jpg)

ARBL lists three major non‑current items:

1. **Long‑term borrowings** (note 4)  
2. **Deferred tax liability**  
3. **Long‑term provisions**  

### 1️⃣ Long‑term borrowings  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M3-Ch6-Chart8.jpg)

In ARBL’s case, the borrowing is an **interest‑free sales‑tax deferment** – essentially a state‑government incentive that lets the firm delay paying sales tax for up to **14 years**. It’s not “free money”, just a timing advantage.  

If a company shows **zero** long‑term debt, ask yourself why: are banks scared of the firm? Is the firm deliberately avoiding leverage? Remember, debt isn’t inherently bad; it fuels growth, but it also creates **finance cost** (interest expense) on the P&L.  

### 2️⃣ Deferred tax liability  

This is a “future tax bill” the company expects to pay because of timing differences (most commonly depreciation). The accounting books may depreciate an asset faster than the tax code, creating a temporary mismatch that will reverse later, resulting in a tax payable down the road.  

### 3️⃣ Long‑term provisions  

These are funds set aside for future employee‑related obligations – gratuity, leave encashment, provident fund contributions, etc. They sit in the long‑term bucket because the company expects to settle them after more than a year.

---

## 6.5 – Current liabilities  

Current liabilities are the obligations that must be cleared **within the next 12 months**. In everyday language, they’re the “pay‑this‑month” items.

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M3-Ch6-Chart9.jpg)

ARBL’s current liabilities break down into four line items:

| Item | Approx. Value (₹ cr) | What it means |
|------|--------------------|----------------|
| **Short‑term borrowings** | 8.3 | Quick cash from banks (SBI, Andhra Bank) to meet working‑capital needs (see note 7). |
| **Trade payables** | 127.7 | Money owed to suppliers – raw material vendors, utilities, office‑supply guys (note 8). |
| **Other current liabilities** | 215.6 | Statutory or miscellaneous obligations not directly linked to operations (note 9). |
| **Short‑term provisions** | 281.8 | Employee‑benefit reserves that are due within a year – similar to the long‑term provisions but with a shorter horizon (note 6). |

### Short‑term borrowings (note 7)  

These are essentially **working‑capital loans** – the company’s short‑term “coffee‑shop‑tab”. ARBL’s exposure is modest at **₹8.3 cr**, indicating a fairly liquid balance sheet.

### Trade payables (note 8)  

Think of this as the company’s “I‑owe‑you” list to its vendors. The larger the figure, the more the firm relies on its suppliers for cash flow.

### Other current liabilities (note 9)  

These can be tax deposits, statutory dues, or any other short‑term obligation that doesn’t fit neatly elsewhere.

### Short‑term provisions (note 6)  

Even though the note is shared with long‑term provisions, the amounts are split by maturity. They’re earmarked for employee benefits that will be paid out within the next year.

---

## Putting it all together  

Now that we’ve toured half the balance sheet (the **liabilities side**), let’s glance at the full picture again:

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M3-Ch6-Chart14.jpg)

The **total liability** (i.e., the entire right‑hand side) is simply the sum of:

\[
\text{Total Liability} = \text{Shareholders’ Funds} + \text{Non‑Current Liabilities} + \text{Current Liabilities}
\]

Plugging in ARBL’s numbers:

\[
\begin{aligned}
\text{Shareholders’ Funds} &= ₹1 362.7 \text{ cr}\\
\text{Non‑Current Liabilities} &= ₹143.03 \text{ cr}\\
\text{Current Liabilities} &= ₹633.7 \text{ cr}\\[4pt]
\text{Total Liability} &= ₹2 139.4 \text{ cr}
\end{aligned}
\]

(Yes, the original said “Cars” – a typo. It’s **crores**.)

---

## Key takeaways from this chapter  

- A **balance sheet** (aka *Statement of Financial Position*) is a **point‑in‑time** picture of what a company **owns** (assets) and **owes** (liabilities).  
- Companies need a balance sheet whenever they court investors, apply for loans, or file taxes.  
- The core equation is **Assets = Liabilities + Shareholders’ Equity**.  
- **Liabilities** are past‑transaction obligations; **Share capital** = *Number of shares × Face value*.  
- **Reserves** = earmarked cash for specific future uses; **Surplus** = retained profit. Dividends are paid out of surplus.  
- **Shareholders’ equity** = Share capital + Reserves + Surplus = *Assets – Liabilities*.  
- **Non‑current liabilities** are obligations due **after** 12 months (e.g., long‑term debt, deferred tax, long‑term provisions).  
- **Deferred tax liabilities** arise from timing differences (most often depreciation).  
- **Current liabilities** must be settled within a year (short‑term borrowings, trade payables, other short‑term duties, short‑term provisions).  
- Both long‑ and short‑term provisions usually relate to employee benefits.  
- **Total Liability** = Shareholders’ Funds + Non‑Current Liabilities + Current Liabilities – the total amount the firm owes to the outside world (or, more politely, to its creditors and owners).  

Now you’ve got the balance sheet down to a science…and a few jokes. Next time you stare at a corporate filing, you’ll know exactly where the **assets**, **liabilities**, and that mysterious **shareholders’ fund** are hiding – and you’ll be able to explain it over a pint without sounding like a walking spreadsheet. Cheers!