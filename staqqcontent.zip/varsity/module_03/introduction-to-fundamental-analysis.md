# 1. Introduction to Fundamental Analysis  

**Source:** https://zerodha.com/varsity/chapter/introduction-fundamental-analysis/

---  

##  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M3-Ch1title.jpg)

## 1.1 – Overview  

Fundamental Analysis (FA) is basically the “big‑picture” Netflix binge of the stock world – you sit down, grab some popcorn, and study a business from every possible angle before you decide whether to fall in love (or dump it).  
If you’re the kind of investor who likes to keep a stock on your radar for **3‑5 years** (or longer—think “marriage” rather than a one‑night stand), you need to cut through the daily market chatter, the meme‑stock hype, and the “buy‑the‑dip” sirens. What really matters is how the underlying company is performing, not how many emojis its price chart shows in a single day.  

Over the long haul, companies with solid fundamentals tend to see their share prices rise like a well‑fed yeast dough, turning modest investments into serious wealth.  

### Real‑life Indian success stories  

Take a stroll down the Indian stock‑market hallway of fame and you’ll see names like **Infosys**, **TCS**, **Page Industries**, **Eicher Motors**, **Bosch India**, **Nestle India**, and **TTK Prestige** flashing neon lights.  
These aren’t just “good” companies; they’re **wealth‑machines** that have delivered an **average compounded annual growth rate (CAGR) of > 20 %** for more than a decade.  

- **What does 20 % CAGR really mean?**  
  Using the Rule of 72, 72 ÷ 20 ≈ **3.6 years**. So, an investor who puts ₹100 k into a 20 % CAGR stock will see that money roughly **double to ₹200 k in just under four years**.  

Some titans, like **Bosch India**, have even flirted with a **30 % CAGR**—that’s a doubling time of a mere **2.4 years**! Imagine the bragging rights at your next family gathering.  

Below are long‑term price charts of three of those superstar stocks. (Don’t worry, the charts are for illustration only; we’re not promising you’ll become the next Warren Buffett after a single glance.)

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M3-Ch1-chart1.jpg)

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M3-Ch1-chart2.jpg)

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M3-Ch1-chart3.jpg)

### The “I‑choose‑the‑dark‑side” examples  

Now, I hear you thinking, “Hey, you’re cherry‑picking the winners. What about the losers?” Good point, detective! Here are the long‑term charts of three companies that turned investors into the financial equivalent of a soggy pizza—**Suzlon Energy, Reliance Power, and Sterling Biotech**.

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M3-Ch1-chart4.jpg)

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M3-Ch1-chart5.jpg)

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M3-Ch1-chart6.jpg)

These are the **wealth‑destructors** you’ll want to steer clear of (or at least keep a safe distance from).  

The secret sauce is simple: **spot the investment‑grade companies that grow your nest egg, and avoid the junk that shrinks it**. All the “good” firms share a handful of common traits, and the “bad” ones share their own tell‑tale patterns.  

Fundamental Analysis is the magnifying glass that lets you see those traits, giving you the conviction to sit tight for the long haul rather than sprinting around the market like a caffeinated squirrel.

## 1.2 – Can I be a fundamental analyst?  

**Spoiler alert:** *Yes, you can.*  

There’s a myth that only Chartered Accountants or people who spend their weekends poring over balance sheets can do FA. Nope. A good fundamental analyst just needs to be able to add 2 + 2 and get 4 (or at least not get 5).  

### The minimal skill set  

1. **Read the basic financial statements** – Income statement, balance sheet, cash‑flow statement. Think of them as the three musketeers of a company’s health.  
2. **Know the industry context** – A tech startup isn’t the same as a cement plant. You need to understand the playground the company is in.  
3. **Basic arithmetic** – Addition, subtraction, multiplication, division. If you can split a pizza into slices, you’re good to go.  

This module’s mission is to give you the first two of those skills (the pizza‑splitting part comes later when you actually invest).  

## 1.3 – I’m happy with Technical Analysis, so why bother about Fundamental Analysis?  

Technical Analysis (TA) is the **“quick‑hit”** snack of the investing world—great for short‑term thrills, like a hot wing challenge at a bar. It helps you time entries and exits, catch momentum, and occasionally ride a wave to a modest profit.  

But here’s the uncomfortable truth: **TA alone won’t make you rich**. Real wealth is built by **owning pieces of solid businesses for the long term**. Think of it like buying a house: you could flip it in a month for a small gain (TA), but the real payoff comes from holding a well‑located property while its value appreciates over years (FA).  

### The “core‑satellite” illustration with Eicher Motors  

Below is the chart of **Eicher Motors** (the two‑wheeler‑and‑truck king).  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M3-Ch1-chart7.jpg)

Imagine someone spots Eicher Motors in **2006**, decides it’s a fundamentally strong company, and buys a sizable chunk. From **2006‑2010**, the stock is basically moving sideways—like watching paint dry. The big move doesn’t start until **post‑2010**.  

If our investor only held the stock during that flat period, they’d see virtually **no return**. A smarter move? Use **Technical Analysis** to trade the sideways market, capturing short‑term gains while still keeping a core position for the long haul.  

### Enter the “Core‑Satellite” strategy  

1. **Core (the steady‑state)** – 60 % of your capital (say ₹5 lakhs → ₹3 lakhs) goes into a basket of fundamentally strong stocks. Expect **12‑15 % CAGR** over the years. This is your financial “safety net” and the main driver of wealth creation.  
2. **Satellite (the spice)** – The remaining 40 % (₹2 lakhs) is allocated to active, short‑term trades using Technical Analysis on equities, futures, options, etc. Aim for an **absolute return of 10‑12 %** per year, which can boost the overall portfolio performance.  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/Core1.jpg)

The idea is simple: **let the core grow like a slow‑cooking stew, and let the satellite add some extra flavor**. Both components need each other—without the core you’re gambling, without the satellite you’re missing out on short‑term opportunities.

## 1.4 – Tools of FA  

Good news: most of the tools you need for solid Fundamental Analysis are **free** (or at least cheap). Here’s the minimalist toolbox:

| Tool | Why you need it | Where to get it |
|------|----------------|-----------------|
| **Annual Report** | Gold‑mine of financials, management commentary, and governance details. | Company website → “Investors” section (PDF download, free). |
| **Industry Data** | Puts the company in context—are its margins beating the sector average? | Industry association sites, RBI/SEBI publications, or free market‑research portals. |
| **News Feed** | Keeps you updated on macro‑events, regulatory changes, product launches, etc. | Business newspapers, Google Alerts, Bloomberg (free tier). |
| **Excel (or any spreadsheet)** | Crunch numbers, build models, run ratios. | If you don’t have MS Excel, Google Sheets works just as well (and it’s free). |

With just these four items you can put together a research report that would make a Wall‑Street analyst nod in approval. In fact, institutional houses often keep their research **simple and logical**—they’re not looking for a magic crystal ball, just clear, data‑driven insights.

### Bonus tip  

If you’re feeling fancy, add a **valuation calculator** (DCF or multiples) built in Excel. It’s not mandatory, but it does make your analysis look extra‑professional when you impress friends at the bar.

## Key takeaways from this chapter  

- **Fundamental Analysis = long‑term investing** (the “buy‑and‑hold” part of the cocktail).  
- Investing in companies with strong fundamentals **creates wealth** (the kind that lets you retire early and still afford avocado toast).  
- FA lets you **separate the “investment‑grade” gems from the “junk‑yard” wrecks**.  
- All quality companies share a handful of **common traits**; likewise, all junk shares its own tell‑tale signs.  
- **Both Technical and Fundamental Analysis should coexist**—think of them as the bread and butter of a balanced diet.  
- To become a fundamental analyst you **don’t need a PhD**; just common sense, basic math, and a sprinkle of business intuition.  
- The **core‑satellite allocation** is a prudent way to split your capital—core for steady growth, satellite for tactical edge.  
- The **tools you need are largely free**: annual reports, industry data, news alerts, and a spreadsheet.  

Now go forth, sip your coffee (or cocktail), and start digging into those annual reports. Your future self will thank you when the portfolio starts looking like a well‑grown money tree. 🌳💰