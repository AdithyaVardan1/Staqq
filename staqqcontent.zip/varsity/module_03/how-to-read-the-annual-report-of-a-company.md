# 3. How to Read the Annual Report of a Company  

**Source:** https://zerodha.com/varsity/chapter/read-annual-report-company/  

---  

##  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M3-Ch3-title.jpg)  

## 3.1 – What is an Annual Report?  

Think of an Annual Report (AR) as the company’s “year‑in‑review” mixtape that it ships out to shareholders, analysts, and anyone else who pretends to care about balance‑sheet poetry. It drops at the tail‑end of the fiscal year—so everything you see is dated **31 March** (or whatever the local year‑end is).  

You’ll usually find the AR tucked away in the “Investors” tab of the firm’s website as a glossy PDF, but you can also phone the corporate secretary and ask for a hard‑copy (just be ready to fend off the sales pitch for the next 30 minutes).  

Why the fanfare? Because once a fact lands inside the AR, it’s *official*. If the company tries to pull a fast‑one—say, inflating revenue or hiding a massive lawsuit—the auditor’s signed, sealed, and dated certificate will come back to bite it. In other words, the AR is the legal equivalent of a wedding photo: you can’t edit it later without everyone noticing.  

**Who reads it?**  
- **Potential investors** looking for a crystal‑ball glimpse of future cash flows.  
- **Current shareholders** who want to make sure their money isn’t disappearing into a black hole.  

For anyone with a stake, the AR should be the *first* stop, not that random finance blog that re‑posts a “Top‑10 Companies to Watch” list. Those sites are great for gossip, but they often re‑package numbers in a way that looks tidy but may hide the gritty details.  

*Why would a media outlet “mis‑represent” data?*  
Usually it’s not a nefarious plot; it’s a matter of formatting. A company might bundle **depreciation** into the “Operating Expenses” line, while a website decides to pop it out under a separate header called “Non‑Cash Charges”. The bottom line (pun intended) stays the same, but the visual flow gets scrambled, and that can throw off a quick eyeball scan.  

---

## 3.2 – What to Look for in an Annual Report?  

An AR is a thick, multi‑chapter novel where fact and PR prose walk hand‑in‑hand. Your job is to separate the plot twists (real risks) from the marketing hype (pretty‑sounding buzzwords).  

Below is the “road‑map” I follow, using **Amara Raja Batteries Limited (ARBL)** FY 2013‑14 as a live example. (If you’re curious, you can download the report here: https://www.amararajabatteries.com/Investors/annual-reports/).  

> **Pro‑Tip:** Grab the PDF, open it side‑by‑side with this guide, and start scrolling as we go. It’s like binge‑watching a series with subtitles.  

### The nine (sometimes ten) sections you’ll typically encounter  

1. **Financial Highlights**  
2. **The Management Statement**  
3. **Management Discussion & Analysis (MD&A)**  
4. **10‑Year Financial Highlights**  
5. **Corporate Information**  
6. **Director’s Report**  
7. **Report on Corporate Governance**  
8. **Financial Section** (the three core statements)  
9. **Notice**  

> *Note:* No two ARs are carbon copies. Companies tailor the layout to fit their industry, regulatory quirks, and sometimes just to look “fancy”. Still, the skeleton above shows up in most Indian listed firms.  

### 3.2.1 Financial Highlights – The Snapshot  

Think of this as the AR’s Instagram story: a quick visual of the key numbers, often displayed in tables or bar‑charts. It usually shows **multi‑year trends** for revenue, profit, EPS, and a handful of ratios the company loves to brag about.  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M3-Ch3-chart11.jpg)  

What you’re really seeing is a distilled slice of the full financial statements. Companies may also sprinkle in self‑calculated ratios (e.g., ROE, Debt‑to‑Equity). I skim this section to get a feel for the company’s trajectory, but I never rely on it for deep analysis. Why? Because I prefer to **re‑calculate** those ratios myself—nothing beats the clarity you get when you punch the numbers into a spreadsheet and watch the magic (or horror) happen.  

### 3.2.2 Management Statement & MD&A – The CEO’s Poetry Corner  

These two sections are my favorite because they give the **human** side of the numbers.  

- **Management Statement** (often called the Chairman’s or MD’s Message) is the “state‑of‑the‑union” speech. It’s where the top‑dog tells you what he *thinks* about the business, the market, and sometimes his favorite cricket team. Look for realism: does the speaker acknowledge both wins and blunders?  

  *Story time:* I once read a tea‑maker’s chairman claim a **10 %** revenue surge, while the historical data showed a modest **4‑5 %** increase. The gap was so glaring I could hear the CFO sigh in the background. That was my cue to walk away.  

  Here’s a snippet from ARBL’s Chairman’s Message (highlighted for drama):  

  ![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M3-Ch3-chart2.jpg)  

- **Management Discussion & Analysis (MD&A)** is the deep‑dive. Companies usually start with macro‑economics: “India’s GDP grew X %; global trade winds are shifting; we expect the auto‑sector to…”. If the firm is export‑heavy, they’ll also talk about exchange‑rate turbulence and overseas demand.  

  ARBL’s MD&A splits the narrative into **Export** and **Domestic** perspectives, because why not?  

  ![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M3-Ch3-chart3.jpg)  

  Their take on the Indian economy:  

  ![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M3-Ch3-chart4.jpg)  

  After the macro chat, the MD&A zooms into **industry trends** and the company’s **strategic outlook**. This is where you can compare the firm’s optimism (or doom‑saying) with its peers—say, juxtaposing ARBL’s view against Exide’s AR.  

  The section later breaks down performance **by division**, shows year‑on‑year changes, and often lists concrete targets for the coming fiscal year.  

  Sample division‑level snapshot:  

  ![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M3-Ch3-chart5.jpg)  

  Some firms even publish a “Road‑Map” of upcoming projects and R&D spend:  

  ![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M3-Ch3-chart6.jpg)  

After the MD&A, you’ll encounter ancillary reports—Human Resources, R&D, Technology, Sustainability, etc. Their relevance depends on the sector. For a manufacturing outfit, the HR report is a red‑flag detector: any mention of strikes, labor shortages, or high turnover could foreshadow a factory shutdown (and a plummeting share price).  

---

## 3.3 – The Financial Statements  

At the bottom of the AR lies the **real meat**: the three statutory financial statements.  

| Statement | What it shows |
|-----------|---------------|
| **Profit & Loss (P&L)** | Revenue, expenses, and the bottom‑line profit (or loss) for the year. |
| **Balance Sheet** | Assets, liabilities, and shareholders’ equity at a specific date (31 Mar). |
| **Cash Flow Statement** | How cash moved in and out of the business (operating, investing, financing). |

We’ll dissect each of these in later chapters, but for now remember there are **two flavors** of every statement:  

1. **Standalone** – Only the parent company’s numbers (ignores subsidiaries).  
2. **Consolidated** – Parent + all subsidiaries (the “whole family” picture).  

### 3.3.1 Why Consolidation Matters  

Most big‑cap firms sit atop a web of subsidiaries, joint ventures, and holding companies. To illustrate, let’s peek at **CRISIL Limited** (the Indian credit‑rating giant).  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M3-Ch3-chart7.jpg)  

Key take‑aways from the diagram:  

- **S&P** (U.S. rating agency) owns **51 %** of CRISIL → S&P is the *promoter* or *holding company*.  
- The remaining **49 %** is split among public investors and financial institutions.  
- **S&P** itself is a **100 %** subsidiary of **McGraw‑Hill** (the publishing behemoth).  
- **CRISIL** wholly owns **Irevna** (another rating‑related outfit).  

Now imagine FY 2014 results:  

- **CRISIL** reports a **loss of ₹1,000 Cr** on its own books.  
- **Irevna** (its 100 % subsidiary) posts a **profit of ₹700 Cr**.  

**What’s the consolidated P&L?**  

\[
\text{Consolidated Loss} = (-₹1,000\text{ Cr}) + (+₹700\text{ Cr}) = -₹300\text{ Cr}
\]

So, the group’s loss shrinks from a frightening **₹1,000 Cr** to a (still uncomfortable) **₹300 Cr** thanks to the subsidiary’s earnings.  

**Bottom line:**  
- **Standalone statements** = only the parent’s numbers.  
- **Consolidated statements** = parent + all subsidiaries, giving a truer picture of the economic entity you actually own a slice of.  

My personal habit? I always start with the **consolidated** statements because they reflect the *real* cash‑generating power of the whole corporate family.  

---

## 3.4 – Schedules of Financial Statements  

When you flip to the core statements, you’ll see a tidy table of line items (e.g., “Share Capital”, “Term Loans”). Each line comes with a superscript number that points to a **note** (or *schedule*) at the back of the report. Those notes are the “footnotes” that explain how the number was derived, any accounting quirks, and sometimes the drama behind the figure.  

Here’s a snapshot of ARBL’s **Balance Sheet**:  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M3-Ch3-chart8.jpg)  

Notice the green arrow pointing to **Share Capital** (₹17.081 Cr). The tiny **2** next to it means you should flip to **Note 2** for details.  

And here’s the corresponding note:  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M3-Ch3-chart9.jpg)  

The note tells you *how* that ₹17.081 Cr was built—perhaps through a fresh issue, a bonus share split, or a rights offering. As an investor, you’ll want to know whether the capital base is solid or if the company is constantly diluting shareholders.  

If all this jargon feels like a foreign language now, don’t worry. The main statement gives you the *headline* numbers; the schedules are the *deep‑dive* you can explore later, once you’re comfortable with the basics. In upcoming chapters we’ll walk through reading these notes without needing a PhD in accounting.  

---

## Key Takeaways from This Chapter  

- The **Annual Report (AR)** is the company’s official, legally‑binding communication to shareholders and stakeholders.  
- For *any* investment decision, the AR should be your **default** source of information—not a third‑party blog or headline news.  
- An AR is a multi‑section document, each part shedding light on a different facet of the business (financials, strategy, governance, etc.).  
- The **Management Discussion & Analysis (MD&A)** is arguably the *most valuable* narrative: it captures the management’s view on macro‑economy, industry trends, past performance, and future outlook.  
- The AR houses the three core **financial statements**—Profit & Loss, Balance Sheet, and Cash Flow.  
- **Standalone** statements show only the parent company; **consolidated** statements roll in subsidiaries, offering a truer picture of the economic entity you’re buying into.  
- Every line item in the statements is backed by a **schedule/note** that explains the calculation, assumptions, and any quirks.  

Armed with this roadmap, you’re now ready to treat an Annual Report like a detective novel—skim the teaser, dig into the chapters that matter, and ignore the marketing fluff. Grab that PDF, pour yourself a drink, and let the numbers tell their story. Happy reading!