# 9. The Financial Ratio Analysis (Part 1)

**Source:** https://zerodha.com/varsity/chapter/financial-ratio-analysis/

---  

## 9.1 – A Note on Financial Ratios  

In the previous chapters we turned into forensic accountants, learning how to read balance‑sheets, P&L statements, cash‑flow statements, and everything in between. Now it’s time to put on our detective hat and *analyze* what those numbers really mean.  

The most popular (and arguably the most fun) way to do that is by using **Financial Ratios**.  The concept was popularised by Benjamin Graham – the grand‑daddy of fundamental analysis, who probably never imagined his ratios would end up on a meme page with a cat wearing glasses.  

A ratio is simply a number that combines two (or more) items from the financial statements.  Before we dive into the sea of percentages and multiples, let’s get a few housekeeping points out of the way.

> **Pro‑Tip:** A ratio by itself is about as informative as a single‑ingredient cocktail – you need the context (other ratios, peers, and history) to make it tasty.

### Why Ratios Need Friends  

Imagine Ultratech Cement Ltd. posts a profit‑margin of **15 %**.  That sounds decent, right?  But without a benchmark it’s like saying “I ran a marathon in 4 hours” – impressive *if* most people take 5 hours, but terrible *if* the world‑record is 2 hours.  

Now look at ACC Cement, which posted a **12 %** margin.  Suddenly Ultratech’s 15 % looks a bit shinier, because we have a comparable peer in the same industry.  In short, a ratio is mute unless you:

1. **Compare** it with a similar‑sized firm (peer comparison).  
2. **Track** it over time (trend analysis).  

Both give you the narrative you need to decide if the number is a hero or a zero.

### Accounting Policies – The “Fine Print”  

Be aware that companies can choose different accounting policies (e.g., depreciation methods, revenue recognition).  A diligent analyst normalises the data before cranking out ratios, otherwise you might be comparing apples to oranges… or apples to *apple juice*.  

---  

## 9.2 – Financial Ratios  

Financial ratios are loosely grouped into four families (think of them as the Hogwarts houses of finance):

| Category | What it tells you |
|----------|-------------------|
| **Profitability Ratios** | How good the company is at turning sales into profits. |
| **Leverage (Solvency) Ratios** | How much debt the firm is using to fund its growth and whether it can survive the long haul. |
| **Valuation Ratios** | How expensive (or cheap) the market thinks the stock is relative to fundamentals. |
| **Operating (Activity) Ratios** | How efficiently the firm turns its assets into revenue – essentially, “do they run a lean machine or a clunky tank?” |

![Profitability vs. Others](http://zerodha.com/varsity/wp-content/uploads/2014/10/M3-Ch9-image11.jpg)

### Profitability Ratios  
These are the “scoreboard” for management’s ability to generate earnings.  Strong profitability usually signals competent leadership, enough cash for expansion, and juicy dividends for shareholders.  

### Leverage (Solvency) Ratios  
Also called *gearing* ratios, they gauge a firm’s long‑term ability to meet its obligations.  High leverage can amplify returns—but also magnify risk, like a double‑espresso for your heart.  

### Valuation Ratios  
These compare the market price of a share to some measure of the firm’s earning power or asset base, letting you decide if the stock is a bargain or an over‑priced latte.  

### Operating (Activity) Ratios  
Sometimes called *Management Ratios*, they show how well the company uses its assets (both current and non‑current) to churn out revenue.  Think of it as the “speedometer” of the business.  

> **Note:** Because many ratios overlap (e.g., a profitability ratio can hint at operating efficiency), the classification is a bit fuzzy—hence the “somewhat loosely” phrasing.  

---  

## 9.3 – The Profitability Ratios  

Below are the profitability metrics we’ll dissect (don’t worry, I’ll keep the math friendly).  

| Ratio | What it measures |
|-------|-------------------|
| **EBITDA Margin** (Operating Profit Margin) | Operating profitability before interest, tax, depreciation, and amortisation. |
| **EBITDA Growth (CAGR)** | Compounded annual growth of EBITDA. |
| **PAT Margin** | Bottom‑line profitability after tax. |
| **PAT Growth (CAGR)** | Compounded annual growth of PAT. |
| **Return on Equity (ROE)** | Profit generated per unit of shareholder equity. |
| **Return on Assets (ROA)** | Profit generated per unit of total assets (adjusted for tax shield). |
| **Return on Capital Employed (ROCE)** | Profit generated per unit of total capital (debt + equity). |

### EBITDA Margin – The “Operating Profit” Party  

**EBITDA** = *Earnings Before Interest, Tax, Depreciation, and Amortisation*.  In plain English: it’s the cash‑flow‑ish profit you get after you strip out the “finance‑only” and “accounting‑only” items.  

**How to compute:**  

1. **Operating Revenues** = Total Revenue – Other Income  
2. **Operating Expenses** = Total Expense – Finance Cost – Depreciation & Amortisation  
3. **EBITDA** = Operating Revenues – Operating Expenses  
4. **EBITDA Margin** = EBITDA ÷ Operating Revenues  

> *Why exclude “Other Income”?* Because it’s usually one‑off, non‑core cash (think interest earned on a parking lot of cash). Including it would be like counting the points you get for a free pizza in a basketball game.

#### Example – Amara Raja Batteries Ltd (ARBL) FY 14  

| Item | Amount (₹ Cr) |
|------|----------------|
| Total Revenue | 3 482 |
| Other Income | 46 |
| **Operating Revenue** | **3 436** |
| Total Expense | 2 942 |
| Finance Cost | 0.7 |
| Depreciation & Amortisation | 65 |
| **Operating Expense** | **2 876.3** |
| **EBITDA** | **560** |

Now the **EBITDA Margin**:  

\[
\text{EBITDA Margin} = \frac{560}{3 436} \approx 16.3\%
\]

#### What does that mean?  

- **₹ 560 Cr EBITDA** tells us the firm kept that much cash from its core operations before paying interest, tax, etc.  
- **16.3 % margin** means 83.7 % of operating revenue was eaten by operating costs, leaving 16.3 % as “operating profit”.  

Is 16.3 % good?  Hard to say without a yardstick.  Look at the trend and peers:

| Year | EBITDA (₹ Cr) | EBITDA Margin |
|------|---------------|----------------|
| 2011 | 257 | 14.6 % |
| 2012 | 340 | 15.0 % |
| 2013 | 438 | 15.8 % |
| 2014 | 560 | 16.3 % |

The margin is **creeping upward**, and the **CAGR** for EBITDA over the four years is roughly **21 %** (we’ll revisit the CAGR formula later).  That’s a solid sign of improving operational efficiency.  

**Homework:** Grab the numbers for Exide Batteries Ltd (ARBL’s chief competitor) and see who’s really the “king of the hill”.  

### PAT Margin – The Bottom‑Line Verdict  

While EBITDA looks at the *operating* side, **PAT (Profit After Tax)** includes *everything* – interest, tax, depreciation, the whole shebang.  

\[
\text{PAT Margin} = \frac{\text{PAT}}{\text{Total Revenue}}
\]

For ARBL FY 14:  

- **PAT** = ₹ 367 Cr  
- **Total Revenue** (including other income) = ₹ 3 482 Cr  

\[
\text{PAT Margin} = \frac{367}{3 482} \approx 10.5\%
\]

#### Trend check  

| Year | PAT (₹ Cr) | PAT Margin |
|------|------------|------------|
| 2011 | 190 | 9.2 % |
| 2012 | 240 | 10.0 % |
| 2013 | 300 | 10.2 % |
| 2014 | 367 | 10.5 % |

A **CAGR of ~25.5 %** in PAT over four years signals robust earnings growth.  Again, compare with peers to see if ARBL is a market leader or just cruising in the middle of the pack.  

### Return on Equity (ROE) – Shareholder’s Reward  

ROE tells a shareholder how many rupees of profit they earn for every rupee of equity they’ve put in.  The formula is straightforward:

\[
\text{ROE} = \frac{\text{Net Profit}}{\text{Shareholders’ Equity}} \times 100
\]

**Why we love ROE:**  
- High ROE usually means management is using capital efficiently.  
- The *average* ROE of top Indian firms hovers around **14‑16 %**; many value‑investors hunt for **18 %+**.  

#### The Debt‑Leverage Trap  

Let’s illustrate with a pizza‑shop analogy (because who doesn’t love pizza?).

| Scenario | Equity (₹) | Debt (₹) | Total Assets (₹) | Net Profit (₹) | ROE |
|----------|-----------|----------|------------------|----------------|------|
| 1️⃣ All‑Equity | 10 000 | 0 | 10 000 | 2 500 | 25 % |
| 2️⃣ 20 % Debt | 8 000 | 2 000 | 10 000 | 2 500 | 31.25 % |
| 3️⃣ 50 % Debt | 5 000 | 5 000 | 10 000 | 2 500 | 50 % |

As debt rises, **ROE spikes**, but so does risk (interest payments, covenant breaches).  A sky‑high ROE can be a red flag if it’s driven by excessive leverage.

#### DuPont Analysis – The ROE Detective Kit  

The **DuPont Model** (born in the 1920s at DuPont Corp) deconstructs ROE into three intuitive parts:

\[
\text{ROE} = \underbrace{\text{Net Profit Margin}}_{\text{Profitability}} \times \underbrace{\text{Asset Turnover}}_{\text{Efficiency}} \times \underbrace{\text{Financial Leverage}}_{\text{Leverage}}
\]

| Component | Formula | What it shows |
|-----------|---------|----------------|
| **Net Profit Margin** | \(\frac{\text{Net Profit}}{\text{Net Sales}} \times 100\) | How much profit per rupee of sales (same as PAT margin). |
| **Asset Turnover** | \(\frac{\text{Net Sales}}{\text{Average Total Assets}}\) | How many rupees of sales you generate per rupee of assets. |
| **Financial Leverage** | \(\frac{\text{Average Total Assets}}{\text{Average Shareholders’ Equity}}\) | How much assets are financed by equity vs. debt. |

##### Applying DuPont to ARBL FY 14  

1. **Net Profit Margin** = 9.2 % (same as PAT margin).  
2. **Asset Turnover**  

   - Net Sales = ₹ 3 437 Cr (FY 14)  
   - Average Assets = \(\frac{1 770 + 2 139}{2} = 1 955\) Cr  
   - Asset Turnover = \(3 437 / 1 955 \approx 1.75\) times  

3. **Financial Leverage**  

   - Average Equity = \(\frac{1 059 + 1 362}{2} = 1 211\) Cr  
   - Leverage = \(1 955 / 1 211 \approx 1.61\) times  

Now plug them in:

\[
\text{ROE} = 9.2\% \times 1.75 \times 1.61 \approx 25.9\%
\]

That’s a *respectable* 25.9 % – far above the 14‑16 % “industry average”.  

**Quick‑calc shortcut:**  

\[
\text{ROE} = \frac{\text{PAT}}{\text{Average Equity}} \times 100 = \frac{367}{1 211} \times 100 \approx 30.3\%
\]

The slight difference comes from rounding and the fact that the DuPont method uses *average* numbers throughout.  

### Return on Assets (ROA) – Asset‑Efficiency Score  

ROA measures how many rupees of profit (adjusted for the tax shield on interest) you earn per rupee of assets.

\[
\text{ROA} = \frac{\text{Net Income} + \text{Interest} \times (1 - \text{Tax Rate})}{\text{Average Total Assets}}
\]

Why add interest after‑tax? Because interest is a financing cost, but the tax shield (the tax you save by deducting interest) effectively returns part of that cost to the firm.

**ARBL FY 14 numbers**  

- Net Income (PAT) = ₹ 367.4 Cr  
- Finance Cost (interest) = ₹ 7 Cr  
- Tax Rate (average) = 32 % → Interest after‑tax = \(7 \times (1-0.32) = 4.76\) Cr  
- Average Assets = 1 955 Cr  

\[
\text{ROA} = \frac{367.4 + 4.76}{1 955} \approx 19.0\%
\]

A 19 % ROA tells us the company is pretty good at turning its asset base into earnings.  

### Return on Capital Employed (ROCE) – The Whole‑Capital Profitability  

ROCE looks at profit generated per unit of *total* capital (debt + equity).  It answers the question: “Is the firm earning enough on the money it’s using, regardless of source?”

\[
\text{ROCE} = \frac{\text{Profit Before Interest & Taxes (EBIT)}}{\text{Total Capital Employed}}
\]

**Capital Employed** = Short‑term Debt + Long‑term Debt + Shareholders’ Equity  

**ARBL FY 14**  

| Component | Amount (₹ Cr) |
|-----------|---------------|
| EBIT (PBIT) | 537.7 |
| Short‑term Debt | 8.3 |
| Long‑term Debt | 75.9 |
| Equity | 1 362 |
| **Total Capital Employed** | **1 446.2** |

\[
\text{ROCE} = \frac{537.7}{1 446.2} \approx 37.2\%
\]

A **37 % ROCE** is excellent – the firm is generating more than a third of its capital back as operating profit each year.  

---  

### Key Takeaways (the “cheat‑sheet” you’ll actually read)

- **Ratios are clues, not conclusions.**  Always look at trends or peer groups.  
- **Four main families** – Profitability, Leverage, Valuation, Operating – each offers a different lens.  
- **EBITDA** = operating profit before interest, tax, D&A; **EBITDA margin** = EBITDA ÷ Operating Revenue.  
- **PAT margin** = bottom‑line profit ÷ total revenue; the ultimate profitability gauge.  
- **ROE** measures shareholder return; high ROE is great **unless** it’s driven by too much debt.  
- **DuPont Model** splits ROE into Net‑Profit‑Margin, Asset‑Turnover, and Financial‑Leverage – a superb diagnostic tool.  
- **ROA** tells you how efficiently assets generate earnings (incl. tax‑shielded interest).  
- **ROCE** evaluates returns on *all* capital (debt + equity), giving a holistic profitability picture.  
- **Debt matters:** high ROE + high leverage = a risky cocktail; enjoy responsibly.  
- **Always benchmark** – compare a company’s ratios with peers and with its own historical path.  

Armed with these ratios, you’re now ready to turn raw financial statements into actionable insight—just like a bartender turning spirits into a perfect Old Fashioned.  Cheers to smarter investing! 🍸