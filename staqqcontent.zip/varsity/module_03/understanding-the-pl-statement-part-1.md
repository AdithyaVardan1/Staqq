# 4. Understanding the P&L Statement (Part 1)

**Source:** https://zerodha.com/varsity/chapter/understanding-pl-statement-part1/

---  

## 4.1 – Overview of the financial statements  

Think of financial statements as a two‑player video game: one player **creates** the world, the other **plays** in it.  

| 🎮 Maker (the creator) | 🎮 User (the player) |
|------------------------|----------------------|
| Usually a number‑nerd with an accounting degree (think Chartered Accountant‑level wizardry). <br>‑ Writes journal entries, matches bills with receipts, tallies inflows vs. outflows, audits the whole mess. <br>‑ Goal: a crystal‑clear picture of the firm’s true financial health. | A curious explorer who just wants to *read* what the maker has drawn. <br>‑ No need to know the nitty‑gritty of every debit‑credit line. <br>‑ Goal: extract the story and decide what to do with it (buy, sell, hold, or just brag to friends). |

**Real‑life analogy:** Most of us can’t explain Google’s secret search‑algorithm sauce, yet we can type “best pizza near me” and get a list in two seconds. That’s the maker‑vs‑user gap in accounting.

A common myth is that a fundamental analyst must be a master‑chef of statement‑making. Truth be told, you only need to be a *taster*, not the one who cooked the stew. You read the numbers, not the ledger.

A company’s financial report is a **trio** of statements that together tell the whole saga:

1. **Profit & Loss (P&L) statement** – the income drama.  
2. **Balance Sheet** – the snapshot of assets, liabilities and equity.  
3. **Cash Flow Statement** – the river of cash in and out.  

In the next few chapters we’ll walk through each one from the *user* side of the screen. Grab popcorn; the story is about to get juicy.

---

## 4.2 – The Profit and Loss statement  

The P&L statement wears many nicknames (because accountants love variety): **Income Statement, Statement of Operations, Statement of Earnings**—pick whichever makes you feel fancy at a dinner party.  

What does it actually do? It chronicles everything that happened during a chosen period—usually a quarter or a full fiscal year. The key sections are:

- **Revenue** – the cash‑in from the core business.  
- **Expenses** – the cash‑out needed to earn that revenue.  
- **Tax & depreciation** – the obligatory “let‑the‑government‑have‑its‑share” and the accounting magic of spreading asset cost over years.  
- **Earnings per share (EPS)** – the bottom‑line figure every trader eyes.  

The best way to learn is to stare at a real‑world example. Below is the P&L of **Amara Raja Batteries Limited (ARBL)**. Let’s dissect every line like a forensic accountant with a magnifying glass and a sense of humor.

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M3-Ch4-chart1.jpg)

---

## 4.3 – The Top Line of the company (Revenue)  

When analysts rave about a firm’s “top line,” they’re simply pointing at the **revenue** row—the first thing you see on the P&L. Think of it as the company’s “gross paycheck” before anyone takes a bite.

### First glance at the header  

Before we dive into the numbers, let’s decode the header that sits atop the statement (yes, the little text block you might skim over while sipping coffee).

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M3-Ch4-chart2.jpg)

The header tells us three vital things:

1. **Period** – “Statement of P&L for the year ending March 31, 2014.”  
   → It’s an **annual** statement, not a quarterly teaser.  
   → Since the fiscal year ends on 31‑Mar‑2014, this belongs to FY 2013‑14 (aka FY14).  
2. **Units** – “All amounts in Rupee Million.”  
   → 1 Million INR = **10 Lakh** INR. Companies pick a unit that keeps the numbers tidy.  
3. **Layout** – The **left‑most column** shows the **current** year (FY14), and the **right‑most** column shows the **previous** year (FY13).  

### Line‑by‑line walk‑through  

| Item | FY 14 (₹ Million) | FY 13 (₹ Million) | What it really means |
|------|-------------------|-------------------|----------------------|
| **Sale of Products** | 38,041.27 | 32,940.00 | All battery sales (the core business). In crore terms: **₹ 3,804 Cr** vs **₹ 3,294 Cr**. |
| **Excise Duty** | **–400** | — | Government’s “thanks for selling batteries” tax. Subtract it to get net sales. |
| **Net Sales** | 34,403.27 | 29,440.00 | Revenue *after* excise duty. This is the number the P&L actually calls “Net Sales.” |
| **Sale of Services** | 30.90 | — | Likely battery‑maintenance contracts, warranty services, etc. |
| **Other Operating Revenues** | 2.10 | — | Incidental cash—think scrap metal, one‑off fees, or selling a spare part that isn’t a battery. |
| **Total Operating Revenue** | **3,436.30** | **2,959.00** | Sum of Net Sales, Services, and Other Ops Revenue. This is the celebrated “top line.” |

> **Quick math:** Net Sales (₹ 3,403 Cr) + Services (₹ 30.9 Cr) + Other Ops (₹ 2.1 Cr) = **₹ 3,436 Cr**. Yep, the numbers line up.

### Digging into the notes (the fine print)  

Remember those tiny superscripts you see next to line items? They point to **notes**—the accountant’s way of saying “there’s more to this story.” Note 17 explains the split‑up of “Net Revenue from Operations.”

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M3-Ch4-chart3.jpg)

Key nuggets from Note 17:

- **Sale of storage batteries (finished goods)** – ₹ 3,523 Cr (FY14) vs ₹ 3,036 Cr (FY13).  
- **Sale of storage batteries (stock in trade)** – ₹ 208 Cr vs ₹ 149 Cr. *Stock‑in‑trade* means you sold inventory that was produced in a previous year.  
- **Sale of home UPS (stock in goods)** – ₹ 71 Cr vs ₹ 109 Cr.  
- Adding the above gives the **Net Sales** of ₹ 3,403 Cr, exactly matching the P&L line.  
- **Services revenue** tallies with the ₹ 30.9 Cr shown earlier.  
- **Sale of process scrap** – ₹ 2.1 Cr, recorded under “Other operating revenue” because it’s not part of the core battery‑making business.  

If you compare FY13’s note, you’ll see the same categories but smaller numbers, confirming the company grew its battery sales year‑over‑year.

### “Other Income” – the side hustle  

Scrolling further down, ARBL reports **Other Income** of ₹ 45.5 Cr. Note 18 tells us where that cash sneaked in.

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M3-Ch4-chart4.jpg)

Typical components of “Other Income”:

- Interest earned on bank balances.  
- Dividend receipts from investments.  
- Insurance claim payouts.  
- Royalty income (maybe they licensed a battery‑design).  

Generally, this bucket is **small**—a nice garnish, not the main dish. If it balloons, it’s a red flag that the company might be relying on non‑core cash flows, which could be unsustainable.

**Total revenue** for FY14 = Operating Revenue (₹ 3,436 Cr) + Other Income (₹ 45 Cr) ≈ **₹ 3,482 Cr**.

---

### Key takeaways from this chapter  

- Financial statements are the **storybooks** that reveal a company’s financial health.  
- The **complete set** = Profit & Loss, Balance Sheet, Cash Flow Statement.  
- A **fundamental analyst** is a *user* of these books, not the *author*.  
- The **P&L** tells you **how much profit** (or loss) the firm made in the period under review.  
- Numbers in the P&L are **estimates**; firms can restate them later, and they always present *current* and *previous* year side‑by‑side.  
- The **top line** = **Revenue** (the first big number you see).  
- **Revenue from operations** is the core cash‑generating activity.  
- **Other operating income** = incidental earnings tied to the core business (e.g., scrap sales).  
- **Other income** = non‑operating cash (interest, royalties, etc.).  
- Adding **Net Revenue from Operations** and **Other Income** gives you the **total revenue** figure shown at the top of the P&L.  

Now that we’ve peeled back the curtain on the top line, you’re ready to move on to the **expense side** and see how that revenue gets whittled down to the bottom line. Stay tuned—next stop: the cost‑of‑goods‑sold roller coaster!