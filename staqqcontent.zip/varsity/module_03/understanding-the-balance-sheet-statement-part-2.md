# 7. Understanding the Balance‑Sheet Statement (Part 2)

**Source:** https://zerodha.com/varsity/chapter/understanding-balance-sheet-statement-part-2/

---  

## 7.1 – The Assets side of the Balance Sheet  

In the previous chapter we geek‑sprinted through the **liability** side (the “what we owe” column). Now it’s time to flip the table and look at the other half of the balance‑sheet – the **Asset** side. Think of assets as the goodies a company owns that help it make money, from the day it’s born until the day it retires (or gets acquired).  

Here’s a quick visual of what the asset side looks like:  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M3-Ch7-Chart1.jpg)

You’ll notice two big buckets:

| Bucket | What it means |
|--------|---------------|
| **Non‑current assets** | Stuff that sticks around for more than a year (think of it as the “long‑term furniture” of the business). |
| **Current assets** | Things that can be turned into cash within 12 months (the “quick‑cash snacks”). |

Both buckets contain a bunch of line‑items, each backed up by footnotes (the notes are the boring‑but‑necessary “fine print”). Let’s dive in, shall we?  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M3-Ch7-title1.jpg)

---

## 7.2 – Non‑current assets (Fixed Assets)

Remember the previous chapter’s spiel about assets that give benefits **beyond 365 days**? That’s exactly what lives in the **Non‑current** corner. An asset is essentially a resource that will keep the cash‑cow churning over its useful life.

### Fixed assets – the heavyweights  

Inside the non‑current section you’ll see a sub‑section called **Fixed Assets**. These are the items that aren’t easy to turn into cash – you can’t just toss a plant and machinery into a vending machine. Typical examples: land, factories, vehicles, buildings, etc. Intangible goodies (patents, trademarks, goodwill) also belong here because they deliver value for many years, even though you can’t touch them.

All the line‑items under Fixed Assets share **Note 10** – think of it as the “behind‑the‑scenes documentary” that explains the numbers.

Here’s the snapshot for **Amara Raja Batteries Ltd. (ARBL)**:

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M3-Ch7-Chart2.jpg)

| Line‑item | Value (₹ Cr) | What it really means |
|-----------|--------------|----------------------|
| **Tangible assets** | **619.8** | Physical stuff you can see, touch, and probably trip over (plants, machines, vehicles, buildings). |
| **Intangible assets** | **3.2** | Fancy legal rights – patents, copyrights, brand names – that you can’t hug, but they’re worth something. |

> **Side note:** When we talked about the P&L, we introduced **depreciation** – the accounting way of saying “this thing is getting old and less useful”. Depreciation spreads the purchase price over the asset’s useful life, and the cumulative amount shows up as **Accumulated Depreciation** on the balance sheet.

### From Gross Block to Net Block  

When a firm buys a machine, the raw purchase price is called the **Gross Block**. Over the years you subtract the accumulated depreciation and you end up with the **Net Block**:

```
Net Block = Gross Block – Accumulated Depreciation
```

*“Accumulated”* simply means “all the depreciation we’ve recorded since day one”.

So, when you see **₹ 619.8 Cr** (tangible) and **₹ 3.2 Cr** (intangible) on the balance sheet, those are already **net** numbers – they’re after the depreciation has been taken out.

Check out Note 10 for a deeper dive:

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M3-Ch7-Chart3.jpg)

At the top you’ll see the **Gross Block**, the **Depreciation/Amortisation**, and the resulting **Net Block**. The two Net‑Block figures highlighted line up perfectly with the balance‑sheet numbers – a nice little sanity check.

### Let’s peek under the hood – Tangible assets breakdown  

Scrolling down Note 10, you’ll find a table of everything the company actually owns:

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M3-Ch7-Chart4.jpg)

For example, **Buildings** appear as a line‑item. Here’s the snippet:

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M3-Ch7-Chart5.jpg)

- **FY 13 (31 Mar 13)**: Building value = **₹ 93.4 Cr**  
- **FY 14 additions**: **₹ 85.8 Cr** (new construction, expansions)  
- **FY 14 deductions**: **₹ 0.668 Cr** (demolition, impairment)

So the **gross** building figure for FY 14 is:

```
93.4 + 85.8 – 0.668 = 178.5 Cr
```

That blue‑highlighted number is the **gross block** for buildings. To get the **net** figure we must subtract accumulated depreciation:

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M3-Ch7-Chart6.jpg)

- **Depreciation up to FY 13**: **₹ 17.2 Cr**  
- **Depreciation for FY 14**: **₹ 2.8 Cr**  
- **Depreciation deduction (e.g., asset sold)**: **₹ 0.376 Cr**

Total depreciation = 17.2 + 2.8 – 0.376 = **₹ 19.736 Cr** (the red‑highlighted figure).

Now:

```
Net Block (Buildings) = Gross Block – Accumulated Depreciation
                       = 178.5 – 19.736 ≈ 158.8 Cr
```

That net number is highlighted in the next picture:

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M3-Ch7-Chart7.jpg)

The same arithmetic is repeated for every other tangible and intangible asset, ultimately giving the **Total Net Block** for the firm.

### Capital Work in Progress (CWIP) & Intangible Assets under Development  

After the big “Fixed Assets” block, you’ll see two more line‑items:

| Line‑item | Value (₹ Cr) | What’s the story? |
|----------|--------------|-------------------|
| **Capital work in progress (CWIP)** | **144.3** | Projects still under construction – think “building a factory that isn’t finished yet” or “machines being assembled”. Once complete, they move into the Tangible‑Assets bucket. |
| **Intangible assets under development** | **0.3** | The R&D version of CWIP – patents being filed, brand‑building campaigns, software in development, etc. |

Both are added to the overall **fixed‑asset** total once they’re “ready for prime time”.

---

## 7.3 – Non‑current assets (Other line items)

Fixed assets aren’t the only things that sit in the non‑current corner. Here’s a snapshot of the rest:

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M3-Ch7-Chart8.jpg)

| Line‑item | Value (₹ Cr) | What it means |
|----------|--------------|---------------|
| **Non‑current investments** | **16.07** | Long‑term stakes – could be equity in another firm, debentures, mutual‑fund holdings, etc. |
| **Long‑term loans & advances** | **56.7** | Money ARBL has lent out to group entities, employees, suppliers, etc., that won’t be repaid within the next year. |
| **Other non‑current assets** | **0.122** | Miscellaneous long‑term goodies that don’t fit elsewhere. |

A quick peek at Note 11 (partial view) gives you a feel for the investment details:

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M3-Ch7-Chart9.jpg)

---

## 7.4 – Current assets  

Now we jump to the **quick‑cash** side of the balance sheet. Current assets are the items a company expects to turn into cash (or consume) **within 365 days**. They keep the day‑to‑day engine humming.

Typical suspects: cash & cash equivalents, inventory, trade receivables, short‑term loans/advances, sundry debtors.

Here’s ARBL’s current‑asset snapshot:

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M3-Ch7-Chart10.jpg)

### Inventory – the “stock‑in‑the‑warehouse”  

- **Value:** **₹ 335.0 Cr**  
- What it contains: finished goods, raw material, work‑in‑progress (WIP).  

Note 14 breaks it down:

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M3-Ch7-Chart11.jpg)

The bulk is split between **Raw material** and **Work‑in‑progress**, which makes sense for a battery manufacturer.

### Trade Receivables (Accounts Receivable)  

- **Value:** **₹ 452.7 Cr**  
- This is the money ARBL expects to collect from distributors, dealers, and other customers who bought on credit.

### Cash & Cash Equivalents  

- **Value:** **₹ 294.5 Cr**  
- Cash = money in the till or in the bank.  
- Cash equivalents = ultra‑short‑term, highly liquid investments (think Treasury bills maturing in < 3 months).  

Note 16 shows the various bank accounts where the cash is parked:

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M3-Ch7-Chart12.jpg)

### Short‑term Loans & Advances  

- **Value:** **₹ 211.9 Cr**  
- Money the company has lent out (to suppliers, customers, employees, etc.) that is expected back within a year.

### Other Current Assets  

- **Value:** **₹ 4.3 Cr**  
- The “miscellaneous” bucket for small‑scale current‑asset items that don’t merit their own line.

### Putting it all together  

Add up the two sides:

```
Total Fixed Assets (Non‑current) = 840.831 Cr
Total Current Assets             = 1,298.61 Cr
------------------------------------------------
Grand Total Assets               = 2,139.441 Cr
```

That number **exactly matches** the total liabilities and shareholders’ equity – the hallmark of a balanced sheet.

A full‑sheet view:

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M3-Ch7-Chart13.jpg)

You’ll see the classic equation:

```
Assets = Shareholders’ Funds + Liabilities
```

We’ve now toured **both** sides of the balance sheet. In the next chapter we’ll sip on the **cash‑flow statement**, but first let’s talk about how the balance sheet and the P&L are BFFs.

---

## 7.5 – Connecting the P&L and Balance Sheet  

The profit‑and‑loss (P&L) and balance‑sheet are like two roommates sharing a flat: what one does affects the other. Below is a schematic that pairs typical P&L line‑items (left) with the balance‑sheet items they touch (right).

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M3-Ch7-Chart141.jpg)

### How the dance works  

| P&L Item | Balance‑Sheet Impact | Example |
|----------|---------------------|---------|
| **Revenue from Sales** | ↑ **Trade Receivables** (if credit sales) or ↓ **Cash** (if cash sales) | You sell batteries on credit → your receivables balloon. |
| **Operating Expenses** (raw material, wages, etc.) | ↑ **Trade Payables** (if bought on credit) and ↑ **Inventory** (if you stock raw material) | Buying copper for batteries on credit raises payables; the copper sits in inventory until you use it. |
| **Depreciation** | ↑ **Accumulated Depreciation** (a contra‑asset) | Plant and machinery lose value over time; the balance sheet shows it as a reduction from the gross block. |
| **Other Income** (interest, rent, etc.) | ↑ **Cash & Cash Equivalents** or ↑ **Investments** | You earn interest on a bank deposit → cash rises. |
| **Finance Cost / Borrowing Cost** | ↑ **Long‑term Debt** (if you take a loan) or ↑ **Interest Payable** (if you accrue interest) | You take a 5‑year loan → liability goes up, and interest expense shows on the P&L. |
| **Profit After Tax (PAT)** | ↑ **Retained Earnings** (part of shareholders’ equity) | The net profit stays in the business, bolstering equity. |

In short: every **sale**, **expense**, **investment**, or **financing decision** leaves footprints on the balance‑sheet.

---

### Key takeaways from this chapter  

- The **Asset side** shows everything the company owns (or is owed) that can generate future economic benefits.  
- Assets are split into **Non‑current** (long‑term) and **Current** (short‑term) categories.  
- **Non‑current assets** live longer than 365 days; **Current assets** are expected to be liquidated or used up within a year.  
- **Gross Block** = purchase price of an asset; **Net Block** = Gross – Accumulated Depreciation.  
- **Net Block = Gross Block – Accumulated Depreciation** (the classic “depreciation math”).  
- The **Total Assets** must always equal **Total Liabilities + Shareholders’ Equity** – that’s the “balance” in balance‑sheet.  
- The **Balance‑Sheet and P&L are inseparable twins**; changes in one reverberate in the other.  

That’s it for the asset side (and the whole sheet!). Next stop: the **cash‑flow statement**, where we’ll see the actual movement of cash in and out – the lifeblood that makes all those numbers meaningful. 🎉