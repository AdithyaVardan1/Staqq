# 12. The Investment Due Diligence  

**Source:** https://zerodha.com/varsity/chapter/investment-due-diligence/  

---  

## 12.1 – Taking stock  

Over the past few chapters we’ve been busy playing “financial‑statement bingo” – learning how to read balance sheets, income statements, cash‑flow statements, and then mixing a handful of ratios together like a financial cocktail. Those chapters gave us the **tool‑kit** we need for the grand finale of this module: **using fundamental analysis to spot the stocks that deserve a place in our portfolio**.  

If you remember, we once talked about *investable‑grade attributes*. Think of those as the “must‑have” criteria a company must clear before we hand over any hard‑earned rupees. In practice they’re just a checklist built on the company’s fundamentals. The more boxes a firm checks, the more “investment‑worthy” it looks.  

But— and here’s the twist— the checklist isn’t a one‑size‑fits‑all. What I flag as a red‑flag (say, corporate‑governance quirks) might be a tiny speck in your eye. One investor could shrug, “Everyone’s a little shady; as long as the numbers add up, I’m happy.” Another might treat governance like a health‑check‑up before a marathon.  

Bottom line: **there is no universal list**. Each of us must craft our own, based on personal experience, risk appetite, and what we actually care about. The only rule is that every item must be backed by solid logic, not by a horoscope. Later in this chapter I’ll share a “reasonably well‑curated” checklist that you can cherry‑pick from if you’re starting from scratch. Think of it as a friendly template, not a rigid law.  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/11/M3-Ch12-title1.jpg)  

## 12.2 – Generating a stock idea  

Before we start slapping checklists on everything, we first need a **stock that looks tasty enough to investigate**. In other words: how do we turn the ocean of listed companies into a manageable list of “maybe‑yes”? Below are the most common ways (feel free to mix‑and‑match like a DJ at a party).  

| Method | What it means | Real‑world example (my own) |
|--------|---------------|-----------------------------|
| **General Observation** | Keep your eyes, ears, and even your grandma’s gossip circle open. Notice what people are buying, what new storefronts are popping up, what tech gadgets are the talk of the town. Peter Lynch swears by it in *One Up on Wall Street*. | I first bought **PVR Cinemas** after seeing multiplexes sprouting like mushrooms in my city, **Cummins India** because every construction site I passed had a Cummins generator humming, and **Info Edge** after hearing everyone rave about Naukri.com. |
| **Stock Screener** | Plug numbers into a filter (ROE > 25%, PAT margin > 20%, etc.) and let the computer spit out a handful of candidates. It’s the “Google‑search” of investing. | I love Google Finance’s screener; a quick “ROE > 25 % & Debt/Equity < 0.5” gave me a shortlist that I later trimmed down with my own checklist. |
| **Macro Trends** | Scan the big‑picture economy: policy pushes, demographic shifts, geopolitical events. Then ask, “Which industries will ride this wave?” | India’s current infrastructure push makes **cement makers** look like potential gold mines. I’ll scan the cement index, then apply my checklist to see which firms are best positioned. |
| **Sectoral Trends** | Zoom into a specific industry and watch for sub‑segment growth or consumer‑taste changes. | The non‑alcoholic beverage space used to be “coffee, tea, water”. Lately, **energy drinks** have been stealing the limelight, so I’m scouting brands that are already dabbling in that niche. |
| **Special Situations** | Look for corporate events that could be catalysts: board appointments, spin‑offs, regulatory approvals, etc. | In 2013, **Cox & Kings** announced that Keki Mistry (the HDFC Bank guru) joined its advisory board. A friend thought, “That’s a stamp of credibility,” dug deeper, and rode a 200 % gain after the news filtered through the market. |
| **Circle of Competence** | Leverage your own professional know‑how. If you’re a doctor, you probably understand pharma better than a day‑trader; if you’re a banker, you get banking better than most. | A pediatrician I know invested early in **Fortis Healthcare** because she knew the nuances of the Indian hospital market better than any Wall Street analyst. |

The **trigger** for a deeper look can come from any of the above—or from that random tip your cousin’s neighbour’s dog walker gave you. Whenever a ticker catches your eye, add it to a **watch list**. A watch list is a living document; stocks may not meet your checklist today, but tomorrow’s business dynamics could change that. Review it regularly, and you’ll have a pipeline of ideas instead of scrambling for a “last‑minute” pick.  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/11/M3-Ch12-title21.jpg)  

## 12.3 – The Moat  

Now that you have a candidate, it’s time to put it through the **investment‑due‑diligence gauntlet**. Before you pull out the massive 10‑point checklist, let’s talk about the **moat**—the term Warren Buffett popularized to describe a company’s durable competitive advantage.  

A moat is like a medieval ditch filled with alligators: it keeps rivals at bay and protects the company’s long‑term earnings. The key is **sustainability**. A brand that can command premium pricing, own a massive market share, or enjoy regulatory headwinds that keep competitors out—those are classic moat characteristics.  

**Eicher Motors Ltd.** offers a textbook example. Its **Royal Enfield** bikes have a cult‑like following, sitting snugly between the pricey Harley‑Davidson and the budget‑friendly TVS. The brand’s heritage, distinctive design, and community‑driven marketing make it hard for a newcomer to steal its loyal riders. That brand moat gives Eicher a cushion of pricing power and market share protection.  

Other companies with recognizable moats include:  

- **Infosys** – low‑cost, high‑skill Indian talent (labour arbitrage) that lets it win large US contracts.  
- **Page Industries** – exclusive licence to manufacture and distribute **Jockey** innerwear in India.  
- **Prestige** – near‑monopoly on pressure‑cookers in the Indian kitchen‑appliance segment.  
- **Gruh Finance** – niche focus on micro‑loans to a segment that big banks often ignore.  

When you spot a **wide, sustainable moat**, you’ve essentially found a “wealth‑creating” engine. That’s the kind of company you want to keep on your radar (and eventually own).  

## 12.4 – Due Diligence  

The **equity‑research due‑diligence process** can be boiled down to three stages:  

1. **Understanding the Business** – read the annual report, watch earnings calls, talk to customers if you can.  
2. **Applying the Checklist** – test the firm against a set of performance and quality metrics.  
3. **Valuation** – estimate the intrinsic value (most commonly via Discounted Cash Flow).  

### Stage 1 – Understanding the Business  

You start by asking a **fundamental question**: *“What exactly does this company do?”*  

Instead of typing the company name into Google and skimming the Wikipedia teaser, dig into the **latest Annual Report** (or the investor‑relations section of the website). The report is the company’s own story, told in numbers, strategy, and risk disclosures.  

In my own practice, I gravitate toward businesses that operate in **low‑competition, low‑government‑intervention** spaces. Take **PVR Cinemas** as an example. When I first bought it, the Indian multiplex arena had only three listed players: PVR, INOX, and Cinemax. After PVR merged with Cinemax, only two listed names remained, making the market relatively insulated. Fast forward a few years and new entrants have appeared, prompting me to **re‑evaluate** the thesis.  

### Stage 2 – Applying the Checklist  

Once you’ve gotten comfortable with the company’s story, you pull out the **checklist**. Below is a **10‑point starter list** (feel free to add, subtract, or tweak as you gain experience):  

| # | Checklist Item | Why it matters |
|---|----------------|----------------|
| 1 | **Revenue growth consistency** (CAGR ≥ 10 % over 3‑5 years) | Shows the business can scale. |
| 2 | **ROE > 15 %** | Indicates efficient capital use. |
| 3 | **Debt‑to‑Equity ≤ 0.5** | Limits financial risk. |
| 4 | **Operating margin > 20 %** | Signals pricing power or cost advantage. |
| 5 | **Free cash flow conversion > 70 %** | Cash is king; profits that turn into cash are even better. |
| 6 | **Management track record** (stay‑on‑track with past guidance) | Good stewardship reduces execution risk. |
| 7 | **Strong moat** (brand, network, licences, etc.) | Protects long‑term earnings. |
| 8 | **Industry tailwinds** (macro or sectoral trends) | Provides a growth catalyst. |
| 9 | **Insider ownership ≥ 5 %** | Aligns management interests with shareholders. |
|10| **Transparent governance** (audit committee, independent directors) | Reduces the chance of nasty surprises. |

A company could ace every line above, yet still be a **bad buy** if the market price is too high. That brings us to the final stage.  

### Stage 3 – Valuation (DCF)  

The most widely‑used intrinsic‑value technique is the **Discounted Cash Flow (DCF) analysis**. In simple terms, you forecast the company’s future free cash flows, discount them back at an appropriate cost of capital, and sum them up. If the resulting present value is **higher than the current market price**, the stock is theoretically undervalued (a potential buy). If it’s lower, you might stay away—unless you have a compelling catalyst that the DCF missed.  

In the chapters ahead we’ll walk through a **step‑by‑step DCF framework**, plus a few complementary valuation tools (multiples, EV/EBITDA, etc.). For now, just remember: **valuation is the final sanity‑check** after you’ve understood the business and confirmed the moat.  

> **Pro‑Tip:** In practice, most investors spend **70 % of the time** on Stage 1 (research) and **30 %** on Stage 2‑3 (checklist & valuation). Skipping the deep‑dive is like buying a pizza without checking if it’s actually cheese.  

### What’s Next?  

Over the next few chapters we’ll flesh out the **Equity‑Research framework** in detail, focusing heavily on **Stage 2 (checklist) and Stage 3 (valuation)**. Stage 1, while critical, is mostly about gathering information—something you’ll get better at each time you open an annual report.  

### Key takeaways from this chapter  

- A stock idea can come from **any source** – from a coffee‑shop chat to a macro‑trend report.  
- **Circle of competence** and **general observation** are excellent starting points for newbies.  
- Keep a **watch list** of tickers that pique your curiosity; revisit it regularly.  
- Once you have a candidate, hunt for a **sustainable moat** before you get too excited.  
- The due‑diligence process consists of three pillars: **understanding the business, running a checklist, and valuing the firm**.  
- When you’re in Stage 1, be **thorough** – read the annual report, listen to earnings calls, and ask “What does this company actually do?”  
- **Iterate** on the checklist as you gain experience; a static list will soon become obsolete.  
- The **DCF method** remains one of the best ways to pin down a company’s intrinsic value.  
- **Circle of competence** and **general observation** are a great way to start.  

Happy hunting, and may your moats be deep and your valuations generous!  