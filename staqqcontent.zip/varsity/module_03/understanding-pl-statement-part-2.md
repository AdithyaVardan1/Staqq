# 5. Understanding P&L Statement (Part 2)

**Source:** <https://zerodha.com/varsity/chapter/understanding-pl-statement-part2/>

---  

##  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M3-Ch5-title2.jpg)

## 5.1 – The Expense Details  

In the last episode we ogled at the **revenue** side of the Profit‑and‑Loss (P&L) statement – the cash‑rain that makes a company grin.  
Now it’s time to talk about the other side of the coin: **expenses**. Think of them as the “taxes” you pay for living in the corporate world – everything from raw material bills to that fancy coffee machine in the break‑room.  

Expenses can be grouped **by function** (the “cost of sales” method) or **by nature** (what the money actually bought). Whichever way you slice it, every line in the P&L is usually backed up by a note, because regulators love footnotes more than a detective loves magnifying glasses. As the snippet below shows, almost every expense line has a little “see‑note‑19” whisper attached to it.  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M3-Ch5-chart1.jpg)

### Cost of Materials Consumed  

The very first expense line is **Cost of Materials Consumed** – basically the price tag on the raw stuff that gets turned into finished goods. For Amara Raja Batteries Limited (ARBL) this is the **biggest bite**:  

| FY | Cost of Materials (₹ Cr) |
|----|--------------------------|
| 2014 | **2,101** |
| 2013 | **1,760** |

Note 19 holds the nitty‑gritty. Let’s peek:  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M3-Ch5-chart2.jpg)

The note tells us the company gobbles up **lead, lead alloys, separators and a smorgasbord of other goodies** totalling the ₹ 2,101 Cr shown above.  

### Purchases of Stock in Trade & Change in Inventories  

The next two lines – **Purchases of Stock in Trade** and **Change in Inventories of Finished Goods, Work‑in‑Process & Stock‑in‑Trade** – both point to **Note 20**.  

* **Purchases of Stock in Trade** = the cash spent on buying finished goods ready for resale. ARBL shelled out **₹ 211 Cr**.  
* **Change in Inventories** = the cost of goods that were made in earlier years but only sold now. This appears as a **negative** (₹ (29.2) Cr) for FY‑14, meaning the company produced more batteries than it could push out the door that year.  

A negative number isn’t a “loss” here; it’s a **stock‑pile adjustment**. The firm will add this cost back to the expense line when the extra batteries finally find a buyer. In other words, the company is saying, “We made these batteries last year, we’ll count the cost when we actually sell them – not now.”  

Here’s a quick glance at Note 20:  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M3-Ch5-chart3.jpg)

Nothing cryptic – just the totals you need. When you dive into **financial modeling** later, you’ll learn how to pull these numbers apart like a seasoned sushi chef.  

### Employee Benefits Expense  

Next up: **Employee Benefits Expense** – salaries, PF contributions, health perks, the whole “we‑pay‑you‑to‑work‑for‑us” package. ARBL’s payroll tab reads **₹ 158 Cr** for FY‑14. The note (21) spells it out:  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M3-Ch5-chart4.jpg)

A quick mind‑blow: the firm churned out **₹ 3,482 Cr** in revenue but only spent **₹ 158 Cr** (≈ 4.5 %) on its people. That’s a skinny payroll, typical for non‑IT manufacturers. If you were dreaming of a “people‑first” startup, you might want to re‑think the numbers – or at least double‑check your assumptions!  

### Finance Cost / Borrowing Charges  

After payroll, we hit **Finance Cost** – the interest you pay when you borrow money. Think of it as the “price of borrowing a friend’s lawn mower”. ARBL’s finance cost is a modest **₹ 0.7 Cr** for FY‑14. We’ll unpack debt and balance‑sheet interplay later, but for now, note that the company isn’t spending a fortune on interest.  

### Depreciation and Amortization  

Now we arrive at the **Depreciation & Amortization** line, standing at **₹ 64.5 Cr**. To get why this exists, we need a crash‑course in **tangible vs. intangible assets**:  

| Type | Physical? | Example |
|------|-----------|---------|
| Tangible | Yes | Laptop, factory plant, delivery truck |
| Intangible | No | Brand name, patents, customer list |

Both kinds of assets **lose value over time** – that’s the “useful life” concept. A laptop might be useful for **4 years**; a patent perhaps **10 years**. Instead of dumping the entire purchase price into the current year’s profit, we **spread** it across its life. That spreading is **depreciation** (tangible) or **amortization** (intangible).  

**Illustrative Example** – Zerodha (a stock‑broking firm) makes ₹ 100,000 in a year but spends ₹ 65,000 on a high‑performance server that will serve for **5 years**. If we booked the whole ₹ 65,000 as an expense now, the profit would look like:  

```
Revenue  –  Expense  =  100,000 – 65,000 = 35,000
```

That would **under‑state** earnings because the server will keep delivering value for four more years. Instead, we **depreciate**:  

```
65,000 ÷ 5 = 13,000 per year
```

So the P&L shows:  

```
Revenue – Depreciation = 100,000 – 13,000 = 87,000
```

That’s a more honest picture of operating performance. The same logic applies to intangible assets (think of it as “amortization”).  

**Cash vs. Accounting** – While depreciation lowers accounting profit, the cash actually left the company’s bank account when the server was bought. The **cash‑flow statement** (coming up later) captures that outflow.  

Here’s the snapshot of **Note 23**, which details the depreciation numbers for ARBL:  

*(image omitted – same link as original)*  

### Other Expenses  

Finally we hit the **Other Expenses** bucket – a whopping **₹ 434.6 Cr**. That’s a big chunk, so we should peek under the hood.  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M3-Ch5-chart5.jpg)  
![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M3-Ch5-chart6.jpg)  
![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M3-Ch5-chart7.jpg)

The note tells us this bucket includes **manufacturing, selling, administrative** and other sundry costs. For example, ARBL splurged **₹ 27.5 Cr** on advertising and promotions.  

If you add up **all** the expense lines (materials, purchases, employee benefits, finance cost, depreciation, other expenses, etc.) you arrive at a total **₹ 2,941.6 Cr** – that’s what the company actually spent to keep the lights on in FY‑14.  

---

## 5.2 – The Profit Before Tax  

**Profit Before Tax (PBT)** is what you get after you’ve subtracted **all operating expenses** from revenue **but before** you hand over money to the taxman and interest‑paying folks.  

Formula:  

```
PBT = Total Revenues – Total Operating Expenses
```

Plugging ARBL’s numbers:  

```
Revenue            = ₹ 3,482 Cr
Operating Expenses = ₹ 2,941.6 Cr
--------------------------------
PBT (raw)          = ₹ 540.5 Cr
```

Hold your horses – there’s an **exceptional (extraordinary) item** of **₹ 3.88 Cr** that the firm treats as a one‑off (think a sudden lawsuit settlement or a fire‑sale of a plant). We subtract it:  

```
Adjusted PBT = 540.5 – 3.88 = ₹ 536.6 Cr
```

The P&L excerpt confirming the figure:  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M3-Ch5-chart8.jpg)

---

## 5.3 – Net Profit After Tax  

Now we march to the **bottom line** – **Net Profit After Tax (PAT)**, also called **Net PAT**. This is the money left after the government takes its share.  

The P&L snapshot shows the tax breakup:  

* **Current Tax** (corporate tax for the year) = **₹ 158 Cr**  
* **Other Taxes** (perhaps surcharge, cess, etc.) = **₹ 11.21 Cr**  

Total taxes = **₹ 169.21 Cr**  

Subtracting from the adjusted PBT:  

```
PAT = 536.6 – 169.21 = ₹ 367.4 Cr
```

That’s the amount that will ultimately flow to shareholders (after any preferred dividends).  

The statement also reports **Basic & Diluted EPS** – a metric investors adore. EPS tells you how much profit belongs to each ordinary share. ARBL’s numbers:  

* **Shares Outstanding** = 1,708,125,000 (≈ 17.08 Cr)  
* **PAT** = ₹ 367.4 Cr  

```
EPS = 367.4 ÷ 1,708.125 ≈ ₹ 21.5 per share
```

Snapshot of the EPS line:  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M3-Ch5-chart10.jpg)

---

## 5.4 – Conclusion  

We’ve now marched through every line on the **expense side** of the P&L, calculated **PBT**, and arrived at the **bottom‑line PAT** and **EPS**. Here’s the full picture for a quick sanity check:  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M3-Ch5-chart11.jpg)

If you stare at this long enough, it should start to make sense – each figure is backed by a note, each note tells a story. The P&L is not an isolated island; it’s tightly linked to the **Balance Sheet** (assets, liabilities, equity) and the **Cash‑Flow Statement** (actual cash in‑ and out‑flows). We’ll explore those relationships when we hit the next chapters.  

---

### Key Takeaways  

- The **expense side** of the P&L lists every cash‑outflow the firm incurred during the year.  
- Each expense line is usually explained in a **note** – dig into them for deeper insight.  
- **Depreciation** (tangible) and **Amortization** (intangible) spread the cost of assets over their useful life, keeping profit numbers realistic.  
- **Finance cost** is the interest paid on borrowed money; ARBL’s was a modest ₹ 0.7 Cr.  
- **PBT** = Revenue – Operating Expenses – Exceptional Items (if any).  
- **Net PAT** = PBT – All applicable taxes.  
- **EPS** = PAT ÷ Number of ordinary shares outstanding; it shows profit on a per‑share basis.  

Now that you’ve wrestled the P&L into submission, you’re ready to move on to **financial ratios**, **balance‑sheet analysis**, and the ever‑fascinating **cash‑flow statement**. Grab a drink, celebrate, and keep the learning rolling!