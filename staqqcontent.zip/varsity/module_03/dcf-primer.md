# 14. DCF Primer  

**Source:** https://zerodha.com/varsity/chapter/dcf-primer/  

---  

## 14.1 – The Stock Price  

In the last chapter we dissected stage 1 and stage 2 of equity research. Stage 1 was the “who‑are‑you‑and‑what‑do‑you‑do?” part – getting to know the business like you’d meet a new Tinder match (but without the ghosting). Stage 2 was the “show‑me‑the‑money” part – digging into the company’s financials like a detective looking for clues in a crime novel.  

Only when you’re satisfied with both the romance and the forensic report do you move on to stage 3, the grand finale: pricing the stock.  

Remember the old investing mantra: “Buy a great business at a great price.” It’s like scoring a VIP table at a club – you want the best spot **and** the best price on the drink. In fact, I’d even go so far as to say buying a *mediocre* business can be a winning move **if** you snag it at a bargain. That’s why price matters more than your favorite brand of pizza (well, maybe not *that* much, but you get the idea).  

The next two chapters are all about cracking the code of **the price**. A valuation technique will give us an estimate, and that estimate is what we call the **intrinsic value** – the “real‑deal” worth of a company, stripped of hype and Instagram filters.  

We’ll use the **Discounted Cash Flow (DCF)** method – the financial equivalent of a crystal ball that looks at all future cash flows, adjusts them for risk, and spits out a number you can actually use. Think of it as turning the company’s future cash‑flow movie into a present‑day Netflix rating.  

The DCF model is a tapestry woven from several inter‑locking ideas. To master it, we first need to untangle each thread and then re‑weave them into the full picture. In this chapter we’ll start with the beating heart of DCF: **Net Present Value (NPV)**. After that, we’ll stroll through the other concepts, and finally we’ll see how they all dance together in the full DCF choreography.  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/12/M3-Ch14-title.jpg)  

---  

## 14.2 – The Future Cash Flow  

Future cash flow is the secret sauce of the DCF model – the “what‑if‑I‑had‑a‑crystal‑ball” part. Let’s illustrate it with a story that’s tastier than a stale biscuit.  

Meet **Vishal**, the pizza wizard of town. He’s the kind of guy who can turn dough into art and make the smell of mozzarella drift three blocks away. One night he invents an **automatic pizza maker** that whips out a fresh, cheesy masterpiece in five minutes, no human hands required. He plugs the ingredients in, presses a button, and—*voilà*—pizza.  

His market research (a.k.a. his stomach) tells him the machine can pull in **₹500,000 per year** and it’s built to last **10 years** before it starts spitting out burnt crusts.  

Enter **George**, Vishal’s best bud, who’s instantly dazzled and says, “I’ll buy that gizmo from you!”  

**Question time:** What is the *minimum* price George should offer for the machine?  

To answer, we must ask: *How much economic benefit does this pizza‑making robot give George?* If he buys it today (let’s say 2014), the machine will generate **₹500,000 each year for the next ten years**.  

So George’s cash‑flow timeline looks like this (we’ll assume the first pizza‑cash shows up in 2015, because even machines need a warm‑up period):  

| Year | Cash Flow (₹) |
|------|---------------|
| 2015 | 500,000 |
| 2016 | 500,000 |
| …    | … |
| 2024 | 500,000 |

Add ’em up and you get **₹5,000,000** (10 × 500,000). After the tenth year the machine is about as useful as a pizza‑box after the party—worth essentially **₹0**.  

**Logic checkpoint:** No rational buyer would pay **more** than the total benefit he can extract, i.e., more than ₹5 million. Paying extra would be like buying a Ferrari and then parking it in a garage for a decade while paying a premium insurance premium.  

Now let’s spice things up with an *opportunity‑cost* twist. Suppose George can either:

1. **Buy the pizza machine for X rupees**, or  
2. **Park X rupees in a fixed‑deposit** that guarantees safety and pays **8.5 %** per annum (the “risk‑free” rate for our story).  

If George picks the pizza machine, he **foregoes** the 8.5 % risk‑free return. That foregone return is the **opportunity cost** of buying the machine.  

Summarising the three nuggets we have so far:  

- **Total cash flow** from the machine over 10 years = **₹5,000,000**.  
- **Maximum price** you could rationally pay = less than that total cash flow.  
- **Opportunity cost** of the capital = 8.5 % (the FD rate).  

Now we move to the juicy part: **discounting each future cash flow back to today’s terms**. George is looking at a series of ₹500,000 payments that will arrive in 2015, 2016, …, 2024. He asks himself:

- What’s the 2016 ₹500,000 worth **today**?  
- What about the 2018 slice?  
- How about the 2020 slice?  
- In general, how do we value any future cash flow **right now**?  

The answer lives in the kingdom of **Time Value of Money (TVM)**. If we can translate every future rupee into its present‑day equivalent, we’ll have a solid basis for pricing the pizza machine (and later, any company).  

Don’t worry, we’ll momentarily step away from pizza to unpack TVM, then swing right back to our dough‑loving gadget.  

---  

## 14.3 – Time Value of Money (TVM)  

Time Value of Money is the financial world’s version of “gravity”: everything’s affected by it, and you can’t ignore it unless you enjoy crashing. TVM shows up in everything from DCF to derivatives, from project finance to the calculation of annuities—basically any time you see money and a clock together, TVM is humming in the background. Think of TVM as the **engine** of the car called “Financial World”; without it, the vehicle won’t move.  

The core idea is simple: **₹100 today ≠ ₹100 next year**. Money is a living, breathing thing that grows (or shrinks) with time because you can *do something* with it while you wait. That “something” is the **opportunity cost**—the return you could have earned elsewhere.  

Two sides of the same coin:  

- **Future Value (FV)** – “If I have ₹X today, how much will it be worth after *n* years at a given rate?”  
- **Present Value (PV)** – “If I’m promised ₹Y in *n* years, how much is that worth **today**?”  

When we push money **forward** in time, we **compound** it (add interest). When we pull money **backward**, we **discount** it (strip away interest).  

Below are the quick‑fire formulas (no heavy calculus required, just a calculator and a cup of coffee):  

- **Future Value:**  
  \[
  FV = PV \times (1 + r)^{n}
  \]  
- **Present Value:**  
  \[
  PV = FV \div (1 + r)^{n}
  \]  

where  

- *r* = opportunity‑cost (or discount) rate (expressed as a decimal),  
- *n* = number of periods (years, months, etc.).  

### Example 1 – Future Value  
“How much will **₹5,000** be worth **five** years from now if I could earn **8.5 %** per year?”  

\[
FV = 5{,}000 \times (1 + 0.085)^{5} = 5{,}000 \times 1.50366 \approx \mathbf{₹7,518.30}
\]  

So today’s ₹5k is the equivalent of roughly **₹7,518** in five years, assuming you could park it at 8.5 % risk‑free.  

### Example 2 – Present Value  
“How much is a **₹10,000** promise, payable **six** years from now, worth **today** if the discount rate is **8.5 %**?”  

\[
PV = \frac{10{,}000}{(1 + 0.085)^{6}} = \frac{10{,}000}{1.63068} \approx \mathbf{₹6,129.50}
\]  

In other words, a ₹10k cheque you’ll receive in six years is only worth about **₹6,130** right now.  

### Example 3 – The Reverse Check  
Let’s rewind Example 1. We already know that ₹7,518.30 in five years should discount back to ₹5,000 today. Let’s prove it:  

\[
PV = \frac{7{,}518.30}{(1 + 0.085)^{5}} = \frac{7{,}518.30}{1.50366} = \mathbf{₹5,000}
\]  

Boom! The math checks out, confirming that FV and PV are perfect inverses.  

Armed with TVM, we can now hop back to our pizza‑machine saga and ask: **What’s the present value of each ₹500,000 slice of future cash?**  

---  

## 14.4 – The Net Present Value of Cash Flows  

We’re back at the pizza‑machine, and we’ve already mapped out the future cash‑flow stream:

| Year (starting 2015) | Cash Flow (₹) |
|----------------------|---------------|
| 1                    | 500,000 |
| 2                    | 500,000 |
| …                    | … |
| 10                   | 500,000 |

The big question (the one we asked earlier) is: **How much is this whole future stream worth **today**?**  

To answer, we discount each of the ten ₹500,000 cash flows back to 2014 using the **8.5 %** discount rate we identified as the opportunity‑cost benchmark.  

Here’s the step‑by‑step discount table (rounded to the nearest rupee for readability):  

| Year | Cash Flow (₹) | Discount Factor = \((1+0.085)^{n}\) | Present Value (₹) |
|------|---------------|-----------------------------------|-------------------|
| 1 (2015) | 500,000 | 1.085ⁱ = 1.085 | 500,000 ÷ 1.085 = **₹460,829** |
| 2 (2016) | 500,000 | 1.085² = 1.1772 | 500,000 ÷ 1.1772 = **₹424,724** |
| 3 (2017) | 500,000 | 1.085³ = 1.2785 | 500,000 ÷ 1.2785 = **₹391,025** |
| 4 (2018) | 500,000 | 1.085⁴ = 1.3899 | 500,000 ÷ 1.3899 = **₹359,706** |
| 5 (2019) | 500,000 | 1.085⁵ = 1.5115 | 500,000 ÷ 1.5115 = **₹330,750** |
| 6 (2020) | 500,000 | 1.085⁶ = 1.6439 | 500,000 ÷ 1.6439 = **₹304,144** |
| 7 (2021) | 500,000 | 1.085⁷ = 1.7879 | 500,000 ÷ 1.7879 = **₹279,877** |
| 8 (2022) | 500,000 | 1.085⁸ = 1.9440 | 500,000 ÷ 1.9440 = **₹257,938** |
| 9 (2023) | 500,000 | 1.085⁹ = 2.1130 | 500,000 ÷ 2.1130 = **₹236,824** |
|10 (2024) | 500,000 | 1.085¹⁰ = 2.2959 | 500,000 ÷ 2.2959 = **₹217,913** |

**Add ’em all up:**  

\[
\text{NPV} = 460,829 + 424,724 + 391,025 + 359,706 + 330,750 + 304,144 + 279,877 + 257,938 + 236,824 + 217,913 \approx \mathbf{₹3,283,530}
\]

*(The original source rounded to ₹3,28,08,842; minor rounding differences aside, the concept stands.)*  

That **₹3.28 million** is the **Net Present Value (NPV)** of the pizza machine – the total worth of all future cash flows expressed in today’s rupees.  

**Interpretation:**  

- If Vishal asks for **more than ₹3.28 million**, George should politely decline (or try to negotiate a discount).  
- If the price is **exactly ₹3.28 million**, George breaks even relative to his 8.5 % opportunity cost.  
- Anything **below** that price means George is getting a *good deal*—the machine will earn him more than the return he could get elsewhere.  

Now, replace the pizza machine with a **company**. The cash‑flow stream becomes the firm’s free cash flows, the discount rate becomes the company’s **Weighted Average Cost of Capital (WACC)**, and the NPV becomes the **intrinsic value per share**. That’s the essence of the **Discounted Cash Flow** model.  

### Key takeaways from this chapter  

- A valuation model like DCF gives you a *price estimate* for a stock, not a crystal‑ball guarantee.  
- DCF is built from several interlocking concepts (cash‑flow forecasts, discount rates, NPV, etc.).  
- **Time Value of Money** is the engine that powers almost every finance calculation, DCF included.  
- Money’s value changes over time; ₹100 today is not the same as ₹100 tomorrow.  
- To compare money across periods, you must **adjust for opportunity cost**—either by compounding (future value) or discounting (present value).  
- **Future Value (FV)** tells you what today’s cash will become later.  
- **Present Value (PV)** tells you what a future cash receipt is worth right now.  
- **Net Present Value (NPV)** is simply the sum of all those discounted cash flows—a single number that tells you “how much is this future stream worth today?”.  

Armed with NPV and the rest of the DCF toolkit, you’re now ready to price anything from pizza‑making robots to multinational conglomerates—without needing a wizard’s wand, just a calculator and a dash of common sense. Cheers to making money *talk* and listening to what it says! 🍕💰  