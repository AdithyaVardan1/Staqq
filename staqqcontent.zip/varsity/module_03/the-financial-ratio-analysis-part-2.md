# 10. The Financial Ratio Analysis (Part 2)

**Source:** <https://zerodha.com/varsity/chapter/financial-ratios-part-2/>

---  

##  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/11/M3-Ch10-title.jpg)

## 10.1 – The Leverage Ratios  

We already flirted with *financial leverage* when we dissected **Return on Equity** and the **DuPont** framework. Think of leverage (i.e. debt) as a two‑sided sword: wield it right and you look like a financial Jedi; misuse it and you’ll end up as a corporate Sith Lord with a mountain of interest payments.

Savvy firms only borrow when they can *earn* more on the borrowed cash than they have to pay in interest. In other words, the extra return on the new assets must beat the cost of the loan. When this works, equity holders get a nice boost in **ROE** because the same amount of shareholder money now supports a bigger asset base.

But beware the *thin line* between “good debt” and “bad debt.” Too much borrowing means interest starts chewing into the profit pie, leaving shareholders with smaller slices. That’s why we have **leverage ratios** – they give us a quick health‑check on how much debt a company is carrying and how comfortably it can service that debt.

We’ll walk through four classic leverage ratios:

| Ratio | What it tells you |
|-------|-------------------|
| **Interest Coverage Ratio** | Ability to meet interest obligations |
| **Debt‑to‑Equity Ratio** | Debt level relative to shareholders’ stake |
| **Debt‑to‑Asset Ratio** | Portion of assets funded by creditors |
| **Financial Leverage Ratio** | How many rupees of assets are supported per rupee of equity |

Previously we used **Amara Raja Batteries Ltd. (ARBL)** as our sandbox company. This time we need a firm that actually *has* debt on its balance sheet, so let’s roll up our sleeves for **Jain Irrigation Systems Ltd. (JISL)**. (Feel free to pick any other company you like and crunch the numbers yourself – the world is your spreadsheet!)

### Interest Coverage Ratio  

Also called the **Debt Service Ratio** or **Debt Service Coverage Ratio**, this metric answers the question: *“How many times can the firm pay its interest out of its operating earnings?”*  

- **High ratio** → plenty of cushion, the firm can comfortably service debt.  
- **Low ratio** → thin cushion, higher bankruptcy risk.

\[
\text{Interest Coverage Ratio} = \frac{\text{EBIT}}{\text{Interest Expense}}
\]

> **EBIT** = Earnings Before Interest and Tax = **EBITDA – Depreciation & Amortisation**  

Let’s plug in JISL’s FY‑14 numbers (finance costs highlighted in red in the image).  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/11/M3-Ch10-chart1.jpg)

1. **Calculate EBITDA**  
   - Revenue – Operating Expenses (excluding finance cost & D&A)  
   - Total expenses = ₹5,730.34 cr  
   - Finance cost = ₹467.64 cr  
   - D&A = ₹204.54 cr  

   \[
   \text{EBITDA}= 5,828.13 - (5,730.34 - 467.64 - 204.54) = 5,828.13 - 5,058.15 = \mathbf{₹769.98\;cr}
   \]

2. **Derive EBIT**  
   \[
   \text{EBIT}= \text{EBITDA} - \text{D\&A}= 769.98 - 204.54 = \mathbf{₹565.44\;cr}
   \]

3. **Interest expense** = ₹467.64 cr  

4. **Interest coverage**  
   \[
   \frac{565.44}{467.64}= \mathbf{1.209x}
   \]

The “x” is a multiplier, so JISL can generate **1.209 times** the earnings needed to cover each rupee of interest. Not spectacular, but at least it’s positive – the firm isn’t drowning yet.

---

### Debt‑to‑Equity Ratio  

This one is as straightforward as a “two‑plus‑two” math problem. Grab the two numbers from the balance sheet:

\[
\text{Debt‑to‑Equity} = \frac{\text{Total Debt}}{\text{Total Equity}}
\]

*Total Debt* = **short‑term borrowings** + **long‑term borrowings**.  

Here’s JISL’s balance sheet with the relevant boxes highlighted:

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/11/M3-Ch10-chart2.jpg)

- Long‑term borrowings = ₹1,497.663 cr  
- Short‑term borrowings = ₹2,188.915 cr  

\[
\text{Total Debt}=1,497.663+2,188.915= \mathbf{₹3,686.578\;cr}
\]

- Total equity = ₹2,175.549 cr  

\[
\text{Debt‑to‑Equity}= \frac{3,686.578}{2,175.549}= \mathbf{1.69}
\]

A ratio of **1.69** means the company carries roughly 1.7 rupees of debt for every rupee of shareholders’ equity – a fairly leveraged capital structure.

---

### Debt‑to‑Asset Ratio  

This ratio tells you what slice of the **total asset pie** is funded by creditors.

\[
\text{Debt‑to‑Asset}= \frac{\text{Total Debt}}{\text{Total Assets}}
\]

From the same balance sheet, total assets = ₹8,204.447 cr.

\[
\frac{3,686.578}{8,204.447}= \mathbf{0.449}\;\text{or}\;44.9\%
\]

So about **45 %** of JISL’s assets are financed with debt, the rest (≈55 %) comes from owners. The higher the percentage, the more “levered” and risk‑prone the firm looks.

---

### Financial Leverage Ratio  

Remember this from the DuPont chapter? It measures how many rupees of assets sit on each rupee of equity.

\[
\text{Financial Leverage}= \frac{\text{Average Total Assets}}{\text{Average Total Equity}}
\]

Using JISL’s FY‑14 figures:  

- Average total assets = ₹8,012.615 cr  
- Average total equity = ₹2,171.755 cr  

\[
\frac{8,012.615}{2,171.755}= \mathbf{3.68}
\]

Interpretation: For **₹1 of equity**, the firm controls **₹3.68 of assets** – a classic sign of leverage. The larger the number, the more the firm leans on debt.

---

## 10.2 – Operating Ratios  

Also known as **Activity** or **Management Ratios**, these numbers gauge how efficiently a company turns its assets into sales. In other words, they’re the “speedometer” for operational performance. We’ll calculate them for **Amara Raja Batteries Ltd. (ARBL)**, but feel free to swap in any peer you like.

> **Pro tip:** Always compare these ratios to industry peers *and* to the company’s own historical numbers. Otherwise you might be admiring a “fast” car that’s actually a cheap scooter.

### Fixed‑Assets Turnover  

This ratio asks: *“How many rupees of revenue do we earn per rupee invested in plant and equipment?”* Higher is better – it means the firm squeezes more sales out of its fixed‑asset base.

\[
\text{Fixed‑Asset Turnover}= \frac{\text{Operating Revenue}}{\text{Average Net Fixed Assets}}
\]

*Net fixed assets* = Gross fixed assets – accumulated depreciation + Capital work‑in‑progress (CWP).  

ARBL’s balance sheet snapshot:

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/11/M3-Ch10-chart4.jpg)

- FY‑13 net fixed assets = ₹461.847 cr  
- FY‑14 net fixed assets = ₹767.864 cr  

\[
\text{Average}= \frac{461.847+767.864}{2}= \mathbf{₹614.855\;cr}
\]

Operating revenue FY‑14 = ₹3,436.7 cr  

\[
\frac{3,436.7}{614.855}= \mathbf{5.59}
\]

So ARBL generates **₹5.59** of sales for every rupee locked in plant & equipment. A respectable number, especially for a capital‑intensive business.

> **Side note:** A rapidly growing firm may see its fixed‑asset base balloon year‑on‑year, temporarily depressing the turnover ratio. Keep that context in mind!

---

### Working‑Capital Turnover  

Working capital = **Current Assets – Current Liabilities**. It’s the cash‑ready money the firm needs to keep the day‑to‑day engine humming. The turnover ratio tells us how many rupees of revenue we earn per rupee of working capital.

\[
\text{Working‑Capital Turnover}= \frac{\text{Revenue}}{\text{Average Working Capital}}
\]

ARBL’s balance sheet (current assets in red, current liabilities in green):

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/11/M3-Ch10-chart5.jpg)

Compute working capital for FY‑13 and FY‑14, then average them (the numbers are already highlighted in the original source, so we’ll skip the arithmetic steps). The resulting average working capital = **₹672.78 cr**.

Revenue FY‑14 = ₹3,437 cr  

\[
\frac{3,437}{672.78}= \mathbf{5.11\;times}
\]

Interpretation: For every rupee of working capital, ARBL creates **₹5.11** of sales – a sign of efficient use of short‑term resources.

---

### Total‑Asset Turnover  

A broader sibling of the fixed‑asset turnover, this ratio looks at **all** assets (fixed + current) and asks: *“How much revenue do we generate per rupee of total assets?”*

\[
\text{Total‑Asset Turnover}= \frac{\text{Operating Revenue}}{\text{Average Total Assets}}
\]

ARBL’s total assets:  

- FY‑13 = ₹1,770.5 cr  
- FY‑14 = ₹2,139.4 cr  

\[
\text{Average}= \frac{1,770.5+2,139.4}{2}= \mathbf{₹1,954.95\;cr}
\]

\[
\frac{3,437}{1,954.95}= \mathbf{1.75\;times}
\]

So each rupee of assets produces **₹1.75** of revenue. Compare this with peers to see if ARBL is a lean‑machine or a lumbering giant.

---

### Inventory Turnover Ratio  

Inventory = the stock of finished goods (or raw material) waiting for a customer hug. The turnover ratio tells us **how many times the inventory is sold and replenished in a year**.

\[
\text{Inventory Turnover}= \frac{\text{Cost of Goods Sold (COGS)}}{\text{Average Inventory}}
\]

**Step 1 – COGS**  
From the profit‑and‑loss statement:

- Materials consumed = ₹2,101.19 cr  
- Purchases of stock‑in‑trade = ₹211.36 cr  
- Stores & spares = ₹44.94 cr  
- Power & fuel = ₹92.25 cr  

\[
\text{COGS}=2,101.19+211.36+44.94+92.25= \mathbf{₹2,449.74\;cr}
\]

**Step 2 – Average inventory**  
Balance‑sheet figures:  

- FY‑13 inventory = ₹292.85 cr  
- FY‑14 inventory = ₹335.00 cr  

\[
\text{Average}= \frac{292.85+335.00}{2}= \mathbf{₹313.92\;cr}
\]

**Turnover**  

\[
\frac{2,449.74}{313.92}= \mathbf{7.8\;times}
\]

Rounded, ARBL turns its inventory **about 8 times per year** – roughly once every 1.5 months.

---

### Inventory Number of Days  

The turnover ratio is nice, but sometimes you want a **calendar** view: *“How many days does each inventory cycle take?”*  

\[
\text{Inventory Days}= \frac{365}{\text{Inventory Turnover}}
\]

\[
\frac{365}{7.8}= \mathbf{46.8\;\text{days}} \approx 47\;\text{days}
\]

Thus ARBL needs **≈ 47 days** to convert its stock into cash. Shorter is usually better, but remember to benchmark against competitors.

#### A Thought Experiment  

Imagine a company with:

- **Very high inventory turnover** (so inventory days are low)  
- Yet **tiny production capacity** (they can’t make more product even if demand spikes)

What does this signal?

- The firm may be *selling* fast but can’t ramp up output → potential supply bottlenecks.  
- Why can’t they expand?  
  - Lack of funds?  
  - Bank unwillingness?  
  - Management track‑record issues?  
  - Raw‑material scarcity or regulatory constraints (coal, power, oil, etc.)?  

If any of those red flags appear, the shiny inventory numbers might be a mirage. Always dig into the **Management Discussion & Analysis** (MD&A) section of the annual report for clues about capacity, financing, and operational constraints.

---

### Accounts Receivable Turnover Ratio  

Now we flip from inventory to the money *owed* to the firm. This ratio measures **how many times per year the company converts its credit sales into cash**.

\[
\text{Receivable Turnover}= \frac{\text{Revenue}}{\text{Average Receivables}}
\]

ARBL’s receivables:  

- FY‑13 trade receivables = ₹380.67 cr  
- FY‑14 trade receivables = ₹452.78 cr  

Average (the source used 416.72 cr) → we'll keep that figure.

Revenue FY‑14 = ₹3,437 cr  

\[
\frac{3,437}{416.72}= \mathbf{8.24\;times}
\]

Interpretation: ARBL collects cash **about 8.2 times a year**, i.e., roughly every **1.5 months**.

---

### Days Sales Outstanding (DSO) – Average Collection Period  

DSO translates the turnover number into days, showing the average lag between invoicing and cash receipt.

\[
\text{DSO}= \frac{365}{\text{Receivable Turnover}}
\]

\[
\frac{365}{8.24}= \mathbf{44.3\;\text{days}} \approx 45\;\text{days}
\]

So ARBL needs **≈ 45 days** from the moment it raises an invoice to the moment the cash lands in the bank. A reasonable window for many industries, but always compare with peers.

> **Bottom line:** Receivable turnover and DSO together paint the picture of a firm’s credit policy. Too generous a credit line inflates sales but hurts cash flow; too tight a policy may choke sales.

---

### 🎯 Key Takeaways  

| Category | Ratios | What they Reveal |
|----------|--------|------------------|
| **Leverage** | Interest Coverage, Debt‑to‑Equity, Debt‑to‑Asset, Financial Leverage | How much debt a firm holds **and** whether it can meet interest and principal obligations |
| **Operating / Activity** | Fixed‑Asset Turnover, Working‑Capital Turnover, Total‑Asset Turnover, Inventory Turnover, Inventory Days, Receivable Turnover, DSO | How efficiently a firm uses **its assets** to generate sales and cash |
| **Specific Insights** | • Interest coverage > 1 → earnings exceed interest expense<br>• Debt‑to‑Equity > 1 → more debt than equity (higher risk)<br>• Debt‑to‑Asset ≈ 45 % → almost half of assets financed by creditors<br>• Financial leverage ≈ 3.7 → ₹3.7 assets per ₹1 equity<br>• Fixed‑Asset Turnover ≈ 5.6 → strong use of plant/equipment<br>• Working‑Capital Turnover ≈ 5.1 → good conversion of short‑term assets into sales<br>• Total‑Asset Turnover ≈ 1.75 → modest asset efficiency<br>• Inventory Turnover ≈ 8 × /year, **Inventory Days** ≈ 47 → inventory cycles roughly every month‑and‑a‑half<br>• Receivable Turnover ≈ 8.2 × /year, **DSO** ≈ 45 days → cash collected about every six weeks |
| **Cautions** | • High inventory turnover *doesn’t* guarantee production capacity – dig into financing and supply constraints.<br>• Leverage ratios must be read alongside cash‑flow statements; a good interest coverage today can evaporate if earnings fall.<br>• Always benchmark against industry peers and the firm’s own history. |

In short, leverage ratios tell you **how heavy the company’s debt load is**, while operating ratios reveal **how slickly the company runs its business**. Master both, and you’ll be the kind of investor who can spot a hidden gem (or a ticking time‑bomb) faster than you can finish a pint of craft beer. Cheers to smarter ratio‑watching! 🍻