# 3. Buying a Call Option  

**Source:** <https://zerodha.com/varsity/chapter/buying-a-call-option/>

---  

## 3.1 – Buying a Call Option  

In the earlier chapters we broke down what a call option *looks* like and we talked about the *when*‑and‑why of buying one. Now it’s time to roll up our sleeves, put on our “options‑nerd” hat, and actually walk through the mechanics of buying (and eventually selling) a call.  

Before we dive in, let’s do a lightning‑fast recap of the three golden rules we learned in Chapter 1:  

| # | Rule (in plain English) |
|---|--------------------------|
| 1️⃣ | **Buy a call when you think the underlying will go up.** Think of it as buying a ticket to a concert that you’re sure will sell out – you want to be in the front row when the price spikes. |
| 2️⃣ | **If the price stays flat or drops, the buyer loses money.** It’s like buying a movie ticket and then the theater decides to show a documentary about paint drying. |
| 3️⃣ | **Your loss is limited to the premium you paid.** That’s the “cover charge” you hand over to the writer of the option. No hidden bar tabs. |

Keep those three pearls of wisdom handy; they’ll be our compass as we explore the call option in more depth.  

---  

## 3.2 – Building a Case for a Call Option  

There are countless market scenarios that scream “buy a call!” – one of my recent “aha!” moments came while I was sketching a chart for this very chapter. Take a look at the picture below:  

![Bajaj Auto price chart](http://zerodha.com/varsity/wp-content/uploads/2015/03/Image-1_Bajaj-Auto-stock-price.jpg)

The star of the show is **Bajaj Auto Ltd.**, one of India’s biggest two‑wheeler manufacturers. Lately the stock has been bruised, trading down at its 52‑week low. That kind of price depression often hints at an *over‑reaction* – the market gets jittery, and the price may be screaming for a bounce.  

Here’s my mental checklist for why this could be a perfect call‑option playground:  

- **Fundamentals are solid.** Bajaj Auto has a strong balance sheet, good cash flows, and a brand that’s hard to forget (even after a bad haircut).  
- **The price has been hammered.** A deep discount could just be market panic, not a fundamental flaw.  
- **I expect the price to stop falling soon and start climbing.** In other words, I see a “bottom‑turn‑up” pattern forming.  
- **I’m not ready to buy the shares outright.** If the price falls a little more, I’d be stuck with a paper‑weight portfolio.  
- **Future contracts feel risky too.** Mark‑to‑market (M2M) losses could drain my account before the bounce even begins.  
- **I don’t want to miss a sharp reversal.** A call gives me upside exposure without the downside of owning the stock.  

So, I’m optimistic that Bajaj Auto will rally, but I’m also a little jittery about the short‑term turbulence. The question is: **How do I get the upside without the downside?**  

Enter the classic options solution – buying a call.  

Below is the option chain snapshot for Bajaj Auto on the day of writing:  

![Bajaj Auto option chain](http://zerodha.com/varsity/wp-content/uploads/2015/03/Image-2_Bajaj-Auto.jpg)

The spot price is **₹2,026.9** (the blue‑highlighted cell). I’m eyeing the **₹2,050 strike call** and the premium is **₹6.35 per share** (red box/arrow).  

> *You might wonder:* “Why the ₹2,050 strike? There are dozens of strikes, why not 2,040 or 2,060?”  

That’s a whole other rabbit hole – strike‑selection strategies deserve their own chapter. For now, let’s just assume ₹2,050 looks like a sweet spot for our trade.  

---  

## 3.3 – Intrinsic Value of a Call Option (At Expiry)  

Now the clock is ticking – the option expires in **15 days**. What can happen? In reality there are infinite price paths, but for teaching purposes we’ll bundle them into three tidy scenarios (you’ll recognize them from Chapter 1):  

| Scenario | Spot price at expiry | What we call it |
|----------|----------------------|-----------------|
| **1** | **> ₹2,050** (e.g., ₹2,080) | **In‑the‑money** – the stock out‑runs the strike. |
| **2** | **< ₹2,050** (e.g., ₹2,030) | **Out‑of‑the‑money** – the stock lags behind. |
| **3** | **= ₹2,050** | **At‑the‑money** – dead‑heat. |

You already know how to compute P&L for each of those three buckets, but let’s broaden the lens:  

- **What about every price between ₹2,050 and ₹2,080?**  
- **What about every price between ₹2,030 and ₹2,050?**  

In other words, we need a *continuous* picture of profit/loss, not just three isolated points.  

The concept that helps us do that is the **Intrinsic Value (IV)** of the option *at expiry*. For a call, IV is simply the **non‑negative** amount you’d pocket if you exercised the option right then and there:  

\[
\text{IV} = \max\bigl[0,\; \text{Spot} - \text{Strike}\bigr]
\]

*Example:* If Bajaj Auto closes at **₹2,068** on expiry, the ₹2,050 call’s IV is  

\[
2,068 - 2,050 = 18
\]

If the stock ends at **₹2,025**, the raw difference is \(-25\), but IV can’t be negative, so we set it to **0**.  

Keeping IV front‑and‑center lets us compute the buyer’s profit for **any** expiry spot price.  

---  

## 3.4 – Generalizing the P&L for a Call‑Option Buyer  

Armed with the IV formula, let’s build a quick table that shows the buyer’s net profit for a handful of plausible expiry spots. Remember: we paid **₹6.35** for the option, and that outlay is a *fixed* cost no matter where the spot lands.  

| Spot (₹) | Intrinsic Value (₹) | Net P&L = IV – Premium |
|----------|--------------------|------------------------|
| 2,023 | 0 (since 2,023 < 2,050) | 0 – 6.35 = **‑6.35** |
| 2,055 | 5 (2,055 – 2,050) | 5 – 6.35 = **‑1.35** |
| 2,072 | 22 | 22 – 6.35 = **+15.65** |

A few observations pop out of the table (and they line up with the “generalizations” we hinted at earlier):  

1. **Maximum loss = premium paid.** Even if the stock collapses to zero, the worst‑case loss is the ₹6.35 you shelled out.  
2. **Profit climbs linearly once you’re above the strike** – the farther the spot drifts beyond ₹2,050, the bigger the payoff. (Technically it’s *linear*, not exponential; the “exponential‑feel” comes from the steep slope on a graph.)  
3. **A breakeven point exists.** That’s the spot where IV just equals the premium, i.e. where you walk away with a zero net P&L.  

Let’s compute that **breakeven (B.E.)** formally:  

\[
\text{B.E.} = \text{Strike} + \text{Premium}
           = 2,050 + 6.35
           = 2,056.35
\]

Plug‑in the numbers to verify:  

\[
\text{IV at }2,056.35 = 2,056.35 - 2,050 = 6.35 \\
\text{Net P&L} = 6.35 - 6.35 = 0
\]

So, any spot **above** ₹2,056.35 yields a *real* profit, while any spot **below** that leaves you in the red (or flat at the exact strike).  

Here’s the compact formula that captures everything in one line:  

\[
\boxed{\text{P&L} = \max\bigl[0,\; \text{Spot} - \text{Strike}\bigr] - \text{Premium}}
\]

Feel free to plug any spot value you like into that expression – it will spit out the exact profit or loss.  

---  

## 3.5 – Call‑Option Buyer’s Payoff  

Let’s recap the key takeaways, this time with a sprinkle of bar‑room wisdom:  

| # | What the buyer experiences |
|---|-----------------------------|
| **1** | **Maximum loss = premium** (₹6.35). As long as the spot stays **≤ strike**, you’re out the premium and nothing more. |
| **2** | **Unlimited upside** – every rupee the spot climbs *above* the strike adds a rupee to your profit (after you’ve covered the premium). |
| **3** | **Breakeven point** = strike + premium (₹2,056.35). Only beyond this does the trade become truly profitable. |
| **4** | **Losses shrink** as the spot moves from the strike toward the breakeven. Think of it as a “pain‑relief” zone. |
| **5** | **Profit curve** is a straight‑line with a kink at the strike, then a steeper line after the breakeven – classic “limited‑risk, unlimited‑reward” shape. |

And just to give you a visual treat, here’s the payoff diagram for our Bajaj Auto call:  

![Payoff chart](http://zerodha.com/varsity/wp-content/uploads/2015/03/Image-3_Payoff.jpg)

Read the chart like you’d read a cocktail menu:  

- **Left side (spot < 2050)** – flat loss of ₹6.35.  
- **Between 2050 and 2056.35** – the loss *shrinks* as the spot climbs.  
- **At 2056.35** – you break even (the “zero‑calorie” drink).  
- **Beyond 2056.35** – profit line shoots upward, steeper than a roller‑coaster drop.  

Bottom line? As a call buyer you walk away with **capped downside** (the premium) and **uncapped upside** (the stock’s rally).  

---  

### Key Takeaways from This Chapter  

- Buying a call is sensible **when you expect the underlying price to rise**.  
- If the price stays flat or falls, the buyer **loses the premium**.  
- The premium is the **maximum loss** you can suffer.  
- **Intrinsic Value (IV)** is always non‑negative:  

  \[
  \text{IV} = \max\bigl[0,\; \text{Spot} - \text{Strike}\bigr]
  \]

- **Breakeven point** = **Strike + Premium**. Only above this level does the trade generate profit.  
- The call buyer’s profit curve is **limited‑risk, unlimited‑reward**.  
- The compact P&L formula is  

  \[
  \text{P&L} = \max\bigl[0,\; \text{Spot} - \text{Strike}\bigr] - \text{Premium}
  \]

- In our Bajaj Auto example:  

  - Premium = ₹6.35  
  - Strike = ₹2,050  
  - Breakeven = ₹2,056.35  

- Remember the three scenarios (above strike, below strike, at strike) and the “in‑between” continuum we just explored.  

That’s it for the buyer’s side of the story. In the next chapter we’ll flip the script and see what it feels like to *sell* a call – think of it as being the bartender who collects the cover charge but risks having to pour a pricey drink if the party gets wild. Cheers!  