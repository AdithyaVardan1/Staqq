# 19. Vega  

**Source:** <https://zerodha.com/varsity/chapter/vega/>  

---  

## 19.1 – Volatility Types  

The previous chapters gave us a crash‑course on volatility – what it is, how to compute it, and how to squeeze it into a trading plan.  
Now it’s time to swing back to the main event: the fourth Option Greek, **Vega**.  
But before we jump into the math, I have to pay homage to a certain cinematic legend – Quentin Tarantino. 🎬  

If you haven’t met Tarantino, think of him as the culinary master of Hollywood who serves up *Pulp Fiction*, *Kill Bill*, *Reservoir Dogs*, *Django Unchained* and a host of other cult classics. I’m a self‑confessed fan – I’ve watched his movies more times than I’ve checked my own trading P&L (and that’s saying something).  

Tarantino’s hallmark? He keeps every detail under lock‑and‑key until the trailer drops. Then the world finally learns the title, the cast, the plot, the shooting location… all the juicy bits.  

Enter his newest project (as of the writing of the original article): **“The Hateful Eight”**, slated for a December 2015 release. Unlike his previous films, the whole shebang—cast, story, location—has already been leaked. So the market (read: the movie‑going public) is already buzzing with speculation about how the box office will behave.  

Let’s break down those speculations the way a quant would break down volatility:  

| Perspective | What the “analysts” are saying |
|-------------|--------------------------------|
| **Past Movies** | Tarantino’s track record is basically a string of hits. By historical precedent, “The Hateful Eight” should be a blockbuster. |
| **Professional Film Forecasts** | Some Hollywood forecasters argue that because everything’s already known, the film won’t have the mystery factor that fuels excitement, so it could under‑perform. |
| **Social‑Media Sentiment** | Twitter, Facebook, Reddit – the chatter is largely positive. The crowd’s hyped, which points toward a hit. |
| **Actual Outcome** | Until the opening weekend, we can’t know for sure. The final verdict will be written on the box‑office receipts. |

We’re not here to predict the movie’s earnings (though I’ll be there with popcorn), but the analogy helps us introduce the three flavors of volatility that traders actually use: **Historical Volatility (HV), Forecasted Volatility (FV), and Implied Volatility (IV).**  

### Historical Volatility – the “Past‑Movies” Approach  
Think of it as judging the future performance of “The Hateful Eight” by looking at how *Pulp Fiction* and *Kill Bill* did. In markets, we take a series of past closing prices, plug them into the formula we learned in Chapter 16, and get a number that tells us how wildly the price has moved **so far**. It’s easy to compute, quick to apply, and gives a “rough‑and‑ready” estimate you can feed into an options‑pricing calculator.  

### Forecasted Volatility – the “Analyst‑Forecast” Approach  
This is the market’s version of a film‑analyst’s crystal ball. Instead of just staring at the past, we build statistical models (think GARCH, ARIMA, or whatever the latest paper is bragging about) to **predict** how choppy the market will be over a future window. Why bother? Because many option strategies (think long straddles, short strangles, volatility‑sell spreads) make money **only** if the volatility ends up where you think it will. If you think volatility will jump 12.34 % over the next seven trading sessions, you can line up a trade that profits from that move – no need to guess the direction of the market itself.  

A quick reality check: professional options traders often say that **volatility forecasting is easier (and more profitable) than trying to guess whether the market will go up or down**.  

If you want a concrete model, start with the classic **GARCH(1,1)** (or its cousin GARCH(1,2)). It’s spooky‑sounding, but it’s basically “the market is sometimes volatile, sometimes calm, and we’ll let yesterday’s surprise and yesterday’s volatility tell us what today might look like.”  

### Implied Volatility – the “Social‑Media Buzz” Approach  
Now imagine the whole internet buzzing about “The Hateful Eight.” Whether the hype is justified or not, the chatter gives you a *consensus* view of how big the movie will be. In options, that consensus is captured by **Implied Volatility (IV)** – the market’s collective expectation of how much the underlying will swing **over the remaining life of the option**.  

IV is baked right into the option premium. In practice, traders care about IV **more** than historical or forecasted volatility because it tells you what *everyone* is paying for the “right” to move.  

> **Fun fact:** The NSE’s **India VIX** is the Indian version of the famous VIX “Fear Index.” It’s calculated from the order‑book of Nifty options (near‑month and next‑month strikes) and reflects the market’s expectation of volatility over the next 30 calendar days.  

A quick cheat‑sheet on India VIX (taken from the NSE white‑paper):  

- Computed from the best bid‑ask of Nifty options (near‑month + next‑month).  
- Expressed as an annualised percentage, not a point level like NIFTY itself.  
- Higher VIX → higher expected volatility (and vice‑versa).  
- When markets get jittery, VIX spikes; when calm, VIX retreats.  
- Often called the “Fear Index” because a soaring VIX signals that investors should buckle up.  

You can also see implied volatilities for individual strikes on the option chain (e.g., the Cipla chain screenshot below). Those numbers are derived from a standard options‑pricing model (Black‑Scholes or its variants).  

![Cipla option chain with IVs highlighted](http://zerodha.com/varsity/wp-content/uploads/2015/09/Image-1_IV.png)  

**Realized Volatility** is the eventual, post‑mortem version of our movie analogy – the actual volatility that *did* happen over the life of the option, revealed only after expiry. It’s useful when you want to compare today’s IV with what actually unfolded. We’ll revisit that when we talk about concrete option‑trading strategies.  

![Cartoon illustration of volatility concepts](http://zerodha.com/varsity/wp-content/uploads/2015/09/M5-Ch19-cartoon.png)  

---  

## 19.2 – Vega  

Ever noticed that when a thunderstorm rolls in, the voltage at home starts doing the electric slide? The surge protectors start screaming, and you’re suddenly terrified that your fancy TV will turn into a very expensive paperweight.  

Volatility does the exact same thing to a stock’s price. Imagine a stock sitting pretty at ₹100. If volatility spikes, that price can now swing anywhere from ₹90 to ₹110 (or even wider).  

- **When the price drops to ₹90**, all the *put* writers start sweating like they’re in a sauna, because their puts are now deep in‑the‑money.  
- **When the price jumps to ₹110**, the *call* writers get the same sweaty feeling, because their calls are now deep in‑the‑money.  

**Bottom line:** When volatility rises, the probability of *either* side ending up in‑the‑money goes up, so **option premiums inflate**.  

### A concrete example  

Suppose you’re eyeing 500 CE (call) options on a stock that’s trading at 475, with 10 days left to expiry. There’s no intrinsic value (the strike is above the spot), but there’s time value. Let’s say the market is quoting the premium at **₹20**.  

- **If you’re comfortable with volatility staying tame**, you could sell those 500 calls, collect ₹20 × 500 = ₹10,000, and hope the stock stays flat.  

- **But what if an election, earnings season, or a sudden geopolitical event is about to crank volatility up?** Suddenly the same 475‑strike call could be worth ₹30 or even ₹40 because the market now expects larger swings.  

Now you have a dilemma: do you still write the call for ₹20? Probably not, because the upside risk (the call finishing in‑the‑money) has just ballooned. The only way you’d be enticed to write is if the premium were higher—say ₹30‑₹40—compensating you for that extra risk.  

That’s exactly what happens in the real world: **When volatility is expected to rise, option writers demand higher premiums**.  

The two charts below illustrate the point nicely.  

![Call premium vs volatility (different expiries)](http://zerodha.com/varsity/wp-content/uploads/2015/09/Image-2_CE.png)  

![Put premium vs volatility (different expiries)](http://zerodha.com/varsity/wp-content/uploads/2015/09/Image-3_PE.png)  

- **X‑axis:** Volatility (in %).  
- **Y‑axis:** Premium (₹).  

You’ll see that as volatility climbs, the premium line shoots upward for both calls and puts. The colour‑coded lines show how the effect varies with time‑to‑expiry:  

| Line colour | Days to expiry | Example premium shift (15 % → 30 % vol) |
|-------------|----------------|----------------------------------------|
| **Blue**    | 30 days (start of series) | ₹97 → ₹190 (**≈ 95.5 %** increase) |
| **Green**   | 15 days (mid‑series) | ₹67 → ₹100 (**≈ 50 %** increase) |
| **Red**     | 5 days (near expiry) | ₹38 → ₹56 (**≈ 47 %** increase) |

A few take‑aways from those numbers:  

1. **Volatility doubles (15 % → 30 %) and premiums rise dramatically**, especially when you have many days left.  
2. **Even a modest volatility bump (say 20‑30 % move)** will cause a proportional premium move – the relationship is roughly linear for small changes.  
3. **Time matters:** The earlier you are in the option’s life, the *more* premium you get for a given volatility surge. Near expiry, the premium still rises with volatility, but the effect is muted.  

So, *how much* does a premium move when volatility moves? That’s the job of **Vega**.  

### Vega defined (in layman’s terms)  

> **Vega = the change in an option’s price for a 1 % change in implied volatility.**  

Because higher volatility always makes an option *more* valuable (the chance of ending up ITM goes up), Vega is **positive** for both calls and puts.  

- If an option has a Vega of **0.15**, a 1 % rise in IV will bump its theoretical value by **₹0.15**.  
- Conversely, a 1 % drop in IV will shave **₹0.15** off the price.  

That’s all there is to it – a single number that tells you the premium’s sensitivity to the market’s “fear factor.”  

---  

## 19.3 – Taking Things Forward  

Let’s take a quick “rewind” of our Options‑Trading saga so far:  

1. **Option Basics** – What they are, how they’re structured, buyer vs. seller viewpoints.  
2. **Moneyness** – In‑the‑money, at‑the‑money, out‑of‑the‑money, and why those labels matter.  
3. **Greeks 101** – Delta, Gamma, Theta, and now Vega, plus a crash course on the Normal Distribution and Volatility.  

So far we’ve treated each Greek in isolation. In reality, **all Greeks act simultaneously**. The market can be moving, volatility can be exploding, liquidity can be draining, and the clock is ticking—all at once. For a rookie, that can feel like stepping into a casino where the dealer is also the house‑edge calculator.  

When you hear someone dismiss the markets as a “casino”, point them toward this Varsity – we’re not gambling, we’re modeling!  

What matters now is that **premium = f(Delta, Gamma, Theta, Vega, …)** and these sensitivities change *second‑by‑second*. The next chapter will dive into those *inter‑Greek* interactions, and we’ll also get our hands dirty with the **Black‑Scholes** pricing formula.  

---  

## 19.4 – Flavors of Inter‑Greek Interactions  

*(Excerpt originally published in *Business Line*, 31 August 2015)*  

On **24 August 2015**, the Indian equity market took a tumble of **≈ 5.92 %** – one of the worst single‑day drops in Indian market history. All the big‑cap stocks fell 8‑10 %, and panic was the order of the day.  

What made the options market behave oddly that day? Let’s look at the numbers:  

- **Nifty** fell **4.92 %** (≈ 490 points).  

  ![Nifty drop chart](http://zerodha.com/varsity/wp-content/uploads/2015/09/Image-4_Nifty.png)  

- **India VIX** surged **64 %**.  

  ![VIX spike chart](http://zerodha.com/varsity/wp-content/uploads/2015/09/Image-5_Vol.png)  

- **Call option premiums** – contrary to intuition, many of them *rose*.  

  ![Option chain premium jump](http://zerodha.com/varsity/wp-content/uploads/2015/09/Image-6_Options-chain.png)  

Normally, when the market crashes, call premiums drop because their **Delta** is positive: a falling underlying drags the call price down. Indeed, the deep‑in‑the‑money calls (strike < 8600) behaved as expected and lost value.  

However, the out‑of‑the‑money (OTM) calls (strike > 8650) showed a **different story**: their premiums *increased* by **50‑80 %** despite the market plunge.  

Why? Two Greek‑driven forces at play:  

1. **Delta** – OTM calls have a tiny Delta (≈ 0.05‑0.1). Their price barely moves with the underlying, so the 490‑point Nifty slide barely dented them.  
2. **Vega** – The 64 % VIX spike meant **implied volatility** exploded. Vega is the sensitivity of the option price to that volatility. When IV jumps, **Vega makes premiums swell**, especially for OTM options where Delta is near‑zero.  

Hence, the low‑Delta shielded the OTM calls from a price crash, while the high‑Vega (fueled by the VIX surge) pumped their premiums up.  

That’s why, on a day when the market tanked, we saw a **paradoxical rise of call premiums**.  

### Key take‑aways from this chapter  

- **Historical Volatility** = measured from past closing prices of the underlying.  
- **Forecasted Volatility** = produced by statistical models (e.g., GARCH) to predict future turbulence.  
- **Implied Volatility** = market participants’ consensus on future volatility, embedded in option prices.  
- **India VIX** = the Indian market’s 30‑day implied volatility index, derived from Nifty option order‑books.  
- **Vega** = the rate of premium change for a 1 % change in IV (positive for both calls and puts).  
- **All options become more expensive when volatility rises**.  
- **The impact of volatility is strongest when there are many days left to expiry** (the longer the time, the larger the premium swing).  

Armed with these insights, you’re now ready to treat Vega not as a mysterious Greek, but as the *volatility‑meter* that tells you how much extra cash you can earn (or lose) when the market’s fear factor changes. Happy trading, and may your Vega always be positive! 🎉  