# 18. Volatility Applications  

**Source:** https://zerodha.com/varsity/chapter/volatility-applications/  

---  

##  

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/08/M5-Ch18-Cartoon2.png)  

## 18.1 – Striking it Right  

We’ve just spent the last couple of chapters getting cozy with volatility, standard deviation, the good‑old normal curve, and all that statistical jazz. Now it’s time to put the theory to work and see how it can actually help us make (or at least *not lose*) money in the market. In this section we’ll focus on two practical tricks:  

1. Picking the “just‑right” strike when you’re selling (or “writing”) an option.  
2. Figuring out a sensible stop‑loss for a trade.  

*(Later, in a completely different module, we’ll go deep into Relative‑Value Arbitrage, Pair Trading, and Volatility Arbitrage. For now we’ll keep our feet planted firmly in the world of options and futures.)*  

### Why the right strike matters  

An option writer’s nightmare is getting caught on the wrong side of a sudden market swing. The goal is to sell an option, pocket the premium, and hope the underlying price stays comfortably out of the money (OTM). Of course, the market can always surprise you, but a disciplined trader can *shrink* that surprise by using the normal distribution as a guide.

#### Quick reminder of the bell curve  

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/08/Image-1_SD1.png)  

The classic bell tells us, with respect to the mean (the average):  

| **σ‑range** | **Probability the price stays inside** |
|------------|----------------------------------------|
| 1‑σ (≈ 68 %) | 68 % chance the price lives inside the first standard deviation |
| 2‑σ (≈ 95 %) | 95 % chance it stays inside the second |
| 3‑σ (≈ 99.7 %) | 99.7 % chance it’s inside the third |

Since Nifty’s daily returns behave *almost* like a normal distribution, we can use those percentages to guess where the index might wander over a given horizon.

### A live‑action example  

Let’s pretend we’re looking at the market on **11 August 2015**, with 16 days left until expiry.  

| **Parameter** | **Value** |
|---------------|-----------|
| Current Nifty price | 8 462 |
| Daily average return | 0.04 % |
| Annualised return | 14.8 % |
| Daily σ (standard deviation) | 0.89 % |
| Annualised σ | 17.04 % |

First, we need the 16‑day equivalents:

* **16‑day σ** = Daily σ × √16 = 0.89 % × 4 = **3.567 %**  
* **16‑day average move** = Daily average × 16 = 0.04 % × 16 = **0.65 %**

Now we can sandwich the expected price range:

* **Upper bound** = (Average + σ) = 0.65 % + 3.567 % = **4.215 %**  
  *Price* = 8 462 × (1 + 4.215 %) = **≈ 8 818**  

* **Lower bound** = (Average – σ) = 0.65 % – 3.567 % = **‑2.920 %**  
  *Price* = 8 462 × (1 – 2.920 %) = **≈ 8 214**  

So, with a **68 % confidence** (one‑σ rule), Nifty is likely to finish the next 16 days somewhere between **8 214 and 8 818**. There’s a 32 % chance it strays outside that band – a reminder that nothing’s guaranteed, but the odds are on our side.

#### What does that mean for option strikes?  

* Anything **above 8 818** is probably going to stay OTM → you can **sell** those calls and keep the premium.  
* Anything **below 8 214** is likely to stay OTM on the put side → you can **sell** those puts and pocket the premium.  

Conversely, buying calls above 8 818 or puts below 8 214 is like buying lottery tickets with a *very* low chance of winning – not a great idea if you care about ROI.

Here’s a quick snapshot of the Nifty call strikes sitting above 8 818:

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/08/Image-2_Call-Strikes1.png)  

If I were picking today, I’d probably go for the **8 850** or **8 900** strikes (or both) because they sit roughly one‑σ away and still offer decent premium:

| **Strike** | **Premium (₹)** |
|-----------|-----------------|
| 8 850 CE | 7.45 |
| 8 900 CE | 4.85 |

Why those? Simple: they give a comfortable cushion (one σ) and a respectable payout.

### “That’s just ₹7.45 per lot? No thanks!” – the ROI perspective  

Let’s do the math:  

* Premium collected = 7.45 × 25 (lot size) = **₹186.25**  
* Required margin (roughly) ≈ **₹12 000** (use Zerodha’s margin calculator for the exact figure).  

**Return on margin** = 186.25 / 12 000 ≈ **1.55 %** for a 16‑day trade. Not eye‑popping on an annual basis, but if you can repeat it month after month you’re looking at **> 18 % annualised** just from writing options.  

#### My personal bias: Calls over Puts  

* **Puts** – I steer clear of shorting puts because panic spreads faster than greed. A sudden market drop can turn an OTM put into an ATM/ITM one in a flash, and you’ll be scrambling to cover.  
* **Calls** – The opposite logic applies. For a call to become ITM, the market must **rise** a good chunk. That usually takes longer and requires “excess greed,” which is less common than a panic‑driven plunge. In the example above, Nifty would need to climb **≈ 438 points** in 16 days for the 8 900 CE to be ATM – a tall order.

#### How I actually execute the plan  

1. **Strike identification** – Do the σ‑mean calculations **the week before expiry**, not weeks ahead. The nearer you are, the tighter the distribution, and the more reliable the numbers.  
2. **Timing** – I like to sell on the **last Friday before the expiry week** (e.g., 21 Aug for a 27 Aug expiry). Why? Because **theta (time decay)** is in full‑swing, eroding the option’s value like a melting ice‑cream cone.  
3. **Premium collected** – Since I’m selling very close to expiry, the premiums are modest (₹5‑6 per Nifty lot), translating to about **1 %** return on the margin. Yet the trade feels safe because:  
   * The market would need to move **≈ 1 σ in just 4 days** to bite you – a rare event.  
   * Theta does the heavy lifting, wiping out the premium quickly in the final week.  
4. **Why bother with tiny premiums?** – Because the trade checks all the boxes I care about:  
   * **Quantifiable risk/reward** (you know exactly what you’re risking).  
   * **Repeatability** (if it works today, it should work tomorrow).  
   * **Consistency** (there’s always a few strikes that fit the criteria).  
   * **Known worst‑case** (you can size your position to survive the rare blow‑up).  

#### SD distance & expiry horizon  

* **1 σ** away when you’re 3‑4 days from expiry → a decent premium with a comfortable cushion.  
* **2 σ** away when you’re farther out → higher confidence but lower premium.  

Rule of thumb: **Never write options with > 15 days to expiry** unless you have a very specific view.

#### Events & Black Swans  

I **avoid** writing around big news – RBI rate decisions, earnings, macro announcements – because those can cause a sudden, outsized move (the dreaded “black swan”). Even with all the precautions, a black‑swan can turn a ₹5‑point premium into a **‑20‑point** loss, wiping out months of tiny gains. As Satyajit Das quipped in *Traders, Guns, and Money*: option writers “eat like a hen but sh*t like an elephant.”  

**Survival tip:** Keep a pulse on market sentiment. If you sense the tide turning, exit early.  

#### Success ratio & conviction  

Option writing is an emotional roller‑coaster. You’ll feel the “fear of a black swan” creep in, only to have the market calm down later. The key is to **distinguish a false alarm from a genuine black‑swan**. That comes with **conviction**, which you build by doing the trade repeatedly **with sound logic**, not guesswork.  

My personal rule: **Get out when the option moves from OTM to ATM** – that’s the moment the risk‑reward balance collapses.  

#### Expenses – keep them tiny  

Brokerage eats profit. With Zerodha, a Nifty lot costs about **₹1.95** in total charges. The more lots you trade, the lower the per‑lot cost (e.g., 10 lots → ≈ ₹0.30 per lot). Shop around – a greedy broker can kill a 1 %‑return strategy.  

#### Capital allocation – how much to risk?  

I’m an equity‑purist, so my capital sits 100 % in stocks/equity‑related products (no gold, FD, or real‑estate for me). Still, diversification across asset classes is a good idea for most people. Here’s how I split **₹500 000**:

| **Bucket** | **% of capital** | **Amount (₹)** | **Purpose** |
|------------|------------------|----------------|-------------|
| Mutual‑fund SIPs | 35 % | 175 000 | Long‑term equity exposure |
| Direct equity portfolio (≈ 12 stocks) | 40 % | 200 000 | Core holdings, 5‑year+ horizon |
| Short‑term strategies (including option writing) | 25 % | 125 000 | Tactical trades |
| **Max per short‑term trade** (35 % of the 25 % bucket) | — | **43 750** | ≈ 8.75 % of total capital, limits exposure |

That **₹43 750** ceiling translates to roughly **4 Nifty lots** (4 × ₹12 000 margin ≈ ₹48 000, a tad above the limit, so I’d stick to **3‑4 lots**). The rule of “no more than 9 % of overall capital on any one short‑term play” keeps my downside manageable.  

#### Instruments I like  

Liquidity is king. I stick to:  

* Nifty & Bank Nifty  
* Heavyweights: **SBI, Infosys, Reliance, Tata Steel, Tata Motors, TCS**  

Venturing beyond these usually means paying higher spreads and dealing with thinner order books – not worth the hassle for a strategy that thrives on tight pricing.  

#### Your homework  

1. On a day about **5‑7 days before expiry** (e.g., 21 Aug), calculate the **mean and σ** for Nifty (and Bank Nifty if you like).  
2. Spot the strikes that sit roughly **1 σ away** from the spot price.  
3. Write (sell) those calls (or puts, if you’re daring) *virtually* and track what happens at expiry.  
4. If you have bandwidth, repeat the exercise on the other liquid stocks I mentioned.  

Do this a few times, get comfortable with the numbers, and only then start committing real capital.  

> **Disclaimer:** The approach above reflects my personal risk‑reward temperament. Your own preferences, capital size, and comfort level may differ. Treat this as a framework, not a gospel.  

> **Bonus reading:** If you haven’t already, crack open Nassim Nicholas Taleb’s *Fooled by Randomness*. It will make you question everything you think you know about markets (and life).  

---

## 18.2 – Volatility‑Based Stop‑Loss  

We’ve been talking options, but the idea of a volatility‑driven stop‑loss is just as handy for futures (or any directional trade). Before you pop a position, you need a price point where you’ll bail out – that’s your **stop‑loss (SL)**.  

### The naive 2 % rule (and why it hurts  

A common, “set‑and‑forget” method is to use a fixed percentage, say **2 %** of the entry price. Example: buy a stock at ₹500, set SL at ₹490, risking ₹10. The flaw? It ignores the **daily noise** of the particular stock. If a stock normally swings 2‑3 % a day, you’ll get stopped out **even if you’re right about the trend**. Tight, static stops can turn a winning idea into a losing trade.  

### Let volatility do the heavy lifting  

Volatility tells us how much a price is *expected* to jiggle. By sizing the SL a little beyond the “normal” swing, we give the trade breathing room while still protecting the downside.  

#### Walk‑through with Airtel  

Picture a bullish harami forming on Airtel (yes, the telecom giant). The pattern suggests a long entry, with the prior day’s low (≈ ₹385) as a conventional SL and the next resistance (≈ ₹417) as the target.  

| **Trade details** | **Value** |
|-------------------|-----------|
| Entry (Long) | ₹395 |
| Initial SL | ₹385 |
| Target | ₹417 |
| Risk | 395 – 385 = 10 points (≈ 2.5 %) |
| Reward | 417 – 385 = 32 points (≈ 8.1 %) |
| R/R Ratio | 32 / 10 = 3.2 |

A 3.2 : 1 reward‑to‑risk looks tasty. But is the **₹385** stop realistic? Let’s check with volatility:  

1. **Daily σ for Airtel** ≈ **1.8 %** (calculated from recent returns).  
2. **5‑day σ** = 1.8 % × √5 ≈ **4.01 %**.  
3. **5‑day price swing** = 4.01 % of 395 ≈ **15.8 points**. So a 5‑day move could take the price down to **≈ 379**.  

That means our **₹385** SL sits *inside* the expected noise band – it’s likely to get hit before the trade has a chance to work out.  

**Re‑calculated SL**: pick something below the 5‑day lower bound, say **₹375** (≈ 20 points below entry).  

New **RRR** = (417 – 375) / (395 – 375) = 42 / 20 = **2.1**. Still respectable, and now the stop respects the stock’s volatility.  

*If you were planning a 10‑day hold, just replace √5 with √10, and you’ll get a wider band.*  

### TL;DR on stop‑losses  

* Fixed‑percentage stops ignore the market’s “loudness” and can get you out too early.  
* Volatility‑based stops place the SL **outside the normal price jitter**, reducing the chance of a premature exit while still capping risk.  

---

### Key Takeaways  

- **Use σ to spot strikes you can safely write.**  
- **Avoid shorting puts** (panic spreads faster than greed).  
- **Strikes ~1 σ away give you ~68 % confidence**; go to 2 σ for ~95 % confidence (but expect lower premium).  
- **Higher σ → broader range → smaller premium**, so balance risk and reward.  
- **Allocate capital** according to your belief in asset classes; diversification is generally wise.  
- **Set stop‑losses based on daily volatility**, not a flat percentage, to respect the instrument’s natural noise.  

Happy trading, and may your premiums be plentiful while your black‑swans stay well‑outside your charts! 🍻