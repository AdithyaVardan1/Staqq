# 1. Call Option Basics  

**Source:** https://zerodha.com/varsity/chapter/call-option-basics/  

---  

## 1.1 – Breaking the Ice  

Alright, strap in – just like every other chapter in Varsity, we’re going to *pretend* you’re a complete option‑novice who’s never even heard the word “derivative.” (If you actually know a thing or two, feel free to roll your eyes, we’ll still start from square one.)  

First, a quick tour‑de‑force of the options universe. In India, options dominate the derivative playground: roughly **80 %** of all derivative turnover comes from options, the remaining 20 % being futures. That’s like a pizza where the cheese (options) is the whole thing and the crust (futures) is just a thin edge.  

How did we get here? A lightning‑fast timeline:  

| Year / Era | What Happened | Where? |
|------------|----------------|--------|
| **1920s** | Custom, over‑the‑counter (OTC) options – mostly on commodities | Global (OTC) |
| **1972** | First exchange‑traded equity options – Chicago Board Options Exchange (CBOE) | USA |
| **Late 1970s** | Currency & bond options (still OTC) | Global |
| **1982** | Exchange‑traded currency options debut – Philadelphia Stock Exchange | USA |
| **1985** | Interest‑rate options start trading on CME | USA |

So the West had a few decades of “let’s try this on the back‑yard” before the big exchange parties showed up.  

India’s story is a little different. From day one the exchanges ran the show, but there was also a shadowy “Badla” market – think of it as the speakeasy of derivatives. Badla was the grey‑market, the “under‑the‑table” way to get leverage. It’s long gone, dead as a dodo, but it paved the way for today’s formal markets.  

Here’s the Indian milestones in a neat bullet list (because we love bullet points almost as much as we love chai):  

- **12 June 2000** – Index futures debut.  
- **4 June 2001** – Index options launch.  
- **2 July 2001** – Stock (single‑stock) options go live.  
- **9 November 2001** – Single‑stock futures appear.  

Even though the paperwork was filed in 2001, real‑life liquidity didn’t show up until **2006**. Back then spreads were as wide as the Ganges during monsoon, and getting a fill felt like finding a parking spot in Delhi.  

What finally lit the fire? The infamous Ambani brothers split their empire, listing the two new entities separately. Suddenly there were *real* stocks to trade, and the market’s liquidity went from “tortoise” to “cheetah” overnight.  

Still, compared to the U.S. or Europe, Indian option markets are like a junior‑league cricket team – promising, but still learning the ropes.  

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/03/M5-Ch1-title1.jpg)  

---  

## 1.2 – A Special Agreement  

Options come in two flavours: **calls** (the “I want it” side) and **puts** (the “I’m scared of it” side). You can be the buyer *or* the seller, and each role flips the profit‑and‑loss (P&L) profile upside‑down. We’ll get into the juicy P&L later; first, let’s demystify the call option with a *real‑world* story that even your grandma could follow.  

### Meet Ajay and Venu  

- **Ajay**: A keen‑eyed investor, eyeing a 1‑acre plot owned by his buddy Venu.  
- **Venu**: The landowner, a bit of a “sell‑it‑if‑I‑get‑the‑price” kind of guy.  

The land is currently worth **₹5,00,000**. Ajay hears a rumor: a new highway might be approved within six months, which would make the plot *skyrocket* in value. If the highway shows up, Ajay could be sitting on a gold mine. If it’s just hot air, Ajay ends up with a barren slab and a hole in his pocket.  

So, what does a cautious yet opportunistic friend do? He crafts a *special agreement* that looks a lot like an option contract. Here’s the deal in plain English (and a dash of drama):  

1. **Up‑front fee** – Ajay hands Venu **₹1,00,000** today. Think of this as a non‑refundable “reservation” charge.  
2. **Future purchase right** – Venu promises to sell the land **in six months** at a price **fixed today at ₹5,00,000**.  
3. **One‑way pull‑out** – Only Ajay can back out after six months; Venu is *stuck* with the promise.  
4. **Fee for the right** – If Ajay decides not to buy, Venu pockets the ₹1,00,000 fee.  

Who’s the genius here? Is it Ajay for inventing a “win‑win” (or at least a *win‑some*) deal, or Venu for agreeing to it? The answer hides in the numbers, so let’s dissect the agreement like a forensic accountant.  

### Breaking Down the Deal  

- **Fee = ₹1,00,000** → This locks Venu into an *obligation*: “I can’t sell this acre to anyone else for six months.”  
- **Strike price = ₹5,00,000** → Ajay locks in today’s market price, irrespective of where the market wanders later.  
- **Right to walk away** → At maturity, Ajay can either shout “Deal!” or “Never mind!” Venu, however, must honour the contract if Ajay says “Deal!”.  
- **Non‑refundable** → The fee disappears into Venu’s pocket no matter what.  

Now we fast‑forward six months. The highway rumor either becomes a reality, fizzles out, or stays in limbo. In practice, only three outcomes make sense:  

| Scenario | Market price after 6 months | What happens? |
|----------|-----------------------------|---------------|
| **A** | **₹10,00,000** (boom) | Land value explodes. |
| **B** | **₹3,00,000** (bust) | Land value crashes. |
| **C** | **₹5,00,000** (steady) | Nothing changes. |

No other price makes sense because the only driver we’ve introduced is the highway. Let’s walk in Ajay’s shoes for each case.  

### Scenario 1 – Highway built, land rockets to **₹10,00,000**  

Ajay’s right now looks like a bargain‑bin treasure. He can buy for **₹5,00,000** (plus the fee he already paid).  

- **Total cash outlay** = Strike **₹5,00,000** + Fee **₹1,00,000** = **₹6,00,000**.  
- **Market value** = **₹10,00,000**.  

**Profit** = ₹10,00,000 – ₹6,00,000 = **₹4,00,000**.  

That’s a **400 %** return on the ₹1,00,000 premium – a four‑fold money‑making machine! Venu, on the other hand, is forced to sell at half the market price, losing ₹4,00,000 in the process.  

### Scenario 2 – Highway fizzles, land drops to **₹3,00,000**  

Now buying makes no sense. If Ajay exercised, his total cost would be **₹6,00,000** for a piece worth only **₹3,00,000**.  

Result: Ajay *doesn’t* exercise, walks away, and loses only the premium **₹1,00,000** (which Venu happily keeps).  

### Scenario 3 – No news, price stays at **₹5,00,000**  

Again, buying would cost **₹6,00,000** for a land worth **₹5,00,000**. Not a great deal.  

Ajay drops the deal, forfeits the premium, and Venu walks away with **₹1,00,000**.  

### Quick‑fire Q&A (because we love repeating ourselves)  

- **Why would Ajay even take a loss of ₹1 lakh if the land doesn’t rise?**  
  Because he *knows* his maximum loss upfront. No nasty surprises. If the land does shoot up, his upside is theoretically unlimited. At ₹10 lakh, his profit is ₹4 lakh on a ₹1 lakh outlay = **400 %**!  

- **When does Ajay’s position make sense?**  
  Only when the land price *increases* – i.e., Scenario 1.  

- **When does Venu’s side look good?**  
  When the price *decreases* or stays flat – Scenarios 2 & 3.  

- **Is Venu taking a huge risk?**  
  Statistically, Venu wins **2 out of 3** times (≈ 66.66 %). Ajay’s odds are **1 out of 3** (≈ 33.33 %).  

> *Pro tip*: In any binary bet, the side with the *premium* (the buyer) usually has the lower probability of winning, but the *payoff* can be massive.  

### TL;DR (the “Too‑Long‑Did‑n’t‑Read” version)  

- **Fee** = right for Ajay, obligation for Venu.  
- **Outcome** is decided solely by the land’s market price at expiry.  
- The land = **underlying asset**; the contract = **derivative** (specifically an *options* agreement).  
- Ajay = **Option Buyer** (or “holder”).  
- Venu = **Option Seller/Writer**.  
- The **₹1,00,000** Ajay hands over is called the **premium**.  
- All terms (area, price, date) are fixed at inception.  
- In an options contract, **buyer gets a right; seller gets an obligation**.  

Make sure this story sticks in your brain – we’ll revisit it many times, just like that annoying song you can’t get out of your head.  

Now, let’s translate this land‑deal saga into the language of stocks.  

---  

## 1.3 – The Call Option  

Time to swap the farmland for a ticker symbol. Imagine a stock currently trading at **₹67**. You can buy a *right* today to purchase that same share **one month later** at a *strike price* of **₹75**.  

But there’s a catch: you only *exercise* that right if the market price on the expiry date is **above** ₹75.  

To secure this right, you pay a **premium** of **₹5** right now.  

- **If** the stock ends up at **₹85**, you’ll exercise, pay ₹75 for the share, plus the ₹5 premium you already spent = total **₹80**.  
  - **Profit** = ₹85 – ₹80 = **₹5**.  

- **If** the stock falls to **₹65**, buying at ₹75 (plus ₹5 premium) would cost you **₹80** for a share worth ₹65. You simply *don’t* exercise. Your loss = the premium **₹5**.  

- **If** the stock lands exactly on **₹75**, exercising would mean paying ₹80 for a share worth ₹75 – a net loss of ₹5, so you again let the option expire and lose only the premium.  

Three outcomes, three simple calculations. That, my friend, is the *core* of a **call option**.  

> **Bottom line:** Whenever you *expect* an asset’s price to rise, buying a call is usually the smartest move.  

### Formal definition (because textbooks love jargon)  

> “The buyer of a call option has the **right, but not the obligation**, to buy a specified quantity of an underlying asset from the seller at a pre‑determined **strike price** on (or before) a set **expiration date**. The seller (or *writer*) is obligated to sell if the buyer chooses to exercise. The buyer pays a **premium** for this right.”  

We’ll dig deeper into greeks, time decay, and other fun‑stuff in the next chapter.  

---  

### Key takeaways from this chapter  

- Options have been traded in India for **15+ years**, but *real* liquidity only materialised after **2006**.  
- An option is a *risk‑management* tool – it can protect a position or amplify a view.  
- **Call‑buyer** gets a *right*; **call‑seller** gets an *obligation*.  
- Only the buyer receives the right; the seller must honour it if exercised.  
- The seller is often called the **writer** (because they “write” the contract).  
- The buyer pays a **premium** up front – think of it as a non‑refundable reservation fee.  
- The agreed‑upon price is the **strike price**.  
- The buyer profits **only** if the underlying price ends *above* the strike (plus premium).  
- If the price stays at or below the strike, the buyer walks away and only loses the premium.  
- Because the seller collects the premium most of the time, statistically the **seller has higher odds of winning** (≈ 66 % in our simple three‑outcome world).  
- The directional view must *materialise before expiry*; otherwise the option expires worthless.  

That’s it for today’s crash course. Keep the Ajay‑Venu story in your back pocket – you’ll see it pop up again faster than a meme in a group chat. Cheers to options, and may your premiums always be worth the gamble!  