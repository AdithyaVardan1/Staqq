# 24. Quick note on Physical Settlement  

**Source:** <https://zerodha.com/varsity/chapter/quick-note-on-physical-settlement-2/>  

---  

## 24.1 – Overview  

Once upon a time—well, “until recently”—India’s equity futures‑and‑options (F&O) market behaved like a polite friend who never actually shows up at your house. When a contract expired, the parties simply settled the difference in cash and went on with their lives, without ever exchanging the underlying share.  

That all‑cash‑settlement habit changed on **11 April 2018** when SEBI (the market’s strict‑but‑fair parent) issued a circular that said, “Hey, enough of the ghost‑trading! From now on, you must actually deliver the shares when a stock F&O contract expires, and we’ll roll it out gradually.”  

Why the tough‑love? SEBI wanted to curb wild speculation that can turn a quiet stock into a roller‑coaster at the last minute. By forcing real‑share delivery, the regulator hopes traders think twice before piling on massive short positions that could artificially crash a price right before expiry.  

In short: the market moved from “paper‑only” to “paper‑plus‑real‑stock” to keep things honest, less volatile, and a tad less cinematic.  

---  

## 24.2 What is Physical Settlement?  

Physical settlement means **the contract’s underlying security actually changes hands** when the contract expires. Starting with the **October 2019 expiry**, every stock‑based F&O contract in India must be settled this way—no more “cash‑only” shortcuts.  

Let’s picture the old world first. Suppose you bought one lot of SBI futures that expires this month. In a cash‑settled world, on expiry the exchange would calculate the *settlement price* (the official closing price used for futures), compare it to your contract price, and simply credit or debit the difference to your trading account. You never touch a single SBI share; you just watch the numbers dance.  

Now flip the switch to the new world of physical settlement. If you **don’t square‑off** (close) or **roll over** (extend) that same lot before expiry, you’re on the hook for the **full contract value**—i.e., you must pay the total price for 500 SBI shares (the standard lot size) and those shares will magically appear in your Demat account. Conversely, if you were short, you’d have to **source** the shares from the market (or borrow them on the Stock‑Loan‑Borrow market) and hand them over to the exchange.  

So, physical settlement swaps a tidy cash‑adjustment for an actual delivery of securities, turning “paper‑only” trades into “real‑stock” trades.  

---  

## 24.3 Why is Physical Settlement enforced?  

When contracts settle in cash, traders only need to keep **margin** (the SPAN + exposure amount) in their account. This low‑cost entry point is great for speculation, but it also creates a loophole: a short‑seller can pile up a massive short position right up to expiry, hoping the price will tumble in the final hours, then pocket the cash difference. In other words, it’s a recipe for “price‑crash‑the‑last‑minute” drama.  

Physical settlement flips that script. If you’re short and want to deliver shares at expiry, you **must either buy the shares on the spot market or borrow them via the SLB (Stock‑Loan‑Borrow) market**. Both actions require capital (or collateral) and expose you to the actual market price, which naturally damps the incentive to push the price down artificially.  

Think of it like this: you can’t cheat in a poker game if the dealer makes you show your cards before you win. By demanding real‑share delivery, SEBI forces everyone to play with the same deck, keeping the price formation more balanced and less prone to manipulation.  

---  

## 24.4 How are positions settled?  

On expiry day the exchange decides who gets a **delivery** and who must **give a delivery** based on the position’s direction and whether the option is in‑the‑money (ITM). The rule‑book looks like this:  

| Settlement Action | Who does it? | Typical Positions |
|-------------------|--------------|-------------------|
| **Take Delivery** (shares land in your Demat) | **Long** futures, **Long** ITM call, **Short** ITM put | You’re on the “buy” side of the underlying at expiry |
| **Give Delivery** (you hand shares to the exchange) | **Short** futures, **Short** ITM call, **Long** ITM put | You’re on the “sell” side of the underlying at expiry |

Only **ITM options** trigger a physical settlement. If an option finishes **out‑of‑the‑money (OTM)**, it simply expires worthless—no shares change hands, and you just lose (or keep) the premium you paid/received.  

So, in practice, if you’re long a futures contract and the market is still open on the expiry date, you’ll wake up the next morning with a fresh batch of shares in your Demat. If you’re short a futures contract, you’ll need to cough up those shares (or borrow them) and send them back to the exchange.  

---  

## 24.5 Netted‑off positions (sub‑category)  

Sometimes you hold multiple legs on the same underlying with the same expiry—think of it as a mini‑portfolio that can **net out**. When the directions oppose each other, the exchange will match them against each other, cancelling any physical delivery obligation.  

### Example net‑off  

| Position | Type | Direction |
|----------|------|-----------|
| 1 | Long ITM Put | Buy |
| 2 | Short ITM Put | Sell |
| 3 | Short ITM Call | Sell |
| 4 | Short ITM Put | Sell |
| 5 | Long ITM Put | Buy |

If you, for instance, hold an **SBI June long futures** contract **plus** a **long ITM put** with a strike of ₹200 (while SBI’s spot sits around ₹180), here’s what happens:  

* The **long futures** creates a **take‑delivery** obligation (you’ll receive 500 shares).  
* The **long ITM put** creates a **give‑delivery** obligation (you have the right to sell 500 shares at ₹200).  

Since you’re both receiving and giving away the same number of shares, the exchange nets them off. The result? **Zero physical delivery**—you just settle the cash difference (the premium on the put, plus any MTM adjustments).  

Netting is the market’s way of saying, “Hey, you’re hedging yourself; no need to ship any actual stock.” It saves you from the logistical nightmare of moving shares in and out of your account on the same day.  

---  

## 24.6 Margins  

In the F&O world, margin is the **security deposit** you keep to cover potential losses. The rules differ based on the instrument and the settlement regime:  

| Instrument | Typical Margin Requirement (pre‑physical) |
|------------|-------------------------------------------|
| Futures (long or short) | **SPAN + Exposure** (a percentage of contract value) |
| Short Options (writes) | **SPAN + Exposure** (since you could be on the hook for large losses) |
| Long Options (buys) | **Only the premium** you pay (no extra margin, because the most you can lose is the premium) |

**Physical settlement flips the script again.** When you hold a position that will be physically settled, you must be able to **cover 100 % of the contract value**—either by having cash to buy the shares (if you’ll take delivery) or by having the shares ready to hand over (if you’ll give delivery).  

Because of this, brokers often impose **additional “expiry‑margin”** as the contract approaches its final day, to make sure you have enough liquidity to meet the delivery obligation. Think of it as the broker’s way of saying, “Don’t try to pull a Houdini with your shares at the last second.”  

For the nitty‑gritty on how Zerodha calculates and applies these extra margins, check out their **[Physical Settlement Policy](https://zerodha.com/varsity/chapter/quick-note-on-physical-settlement-2/)**.  

---  

*Bottom line:* Physical settlement turned a mostly “paper‑only” game into a genuine share‑exchange showdown, nudging traders toward more responsible positioning, reducing the chance of last‑minute price gymnastics, and adding a dash of real‑world logistics to your trading day. Cheers to a market that actually delivers—both in spirit and in stock!