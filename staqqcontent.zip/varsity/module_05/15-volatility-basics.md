# 15. Volatility Basics  

**Source:** https://zerodha.com/varsity/chapter/understanding-volatility-part-1/  

---  

## 15.1 – Background  

You’ve already wrestled with Delta, Gamma, and Theta, so congratulations – you’re now officially a “Greek‑phile.”  
Next up on the menu is the most flamboyant of the Greeks: **Vega**.  Think of Vega as the “mood‑swing detector” for an option premium – it tells you how much the price of the option will wobble when the underlying’s volatility decides to throw a tantrum.  

But… *what* on Earth is volatility?  I’ve asked a bunch of traders and the most common reply is, “It’s just the up‑and‑down‑and‑up‑and‑down of the market.”  If that’s your mental picture, it’s time for a reality‑check (and maybe a little therapy).  

Here’s the game plan for the next few chapters (yes, we’ll spill over a little – like a good wine, it gets better with time):  

- Decode what volatility truly means.  
- Learn how to **measure** volatility (no crystal balls required).  
- See volatility in action with real‑world examples.  
- Differentiate the various flavors of volatility.  
- Finally, meet the star of the show – **Vega**.  

Buckle up, grab a coffee (or a cocktail, we’re casual), and let’s roll.  

---  

## 15.2 – Moneyball  

Ever seen the Hollywood flick *Moneyball*?  It’s the true‑story drama of Billy Beane, a baseball GM who swapped gut feeling for cold, hard statistics.  He and his data‑savvy sidekick built a team of “underdogs with hidden gems” by looking at numbers that nobody else cared about.  Think of it as *The Wolf of Wall Street* meets *The Office* – but with baseball cards instead of stock tickers.  

(If you need a trailer, just Google “Moneyball trailer” – you’ll get Brad Pitt looking very serious about batting averages.)  

Why am I dragging a baseball movie into an options lecture?  Because the concept of **volatility** can be illustrated with a pair of batsmen and their run‑scoring records.  Stick with me; the payoff is worth the mental jog.  

### Meet the contenders  

| Player | Match 1 | Match 2 | Match 3 | Match 4 | Match 5 | Match 6 | **Total (Σ)** |
|--------|--------|--------|--------|--------|--------|--------|--------------|
| **Billy** | 20 | 23 | 21 | 24 | 19 | 23 | **130** |
| **Mike**  | 45 | 13 | 18 | 12 | 26 | 19 | **133** |

You’re the captain, the 7th match is tomorrow, and you need a batsman who will **at least** reach 20 runs.  Two obvious ways to decide:  

1. **Σ (Sigma)** – pick the lad with the higher cumulative runs.  
2. **Mean (Average)** – pick the lad with the higher per‑match average.  

Let’s crunch the numbers (and sprinkle in some jokes while we’re at it).  

### Step 1: Totals (Σ)  

- Billy: 130 runs  
- Mike: 133 runs  

By the “bigger‑is‑better” rule, Mike takes the crown.  

### Step 2: Averages  

- Billy: 130 ÷ 6 = **21.67** runs per game  
- Mike: 133 ÷ 6 = **22.16** runs per game  

Again, Mike looks slightly shinier.  

So far, both methods point to Mike.  But wait!  Our **real goal** is to *guarantee* at least 20 runs in the next match, not just to pick the guy with the highest historical sum.  The numbers above give us no clue about *consistency* – and that’s the secret sauce.  

### Step 3: Digging into deviation  

We now compute how far each innings strays from its player’s average.  For Billy, the first match gave 20 runs, which is **20 – 21.67 = –1.67** runs away from his mean (a little under‑perform).  The second match was **23 – 21.67 = +1.33** (a modest over‑perform).  Do this for every inning, and you’ll get a series of “deviation” values.  

Visually, imagine a horizontal line representing the mean (21.67 for Billy).  Each match gets a vertical arrow pointing up (positive deviation) or down (negative deviation).  That’s the picture we’ll use to introduce **variance**.  

![Billy’s deviations](http://zerodha.com/varsity/wp-content/uploads/2015/07/Ch15-graph.png)  

### Step 4: Variance – the squared‑deviation party  

Variance = ( Σ (deviation²) ) ÷ *N*  

Where *N* = number of observations (here, 6 matches).  Squaring each deviation makes sure negatives don’t cancel out positives – think of it as “punishing” large swings twice as hard.  

For Billy:  

\[
\begin{aligned}
\text{Variance}_\text{Billy} &= \frac{(-1.67)^2 + (1.33)^2 + (-0.67)^2 + (2.33)^2 + (-2.67)^2 + (1.33)^2}{6}\\
&= \frac{2.79 + 1.77 + 0.45 + 5.43 + 7.13 + 1.77}{6}\\
&= \frac{19.34}{6}\\
&\approx 3.22
\end{aligned}
\]

(You’ll notice a tiny rounding difference from the original 19.33 – we’re keeping the math honest.)  

### Step 5: Standard Deviation – the “real‑world” risk gauge  

Standard Deviation (σ) = √Variance  

\[
\sigma_\text{Billy}= \sqrt{3.22}\approx 1.79
\]

Do the same for Mike and you’ll get **σ ≈ 11.18** – a massive spread!  

### Quick recap of the stats table  

| Player | Σ (Total) | Mean | Variance | σ (Std Dev) |
|--------|-----------|------|----------|-------------|
| Billy | 130 | 21.67 | 3.22 | **1.79** |
| Mike  | 133 | 22.16 | 125.2 (≈) | **11.18** |

> **Note:** Don’t confuse the Greek **σ** (standard deviation) with the summation symbol **∑** (sigma).  One tells you “how far we wander,” the other tells you “how much we’ve accumulated.”  

### Using σ to forecast the next innings  

A handy (though naïve) rule of thumb: **Mean ± σ** gives a plausible interval for the next observation.  

- Billy: 21.67 ± 1.79 → **[19.88, 23.46]**  
- Mike: 22.16 ± 11.18 → **[10.98, 33.34]**  

Graphically (courtesy of Zerodha’s cartoon):  

![Projected scores](http://zerodha.com/varsity/wp-content/uploads/2015/07/M5-Ch15-cartoon.png)  

Interpretation:  

- **Billy** looks like a steady, “always‑on‑target” type.  His range is narrow, so the odds of scoring **≥ 20** are very high.  
- **Mike** is a roller‑coaster.  He could blast 33 runs *or* crumble for 11.  Selecting him is a gamble.  

Hence, if your mission is “score at least 20”, **Billy** is the safer bet.  

### From cricket to the stock market  

That exercise taught us a priceless lesson: **Standard Deviation ≈ Risk**.  In finance, we call that risk **Volatility**.  It’s simply the standard deviation of **returns** (not runs) expressed as a **percentage**.  

> **Investopedia definition (quoted for you)**:  
> “A statistical measure of the dispersion of returns for a given security or market index. Volatility can be measured by using the standard deviation or variance between returns from that same security or market index. Commonly, higher the standard deviation, higher the risk.”  

So, if **Infosys** has a volatility of **25 %** and **TCS** sits at **45 %**, Infosys is the calmer, less‑jumpy sibling.  (Unless you’re a thrill‑seeker who loves heart‑racing swings, you’ll probably prefer Infosys.)  

---  

## 15.3 – Some Food for Thought  

Let’s play a quick crystal‑ball exercise (no actual crystal required).  

- **Today’s date:** 15 July 2015  
- **Nifty spot:** 8 547  
- **Nifty volatility:** 16.5 %  
- **TCS spot:** 2 585  
- **TCS volatility:** 27 %  

**Question:** Where will Nifty and TCS likely be trading **one year** from now?  

### The math (with a splash of intuition)  

A simple way to get a rough range is:  

\[
\text{Upper bound} = \text{Spot} \times (1 + \text{Vol})  
\]  
\[
\text{Lower bound} = \text{Spot} \times (1 - \text{Vol})  
\]  

(We treat volatility as a *one‑sigma* move; you can imagine a 68 % probability that the price lands somewhere inside this band.)  

- **Nifty:**  
  - Upper = 8 547 × (1 + 0.165) ≈ **9 957**  
  - Lower = 8 547 × (1 – 0.165) ≈ **7 136**  

- **TCS:**  
  - Upper = 2 585 × (1 + 0.27) ≈ **3 285**  
  - Lower = 2 585 × (1 – 0.27) ≈ **1 889**  

So, a year from now, **Nifty** is likely to be between **7 136** and **9 957**, while **TCS** could wander between **1 889** and **3 285**.  The exact probability for any single point inside those bands varies, but you can think of a bell‑shaped curve peaking around the spot price.  

### Why does this matter?  

- **Trading‑the‑range:** If we can forecast a short‑term range (say, the next 3 days or up to expiry), we can spot options that are *likely* to finish out‑of‑the‑money (OTM).  Those options are prime candidates for **selling** today and pocketing the premium.  
- **Confidence intervals:** The “one‑sigma” band we just used corresponds to about a **68 %** confidence level.  If you want tighter confidence (say, 95 %), you’d multiply σ by 2 (≈ 2σ band).  
- **Volatility isn’t static:** Our numbers assumed volatility stays at 16.5 % for Nifty.  In reality, it can swing up or down.  When volatility spikes, the range widens; when it collapses, the range narrows.  
- **Excel to the rescue:** All these calculations are one‑click away in a spreadsheet – just feed in spot, volatility, and the time horizon, and let Excel churn out the range.  

In the chapters ahead, we’ll answer:  

1. **How to compute volatility from raw price data** (hint: the `STDEV.P` function).  
2. **How to adjust the range for different confidence levels**.  
3. **How to translate volatility into concrete option‑selling strategies**.  
4. **What happens when volatility changes mid‑trade** (and how to hedge).  

Stay tuned; the fun is just beginning!  

---  

### Key Takeaways  

- **Vega** = sensitivity of an option’s premium to a 1 % change in volatility.  
- Volatility ≠ “just up‑and‑down”.  It’s a *statistical* measure of how wildly prices swing.  
- **Risk = Standard Deviation** (σ).  Bigger σ → wilder price swings → higher volatility.  
- **Variance** is the average of squared deviations; **σ** is its square‑root.  
- Given σ, you can sketch a plausible **price range** for a security over any horizon.  
- The wider the range, the higher the volatility (and the higher the risk‑reward profile).  

Now that you’ve got the basics, go out there and start spotting those “low‑vol‑high‑premium” option opportunities.  And remember: in the world of Greeks, Vega is the party‑animal, but it only shows up when volatility decides to dance. 🍸📈  