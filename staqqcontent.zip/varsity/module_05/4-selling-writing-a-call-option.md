# 4. Selling / Writing a Call Option  

**Source:** <https://zerodha.com/varsity/chapter/sellingwriting-a-call-option/>

---  

##  

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/04/M5-Ch4-title.png)  

## 4.1 – Two sides of the same coin  

Remember that 1975 Bollywood blockbuster **_Deewaar_**?  The one where the iconic line *“Mere paas maa hai”* still makes us choke on popcorn? The film’s about two brothers: one a straight‑arrow cop, the other a smooth‑talking don.  

Now picture those two brothers as **option buyer** (the daring cop) and **option seller** (the sly don). They’re two halves of the same market‑coin. The moral compass isn’t the issue here—what matters is what each side **expects** the market to do. The rule of thumb is simple: **what the seller gains, the buyer loses, and vice‑versa**.  

| What the buyer sees | What the seller sees |
|----------------------|----------------------|
| **Limited risk** – can lose at most the premium paid | **Limited profit** – can earn at most the premium received |
| **Unlimited upside** – if the stock soars, profit can be infinite | **Unlimited downside** – if the stock rockets, loss can be infinite |
| **Breakeven** = Strike + Premium paid (the price where buyer starts to smile) | **Break‑even (or “break‑down”)** = Strike + Premium received (the price where seller stops grinning) |
| Profit of **₹X** → Seller’s loss of **₹X** | Loss of **₹X** → Seller’s profit of **₹X** |
| Bullish view: “Price will go above the strike” | Bearish view: “Price will stay at or below the strike” (or the seller is just a pessimist) |

All of the above can be visualised by flipping a call‑option payoff diagram upside‑down.  

> **Heads‑up:** Because the P&L of the writer mirrors that of the buyer, this chapter may feel like déjà‑vu from the previous one. Resist the urge to skim—look for the tiny nuances that flip the profit‑loss story on its head.  

## 4.2 – Call‑option seller’s thought process  

Let’s revisit the **Ajay‑Venu** land‑deal from Chapter 1. Three outcomes were possible:

1. **Land > ₹5 Lakhs** – Ajay (buyer) wins.  
2. **Land = ₹5 Lakhs** – Venu (seller) wins.  
3. **Land < ₹5 Lakhs** – Venu wins again.

Two out of three scenarios favor the seller. That statistical edge is one of the reasons many writers love to sell options. **But** a statistical edge ≠ guaranteed profit—market insight still matters.

Now, swap the land for **Bajaj Auto** shares (the same chart we dissected in the previous chapter).  

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/04/Image-1_Bajaj-Auto-stock-price.png)

- The stock has been **battered**; sentiment is as low as a Monday morning without coffee.  
- Many traders are stuck in *desperate long* positions, i.e., they bought at higher levels and can’t get out without a price bounce.  
- Any modest uptick will be a **golden exit** for those longs.  
- Consequently, a *quick* rally is unlikely; the market’s more likely to stay limp for a while.  
- With that outlook, the writer thinks: *“If the price stays flat, I just keep the premium—cheers!”*  

So the writer decides to **sell a call** on Bajaj Auto, **strike = ₹2 050**, premium **₹6.35** per share.  

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/04/Image-2_Bajaj-Auto.png)

### How the writer’s P&L is built  

| Item | Meaning |
|------|---------|
| **Premium received** (positive sign) | Cash **inflow** for the writer – a *credit* to his account. |
| **Intrinsic value** (at expiry) | Same for buyer **and** seller – it’s just the “real” value of the option. |
| **Net P&L** for the writer | **Premium – Intrinsic Value**. The writer first pockets the premium; he only starts losing money **after** the intrinsic value exceeds the premium. |
| **Net P&L** for the buyer | **Intrinsic Value – Premium**. The buyer must first recoup his premium before seeing any profit. |

> **Note:** The above logic appears three times in the original text (a tiny copy‑paste glitch). We’ll keep it once—clarity over redundancy.

#### Quick sanity‑check with numbers  

Assume three possible spot prices on expiry:

| Spot (₹) | Intrinsic Value = max(0, Spot – Strike) | Writer’s P&L = 6.35 – Intrinsic |
|----------|------------------------------------------|---------------------------------|
| 2 023 | 0 | **+6.35** (premium kept) |
| 2 072 | 22 | **‑15.65** (loss) |
| 2 055 | 5 | **+1.35** (still profit) |

Why does the writer still earn at 2 055? Because the **break‑down point** (the writer’s breakeven) is **Strike + Premium** = 2 050 + 6.35 = 2 056.35. Below that level the writer walks away with cash; above it, the loss starts to bite.

> **Bottom line:**  
> **P&L (writer) = Premium – max[0, Spot – Strike]**  

### Generalised takeaways  

1. **Maximum profit = premium received**, *as long as* Spot ≤ Strike.  
2. **Losses begin** once Spot > Strike; the farther Spot climbs, the deeper the writer’s hole.  
3. **Profit ceiling** = premium; **loss ceiling** = theoretically infinite.  

These three bullet‑points are the essence of selling a **call**.

## 4.3 – Call‑option seller payoff diagram  

The seller’s payoff is a mirror image of the buyer’s.  

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/04/Image-3_Short-call-pay-off.png)

Observations:

- **Flat profit** of ₹6.35 when Spot ≤ 2050.  
- From 2050 up to **2056.35** (the breakdown point) profit shrinks linearly.  
- At **2056.35** the line crosses zero – no profit, no loss.  
- Beyond 2056.35 the line slopes **downward**, indicating mounting losses as Spot rockets away from the strike.

## 4.4 – A note on margins  

Let’s compare risk profiles:

| Party | Risk exposure |
|-------|----------------|
| **Buyer** | **Limited** – max loss = premium paid. |
| **Seller** | **Unlimited** – loss grows without bound as Spot rises above Strike. |

Because the exchange can’t let a participant walk away with an *unlimited* hole, **margin** is mandatory for the writer—just like you’d post margin for a futures contract.  

Here’s a snapshot from Zerodha’s margin calculator (both contracts expire 30 Apr 2015):

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/04/Image-4_Futures-Margin.png)  

…and the margin required to **sell** the 2050 CE:

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/04/Image-5_-Options-Margin.png)  

You’ll notice the numbers are **pretty close** to the futures‑margin requirement. The small difference will be discussed later, but for now just remember: **selling a call ties up margin, roughly the same as a futures position**.

## 4.5 – Putting things together  

We’ve now walked through buying **and** selling calls, so let’s cement the key points.  

### Buying a call (Long Call)

| What you do | Why you do it | Cash‑flow | Risk / Reward |
|-------------|---------------|-----------|---------------|
| Pay a premium (e.g., ₹6.35) | Bullish view – you expect Spot > Strike | Outflow of premium | **Risk** = premium (max loss). **Reward** = unlimited (stock can rise forever). |
| Breakeven = Strike + Premium | The price where profit starts | — | P&L = max[0, Spot – Strike] – Premium |

### Selling a call (Short Call)

| What you do | Why you do it | Cash‑flow | Risk / Reward |
|-------------|---------------|-----------|---------------|
| Receive a premium (e.g., ₹6.35) | Bearish/neutral view – you think Spot ≤ Strike | Inflow of premium | **Reward** = premium (max profit). **Risk** = unlimited (stock can surge). |
| Breakdown point = Strike + Premium | The price where you start losing | — | P&L = Premium – max[0, Spot – Strike] |

#### Other handy nuggets

- **Bullish** → buy spot, buy futures, **or** buy a call.  
- **Bearish** → sell spot (intraday), short futures, **or** short a call.  
- Intrinsic value formula is the same for buyer **and** seller (only the P&L sign flips).  
- For **puts**, the intrinsic‑value calculation flips (we’ll get there).  
- Most option traders don’t wait for expiry; they chase **premium moves**. Example: bought Bajaj 2050 CE at ₹6.35, it jumps to ₹9 by noon → you can close for a quick profit.  
- Premiums are **dynamic**, driven by volatility, time‑decay, interest rates, etc.—all topics coming up later.  
- Call options are abbreviated **CE** (short for *European Call*). So Bajaj 2050 CE = Bajaj 2050 Call.

## 4.6 – European vs. American options  

When options first landed in India, we had **two flavors**:

| Type | Exercise rule | Typical Indian instrument |
|------|---------------|----------------------------|
| **European** | Can be exercised **only on expiry**. Settlement = spot price on expiry. | All index options (Nifty, Bank Nifty). |
| **American** | Can be exercised **anytime** before expiry. Settlement = spot price on the day of exercise. | Stock options (until ~2018). |

### What does that mean in plain English?  

- **European Call**: If you bought Bajaj 2050 CE, you must wait until the expiry day. If on that day Spot > 2056.35 (strike + premium), you’re in the money; otherwise you lose the premium.  
- **American Call**: Same contract, but you could walk in tomorrow, see Spot = 2052, and *exercise* immediately. The seller would be forced to deliver the stock at 2050, and you pocket the intrinsic value (₹2).  

**Why are American calls pricier?** Because the writer carries **extra risk**: the buyer could pull the trigger *any* day a rumor spikes the price. The writer demands a higher premium to compensate for that “any‑day‑exercise” risk.

**What happened to American options in India?** Around three years ago, NSE **phased them out**. All Indian options are now **European**, meaning the only exercise date is the expiry.  

Next up: **Put Options** – the other side of the options coin.  

---  

### Key take‑aways from this chapter  

- **Selling a call** = bearish/neutral stance on the underlying.  
- Buyer’s and seller’s P&L are **mirror images** (profit for one = loss for the other).  
- Writer **receives** premium up front; buyer **pays** it.  
- **Margin** is mandatory for writers (similar to futures margin).  
- **Profit cap** = premium received; **loss potential** = unlimited.  
- **P&L formula**: `Premium – max[0, Spot – Strike]`.  
- **Breakdown point** (seller’s breakeven) = `Strike + Premium`.  
- All Indian options are now **European** – you can only exercise on expiry.  

Feel free to raise a glass (or a coffee) and toast to your newfound mastery of the call‑option writer’s world. Cheers!  