# 23. Case studies – wrapping it all up!  

**Source:** https://zerodha.com/varsity/chapter/case-studies-wrapping-it-all-up/

---  

## 23.1 – Case studies  

Alright, we’ve hit the finish line of this marathon‑length module. Hopefully you now have a decent feel for options – and not just the “buy low, sell high” version you learned from your aunt’s WhatsApp memes. As I kept reminding you, options are *not* the straight‑arrow cousins of futures. They’re more like that friend who has a Ph.D. in physics, a side hustle in yoga, and a penchant for quoting Nietzsche at brunch.  

Why? Because a whole zoo of market forces (price, time, volatility, interest rates, dividends…) are all tugging at an option at the same time. The result? A multi‑dimensional beast that can make even seasoned traders break out in a cold sweat. From my own battle‑scarred experience, the only real way to tame this beast is to **trade it** – and do so with a solid theoretical compass in your pocket.  

To give you a leg‑up, I’m going to walk you through a handful of *real* trades that actually happened. Even better: they were executed by Zerodha Varsity readers in the past two months. Whether they were inspired by the textbook or just a lucky gut‑feel, the traders told me “yes, we read the chapter”. 🙂  

Either way, I’m thrilled because each trade had a logic that blended several disciplines (technical, fundamental, volatility‑theory). It makes a neat, tidy bow for this Options Theory module.  

*Note:* The traders kindly let me share their trades, but they asked to stay anonymous, so I’ll keep their identities under wraps.  

Here are the four trades we’ll dissect:  

- **CEAT India** – a directional play, born from technical‑analysis vibes  
- **Nifty** – a delta‑neutral set‑up that leans on Vega (the volatility whisperer)  
- **Infosys** – another delta‑neutral Vega‑play, this time on the index‑heavy side of things  
- **Infosys** – a pure‑fundamental, directional bet (because sometimes fundamentals still matter)  

For each, I’ll highlight what impressed me and what could have been tweaked. All screenshots come straight from the traders; I just told them “please format it like this”.  

Let’s roll!  

![Cartoon of a trader juggling options](http://zerodha.com/varsity/wp-content/uploads/2015/10/M5-Ch23-Cartoon1.png)  

---  

## 23.2 – CEAT India  

**Trader:** A 27‑year‑old “options newbie”. Yep, his *first* options trade ever.  

**The thesis:** CEAT Ltd. was cruising around ₹1,260 per share, riding a solid up‑trend. Our rookie thought the rally was getting a little wheezy – like a marathon runner who suddenly spots a water station. The last three daily candles were shrinking in range, hinting at exhaustion.  

![Candlestick chart showing shrinking range](http://zerodha.com/varsity/wp-content/uploads/2015/10/Image-1.png)  

**The play:** He bought the 1,220 PE (out‑of‑the‑money) at a premium of **₹45.75 per lot** on **28 Sept**, with expiry on **29 Oct**.  

![Trade ticket for CEAT PE](http://zerodha.com/varsity/wp-content/uploads/2015/10/Image-2.png)  

### Quick‑fire Q&A (re‑phrased by yours truly)

| Question | Trader’s Answer (paraphrased) |
|----------|------------------------------|
| **Why options, not short futures?** | Short futures would have given me a nasty *MTM* scar if the rally snapped back sharply. Options limit my downside to the premium paid. |
| **Why not a far‑OTM strike given the long time to expiry?** | Liquidity, my friend. Stock options thin out as you move away from the ATM. Sticking near‑ATM means tighter spreads and smoother fills. |
| **What’s the stop‑loss plan?** | If CEAT makes a *new high*, the up‑trend is still alive and my contrarian short‑call is dead. I’ll square off at that point. |
| **What’s the profit target?** | Since the stock is on a strong up‑trend, I’ll lock in gains as soon as the premium looks juicy. If the trend reverses, I might even flip to a long call. |
| **How long will you hold?** | This is a *premium‑appreciation* trade, not a hold‑to‑expiry bet. With a month left, even a modest dip can boost the put’s value. I’m not planning to ride it to expiry. |

*Note:* The Q&A above is a distilled version; I wanted the gist, not a word‑for‑word transcript.  

**What happened next?**  

The very next day CEAT slid to **₹1,244** and the put’s premium swelled to **₹52**. The trader smiled, pocketed **₹7 per lot**, and closed the position.  

![Profit screenshot after CEAT dip](http://zerodha.com/varsity/wp-content/uploads/2015/10/Image-3.png)  

Looking back, that was a tidy first‑time win.  

![Final trade screenshot](http://zerodha.com/varsity/wp-content/uploads/2015/10/Image-4.png)  

### My two‑cents  

First off, kudos for crystal‑clear thinking on a maiden trade. If I were to tweak it:  

1. **Direction of the option:** The chart showed “exhaustion”, which often translates to a *sideways* market rather than a sharp drop. I’d have sold a call (or a call spread) instead of buying a put. Why? A flattening price helps option sellers collect premium via time‑decay.  
2. **Strike selection:** Use the normal‑distribution method we covered earlier to pick strikes that balance probability and premium, while still respecting liquidity.  
3. **Timing:** Since the trade is time‑decay dependent, I’d open it in the *second half* of the expiry series to get more theta (time decay) on my side.  

I’m generally wary of naked directional bets because risk‑reward isn’t obvious. The only time I go **naked long call** is when a textbook flag pattern shows up:  

- Prior rally of **5‑10 %**  
- A modest **≈3 %** pull‑back on *low volume* (signs of profit‑taking)  

That’s my “buy the dip” flag.  

![Cartoon of a flag pattern](http://zerodha.com/varsity/wp-content/uploads/2015/10/M5-Ch23-Cartoon2.png)  

---  

## 23.3 – RBI News Play (Nifty Options)  

**Trader:** A Delhi‑based Varsity reader. This one looked like a textbook case of “volatility‑play before a macro event”.  

**Backdrop:** The Reserve Bank of India (RBI) was slated to announce its monetary policy on **29 Sept**. The market was buzzing that the repo rate might be **cut by 25 bps**. (If you’re not sure what a repo rate is, check out the “Key Events and Their Impact” chapter.)  

**Market observations (the trader’s cheat‑sheet):**  

- 2‑3 days before a big announcement, the index usually *wanders* sideways.  
- Volatility spikes *before* the news.  
- Higher volatility → puffed‑up option premiums (both calls and puts).  

With those premises, he sold *both* the ATM call and put on **28 Sept** (a day before the announcement), hoping volatility would calm down and the premiums would shrink.  

![Nifty chart with ATM strike highlighted](http://zerodha.com/varsity/wp-content/uploads/2015/10/Image-5.png)  

**Trade specifics:**  

- Underlying: Nifty ~ 7,780  
- Strike: 7,800 (ATM)  
- 7,800 CE premium = **₹203**  
- 7,800 PE premium = **₹176**  
- **Total collected:** **₹379** per lot  

Here’s the option chain that captured those numbers:  

![Option chain snapshot](http://zerodha.com/varsity/wp-content/uploads/2015/10/Image-6.png)  

### Q&A (summarised)

| Question | Answer (paraphrased) |
|----------|----------------------|
| **Why short both CE & PE?** | With plenty of time to expiry and a volatility surge, the premiums looked *expensive*. I expect volatility to recede, letting me buy back cheaper. |
| **Why ATM, not OTM?** | ATM options have the *tightest* bid‑ask spreads, so when I exit via market order I’ll incur minimal impact cost. |
| **Holding period?** | Volatility usually drops *right before* the announcement. I’ll square off at **10:50 AM** (the RBI announcement is slated for 11:00 AM). |
| **Target profit?** | Roughly **10‑15 points** per lot (i.e., ₹10‑₹15). |
| **Stop‑loss?** | Since this is a volatility play, the SL is *volatility‑based* rather than premium‑based, plus the built‑in “exit before the news” rule. |

(The bullet list repeats a bit – that’s intentional; the original did the same.)  

**Outcome:**  

True to plan, he closed the position a few minutes before the RBI statement. The combined premium fell from **₹379 → ₹369**, netting about **10 points** per lot.  

![Post‑close option chain](http://zerodha.com/varsity/wp-content/uploads/2015/10/Image-7.png)  

A quick glance at the market after the RBI announcement shows the index wobbling, confirming the volatility contraction.  

![Market reaction after RBI news](http://zerodha.com/varsity/wp-content/uploads/2015/10/Image-8.png)  

### My take  

I’m a fan of *short‑volatility* plays before scheduled events, but I’d start the trade **a couple of days** out, not just the night before. It gives you a wider “volatility‑decay” window and reduces the risk of a surprise “volatility explosion”.  

A common misconception is the “Long Straddle” (buy both CE & PE) before big news. The logic sounds sweet: the market will move, one leg will win, the other will lose, you just keep the winner. The missing piece? **Volatility crush**.  

When the news drops, the *winning* leg (say the call) might gain 30 pts, but the *losing* leg (the put) could lose 45 pts because its premium evaporates faster than the call’s inflates. The net result can be a loss even though the market moved in the right direction. Hence, selling the options *before* the news is often the smarter play.  

![Cartoon of a trader debating straddle vs short vol](http://zerodha.com/varsity/wp-content/uploads/2015/10/M5-Ch23-Cartoon3.png)  

---  

## 23.4 – Infosys Q2 Results  

**Trader:** Another Delhi‑based enthusiast, a step up in sophistication from the RBI guy.  

**Event:** Infosys’s Q2 earnings call on **12 Oct**. The expectation? Decent numbers, nothing earth‑shattering.  

**Strategy:** Same as before – short both call and put *before* the volatility spike, then buy back when the news settles. The difference: this time the trade was opened **four days** prior (on **8 Oct**), giving more room for the volatility premium to decay.  

**Underlying price:** Infosys hovering around **₹1,142** → chose the **1,140 ATM** strike.  

![Infosys trade ticket](http://zerodha.com/varsity/wp-content/uploads/2015/10/Image-9.png)  

**Premiums at entry (8 Oct, 10:35 AM):**  

- 1,140 CE = **₹48** (IV ≈ 40.26 %)  
- 1,140 PE = **₹47** (IV ≈ 48 %)  
- **Total collected:** **₹95** per lot  

(We’ll skip the repeat Q&A; the answers mirrored the RBI trade.)  

**Earnings outcome:**  

Infosys posted a *sweet* beat:  

> “Net profit: **$519 m** (vs $511 m YoY)  
> Revenue: **$2.39 bn**, up **8.7 %** YoY (sequential **+6 %**) – well above the 4‑4.5 % consensus.  
> In rupee terms: profit **+9.8 %** to **₹3,398 cr**, revenue **+17.2 %** to **₹15,635 cr**.”  

Source: *Economic Times*.  

The numbers arrived at **9:18 AM** (just three minutes after the market opened). Our trader closed the position almost simultaneously.  

![Post‑earnings option chain](http://zerodha.com/varsity/wp-content/uploads/2015/10/Image-10.png)  

**What changed:**  

- 1,140 CE = **₹55**, IV dropped to **28 %** (call rose modestly)  
- 1,140 PE = **₹20**, IV fell to **40 %** (put collapsed sharply)  

Combined premium = **₹75**, i.e. a **20‑point** profit per lot. Notice the put’s decay outpaced the call’s gain – exactly the volatility‑crush we discussed.  

### My commentary  

The trader showed clear experience: entry timing, strike choice, and exit plan were all on point. If I were to copy, I’d probably do the exact same thing (maybe tighten the stop‑loss a tad, just for safety).  

![Cartoon of a trader celebrating a successful vol‑play](http://zerodha.com/varsity/wp-content/uploads/2015/10/M5-Ch23-Cartoon4.png)  

---  

## 23.5 – Infosys Q2 Aftermath (Fundamentals‑Based)  

**Trader:** A Bangalore mate of mine, a true fundamentalist who’s just started dabbling in options. He’s got a solid grasp of balance sheets and is now testing those skills in the options arena.  

**Scenario:** After the impressive Q2 results, Infosys actually *dropped* about **5 %** on **12 Oct** and a further **1 %** on **13 Oct**. Why? The company trimmed its *revenue guidance* for the next quarter, a bearish signal that the market over‑reacted to.  

Our Bangaloreian concluded:  

- The market had already priced in the *good* news (the earnings beat).  
- The *bad* news (guidance cut) was over‑hyped, pushing the stock down more than justified.  
- Historically, when a company simultaneously throws good and bad news, investors first latch onto the negative. The upside usually resurfaces later.  

**Trade:** Go **long** on a call, betting that the market will correct the over‑reaction.  

He bought **Infosys 1,100 CE** at **₹18.9** (slightly OTM) and was prepared to lose **₹8.9** (i.e., a stop‑loss around **₹10**). The plan: hold until the strike turned ITM (in‑the‑money).  

![Long call ticket](http://zerodha.com/varsity/wp-content/uploads/2015/10/Image-11.png)  

**Result:** The stock recovered, and on **21 Oct** he closed the position, netting **more than double** his initial outlay.  

![Profit screenshot after Infosys rebound](http://zerodha.com/varsity/wp-content/uploads/2015/10/Image-12.png)  

The entire logic was built on three pillars: financial‑statement reading, fundamental intuition, and a dash of options theory.  

### My two‑cents  

Naked directional bets (like a single long call) make my skin crawl because they leave risk loosely defined. In this case, the entry rationale was solid, but the exit plan and stop‑loss could have been tighter. Also, with a month left to expiry, a *slightly farther OTM* strike would have given a better risk‑reward ratio (cheaper premium, same upside potential).  

---  

### And that’s a wrap!  

We’ve now toured four real‑world option trades, from a rookie’s first put to a seasoned macro‑volatility play, and even a fundamentals‑driven long call. I hope the stories, screenshots, and my occasional dad‑jokes have helped you see how the theory you just absorbed can be turned into actual *money‑making* (or at least *learning*) actions.  

Good luck out there, keep the spreadsheets tidy, the Greeks close, and never forget: **options are like pizza** – you can have them thin‑crust (simple) or deep‑dish (complex), but either way you need the right toppings (logic) to make them delicious.  

Happy trading!  