# 2. Basic Option Jargons  

**Source:** https://zerodha.com/varsity/chapter/basic-option-jargons/  

---  

## 2.1 – Decoding the basic jargons  

In the last chapter we got cozy with the skeleton of a **call option**.  The key take‑aways were:  

| What you learned | Why it matters |
|------------------|----------------|
| **Buy a call when you think the underlying will rise** | You’re basically buying a “ticket” that lets you hop on a price‑increase train. |
| **If the price stays flat or falls, the buyer loses money** | The ticket becomes worthless – you paid the fare (the premium) and never rode the train. |
| **The loss equals the premium you paid** | The premium is the “price of admission” to the option party. |

In the next chapter – *Call Option (Part 2)* – we’ll dive deeper into the mechanics.  But before we get our hands dirty, let’s meet the six (actually seven) buzzwords that keep option traders awake at night.  Knowing these now will make the upcoming concepts feel like a walk in the park (or at least a less confusing bar‑room chat).  

We’ll cover:  

- **Strike Price**  
- **Underlying Price**  
- **Exercising of an option contract**  
- **Option Expiry**  
- **Option Premium**  
- **Option Settlement**  

> **Heads‑up:** We’re still talking only about **call** options, so picture yourself with a “right‑to‑buy” cape, not a “right‑to‑sell” one.  

---

### Strike Price  

![Strike price illustration](http://zerodha.com/varsity/wp-content/uploads/2015/03/M5-Ch2-I1.jpg)  

Think of the **strike price** as the *anchor* (or the “meeting point”) where the buyer and seller shake hands and say, “Okay, on expiry we’ll trade at this price, no matter what the market does.”  

In the “Ajay‑Venu” saga from the previous chapter, the anchor was **₹5,00,000** – that was their strike price for the land deal.  In the stock‑world example we saw an anchor of **₹75** per share.  For every **call** option, the strike price tells you the exact price at which you *could* buy the underlying asset on expiry.  

#### Real‑world snapshot: ITC call options  

Suppose you’re eyeing an ITC call with a **₹350** strike.  You pay a premium *today* for the *right* to buy ITC at **₹350** when the contract expires.  You’ll only actually exercise that right if ITC’s market price is **above ₹350** on expiry – otherwise you’d be buying a share for more than it’s worth.  

Here’s a quick screenshot from NSE’s option chain (the “menu” of all available strikes and premiums).  

![ITC option chain](http://zerodha.com/varsity/wp-content/uploads/2015/03/Image-1_SP.jpg)  

The option chain is a treasure chest of data: strike levels, premiums, open interest, volume, bid‑ask spreads, etc.  For now, let’s focus on the three highlighted bits:  

1. **Maroon box** – the **spot (underlying) price** of ITC at the moment of the snapshot: **₹336.90** per share.  
2. **Blue box** – the **range of strike prices** available, starting at **₹260** (in ₹10 steps) up to **₹480**.  
3. **Red number** – the **premium** you’d pay for a specific strike, e.g., a **₹340** call costs **₹4.75** per share.  

Key observations:  

- **Each strike is its own mini‑contract**. You can pick any strike you like, pay the corresponding premium, and you’re done.  
- Buying the **₹340** call for **₹4.75** gives you the right to buy ITC at **₹340** on expiry.  If ITC ends up at **₹360**, you’re **₹20** in the money per share (minus the premium, of course).  

---

### Underlying Price  

![Underlying price illustration](http://zerodha.com/varsity/wp-content/uploads/2015/03/M5-Ch2-I2.jpg)  

A **derivative** gets its value from something else – the **underlying asset**.  The **underlying price** is simply the current market price of that asset in the spot market.  

In our ITC example, the underlying price was **₹336.90**.  For a call option, you *want* this price to climb above the strike, because only then does your right become valuable.  

---

### Exercising of an Option Contract  

![Exercising illustration](http://zerodha.com/varsity/wp-content/uploads/2015/03/M5-Ch2-I3.jpg)  

**Exercising** = “I’m going to use my ticket.”  
When you **exercise a call**, you’re saying, “Hand over those shares at the agreed‑upon strike price, please!”  

A crucial rule: **You can only exercise on the expiry day** (or, for American‑style options, any day *up to* expiry – but Indian equity options are *European‑style*, so it’s a one‑day party).  

**Example:** You buy a **₹340** ITC call 15 days before expiry while ITC is trading at **₹330**.  The next day ITC rockets to **₹360**.  You *cannot* exercise immediately; you must wait until the expiry day.  If ITC is still above **₹340** on that day, you’ll exercise; if it falls back below, you’ll let the option expire worthless.  

---

### Option Expiry  

![Expiry illustration](http://zerodha.com/varsity/wp-content/uploads/2015/03/M5-Ch2-I4.jpg)  

Just like futures, **options have an expiration date**.  For Indian equity options, **the last Thursday of every month** is the grand finale.  

There are three “flavors” of expiries, just like ice‑cream:  

1. **Current month** – expires on the nearest last Thursday.  
2. **Mid month** – the Thursday after the current month’s expiry.  
3. **Far month** – the Thursday after the mid‑month expiry.  

Take a look at this snapshot of an **Ashok Leyland Ltd** call (strike **₹70**, premium **₹3.10**).  

![Ashok Leyland option chain](http://zerodha.com/varsity/wp-content/uploads/2015/03/Image-2_AL.jpg)  

You can see three expiry columns:  

- **26 Mar 2015** – current month  
- **30 Apr 2015** – mid month  
- **28 May 2015** – far month  

The premium changes with each expiry because there’s more or less time for the underlying price to move.  Remember: **more time = higher premium (all else equal)**.  

---

### Option Premium  

![Premium illustration](http://zerodha.com/varsity/wp-content/uploads/2015/03/M5-Ch2-I5.jpg)  

The **premium** is the cash you (the buyer) hand over to the seller for the *right* (but not the *obligation*) to buy (or sell, for puts) at the strike.  It’s the price of the option itself.  

We’ve already seen premiums in action, but let’s dig into *why* they move.  

#### The “Ajay‑Venu” refresher  

Recall the land‑deal story: Venu (the writer) accepted **₹100,000** from Ajay (the buyer).  Why was Venu happy?  

| Factor | What it meant for Venu (the writer) |
|--------|--------------------------------------|
| **News** (speculative highway) | The rumor‑mill meant the land value *might* jump, but wasn’t guaranteed – giving Venu a statistical edge. |
| **Time** (6 months) | Plenty of calendar time for the rumor to resolve; the longer the horizon, the higher the chance the land price will swing. |

Now imagine two tweaks:  

1. **News becomes concrete** – a politician actually announces the highway.  Suddenly the land’s future looks *brighter*, and Venu would demand a **higher premium** (maybe **₹175,000**) to compensate for the higher probability of a price surge.  
2. **Time shrinks** – instead of 6 months, only **10 days** remain.  The market can’t digest the news fully, so Ajay would be reluctant to pay **₹100,000**; a lower premium (say **₹20,000**) would be more realistic.  

#### Translating to stocks  

- **Scenario A:** Infosys trades at **₹2,200**.  The **₹2,300** call (1‑month expiry) is priced at **₹20**.  As a writer, you’d ask yourself: “Is there any big corporate event that could push Infosys past **₹2,300**?”  
- **Scenario B:** A quarterly earnings release is imminent, and history shows Infosys tends to jump after good results.  You’d probably *reject* a **₹20** premium, demanding a richer price (maybe **₹75**) to compensate for the extra risk.  

Bottom line: **Premiums aren’t static**; they’re a function of many forces – news, time, volatility, interest rates, and dividend expectations.  In options lingo these are the **Option Greeks** (we’ll meet them later).  

Key reminders about premiums:  

- They’re the **heart** of option theory.  
- They **fluctuate** every minute, reacting to new information.  
- They’re shaped by **five** primary factors (the Greeks).  

---

### Options Settlement  

![Settlement illustration](http://zerodha.com/varsity/wp-content/uploads/2015/03/M5-Ch2-I6.jpg)  

Let’s walk through a concrete cash‑settlement example.  

#### The contract  

| Symbol | Strike | Expiry | Premium | Lot size |
|--------|--------|--------|---------|----------|
| JP Associates (call) | **₹25** | **26 Mar 2015** | **₹1.35** per share | **8,000** shares |

Two players:  

- **Trader A** – wants to *buy* the option (the buyer).  
- **Trader B** – wants to *write* (sell) the option (the seller).  

**Step 1 – Paying the premium**  
Trader A pays:  

\[
8{,}000 \times ₹1.35 = ₹10{,}800
\]

to Trader B.  

**Step 2 – What happens on expiry?**  

In India, equity options are **cash‑settled**.  That means when the option is exercised, the seller doesn’t have to hand over the physical shares; they just pay the *difference* in cash.  

Assume on **26 Mar 2015** JP Associates trades at **₹32**.  

- The option is **in‑the‑money** by **₹7** (₹32 – ₹25).  
- Trader A decides to exercise.  

**Cash‑flow breakdown:**  

| Party | Action | Amount |
|-------|--------|--------|
| Trader A | Pays strike price for 8,000 shares | 8,000 × ₹25 = ₹200,000 |
| Trader B | Receives ₹200,000 (strike payment) |
| Trader A | Sells the 8,000 shares immediately at market price | 8,000 × ₹32 = ₹256,000 |
| Trader A | Gains **₹56,000** from the price differential |
| Trader A | Subtracts the premium paid earlier (**₹10,800**) | Net profit = ₹56,000 − ₹10,800 = **₹45,200** |
| **Return** | **₹45,200 / ₹10,800 ≈ 419 %** (raw, non‑annualised) |

Because settlement is cash‑based, Trader B could have simply written a cheque for **₹56,000** (₹7 × 8,000) to Trader A, skipping the physical share exchange entirely.  

That **asymmetric payoff** – tiny loss if you’re wrong, massive gain if you’re right – is the main reason options are so alluring to traders.  

---

## Key takeaways from this chapter  

- **Buy calls only when you expect the underlying price to rise.**  
- The **strike price** is the anchor (the “meeting point”) that both buyer and writer agree upon.  
- The **underlying price** is simply the spot price of the asset you’re betting on.  
- **Exercising** means you’re cashing in your right to buy (or sell) at the strike on expiry.  
- Options, like futures, **expire on the last Thursday of every month** and come in three buckets: current, mid, and far month.  
- **Premiums aren’t fixed**; they wiggle with news, time, volatility, interest rates, and dividends (the **Greeks**).  
- In India, **options are cash‑settled**, so you receive (or pay) only the monetary difference, not the actual shares.  

Now you’ve got the lingo down, the jokes in your back pocket, and the fundamentals ready for the next deep‑dive.  Onward to part 2 – where we start pulling the levers and watching the Greeks dance! 🍻