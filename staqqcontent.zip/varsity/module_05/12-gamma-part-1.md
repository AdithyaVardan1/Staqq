# 12. Gamma (Part 1)

**Source:** <https://zerodha.com/varsity/chapter/gamma-part-1/>

---  

## 12.1 – The other side of the mountain  

How many of you still remember that *painful* high‑school calculus class? Does the word **differentiation** make your brain twitch? Back then “derivatives” were just a fancy way of saying “solve that monstrous limit problem.”  

Let’s give those brain‑cells a gentle jog—not a full‑blown proof, just enough to get the intuition ticking. And yes, everything we talk about below is **hug‑tight** with options, so keep reading (you’ll thank me when you’re sipping a cocktail later).

---

### A tiny road‑trip story  

Imagine a car that starts from a stand‑still, zips for **10 minutes** and hits the **3 km** mark. Then it keeps going for another **5 minutes** and reaches the **7 km** mark.

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/06/Ch12-diagram-1.png)

Let’s dissect what’s happening between the 3 km and 7 km stretch:

| Symbol | Meaning |
|--------|---------|
| **x**  | Distance (km) |
| **dx** | Change in distance |
| **t**  | Time (minutes) |
| **dt** | Change in time |

- **dx** = 7 – 3 = **4 km**  
- **dt** = 15 – 10 = **5 min**

If we “divide distance‑change by time‑change” we get **velocity** (V):

\[
V = \frac{dx}{dt}= \frac{4}{5}\; \text{km/min}
\]

So the car is cruising **4 km every 5 minutes**. In everyday chatter we’d say “kilometers per hour”, not “per minute”, so let’s do the conversion:

\[
\text{5 min} = \frac{5}{60}\text{ h}
\qquad\Longrightarrow\qquad
V = \frac{4}{5/60}= \frac{4\times60}{5}=48\;\text{km/h}
\]

**Result:** The car’s speed = **48 km h⁻¹**.

> **Quick reminder:** In calculus, **velocity = the first‑order derivative of position** (distance vs. time).  

---

### Let’s crank the engine a bit  

In the first leg the car hit 7 km after 15 minutes. Suppose it now goes another **5 minutes** and ends up at **15 km**.

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/06/Ch12-diagram-2.png)

First leg speed = 48 km/h (we already computed). Second leg:

\[
dx = 15-7 = 8\text{ km}, \qquad dt = 5\text{ min}
\]

\[
V_2 = \frac{8}{5/60}= \frac{8\times60}{5}=96\;\text{km/h}
\]

So the car is now *twice* as fast.  

---

### From speed to “how fast are you *speeding* up?”  

The jump in speed is called **acceleration** (ΔV).  

\[
\Delta V = V_2 - V_1 = 96 - 48 = 48\;\text{km/h}
\]

But… **48 km/h… over what?** That’s the missing piece.  

---

#### A quick detour – car‑salesman speak  

When a dealer says, “this baby goes 0 → 60 km/h in 5 seconds,” they’re really saying:

\[
\text{Acceleration} = \frac{60\text{ km/h} - 0}{5\text{ s}} = \frac{60\text{ km/h}}{5\text{ s}}
\]

You need the *time* denominator to make sense of the “per‑second” part. Same story for our car.

---

### Back to our example – we need a time frame  

Assume **constant acceleration** (a big simplification, but good for a bar‑talk analogy) and ignore the tiny 7 km checkpoint. Treat the whole stretch from 3 km (t = 10 min) to 15 km (t = 20 min) as one smooth ride.

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/06/Ch12-diagram-3.png)

From this we can write down the **initial conditions**:

| Item | Value |
|------|-------|
| Initial velocity @ 10 min (3 km) | 0 km/h (starting from rest) |
| Time at start | 10 min |
| Acceleration | **Assumed constant** |
| Time at finish | 20 min |
| Final velocity | **?** |
| Total distance | 15 – 3 = **12 km** |
| Total time | 20 – 10 = **10 min** |
| Average speed | 12 km / 10 min = 1.2 km/min = **72 km/h** |

If the average of a uniformly accelerating motion equals the midpoint of the start‑ and end‑speeds, we can back‑solve:

\[
\frac{V_{\text{initial}} + V_{\text{final}}}{2} = 72\;\text{km/h}
\]

Since \(V_{\text{initial}} = 0\),

\[
V_{\text{final}} = 2 \times 72 = 144\;\text{km/h}
\]

Now acceleration (constant) is simply:

\[
a = \frac{\Delta V}{\Delta t}= \frac{144\;\text{km/h}}{10\text{ min}}
\]

Convert 10 min → \(\frac{10}{60}\) h:

\[
a = \frac{144}{10/60}= \frac{144 \times 60}{10}=864\;\text{km/h per hour}
\]

That’s a **864 km/h²** acceleration—obviously a *theoretical* number, but it shows how a little algebra can turn a vague “48 km/h” into a concrete rate.

In reality acceleration isn’t constant; you’d need **differential equations** to model the varying “push”. That’s the calculus world in a nutshell.

---

### Recap of the derivative ladder  

| Order | Physical analogue | Calculus term |
|-------|-------------------|---------------|
| 0th   | Position (distance) | – |
| 1st   | Velocity | **1st‑order derivative of position** |
| 2nd   | Acceleration | **2nd‑order derivative of position** (or 1st derivative of velocity) |

Keep that ladder in mind, because we’re about to climb one more rung—**Gamma**.

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/06/M5-Ch12-title.png)

---

## 12.2 – Drawing Parallels  

We’ve already spent a good chunk of time on **Delta**: the *first‑order* change of an option’s premium when the underlying price nudges.

> **Example:** Nifty is at 8,000. The 8,200 CE is out‑of‑the‑money (OTM) and might have a delta of **0.20**.  
> If Nifty rockets up **300 points** in a day, that same option becomes slightly in‑the‑money (ITM) and its delta could jump to **0.80**.

So **delta itself moves**—it’s a variable that depends on where the underlying sits *and* on the option’s price. That’s exactly like **velocity**: a number that changes as time ticks.

**Gamma** answers the question:  

> “If the underlying moves by *ΔS*, how much will *Δ* (the delta) move?”

In calculus‑speak, **Gamma = the second‑order derivative of the option price** (or the first‑order derivative of delta). Let’s line up the analogies:

| Concept | Physical world | Options world |
|---------|----------------|---------------|
| **1st‑order derivative** | Position → Velocity (how fast you’re moving) | Premium → **Delta** (how fast premium moves when the underlying moves) |
| **2nd‑order derivative** | Velocity → Acceleration (how fast you’re speeding up) | **Delta** → **Gamma** (how fast delta is speeding up as the underlying moves) |

Just as you’d need calculus (or a fancy physics textbook) to compute acceleration from speed, you need **option‑pricing mathematics** (Black‑Scholes, stochastic calculus, etc.) to compute Gamma from Delta.

---

### A little trivia for the nerds  

Why do we call these contracts **derivatives**?  
Because their *value* **derives** from the value of an underlying asset. And the word “derivative” also happens to be a core **mathematical** concept—hence the double‑meaning that makes finance sound extra smart. 😉

If you ever meet a trader who spends his nights solving differential equations and sipping espresso, you’ve probably met a **Quant**. Those are the folks who live on the other side of the “mountain” called **Markets**, turning calculus into profit‑finding machines.

From my own experience, mastering a **second‑order** Greek like Gamma feels a bit like learning to ride a unicycle on a tightrope—tricky, but doable with the right practice (and a few jokes along the way).

---

### Key take‑aways from this chapter  

- **Derivatives** (the contracts) got their name from the mathematical **derivatives** that tell us how a value changes.  
- **Delta** isn’t a static number; it shifts every time the underlying price or the premium moves.  
- **Gamma** captures the *rate of change* of delta, answering “what will delta be if the underlying moves by X?”  
- In calculus language:  
  - **Delta** = **first‑order derivative** of the option premium.  
  - **Gamma** = **second‑order derivative** of the option premium (or first‑order derivative of delta).  

Next time you hear a broker brag about “high Gamma,” picture a car that not only speeds up, but *ramps up its acceleration* the moment you press the gas. That’s the extra kick Gamma gives a trader’s P&L curve. 🚗💨