# 25. Options M2M and P&L Calculation  

**Source:** <https://zerodha.com/varsity/chapter/options-m2m-and-pl/>

---  

## 25.1 – Back to Futures  

After a few (well, many) years I finally dusted off this module and added a brand‑new chapter. It still feels like I wrote the original options chapter yesterday… except now my hair is a little greyer and my coffee consumption has doubled.  

A flood of questions kept rolling in, the most common sounding something like:  

> “I sold (i.e. wrote) an option, and later the premium shot up. How much did I lose?”  

![Image](https://zerodha.com/varsity/wp-content/uploads/2021/11/M5-C24-Web-300x221.png)  

People ask this because they assume options get **marked‑to‑market (M2M)** every day, just like futures. In this chapter we’ll see why that assumption is a *big fat no‑no*.

First, let’s take a quick detour back to good old **futures**.  

If I want to trade Reliance Futures today, the exchange will make sure I have enough **margin** sitting in my account. As of today, the required margin for a Reliance futures contract is **₹1,40,133**.

![Image](https://zerodha.com/varsity/wp-content/uploads/2021/11/Image-1_futril-300x212.png)  

The contract’s **lot size** is 250 shares, so the notional value is  

`250 × 2,504.7 = ₹6,26,175`.

Whether I’m **long** or **short** the same margin amount gets blocked. The margin is split into two parts – **SPAN** (the risk‑based component) and **Exposure** (the remaining cushion). Want the exact split? Zap over to Zerodha’s margin calculator and you’ll see the numbers in all their glory.

![Image](https://zerodha.com/varsity/wp-content/uploads/2021/11/Image-2_split-300x90.png)  

Now, pause and ask yourself: **Why does a futures trade need margin at all?**  
The answer lies in the very DNA of a futures (or forward) contract. A futures contract is simply a *promise*—buyers and sellers agree **today** on a price and quantity, but the actual exchange of the underlying asset happens on a future date.  

Picture this: I press that shiny “Buy” button for a Reliance futures contract today. That means I’ve committed to receiving 250 Reliance shares from the seller **on the expiry date** (say, the December contract).  

What if, on expiry, I decide I don’t want those shares? I can walk away, but that would leave my counter‑party with an open‑ended obligation. The exchange can’t let that happen because it would create a **counter‑party default risk**.  

To neutralise that risk, the exchange does two things:

1. **Blocks margin** when the trade is entered (skin in the game).  
2. **Marks‑to‑market (M2M)** the position every day, crediting profits and debiting losses.  

That daily P&L settlement is the safety net that guarantees nobody walks away with an unfinished contract.

## 25.2 – Margin and M2M  

Futures are built so that **counter‑party risk is practically zero**. The only risk left is **price risk**, which is a whole other beast. The exchange eliminates default risk in two ways:

| What the exchange does | Why it matters |
|------------------------|----------------|
| **Blocks margin** when you open a trade | Guarantees you have funds to cover potential losses. |
| **Runs a daily M2M** | Moves profit/loss in/out of your account each day, so you can’t hide a mountain of loss until settlement. |

Margins give you **skin in the game**, and the M2M engine makes sure the **daily profit or loss** is reflected in your cash balance right away.  

We covered the nitty‑gritty of margins and M2M in the futures module, so you’re already familiar with the concept. Let’s now swing the spotlight back to **options** and see how (or if) the same ideas apply.

## 25.3 – Options Buyer  

Put yourself in the shoes of an **option buyer**. The first thing you do is **pay the premium**. The total cash outlay is:

```
Premium × Lot size × Number of lots
```

Example time: I want one lot of **Reliance 2500 CE** (call) that’s trading at a premium of **₹76**.

![Image](https://zerodha.com/varsity/wp-content/uploads/2021/11/Image-3_reliance-opt-300x216.png)  

Lot size = 250, so the cash needed is  

`1 × 250 × 76 = ₹19,000`.

If I have ₹19 K sitting in my demat, I can lock in that option. This is a **cash‑and‑carry** transaction, which makes two things crystal clear:

- **Cash needed** = ₹19 K (the premium you pay).  
- **Maximum risk** = exactly the premium you paid (₹19 K).  

Unlike futures, the buyer’s risk is **capped** at the premium, no matter how wildly the underlying stock moves. Because the buyer has already paid the full premium, **there’s zero chance of default** on the buyer’s side.  

So, does it make sense for the exchange to **block any margin** for an option buyer? **Nope.** There’s nothing to protect against – the buyer has already handed over the cash.  

But what about **mark‑to‑market** for the buyer? Since there’s no margin to adjust, there’s no daily “settle‑up” needed. The buyer simply waits for the option to either **expire worthless** (losing the premium) or **be exercised/closed** for a profit.

### The other side of the coin – the option seller  

Now imagine you’re the **seller (writer)** of that same Reliance 2500 CE. Your risk is **open‑ended** – if the stock rockets, you could be on the hook for a huge loss. That risk profile looks a lot like a futures seller, so the exchange **does** demand margin (SPAN + Exposure) from you.

If I sell one lot of the 2500 CE, the margin requirement shown by the system is **₹1,36,530**.

![Image](https://zerodha.com/varsity/wp-content/uploads/2021/11/Image-4_optsell-300x213.png)  

Notice the **asymmetry**:

- **Buyer** pays the premium upfront, **no margin**, **no M2M**.  
- **Seller** posts margin, but **no daily M2M** either.  

Why no M2M for options? Think about it: In futures, both parties have margin, so the exchange can debit or credit each day. In options, only the **seller** has margin; the buyer has already given the premium. If we tried to M2M the buyer, we’d be moving money that they never posted as collateral – that would be a bookkeeping nightmare.  

Hence **options have no mark‑to‑market**. The next obvious question is: **How are profits and losses settled for options?** Let’s dive in.

## 25.4 – Options P&L for the Buyer  

The **P&L** for an option buyer is actually *simpler* than futures because there’s no daily M2M to juggle. The only trick is keeping straight the **different ways an option can be closed**:

| Position | Possible actions |
|----------|-------------------|
| **Long Call** | Hold till expiry **or** sell before expiry |
| **Short Call** | Hold till expiry **or** buy back before expiry |
| **Long Put** | Same two choices |
| **Short Put** | Same two choices |

### Closing **before** expiry (both long & short)

When you **square‑off** a position before the expiration date, the profit or loss is just the **difference between the selling price and the buying price of the premium**, multiplied by the lot size (and the number of lots you hold).

**Formula**  

```
P&L = (Sell Premium – Buy Premium) × Lot size × No. of lots
```

*Example*: I buy **2 lots** of Reliance 2500 CE at **₹76** each, then sell them a few hours later at **₹79**.

```
P&L = (79 – 76) × 250 × 2
     = 3 × 250 × 2
     = ₹1,500   (before brokerage, taxes, etc.)
```

The same arithmetic works for **long puts** that you close early.

### Short‑option P&L before expiry  

When you **write** (sell) an option, the exchange blocks margin based on two things:

1. **Premium movement** – if the premium moves **against** you, margin goes up.  
2. **Implied volatility** – higher volatility = higher margin.

Both don’t need to happen at the same time; either one can push your margin requirement higher.

*Illustration*:  
- I write (sell) a Reliance 2500 PE at **₹80** (lot size = 250).  
- Suppose the underlying volatility stays the same, but the premium **jumps to ₹130** (a ₹50 increase).  

The extra margin needed ≈ `₹50 × 250 = ₹12,500`.  

Alternatively, if volatility spikes while the premium stays flat, margin still climbs because the **risk of a big move** has risen. (Remember the volatility‑premium relationship we covered earlier.)

Let’s look at a concrete number chain:

| Action | Premium (₹) | Margin Required (₹) |
|--------|-------------|--------------------|
| Write 2500 CE at 76 | 76 | 1,36,530 |
| Premium climbs to 126 (↑50) | 126 | 1,36,530 + 12,500 ≈ **1,49,030** |

Now the broker will ping you with a **margin call** because your **margin utilisation** has jumped to  

```
Utilisation = New margin / Original margin
            = 1,49,030 / 1,36,530 ≈ 109%
```

Most brokers tolerate up to **~120 %** utilisation; beyond that they’ll **square‑off** your position automatically to protect themselves (and you) from further loss.  

If you decide to **close** the short position after the premium has risen to 126, the P&L is simply  

```
P&L = (Sell Premium – Buy‑back Premium) × Lot size
    = (76 – 126) × 250
    = –50 × 250
    = –₹12,500
```

Your margin is released, the loss (₹12,500) gets deducted from your cash balance, and the settlement (T+1) shows up in your account.

### Holding **to expiry** – physical settlement  

When an option is **in‑the‑money (ITM)** at expiry, it is **physically settled** (i.e., the underlying shares actually change hands). If the option is **out‑of‑the‑money (OTM)**, the buyer simply loses the premium and the seller keeps it.

#### Long Call to expiry (example continued)

- **Settlement price** of Reliance on expiry = **₹2,650**.  
- Our **2500 CE** is ITM, so the buyer can buy the shares at **₹2,500**.  
- **Premium paid** = **₹76**.

Effective acquisition cost = Strike + Premium = `2,500 + 76 = ₹2,576`.  

Profit = Settlement price – Effective cost = `2,650 – 2,576 = ₹74` per share.  
Because the lot size is 250, the total profit is `₹74 × 250 = ₹18,500` (before charges).  

The **seller** receives the premium but must deliver the shares at the strike price. Their effective sale price is also `₹2,500 + 76 = ₹2,576`, so they lose the same **₹74 per share**.

Delivery of shares occurs **T+2**, meaning the actual stock move lands in the buyer’s demat on the following Monday after the Thursday expiry.

#### Long Put to expiry – let’s spice things up with TCS  

| Parameter | Value |
|-----------|-------|
| Underlying | TCS |
| Strike | 3,520 |
| Premium | 55 |
| Option type | Put |
| Position | Long |
| Settlement price | 3,390 |

Since **3,390 < 3,520**, the put is **ITM**. The long‑put holder has the right to **sell** at the strike.  

Effective sale price = Strike – Premium = `3,520 – 55 = ₹3,465`.  

Because the market price is **₹3,390**, the put‑buyer **gains**  

```
3,465 – 3,390 = ₹75 per share
Total = 75 × 250 = ₹18,750
```

For the **put writer**, the opposite happens: they must buy the shares at **₹3,465** while the market price is **₹3,390**, incurring a **₹75 per share loss**.

> **Pro‑tip:** If you hold opposite ITM positions (say, a long call and a short put with the same strike), the physical deliveries **net off** each other. It’s called a *synthetic* position, and you can read more about it in the *position offsets* chapter.

### Quick recap of the formulas  

| Situation | P&L Formula |
|-----------|--------------|
| Close **before** expiry (long or short) | `(Sell Premium – Buy Premium) × Lot size × Lots` |
| Long **ITM** call held to expiry | `(Spot – (Strike + Premium)) × Lot size` |
| Long **ITM** put held to expiry | `((Strike – Premium) – Spot) × Lot size` |
| Short‑option margin increase | Depends on **premium move** and **volatility** (both push margin up) |

## Key Takeaways  

- **Options don’t get marked‑to‑market**; only futures do.  
- **Margins** are only required for **option sellers** (because they carry unlimited risk).  
- Margin requirements rise with **adverse premium moves** *or* **higher implied volatility** (either one can trigger a call).  
- **Closing a position before expiry** is just:  

  `ΔPremium × Lot size × No. of lots`  

- **Holding to expiry** means **physical settlement** for ITM options, which translates into the **effective price = strike ± premium** (plus/minus depending on call/put).  
- The buyer’s **maximum loss** is the premium paid; the seller’s risk is **unlimited** (hence the margin).  

Keep these nuggets in your back‑pocket, and you’ll never again wonder “Did my option lose money because the premium moved, or because the exchange marked‑to‑market me?” – the answer is: **Only futures get the daily M2M love; options settle only when you close or let them run to expiry.** Cheers to smarter (and funnier) trading!