# 13. Gamma (Part 2)

**Source:** <https://zerodha.com/varsity/chapter/gamma-part-2/>

---  

## 13.1 – The Curvature  

Alright, you already know that **Delta** isn’t a rock‑solid number – it wiggles around every time the underlying price moves. Here’s that trusty Delta‑vs‑Spot chart again (the one that looks like a lazy snake slithering between two walls):  

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/06/Image-1_Delta-vs-Spot3.png)  

- The **blue line** = Delta of a **call** – it drifts from 0 (deep OTM) up to 1 (deep ITM) as the spot climbs.  
- The **red line** = Delta of a **put** – same dance, just mirrored, travelling between 0 and –1.  

The picture shouts the same old refrain: *Delta changes all the time.*  
So the burning questions become:

1. **I get that Delta moves, but why should I lose sleep over it?**  
2. **If the move matters, how on Earth do I guess its next step?**  

We’ll tackle the second one first – because the answer to the first will pop out like toast once the math settles.

### Meet Gamma – the “curvature”  

Recall from the previous chapter that **Gamma** is the *second‑order* derivative of the option premium (or, in plain English, “how fast Delta itself changes as the underlying wiggles”). We usually quote Gamma as **Δ‑per‑point**: *how many delta‑points you gain (or lose) for every one‑point move in the underlying*.

- When the underlying **rises**, Delta **increases** by the Gamma amount.  
- When the underlying **falls**, Delta **decreases** by the same amount.  

Let’s run a quick, numbers‑heavy example (don’t worry, it’s not a math test, just a friendly bar‑side demo).

| Parameter | Value |
|-----------|-------|
| Nifty Spot (today) | **8 326** |
| Strike | **8 400** |
| Option type | **CE** (call) |
| Moneyness | Slightly OTM |
| Premium | **₹26** |
| Delta | **0.30** |
| Gamma | **0.0025** |
| Planned Spot move | **+70** points |
| New Spot | **8 396** (8 326 + 70) |

**Step‑by‑step magic**

1. **Premium change** = Δ × Spot‑move = 0.30 × 70 = **₹21**  
   → **New premium** = 26 + 21 = **₹47**  

2. **Delta change** = Γ × Spot‑move = 0.0025 × 70 = **0.175**  
   → **New Delta** = 0.30 + 0.175 = **0.475**  

3. The option has gone from *slightly OTM* to *ATM* (because the strike 8 400 is now only 4 points away). Naturally the Delta creeps toward 0.5 – exactly what we see.

---

### Let’s push the market another 70 points up

| Old Spot | New Spot | Old Premium | Old Δ | Δ‑change | New Premium | New Δ |
|----------|----------|-------------|-------|----------|-------------|-------|
| 8 396 | 8 466 | ₹47 | 0.475 | 0.0025 × 70 = 0.175 | 47 + 0.475 × 70 = ₹80.25 | 0.475 + 0.175 = 0.65 |

Now the 8 400 CE is **ITM**, so Delta should be > 0.5 – we got 0.65, right on the money.

---

### And a little pull‑back: Nifty drops 50 points

| Old Spot | New Spot | Old Premium | Old Δ | Δ‑change | New Premium | New Δ |
|----------|----------|-------------|-------|----------|-------------|-------|
| 8 466 | 8 416 | ₹80.25 | 0.65 | 0.0025 × (‑50) = ‑0.125 | 80.25 ‑ 0.65 × 50 = ₹47.75 | 0.65 ‑ 0.125 = 0.525 |

Delta slides back toward 0.5, as expected for a *slightly ITM* call.  

> **Side note:** In our toy examples we kept Gamma fixed at 0.0025. In reality Gamma also shifts as the spot moves. That “Gamma‑of‑Gamma” (the third‑order derivative) is called **Speed** or **Dγ/DS**. Unless you’re a quant‑engineer or a bank‑risk‑guru dealing with multi‑million‑dollar books, you can safely ignore Speed for now.

### Long vs. Short Gamma  

- **Calls and puts both have *positive* Gamma.**  
- If you **own** options (long calls **or** long puts), you’re **long Gamma**.  
- If you **sell** options (short calls **or** short puts), you’re **short Gamma**.

#### Quick brain‑teaser

> An ATM put has Gamma = 0.004. The underlying moves 10 points (direction not specified). What’s the new Delta?

Take a minute, pretend you’re solving a puzzle over a pint, then check the answer below.

**Solution** – ATM put’s Delta ≈ ‑0.5 (puts are negative).  

| Direction | Δ‑change = Γ × ΔSpot | New Δ |
|-----------|--------------------|------|
| Spot **up** +10 | 0.004 × 10 = +0.04 | –0.5 + 0.04 = ‑0.46 |
| Spot **down** ‑10 | 0.004 × (‑10) = ‑0.04 | –0.5 ‑ 0.04 = ‑0.54 |

**Bonus riddle:** Futures have a Delta of **1**. What’s the Gamma of a Futures contract? (Drop your answer in the comments – no cheating with Google! 😉)

---

## 13.2 – Estimating Risk using Gamma  

Risk limits are the “no‑go‑beyond‑this” lines every trader draws. Imagine you have **₹300 000** in your account and each Nifty Futures contract needs roughly **₹16 500** margin (use Zerodha’s SPAN calculator for exact numbers). You might decide, “I’ll never own more than **5** Futures contracts at a time.” Works fine for plain futures.

**But does that logic survive the wild world of options?** Let’s test it.

### The scenario

- **Lots traded:** 10 (each lot = 1 NIFTY option contract)  
- **Option:** 8 400 CE  
- **Spot:** 8 405  
- **Delta (per contract):** 0.5 (ATM)  
- **Gamma (per contract):** 0.005  
- **Position:** **Short** (you sold the calls)  

First, compute the **portfolio Delta**:

\[
\text{Portfolio Δ} = \text{Δ per contract} \times \text{Number of lots} = 0.5 \times 10 = 5
\]

So, at the start you’re “sitting” at a delta equivalent to **5 Futures contracts**, right inside your “5‑contract ceiling”. And because you’re short the options, you’re **short Gamma**.

### What if the market moves 70 points against you?  

| Item | Value |
|------|-------|
| Initial Δ per contract | 0.50 |
| Gamma per contract | 0.005 |
| Spot move | +70 |
| Δ‑change per contract | 0.005 × 70 = 0.35 |
| New Δ per contract | 0.50 + 0.35 = 0.85 |
| Portfolio Δ now | 0.85 × 10 = **8.5** |

Boom! Your “5‑contract” risk limit has exploded to **8.5 contracts** – a full **70 %** over‑run, simply because Gamma kept adding delta as the price climbed. If you were *long* the calls, you’d love the extra delta (your position would be gaining faster). Since you’re **short**, the extra delta is a **dangerous tail‑wind** that pushes you deeper into loss territory.

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/06/M5-Ch13-cartoon1.png)

**Key intuition:**  

- **Long Gamma** → Delta *grows* when the market moves in your favor, shrinks when it moves against you.  
- **Short Gamma** → Delta *grows* when the market moves **against** you, shrinking when it moves with you.  

That’s why “shorting options = short gamma = high directional risk.” It’s not that you should *never* short; it’s that you must respect the Greeks and avoid shorting contracts with *big* Gamma unless you have a solid hedge or a very tight stop‑loss.

### TL;DR on risk‑limit sanity check  

- **Delta alone** can be deceptive when Gamma is sizable.  
- A position that looks “within limits” today can **burst** out of those limits after a modest move.  
- Keep an eye on Gamma, especially for short‑option books.

---

## 13.3 – Gamma movement  

Earlier we hinted that Gamma itself isn’t a static statue – it changes as the underlying price slides. The third‑order derivative that captures that motion is **Speed** (or “Gamma‑of‑Gamma”, denoted Dγ/DS). We won’t dive into the calculus‑y weeds, but we *do* need a feel for how Gamma behaves so we can steer clear of “high‑Gamma traps”.

### The Gamma‑vs‑Spot chart  

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/06/Image-2_Gamma-vs-Spot.png)

The picture shows three different call strikes (80, 100, 120) and their Gamma curves. Let’s zoom in on the **blue line** – the 80‑strike call – to keep things simple.

Assume the underlying is exactly **80** (so the 80‑CE is **ATM**). What does the graph tell us?

| Observation | What it means for traders |
|-------------|---------------------------|
| **Gamma low when spot > strike** (OTM) | OTM options barely change delta, so their premiums move slowly in absolute rupee terms. A move from ₹2.00 to ₹2.50 is only a 50‑paisa change, but a **25 %** jump. |
| **Gamma peaks at ATM** | Delta changes *fastest* right at the money. ATM options are the most “touch‑y” to spot moves – a perfect storm for *long Gamma* lovers and a nightmare for *short Gamma* sellers. |
| **Gamma low when spot < strike** (ITM) | ITM options have a high base delta, but their delta drifts slowly because Gamma is small. Premiums move a lot in rupee terms (high delta) but not dramatically per point of spot. |
| **All strikes behave the same way** | Regardless of whether you look at 80, 100 or 120, the Gamma curve is a hump that peaks at the strike and falls off on both sides. |

### Three bite‑size takeaways  

1. **Delta rockets for ATM options.**  
2. **Delta crawls for deep OTM or deep ITM options.**  
3. **Never short an ATM or heavily ITM option hoping it will “die” at expiry** – the Gamma will bite you before then.  
4. **OTM options are the usual suspects for short‑option strategies** (they have low Gamma, so the delta won’t explode if the market nudges a little).

---

## 13.4 – Quick note on Greek interactions  

You’ve mastered the solo acts (Delta and Gamma). The real show, however, is the **ensemble performance** of the Greeks. Markets are never static – time ticks, volatility breathes, and the underlying price hops. A savvy options trader learns not only how each Greek behaves *alone* but also how they **interact**.

Typical cross‑Greek duets you’ll meet:

| Pair | What you might see |
|------|-------------------|
| **Gamma ↔ Time (Theta)** | As expiry approaches, Gamma usually **shrinks** (the hump flattens) while Theta (time decay) **accelerates**. |
| **Gamma ↔ Volatility (Vega)** | Higher implied volatility **inflates** Gamma (the hump gets taller). |
| **Vega ↔ Time** | Vega peaks a bit before expiry, then fades as there’s less “time value” left. |
| **Delta ↔ Time** | Delta drifts towards 0 (for calls) or –1 (for puts) as expiration nears and the option becomes either deep OTM or deep ITM. |

Understanding these relationships answers the big strategic questions:

- **Which strike should I trade given today’s market vibe?**  
- **Do I expect the premium to rise or fall?** (Buy or sell?)  
- **If I buy, is there enough “room” for the premium to climb?**  
- **If I sell, can I see the hidden risk that a naked eye might miss?**  

When you internalize both the *individual* Greeks and their *cross* effects, you’ll be able to pick strikes, size positions, and set stops with the confidence of a bartender who knows every cocktail recipe by heart.

### What’s coming up?  

| Roadmap |
|--------|
| ✅ We’ve nailed **Delta** and **Gamma**. |
| 📅 Next chapters: **Theta** (time decay) and **Vega** (volatility). |
| 📈 When Vega lands, we’ll detour into volatility‑based stop‑losses. |
| 🔀 Then we’ll explore **Greek cross‑interactions** (Gamma‑vs‑Time, Gamma‑vs‑Spot, Theta‑vs‑Vega, etc.). |
| 🧮 A quick tour of the **Black‑Scholes** pricing formula. |
| 🧰 Finally, an **Option calculator** to let you play with numbers yourself. |
| 🚶‍♂️ Bottom line: a *lot* of walking before we can finally sit down for a drink! |

---

### Key takeaways from this chapter  

- **Gamma** = rate of change of Delta (Δ per underlying point).  
- Gamma is **always positive** for both calls and puts.  
- **Large Gamma → large directional (Gamma) risk.**  
- Buying options = **Long Gamma**; selling options = **Short Gamma**.  
- **Avoid shorting options with big Gamma** unless you have a solid hedge.  
- **Delta shifts fast for ATM options, slowly for OTM/ITM.**  
- The Greeks *talk* to each other; know those conversations to avoid nasty surprises.  

*Special shout‑out to our good friend **Prakash Lekkala** for the beautiful Greek graphs that made this chapter possible.* 🎨