# 6.  The Put‑Option‑Selling  
**Source:** <https://zerodha.com/varsity/chapter/the-put-option-selling/>

---  

## 6.1 – Building the case  

Remember the old saying: “Every option buyer has a seller on the other side, and they’re basically arguing about the same future price like two drunk cousins at a family reunion.” The buyer’s crystal‑ball says *“the market will go down,”* while the seller’s crystal‑ball says *“nah, it’ll rise.”*  

So if a put‑buyer is bearish, the put‑seller must be wearing rose‑colored glasses – i.e., bullish.  
In the previous chapter we dissected the Bank Nifty chart; let’s pull that same chart out of the drawer, but now wear the seller’s spectacles.  

![Bank Nifty chart (same as before)](http://zerodha.com/varsity/wp-content/uploads/2015/04/Image-1_-Bank-Nifty1.png)

**Typical mental monologue of a put‑seller** (read in a “I‑know‑what‑I’m‑doing” tone):

1. **Current price:** Bank Nifty is chilling at **18 417**.  
2. **Two days ago:** It tried to kiss the resistance at **18 550** (green line).  
3. **Why is 18 550 a resistance?** Because a handful of price‑action zones have set up camp there over a respectable stretch of time. (If “resistance” sounds like a yoga pose, go read the article I linked earlier – it’ll straighten you out.)  
4. **I’ve boxed the zone** in a nice blue rectangle for visual pleasure.  
5. **Trend check:** The index has tried to smash through that ceiling **three** times in a row.  
6. **What could finally push it over?** Maybe a big‑bank earnings bomb – HDFC, ICICI, SBI are about to drop results.  
7. **If that happens**, we could see a clean break‑out and an upward swing.  
8. **Conclusion:** Selling a put and pocketing the premium looks tasty.

> **Reader’s question:** “If I’m bullish, why not just buy a call instead of selling a put?”  

Great question, you future‑option‑guru. The choice boils down to **premium attractiveness**.  
*If* the call’s premium is cheap, buying the call is a good deal.  
*If* the put’s premium is **expensive**, selling the put to collect that fat premium makes sense.  
Deciding “expensive” vs. “cheap” needs a little background in **option pricing**, which we’ll cover later in the module.  

For now, picture the trader writing (i.e., selling) the **18 400** put and pocketing **₹315** as the premium. As always, let’s watch the P&L curve for a put‑seller and draw a few universal rules.

> **Side note:** Whenever you write (sell) options – calls *or* puts – your broker blocks margin in your account. We explained that earlier [here](); give it a skim if you haven’t already.

![Put‑seller P&L skeleton](http://zerodha.com/varsity/wp-content/uploads/2015/04/M5-Ch6-title.png)

---

## 6.2 – P&L behavior for the put option seller  

First, a quick refresher: **Intrinsic value** is calculated the same way whether you’re buying or selling a put. What changes is the **P&L** (profit‑and‑loss) formula, because the cash flow direction flips. We’ll walk through a handful of expiry‑day scenarios and see how the numbers behave.

By now you should be comfortable spotting the pattern – we’ve done the same exercise for calls and for long puts in the previous chapters. Here’s the cheat‑sheet (focus on the row with strike **18 400**, that’s our trade’s anchor):

| Spot at expiry | What happens to the seller? |
|----------------|-----------------------------|
| **≥ 18 400**   | Premium stays in the pocket – flat **₹315** profit. |
| **< 18 400**   | Loss starts to creep in, and it can keep growing without a ceiling (theoretically unlimited). |

Let’s turn those words into solid **generalizations**:

1. **Generalization 1** – *Bullish sellers win as long as the underlying never falls below the strike.* In plain English: sell a put only when you think the market will stay flat or rise.  
2. **Generalization 2** – *A put‑seller’s loss is uncapped once the spot dips under the strike.* The deeper the market falls, the larger the hole in your wallet.

You can compute the exact P&L with a tidy one‑liner (valid for positions held **to expiry**):

\[
\text{P\&L} = \text{Premium Received} \;-\; \max\bigl(0,\; \text{Strike} - \text{Spot}\bigr)
\]

Let’s test it with two random spot levels, just for fun.

### Example 1 – Spot = **16 510** (well below the strike)

\[
\begin{aligned}
\text{P\&L} &= 315 \;-\; \max\bigl(0,\; 18\,400 - 16\,510\bigr)\\
           &= 315 \;-\; \max(0,\,1\,890)\\
           &= 315 - 1\,890\\
           &= -1\,575
\end{aligned}
\]

A loss of **₹1 575**, as expected.

### Example 2 – Spot = **19 660** (comfortably above the strike)

\[
\begin{aligned}
\text{P\&L} &= 315 \;-\; \max\bigl(0,\; 18\,400 - 19\,660\bigr)\\
           &= 315 \;-\; \max(0,\,-1\,260)\\
           &= 315 - 0\\
           &= 315
\end{aligned}
\]

Profit capped at the premium, **₹315**.

Both numbers line up perfectly with our earlier intuition.

#### The “break‑down point”  

The breakdown point is the spot price where the seller’s premium is completely eaten up – any further dip turns profit into loss. Compute it as:

\[
\text{Breakdown Point} = \text{Strike} - \text{Premium Received}
\]

For our Bank Nifty example:

\[
18\,400 - 315 = 18\,085
\]

At **₹18 085** the seller is **break‑even** (zero P&L). Let’s verify with the formula:

\[
\begin{aligned}
\text{P\&L} &= 315 - \max\bigl(0,\;18\,400 - 18\,085\bigr)\\
           &= 315 - \max(0,315)\\
           &= 315 - 315\\
           &= 0
\end{aligned}
\]

Exactly what the theory predicts – the whole premium disappears, but you haven’t lost any more than that.

---

## 6.3 – Put option seller’s payoff  

If you plot those P&L points on a graph and join the dots, you get the classic **put‑seller payoff curve**. (Imagine a smiling “‑” that flips into a frown once you cross the strike.)

![Put‑seller payoff diagram](http://zerodha.com/varsity/wp-content/uploads/2015/04/Image-3_Payoff.png)

**Key visual takeaways** (remember, the vertical line at **18 400** is the strike):

| Observation | What it means for you |
|-------------|-----------------------|
| **Profit flat above strike** | As long as the spot stays **≥ 18 400**, you keep the **₹315** premium – no extra upside. |
| **Loss below strike** | Once the spot slips under **18 400**, you start losing money, and the loss can keep growing (theoretically unlimited). |
| **Maximum gain = premium** | You can’t earn more than the premium you collected. |
| **Break‑down point at 18 085** | At this level you break even – you’ve given up the whole premium, but you’re not in the red yet. |
| **Graph’s kink** | The curve bends exactly at the breakdown point, turning from a flat profit line to a downward slope. |

With those bullets you should now have the *essence* of put‑option selling: you’re basically betting that the market won’t fall too far, and you get paid upfront for that optimism. In the next chapter we’ll wrap up the buyer vs. seller story for both calls and puts, then jump into some other must‑know option concepts.

---

### Key take‑aways from this chapter  

- **Bullish cue → sell a put** (or buy a call). You sell a put when you think the underlying won’t go lower.  
- **Premium attractiveness decides the trade** – if the put premium is rich, selling it may be better than buying a call.  
- **Option‑pricing theory + Greeks** help you judge whether a premium is “rich” or “cheap.”  
- **Buyer vs. seller P&L are mirror images** – what makes the buyer smile makes the seller frown, and vice‑versa.  
- **Selling a put puts cash in your pocket now** (the premium).  
- **Margin is required** when you write options; the broker freezes a portion of your account as safety.  
- **Profit ceiling = premium collected**; **loss potential = unlimited** (the market can keep dropping).  
- **Formula:** `P&L = Premium received – Max[0, (Strike – Spot)]`.  
- **Breakdown point:** `Strike – Premium`. Below that you start bleeding money.

Now go forth, sell those puts wisely, and may your bullish instincts be as solid as a well‑stacked pizza box! 🍕🚀  