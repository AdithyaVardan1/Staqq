# 20. Greek Interactions  

**Source:** https://zerodha.com/varsity/chapter/greek-interactions/  

---  

##  

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/09/M5-ch20-cartoon1.png)  

## 20.1 – Volatility Smile  

We brushed on “inter‑Greek” quirks in the last chapter and saw how they nudge option premiums up and down.  Now it’s time to dig a little deeper, because knowing where the smile hides can make you pick the *right* strikes (and not end up with a face that looks more like a grimace).  

Before we get into the heavy‑lifting, let’s pause for a quick coffee‑break tour of two side‑kicks of volatility: **Volatility Smile** and **Volatility Cone**.  

### What the heck is a Volatility Smile?  

In a perfect‑world textbook, every option on the same underlying that expires on the same day would wear the same **Implied Volatility (IV)** shirt.  In reality, the market is more like a high‑school prom—some options dress up fancier than others.  

Take a look at this screenshot from 4 Sept 2015 for State Bank of India (SBI):  

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/09/Image-1_Vol-smile.png)  

SBI was dancing around the ₹225 mark, so the 225‑strike is the *at‑the‑money* (ATM) option—highlighted with a blue band. The two green bands are the IVs of every other strike.  

**Notice the pattern:** as you drift away from the ATM strike—whether you go up the call ladder or down the put ladder—the implied volatility **climbs**. The farther you get, the higher the IV.  This isn’t a one‑off; you’ll see the same grin on most stocks and indices.  

If you plot “strike vs. IV”, you end up with a curve that looks like a happy mouth, hence the moniker **Volatility Smile** 😊  

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/09/Image-2_Vol-smile.png)  

That’s all there is to the smile—no need to dissect it for now, just remember that OTM options usually carry a fatter IV than their ATM sibling.  

---  

## 20.2 – Volatility Cone  

*(All the graphs in this section were lovingly crafted by Prakash Lekkala.)*  

We haven’t formally introduced the **Bull Call Spread**, but let’s assume you’ve already met that friendly‑neighbourhood strategy.  

Why does IV matter for a Bull Call Spread? Imagine you’re bullish on a stock and you buy a 7800 CE and sell a 8000 CE (classic bull‑call spread).  

| Situation | IV | Cost of spread | Max profit |
|-----------|----|----------------|------------|
| Low volatility | 20 % | ₹72 | ₹128 |
| High volatility | 35 % | ₹82 | ₹118 |

When IV is **high**, you pay **more** upfront and the profit envelope **shrinks**. When IV is **low**, you pay less and the upside looks juicier.  

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/09/M5-ch20-cartoon2.png)  

So, before you jump on any options trade, you need a “volatility radar” to tell you whether you’re buying at a discount or paying a premium.  

### The dilemma: Which underlying should you pick?  

- Nifty ATM IV ≈ 25 %  
- SBI ATM IV ≈ 52 %  

Do you chase the cheaper‑looking Nifty, or do you like the “high‑stakes” SBI?  

Enter the **Volatility Cone**—your new best friend for answering exactly that kind of “is it cheap or is it expensive?” question.  It works across strikes **and** across securities, so you can compare apples to oranges (or Nifty to SBI) without breaking a sweat.  

### Building a Volatility Cone, step‑by‑step  

1. **Grab a 15‑month Nifty chart** – the vertical lines mark expiry dates, the little boxes just before each line capture the price swing of Nifty in the **10 days** leading up to expiry.  

   ![Image](http://zerodha.com/varsity/wp-content/uploads/2015/09/Image-3_-Nifty.png)  

2. **Compute realized volatility** for each box.  The resulting table (not reproduced here) shows that Nifty’s realized vol over those 10‑day windows ranged from a **high of 56 %** (Feb 2015) down to a **low of 13 %** (Apr 2015).  

3. **Calculate the mean and variance** of those realized vol numbers—gives you a statistical “center” and “spread”.  

4. **Repeat** the whole thing for windows of 10, 20, 30, 45, 60 and 90 days.  You now have a matrix of vol figures for each “days‑to‑expiry” bucket.  

5. **Plot it**.  The picture you get looks like a funnel widening as you move right—hence the name **Volatility Cone**.  

   ![Image](http://zerodha.com/varsity/wp-content/uploads/2015/09/Image-4_VC.png)  

**How to read it:**  
Pick a “days‑to‑expiry” column (say 30 days).  Directly above it you’ll see a stack of points representing historic realized vol for that horizon.  The bottommost point is the **minimum**, then you have the **‑2 SD**, **‑1 SD**, **average**, **+1 SD**, **+2 SD**, and finally the **maximum**.  Remember, the cone is built on **realized** volatility, not implied.  

Now sprinkle today’s **implied** volatility on the same graph.  Below is an example for September 2015 (near‑month) and October 2015 (next‑month) Nifty options:  

- **Blue dots** = Calls  
- **Black dots** = Puts  

Each dot corresponds to a single option contract (e.g., 7800 CE, 8000 CE, 8100 PE, etc.).  

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/09/Image-5_Overlap1.png)  

The **first cluster** (leftmost) sits at **x = 12**, meaning those contracts expire in 12 days (September).  The **next cluster** sits at **x = 43**, i.e., 43 days away (October).  

### What the cones are whispering to you  

- A **blue dot** perched **above the +2 SD line** (the top maroon line) tells you: “Hey, this 8200 CE is *expensive*—its IV is two standard deviations higher than what we’ve historically seen for 43‑day expiries.”  That’s a classic candidate for a **short‑vol** trade (sell the vol, hope it cools).  

- A **black dot** hugging the **‑2 SD line** says: “This put is *cheap*—its IV is unusually low.”  You could consider **buying** it, betting the market will bump the IV back up.  

In short, the cone lets you spot **mis‑priced** options:  
- **+2 SD** → likely **overpriced** → think **short**.  
- **‑2 SD** → likely **underpriced** → think **long**.  

**Pro tip:** Only do this on liquid strikes; otherwise you’ll be chasing ghosts.  

With the Volatility Smile and the Volatility Cone under your belt, you now have a solid, visual way to gauge whether an option’s premium is justified by the market’s past behaviour.  

---  

## 20.3 – Gamma vs Time  

Time to turn the spotlight onto **Gamma**—the mischievous little sibling of Delta that tells you how fast Delta itself is moving.  Quick refresher:  

- **Gamma = Δ(Delta) / Δ(Underlying)** – the *rate* of change of Delta.  
- It’s **always positive** for both calls and puts (so it never flips sign on you).  
- Large Gamma → large “Gamma risk” (i.e., your position becomes very sensitive to price moves).  
- Buying an option → you’re **long Gamma**.  
- Selling an option → you’re **short Gamma**.  
- **Rule of thumb:** *Avoid shorting options with a big Gamma* (unless you enjoy heart‑stopping drama).  

### The “What‑if” scenario  

Suppose you *do* want to short a low‑Gamma option and hold it till expiry, hoping to pocket the entire premium.  The million‑dollar question: **Will Gamma stay low the whole way?**  

The answer lives in the relationship between **Gamma and time‑to‑expiry**.  

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/09/Image-6_Gamma-vs-Time2.png)  

**How to read this graph:**  
- **X‑axis:** *time to expiry* (but read it **right‑to‑left**).  Rightmost point = “plenty of time” (value = 1).  Leftmost point = “expiration day” (value = 0).  
- **Y‑axis:** Gamma.  

Key takeaways:  

1. **Ample time** (right side) → all three strikes (ITM, ATM, OTM) sport **low Gamma**.  ITM’s Gamma is the *lowest* of the trio.  
2. **Half‑way to expiry** → Gamma stays roughly flat for all three.  
3. **As expiry looms**:  
   - **ITM** and **OTM** Gamma **plummet toward zero**.  
   - **ATM** Gamma **shoots up like a fireworks finale**.  

**Bottom line:** Short‑selling an **ATM** option *right before expiry* is a recipe for a heart‑attack (Gamma spikes).  

### Visualising three variables at once  

Because we’re juggling **Gamma**, **time‑to‑expiry**, and **strike**, a 3‑D surface plot does the trick.  

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/09/Image-7_Gamma-vs-Time1.png)  

- **X‑axis:** Days to expiry.  
- **Y‑axis:** Gamma value.  
- **Z‑axis (the “depth” of the surface):** Strike.  

Red arrows point to three representative strike‑lines:  

- **Outer lines** = deep **OTM** or deep **ITM**.  
- **Middle line** = **ATM**.  

The picture makes it crystal clear: as you sprint toward expiry, the **outer lines flatten** (Gamma → 0), while the **central line spikes** (Gamma stays high).  

Switch the perspective to look *straight at the strike* dimension:  

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/09/Image-8_Strikes1.png)  

Same story, just a different camera angle—ATM Gamma rockets, others fade.  

And if you’re a fan of moving pictures, here’s a GIF that rotates the surface so you can watch Gamma dance with strike and time:  

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/09/GIF-1_-section-20.3.gif)  

(If the animation refuses to play, click on it—HTML loves a good click.)  

Now you’ve seen, in three‑dimensional glory, why **short‑ATM** near expiry is a risky gamble and why **ITM/OTM** options become “Gamma‑dead” as the clock ticks down.  

---  

## 20.4 – Delta versus implied volatility  

Let’s switch gears and talk about **Delta’s mood swings** when implied volatility changes.  

Here’s a snapshot taken on **11 Sept 2015** when Nifty was at **7,794**.  It shows a **6800 PE** (a put that’s **1,100 points OTM**) trading for **₹8.3**.  

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/09/Image-9_6800-PE.png)  

**Question:** Why would anyone pay ₹8.3 for a contract that’s so far out of the money?  The market would need to drop **14 %** in just **11 trading sessions** (plus two holidays) – a pretty wild ride.  

The answer lies in the **Delta‑vs‑IV** relationship.  

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/09/Image-10_Delta-vs-Volatility-2.png)  

**What you’re looking at:**  

| Line | Option type | Implied Volatility |
|------|-------------|--------------------|
| **Blue** | Call | 20 % |
| **Red** | Call | 40 % |
| **Green** | Put | 20 % |
| **Purple** | Put | 40 % |

- Call‑Delta ranges from **0 → 1**.  
- Put‑Delta ranges from **0 → ‑1**.  
- Assume the underlying price is **175**, making 175 the ATM strike.  

### Decoding the curves  

1. **Low IV (20 %) – blue & green lines**  
   - Deep‑ITM options flatten at **Δ ≈ 1** (calls) or **Δ ≈ ‑1** (puts).  
   - Deep‑OTM options flatten near **Δ ≈ 0**.  In plain English: with low volatility, an OTM option is almost worthless, and an ITM option behaves like a futures contract.  

2. **High IV (40 %) – red & purple lines**  
   - The ends *don’t* flatten.  Even deep‑OTM options retain a **noticeable delta** because volatility makes the distant strike feel “closer”.  
   - Around the ATM region, the slopes are steeper – a tiny move in the underlying will cause a **big move in the option’s price**.  

3. **Key observation:** When volatility is high, the delta of a far‑OTM put (like our 6800 PE) is **not zero**; it hangs around a small but non‑zero value, giving the option a **non‑trivial premium**.  

That’s why the 6800 PE isn’t a free‑bie—it carries a **price** because the market is pricing in a *possibility* of big moves (high IV).  

Take a peek at the **India VIX** chart for that day (showing the market’s fear gauge):  

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/09/Image-11_-India-Vix_Sept11.png)  

Higher VIX → higher IV → higher delta for far‑OTM options → fatter premiums.  

**Takeaway:** Don’t judge an option’s price solely by “how far OTM it is”.  Look at the **IV**; if the market is jittery, even the most out‑of‑the‑money contracts can carry a respectable premium.  

---  

### Key takeaways from this chapter  

- **Volatility Smile** reminds you that OTM options usually sport **higher IVs** than ATM strikes.  
- The **Volatility Cone** lets you compare today’s implied volatility against historic realized volatility, highlighting *cheap* vs *expensive* options.  
- **Gamma** peaks for ATM options **as expiry approaches**; ITM and OTM gammas decay toward zero.  
- **Delta’s behavior** is tame near the extremes when IV is low, but **gets lively** (non‑zero for deep OTM, steeper slopes around ATM) when IV is high.  
- High IV → far‑OTM options retain a **non‑zero delta**, explaining why they can still command a decent premium.  

Armed with these Greek insights, you can now read the market’s “mood” like a bartender reads a regular’s order—quick, accurate, and with a dash of humor. Happy trading!  