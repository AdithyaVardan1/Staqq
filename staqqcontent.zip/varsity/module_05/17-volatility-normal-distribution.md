# 17. Volatility & Normal Distribution  

**Source:** https://zerodha.com/varsity/chapter/volatility-normal-distribution/  

---  

## 17.1 – Background  

In the last chapter we played “guess‑the‑range” with Nifty: we knew its annualised volatility, crunched some maths and ended up with a *upper* and a *lower* band where we thought Nifty would probably hang out. We even bragged that Nifty was “likely” to stay inside that corridor.  

But hold on a sec – how *sure* are we? Could the market decide to swing outside our neat little box? If it does, what are the odds of that happening, and what would those “outside” numbers even look like?  

Answering those questions is more than just academic bragging. It’s the first brick of a quantitative approach to markets – a way of thinking that’s quite a different animal from the usual fundamental‑or‑technical‑analysis chatter.  

So let’s roll up our sleeves, dig a little deeper, and get those answers (with a side of jokes).  

---  

## 17.2 – Random Walk  

What we’re about to discuss is both *crucial* and *fascinating* – kind of like discovering that your favorite pizza place also serves ice‑cream.  

Take a look at the picture below:  

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/08/M5-C17-GaltonBoard11.png)  

That contraption is a **Galton Board** (sometimes called a bean machine). Pins are glued to a board, and a row of bins sits hungrily beneath them.  

The game is simple: drop a tiny steel ball from the top. The ball hits the first pin, then decides – left or right? – hits the next pin, decides again, and so on until it finally plunks into one of the bins.  

Once the ball is airborne, you have **zero** control over its fate. Its path is completely natural, not pre‑programmed. That “let‑it‑do‑its‑thing” journey is what we call a **Random Walk**.  

Now imagine a *lot* of balls being dropped, one after another. Each ball still takes its own random walk, but what will the *overall* picture look like?  

- Will all the balls end up in the same bin?  
- Will they spread out perfectly evenly?  
- Or will they land in some other pattern?  

If you’re not a physics nerd, you might guess “randomly everywhere”. Spoiler alert: that’s **not** what happens. There *is* an order.  

Check out the next image:  

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/08/M5-C17-GaltonBoard2.png)  

What you see is a classic **Normal Distribution** – the beloved bell curve that haunted you in high‑school math class.  

Key observations:  

- Most balls pile up in the *central* bin.  
- As you move away from the centre, the count thins out.  
- The far‑left and far‑right bins are practically empty.  

And the crazy part? No matter how many times you repeat the experiment, the shape stays the same – a perfect bell.  

If you’re a visual learner, there’s a gorgeous video out there that walks you through the whole thing – worth a watch on a lazy Sunday.  

### Why does a bean‑machine matter to finance?  

Because a *lot* of real‑world phenomena obey the same pattern:  

| Phenomenon | How it looks in a histogram |
|------------|------------------------------|
| Adult human weights | Bell‑shaped, centred around ~70 kg |
| Heights | Same story – most people are around 5’7” |
| Shoe sizes | You’ll see a peak around size 9 |
| Fruit/vegetable weights | Think apples: most are 150 g, few are 300 g |
| Commute times | Most people take ~30 min, not 5 or 120 |
| Battery lifetimes | Most last ~500 cycles, few last 1000 or 100 |

…and the list goes on.  

The **star player** for us traders is **daily stock returns**. They’re as unpredictable as a ball’s random walk, but when you collect a *lot* of them and plot them, you’ll see the same bell curve.  

Here’s a snapshot of daily returns for a few Indian equities and indices:  

- Nifty (index)  
- Bank Nifty (index)  
- TCS (large‑cap)  
- Cipla (large‑cap)  
- Kitex Garments (small‑cap)  
- Astral Poly (small‑cap)  

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/08/Image-3_ND-stocks.png)  

See? The bell is there, loud and clear.  

You’re probably thinking, “Okay, cool, but what does this have to do with volatility?” Patience, my friend – the next cartoon will bridge the gap.  

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/08/M5-Ch17-cartoon.png)  

---  

## 17.3 – Normal Distribution  

If you’re new to the normal distribution, this can feel like being handed a three‑volume encyclopedia and asked to read only the first page. So let’s break it down, tie it back to the Galton board, and then swing it over to the market.  

There are *many* ways data can be spread: binomial, uniform, Poisson, chi‑square… but the **Normal Distribution** is the rock‑star – the most studied, the most useful, and the most likely to pop up when you least expect it.  

### Two numbers rule the bell  

A normal curve is **fully described** by just **two** statistics:  

1. **Mean (µ)** – the centre of the mountain, where the most observations cluster. In the Galton board, it’s the bin with the most balls.  
2. **Standard Deviation (σ)** – the “spread” or “dispersion” around the mean. In finance, σ is the same as **volatility**.  

#### Quick note on terminology  

When people shout “Standard Deviation!” they usually mean **1σ** (one standard deviation).  
- **2σ** = 2 × σ  
- **3σ** = 3 × σ  
…and so on.  

#### An example with the board  

Suppose the board’s mean is bin 5 and σ = 1 (just for illustration). Then:  

| σ‑band | Bins covered | What it means |
|-------|--------------|----------------|
| 1σ | 4 – 6 | One bin left/right of the centre |
| 2σ | 3 – 7 | Two bins left/right |
| 3σ | 2 – 8 | Three bins left/right |

#### The magic percentages  

The normal curve has a built‑in “confidence” schedule:  

| Band | Percentage of observations |
|------|-----------------------------|
| 1σ   | **68 %** |
| 2σ   | **95 %** |
| 3σ   | **99.7 %** |

Visualised, it looks like this:  

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/08/M5-C17-ND-graph1.png)  

Applying it back to our Galton board:  

- **68 %** of balls land between bins 4 and 6 (1σ).  
- **95 %** land between bins 3 and 7 (2σ).  
- **99.7 %** land between bins 2 and 8 (3σ).  

### A chat between two friends (you & me)  

> **You:** I’m about to drop a ball. Any clue where it’ll land?  
> **Me:** I can’t name the exact bin – it’s a random walk. But I can give you a *range*.  
> **You:** Shoot.  
> **Me:** Most likely it’ll land between bins 4 and 6. I’m **68 %** sure of that.  
> **You:** 68 % feels a bit shaky. Can you be more confident?  
> **Me:** Sure. Between bins 3 and 7 I’m **95 %** confident. Want the ultra‑safe zone? Between bins 2 and 8 I’m **99.7 %** sure.  
> **You:** Does that mean it’ll never hit bin 1 or 9?  
> **Me:** It *can* – just extremely unlikely. Think “Black Swan in a river”. Probability < 0.5 %.  
> **You:** Tell me more about that Black Swan.  
> **Me:** Black‑swan events are those rare out‑of‑the‑ordinary outcomes (like a ball landing in bin 1 or 9). They’re improbable, not impossible.  

Here’s a picture of those rare‑event balls:  

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/08/M5-C17-GaltonBoard42.png)  

Even after dropping *tons* of balls, only a handful make it to the extreme bins.  

---  

## 17.4 – Normal Distribution and Stock Returns  

Now that we’ve tamed the bell curve with pins and balls, let’s bring it home to the market. The daily returns of stocks and indices behave **almost** exactly like the balls on the Galton board – they form a bell‑shaped (normal) distribution.  

Why does this matter? Because if we know a stock’s **mean return** and its **standard deviation (volatility)**, we can estimate how far the price is likely to wander over any horizon. Let’s walk through a concrete example with **Nifty**.  

### Nifty’s daily‑return distribution  

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/08/Image-7_Nifty-SD.png)  

The histogram screams “normal!” – you can see the classic hill. Using log‑daily returns (the proper way), we get:  

| Statistic | Value |
|-----------|-------|
| **Mean (μ)** | **0.04 %** per day |
| **Std‑Dev (σ)** | **1.046 %** per day |
| **Current Nifty price** | **8 337** |

An average of **0.04 %** means the *center* of the daily‑return distribution sits just a hair above zero.  

Now we’ll answer two practical questions:  

1. **What range is Nifty likely to be in over the next **1 year**?**  
2. **What range over the next **30 days**?**  

In both cases we’ll look at the **1σ (68 % confidence)** and **2σ (95 % confidence)** bands.  

---  

### Solution 1 – Nifty’s one‑year range  

First, annualise the daily stats:  

- **Annual mean** = 0.04 % × 252 ≈ **9.66 %**  
- **Annual σ** = 1.046 % × √252 ≈ **16.61 %**  

> *(We use 252 trading days per year; √252 ≈ 15.874.)*  

#### 68 % confidence (±1σ)  

- Upper log‑return = 9.66 % + 16.61 % = **26.66 %**  
- Lower log‑return = 9.66 % – 16.61 % = **‑6.95 %**  

Convert log‑returns to price levels (e⁽ⁿ⁾ = exponential):  

- **Upper price** = 8 337 × e^(0.2666) ≈ **10 841**  
- **Lower price** = 8 337 × e^(‑0.0695) ≈ **7 777**  

> So, with **68 %** confidence, Nifty should finish the year somewhere between **7 777** and **10 841**.  

#### 95 % confidence (±2σ)  

- Upper log‑return = 9.66 % + 2 × 16.61 % = **42.87 %**  
- Lower log‑return = 9.66 % – 2 × 16.61 % = **‑23.56 %**  

Converted to price:  

- **Upper** = 8 337 × e^(0.4287) ≈ **12 800**  
- **Lower** = 8 337 × e^(‑0.2356) ≈ **6 587**  

> With **95 %** confidence, the one‑year band widens to **6 587 – 12 800**. Notice how the range expands as we demand more certainty.  

You could push this out to **3σ (99.7 %)** and you’ll get an even larger corridor (think: a lower bound somewhere near 5 000). That doesn’t mean Nifty can’t dip below 5 000 – it just means the odds are *tiny*, a classic **Black‑Swan** scenario.  

---  

### Solution 2 – Nifty’s 30‑day range  

Now let’s shrink the horizon to a month.  

- **30‑day mean** = 0.04 % × 30 ≈ **1.15 %**  
- **30‑day σ** = 1.046 % × √30 ≈ **5.73 %**  

#### 68 % confidence (±1σ)  

- Upper log‑return = 1.15 % + 5.73 % = **6.88 %**  
- Lower log‑return = 1.15 % – 5.73 % = **‑4.58 %**  

Price conversion:  

- **Upper** = 8 337 × e^(0.0688) ≈ **8 930**  
- **Lower** = 8 337 × e^(‑0.0458) ≈ **7 963**  

> So, with **68 %** confidence, Nifty should be between **7 963** and **8 930** in the next 30 days.  

#### 95 % confidence (±2σ)  

- Upper log‑return = 1.15 % + 2 × 5.73 % = **12.61 %**  
- Lower log‑return = 1.15 % – 2 × 5.73 % = **‑10.31 %**  

Converted:  

- **Upper** = 8 337 × e^(0.1261) ≈ **9 457**  
- **Lower** = 8 337 × e^(‑0.1031) ≈ **7 520**  

> With **95 %** confidence, the 30‑day corridor widens to **7 520 – 9 457**.  

Feel free to download the Excel sheet I used for these calculations (link in the original chapter) and play around with your own numbers.  

> *You might be thinking:* “Nice math, but how do I **trade** with this?”  
> That’s the whole next chapter – we’ll discuss how to pick option strikes using these bands and how to size stop‑losses with volatility. Spoiler: Vega will make an appearance.  

---  

### Key takeaways from this chapter  

- Daily stock returns are a **random walk** – you can’t predict the exact next step.  
- Those returns are **approximately normally distributed** (bell‑shaped).  
- A normal distribution is anchored by a **mean** and **standard deviation** (σ).  
- **68 %** of observations lie within **±1σ**.  
- **95 %** lie within **±2σ**.  
- **99.7 %** lie within **±3σ**.  
- Anything beyond **3σ** belongs to the realm of **Black‑Swan events** – rare but possible.  
- Knowing σ (volatility) lets you **estimate upper and lower price bounds** for any time horizon.  

That’s the “why” behind the bell curve and volatility – the foundation for the next chapter’s practical trading tools. Happy number‑crunching!  