# 21. Greek Calculator  

**Source:** https://zerodha.com/varsity/chapter/greek-calculator/  

---  

## 21.1 – Background  

Alright, you’ve survived the Greek‑god‑level tour of Delta, Gamma, Vega, Theta and Rho. You now know what each of them does, when they bite, and why they’re the reason you sometimes feel like you need a crystal ball. Time to roll up our sleeves and actually *compute* those Greeks instead of just staring at a spreadsheet that says “Δ = 0.73, go buy the dip!”  

Enter the Black‑&‑Scholes (B&S) options‑pricing calculator – the Swiss‑army‑knife of option nerds. The model was first published in 1973 by Fisher Black and Myron Scholes (hence the name). Robert C. Merton later polished it into a full‑blown mathematical beast, adding stochastic calculus and a sprinkling of partial‑differential‑equations for good measure.  

Why do we care? Because the model is so revered that Scholes and Merton walked away with the 1997 Nobel Prize in Economic Sciences (yes, the Nobel that *doesn’t* have a “Peace” category). The formula itself leans on a few heavy‑hitting concepts: normal distribution, stochastic processes, and the ever‑mysterious PDE. We’re **not** going to turn you into a PhD‑level quant today—if you want that, check out the Khan Academy video linked in the original chapter.  

Our mission here is simple: show you how to plug real‑world numbers into the B&S engine and get back the Greeks (and the “theoretical” price that you can compare to the market). Think of it as a magic‑8‑ball, except the answer is a bunch of numbers you can actually use in a trade.  

---

## 21.2 – Overview of the Model  

Picture the B&S calculator as a black box that looks like a vending machine. You drop in a handful of inputs (the “coins”), push a button, and out pops a tray of Greeks, plus the theoretical price of the call and the put for the strike you chose.  

**The input menu** (what you feed the beast):  

| Input | What it means (in plain English) | Typical source |
|-------|----------------------------------|----------------|
| **Spot price** | Current price of the underlying asset. If you’re trading a futures‑based option, you can swap the spot for the futures price. Equity options always use the spot. | Market data feed, your broker’s app |
| **Strike price** | The price at which you can buy (call) or sell (put) the underlying when you exercise. | Option chain |
| **Interest rate** | The risk‑free rate you’d earn on a “no‑risk” investment for the life of the option. In India we usually grab the RBI 91‑day T‑Bill rate. | RBI website (they publish it on the front page) |
| **Implied volatility (IV)** | The market‑implied expectation of how wildly the underlying will swing, expressed as an annualised standard deviation. | NSE option chain – look for the “IV” column |
| **Dividend** | Any cash dividend you expect the stock to pay *before* expiry. If the stock goes ex‑dividend during the option’s life, you have to subtract that cash‑flow. | Company announcements, corporate actions calendar |
| **Days to expiry** | Calendar days left until the option’s settlement date (not trading days). | Option chain, contract specs |

Below is the schematic that the original text showed – think of it as the wiring diagram of our vending machine. (We’ll keep the image placeholders so you can imagine the picture.)

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/10/M5-C21-Illustration.png)  

### Let’s walk through a real‑world example  

We’ll use an ICICI Bank call (ticker **ICICIBANK**, strike **280**, “CE” = call) that was live on **23 Sept 2015**. The data we need (all pulled from publicly available sources) is:  

| Variable | Value | Source / How we got it |
|----------|-------|------------------------|
| Spot price (S) | **₹272.7** | Live market price |
| Strike (K) | **₹280** | Option contract |
| Interest rate (r) | **7.4769 % p.a.** | RBI 91‑day T‑Bill (Sept 2015) |
| Dividend (q) | **0** (no ex‑div before 24 Sept) | Company calendar |
| Days to expiry (T) | **1** (23 → 24 Sept) | Calendar |
| Implied volatility (σ) | **43.55 %** | NSE option chain screenshot |

*(You can see the IV screenshot in the original chapter – a quick snap of the ICICI 280 CE line.)*  

Now, fire up the free B&S tool on Zerodha: <https://zerodha.com/tools/black-scholes>. Paste the numbers in, hit **Calculate**, and voilà! The output looks something like this:

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/09/Image-4_Greeks-1024x353.png)  

#### What you’ll see on the right side  

1. **Theoretical premiums** for the 280 CE (call) and 280 PE (put). In a perfect world, these numbers would match the market’s quoted bid‑ask, but small mismatches are normal because we’re feeding in approximations (e.g., using a single IV for the whole life).  
2. **All the Greeks** listed underneath: Δ, Γ, Θ, ν (Vega) and ρ. If you’ve already memorised what each one tells you, you’ll see how the numbers shift with the input changes (e.g., a higher IV inflates Vega, a longer T pushes Theta more negative, etc.).  

A quick sanity check: the theoretical price for the call should be close to the market price you see on NSE. If it’s wildly off, double‑check your inputs—maybe you used the wrong dividend, or the IV you pulled belonged to a different expiry.  

**Bottom line:** The calculator is a *very* handy side‑kick for option traders. It lets you see whether the market is over‑ or under‑pricing a contract relative to the classic B&S model. Small differences are expected; they’re the “model risk” you need to live with (or exploit, if you’re an arbitrageur).  

---

## 21.3 – Put‑Call Parity  

Now that we’ve geeked out over the calculator, let’s detour into a tidy little theorem that every options‑trader should have tattooed (figuratively) on their brain: **Put‑Call Parity (PCP)**.  

### The equation, in plain English  

```
Put price  +  Spot price  =  Present value of strike  +  Call price
```

In symbols (assuming continuous compounding):  

\[
P + S = K e^{-rT} + C
\]

Where:  

* **P** = price of an ATM (at‑the‑money) European put  
* **C** = price of the corresponding ATM European call  
* **S** = current spot price of the underlying  
* **K** = strike (the amount you’ll pay/receive at expiry)  
* **r** = continuously‑compounded risk‑free rate  
* **T** = time to expiry (in years)  

**Key assumptions** for the parity to hold:  

1. Both options are *European* (exercise only at expiry).  
2. They share the **same strike** and **same expiry**.  
3. The underlying pays **no dividend** (or you adjust the spot with the present value of expected dividends).  
4. Both positions are held *until expiry*—no early closing.  

If you’re fuzzy on the term *present value*, give the DCF primer a glance: <http://zerodha.com/varsity/chapter/dcf-primer/> (section 14.3).  

### Why does it work?  

Think of two traders who set up opposite sides of the same equation:

| Trader | Portfolio |
|--------|-----------|
| **A** | Long 1 ATM put **+** Long 1 share (the “left‑hand side”) |
| **B** | Long 1 ATM call **+** Cash equal to the discounted strike (the “right‑hand side”) |

Because both portfolios have the *same* payoff at expiry, arbitrage‑free markets force their *current* values to be equal—hence the parity.  

#### Walk‑through with numbers  

Let’s pick **Infosys** (ticker **INFY**) with a strike **K = ₹1,200** and spot **S = ₹1,200** (so it’s ATM).  

| Trader | Holding | Outcome if INFY closes at **₹1,100** |
|--------|---------|--------------------------------------|
| **A** | 1 × 1200 PE  + 1 × share | Put is worth ₹100 (right to sell at 1200), share is worth ₹1,100 → total **₹1,200** |
| **B** | 1 × 1200 CE  + cash **₹1,200** | Call is worthless (stock below strike), cash remains **₹1,200** |

Same total, right?  

Now flip the script: suppose INFY rockets to **₹1,350** at expiry.

| Trader | Holding | Outcome |
|--------|---------|---------|
| **A** | Put expires worthless, share worth ₹1,350 → total **₹1,350** |
| **B** | Call is worth ₹150 (₹1,350 − ₹1,200), cash **₹1,200** → total **₹1,350** |

Again, parity holds. No matter where the underlying ends up, the two portfolios end up with identical wealth.  

### What can you do with PCP?  

In practice, traders watch for **mis‑pricings**: if the left‑hand side (put + spot) is cheaper than the right‑hand side (call + present‑value‑strike), you could buy the cheap side and sell the expensive side, lock in a risk‑free profit (ignoring transaction costs and slippage).  

That’s a whole topic on its own and we’ll dive into it when we roll into the “Option Strategies” module. For now, just remember: PCP is the accounting identity that keeps the option world honest.  

---  

### Key Takeaways  

- The **Greek calculator** you just learned about runs on the Black‑&‑Scholes model, the same model that earned Scholes and Merton a Nobel.  
- B&S spits out a **theoretical price** *and* the full suite of Greeks when you feed it Spot, Strike, Risk‑free rate, Implied volatility, Dividend, and Days‑to‑expiry.  
- Use the **RBI 91‑day T‑Bill rate** as your risk‑free rate (e.g., 7.4769 % p.a. in Sep 2015).  
- **Implied volatility** comes straight from the NSE option chain—look for the “IV” column next to the contract you’re analysing.  
- **Put‑Call Parity** tells us that *Put + Spot = Call + Present‑value‑Strike* (for European, ATM, same‑expiry contracts).  
- When the parity is violated, an arbitrageur can construct a risk‑free profit—something you’ll explore in the next “Option Strategies” chapter.  

Now go forth, plug numbers, stare at Greek letters, and may your delta always be in your favour! 🍻