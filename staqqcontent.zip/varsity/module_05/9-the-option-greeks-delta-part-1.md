# 9. The Option Greeks (Delta) – Part 1  

**Source:** <https://zerodha.com/varsity/chapter/the-option-greeks-delta-part-1/>

---  

## 9.1 – Overview  

So I just finished watching the newest Bollywood blockbuster *Piku*.  Good film, right?  I found myself asking: “What made *Piku* click for me – the snappy storyline, Amitabh Bachchan’s legendary swagger, Deepika Padukone’s sparkle, or Shoojit Sircar’s masterful direction?”  The answer, like most good meals, was a little bit of everything.  

That got me thinking about options trading.  Believe it or not, a trade on an option is a lot like a Bollywood movie.  Both need several “actors” to work together for the final product to be a hit.  In the world of options those actors are called **the Option Greeks** – invisible forces that tug at an option’s premium every single minute, making it go up, down, or sideways.  And just like movie stars who sometimes step on each other’s toes, the Greeks don’t just act alone; they interact, amplify, or dampen one another.  

Picture two famous Bollywood brothers – Aamir Khan and Salman Khan.  In a film they each bring their own fan‑base (think “Greek” power).  If you drop them together in the same picture, you’ll get a lot of drama: they’ll try to out‑shine each other, help each other, and sometimes sabotage each other, all while the movie (i.e., the option premium) tries to stay afloat.  Not a perfect analogy, but you get the vibe: many independent forces, a single outcome.  

In the markets, **option premiums**, the **Greeks**, and the plain‑old supply‑and‑demand of buyers and sellers are all constantly chatting with each other.  They’re independent, yet they’re tangled up like a plate of spaghetti.  For a trader the crucial skill is to read the premium’s movements and infer what the Greeks are up to before committing capital.  

Alright, enough movie‑talk – let’s meet the cast:  

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/05/M5-Ch9-Illustration1.png)

| Greek | What it measures |
|-------|-----------------|
| **Delta** | How fast the premium changes when the underlying moves directionally |
| **Gamma** | How fast *Delta* itself moves |
| **Vega**  | How premium reacts to changes in volatility |
| **Theta** | How time‑erosion chips away at premium as expiry approaches |

We’ll unpack each of these in later chapters.  **Today’s mission:** get cozy with **Delta**.  

---  

## 9.2 – Delta of an Option  

Take a look at these two screenshots of the Nifty 8250 CE contract.  The first was taken at **09:18 AM** when the spot index was **8292**.  

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/05/Image-1_at-918.png)

A few minutes later…  

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/05/Image-2_nifty-8316.png)

Notice what happened?  At 09:18 the call was priced at **₹144**.  By **10:00 AM** Nifty had nudged up to **8315** and the same contract was now **₹150**.  

Fast‑forward to **10:55 AM** – Nifty slipped back to **8288**, and the premium slid down to **₹133**.  

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/05/Image-3_nifty-8288.png)

**Lesson #1:** Whenever the underlying price wiggles, the option premium wiggles in the same direction (for a call).  The call premium climbs when the index climbs, and it falls when the index falls.  

Now, imagine you’re a crystal‑ball‑wielding trader who thinks Nifty will hit **8355** by 3 PM.  From the snapshots we know the premium *will* move, but **by how much?**  That’s the moment Delta swoops in like a superhero.  

> **Delta** tells you: “For every 1‑point move in the underlying, my premium will move **X** points.”  

In other words, Delta quantifies the directional impact of the market on an option’s price.  

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/05/M5-Ch9-Illustration2.png)

### The range of Delta  

| Option type | Delta scale (decimal) | Delta scale (percentage) |
|-------------|----------------------|--------------------------|
| **Call**    | 0 → 1                | 0 → 100 %                |
| **Put**     | –1 → 0               | –100 % → 0 %             |

A call with a **0.55** decimal Delta is the same as a **55** on the 0‑100 scale.  A put with **–0.40** is **–40** on the –100‑0 scale.  (Why puts are negative? Stay tuned – we’ll get there.)  

**Road‑map for this chapter** (keep this cheat‑sheet handy, it’ll help you connect the dots later):  

1. How to wield Delta for **calls**  
2. A quick peek at how Delta is actually calculated  
3. How to wield Delta for **puts**  
4. Delta’s quirks – Delta vs. Spot, Delta acceleration (next chapter)  
5. Building option positions in terms of Delta (next chapter)  

Buckle up – the ride is about to start!  

---  

## 9.3 – Delta for a Call Option  

Remember, a call’s Delta lives between **0 and 1**.  Suppose you have a call with a Delta of **0.30** (or **30** on the percentage scale).  What does that number whisper to you?  

> “For every 1‑point hop the underlying makes, my premium will hop **0.30** points.  Or, for a 100‑point swing, I’ll swing **30** points.”  

### Example 1 – The bullish case  

| Item | Value |
|------|-------|
| Nifty (10:55 AM) | 8288 |
| Call strike | 8250 |
| Current premium | ₹133 |
| Delta | **+0.55** |
| Expected Nifty at 3:15 PM | 8310 |

**Step‑by‑step:**  

1. Expected underlying move = **8310 – 8288 = 22** points  
2. Premium change = **22 × 0.55 = 12.1** points  
3. New premium ≈ **133 + 12.1 = 145.1**  

So, if your crystal ball is right, the call should be trading around **₹145** by late afternoon.  

### Example 2 – The bearish case  

Same starting numbers, but now you think Nifty will **dip** to **8200**.  

1. Underlying move = **8200 – 8288 = –88** points  
2. Premium change = **–88 × 0.55 = –48.4** points  
3. New premium ≈ **133 – 48.4 = 84.6**  

A falling market drags the call’s price down – exactly what Delta warned you about.  

#### Why Delta matters when picking a contract  

Imagine you forecast a **100‑point surge** in Nifty and you have two call candidates:

| Call | Delta |
|------|-------|
| A | 0.05 |
| B | 0.20 |

**Premium impact:**  

* Call A: **100 × 0.05 = 5** points gain  
* Call B: **100 × 0.20 = 20** points gain  

Clearly Call B rewards you more for the same market move.  Delta is your shortcut to spotting the “right‑sized” contract.  

#### FAQ: Why can a call’s Delta never exceed 1 (or drop below 0)?  

Let’s break it with two “what‑if” scenarios.  

**Scenario 1 – Delta > 1 (impossible)**  

| Item | Value |
|------|-------|
| Nifty (10:55 AM) | 8268 |
| Call strike | 8250 |
| Premium | ₹133 |
| **Delta (pretend)** | **1.5** |
| Expected Nifty (3:15 PM) | 8310 |

Underlying move = **42** points → Premium change = **1.5 × 42 = 63** points.  
Result: Premium would jump from **₹133** to **₹196** – a **63‑point** rise while the underlying only moved **42** points.  That would mean the derivative out‑performed its own underlying, which is mathematically impossible.  By definition, the maximum sensible Delta for a call is **1** (the option moves *in lockstep* with the underlying).  

**Scenario 2 – Delta < 0 (also impossible for a call)**  

| Item | Value |
|------|-------|
| Nifty (10:55 AM) | 8288 |
| Call strike | 8300 (out‑of‑the‑money) |
| Premium | ₹9 |
| **Delta (pretend)** | **–0.2** |
| Expected Nifty (3:15 PM) | 8200 |

Underlying drop = **–88** points → Premium change = **–0.2 × –88 = +17.6** points.  
New premium = **9 + 17.6 = 26.6** (still positive, but the math shows the option would *gain* more than the underlying loses).  If we kept pushing the numbers, we could even get a *negative* premium – which cannot happen.  Hence a call’s Delta bottoms out at **0**.  

So the Delta range **0 → 1** is simply a consequence of the fact that a call can’t move faster than, nor in the opposite direction of, its underlying.  

---  

## 9.4 – Who decides the value of the Delta?  

Delta (and the other Greeks) aren’t conjured by a wizard; they’re outputs of the **Black‑Scholes** pricing model.  Feed the model a basket of inputs – spot price, strike, time‑to‑expiry, risk‑free rate, volatility, and dividend yield – and it spits out the fair price *and* the Greeks, including Delta.  

In practice, market data providers (your broker, Bloomberg, etc.) compute Delta on the fly using Black‑Scholes (or a more sophisticated variant).  You can always pull the exact number from a **B&S calculator** if you want to double‑check.  

Below is a handy reference table that gives you a *ballpark* Delta for typical Nifty strikes.  (Think of it as the “Delta menu” at the options restaurant.)  

| Moneyness | Approx. Delta (Call) | Approx. Delta (Put) |
|-----------|----------------------|---------------------|
| Deep ITM  | 0.95 – 1.00          | –0.05 – –0.10       |
| Slightly ITM | 0.70 – 0.90      | –0.10 – –0.30       |
| ATM (at‑the‑money) | ~0.50    | ~–0.50              |
| Slightly OTM | 0.10 – 0.30       | –0.70 – –0.90       |
| Deep OTM  | 0.01 – 0.05          | –0.95 – –0.99       |

Use this as a quick sanity check; the exact figure will vary with volatility and time‑to‑expiry.  

---  

## 9.5 – Delta for a Put Option  

A put’s Delta lives between **–1 and 0**.  The minus sign is the market’s way of saying “I move opposite to you.”  When the underlying climbs, the put’s premium falls – and vice‑versa.  

Let’s walk through an example.  Suppose Nifty is at **8268** (a slightly ITM put) and the put’s Delta is **–0.55**.  The current premium is **₹128**.  

### Case 1 – Underlying shoots up to 8310  

| Calculation | Value |
|-------------|-------|
| Expected change | 8310 – 8268 = **42** |
| Delta | **–0.55** |
| Premium impact | –0.55 × 42 = **–23.1** |
| New premium | 128 – 23.1 = **104.9** |

We **subtract** because a rising market hurts a put.  

### Case 2 – Underlying slides down to 8230  

| Calculation | Value |
|-------------|-------|
| Expected change | 8268 – 8230 = **38** |
| Delta | **–0.55** |
| Premium impact | –0.55 × 38 = **–20.9** |
| New premium | 128 + 20.9 = **148.9** |

Now we **add** because a falling market fattens a put’s price.  

These two scenarios illustrate how a negative Delta simply flips the sign of the premium change.  The same logic that kept a call’s Delta between 0 and 1 also keeps a put’s Delta between –1 and 0 – an option can never lose more value than the underlying itself, nor can it become “negative‑priced.”  

---  

### Key takeaways from this chapter  

- **Option Greeks** are invisible forces that tug at an option’s premium.  
- **Delta** is the Greek that tells you how much the premium moves when the underlying moves.  
- Call‑option Delta lives in **[0, 1]** (or **0 – 100 %**).  
- Put‑option Delta lives in **[–1, 0]** (or **–100 % – 0 %**).  
- A **negative Delta** means the option’s price moves opposite to the underlying.  
- **ATM** (at‑the‑money) options hover around **0.5** (or **50 %**) Delta.  
- **ITM** (in‑the‑money) calls approach **1** (or **100 %**), while ITM puts approach **–1**.  
- **OTM** (out‑of‑the‑money) calls drift toward **0**, and OTM puts drift toward **0** (from the negative side).  

Next up we’ll dig deeper into Delta’s quirks—how it bends around spot, how Gamma (the “Delta accelerometer”) works, and how you can build whole portfolios measured in Delta.  Stay tuned, keep the popcorn handy, and let the Greeks guide your trades!  