# 22. Re‑introducing Call & Put Options  

**Source:** https://zerodha.com/varsity/chapter/re-introducing-call-put-options/  

---  

##  

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/10/M5-Ch22-cartoon.png)  

## 22.1 – Why now?  

Alright, you’re probably thinking, “Hold on a sec – we’ve already trekked through the mystical land of calls and puts for *twenty‑one* chapters. Why are we doing a déjà‑vu tour?”  

Good question. Think of options learning like getting a PhD. The first half of the doctorate teaches you the theory – “what’s a call? what’s a put?”. The second half is where you start *doing* research and you realise there’s a whole other language (the Greeks) that you need to speak fluently.  

Now that you’ve been schooled in Delta, Gamma, Theta, Vega, and the rest of the Greek gang, it’s high time we revisit the fundamentals *through the lens* of those Greeks. In other words, we’ll look at calls and puts again, but this time we’ll ask: “What would the Greeks say if they were on a cocktail date with our trade idea?”  

Quick refresher (in case you spaced out during the earlier chapters):  

| Action | Market View | Plain‑English Meaning |
|--------|-------------|-----------------------|
| **Buy a Call** | You think the underlying will **go up** – you’re bullish as a rooster on sunrise. | “I want the upside, but I don’t want to own the stock.” |
| **Sell a Call** | You think the underlying will **stay flat or fall** – you’re basically saying “no thanks, I’m good”. | “I’ll collect premium, hoping it never gets exercised.” |
| **Buy a Put** | You think the underlying will **go down** – bearish as a grumpy cat. | “I want downside protection without shorting the stock.” |
| **Sell a Put** | You think the underlying will **stay flat or rise** – you’re happy to *maybe* be assigned the stock. | “I’ll take the premium, hoping the market doesn’t tank.” |

Those were the building blocks. The **new agenda** is to ask: *How do volatility and time change the story?* Grab a coffee, we’re about to add some spice.  

---  

## 22.2 – Effect of Volatility  

You already know that buying a Call is the “I think the market will rise” move. Let’s throw a few “what‑ifs” into the pot:  

1. **Volatility is expected to **dip** while Nifty is headed upward?**  
2. **Only 2 days left before expiry?**  
3. **More than 15 days left?**  
4. **Which strike should you pick – OTM, ATM, or ITM – and why?**  

If you’re sweating already, welcome to the real world of options. It isn’t a “just pick a direction and go” game; it’s a *tri‑dimensional* puzzle of **direction**, **volatility**, and **time**.  

I’m not going to tell you how to forecast the market – that’s your job. Use whatever you like: technical analysis, quantitative models, tarot cards (just kidding). Suppose, for the sake of argument, that your technical analysis says *Nifty will jump 2‑3 % in the next couple of days*.  

Now the real question is: **Which strike gives you the biggest bang for your buck?**  

Let’s revive a chart we already met in the **Vega** chapter (yes, the one that looks like a rainbow after a rainy day).  

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/10/Image-1_CE.png)  

**What you’re seeing:**  

* The **blue line** = 30‑day‑to‑expiry call.  
* The **green line** = 15‑day‑to‑expiry call.  
* The **red line** = 5‑day‑to‑expiry call.  

All three lines climb as **volatility rises** and slump when volatility falls. That’s the universal law of option premiums: **more volatility = pricier option**, regardless of how much time you have left.  

### Bottom‑line takeaways for **calls**  

| Situation | What to do with volatility |
|-----------|----------------------------|
| **Long call (buy)** | Buy *when you *expect* volatility to **rise**. Avoid buying right before a volatility collapse (think of it as buying a ticket to a concert that’s being canceled). |
| **Short call (sell)** | Sell *when you *expect* volatility to **fall**. Think of it as being the bartender who collects tips when the party is winding down. |

Now, let’s not forget our **puts** – they behave like their call cousins at the family reunion.  

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/10/Image-2_PE.png)  

The same conclusions apply: **Buy when you expect vol to climb, sell when you expect it to drop**.  

So the *volatility rule* is simple:  

* **Buy options → Expect volatility ↑**  
* **Sell options → Expect volatility ↓**  

But we still have a crucial piece missing: **Which strike should you choose?** That’s where **time to expiry** enters the stage.  

---  

## 22.3 – Effect of Time  

Assume volatility is on an upward trajectory **and** the underlying price is also climbing. Great! The next step is to decide **which strike** to grab. The answer depends heavily on **how much calendar time you have left**.  

> **Pro tip:** Don’t panic if the chart below looks like a cryptic alien script at first. It’s just a fancy way of saying “time matters”. Read it twice, sip some water, and you’ll get it.  

### The calendar of an F&O series  

* A typical futures‑and‑options series has **≈30 days** before expiry (except the February series, which likes to be quirky).  
* **First half** = days 1‑15 (the “young, spry” phase).  
* **Second half** = days 16‑30 (the “old‑timer, theta‑hungry” phase).  

Keep that mental picture while we walk through the charts.  

The first set of four bar charts evaluates **call‑option profitability** under different strike selections, assuming:  

* Spot price = **5,000** (so the 5,000 strike is **ATM**).  
* Trade is entered **somewhere in the first half** of the series.  
* The underlying is expected to **gain 4 %** (i.e. go to **5,200**).  

We then ask: **If the 4 % move happens in …**  

1. **5 days**  
2. **15 days**  
3. **25 days**  
4. **On expiry**  

…which strike will have the biggest smile?  

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/10/Image-3_CE_Theta.png)  

### Chart #1 – First half, target hit in **5 days**  

Imagine today is **7 Oct**, Infosys results drop on **12 Oct**, and you’re **bullish**. You want to lock in a profit *five days later*. Which strike?  

**Result:** When you have *plenty of time* *and* the move is *quick*, **far‑OTM** calls (think 5,400‑5,500 strikes) give you the *most* profit. The reason? The underlying can zip past the strike, turning a cheap ticket into a gold‑mine.  

**Takeaway:** *In the first half, if you expect a swift move, buy OTM calls about **2‑3 strikes** away from ATM. Don’t go too deep OTM; you’ll pay for a lottery ticket you can’t afford.*  

### Chart #2 – First half, target hit in **15 days**  

Same setup, but the price takes **15 days** to reach 5,200.  

**Result:** The far‑OTM options start to **lose steam**. Their profitability curve flattens, and you may even see a loss on the 5,500 strike.  

**Takeaway:** *If the move is more leisurely, stick to **ATM or slightly OTM** strikes (1 strike away). Far‑OTM is now a losing gamble.*  

### Chart #3 – First half, target hit in **25 days**  

Now the 4 % climb is stretched to **25 days**.  

**Result:** **ITM** calls (e.g., 4,800‑4,900 strikes) become the champions. OTM calls are mostly in the red because the time decay (Theta) has been gnawing away at their value for too long.  

**Takeaway:** *When you’re early in the series but the price move is slow, go **ITM**. Low‑premium OTM looks tempting, but it’s a *shallow‑water* trap – you’ll likely lose the entire premium.*  

### Chart #4 – First half, target hit **on expiry**  

If you’re banking on the move happening **right on the expiration day**, the story is stark: **Only ITM** calls survive. ATM and OTM options bleed out due to the final Theta slough.  

**Takeaway:** *Near‑expiry, only **deep‑in‑the‑money** calls have a fighting chance.*  

---  

## 22.4 – The Second‑Half (15‑30 days) – Time Decay Gets Hungry  

Now flip the calendar: you’re **in the second half** of the series (days 16‑30). Theta has become a **hungry monster**, eating away extrinsic value faster than a teenager on a diet. Let’s see how the strike‑selection wisdom changes.  

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/10/Image-4_CE_Theta.png)  

### Chart 1 – Second half, target hit **same day**  

Think “RBI announces a surprise rate cut, and the Nifty rockets 4 % in a single session.”  

**Result:** All strikes make money, but **far‑OTM** options explode the most. The massive one‑day jump gives them a *price‑surge* that outweighs the heavy Theta bite.  

**Takeaway:** *Same‑day fireworks? Grab **far‑OTM** (2‑3 strikes away). No point buying ITM – you’ll pay more for less upside.*  

### Chart 2 – Second half, target hit in **5 days**  

Same market, but the 4 % move now takes **five days**.  

**Result:** The far‑OTM curve drops dramatically. Theta has had five whole days to gnaw at the premium, so the **slightly OTM** strikes (1 strike away) become the sweet spot.  

**Takeaway:** *When you have a few days left, stay **just a little OTM**. The extra time decay on far‑OTM kills the profit potential.*  

### Charts 3 & 4 – Second half, target hit in **10 days** or **on expiry**  

Both scenarios are similar because the remaining calendar time is short.  

**Result:** **Far‑OTM** options turn **deep‑red**. Only **ATM** or **slightly ITM** strikes survive, with ITM usually edging ahead as expiry approaches.  

**Takeaway:** *Close to expiry, **avoid far‑OTM** like you’d avoid a bad haircut. Stick to **ATM or a touch ITM**.*  

---  

## 22.5 – Put‑Option Mirror Image  

All of the above was a call‑centric love story, but puts are just calls in reverse (and sometimes more dramatic). The same four‑chart logic applies when you’re bearish.  

### First‑half put charts  

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/10/Image-5_PE_Theta.png)  

* Quick 5‑day drop → far‑OTM puts shine.  
* 15‑day drop → ATM / slight OTM best.  
* 25‑day or expiry‑day drop → ITM puts dominate.  

### Second‑half put charts  

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/10/Image-6_PE_Theta.png)  

* Same‑day crash → far‑OTM puts win.  
* 5‑day slump → slightly OTM is your friend.  
* 10‑day or expiry‑day slump → stick to ATM / slight ITM.  

So, **the rulebook for calls works perfectly for puts** – just flip the direction.  

---  

## 22.6 – Putting It All Together – Your Quick‑Reference Cheat Sheet  

| **When you’re buying a naked option** | **Look at** | **Best strike** | **Avoid** |
|----------------------------------------|-------------|----------------|-----------|
| **First half, target reached **< 5 days** | Plenty of time, fast move | **Far OTM** (2‑3 strikes) | Deep ITM |
| **First half, target reached **≈ 15 days** | Moderate time | **ATM / Slight OTM** (0‑1 strike) | Far OTM |
| **First half, target reached **≥ 25 days** or **on expiry** | Long drift / final day | **ITM** (1‑2 strikes ITM) | ATM / OTM |
| **Second half, target reached **same day** | Theta is a beast but you have a fire‑sale move | **Far OTM** (2‑3 strikes) | ITM / ATM |
| **Second half, target reached **≈ 5 days** | Theta starts devouring premium | **Slight OTM** (1 strike) | Far OTM |
| **Second half, target reached **≈ 10 days** or **on expiry** | Very little time left | **ATM / Slight ITM** | Far OTM |

*The same matrix works for **puts**; just flip “OTM” ↔ “ITM” and “bullish” ↔ “bearish”.*  

---  

## 22.7 – What’s Next?  

We’ve just walked through the **“when & which strike”** part of the option‑trading puzzle. In the next chapter I’ll pull out **real‑world trade tickets** I punched over the past few weeks, explain *why* I chose a particular strike, and walk you through the *post‑trade* thought process (including how I managed the Greeks as the trade aged).  

Spoiler alert: you’ll see a lot of “I bought a 2‑strike OTM call because I expected a 4 % move in 5 days, and the market actually moved 4.2 % in 4 days – bingo!”  

---  

### Key takeaways from this chapter  

* **Volatility** is the *mood* of the market – buy options when you anticipate a **volatility rise**, sell when you anticipate a **volatility fall**.  
* **Time to expiry** and **the window in which you expect the price move** dictate the *optimal strike*:  
  * **First half + fast move → far OTM**  
  * **First half + slow move → ITM**  
  * **Second half + same‑day move → far OTM**  
  * **Second half + multi‑day move → ATM / slight OTM / slight ITM**  
* The **same principles** apply to puts; just remember puts are calls that decided to wear a “bear” costume.  

Armed with these insights, you can now walk into the options market with a **battle‑plan** rather than a guess‑and‑hope approach. Cheers to smarter, more profitable option trades! 🎉  