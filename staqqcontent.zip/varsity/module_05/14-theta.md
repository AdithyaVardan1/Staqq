# 14. Theta  

**Source:** <https://zerodha.com/varsity/chapter/theta/>  

---  

## 14.1 – Time is money  

You’ve probably heard the old saying “Time is money”. In options trading it isn’t just a motivational poster – it’s the very DNA of the contract.  
Let’s park the Greeks for a minute and go back to a simple, everyday example.

Imagine you’ve signed up for a competitive exam. You’re bright, you could ace it, but you only skim the syllabus for a night before the test. What’s the probability you’ll pass? It’s basically **zero** unless you *spend* time actually studying. The more days you allocate to preparation, the higher the chance you’ll clear the exam.  

Now swap the exam for the market:

- **Spot Nifty = 8 500**  
- You buy a **Nifty 8 700 Call**  

The question is: *What’s the chance that Nifty will climb 200 points before the contract expires?*  

| Time to expiry | How realistic is a 200‑point move? | Likelihood the call ends **ITM** |
|----------------|------------------------------------|-----------------------------------|
| **30 days**    | Very plausible – Nifty moves ~200 points a month in normal conditions. | **Very high** |
| **15 days**    | Still plausible, but a bit tighter. | **High** (not “very high”, just “high”) |
| **5 days**     | 200 points in a work‑week? That’s a stretch. | **Low** |
| **1 day**      | A 200‑point jump in a single session? Practically impossible. | **Ultra‑low** |

**Take‑away:** The more calendar days you have, the greater the odds the option finishes in‑the‑money (ITM). Keep that in your back‑pocket, because the **option seller** lives in the exact opposite world.

When you **sell** (or “write”) an option you collect the premium up‑front. In exchange you take on **unlimited downside** (the underlying could sprint past the strike) while your upside is capped at the premium you received. The seller’s profit is locked **only if the option expires worthless**.

Now think like a seller who writes a contract **early in the month**:

1. He knows he’s risking unlimited loss.  
2. He also knows that *time* gives the option a chance to become ITM, which would eat up his premium.

If time always creates a chance of ITM, why would anyone ever sell? The answer is simple: the buyer *pays* for that time risk. In other words, the premium you pay today is the sum of two things:

\[
\text{Premium} = \text{Intrinsic Value} + \text{Time Value}
\]

### Quick refresher on Intrinsic Value  

Intrinsic value is the cash you’d walk away with if you exercised the option **right now**.  

Assume **Nifty = 8 423**. Compute intrinsic values for these four contracts:

| Contract | Formula | Calculation | Intrinsic Value |
|----------|---------|-------------|-----------------|
| 8350 CE | Spot – Strike | 8 423 – 8 350 | **+ 73** |
| 8450 CE | Spot – Strike | 8 423 – 8 450 = –27 → 0 | **0** |
| 8400 PE | Strike – Spot | 8 400 – 8 423 = –23 → 0 | **0** |
| 8450 PE | Strike – Spot | 8 450 – 8 423 | **+ 27** |

Intrinsic value can never be negative – if the maths give you a minus, treat it as **zero**.

---

### Decomposing a real‑world premium  

Below is a snapshot I took on **6 July 2015** (yes, that’s a Thursday – the market never sleeps).

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/07/Image-1-_IVTV.png)

| Parameter | Value |
|-----------|-------|
| Spot price | **8 531** |
| Strike | **8 600 CE** |
| Moneyness | OTM (out‑of‑the‑money) |
| Premium | **99.4** |
| Date | 6 July 2015 |
| Expiry | 30 July 2015 |

**Intrinsic value** = Spot – Strike = 8 531 – 8 600 = **‑69** → 0 (because it’s OTM).  
Therefore  

\[
99.4 = \text{Time Value} + 0 \quad\Longrightarrow\quad \text{Time Value}=99.4
\]

So the market is willing to cough up **₹99.4** for *pure time* – no intrinsic bite at all. That’s the “time is money” mantra in action.

#### One day later (7 July)

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/07/Image-1-_IVTV.png)

Spot nudged to **8 538** but the premium fell to **87.9**.

*Intrinsic* is still 0 (8 538 – 8 600 = –62).  

\[
87.9 = \text{Time Value} + 0 \quad\Longrightarrow\quad \text{Time Value}=87.9
\]

The premium dropped **₹11.5** overnight. Part of that is because volatility slipped; the rest is the inevitable decay of time. If volatility and spot had stayed flat, we’d expect only a few rupees (≈ ₹5) to be lost purely to time.  

---

### A deeper‑in‑the‑money example  

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/07/Image-3_IVTV.png)  
![Image](http://zerodha.com/varsity/wp-content/uploads/2015/07/Image-2_ITVT.png)

| Parameter | Value |
|-----------|-------|
| Spot | **8 514.5** |
| Strike | **8 450 CE** |
| Moneyness | ITM |
| Premium | **160** |
| Date | 7 July 2015 |
| Expiry | 30 July 2015 |

Intrinsic = 8 514.5 – 8 450 = **64.5**  

\[
160 = \text{Time Value} + 64.5 \quad\Longrightarrow\quad \text{Time Value}=95.5
\]

Out of the ₹160 you pay, **₹64.5** is “real” (the amount you’d get if you exercised right now) and **₹95.5** is the price of waiting. You can run the same arithmetic on any call or put to see how much of the premium is pure time.

---

## 14.2 – Movement of time  

Time is a one‑way street heading straight to expiry. As the expiration date approaches, the “days‑to‑expiry” count shrinks, and so does the amount traders are willing to pay for the time component.

Ask yourself:  

> With **≈ 18 trading days** left, buyers might pay **₹100** for time value. Would they still fork out **₹100** if only **5 days** remained?  

**Nope.** Less time = less price.

Here’s a real‑world chain from an Indian‑stock option that was about to expire:

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/07/Image-4_Idea-option-chain.png)

| Detail | Value |
|--------|-------|
| Date | 29 April |
| Expiry | 30 April (1 day left) |
| Strike | **190** |
| Spot | **179.6** |
| Premium | **₹0.30** |
| Intrinsic | 179.6 – 190 = **‑10.4 → 0** |
| Time value | **₹0.30** (the whole premium) |

When there’s **one day** to go, the market is only willing to pay a few paise for time. If you had **20 days** left, you’d likely see a time value of **₹5–₹8** for a similar contract.  

The takeaway is simple: **Every day that passes erodes the time component**. If today you’re paying **₹10** for time, tomorrow you’ll probably pay **₹9.5**, all else equal.  

That leads to a cornerstone principle:

> **All else being equal, an option is a depreciating asset.** Its premium decays day‑by‑day because time is marching inexorably toward expiry.

The natural question is: *How fast does that decay happen?* The answer lives in the Greek called **Theta**.

---

## 14.3 – Theta  

All options—calls **and** puts—lose value as the expiration clock ticks. **Theta** (sometimes called **time‑decay**) quantifies **how many price points an option loses per day**, assuming everything else (spot, volatility, interest rates) stays constant.

- Theta is expressed as a **negative** number for a long (buyer) position, because it’s a loss.  
- For a short (seller) position, Theta appears **positive** because the seller *gains* from the decay.

**Example:** An option trades at **₹2.75** with a Theta of **‑0.05**. All else unchanged, tomorrow it should be worth **₹2.70**.

| Position | Theta sign | What it means |
|----------|------------|----------------|
| Long (buyer) | **‑** | You lose that amount each day (time is your enemy). |
| Short (seller) | **+** | You *gain* that amount each day (time is your buddy). |

### Why sellers love Theta  

A seller’s profit comes from two sources:

1. **Premium collected upfront.**  
2. **Theta decay** – the option’s price falling while the seller sits on cash.

Suppose you sold an option for **₹54** and its Theta is **+0.75**. After **3 days** (assuming everything else flat):

\[
\text{Decay} = 0.75 \times 3 = 2.25 \\
\text{New price} = 54 - 2.25 = 51.75
\]

If you buy it back at **₹51.75**, you pocket **₹2.25** purely from time decay. That’s Theta working for you.

### The classic “time‑decay” curve  

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/07/Image-5_Time-Decay.png)

Key observations:

1. **Early in the series** (lots of days left) – the curve is flat. Moving from 120 → 100 days only shaved about **₹50** off the premium (₹350 → ₹300). Theta is modest.  
2. **Near expiry** – the curve steepens dramatically. From 20 days left to the final few days, premium can plunge from **₹150** down to **under ₹50**. Theta spikes.

**Strategic implication:**

| When you sell | Premium you collect | Theta decay speed |
|---------------|--------------------|-------------------|
| **Early** (e.g., 120‑day series) | **High** (big time value) | **Slow** – you’ll need to wait longer for decay to work. |
| **Close to expiry** (e.g., <10 days) | **Low** (tiny time value) | **Fast** – the option bleeds value quickly, giving you rapid profit if you close soon. |

Theta is one of the friendliest Greeks for option writers: it’s a *steady, predictable* erosion that you can actually *collect*. We’ll later see how Theta interacts with the other Greeks (Vega, Gamma, etc.), but for now, if you grasp the above, you’re golden.

---

### Key takeaways from this chapter  

- **Option sellers are compensated for the time risk** they take on.  
- **Premium = Intrinsic Value + Time Value**.  
- **All else equal, options lose money each day because of Theta.**  
- **Theta is positive for sellers, negative for buyers** (time moves forward, never backward).  
- **Sell early** → large premium, but decay is slow.  
- **Sell near expiry** → small premium, but decay is rapid – a fast‑track to profit for the writer.  

And that’s Theta, the “watch‑the‑clock” Greek that makes every day count. Next up we’ll meet **Vega**, the Greek that cares about volatility more than a weather‑app. 🌦️