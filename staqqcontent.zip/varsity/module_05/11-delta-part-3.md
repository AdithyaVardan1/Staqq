# 11.   Delta (Part 3)

**Source:** <https://zerodha.com/varsity/chapter/delta-part-3/>

---  

##  

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/06/M5-Ch11-title.png)

## 11.1 – Adding Up the Deltas  

You know what’s cooler than a single‑piece LEGO? A whole tower made of them.  
The same goes for **Delta** – you can stack them, add them, and watch the whole thing move.  

### The “Delta‑Sum” trick  

Let’s rewind to good‑old Futures for a sec.  
Every 1‑point tick in the underlying index drags the futures along **exactly** one point.  
Example: Nifty Spot jumps from **8 340 → 8 350** → the Nifty Futures, which were at **8 347**, hop to **8 357** (same 10‑point move).  

If we hand a delta number to that futures contract, it’s a clean **1** – one point in the index equals one point in the futures.  

Now picture buying a single **ATM (at‑the‑money) option** whose delta is **0.5**.  
That means for every 1‑point swing in Nifty, the option’s price only wiggles half a point.  
In plain English: owning one ATM option is like holding **half** a futures contract.  

Got two of those?  
0.5 + 0.5 = **1** → you’ve just recreated a full futures contract with two options.  
That’s the magic: **deltas of multiple option legs can be summed** to get the net delta of the whole position.  

Below are a handful of “case‑studies” (because who doesn’t love a good case study?) that show how this works in practice.

---

### Case 1 – Three different Call options, Nifty = 8 125  

| Position | Δ (Delta) | Qty | Position Δ |
|----------|-----------|-----|------------|
| Call A   | +0.6      | 1   | +0.6 |
| Call B   | +0.4      | 1   | +0.4 |
| Call C   | +0.25     | 1   | +0.25 |
| **Total**| —         | —   | **+1.25** |

**Observations**

* The “+” sign next to the 1 in the *Position Δ* column tells you it’s a **long** (you bought it).  
* Net delta = **+1.25** → the whole combo moves **in the same direction** as Nifty, and a *full* point move in the index will shift the position by **1.25 points**.  
* If Nifty rockets up by **50 points**, the position is expected to climb **50 × 1.25 = 62.5 points**.  

---

### Case 2 – A mix of Calls and Puts, Nifty = 8 125  

| Position | Δ | Qty | Position Δ |
|----------|---|-----|------------|
| Call A   | +0.5 | 1 | +0.5 |
| Put B (deep‑ITM) | –0.25 | 1 | –0.25 |
| **Total**| — | — | **+0.25** |

**Observations**

* Net delta **+0.25** → still moves *with* the market, but far less aggressively.  
* Adding that deep‑ITM put **tames** the delta, making the overall position less sensitive to direction.  
* Every 1‑point Nifty swing now nudges the position by **0.25 points**.  
* A 50‑point market swing translates into **50 × 0.25 = 12.5 points** for the portfolio.  
* **Key rule:** you can add deltas of calls **and** puts **as long as they reference the same underlying** (here, Nifty).  

---

### Case 3 – Two lots of deep‑ITM Put, Nifty = 8 125  

| Position | Δ | Qty | Position Δ |
|----------|---|-----|------------|
| Call A   | +0.5 | 1 | +0.5 |
| Put B (deep‑ITM) | –0.625 | 2 | –1.25 |
| **Total**| — | — | **‑0.75** |

**Observations**

* Net delta is **‑0.75** → the option book moves **opposite** to the index (short‑delta).  
* Adding two deep‑ITM puts flipped the sign from positive to negative, making the whole thing *directionally sensitive* but in reverse.  
* For each 1‑point rise in Nifty, the position **drops 0.75 points**.  
* A 50‑point jump in the index therefore drags the portfolio **‑37.5 points** (50 × ‑0.75).  

---

### Case 4 – ATM Call vs. ATM Put on the same strike, Nifty = 8 125  

| Position | Δ | Qty | Position Δ |
|----------|---|-----|------------|
| 8 100 CE (ATM) | +0.5 | 1 | +0.5 |
| 8 100 PE (ATM) | –0.5 | 1 | –0.5 |
| **Total**| — | — | **0** |

**Observations**

* Call’s delta **+0.5**, put’s delta **‑0.5** → they cancel perfectly.  
* Net delta **0** → the combined book is **Delta‑Neutral**.  
* No matter how wildly Nifty wiggles, the position’s value stays put (ignoring other Greeks).  
  * Example: Nifty jumps 100 points → change = 100 × 0 = **0**.  
* Delta‑neutral positions are insulated from **directional** risk but remain exposed to **volatility** and **time decay** (we’ll talk about those later).  

---

### Case 5 – Short (sold) Call, Nifty = 8 125  

| Position | Δ | Qty | Position Δ |
|----------|---|-----|------------|
| Short 8 200 CE | –0.5 | 1 | –0.5 |

**Observations**

* The minus sign in the *Qty* column tells you it’s a **short** (you sold it).  
* A short call gives a **negative delta** because the option’s value climbs when the market **falls**, which is the opposite of the underlying.  
* Intuitively, if the spot rallies, you lose money on the short call → delta is negative.  
* Flip the script: a short **PUT** carries a **positive** delta because the put loses value when the market falls (good for the seller).  
  * Mathematically: –1 × (‑0.5) = **+0.5**.  

---

### Bonus Example – Five lots of deep‑ITM options  

* **Long** 5 deep‑ITM Calls: each has Δ ≈ +1 → total Δ = **+5**.  
  * Every 1‑point move in Nifty pushes the position by **5 points** in the same direction.  

* **Short** 5 deep‑ITM Puts: each has Δ ≈ ‑1, and you’re short (‑) → (‑5) × (‑1) = **+5** again.  

So, whether you’re holding five deep‑ITM calls **long** or five deep‑ITM puts **short**, the net delta ends up **+5**.  

---

#### Bottom line of the case‑studies  

1. **Add up the individual deltas** to see the overall directional exposure.  
2. This “delta‑summing” trick is priceless when you juggle many option legs at once.  
3. Treat the sum as a quick‑look gauge of **sensitivity** (how many points you move per index point) and **leverage** (how much exposure you have relative to capital).  

> **Pro tip:** Always calculate the net delta of a multi‑leg portfolio before you go for that extra cup of chai. It tells you whether you’re effectively **long**, **short**, or **neutral** on the market.  

---

#### A quick refresher on the “ATM‑option rule”  

| # of ATM options | Net Δ |
|------------------|-------|
| 1                | 0.5 |
| 2                | 1   |
| 3                | 1.5 |
| …                | …   |

Two ATM options behave **exactly** like one futures contract in terms of directional movement (Δ = 1).  
**But** don’t mistake them for a *real* futures contract – options still care about **volatility**, **time decay**, and **interest rates**, whereas futures care only about price direction.  

Sometimes you’ll swap a futures position for two ATM options to **save margin**, but always be aware of the extra Greeks that sneak in. We’ll meet them later.  

---

## 11.2 – Delta as a probability  

Delta isn’t just a sensitivity number; it’s also a **rough probability** that the option will finish **in‑the‑money (ITM)** at expiry.  

### How to think about it  

When you buy an option you’re basically shouting, “I *hope* the market moves in my favour!”  
Take a **Nifty 8 000 PE** while the spot sits at **8 100** (a classic OTM put). Your wish‑list:

* Spot drops **below** 8 000 → the put becomes ITM → premium rises → you profit.  

If that put’s delta is **0.30**, we can interpret it as a **30 % chance** of ending ITM.  
Just multiply by 100 and you’ve got a probability estimate.  

> **Note:** Delta‑derived probabilities are *approximate* and work best for **ATM‑ish** options with not‑too‑much time left.  

### Real‑world illustration  

| Option | Spot | Premium | Days‑to‑Exp | Approx. Δ |
|--------|------|---------|------------|----------|
| 8 400 CE | 8 275 | ₹4 | 2 | ~0.10 |

*Why would anyone buy this cheap call?*  
* **Cost** is low (₹4) – sounds like a lottery ticket.  
* **Delta** is only **0.10** → roughly a **10 %** chance of finishing ITM.  
* Only **2 days** left → the odds of a 125‑point rally in two sessions are slimmer than a cat landing on its feet.  

A prudent trader would **sell** this call, collect the ₹4, and enjoy a **90 %** chance of keeping the money.  

### The flip side: ITM options  

Deep‑ITM options have Δ ≈ 1 (or –1 for puts).  
That translates to **~100 %** probability of finishing ITM – which means **very little chance** of expiring worthless.  
Shorting such an option is risky: you’re basically betting that the market will *miraculously* reverse direction.  

> **Bottom line:** Use delta as a quick‑and‑dirty gauge of “how likely am I to be right?” before you place a bet.  

---

## 🎉 Wrap‑up  

You’ve now met the **first Greek** in the wild: **Delta**.  
* It **adds up** across legs.  
* Futures always sit at Δ = 1.  
* Two ATM options ≈ one futures contract (directionally).  
* It doubles as a **probability** of ending ITM.  

Next stop on the Greek tour? **Gamma** – the mischievous sibling that tells you how fast your delta changes.  

### Key take‑aways (in bullet‑point form for the lazy reader)  

- **Additivity:** You can sum the deltas of any combination of calls and puts on the same underlying.  
- **Futures Delta:** Always **1** (one‑for‑one with the index).  
- **ATM Pair = Futures:** Two at‑the‑money options give you a net delta of **1**.  
- **Not a perfect substitute:** Options still care about volatility, time, and interest rates – futures do not.  
- **Probability view:** Delta ≈ probability (in %) of finishing ITM.  

Now go forth, compute those deltas, and may your portfolios stay as balanced as a bartender’s cocktail shaker! 🍸🚀