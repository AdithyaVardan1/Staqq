# 10. Delta (Part 2)

**Source:** <https://zerodha.com/varsity/chapter/delta-part-2/>

---  

## 10.1 – Model Thinking  

In the last chapter we gave you a teaser of the very first Greek – **Delta**.  But there was a sneaky second goal hidden in the prose: to get you onto the **“model‑thinking”** highway.  What does that even mean? Think of it as swapping your old, rickety bicycle for a sleek sports car that runs on equations instead of guess‑work.  

The previous chapter cracked open a brand‑new window on how to look at options.  Before, you might have stared at the market like a kid looking at a candy shop and thought, *“I’m bullish, so I’ll either buy a call or sell a put.”*  That’s the **one‑dimensional** view – cute, but about as useful as a fortune cookie.

Now picture yourself as a **quant‑ish** strategist:  

> “I’m bullish **and** I think the market will swing **about 40 points**.  So I’ll hunt for an option whose **delta is ≥ 0.5** – that way, if the market moves those 40 points, the option’s premium should move at least 20 points.”

See the upgrade? The first line is a vague feeling; the second line is a **quantified** plan backed by a simple formula we learned earlier:

\[
\text{Expected change in option premium} \;=\; \Delta \times \Delta\text{(underlying points)}
\]

That equation was just the tip of the iceberg.  As we uncover **Gamma, Vega, Theta** and the rest of the Greek crew, the whole evaluation becomes a **scientific, numbers‑driven** affair.  “Casual trading thoughts” will shrink to a footnote.  

Sure, there are traders who throw darts blindfolded and sometimes hit the bullseye.  That’s like winning the lottery – fun for a story, but not a reliable strategy.  When you **put numbers in the driver’s seat**, the odds of a smooth ride go up dramatically.  That, my friend, is what we call **model thinking**.

So, keep this **model‑thinking framework** glued to your brain while you dissect options.  It will help you build **systematic, repeatable trades** instead of relying on “gut feelings” that change with your mood (or the number of coffee cups you’ve had).  

---  

## 10.2 – Delta versus the Spot Price  

Before we dive deeper, a lightning‑quick recap of the Delta basics we covered earlier:

| Option type | Delta sign | What a delta of 0.4 (call) means |
|-------------|------------|-----------------------------------|
| **Call**    | **+**      | For every 1‑point rise in the underlying, the call’s premium rises **0.4 points** |
| **Put**     | **–**      | For every 1‑point fall in the underlying, the put’s premium rises **0.4 points** |
| **Moneyness**| – | OTM = 0 → 0.5, ATM ≈ 0.5, ITM = 0.5 → 1 (calls) / –1 → –0.5 (puts) |

Armed with that, let’s do a little **thought experiment**.  Imagine:

* **Nifty Spot:** 8 312  
* **Strike under review:** 8 400  
* **Option type:** CE (European Call)

### 1️⃣ Spot = 8 312 → 8 400 (still OTM)  
- Since the strike is above the spot, the option is **out‑of‑the‑money**.  
- Its delta lives somewhere between **0 and 0.5** – let’s pretend it’s **0.4**.

### 2️⃣ Spot = 8 400 (now ATM)  
- At‑the‑money options typically sit at **Δ ≈ 0.5**.  

### 3️⃣ Spot = 8 500 (now ITM)  
- The call is **in‑the‑money**, so delta climbs toward **1**.  A reasonable guess: **0.8**.

### 4️⃣ Spot crashes back to 8 300 (now OTM again)  
- The delta slides back down because the option loses its moneyness.  Let’s say it falls to **0.35**.

**What do we learn?**  
As the underlying price wobbles, **moneyness shifts**, and **delta follows**.  Delta isn’t a static number you can pin on a wall; it’s a **living, breathing variable** that moves with the spot.  

### Visualising the Dance  

Below is a generic **Delta‑vs‑Spot** chart (not tied to any specific contract).  Two lines strut across the graph:

* **Blue line** – Call delta, ranging from **0** (deep OTM) to **1** (deep ITM).  
* **Red line** – Put delta, ranging from **–1** (deep ITM) up to **0** (deep OTM).

![Delta vs Spot – Call (blue) & Put (red)](http://zerodha.com/varsity/wp-content/uploads/2015/06/Image-1_Delta-vs-Spot1.png)

#### How to read the blue (call) line  

1. **X‑axis = Spot price** – moving left‑to‑right means the underlying climbs from deep OTM → ATM → ITM.  
2. **Delta climbs with the spot** – the higher the spot, the higher the delta.  
3. **Flat near 0 on the far left** – even if the spot plummets deeper OTM, delta stays stuck at **0** (calls can’t go negative).  
4. **From OTM to ATM** – delta starts to rise, staying in the **0–0.5** corridor.  
5. **At ATM** – you hit the sweet spot **Δ = 0.5**.  
6. **Beyond ATM** – delta pushes past 0.5, heading toward **1**.  
7. **Deep ITM plateau** – once you’re well inside the money, delta **locks at 1** (it can’t exceed that).  

The red line mirrors this logic for puts, just flipped and negative.  

Bottom line: **Spot moves → moneyness moves → delta moves**.  That’s the core takeaway.  

---  

## 10.3 – The Delta Acceleration  

If you’ve ever been in an options chatroom, you’ve probably heard tales of traders turning a modest stake into a **golden goose** by buying far‑out‑of‑the‑money (OTM) contracts.  Let me spin you a real‑life yarn.

### The 17 May 2009 “Election‑Day Rocket”

* **Date:** Sunday, 17 May 2009 – India’s general elections.  
* **Result:** UPA wins, Manmohan Singh back for round‑two.  
* **Market expectation:** A stable government → a bullish rally the next day.  

Our little boutique (yes, we weren’t Zerodha yet) had a daring associate who, a few days earlier, **wasted ₹2 00 000** buying deep OTM calls on Nifty.  Why? Because he *knew* (well, hoped) a big move was brewing.

Fast forward to **18 May 2009** – the market opened, hit the **upper circuit**, and surged **~20 %** to close at **4 321**.  The exchange even shut the doors at **10:01 AM** because the market was hotter than a summer barbecue.

> **Result:** Our associate’s OTM calls ballooned from a few hundred rupees to **₹28 00 000** – a **1 300 %** overnight gain.  

That’s the stuff of legends.  It also raises two obvious questions:

1. **Why go OTM instead of ATM or ITM?**  
2. **What would have happened if he’d taken an ATM/ITM instead?**  

The answer lies in the **Delta Acceleration** graph.

![Delta Acceleration](http://zerodha.com/varsity/wp-content/uploads/2015/06/Image-2_Delta-accelaration-1024x614.png)

The graph divides the life‑cycle of an option’s delta into **four stages**.  Let’s walk through each, peppered with some friendly advice.

### 📚 Pre‑development (Deep OTM)  

* **Delta ≈ 0** – the option is practically invisible to spot moves.  
* Example: Spot = 8 400, **8 700 Call** is deep OTM with Δ ≈ 0.05.  

If the spot jumps to **8 500** (a 100‑point swing), the premium change is:

\[
\Delta\text{Premium}=100 \times 0.05 = 5 \text{ points}
\]

So a **₹12** option becomes **₹17** – a **41.6 %** jump in percentage terms, even though the absolute move is tiny.  

**Takeaway:** Deep OTM options can deliver eye‑popping **percentage returns**, but only if the underlying makes a **huge move**.  In reality, that’s a risky bet.  

**Recommendation:** **Avoid buying deep OTM** (tiny delta, massive underlying move needed).  However, **selling** deep OTM can be lucrative because the premium is cheap and the probability of a big move is low – we’ll revisit that when we meet **Theta**.

### 🚀 Take‑off & Acceleration (OTM → ATM)  

Here the magic happens.  The option is still OTM but **close enough** that delta is rising quickly (≈ 0.2‑0.3).  

**Scenario:** Spot = 8 400, strike = 8 500 Call, Δ ≈ 0.25, premium = ₹20.  

Spot jumps 100 points to **8 500**:  

\[
\Delta\text{Premium}=100 \times 0.25 = 25 \quad\Rightarrow\quad \text{New premium}=₹45
\]

**Percentage gain:** \((45‑20)/20 = 125 %\) – a **huge** reward for a modest move.  

**Why does it work?** Because the option sits in the **steep part of the delta curve** – a small nudge in the underlying produces a **big swing** in premium.

**Recommendation:** If you have **ample time to expiry** and you’re confident about a sizable move, **buy slightly OTM** (Δ ≈ 0.2‑0.3).  It’s pricier than deep OTM, but the payoff potential is much larger.

### ⚖️ ATM (Δ ≈ 0.5)  

Now the option is right on the money.  

* Spot = 8 400, strike = 8 400, premium = ₹60.  
* Same 100‑point rally → Δ = 0.5 → premium rises by **₹50** → new premium **₹110**.  

**Percentage gain:** \((110‑60)/60 ≈ 83 %\).  

**Takeaway:** ATM options are **more sensitive** than deep OTM, but **less volatile** than the steep OTM zone.  They’re a **balanced** choice – you pay more upfront, but you don’t need a *monster* move to see a decent profit.

**Recommendation:** Use ATM when you want a **safer** bet (still moves nicely with the underlying) and **avoid selling** them unless you’re a seasoned pro who can tolerate the risk.

### 🛡️ Stabilization (ATM → ITM → Deep ITM)  

Once an option goes deep ITM, its delta **flattens at 1**.  The option now behaves almost **exactly like the underlying**.

| Option | Strike | Δ | Premium | Underlying move (100 pts) | Premium change | New premium | % change |
|--------|--------|---|---------|---------------------------|----------------|------------|----------|
| A | 8 300 CE | 0.8 | ₹105 | 8 400 → 8 500 | 100 × 0.8 = 80 | ₹185 | 76.2 % |
| B | 8 200 CE (deep ITM) | 1.0 | ₹210 | 8 400 → 8 500 | 100 × 1 = 100 | ₹310 | 47.6 % |

**Insights:**  

* **Absolute points**: Deep ITM (Δ = 1) gives the **largest raw point gain**.  
* **Percentage terms**: The **less‑deep ITM** (Δ = 0.8) actually yields a higher % return because it started from a lower base.  

Most importantly, a **deep‑ITM call** with Δ = 1 moves **one‑for‑one** with the underlying.  In practice, that means:

* **Long a deep‑ITM call** ≈ **long the underlying** (or a futures contract) but with **lower margin requirements**.  
* Keep an eye on **liquidity** and ensure the contract stays deep‑ITM, otherwise delta may drift away from 1.

**Recommendation:** If you crave **near‑futures exposure** with less cash tied up, grab a **deep‑ITM call**.  It’s the *cheapest* way to mimic a futures position, provided you monitor the delta and the order book.

---

### TL;DR (or “Key Takeaways” for the impatient)

| ✅ | Takeaway |
|---|----------|
| **Model thinking** gives you a **scientific, repeatable** trading edge. |
| **Delta isn’t static** – it morphs as the spot price moves. |
| As an option migrates **OTM → ATM → ITM**, its delta **climbs** (0 → 0.5 → 1 for calls). |
| **ATM** options sit at **Δ ≈ 0.5**. |
| **Pre‑development** (deep OTM) = tiny delta → huge % moves only with massive underlying swings. |
| **Take‑off & acceleration** (OTM → ATM) = the *sweet spot* for **high % returns**. |
| **Stabilization** (ITM → deep ITM) = delta **locks at 1**, making the option behave like the underlying. |
| Buying in the **take‑off stage** can explode your % returns – but watch the risk. |
| **Deep‑ITM** calls are practically **synthetic futures** – great for margin‑efficiency. |

---

### Final Thought Experiment  

Recall the election‑day story and the two questions we posed.  With the **Delta Acceleration** map in hand, you can now answer them:

1. **Why OTM?** – The trader wanted the *steep part* of the delta curve, where a modest spot jump translates into a **massive premium surge** (125 %+ in our example).  
2. **What if he’d bought ATM/ITM instead?** – He’d still have profited (ATM would have given ~83 % on the same move), but the **percentage upside** would have been smaller, and the **premium outlay** would have been larger.  

That’s the power of **model thinking**: you can **size‑up** the risk‑reward profile *before* the market opens, rather than retro‑fitting a story after the fact.

Enjoy experimenting with deltas, keep those equations close, and may your next trade be as thrilling as a roller‑coaster **without** the nausea! 🚀📈  