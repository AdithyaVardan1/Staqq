# 16. Volatility Calculation (Historical)

**Source:** https://zerodha.com/varsity/chapter/volatility-calculation-historical/

---  

##  

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/07/M5-Ch16-Cartoon.png)

## 16.1 – Calculating Volatility on Excel  

In the last chapter we flirted with **standard deviation** and hinted that it’s the secret sauce behind a stock’s “risk” or “volatility”. Before we start sprinkling it over options pricing, let’s actually *cook* the numbers ourselves. Volatility isn’t a free‑range commodity you can just download from a magic portal (unless you’ve got a crystal ball). So it’s worth knowing how to crank it out with a spreadsheet—because Excel is basically the kitchen gadget that does the heavy lifting while you sip your coffee.

Remember Billy & Mike’s little example? We broke down the math into four bite‑size steps:

1. **Average** – Find the mean of the observations.  
2. **Deviation** – Subtract that average from each observation.  
3. **Variance** – Square each deviation, then add ‘em up.  
4. **Standard deviation** – Take the square‑root of the variance.  

That exercise was the *why* behind the formula. Knowing the guts of the calculation makes you the Sherlock Holmes of numbers—you’ll spot when something smells fishy.  

In this chapter we’ll let Excel do the heavy lifting. The program follows the exact same recipe, just with a “one‑click‑and‑boom” vibe. Here’s the quick‑fire roadmap; we’ll unpack each bullet after the list:

- **Grab** historical closing‑price data.  
- **Compute** daily returns (the raw material for volatility).  
- **Apply** the `STDEV` function to those returns.  

Ready? Let’s roll up our sleeves.

---

### Step 1 – Download the historical closing prices  

Pick any data source you trust. The most popular freebies are the **NSE India** website and **Yahoo Finance**.  

I’m a fan of the NSE portal; it’s like the Swiss‑army‑knife of Indian market data—clean, comprehensive, and surprisingly easy to navigate.  

For this demo we’ll measure the volatility of **Wipro Ltd.** (yes, the IT giant that makes both software and the occasional headache).  

1. Pop over to the NSE historical‑data page:  
   `http://www.nseindia.com/products/content/equities/equities/equities.htm`  
2. Click the **Historical Data** tab and then the **Search** button.  

Here’s a screenshot with the search button highlighted (green box for the win):

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/07/Image-1_Search.png)

3. Fill in the required fields—ticker, exchange, date range, etc. I chose a clean 1‑year window: **22 July 2014 → 21 July 2015**.  
4. Hit **Get Data**. NSE will fetch the CSV for you, and you’ll see a screen like this:

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/07/Image-2_Download-CSV.png)

5. Click the green‑boxed **Download file in CSV format**. Boom—your data is now chilling in your Downloads folder.

When you open the CSV in Excel you’ll be greeted by a wall of columns: date, open, high, low, close, volume, etc. I’m a minimalist, so I trim the clutter and keep only **Date** and **Close**. A tidy sheet looks like this:

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/07/Image-3_Excel.png)

*(If you’re still seeing extra columns, feel free to smash the Delete key. Clean data = happy analyst.)*

---

### Step 2 – Calculate Daily Returns  

The textbook definition of a simple daily return is  

\[
\text{Return} = \frac{\text{Ending Price}}{\text{Beginning Price}} - 1
\]

But finance nerds love log returns because they’re **time‑additive** and they handle huge price swings more gracefully. The shortcut is:

\[
\text{Log Return} = \ln\!\Big(\frac{\text{Ending Price}}{\text{Beginning Price}}\Big)
\]

where “ln” is the natural logarithm (base *e*). In Excel the function is `LN`.  

So, in a fresh column next to the closing prices, drop this formula (assuming Close prices are in **C2:C252** and the first return goes in **D3**):

```excel
=LN(C3/C2)
```

Drag it down to the bottom of the list and you’ll have a column of daily log returns. Here’s a visual of what that looks like for Wipro:

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/07/Image-4_LN-returns.png)

*(Pro tip: format the column as a percentage with two decimals; it makes the numbers look like real‑world returns instead of cryptic decimals.)*

---

### Step 3 – Use the STDEV Function  

Now that we have a tidy series of daily returns, we can ask Excel for their standard deviation—aka **daily volatility**. The function we need is `STDEV.P` for the *population* standard deviation (or `STDEV.S` if you treat your data as a sample; the difference is negligible for a full‑year dataset).  

Here’s the cheat‑sheet for the keystrokes:

1. Click an empty cell (say **E2**).  
2. Type `=` to start a formula.  
3. Type `STDEV.P(` (or `STDEV.S(`).  
4. Highlight the range of daily returns (e.g., **D3:D252**).  
5. Close the parenthesis `)` and press **Enter**.

Excel spits out a tiny decimal. In my Wipro example I got **0.0147**, which translates to **1.47 %** when you format it as a percentage.

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/07/Image-5_STDEV.png)

That 1.47 % is the **daily volatility** of Wipro.  

#### Turning Daily Volatility into Annual Volatility  

Markets are lazy: they assume **252 trading days** in a year (the number of weekdays minus holidays). To annualise a daily standard deviation you multiply by the square root of the time‑factor:

\[
\text{Annual Volatility} = \text{Daily Volatility} \times \sqrt{252}
\]

Plugging the numbers:

- Daily Volatility = **1.47 %**  
- \(\sqrt{252} \approx 15.874\)  

\[
1.47\% \times 15.874 \approx 23.33\%
\]

So Wipro’s annualised volatility is about **23 %**. Here’s the screenshot of the Excel calculation:

![Image](https://zerodha.com/varsity/wp-content/uploads/2015/07/Screenshot_22.png)

---

### Quick sanity‑check with NSE’s own numbers  

NSE publishes implied volatilities for the F&O (Futures & Options) universe. For Wipro they list:

- **Daily Volatility ≈ 1.34 %**  
- **Annualised Volatility ≈ 25.5 %**  

Our DIY figure (1.47 % daily, 23 % annual) is close enough to be reassuring. The small gap could be due to NSE using **futures** prices rather than spot closing prices, or perhaps a slightly different look‑back window. No need to go full‑detective—our goal was to learn the mechanics, not to audit the exchange.

---

### Bonus: Converting an **annual** volatility back to a **daily** one  

Suppose you’re handed the NSE‑published annual volatility of **25.5 %** and you want the daily equivalent. Just reverse the earlier step:

\[
\text{Daily Volatility} = \frac{\text{Annual Volatility}}{\sqrt{252}}
\]

\[
\frac{25.5\%}{15.874} \approx 1.60\%
\]

So the daily volatility implied by NSE’s 25.5 % annual figure is about **1.60 %**. Easy peasy, right?

---

## Wrapping up  

We’ve walked through:

1. **Fetching** raw close prices.  
2. **Deriving** daily log returns.  
3. **Applying** Excel’s `STDEV` to get daily volatility.  
4. **Annualising** (and de‑annualising) the result with the square‑root‑of‑time rule.

Next stop? We’ll see how that volatility number powers **option Greeks**—specifically **Vega**—and why traders love it (and occasionally hate it). Keep your eyes on the prize; we’re heading toward the heart of options pricing.

> **Download the accompanying Excel workbook** – [click here](#)  

---

### Key takeaways from this chapter  

- **Standard deviation = volatility = risk** (they’re all the same beast, just wearing different hats).  
- **NSE** is a reliable source for daily closing prices (free, fast, and surprisingly tidy).  
- **Log returns** (`LN`) are the preferred way to compute daily returns.  
- Excel’s **LN** function handles the logarithm, while **STDEV.P** (or **STDEV.S**) gives you the volatility.  
- **Daily volatility** is simply the standard deviation of daily log returns.  
- **Annual volatility** = daily volatility × √252 (≈ 15.874).  
- **Conversely**, daily volatility = annual volatility ÷ √252.  
- Converting back and forth is just a matter of the square‑root‑of‑time trick.  

That’s it—now you can brag to your friends that you *actually* know how to measure a stock’s mood swings, not just quote the numbers you saw on a chart. 🎉