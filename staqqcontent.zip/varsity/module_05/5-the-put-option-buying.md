# 5. The Put Option Buying  

**Source:** <https://zerodha.com/varsity/chapter/the-put-option-buying/>  

---  

## 5.1 – Getting the orientation right  

By now you’ve already wrestled with the call‑option circus—both the buyer who shouts “Buy me a ticket to the upside!” and the seller who mutters “I’ll collect the entry fee and hope the show flops.” If that’s still fresh in your brain, sliding into the world of **puts** is like swapping your sunny beach umbrella for a raincoat: the only thing that changes is the weather forecast you’re betting on.  

A put‑option buyer is the gloomy‑grandma of the market: she thinks the price of the underlying stock will **drop** before the contract’s expiry. To turn that pessimism into profit, she signs a put‑option contract. In plain English: the buyer purchases *the right* (but not the obligation) to **sell** a stock at a pre‑agreed price (the **strike price**) no matter how low the market price actually goes.  

> **Golden rule of options:** whatever the buyer thinks will happen, the seller thinks the opposite. If everyone thought the same thing, there would be no one to take the opposite side and the market would collapse faster than a house of cards in a hurricane.  

So, when the put‑buyer believes the market will tumble, the put‑seller is silently cheering for a rally or at least a flat‑line.  

### The mechanics in a nutshell  

| Role | What they do | What they get |
|------|--------------|----------------|
| **Put‑buyer** | Pays a **premium** up‑front to get the *right* to sell the underlying at the strike price on expiry. | The *right* to dump the stock at a hopefully higher price than the market. |
| **Put‑seller (writer)** | Receives that premium and, in return, takes on the **obligation** to buy the stock at the strike price **if** the buyer decides to exercise. | The premium (cash in the pocket) and the potential obligation to buy a falling stock. |

If the market price at expiry is **below** the strike, the buyer will cry “Take it!” and sell the stock to the writer at the higher strike price, pocketing the difference (minus the premium). If the market price is **above** the strike, the buyer simply says “Nah, I’m good,” and lets the contract expire—losing only the premium he paid.  

#### A tiny story to cement the idea  

- **Underlying:** Reliance Industries, currently trading at **₹850**.  
- **Put contract:** Buyer pays a premium to get the right to sell Reliance at **₹850** on expiry.  
- **If at expiry** Reliance is **₹820**, the buyer can force the seller to buy it at **₹850** → **₹30** profit per share (minus the premium).  
- **If at expiry** Reliance is **₹870**, the buyer just walks away and loses the premium—no reason to sell at a lower price than the market.  

That, dear reader, is a **put option** in action.  

![Put‑Option Illustration](http://zerodha.com/varsity/wp-content/uploads/2015/04/M5-Ch5-title.png)  

If the above still feels like trying to understand a Shakespearean tragedy, don’t panic. We’ll keep sprinkling jokes and examples until everything clicks.  

**Three take‑aways to lock in now:**  

1. **Bearish buyer, neutral/bullish seller.** The buyer hopes the price falls; the seller hopes it stays flat or climbs.  
2. **Buyer gets the *right* to sell** the underlying at the strike price on expiry.  
3. **Seller is *obligated* to buy** if the buyer exercises (because he pocketed the premium).  

---

## 5.2 – Building a case for a Put Option buyer  

Just like we did with calls, let’s craft a realistic scenario for a put‑buyer. We’ll start from the buyer’s eye view, then flip the script for the seller later.  

### The chart that sparked the idea  

*(All dates are historical; treat them as a teaching tool, not a trading tip.)*  

![Bank Nifty chart – 8 Apr 2015](http://zerodha.com/varsity/wp-content/uploads/2015/04/Image-1_-Bank-Nifty.png)  

**My brain‑dump on Bank Nifty:**  

- **Current level:** **18,417** points.  
- **Two days ago:** It tried to breach **18,550**—the classic “resistance” line (the green horizontal line).  
- **Why 18,550?** Because there’s a price‑action cluster there that’s been visited a few times, forming a “no‑go” zone. (If you’re new to resistance, think of it as a ceiling that the market keeps hitting and then bouncing off.)  
- **Technical clue:** I boxed that price‑action zone in blue rectangles for emphasis.  
- **Fundamental backdrop:** On April 7 the RBI left repo and reverse‑repo rates unchanged. For a banking‑heavy index like Bank Nifty, the RBI’s decision is basically the market’s mood‑setter. No surprise, no drama—so the banks lost their “spice.”  
- **Resulting sentiment:** Traders might start dumping bank stocks and rotate into sectors with better catalysts.  
- **My bias:** Bearish on Bank Nifty.  

**Why not just short futures?**  
Shorting the futures directly would expose you to unlimited loss if the market rallies (and the overall market was still bullish). A put caps your downside to the premium you paid, while still letting you profit if the index falls.  

**The plan:** Buy the **18,400 put** (the nearest OTM strike) trading at a **premium of ₹315**.  

![Option chain for Bank Nifty (April 2015)](http://zerodha.com/varsity/wp-content/uploads/2015/04/Image-2_Option-Chain.png)  

### How to actually buy it  

1. Call your broker, whisper “Give me the 18,400 put on Bank Nifty, please.”  
2. Or, log into your trading platform (Zerodha Pi, Kite, etc.) and click‑click‑click.  

That’s it—now you own a contract that will make you happy **if** Bank Nifty drops before April 30 (the expiry).  

### What happens at expiry?  

We’ll walk through a few “what‑if” scenarios and, in the process, discover the **P&L** shape of a put buyer.  

---  

## 5.3 – Intrinsic Value (IV) of a Put Option  

You already know **intrinsic value** from the call chapter: it’s the amount of “real” money you’d get if you exercised right now.  

- **Call IV** = Spot – Strike  
- **Put IV** = **Strike – Spot**  

So, if the spot price is **₹16,000** and the strike is **₹18,400**, the put’s intrinsic value is **₹2,400** (because you could sell at 18,400 while the market only pays 16,000).  

**Important nuance:** The IV formulas apply **only on expiry** (or at any moment you actually decide to exercise). During the life of the contract the option’s price also includes **time value**, but we’ll ignore that for now and focus on the pure “exercise‑right” value.  

Here’s a little timeline to remind you:  

![Option timeline – IV only matters at expiry](http://zerodha.com/varsity/wp-content/uploads/2015/04/Image-3_timeline-new.png)  

---  

## 5.4 – P&L behaviour of the Put Option buyer  

Armed with the IV formula, let’s build a simple **P&L table** for our **Bank Nifty 18,400 put** that we bought for **₹315**. Remember: the premium is a sunk cost—it’s a cash outflow that stays constant no matter where the market ends up.  

| Spot on expiry | Intrinsic Value (Strike – Spot) | P&L = IV – Premium |
|----------------|--------------------------------|-------------------|
| 20,000 | 0 (out‑of‑the‑money) | **‑315** |
| 19,000 | 0 | **‑315** |
| 18,800 | 0 | **‑315** |
| 18,400 | 0 | **‑315** |
| 18,200 | 200 | **‑115** |
| 18,000 | 400 | **+85** |
| 17,800 | 600 | **+285** |
| 17,500 | 900 | **+585** |
| 17,000 | 1,400 | **+1,085** |
| 16,500 | 1,900 | **+1,585** |
| 15,000 | 3,400 | **+3,085** |

*(Negative numbers are losses; positive numbers are profits.)*  

**Key observations (focus on the row where Spot = 18,400, i.e., the strike):**  

1. **Profit climbs as the spot falls below the strike.** That’s the whole point of buying a put.  
   - *Generalisation 1:* **Put buyers make money only when the underlying price ends up **below** the strike.**  
2. **If the spot stays **above** the strike, the buyer loses exactly the premium paid—no more, no less.**  
   - *Generalisation 2:* **Maximum loss = premium paid.**  

You can also condense the math into a single tidy formula (valid at expiry):  

\[
\text{P\&L} = \bigl[\max(0,\; \text{Strike} - \text{Spot})\bigr] - \text{Premium}
\]

Let’s test it with two random spot values:  

- **Spot = 16,510** (well below strike)  

  \[
  \text{P\&L} = \max(0, 18,400-16,510) - 315 = 1,890 - 315 = \mathbf{+1,575}
  \]  

- **Spot = 19,660** (above strike)  

  \[
  \text{P\&L} = \max(0, 18,400-19,660) - 315 = \max(0,-1,260) - 315 = -315
  \]  

Both results match the table.  

### Breakeven point  

The breakeven is the spot where **P&L = 0**. From the formula:  

\[
\text{Breakeven} = \text{Strike} - \text{Premium}
\]  

Plugging our numbers:  

\[
18,400 - 315 = \mathbf{18,085}
\]  

At **₹18,085** the intrinsic value is exactly **₹315**, wiping out the premium. Verify with the formula:  

\[
\max(0, 18,400-18,085) - 315 = 315 - 315 = 0
\]  

### What if we close early?  

So far we assumed we hold the contract *to* expiry. In reality, most traders close **before** the last day. When you exit early, the **time value** component of the option’s price comes back into play, making the actual P&L a bit different (usually higher if volatility is still high).  

For illustration:  

- **Scenario A:** Spot = 17,000 on **30 Apr** (expiry).  
  \[
  \text{P\&L}_{\text{expiry}} = \max(0, 18,400-17,000) - 315 = 1,400 - 315 = \mathbf{+1,085}
  \]  

- **Scenario B:** Same spot = 17,000 but on **15 Apr** (mid‑contract).  
  The option will still have **time value**, so its market price will be **higher** than the intrinsic ₹1,400. If you sell it, you’ll likely pocket **more than ₹1,085** (because you’ll also collect some of that time premium). The exact number depends on volatility, days‑to‑expiry, and interest rates, which we’ll cover later.  

---  

## 5.5 – Put option buyer’s P&L payoff  

If you plot the P&L values against the spot price, you get the classic **downward‑sloping, limited‑loss, unlimited‑gain** graph that is the hallmark of a long put.  

![Put payoff diagram](http://zerodha.com/varsity/wp-content/uploads/2015/04/Image-4_PL-Payoff.png)  

**What to soak up from the chart (strike = 18,400):**  

- **Loss zone:** Spot **≥ 18,400** → loss capped at the premium (‑₹315).  
- **Breakeven point:** **₹18,085** – the line crosses the zero‑profit axis here.  
- **Profit zone:** Spot **< 18,400** – profit rises linearly as the spot falls, theoretically without bound (the market can’t go below zero, but in practice the profit can be huge).  

---  

### Key takeaways from this chapter  

1. **Buy a put when you’re bearish.** You only profit if the underlying drops.  
2. **Put IV formula:** `IV = Strike – Spot` (only on expiry).  
3. **P&L formula for a long put:**  

   \[
   \text{P\&L} = \bigl[\max(0,\; \text{Strike} - \text{Spot})\bigr] - \text{Premium}
   \]  

4. **Breakeven point:** `Strike – Premium`.  
5. **Risk profile:**  
   - **Maximum loss** = premium paid (the cost of buying the insurance).  
   - **Maximum gain** = theoretically unlimited (as low as the underlying can go).  

Now that you’ve mastered the put, you can confidently walk into the options bar, order a “bear‑tail” cocktail, and watch the market’s weather forecast with a smile. Cheers to profiting from the downside! 🍻  