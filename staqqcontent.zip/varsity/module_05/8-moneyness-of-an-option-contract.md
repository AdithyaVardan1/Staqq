# 8. Moneyness of an Option Contract  

**Source:** https://zerodha.com/varsity/chapter/moneyness-of-an-option-contract/  

---  

## 8.1 – Intrinsic Value  

Before we start bragging about “ITM, ATM, OTM”, let’s give a quick (and slightly theatrical) reminder of what **intrinsic value** actually means.  
Think of an option as a “golden ticket” that lets you buy or sell the underlying at a pre‑agreed price. The intrinsic value is the amount of cash you’d walk away with **right now** if you decided to use that ticket, *ignoring* whatever you paid for it. It can never be negative – the worst case is you walk away with zero, not a debt collector on your doorstep.  

### Example that makes you go “Aha!”  

Suppose you bought a **Nifty 8050 CE** (call). The market is currently at **8070** and you could exercise today instead of waiting 15 days for expiry. How much would you pocket?  

When you exercise a long option, the profit = **Intrinsic Value – Premium Paid**. So first we need the intrinsic value. From Chapter 3 we have the call‑option intrinsic‑value formula:  

\[
\text{Intrinsic Value (Call)} = \text{Spot Price} - \text{Strike Price}
\]

Plug‑in the numbers:  

\[
= 8070 - 8050 = \boxed{20\ \text{points}}
\]

If you exercised right now, you’d earn 20 points **before** subtracting the premium you originally paid.  

Below is a quick‑and‑dirty table (made‑up numbers, but good for illustration) that shows intrinsic values for a handful of strikes.  

| Strike | Spot | Intrinsic Value (Call) |
|--------|------|------------------------|
| 7700   | 8070 | 370                    |
| 7900   | 8070 | 170                    |
| 8050   | 8070 | 20                     |
| 8200   | 8070 | 0 (negative → treated as 0) |
| 8400   | 8070 | 0 (negative → treated as 0) |

#### TL;DR – What you must remember  

- **Intrinsic value** = cash you’d get if you exercised **right now**.  
- It can never be negative; the floor is zero.  
- **Call:** Spot – Strike  
- **Put:** Strike – Spot  

#### Why can’t intrinsic value be negative?  

Pick the 920‑call from the table above. Spot = 918, premium = ₹15.  

| Step | Calculation | Result |
|------|-------------|--------|
| Intrinsic value | 918 – 920 | **–2** (negative) |
| “Profit” if we allowed negatives | –2 – 15 (premium) | **–17** |

But a long‑call buyer’s *maximum* loss is the premium paid (₹15). Allowing a negative intrinsic value would let the loss exceed that, breaking the core rule that you can’t lose more than you put in. Hence, by definition we **cap intrinsic value at zero**. The same logic holds for puts.  

So, intrinsic value is always **≥ 0**, and that’s why the payoff diagram of an option always has that nice “kink” at the strike price.  

---  

## 8.2 – Moneyness of a Call Option  

Now that intrinsic value is crystal clear, classifying strikes by **moneyness** becomes a piece of cake (or a piece of naan, if you prefer Indian snacks). Moneyness simply tells you how deep you are in profit territory **if you exercised today**. The three classic buckets are:  

| Category | Meaning |
|----------|---------|
| **In the Money (ITM)** | Intrinsic value > 0 |
| **At the Money (ATM)** | Intrinsic value = 0 *and* strike is the closest to the spot |
| **Out of the Money (OTM)** | Intrinsic value = 0 (i.e., spot is on the wrong side) |

For extra granularity traders also talk about:  

- **Deep ITM** (big intrinsic value)  
- **Deep OTM** (far from the spot)  

### How to tell which is which?  

1. **Find the ATM** – the strike nearest the spot price.  
2. **Compute intrinsic values** for a few neighboring strikes.  
3. **Label**: non‑zero → ITM, zero → OTM, closest → ATM.  

#### Real‑world snapshot (Nifty on 7 May 2015)  

Spot = **8060**. The exchange offered strikes from **7100** to **8700** (see the blue‑boxed screenshot).  

| Strike | Intrinsic Value (Spot – Strike) | Classification |
|--------|--------------------------------|----------------|
| 7100   | 8060 – 7100 = **960**           | **ITM** (deep) |
| 7500   | 8060 – 7500 = **560**           | **ITM** |
| 8050   | 8060 – 8050 = **10** (but we treat it as ATM because it’s the nearest) | **ATM** |
| 8100   | 8060 – 8100 = **‑40 → 0**       | **OTM** |
| 8300   | 8060 – 8300 = **‑240 → 0**      | **OTM** |

A quick sanity‑check:  

- **All strikes *below* the ATM strike are ITM** (you’d make money exercising a call).  
- **All strikes *above* the ATM strike are OTM** (you’d lose money, so intrinsic = 0).  

The NSE even colour‑codes this for you: pale yellow background = ITM, plain white = OTM. Look at the second screenshot – the 7500 and 8000 strikes glow yellow because they’re ITM, while 8200‑plus are stark white.  

> **Pro tip:** The deeper the ITM, the larger the intrinsic value, and the **higher the premium** you’ll pay. Premiums shrink as you move toward deep OTM.  

---  

## 8.3 – Moneyness of a Put Option  

Puts are just calls in reverse, so let’s flip the script. We’ll use the same methodology on the **Nifty put chain** taken on **8 May 2015** (spot = **8202**).  

### Spot the ATM  

The nearest strike to 8202 is **8200**, trading at ₹131.35 – that’s our **ATM put**.  

### Test a few other strikes  

| Strike | Intrinsic Value (Strike – Spot) | Classification |
|--------|--------------------------------|----------------|
| 7500   | 7500 – 8202 = **‑702 → 0**     | **OTM** |
| 8000   | 8000 – 8202 = **‑202 → 0**     | **OTM** |
| 8200   | (ATM – we skip)                | — |
| 8300   | 8300 – 8202 = **+98**          | **ITM** |
| 8500   | 8500 – 8202 = **+298**         | **ITM** |

General rule‑of‑thumb for puts (the mirror of calls):  

- **Strikes *above* the ATM are ITM** (you can sell the underlying at a price higher than market).  
- **Strikes *below* the ATM are OTM**.  

Just like with calls, the ITM puts carry **much larger premiums** than the OTM ones.  

---  

## 8.4 – The Option Chain  

Think of the **option chain** as the ultimate cheat sheet on any exchange platform. It lists every available strike for a given underlying, colour‑coded by moneyness, and also spits out the live premium (LTP), bid‑ask spread, volume, open interest, and a bunch of other goodies.  

Here’s a snapshot for **Ashok Leyland Ltd.** (NSE):  

- Underlying spot = **₹68.7** (highlighted in blue).  
- **Calls** sit on the left side, **puts** on the right.  
- Strikes ascend from low to high in the centre.  

Given the spot of 68.7, the nearest strike is **67.5** → that’s the **ATM** (yellow‑highlighted).  

| Call side (left) | Put side (right) |
|------------------|------------------|
| Strikes **below** 67.5 are **ITM** → pale‑yellow background | Strikes **above** 67.5 are **ITM** → pale‑yellow background |
| Strikes **above** 67.5 are **OTM** → white background | Strikes **below** 67.5 are **OTM** → white background |

The colour scheme isn’t a universal standard – some brokers use different hues – but the idea is always the same: a visual cue to separate ITM from OTM.  

You can explore the full Nifty option chain here: *(link to NSE option chain)*  

---  

## 8.5 – The Way Forward  

You’ve now mastered the *who, what, and why* of moneyness for both calls and puts. The next chapters will dive into the **Option Greeks** – Delta, Gamma, Theta, Vega, and Rho – and explain how each Greek nudges the premium of an ITM, ATM, or OTM strike differently.  

Later we’ll also peek at the **Black‑Scholes formula** to see why a Nifty 8200 PE might be priced at ₹131 and not ₹152 or ₹102. (Spoiler: it’s all about volatility, time‑decay, and the risk‑free rate.)  

So, strap in, keep your sense of humor handy, and let’s keep the learning party rolling.  

**Onwards to Option Greeks!**  

---  

### Key Takeaways from This Chapter  

- **Intrinsic value** = cash you’d receive if you exercised **right now** (ignoring the premium).  
- Intrinsic value can never be negative; the floor is **0**.  
- **Call intrinsic** = Spot – Strike.  
- **Put intrinsic** = Strike – Spot.  
- Any option with a **positive** intrinsic value is **In‑the‑Money (ITM)**.  
- Any option with **zero** intrinsic value is **Out‑of‑the‑Money (OTM)**.  
- If the strike is **closest** to the spot, it’s **At‑the‑Money (ATM)**.  
- For **calls**: strikes **below** ATM → ITM; strikes **above** ATM → OTM.  
- For **puts**: strikes **above** ATM → ITM; strikes **below** ATM → OTM.  
- **Deep ITM** = huge intrinsic value; **Deep OTM** = far from the spot.  
- **Premiums** rise with depth of ITM and fall as you move toward deep OTM.  
- The **option chain** visualises all of the above (plus volume, OI, bid‑ask, etc.) in one tidy table.  

Now go forth, classify strikes like a seasoned bartender classifies cocktails – with confidence, a dash of flair, and a solid understanding of what’s actually in the glass. 🍸📈