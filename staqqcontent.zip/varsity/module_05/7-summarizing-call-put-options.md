# 7. Summarizing Call & Put Options  

**Source:** <https://zerodha.com/varsity/chapter/summarizing-call-put-options/>

---  

## 7.1 – Remember These Graphs  

Over the past few chapters we’ve been hanging out with the two basic option “characters”: the **Call** and the **Put**.  
From those two, we derived **four** distinct roles that you can play in the options‑theatre:

| Role | What you actually do |
|------|----------------------|
| **Buy a Call** | Pay a premium for the right to buy the underlying later |
| **Sell a Call** | Collect a premium for giving someone else that right |
| **Buy a Put** | Pay a premium for the right to sell the underlying later |
| **Sell a Put** | Collect a premium for giving someone else that right |

Just like an artist needs a palette and a canvas, a trader needs these four “brush‑strokes” to paint all kinds of option strategies.  All you need is imagination (and a sprinkle of math).  Before we get fancy, let’s cement the basics by revisiting the payoff diagrams for each of the four positions.

![Pay‑off diagrams for the four basic option positions](http://zerodha.com/varsity/wp-content/uploads/2015/05/Image1_Payoff.png)

Seeing them stacked the way they are helps us spot a few tidy patterns:

1. **Mirror‑image on the left** – The **Buy‑Call** graph sits directly above the **Sell‑Call** graph.  They are perfect reflections of each other.  This tells us a simple truth: the risk‑reward profile of a buyer is the opposite of a seller.  
   * The call‑buyer’s **maximum loss** = the premium paid → this is exactly the **maximum profit** the call‑seller can pocket.  
   * The call‑buyer enjoys **unlimited upside** if the underlying rockets, while the call‑seller’s worst‑case is an infinitely deep hole (the price can keep climbing forever).

2. **Side‑by‑side “bull‑ish” pair** – We placed **Buy‑Call** next to **Sell‑Put**.  Both of these positions make money **only when the market climbs**.  
   * If you buy a call or sell a put while you secretly think the market is about to tumble, you’re basically buying a ticket to a concert that’s been cancelled.  You’ll lose money (or at best break even).  
   * (A quick side‑note: volatility will later add some spice to this picture – but we’ll get to that later.)

3. **Mirror‑image on the right** – The **Buy‑Put** sits on top of **Sell‑Put**, again as twins facing opposite directions.  
   * The put‑buyer’s **maximum loss** is the premium paid – that’s the **maximum profit** for the put‑seller.  
   * The put‑buyer can profit without bound if the underlying crashes, while the put‑seller’s downside is unlimited (the stock could, in theory, go to zero).

---

### Long vs. Short – The Lingo

| Action | “Position” name | What it really means |
|--------|----------------|----------------------|
| **Buy** a call or put | **Long Call / Long Put** | You’re creating a fresh, brand‑new option position. |
| **Sell** a call or put | **Short Call / Short Put** | You’re writing (i.e., creating) a fresh short position. |

But buying or selling can also be a **square‑off** move – i.e., you’re closing an existing opposite position rather than starting a new one.

- **Buy to close** a short: you’re not “going long”; you’re just covering your shorts.  
- **Sell to close** a long: you’re not “going short”; you’re simply exiting.

![Summary table of the four basic option positions](http://zerodha.com/varsity/wp-content/uploads/2015/05/M5-Ch7-title1.png)

---

## 7.2 – Option Buyer in a Nutshell  

By now you should have a mental picture of what it feels like to sit on the *buyer’s* side of a call or a put.  Let’s hammer home the essentials before we sprint ahead.

### When does buying make sense?  

You buy an option when you **strongly believe the market will move** away from the strike in a particular direction.  In other words, the underlying price must **break out** of the strike zone for you to start seeing profit.

#### Key formulas (if you hold till expiry)

| Position | Profit‑Loss (at expiry) |
|----------|--------------------------|
| **Long Call** | `P&L = max[0, Spot – Strike] – Premium Paid` |
| **Long Put**  | `P&L = max[0, Strike – Spot] – Premium Paid` |

A few things to keep in mind:

* These equations only apply if you **hold the option to expiry**.  If you exit early, you’ll have to use the *current* premium, not the intrinsic value.
* The **intrinsic value** (`max[0, …]`) is a **day‑of‑expiry** concept.  During the life of the contract you have *time value* on top of that.
* When you **square‑off early**, the P&L calculation morphs into “what you sold the option for minus what you paid”, plus any transaction costs.
* **Risk is capped** at the premium you paid.  Your loss can’t exceed that amount.  
* **Reward is uncapped** – a call can keep soaring, a put can keep falling, and you ride those waves forever (well, until expiry, of course).

![Long option payoff recap](http://zerodha.com/varsity/wp-content/uploads/2015/05/M5-Ch7-title2.png)

---

## 7.2 – Option Seller in a Nutshell  

(Yes, the original text reused the same heading – we’ll keep it for fidelity.)

The **seller** (also called the **writer**) lives on the opposite side of the buyer’s table.  Your profit‑loss profile is the mirror image of the buyer’s, and you collect the premium **up‑front**.

### When does writing make sense?  

You write when you think the market will **stay flat or move in the “safe” direction**:

* **Short Call** → you’re happy if the price stays **below** the strike.  
* **Short Put** → you’re happy if the price stays **above** the strike.

Because the seller only needs the market to *not* move aggressively, the odds are *slightly* more in their favor compared to the buyer (who needs a decisive move).  That said, don’t take this as a free‑lunch invitation – the risk can be massive.

#### Key formulas (if you hold till expiry)

| Position | Profit‑Loss (at expiry) |
|----------|--------------------------|
| **Short Call** | `P&L = Premium Received – max[0, Spot – Strike]` |
| **Short Put**  | `P&L = Premium Received – max[0, Strike – Spot]` |

Important nuggets:

* These formulas assume you **hold to expiry**.  Exiting early swaps the “max” term for the *current* premium.
* **Margin** is blocked in your account when you write options – think of it as a security deposit for the potentially unlimited liability.
* **Risk is unlimited** (the price could skyrocket for a short call, or plunge to zero for a short put).  
* **Reward is capped** at the premium you collected.

> *“Option writers eat like a chicken but shit like an elephant.”* – Nassim Nicholas Taleb, *Fooled by Randomness*  

In plain English: writers collect modest, regular income, but a single market shock can turn that modest profit into a catastrophic loss.

With this, you should now have a solid mental model of **how calls and puts behave from both sides of the table**.  Upcoming sections will dive into **moneyness, premiums, Greeks, and strike selection**, allowing us to revisit calls and puts with fresh eyes and a professional‑grade toolbox.

---

## 7.3 – A Quick Note on Premiums  

Take a look at this intraday snapshot for BHEL (30 April 2015).  The trade‑date, strike, and option type are highlighted in the red box.

![BHEL premium intraday chart](http://zerodha.com/varsity/wp-content/uploads/2015/05/Image-2_BHEL.png)

* The **230 CE** opened at **₹2.25**, surged to a high of **₹8.00**, and closed the day at **₹4.05**.  
* That’s a **350 % swing** during the session, and a **≈180 % gain** from open to close.  

In the options world, such gyrations are *normal* rather than *exceptional*.  

### Why does this matter?

Imagine you caught just **2 points** of that swing (say you bought at ₹2.25 and sold at ₹4.25).  With a lot size of **1 000**, that’s **₹2 × 1 000 = ₹2 000** in profit – a tidy lunch‑money bonus for a single trade.  

Most traders **don’t hold options to expiry**.  They trade the **premium** itself, entering and exiting positions within minutes, hours, or a few days, hoping to harvest the volatility‑driven price swings.  

* A **100 %+ return** in a single day isn’t unheard of, but it’s not a guarantee.  Consistently pulling it off requires a deep understanding of what drives premium movements.

---

### Another Real‑World Example – IDEA Cellular

![IDEA call premium intraday chart](http://zerodha.com/varsity/wp-content/uploads/2015/05/Image-3_Idea-option-chain.png)

* **190 CE** opened at **₹8.25**, dipped to a low of **₹0.30**.  
* If you were a **short‑call writer** and managed to capture just **2 points** (say you bought back at ₹6.25), with a lot size of **2 000** you’d pocket **₹2 × 2 000 = ₹4 000** – enough for a fancy dinner at the Marriott.

The takeaway: **Most traders chase premium volatility** rather than waiting for the option to expire.  That said, some sellers *do* hold till expiry, especially when they’ve collected a healthy premium and are comfortable with the risk profile.

---

### Why Do Premiums Move?  

Four invisible forces constantly tug at an option’s price.  Think of a **ship sailing**: its speed (the premium) depends on wind, currents, water density, and engine power.  In the options world those “forces” are the **Option Greeks**.

| Greek | What it does (simplified) |
|-------|---------------------------|
| **Delta** | Sensitivity to underlying price moves |
| **Gamma** | Speed of change of Delta |
| **Theta** | Time decay – how the option loses value as expiry approaches |
| **Vega** | Sensitivity to volatility changes |
| **Rho** (often ignored) | Sensitivity to interest‑rate shifts |

The celebrated **Black‑Scholes pricing model** plugs these Greeks (and a few other inputs) into a formula that spits out the theoretical premium.  

Because **the market is a live, breathing beast**, the Greeks change every second, and so does the premium.  In later chapters we’ll dissect each Greek, see how the market moves them, and learn how to use that knowledge to pick the *right* strike.

Our roadmap from here:

1. **Feel the Greeks** – Understand how each Greek pushes the premium up or down.  
2. **Price it right** – See how the Black‑Scholes (and its modern cousins) turn Greeks into a number.  
3. **Choose strikes wisely** – Combine moneyness, Greeks, and your market view to craft sensible trades.

Before we go full‑steam into Greek‑land, make sure you’re comfortable with everything we’ve covered so far.  The Greeks can feel like a foreign language, but with the basics locked down, they’ll start to sound like a dialect you already speak.

---

### Key Takeaways from This Chapter  

- **Buy a call** *or* **sell a put** **only** when you *expect* the market to **rise**.  
- **Buy a put** *or* **sell a call** **only** when you *expect* the market to **fall**.  
- **Option buyers** enjoy **unlimited upside** and **limited downside** (the premium).  
- **Option sellers** face **unlimited downside** and **limited upside** (the premium received).  
- Most traders **trade the premium**, not the underlying price at expiry.  
- Premiums can swing **hundreds of percent** intraday – that’s just the nature of the beast.  
- Four forces – the **Option Greeks** – drive those premium moves.  
- The **Black‑Scholes** (and its successors) combine the Greeks into a single price.  
- **Markets** constantly reshape the Greeks, which in turn reshapes premiums.  

Keep these nuggets in your back pocket, and you’ll be ready to dive deeper into the beautiful (and occasionally terrifying) world of options. Cheers to mastering the call‑and‑put circus! 🍻