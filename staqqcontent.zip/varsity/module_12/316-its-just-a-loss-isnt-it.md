# 316. It’s Just a Loss, Isn’t It?  

**Source:** https://zerodha.com/varsity/chapter/its-just-a-loss-isnt-it/  

---  

Everyone loves the feeling of a win, but are we really chasing triumph just to keep a loss‑avoidance monster at bay?  In the grand theatre of trading, you have to be cool‑headed when the curtain falls on a losing position.  Yet some traders treat every loss like a personal tragedy worthy of a funeral procession.  Dr. Richard Geist, in his cult classic *Investor Therapy*, points out that many traders (consciously or not) replay their biggest life‑losses every time a trade goes south.  So ask yourself: does a trading loss mean exactly what it says on the tin—“just a loss”—or is it secretly trying to whisper something about your ego, your past, or that time you lost your favorite hoodie in high school?  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/06/20041201-300x294.png)  

Geist writes, “Investors who grew up with unresolved losses often have a hard time selling their stocks.”  In plain English: if you never got closure on a breakup, a busted business, or that missed bus, your brain will throw a tantrum every time you’re asked to cut a losing position.  You might cling to a losing trade like a kid holding onto a soggy balloon, or you might sell winners too early just to lock in a tidy profit—missing out on the extra gains that would have come if you’d let the trade breathe.  Even arbitrary rules—like “sell if the price drops 8 %”—can be a sneaky side‑effect of a deep‑seated need to dodge the sting of a big loss.  Losses are a natural part of life, but for some folks they feel like a personal apocalypse.  The emotional baggage attached to a losing trade can be heavier than the actual dollars on the line.  

The cure, dear trader, is to treat stocks like a spreadsheet and not a diary entry.  That’s easier said than done when you start comparing a busted position to that time your best friend told you, “You’ll never amount to anything.”  Suddenly a $200 dip feels like a soul‑crushing verdict from the universe.  Sure, money is on the line and you could lose it—no one’s denying that.  But if you spend every trading session rehearsing the worst‑case scenario (“I’ll lose my house, my cat will abandon me, I’ll be forever a loser”), you’ll end up paralyzed, over‑thinking, and eventually cracking under the self‑imposed pressure.  Trading becomes a horror movie instead of a game of chess.  

If you’re the type who can already look at a trade as a cold, hard business transaction, you’ve got a head start.  For the rest of us, though, we have to unlearn years of attaching personal significance to every tick.  The first step is a simple, almost zen‑like reminder: “It’s just a work product and nothing more.”  Yes, it sounds like a mantra you’d shout in a yoga class, but repetition is the secret sauce.  Tell yourself that a loss is no more a reflection of your self‑worth than a spilled coffee is a reflection of your culinary skill.  Over time, that mantra rewires the brain, loosening the grip of the old belief that every setback is a character‑defining event.  It’s not an overnight miracle, but it’s definitely not hopeless.  

Keep hammering the point home: accepting losses is as inevitable as paying taxes, and it’s actually a prerequisite for winning in the long run.  The more you internalise the idea that losses are just part of the game, the less they will hijack your decision‑making.  Remember, it isn’t the sheer number of losing trades that matters; it’s how quickly and gracefully you bounce back.  If your winning trades consistently out‑earn the losers, you can stop obsessing over that single $50 dip and focus on the bigger picture.  In the end, a loss is only a loss if you allow it to be—otherwise, it’s just a tiny blip on the radar of a trader who knows how to keep the ship sailing.  



---  



*Stay casual, stay funny, and keep those losses in perspective—after all, even the best‑selling bands had a few one‑hit wonders before they hit the charts.*