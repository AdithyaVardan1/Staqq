# 207. Don’t Be Afraid to Go Your Own Way  

**Source:** <https://zerodha.com/varsity/chapter/dont-be-afraid-to-go-your-own-way/>

---

Jim leans over the lunch‑table, tapping his watch like a nervous drummer. “Marty, where the heck have you been? I’ve been standing here for **15 minutes**. The restaurant is about to hand our reservation to the next starving couple.”  

Marty, cheeks pink from the heat of the ATM line, mutters, “Sorry, Jim. I got stuck in the queue at the only ATM we *thought* was working. Everyone else was crowd‑surfing the other machine, convinced it was busted. Then some impatient dude tried the ‘broken’ one, and—surprise!—it was actually fine. If he hadn’t rushed over, we’d have been here another 15 minutes.”  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/04/20060815-300x300.png)

Jim snorts, “No wonder this guy can’t trade—he just follows the herd.” He fires back, “Why didn’t you go check the other ATM yourself? Why just stand there like a statue?”  

Marty sighs, “I didn’t want to make a scene. Imagine the embarrassment if I’d been wrong. Better to wait and look ‘civilized.’”  

Marty is the poster‑child of **extreme conformity**, and in the trading world that’s the stuff of nightmares.

---

## Conformity: The Trader’s Kryptonite  

Marty’s little ATM drama is more than a commuter‑level anecdote; it’s a mirror of how many traders behave when the market gets noisy. He cares *way* too much about what other people think, and he’d rather risk a 15‑minute lunch delay than look foolish.  

### 1. The “Look‑Good” Reflex  

From the moment we’re handed a crayon in kindergarten, we’re taught to keep the picture neat so the teacher (or Mom) won’t frown. That conditioning sticks around like gum under a desk. In the market, it shows up as:  

- **Holding on to a losing trade** just because admitting defeat would feel like a bad hair day in front of the office.  
- **Avoiding novel ideas** because “What will the guys at the bar think of my crazy strategy?”  

Spoiler alert: No one at the bar is actually judging your trade entries. They’re probably more interested in the happy hour specials.

### 2. The Fear‑of‑Risk‑Shame Loop  

Conformists are terrified of being the “guy who messed up.” The mental equation looks something like:  

```
Risk + Possible Failure = Public Shame
```

So they do the safest thing—stay in the *status‑quo*—even if that means missing the next big move.  

But here’s the plot twist: **Everyone fails a lot.** If you ask any high‑flyer, their résumé reads like a Hall of Fame for screw‑ups before the wins.  

- **Babe Ruth** struck out more times than he hit home runs before he became a legend.  
- **Matt Leinart** threw interceptions that would make a quarterback’s therapist cry.  
- **Reggie Bush** got tackled so often you’d think he was auditioning for a wrestling gig.  
- **The Bee Gees** hold a Guinness World Record for the most *“stayin’ alive”* karaoke attempts that never charted. (Okay, that one’s a joke, but you get the vibe.)  
- **Thomas Edison** racked up 1,000+ busted light‑bulb prototypes before finally illuminating the world.  

If Edison had quit after the 999th fizz, we’d still be lighting candles at night.

---

## What the Winning Trader Actually Does  

The champion of the trading arena isn’t some mythic oracle who never trips; they’re the person who **embraces failure** like it’s a free sample at a grocery store. They understand that:  

1. **Risk is a necessary ingredient**—like salt in a soup. Too little and the dish is bland; too much and you’re choking.  
2. **Looking “bad” for a moment is okay**—the market won’t remember your typo, but it will remember your disciplined exit.  
3. **Self‑presentation can be outsourced**—let the numbers do the talking, not your Instagram story.  

So the next time you’re standing in front of two ATMs, or two potential trades, ask yourself: *Am I waiting for the crowd’s applause, or am I pulling the lever that feels right for *me*?*  

The answer, my friend, is simple: **Don’t be afraid to go your own way**—even if it means looking a little odd for a minute. After all, the best stories (and the best trades) start with someone daring enough to press the “different” button. 🍀