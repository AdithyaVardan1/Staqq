# 244. Stay Detached and Impersonal: It’s Not Always About You  

**Source:** https://zerodha.com/varsity/chapter/stay-detached-and-impersonal-its-not-always-about-you/  

---  

Picture Stan: three months of red candles, a drawdown that would make a seasoned accountant wince, and a stomach that feels like it just swallowed a bag of marbles. He’s been at it for two years, and the first six months he already tasted his *first* major drawdown. That early bruise healed, his account bounced back, and he strutted around like he’d finally cracked the “trading code.” Then—bam!—the latest slump hit, and he’s now staring at his screen muttering, “I thought I had it beat. I thought I’d mastered the markets and become a profitable trader, but I was wrong. I’m not as great of a trader as I thought. I’m really disappointed with my performance.”  

Stan’s story is practically the “starter pack” for anyone who’s ever tried to wrestle the market. Early wins, a sudden gut‑punch, and a flood of self‑doubt that could fill a kiddie pool. The key question is: **Should he wallow, or should he step back and watch the drama like a Netflix binge?** Veteran traders would tell you to pull the emotional plug and stay detached. In other words, stop treating every loss like a personal betrayal.

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/04/20061101-300x300.png)

When you read a tale like Stan’s, the first thing most newbies do is nod vigorously and say, “Yeah, of course he’s upset. He’s lost a lot of cash, his ego is bruised, and his future looks as bleak as a Monday morning without coffee.” And they’re right—**it’s perfectly natural** to feel a sting when you watch your capital evaporate faster than a cheap cocktail in a dive bar.  

*Financially*: He’s down a serious chunk of his bankroll. Even if he climbs back to steady profitability, rebuilding that capital will take time, patience, and a few more winning trades than a lottery ticket.  

*Psychologically*: His ego took a hit. He thought he’d “mastered” the markets, only to discover his self‑confidence was about as sturdy as a house of cards in a hurricane.  

So, **should Stan be disappointed?** Absolutely—disappointment is the brain’s built‑in alarm clock that says, “Hey, something’s off; maybe you need to level up.” It can be the spark that gets you back to the books, the webinars, the back‑testing. In short, a little disappointment can be *productive* if you channel it into skill‑building rather than self‑flagellation.  

But there’s a flip side: **detachment**. Trading is a weird hybrid of chess, poker, and a slot machine. The most successful players treat it like a *probability experiment*, not a personal love‑affair. Let’s break that down with a few bar‑room analogies that (hopefully) won’t make you spill your drink.

---

## Why Emotions Are the Worst Trading Partner  

### 1. Trading = Playing the Odds, Not Winning the World Cup  

Think of a trading strategy as a die‑roll or a coin‑flip—except the die has more faces and the coin sometimes lands on its edge (thanks, market noise). If you have a **positive expectancy** strategy, the math says you’ll make money *over a large number of trades*. In the short run, however, even a 60%‑win strategy can give you a streak of losses that feels like the universe is conspiring against you.  

Why? Because **probability theory** loves short‑run chaos. A handful of flips isn’t “infinite,” so it’s entirely plausible to get 10 heads in a row on a fair coin. That’s the same as getting 10 losing trades in a row with a winning system. It’s not a personal vendetta; it’s the law of large numbers playing hard‑to‑get.

### 2. Ego vs. Edge: When Pride Becomes a Liability  

In most jobs, you can tie your ego to outcomes: you work hard, deliver a project, and the boss (or your paycheck) rewards you. The relationship feels *direct*. In trading, you can grind, study charts, and still watch the market swing the other way because **the odds are indifferent to your hustle**.  

If you let your ego ride every trade like a prizefighter, a single loss will feel like a knockout. Detachment is the “coach in the corner” that says, “Okay, that punch landed. Reset, follow the game plan, and keep your guard up.” It’s not about being cold‑hearted; it’s about keeping your *process* intact while the *outcome* fluctuates.

### 3. The “I’m a Master” Trap  

Let’s be honest: there’s no such thing as a market‑master who never loses. Even the legends—Jesse Livermore, Paul Tudor Jones, those guys who made a fortune—have had years where the market beat them like a drum. If you truly *have* a high‑probability edge, the math tells you that **the odds will eventually swing back in your favor**. But you need to be patient enough to wait for the law of large numbers to do its thing, not impatient enough to chase every bounce.

---

## How to Get Your Zen On (While Still Making Money)

1. **Treat each trade as a “ticket”** – You buy a ticket to a raffle. Sometimes you win, sometimes you lose. The more tickets you buy (within a sensible risk budget), the higher the chance you’ll end up with a prize.  

2. **Risk Management = Your Safety Net** – Think of it as wearing a seatbelt while driving a Ferrari. You love the speed, but you don’t want the crash to end your trip. Position sizing, stop‑losses, and diversified strategies keep a single loss from turning into a financial apocalypse.  

3. **Process Over Profit** – Write down the *rules* of your system: entry criteria, exit rules, risk per trade. Then **follow them like a recipe**. If the dish comes out bland, you tweak the spices, not the oven temperature every time it burns.  

4. **Accept the Randomness** – Imagine you’re at a casino (which, technically, you are). The house edge exists, but you’re there for the *experience* and the *probability* of a win, not the guarantee that every spin will be a jackpot.  

5. **Use Disappointment as Data** – When you’re disappointed, ask: “What did the market do that I didn’t anticipate? Was my stop too tight? Did I ignore a higher‑time‑frame signal?” Turn that feeling into a bullet point on your trading journal, not a self‑esteem crisis.

---

## The Bottom Line: Detach, But Don’t Disengage  

If Stan truly *has* a solid edge, the market’s temporary hostility is just a phase—like a hangover after a night of “learning.” By staying detached, he avoids the emotional roller‑coaster that makes him either **gloat** when luck smiles or **sulk** when it frowns. Detachment doesn’t mean he stops caring about his capital; it means he cares *about the process* more than the outcome of any single trade.

In practice, that translates to:

- **Keeping ego in the locker room** – Celebrate wins, but don’t let them inflate your self‑image.  
- **Sticking to risk rules** – No “I’ll risk 10% this time because I feel good.”  
- **Viewing each loss as a data point** – Not a personal indictment.  
- **Understanding that “mastery” = “consistent probability advantage,”** not “guaranteed profits.”  

So, Stan (and anyone else feeling the sting of a drawdown), grab a cold brew, step back, and remember: the market is a giant, indifferent dice‑roller. Your job is to stay in the game long enough for the odds to do their thing, while keeping your emotions on a short leash. That’s how you turn a painful slump into just another chapter in a longer, more profitable story.

---  

*Cheers to staying detached, keeping the ego in check, and letting the odds do their magic!*  