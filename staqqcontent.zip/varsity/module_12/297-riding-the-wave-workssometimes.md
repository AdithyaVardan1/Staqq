# 297. Riding the Wave Works…Sometimes  

**Source:** https://zerodha.com/varsity/chapter/riding-the-wave-workssometimes/  

---  

> “I like it when a plan comes together.” – *Hannibal Smith, A‑Team*  

A couple of weeks back we used Apple’s (AAPL) product launch and earnings binge to illustrate how the herd can sometimes act like a crowd at a free‑beer festival: unpredictable, loud, and occasionally very profitable. The truth is, nobody can read the collective mind of the market in advance. Will the masses gulp the news like a fresh latte? Or will they stare at it, yawn, and move on? It’s a mystery that only resolves itself after the fact—kind of like waiting for a pizza delivery you can’t see the driver’s bike.

If you glanced at the AAPL chart over the last few weeks, you’d notice a curious pattern: while most tech stocks were doing the “down‑and‑out” dance, Apple’s price was bobbing along with media hype and analysts’ chatter. Guess that the product announcements and earnings would push the price upward? Congratulations, you’d have just pocketed a tidy profit. That’s the essence of “riding the wave”—sometimes the crowd’s sentiment is a surfboard you can hop on without wiping out.

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/05/20050215-294x300.png)

It sounds as easy as ordering a cocktail: “Give me a wave, hold the splash.” But—just like a cocktail—too much of it without a garnish of caution can leave a nasty hangover. A plan that looks flawless this Monday could crumble into a soggy mess by Friday. So keep one eye on the horizon and the other on your risk‑management life‑vest.  

---

## The Apple‑to‑Apple (pun intended) Growth Story  

Over the past 12 months Apple has been on a growth binge, climbing from roughly **$20 a share** a year ago to **over $70** at the close of the most recent Monday. Do the math: buy‑and‑hold a year ago and you’d have raked in **more than 300 %** returns (yes, even more than a triple‑espresso). If only we all possessed a crystal ball (or at least a very accurate fortune‑telling cat).  

Remember the iPod hype? At the Macworld Expo analysts were chanting “5 million iPods sold!” like a football crowd. In the week leading up to the show the stock drifted upward from about **$65 to $70**, purely on the buzz. Then Steve Jobs stepped up and announced **4,580,000** iPods sold—short of the 5‑million hype. The reaction? The price took a nosedive as the herd sold, because expectations weren’t met. Simple psychology: **when reality under‑delivers, the crowd runs.**  

Without insider intel, nobody could have known the exact sales number before Jobs spoke. So trying to profit from that news was a bit like betting on a roulette wheel—fun, risky, and dependent on pure luck. Even though Apple rolled out a parade of shiny new gadgets that analysts thought would fatten the next quarter’s profit, the stock still slid—likely because other tech stocks were coughing and sputtering, pulling the whole sector down.  

Bottom line: you can’t fully predict whether the crowd will react the way you hope. Will a surprise earnings beat make them cheer? Will a weak product number make them scream? The market is a cocktail of news, sentiment, and—sometimes—pure randomness. If you had bet on a price rise at the close that day, you’d have been left holding the bag. The masses sold off on the lower‑than‑expected iPod sales **and** on the gloom spreading from other tech stocks.  

---

## Waves of Earnings and the “Whoa, That’s a Bounce!” Effect  

Trading isn’t a single wave; it’s a whole ocean of them. The very next day Apple’s earnings **beat** analysts’ forecasts. Guess what happened? The price popped up like a startled rabbit, as most expected. Even with intra‑day jitter, AAPL kept closing near **$70** most days over the past two weeks—the highest it’s been in several years.  

Will the upward tide keep rolling? Who knows! New product launches could be delayed, a global event could send shockwaves through the market, or the next iPhone could be made of cardboard (hey, we can dream). Yet, sometimes trading can feel almost *too* easy: price rises, price falls, repeat, and if you time your buys and sells just right, you end up with a “tidy profit”—like finding a twenty in an old jacket pocket.  

---

## The Axiom Nobody Wants to Hear  

There’s a hard‑core trading proverb that feels a bit like a bad dad joke: **Sometimes the market behaves exactly as you expect, and sometimes it behaves like a cat on a hot tin roof.** Most folks cling to the comforting belief that the world runs like clockwork. In reality, life is more like a reality TV show—full of twists, surprise eliminations, and dramatic cliffhangers.  

We never truly know which events will nudge a stock’s price or how the masses will react. Did we forget to factor in a Fed rate cut? A sudden supply‑chain hiccup? A celebrity tweet? At the end of the day, it’s all an **educated guess**—a mix of data, intuition, and a dash of “let’s hope for the best.”  

Accepting that risk is part of the game is crucial. Conventional wisdom only works *when* it works. When it doesn’t, you need the humility to shrug it off, learn, and move on. The market rewards the traders who can roll with the punches, not the ones who keep staring at the scoreboard hoping for a perfect 10‑0 run.  

---

## History, the Masses, and the Art of Going With—or Against—The Grain  

History repeats itself **only when it wants to**. The crowd behaves predictably **only when it feels like it**. That’s a fact, not a feeling. Sometimes you can simply follow the herd—like joining a conga line at a wedding—and cash in. Other times you need to be the contrarian who says “nope, I’ll go left while everyone goes right” (think of the guy who bought Netflix in 2002).  

Ultimately, it’s about embracing uncertainty, making your best‑educated guesses, and acting decisively. If you pull off enough trades, the law of large numbers suggests you’ll end up with a net profit—just like a gambler who eventually wins by playing the odds, not the roulette wheel.  

So remember: **a plan may come together, or it may fall apart faster than a cheap IKEA bookshelf.** When it falls, treat it like a spilled drink—wipe it up, order another round, and keep the night (and your portfolio) moving forward. With that mindset, you’ll be on the right side of the long‑run profit curve. Cheers to riding those waves, both the smooth swells and the gnarly breakers!  