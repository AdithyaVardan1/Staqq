# 295. Trading With Discipline  

**Source:** https://zerodha.com/varsity/chapter/trading-with-discipline/  

---  

Top‑notch traders are the kind of people who would still eat their veggies even when there’s a pizza party happening. As the ever‑wise John Hayden puts it, “Without discipline, you’ll never tame your ego, craft empowering beliefs, have faith, or feel confident in your abilities. A lack of discipline stalls a trader’s growth faster than a traffic jam on a Monday morning.” It’s easy to imagine yourself “winging it” like a reckless pilot, but if you don’t lock down a crystal‑clear trading plan and stick to it like gum to a shoe, the road to lasting financial success will be as bumpy as a pothole‑filled highway.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/05/20050217-294x300.png)  

### “What’s the harm?” – The Siren Call of a Lucky Win  

You might be thinking, “Hey, I made a tidy profit even after I tossed my plan out the window—so why bother?” That momentary thrill is about as reliable as a lottery ticket that actually wins twice in a row. A single, lucky winning trade can feel like a free‑drink at happy hour, but habitually entering positions on a whim erodes your discipline faster than a cheap beer erodes your liver. When you skip the plan and still cash out, your brain hands you an undeserved gold star. That “reward” convinces you that ditching the plan is no big deal, and before you know it you’re the poster child for “I’ll try something new tomorrow.”  

The problem is that those shiny, unjustified wins are usually flash‑in‑the‑pan. They can’t carry you through the inevitable rough patches, and the longer you rely on them, the deeper the eventual loss will hit—think of it as a hangover after that “just one drink” night.  

### Justified Wins vs. Unjustified Wins – The Accounting of Luck  

Let’s break it down like a bartender tallying tabs:  

- **Justified win** – You sit down, write a meticulous trading plan, follow it step‑by‑step, and the trade works out. The profit is the logical, “I earned this because I did the work” kind of satisfaction. It reinforces discipline, like a high‑five after nailing a perfect jump shot.  

- **Unjustified win** – You wander in, ignore the menu, order whatever looks good, and miraculously get a decent drink. The profit arrives by sheer chance, not because you followed a method. That “win” feels good, but it’s a false alarm that can seduce you into more reckless orders.  

### Discipline = Consistency = Profit (It’s Not Magic, It’s Math)  

Trading is essentially a long‑term gamble where the law of averages is your best friend. Think of it as shooting free throws in basketball: the more you practice the same motion, the higher the chance the ball swishes through the net. If you start mixing up your technique every time—one day you shoot with your left hand, the next with a spaghetti noodle—your scoring average will nosedive.  

The same principle applies to the markets. You need a repeatable, proven strategy that you execute on *every* trade, just like a seasoned shooter repeats his form on every possession. When you do that, the probability curve bends in your favor and, over a large enough sample of trades, you’ll end up in the green. Flip‑flopping between plans or abandoning the script mid‑game scrambles those odds and usually lands you on the losing side of the ledger.  

### Bottom Line: Let Discipline Pay the Bills  

Don’t let those occasional, unjustified windfalls tempt you into a “plan‑free” lifestyle. Treat each trade as a disciplined experiment, and let the compounding effect of consistent, rule‑based decisions do the heavy lifting. In the long run, the trader who respects the plan will be the one sipping a well‑earned cocktail while watching the profits roll in, not the one nursing a bitter after‑taste of missed opportunities.  

Stay disciplined, follow the plan, and let the law of averages work its magic—your future self (and your bank account) will thank you. 🍹📈