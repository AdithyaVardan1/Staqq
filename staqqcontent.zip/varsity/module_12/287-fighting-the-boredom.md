# 287. Fighting the Boredom  

**Source:** https://zerodha.com/varsity/chapter/fighting-the-boredom/

---  

Trading can feel like the most thrilling roller‑coaster you’ve never been on. You picture the stacks of cash rolling in, the way a sudden win could buy you that shiny new bike, the fancy coffee machine, or even that beach house you’ve been day‑dreaming about while scrolling TikTok. Some folks get a buzz just **thinking** about how a trade might pan out, others love the adrenaline spike when the order hits the tape.  

But here’s the kicker: a surprising number of traders spend half the day staring at a chart like it’s a blank wall, waiting for the *right* cue. That waiting game can be drier than a martini at a desert party, and boredom starts creeping in. When the market decides to take a coffee break, many traders reach for the “trade‑more‑stuff” button just to sprinkle a little excitement into the day.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/05/20060309-300x300.png)  

The crowd‑sourced drama of the market is basically a tug‑of‑war between **fear** and **greed**—think of it as the financial version of a soap opera, only the characters are numbers and the plot twists cost you real cash. The asymmetry is real: losing $1,000 feels like getting a splinter in the eyeball, while gaining $1,000 is about as pleasant as finding an extra fry at the bottom of the bag. Still, those emotions are the secret sauce that makes the market feel alive. You can’t make money without putting some of it on the line, and eventually greed tends to out‑grow fear—otherwise we’d all be stuck in the “I‑won’t‑trade‑again‑ever” corner.  

In practice, every trading session is a mini‑theatre of fear vs. greed. The drama is intoxicating: you cheer when the price climbs, you panic when it drops, you sell to protect what’s left, then you stare at the screen and think, “Bored again? Let’s chase that big win!” And the cycle repeats, like a bad sitcom that somehow never gets canceled.  

Understanding why the masses act the way they do is like reading the script of that sitcom. They chase thrills, buy the hype, then bail out at the first hint of trouble—often at a loss. The question for you, dear trader, is: **Which side of the drama do you want to sit on?** Do you want to be another character who runs around in fear and greed, or do you want to be the quiet, slightly smug “pro” who watches the crowd’s predictable missteps and scoops up the leftovers? Think of yourself as the bartender who knows exactly when to pour the next round because you’ve seen the patrons’ drinking patterns for years.  

When the herd buys because they’re chasing a hype‑filled high, you can anticipate the inevitable sell‑off and position yourself to profit from their collective sigh. But remember, you’re still human. The same dopamine rush that makes you want to shout “Buy!” at a rally can also make you reach for a trade just because you’re bored. The professional trader is not a robot; we all crave drama—just not **in** our trading.  

The secret sauce is to **park** that craving for excitement elsewhere. Sign up for a salsa class, binge a new series, take up rock climbing, or simply adopt a pet rock that you can name “Excitement.” By satisfying your need for thrills outside the market, you can treat trading as the disciplined, methodical practice it really is—like brushing your teeth, only with a lot more money on the line. The market will still throw you a few fireworks now and then, but if you keep your eyes on the systematic plan, you won’t be the one who chases every spark.  

In short: the market is a drama‑filled arena, but you don’t have to be the lead actor in every act. Keep the drama in your hobbies, keep your trading cool, objective, and systematic, and watch the profits stack up while the boredom stays where it belongs—on the other side of the screen, sipping a latte while you execute your plan like a pro. 🍸📈