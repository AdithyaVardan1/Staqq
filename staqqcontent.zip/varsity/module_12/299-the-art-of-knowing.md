# 299. The Art of Knowing  

**Source:** https://zerodha.com/varsity/chapter/the-art-of-knowing/  

---  

If you’re the kind of eternal optimist who thinks “the glass is always half‑full… and the bartender will keep refilling it,” you probably break out in a cold sweat at the sound of *bad news*. But here’s the kicker: “bad” is a relative word. What feels like a gut‑punch to one trader is just another piece of data – or even a party‑time invitation – to another.  

> **Example:** Imagine you went **long** a stock on Friday and the market decided to take a tumble. To you, it’s a nightmare headline. To the trader who was **short**, it’s like discovering a free‑food buffet.  

New‑bies often go full‑on “no‑news‑please” mode, shoving any uncomfortable info into the darkest corner of their brain. That avoidance shows up in a bunch of creative ways.

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/05/20050211-294x300.png)

1. **Paper‑loss hoarding:** Some keep losing trades alive on the screen forever, hoping that someday the numbers will magically turn green.  
2. **Stat‑shy syndrome:** Others refuse to glance at their win‑loss ratio, because admitting a 40 % win‑rate feels like being told you’re terrible at Mario Kart.  
3. **Win‑ratio gymnastics:** A few will deliberately slice the profit‑target on a handful of micro‑wins just to inflate that shiny win‑ratio, like buying a fancy trophy you’ll never display.  
4. **Monthly “hope” deposits:** And there’s the classic “feed the account $500 a month and pray the market will finally hand you a unicorn trade.”  

All of these are just **psychological denial** in disguise – a lazy, passive attempt to dodge the uncomfortable truth. The upside? Knowing more about your own performance is like having a secret cheat code: the more you understand, the better you can tweak your strategy and, ultimately, bring home more profit.  

### When Denial Might Actually Help  

Denial isn’t always the villain. Picture a solid, battle‑tested trading plan that you’ve stress‑tested for months. If you start obsessing over every improbable “what‑if” (think “the market will implode because Mercury is in retrograde”), you’ll freeze at the entry point. A dash of denial can keep you **carefree** right before the trade, letting you execute without second‑guessing yourself.  

But that little‑white‑lie is a short‑term band‑aid. Over the long haul, chronic denial is a profit‑draining leech. If you keep dodging performance reviews, you’ll live with a constant, gnawing unease – the kind you feel when you know you left the oven on but pretend you don’t.  

### Why the Honest Look is the Real Party Trick  

Let’s be real: staring at a losing streak feels about as pleasant as watching paint dry on a rainy day. Yet, **if you never look, you’ll never know what to fix**. It’s an attitude game. Winners treat their performance like a mechanic treats a busted engine.  

* **Step 1 – Diagnose:** Pull up the numbers, watch the trades play out, and spot the patterns that work and those that don’t.  
* **Step 2 – Replace the Bad Parts:** If a particular entry rule is a lemon, toss it out. If a stop‑loss size is consistently too tight, loosen it.  
* **Step 3 – Test the Fix:** Run the revised system on paper or a demo account, then decide if it’s ready for the live stage.  

In other words, instead of whining at the TV about “the market is out to get me,” imagine you’re watching a documentary about a cool, detached trader who calmly narrates, “Here’s what happened, here’s why, and here’s how we improve.”  

### Action Plan: Get Comfortable with the Uncomfortable  

If you haven’t flipped through your trade journal lately, consider it a **mission‑critical** task. Here’s a light‑hearted checklist to make the process less soul‑crushing:  

| ✅ | What to Do | Why It Helps |
|---|------------|--------------|
| 1 | **Schedule a “performance night.”** Set a calendar reminder – think Netflix binge, but with charts. | Turns a dreaded chore into a ritual. |
| 2 | **Adopt a neutral tone.** Pretend you’re a TV presenter narrating, “And now we examine the win‑loss ratio of our fearless protagonist.” | Keeps emotions from hijacking the analysis. |
| 3 | **Label every loss as “data.”** No shame, just information. | Removes the stigma of a “bad trade.” |
| 4 | **Celebrate tiny wins.** A 0.2 % profit on a micro‑trade? Pop a virtual confetti. | Reinforces positive reinforcement. |
| 5 | **Write one actionable tweak.** E.g., “Reduce max‑drawdown per trade from 2 % to 1.5 %.” | Gives you a concrete next step. |

If the numbers don’t meet your lofty expectations, **don’t call it a failure**; call it **feedback**. Treat it like a coach’s video review after a football game – you watch, you learn, you adjust. Stay calm, stay upbeat, and keep the creative juices flowing.  

### Knowing When to Step Back  

Sometimes the data will tell you that a strategy is just a sunk ship. In that case, the smartest move is to **park the boat** rather than keep pumping fuel into a leaky hull. Walk away, take a breather, and return with fresh eyes when you’ve cooked up a new plan.  

Conversely, if you’re actively **problem‑solving**—digging into trade logs, testing tweaks, learning from each loss—you’ll eventually crack the profitability code. And once you’re in that habit loop of *review → adjust → re‑review*, you’ll be better equipped to ride any market condition, from a tranquil bull to a raging bear.  

So, raise a glass (of whatever non‑alcoholic beverage you prefer) to the uncomfortable truth: **knowing yourself is the most profitable trade you’ll ever make**. Cheers to the art of knowing!