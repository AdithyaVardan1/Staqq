# 149. The Background Factors That Throw Us Off  

**Source:** https://zerodha.com/varsity/chapter/the-background-factors-that-throw-us-off/

---  

Trading is supposed to be a zen‑like activity: stare at charts, sip coffee, and let the market whisper sweet nothings to your brain. In reality, it’s more like trying to solve a Rubik’s Cube while riding a roller‑coaster – you need laser focus, and even a tiny impulse can send you careening off the rails. Why do we act on impulse? The list is as long as a broker’s commission schedule. Some of us are born “thrill‑seekers” who get a buzz from risk the way other people get a buzz from a good burrito. Even the most monk‑like trader, however, finds his self‑control muscles wobbling now and then. The trick is to keep a diary of the moments when your discipline cracks and to shrink those pesky triggers as much as humanly possible.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/03/20060717-300x300.png)

Ever been so knackered that the thought of *any* activity beyond flopping into bed feels like an Olympic sport? Imagine you’re so beat you consider checking into a hotel halfway across town just to avoid the trek home. Or picture yourself starving enough that you’d gladly devour a deep‑fried, cheese‑smothered monstrosity you swore you’d never touch again. When the bus is late and you’re running late, the idea of splurging on a cab suddenly looks like a life‑saving miracle.  

Now, let’s take it a notch higher: you’ve let the laundry pile up for a week, you’re too exhausted to even throw a single sock into the washer, and—what’s this?—you’re tempted to swing by a department store to buy fresh undies for tomorrow. (Because, of course, clean underwear is the foundation of any successful trade.) These anecdotes prove a simple truth: fatigue and pressure turn us into a different species, one that makes decisions we’d normally file under “What Was I Thinking?” When the stress‑monster finally retreats and our brain returns to its usual rational self, we’re left staring at the aftermath, cringing at the choices we made in the heat of the moment. The same drama unfolds on the trading floor.  

When market pressure squeezes you into abandoning your meticulously crafted plan, the regret that follows can feel like a punch in the gut. Say you’re holding a position that’s stubbornly heading the wrong way. Your inner critic starts chanting, “Sell! Sell! Sell!” and you slam the order, abandoning the patient, rule‑based exit you’d promised yourself. Anxiety and discomfort act like gremlins that sabotage self‑control, making you forget the long‑term consequences and focus solely on the immediate relief of the uneasiness.  

## How do we keep our cool?  

1. **Admit that self‑control is a finite mental muscle.**  
   Think of psychological stamina the same way you think of a bicep after leg day—you can only lift so much before you start wobbling. If you’ve been battling the urge to book profits early, to resist the siren song of “just one more trade,” or to stay glued to your stop‑loss for weeks on end, you’re basically running a mental marathon without proper training. Your “impulse‑resistance” muscles are exhausted, and you’ll find yourself flailing at the first chance to slip.  

2. **Don’t pile on other self‑control projects while you’re already depleted.**  
   This isn’t the time to start a keto diet, take on a weekend side hustle, or vow to cut Netflix to “zero.” Your brain’s self‑control reservoir is already low; adding more “will‑power drains” will turn it into a desert. Instead, give yourself permission to indulge in small, harmless pleasures elsewhere (maybe that extra slice of pizza or a lazy Sunday binge) so you can reserve the remaining mental firepower for the market.  

3. **Recharge with sleep and rest—your brain’s version of a power‑nap espresso.**  
   Psychological resources are even scarcer when you’re running on fumes. Catching extra Z’s is like adding premium fuel to a race car; you’ll be able to focus sharper, react quicker, and, most importantly, keep the “I‑just‑have‑to‑sell‑now” reflex in check. Think of a good night’s sleep as a reset button for your trading‑brain firmware.  

4. **Knock down background stress like a kid demolishing a Jenga tower.**  
   Stress isn’t just the big, obvious stuff (like a market crash); it’s the sneaky little things humming in the background—bills, relationship drama, that weird email from your boss about “new KPIs.” Those low‑level stressors gnaw away at your concentration bandwidth, leaving you with a thinner slice of mental real‑estate to devote to your trading plan. Spot these hidden stressors, neutralize them (or at least put them on a “deal with later” list), and you’ll keep your self‑control engine humming when the market throws a curveball.  

By treating your psychological stamina like any other trading capital—monitoring, protecting, and replenishing it—you’ll stay steadier when the market tries to tempt you into a rash move. In short, keep the mind rested, the background stress low, and the impulse‑driven “just‑do‑it” button locked away until you’ve earned the right to press it. Happy, well‑rested trading!