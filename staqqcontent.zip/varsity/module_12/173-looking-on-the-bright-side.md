# 173. Looking on the Bright Side  

**Source:** https://zerodha.com/varsity/chapter/looking-on-the-bright-side/  

---  

Winning traders don’t just wing it like they’re playing a round of “Pin the Tail on the Market”. They act like lab‑coats in a chemistry class: they write down a hypothesis, concoct a disciplined trading plan, and then *actually* run the experiment by putting a trade on the board. The whole thing is as systematic as a Swiss watch—tick‑tock, test, tweak, repeat.  

Sometimes the data scream “Eureka!” and the method proves profitable under a specific market climate (think of it as finding a sweet spot on a surfboard). Other times the numbers just laugh at you, showing the theory was a flop. That’s when the revision stage kicks in. You have to sit down, play detective, and ask: *What went wrong? What went right?* Then you adjust the model, like swapping out a busted tire before the next race.  

The key, however, is to keep the post‑mortem **emotion‑free**. If you let feelings hijack the analysis, you’ll end up in a puddle of pessimism, tearing your own strategy apart like a toddler with a new toy.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/03/20070215-300x300.png)  

---

## When the Market Gives You the Cold Shoulder  

It’s all too easy to slip into the “Everything’s a mess” mindset. You start muttering, “Man, this is terrible. I should’ve been a barista instead.” Even the most chill‑as‑a‑cucumber trader can turn into a professional downer in a heartbeat.  

Why does that happen? Because pessimism opens the door to denial, and denial invites emotional, knee‑jerk reactions. Picture a cat that’s just been startled—it darts, it swats, it knocks over a vase. In trading, those impulsive moves usually end up as **losses** (and a lot of regret).  

---

## The “Bright Side” Cheat Code  

When the charts look like a toddler’s scribble, the temptation is to whisper to yourself, “At least it could’ve been worse.” Say you lose $10,000 on a trade you thought was a *sure thing*. Instead of spiraling, you could think, “Well, thank the trading gods I didn’t lose $20,000!” It’s the classic “glass half‑full” trick, but with cash instead of water.  

A real‑world sanity check comes from Dr. Chris Davis, a psychology professor at Carleton University, and his research crew. They asked volunteers to imagine a major setback. One group was told to **focus on how bad it could have been** (the bright‑side approach). The other group was asked to **focus on how great it could have been** (the “look‑on‑the‑up‑side” approach).  

The scientists measured mood afterwards. Guess which group walked away smiling? The “could‑have‑been‑worse” crowd. In plain English: *Thinking “thankfully it wasn’t a total disaster” makes you happier than thinking “if only it had been a total win.”* So, if you want to keep your chin up after a nasty loss, count your blessings—especially the ones you didn’t lose.  

---

## How Your Lens Shapes Your Recovery  

Your mental framing of a setback is basically the GPS for your recovery. If you label a loss as a personal apocalypse, you’ll be flooded with anxiety, denial, and the urge to hide under your desk. You’ll waste precious mental bandwidth on “What the heck just happened?” instead of “What’s the next move?”.  

Instead, treat setbacks like a pothole on a road trip. You don’t scream at the pothole; you slow down, adjust your line, and keep driving. Identify the problem, brainstorm fixes, and move on. Don’t get stuck replaying the crash scene in your head like a bad Netflix binge.  

---

## Stop the Self‑Flagellation, Start the Science  

When you dissect a busted trading plan, it’s tempting to beat yourself up like a drum solo gone wrong. “Why didn’t I have a bullet‑proof plan? I’m a loser!” – cue the sad violin. But dwelling on the *why* fuels disappointment and stalls progress.  

What you need is a **scientist’s mindset**: treat the trade like a math problem you’re solving for extra credit. Write down the variables, plug in the numbers, see where the error term is, and move on. Self‑doubt is just mental static that wastes energy—energy you could spend on the next high‑probability entry.  

So, give yourself a quick “bright‑side” pep talk, then roll up your sleeves, hunt for the next edge, and lock in that winning trade. Remember: the market will always throw curveballs; it’s up to you to decide whether you’ll duck, swing, or—better yet—hit it out of the park. 🚀