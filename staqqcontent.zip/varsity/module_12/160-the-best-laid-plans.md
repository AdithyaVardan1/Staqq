# 160. The Best Laid Plans  

**Source:** https://zerodha.com/varsity/chapter/the-best-laid-plans/

---  

Novice traders love to brag about the “perfect” trading plan they scribbled down on a napkin after a couple of espresso shots—until the market opens and they start Googling “how to quit trading without looking like a loser.” The sad reality is that most of these freshly‑minted plans are either so fuzzy they belong in a weather forecast (“maybe enter if the market feels sunny”) or they’re missing whole chunks, like the exit strategy (yeah, you can’t just ride a trade forever). When a plan looks like an IKEA manual with half the pages torn out, it’s no wonder you can’t follow it.  

But vagueness is only half the story. The real drama unfolds **when you actually try to execute** the plan. You built it in a zen‑like state of calm—perhaps while watching the sunset, sipping chamomile tea, and humming “Don’t worry, be happy.” You nailed down entry and exit points, stop‑loss levels, profit targets, and even the exact meme you’d post if it worked. Then, the next morning, the market bell rings, your inbox pings, and a whole circus of emotions storms the stage. If you let those feelings run wild, they’ll stomp all over your carefully‑crafted blueprint.

> **Emotions are like a bad Wi‑Fi connection:** they can make you see the same chart as a blurry mess.  

Imagine you wrote your plan on a quiet Tuesday night. Everything seemed logical: “Buy at 10,200, sell at 10,500, stop at 10,100.” Fast forward to Monday, and you’re staring at the screen with a coffee that tastes like regret. Your mood has shifted—maybe you dreamed you were being chased by a giant hamster, maybe you just remembered that your kid’s tuition is due next month, or maybe the office temperature feels like a sauna in July. Suddenly, the numbers that looked crystal‑clear now look like a cryptic crossword.  

Your car is coughing louder than a cat with a hairball, the thermostat is stuck on “tropical storm,” and the market is wobblier than a three‑legged chair. All these “external” irritants—real or imagined—sneak into your brain and tint your perception. What you do next is a personal choice:  

- **The “wait‑and‑see” crowd:** They step back, sip water, and wait for the emotional clouds to clear.  
- **The seasoned samurai:** They’ve seen enough market mayhem to treat emotions like background noise, flick the switch, and keep marching.  

If you’re a fresh‑out‑of‑trading‑school rookie, you’re more likely to get rattled and either bail on the trade or, worse, make a sloppy, emotion‑driven entry. That’s the moment most plan‑abandonments happen—when the mind is a jittery squirrel and the heart is doing the cha‑cha‑cha.

## How to Stop Your Plans from Turning into Hot Air Balloons  

1. **Write a crystal‑clear plan** – No vague “maybe” or “somewhat.” Spell out:  
   - *Exact entry price* (e.g., “Buy at 10,200 if the 15‑minute EMA crosses above the 30‑minute EMA”).  
   - *Signal for exit* (e.g., “Sell at 10,500 or when RSI > 70”).  
   - *Stop‑loss location* (e.g., “Place a stop at 10,100, no wiggle room”).  
2. **Make execution your sole mission** – Treat it like a Netflix binge: you’re not pausing halfway to check the fridge. When emotions start whispering “maybe wait,” remind yourself you have a limited pool of psychological bandwidth. Think of your brain as a smartphone battery; you don’t want to run low while trying to navigate a complex app.  

   - **Don’t over‑think**: The plan is your map; the market is the terrain. If you keep re‑routing mid‑journey, you’ll end up in a ditch.  
   - **No last‑minute tweaks**: If you feel the urge to adjust the stop‑loss a few ticks because you “just have a gut feeling,” politely decline. The plan already baked in a risk buffer, so you’re safe.  

3. **Adopt a warrior mindset** – Picture yourself in full armor, sword drawn, ready to duel a dragon (the dragon being the market volatility). Warriors don’t pause to count their scars before the first swing; they trust their training and go for the kill. Likewise, once your trade ticket is punched, lock eyes with that candle and charge.  

   - **Live in the now**: The past is a dead horse, the future is a mystery box. The only thing you control is the present action—press that “Buy” button or place that stop.  
   - **Remember the risk was pre‑priced**: You already factored the worst‑case scenario into your stop. If it hits, you’ve lost a predetermined amount, not a fortune.  

## The “Fate‑Or‑Flub” Thought Experiment  

Think of your trade as a movie that’s already been scripted. The director (you) wrote the plot, cast the characters (entry/exit), and set the special effects (risk). All that’s left is the performance. If you freeze up on cue, the whole scene collapses.  

- **If the trade is a loser** – No amount of heroic acting will turn a loss into a win; you’ve already accepted the loss in your stop‑loss.  
- **If the trade is a winner** – This is where the drama peaks. A tiny hesitation, a second‑guess, a “maybe I should wait for a better price,” can evaporate the upside you painstakingly planned.  

From a pure statistics standpoint, each trade is a data point. Your edge is the *probability* that you’ll win **more** than you lose over a large sample. Skipping a winning trade because you let emotions “foul up” the plan is like tossing a coin and deciding not to count heads because you felt lucky when tails showed up. Over hundreds of flips, that missing head hurts your win‑rate.  

**Bottom line:** The best‑laid plans are only as good as the execution. If you carve out a razor‑sharp, unambiguous plan and then laser‑focus on carrying it out—no second‑guessing, no emotional detours—you’ll stack up profits over time, just like a disciplined athlete racks up medals.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/03/20070201-300x300.png)  

In short, treat your trading plan like a well‑rehearsed punchline: know the setup, deliver the line with confidence, and let the audience (the market) react. If you’re jittery, you’ll stumble over the words; if you’re steady, the joke lands and the profit rolls in. Keep the plan tight, the focus tighter, and watch those “best‑laid” schemes turn into real‑world gains. Cheers to trading like a calm, slightly sarcastic samurai!