# 119. Buy on Weakness, Sell on Strength: An Example of a Contrary Approach  

**Source:** https://zerodha.com/varsity/chapter/buy-on-weakness-sell-on-strength-an-example-of-a-contrary-approach/

---

Lots of “investment‑psychology” books love to hand you a superhero cape and shout, *“Be a lone wolf! Don’t follow the herd! Be a contrarian!”*  It’s a neat idea, but abstract—like telling someone to “think outside the box” without ever showing the box.  
So, let’s pull that lofty mantra down from the clouds, drop it into a glass of cheap wine, and walk through a **real‑world (albeit simplified)** example.  

Why does this matter now more than ever? Back in the late‑1990s there were **more amateurs than you could count on a hand**. Those newbies created massive, easy‑to‑spot trends. A trader could simply pick a hot‑ticket stock, sit back while the crowd rushed in, and pop out with a tidy profit once the price hit the pre‑set target.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/02/20070502-300x300.png)

Ironically, in those “old‑school” days **being a copy‑cat was profitable**. When a lot of amateurs are in the game, the market tends to swing like a playground seesaw: price climbs, the media starts chanting “Bullish! Bullish!”, confidence inflates, and more and more eager buyers hop on.  
If you’re a nervous‑Nell investor, you could simply wait for that “positive news” headline or a sudden buying frenzy as your cue to jump in. That “follow‑the‑crowd” routine *sometimes* works, but it’s about as reliable as a weather forecast from a fortune‑cookie. In today’s hyper‑connected markets, it’s a **rarely‑consistent** strategy.

---

## The modern reality: “Buy low, hope a herd appears” is a pipe dream  

These days you can’t just assume that after you “buy low” a legion of naïve, wide‑eyed amateurs will swoop in and push the price sky‑high.  
If you sit on the sidelines too long, you’ll likely hit a **resistance level**—the price ceiling where sellers outnumber buyers—and the opportunity evaporates faster than a cheap beer at a frat party.  

The market now feels more like a **tightrope walk in a fog**. You have to:

1. **Identify the current phase** (are we in a rally, a slump, or a sideways lull?).  
2. **Anticipate the next move** (will the next wave be up or down?).  
3. **Enter and exit at optimal moments** (not too early, not too late).  

All of this demands **instincts, perception, and a dash of gut feeling**—the very ingredients that make a contrarian approach necessary.  

---

## Contrarian isn’t just “do the opposite of the crowd”  

Being a contrarian is **more than a mirror image** of the herd’s actions. It’s about flipping the whole *thought process* on its head.  

Most traders have a **“obvious‑only” radar**. They see a stock trending upward, think, “Buy it, hold, sell higher, repeat.” That works fine when **there’s an army of buyers** to keep the price climbing—something that was more common back in the 90s.  

In today’s tighter‑rope environment, **resistance shows up quicker**. You might find a stock that looks like a rocket, but the moment you hop on, a wall of sellers slams it back down. So you need to **anticipate that turning point** and get out *before* the price does a nosedive.  

That’s where the “reverse‑thinking” mindset shines. Instead of:

- **Buying when everyone else is buying**  
- **Selling when everyone else is selling**  

…you do the opposite:

- **Buy when everyone else is selling** (i.e., when the market looks weak).  
- **Sell when everyone else is buying** (i.e., when the market looks strong).  

In plain English: **Buy on weakness, sell on strength**.  

---

## A toy example – because everybody loves a good story  

Imagine, just for illustration, that market cycles behave like a **predictable sitcom**:  

- **Monday:** Prices dip (the “Monday blues”).  
- **Tuesday:** Prices climb (the “Tuesday boost”).  
- **Wednesday:** Prices dip again (the “Wednesday slump”).  

If history *actually* repeated this exact script—*spoiler alert*: it never does—you could simply **buy on Monday’s low, hold through Tuesday, and sell at Tuesday’s high**. Easy peasy, right?  

Now, if the market were that obedient, you wouldn’t need any rugged individualist swagger, any contrarian mindset, or even a sliver of intuition. You’d just program a robot to execute the script and sip margaritas while it makes you money.  

But—*and this is the crucial “but”*—the markets are **capricious, chaotic, and occasionally moody**. “History repeats itself” only when it feels like it; most of the time it writes its own script. That uncertainty is what makes trading a **real challenge** (and also what makes it fun).  

You never know **when the cycle will repeat**, or if it will at all. All you have are **probabilities** and **odds**, not guarantees. Waiting for the herd to give you a crystal‑clear sign is like waiting for your friend to text back after a night out—sometimes they do, sometimes they ghost you.  

---

## Why the rugged individualist mindset still matters  

Since **future prices are inherently uncertain**, you need to rely on **your own (imperfect) strategies and intuition**. The market won’t hand you a “sure thing” on a silver platter.  

Being a **rugged individualist** means:

- **You trust yourself more than the crowd**.  
- **You’re comfortable taking calculated risks**—think of it as betting on your favorite sports team when everyone else is cheering for the underdog.  
- **You hone your gut feeling through experience**, like a bartender who knows exactly when to pull the tap on a perfect draft.  

In essence, trading is **making an educated guess, taking a chance, and waiting to see if the universe rewards you**. If you’re constantly looking for group validation, you’ll end up **chasing a moving target** in a market that’s far too complex for “follow‑the‑crowd” shortcuts.  

So, **nurture those individualist instincts**. Build intuition by **studying charts, replaying past trades, and learning from both wins and epic fails**. And, most importantly, **look at the market from multiple angles—especially the contrary ones**.  

When you do that, you’ll find that buying on weakness and selling on strength isn’t just a catchy headline; it’s a **practical, albeit nuanced, way to tilt the odds in your favor**—all while keeping the bar‑room banter alive. Cheers to being the lone wolf who knows when to howl and when to stay quiet! 🍻