# 273. Combating Ego Shock  

**Source:** https://zerodha.com/varsity/chapter/combating-ego-shock/  

---  

Sam’s been eye‑balling his trade like a hawk for the past seven days. He popped in at **$50**, penciled a tidy **$52** target, and watched the chart behave like a well‑trained puppy. “I’m basically a market wizard,” he thought, while sipping his third espresso of the week. He’d spent a whole month polishing the setup, and his ego was practically doing push‑ups in anticipation of the payoff.  

Then—*boom!*—a handful of heavyweight stocks missed the analysts’ crystal‑ball forecasts, the whole sector took a nosedive, and the price slumped to **$49**. Sam’s heart sank faster than a lead balloon. Not only did his bank balance get a tiny bruise, his pride took a full‑blown karate chop. He stared at the screen, wondering whether his trading career should be filed under “great ideas that never made it to the finish line.”  

In the world of markets you can’t stay down forever; you’ve got to dust yourself off, re‑tighten that tie, and remember that losses are just part of the job description.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/05/20060131-300x300.png)  

### How you react to losses is a matter of perspective  

Do you treat a loss like a personal affront—*“They’ve insulted my very soul!”*—or do you see it as a routine pothole on the highway to profitability? Psychologists led by Dr. Keith Campbell found that when something threatens our self‑esteem, we experience what they dubbed **“ego shock.”** (Campbell, Baumeister, Dhavale, & Tice, 2003). Think of it as the market’s way of pulling the rug out from under you, leaving you momentarily stuck in a state of “what‑the‑heck‑just‑happened?” The bigger the threat, the more spectacular the shock.  

For traders, ego shock hits when a loss is both **big** and **unexpected**. Right when you need to make a cool‑headed decision, you’re left feeling like a deer in headlights—paralyzed, jittery, and probably muttering a few choice expletives under your breath. While it’s perfectly human to feel stunned by a major setback, the *winning* trader learns to keep their cool and act anyway.  

### What to do when your ego gets a concussion  

1. **Name the beast** – Admit that a massive hit to your self‑image will almost certainly produce a shock response. Once you put a label on it (“Hey, that’s just ego shock, not the end of the world”), you can start plotting a workaround.  

2. **Trim the threat** – The magnitude of your shock is directly proportional to the size of the risk you’re taking. Reduce your position size, and you’ll shrink the “ego‑damage” potential. Yes, you’ll also cap your upside a bit, but you’ll gain a lot more mental bandwidth to stay rational when things go south. Think of it as swapping a heavyweight champion for a well‑conditioned middle‑weight—still a contender, but less likely to knock you out.  

3. **Expect the unexpected** – Give yourself a mental heads‑up that markets are as fickle as a cat on a hot tin roof. If you *anticipate* that a trade could swing against you, the eventual loss feels less like a betrayal and more like a scheduled maintenance stop. It may feel a little uncomfortable to rehearse worst‑case scenarios, but that rehearsal softens the blow when reality finally shows up.  

### Bottom line  

Losses are as inevitable as the sunrise for anyone who dares to trade. They don’t have to be the hammer that shatters your confidence. By (a) recognizing that ego shock is a real, neuro‑psychological reaction, (b) scaling back the size of the bets that could deliver a massive ego bruise, and (c) mentally pre‑programming yourself to expect hiccups, you keep your cool even when the market decides to throw a tantrum.  

In short: **don’t let your ego get a concussion; give it a good night’s sleep, a healthy dose of perspective, and a smaller position size.** Then you’ll be ready to bounce back, smile at the next chart, and maybe even enjoy the ride. Cheers to staying zen while the market does its drama!  