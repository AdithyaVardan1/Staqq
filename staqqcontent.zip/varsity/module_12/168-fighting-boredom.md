# 168. Fighting Boredom  

**Source:** https://zerodha.com/varsity/chapter/fighting-boredom/

---  

These days you’ll hear more traders brag about “catching the swing” than “scalping the last tick.”  The high‑frequency scalp‑and‑run game is getting squeezed tighter than a cheap pair of jeans after Thanksgiving, so most folks have migrated to swing‑trading.  Swing trading, however, can feel a bit like watching paint dry—if that paint were a *very* expensive, very volatile paint.  

Depending on how fat your bankroll is, you can’t just throw a bazillion swing trades at the market and hope risk magically disappears.  Capital limits mean you’ll usually end up with a handful of positions, each of which you have to sit on for a few days (or sometimes weeks) before you can even think about tweaking anything.  As long as your setup isn’t a total dumpster fire, you’ll spend a good chunk of time just **waiting** to see what the market decides to do.  In other words, you either execute a trade (or a couple of trades) and then enter the “patient‑trader” zone—aka the waiting room of the trading world.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/03/20070112-300x300.png)  

A scalper, by contrast, wants to be in and out faster than you can say “latency.”  The idea of sitting still feels about as pleasant as watching a hamster run on a wheel forever.  The itch to do something—anything—while your swing trade chills in the market can be agonizing.  It’s the classic “I’ve got a trade, but I’m bored” dilemma.  If you don’t have a boredom‑busting game plan, you’ll probably start hunting for excitement elsewhere, and that often ends in an impulsive trade that throws your carefully‑crafted plan out the window.  

---

## When Your Inner Daredevil Gets Bored  

Some people are born with a “risk‑addiction” gene.  They get bored faster than a cat with a new laser pointer.  For them, a swing trade can feel like a Sunday stroll through a museum—nice, but not exactly a roller‑coaster.  The temptation to close a position early because you “just can’t wait” is real, and it’s a trap that can shred your profit potential.  

If you recognize yourself in that description, consider these work‑arounds:

1. **Stop‑loss your way to peace of mind** – Pop a sensible stop‑loss on the trade, then **pretend the trade is on autopilot**.  Once the safety net is in place, you can walk away without feeling guilty.  
2. **Limit the number of simultaneous swings** – Unless you have a massive account that can comfortably hold a dozen or more positions while still risking, say, 1‑2 % of equity per trade, keep the list short.  Fewer positions = less screen‑time = less boredom.  

When the stop‑loss is locked in, you can actually *walk away*—no guilt, no second‑guessing, just a moment of freedom.  

---

## The Slot‑Machine Syndrome  

If you keep glancing at the chart like you’re watching a slot machine waiting for the jackpot, you’re basically dangling a piece of candy in front of a toddler.  The brain’s “I want more” circuitry lights up, and you end up fighting an internal tug‑of‑war between discipline and instant gratification.  

**Solution:** Put the screen down and pick up a completely unrelated activity.  Here are a few ideas that have worked for seasoned swing‑traders:

- **Side‑hustle time** – Open a part‑time gig (deliver pizzas, freelance graphic design, whatever).  The extra cash can even *fund* a larger stop‑loss cushion for your next swing.  
- **Skill‑building** – Read a trading book, binge a finance podcast, or develop a brand‑new strategy on paper.  The brain loves learning, and you’ll come back to the market sharper.  
- **Household chores** – Vacuuming, laundry, fixing that leaky faucet.  Nothing screams “I’m a responsible adult” like a clean kitchen while your position does its thing.  

For some people, even indirect trading temptations (like constantly checking the “watchlist”) are enough to pull them back.  If that’s you, consider a **full‑on digital detox**: uninstall the trading app for a day or two, and give your mind a breather.  

---

## Boredom Is Not a Minor Inconvenience  

Boredom isn’t just a mild annoyance; it’s a signal that your brain is starving for stimulation.  When you keep trading while bored, you’re essentially feeding that hunger with low‑probability, high‑noise trades.  The math is simple: more junk trades → lower expectancy → long‑run losses.  

Think of it like this: If you have $10,000 tied up in three well‑chosen swing positions, you’re already *invested* in the market’s outcome.  Adding a fourth “just‑because‑I’m‑bored” trade is like sprinkling pepper on an already perfect pizza—doesn’t make it better, just messes up the flavor.  

So, **stay put**.  Let the original trades run their course.  Meanwhile, do something that genuinely excites you: play with the kids, binge‑watch a sitcom, or finally finish that jigsaw puzzle you’ve been ignoring.  The point is to give your brain the dopamine hit it craves without compromising your capital.  

---

## Practical Tips to Keep Boredom at Bay  

| Boredom Trigger | What To Do Instead | Why It Works |
|-----------------|-------------------|--------------|
| **Staring at charts** | Set a timer for “check‑in” only (e.g., once every 24 h) | Reduces compulsive checking, lowers anxiety |
| **Feeling “idle”** | Schedule a non‑trading activity (gym, cooking class) | Gives you a sense of accomplishment outside the market |
| **Impulse to add a trade** | Write down the trade idea, then wait 48 h before acting | The “cool‑off” period filters out low‑quality setups |
| **Screen fatigue** | Use a “do‑not‑disturb” mode on your phone & computer | Physical distance reinforces mental distance |

---

## Bottom Line: Let the Market Do Its Thing While You Do Anything Else  

The beauty of swing trading is that you **don’t have to be glued to the screen 24/7**.  Once you’ve set up a solid trade with a sensible stop‑loss, the rest of the day (or week) is yours to live your life.  Treat your swing trades like a slow‑cooking stew—let them simmer, and you’ll get a richer flavor later.  

So, the next time boredom starts tapping on your shoulder, remember:

1. **Don’t chase excitement with bad trades** – Your edge is in quality, not quantity.  
2. **Use automatic orders** – Stops, targets, trailing stops = “set it and forget it.”  
3. **Fill the downtime with life** – Family, hobbies, side‑jobs, or simply a good nap.  

When you master this balance, you’ll find that swing trading isn’t a prison; it’s a **flexible income engine** that lets you enjoy the things that truly matter while your capital does the heavy lifting.  

Stay patient, stay disciplined, and let boredom be the *signal* that you’ve got a solid plan—rather than a reason to throw darts at the chart. Happy swinging!  