# 151. When You Fall Off the Horse  

**Source:** <https://zerodha.com/varsity/chapter/when-you-fall-off-the-horse/>

---

## The “Try‑Again‑And‑Again” Mantra (and Why It’s Not Always a Gold‑Star Idea)

Picture this: you’re trying to impress a date, you spill coffee, you laugh it off, and you think, “Just keep going, I’ll get it right next time!”  In the trading world that mindset sometimes works, sometimes it lands you flat on your face.  

Back in the day, a bunch of clever psychologists cooked up something called the **inverted‑U theory of stress and performance**. Think of it as a roller‑coaster shaped like the letter “U” (but upside‑down, because why not?). The key takeaway? **The harder the task, the less a little bit of stress helps you.**  

- **Easy task** (e.g., remembering your Netflix password): a sprinkle of adrenaline can actually sharpen you up.  
- **Hard task** (e.g., figuring out why your favorite stock just tanked 15% after a “good” earnings report): even a whisper of stress can turn you into a nervous wreck, spawning frustration, anger, or full‑blown despair.  

And let’s be brutally honest—**trading is hard**. It’s the kind of hard that makes you wish you’d taken up pottery instead.

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/03/20060720-300x300.png)

---

## Trading Is a Mental Gym—And You’re Not a Robot (Yet)

When you first dip your toes into the market, you need to bring every ounce of mental horsepower you own. It’s a lot like learning to drive a stick‑shift car for the first time while your aunt keeps shouting “Don’t forget to check your blind spot!”  

- **Early days:** You’re glued to the screen, calculating stop‑losses, counting pips, and wondering if you should have taken that night class on “Candlestick Patterns for Dummies.”  
- **After the grind:** With enough repetitions, you’ll start to steer almost on autopilot, just like you can now parallel‑park without breaking a sweat.  

If the job is *easy*, you can safely keep grinding. You won’t feel exhausted, and persistence will eventually turn you into a competent trader (or at least stop you from blowing every cent on a single trade).  

But here’s the kicker: **most newbies think “just keep trying” works for everything**. Trading isn’t a simple “practice makes perfect” scenario; it’s a psychological battle that demands you juggle complex data, fine‑tune your gut, and risk both your money **and** your ego.  

When the market slams you with a loss, the smartest move is often to **step away, breathe, and come back when you’re refreshed**—kind of like taking a coffee break after a particularly nasty meeting.

---

## Everyone’s Stress Tolerance Is Different (Even If You Pretend It’s Not)

Some folks can swallow loss after loss like a champion pizza‑eater at a contest. Why? Maybe they have deep pockets, or perhaps they’ve been hardened by a career that thrives on rejection—think of a cold‑call salesperson who dials 100 numbers to close a single deal.  

**Know thyself.** Your psychological makeup is the secret sauce that determines how many bruises you can take before you start seeing red.  

A common rookie myth is:  

> “Real traders are glued to their screens 24/7. They never quit, no matter what.”  

This macho “I‑won’t‑stop‑even‑if‑I’m‑bleeding‑money” attitude is a fast‑track ticket to the *break‑down* lane.  

---

## The High‑Standard Trap (And How It Turns Into a Psychological Drawdown)

Here’s a scene you’ve probably seen at a trader’s coffee shop: a bright-eyed newbie sets a sky‑high profit target, then watches the market dance around it like an over‑caffeinated squirrel. When the target is missed, the disappointment hits harder than a bad haircut.  

**What follows?**  

1. **Mood dip:** You start feeling stressed, cranky, and more likely to click “Buy” on the next random ticker.  
2. **Error avalanche:** Bad decisions pile up, losses snowball, and your confidence does a disappearing act.  
3. **Despair pit:** It feels like a massive psychological drawdown—your mental equity is in the red, and you can’t just “snap out of it.”  

If you spot this downward spiral early, you can take *preventive* steps (like a mental first‑aid kit) and stop a bad day from turning into a career‑changing catastrophe.

---

## How the Pros Keep Their Cool (Spoiler: They Don’t Trade When They’re Exhausted)

Seasoned traders have a habit that might look like a secret handshake: **they monitor their own moods.** When they sense fatigue, irritability, or the urge to fling their laptop out the window, they **step aside**.  

- **Why?** Because they recognize that markets are stressful by design, and they treat themselves like a high‑performance car—regular oil changes (breaks) keep the engine humming.  
- **Individual thresholds:** Some can handle a week‑long binge of chart‑watching; others need a half‑hour walk after every trade. The key is to **identify your personal limit** and honor it.  

If you ignore the warning signs and hop back on the horse while you’re still wobbling, you risk **doing more damage than a bull in a china shop**.  

---

## The Bottom Line: It’s Not About How Many Times You Get Knocked Down, It’s About How You Get Back Up (And Maybe Grab a Snack First)

To trade well, you must accept that setbacks are as inevitable as taxes. But you **don’t have to let those setbacks own you**.  

- **Pretending to be invincible?** Bad idea. It’s like walking into a bar and shouting “I never lose!”—you’ll just get a swift reminder from the bartender (or the market).  
- **Taking a break, recharging, and rebuilding your psychological bankroll?** That’s the smart play. After a proper reset, you’ll be ready to ride the market like a champion jockey, with confidence, clarity, and maybe a dash of swagger.  

So next time you tumble off the horse, remember: **pause, breathe, maybe sip a cold brew, and then get back in the saddle when you’re truly ready**. The market will still be there—just a little less intimidating when you’re mentally fit to ride it. 🚀