# 245. Don’t Take It Personally  

**Source:** https://zerodha.com/varsity/chapter/dont-take-it-personally/  

---  

Seasoned traders are the Zen masters of the market – they stare at candlesticks the way a monk stares at a candle, cool, detached, and never blinking at the next flicker.  
Rookie traders, on the other hand, tend to treat every loss like a personal insult from the universe. “My trade went south? That’s a slap to my ego!” they mutter, as if the market just wrote a snarky comment on their Facebook wall. The truth is: losses are as inevitable as traffic on a Monday morning, and you **must not** take them personally.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/04/20061031-300x300.png)  

### Why a Drawdown Feels Like a Bad Break‑up  

Let’s be real: watching your account take a nose‑digging dive is soul‑crushing. You’ve just watched a decent chunk of cash evaporate, and even if you bounce back to profitability, the math tells you it’ll take a while to rebuild the capital you once had. Feeling a tad disappointed is **completely normal** – it’s the human version of a sore throat after shouting “I’m the king of the world!” on a roller coaster.  

But here’s the kicker: **don’t let that disappointment hijack your self‑worth.** Your value isn’t measured by a single trade or a single day’s P&L. It’s measured by the whole *process* you follow, the discipline you keep, and the edges you shave off your strategy over months (or years).  

### Disappointment: The Bad‑Boy Motivator  

Surprise, surprise – disappointment can actually be useful. Think of it as the market’s way of tapping you on the shoulder and saying, “Hey, maybe you should hit the books.” If you’re not performing, that sting is a polite nudge to level‑up your skills, tighten your risk‑rules, and turn those “oops” moments into “aha!” moments.  

That said, there’s a thin line between *productive* disappointment and *paralyzing* self‑pity. Trading is an *unnatural* sport; it asks you to **control** emotions that would otherwise have you screaming at the screen like a toddler denied a cookie. The more you can stay objective, the fewer you’ll waste brain‑fuel on ego‑driven drama.  

### How Do You Tame the Beast?  

Ask yourself: what does *consistent* trading actually mean? At its core, it’s simply riding a **strategy that has a positive expectancy**. Sometimes you discover that edge by grinding data, sometimes you stumble upon it by sheer luck (or by copying the guy who made a fortune on the “Golden Cross”). In the end, it’s all about **odds**.  

Picture a six‑sided die. Roll it a thousand times, and you’ll see each face show up roughly 166‑167 times. Flip a fair coin a hundred times, and you’ll probably get about 50 heads, give or take a few. Now, toss that same coin ten times and you might get 8 heads, 2 tails – a short‑run streak that looks *unfair* but is perfectly normal.  

Trading works the same way. Even a **winning system** will endure a string of losers because probability loves to be a little mischievous in the short run. The chance of getting 50 heads in a row is \((1/2)^{50}\) ≈ 8.9 × 10⁻¹⁶ – astronomically tiny, but *possible*. So why make every loss a personal affront? Why let your ego ride shotgun on every trade, cheering when luck smiles and sulking when it frowns?  

### Un‑learning the “It’s All About Me” Mantra  

In most jobs, effort equals payoff. You put in the hours, deliver the product, and your boss (or client) hands you a raise or a pat on the back. It’s a neat, causal chain, and it’s perfectly natural to feel proud of it.  

Trading, however, throws a curveball: **the odds can bite you even when you’ve worked your butt off.** Imagine you spend months perfecting a strategy, only to get whacked by a market‑wide shock that temporarily flips the odds against you. Your skill set is still solid, but the *random* component of the market has taken a brief vacation from your side.  

That realization can sting because it *steals* a bit of the glory. “Hey, I’m a great trader!” suddenly sounds a little less like a badge of honor and more like “I got lucky… this time.” Yet, embracing that randomness is exactly what helps you **sleep** after a nasty drawdown.  

If you truly understand the mechanics of your edge, you can trust that **the odds will eventually swing back** in your favor—provided you stay disciplined, keep your position sizes modest, and don’t start betting the house on a single “I’m due for a win” feeling.  

### The Bottom Line: Detach, Don’t Disappear  

Taking a detached, almost Zen‑like approach might feel like you’re draining the fun out of the game. Sure, you won’t be doing victory dances every time a trade hits the green, but you’ll also avoid the “cry‑in‑the‑corner” routine after a loss. Detachment gives you three priceless benefits:  

1. **Cold‑blooded risk management** – you’ll size your trades based on volatility and drawdown tolerance, not on how much you *need* a win today.  
2. **Process over outcome** – you’ll focus on reading charts, refining rules, and sticking to the plan, rather than obsessing over the profit‑and‑loss line.  
3. **Emotional resilience** – when the market throws a curveball, you’ll be the one calmly sipping your coffee, while everyone else is shouting at the screen.  

So, next time a trade bites you, remember: the market isn’t targeting your ego; it’s just playing the odds. Treat it like a poker game with a friend who never folds – sometimes you win, sometimes you lose, and the best players are the ones who keep their poker face on, no matter how many chips are on the table. Cheers to staying cool, calm, and *profitably* detached!  