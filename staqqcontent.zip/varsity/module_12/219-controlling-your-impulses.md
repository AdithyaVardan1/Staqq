# 219. Controlling Your Impulses  

**Source:** https://zerodha.com/varsity/chapter/controlling-your-impulses-2/

---

When your hard‑earned cash is staring you straight in the face, staying cool, rational, and *totally* in control feels about as easy as keeping a cat off a keyboard. What if the trade tanks? How the heck do you bounce back? It’s only natural for a wave of self‑doubt to hit you harder than a Monday‑morning inbox, for you to toss your trading plan out the window, or to start acting like a squirrel on espresso during a market‑mayhem frenzy.  

But here’s the kicker: the winners—those traders who actually make money—learn to **tame their impulses**. They follow their strategy with the smoothness of a barista pulling a perfect espresso shot, even when the market is throwing tantrums like a toddler denied candy. The secret sauce is discipline. Discipline is the backbone of every profitable trader, yet not everyone can keep that backbone straight without cracking. First, you’ve got to figure out where you sit on the discipline‑scale. If you’re a self‑control rookie, you’ll need to train that muscle (yes, it’s a muscle—no, you can’t skip leg day).  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/04/20061219-300x300.png)

Some folks are the **over‑achieving monks of self‑control**. They pay off credit‑card bills before the due date, never miss a dentist appointment, and have a spreadsheet for everything from grocery runs to how many times they blink per hour. On paper, they look like the perfect candidates for trading greatness.  

*But* there’s a hidden trap: **over‑discipline** can turn you into a risk‑averse robot that prefers a guaranteed 2% return from a savings account over a 20% market swing. Trading, however, is not a “sure thing” carnival game; it’s more like a high‑stakes poker table where you have to bluff a little and sometimes go all‑in on a gut feeling.  

The savvy trader knows it’s okay to dip a toe on the wild side—just not a full‑blown cannonball into the abyss. He or she doesn’t chase reckless risk for the thrill of it, but they also don’t shiver at the thought of volatility. Bottom line: **every trader wrestles with discipline**, whether it’s too little or too much. Whether discipline flows through your veins like caffeine or you have to hustle for it like a late‑night pizza delivery, you *must* trade with some level of disciplined rigor.  

So, grab a mirror (or just think of your most recent missed appointment) and ask yourself:  

- **How disciplined am I really?**  
- **Do I bail on my trading plan the way I bail on my gym routine?**  
- **Do I wish I had the self‑control of a monk or a Navy SEAL when it comes to positions?**  
- **How’s my everyday life?** Am I constantly late, blowing my budget, or breaking promises like a kid on a sugar rush?  

A trader who’s on time for brunch but constantly breaks financial promises is still walking a shaky line. Discipline in life doesn’t have to be *perfect* across the board, but the more you practice it, the easier it gets to copy‑paste that behavior into your trading desk.  

Your day‑to‑day habits are the **sneaky little ninjas** that either help or hinder your trading mojo. If you’re the type who overspends on take‑out, binge‑eats Netflix marathons, or chases every shiny new gadget, you’ll probably find it harder to stick to a stop‑loss or wait for that sweet entry signal. Don’t panic, though—​even the most undisciplined couch‑potato can become a disciplined trader. It just takes **time, repetition, and a willingness to admit you’re a mess sometimes**.  

Markets are chaotic, unpredictable, and occasionally as friendly as a porcupine in a hug‑factory. It’s perfectly normal to feel jittery, like you just stepped on a LEGO in the dark. After you hit the “execute” button, the next few minutes feel like a roulette wheel spun by a drunken pirate—stressful, right? The antidote? **Structure**.  

If you craft a **detailed trading plan**, you’re essentially putting a fence around that wild beast called “market randomness.” By spelling out a clear profit target, entry criteria, and exit rules, you give your brain a cheat‑sheet, reducing the “what‑the‑heck‑now?” factor. The more concrete the plan, the less you’ll feel like you’re navigating a foggy night in a broken‑GPS car. You’ll know exactly what to do, when to do it, and—most importantly—*why* you’re doing it.  

Think of discipline as a **muscle** (yes, that metaphor again, because it works). Like any bicep, it needs progressive overload. Psychological stamina isn’t infinite; it’s like your phone battery—once it hits 5 %, everything starts lagging. When you’re exhausted, your brain’s “impulse‑control” app crashes, and you’re more likely to chase that next “big win” or panic‑sell.  

**Solution:** stock up on psychological energy. That means **sleep, rest, and a bit of mental downtime**. If you’re running on three hours of shut‑eye, you’ll trade like a zombie on a sugar rush—mistakes galore. Proper rest fuels focus, keeps pessimism at bay, and gives you the mental bandwidth to stay disciplined even when the market throws a tantrum.  

Let’s be real: **most traders struggle with discipline**. The “trade‑by‑the‑seat‑of‑your‑pants” approach looks tempting, especially when you see a hot tip on a meme forum and think, “What could go wrong?” Spoiler: a lot. The **winning trader is the disciplined trader**—the one who refuses to let emotions hijack the dashboard. By actively building self‑control (think: daily journaling, habit‑stacking, and occasional meditation), you raise your odds of ending the day with a smile *and* a healthier account balance.  

So, grab that discipline‑muscle, feed it with rest, wrap your trading strategy in a sturdy plan, and remember: **impulse control isn’t a one‑time thing; it’s a daily habit, like brushing your teeth—only more profitable**. Cheers to trading like a calm, collected, and slightly sarcastic friend at the bar! 🍻