# 3. Accepting Criticism  

**Source:** https://zerodha.com/varsity/chapter/accepting-criticism/  

---  

Novice traders have a reputation for treating “being right” like it’s the last slice of pizza at a party—if they don’t get it, the whole night is ruined. That ego‑fuelled need is so strong that many fresh‑face traders start pulling all‑sorts of weird stunts just to keep the “I‑was‑right” flag flying.  
- **Holding on to losers** – instead of cutting a bleeding trade, they cling to it like a bad Tinder date, hoping the loss will magically turn into a “paper profit” (spoiler: it won’t).  
- **Procrastinating on the next entry** – they sit on the sidelines, scrolling memes, because the thought of another “maybe‑I‑screwed‑up” idea feels like staring at a dentist’s drill.  

All this right‑or‑else‑I‑lose‑my‑mind behavior ends up shackling creativity. When a trader’s brain is busy playing “don’t‑be‑wrong‑tetris,” the real game—making repeatable, disciplined trades—never gets a chance to start. And without that practice‑by‑practice grind, you’ll never graduate from “market‑magician‑in‑training” to “profit‑producing‑pro.” Bottom line: swallowing a healthy dose of feedback and criticism is the secret sauce for any trader who wants to stop flailing and start thriving.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2019/11/20041005.png)  

### Why does criticism feel like a punch in the gut?  

Because we’ve wired ourselves to treat any negative comment as if it were a report card from kindergarten—*“You drew a stick figure, Timmy, not a masterpiece!”* In the trading world, that “stick‑figure” is a losing trade, and the “teacher” could be a broker, a mentor, or the cold, unforgiving market itself.  
- **Emotional over‑inflation:** A single snarky remark can balloon into a full‑blown identity crisis. We start believing the market is judging our moral character, not just the price action.  
- **The “moral” myth:** It’s easy to imagine a hidden jury of parents and professors shouting, “You’re a failure!” when a trade sputters, even though the market is really just saying, “Hey, that price moved the other way.”  

If you can strip away the drama and look at criticism the way you’d glance at a spreadsheet—cold, hard data with no smiley‑face emojis—you’ll find a treasure trove of information instead of a personal attack. Think of it as the market’s way of texting you, “Yo, you missed the bus; maybe try the next one.”  

### The perfection‑complex: why we can’t stand a single mistake  

Another big, stubborn roadblock is our irrational love affair with perfection. We’ve been schooled to believe that a single slip‑up equals a permanent scar on our résumé. Remember those school days when you got **one** shot at a term paper, and if you flubbed it, the grade was set in stone? No retakes, no “let’s try that again” button.  
- **One‑chance‑only mindset:** In school, a bad test meant a bad grade for the whole semester. That pressure teaches us to equate *any* error with *total* failure.  
- **Trading doesn’t work that way:** Here, you can take a “practice” trade, learn from the loss, and instantly place a new one. It’s like playing a video game on “lives” mode—you die, you respawn, you get better. As long as you size your position so the loss is manageable (think $50‑$100 on a $10,000 account, not a whole‑life‑savings wipe‑out), you’re basically paying a tuition fee for the school of market‑life.  

So, if you’re terrified of making a mistake, just remember: the market loves to teach. Every loss is a free lesson, and you’re only paying with the amount you *can* afford to lose. No need to clutch your pearls over a tiny stumble.  

### Embrace the sting—seek criticism like a bar‑hop for free drinks  

There’s absolutely no upside to hiding from feedback. In fact, the more you chase it, the sharper your trading instincts become. Here are a few low‑cost (sometimes free) ways to get your daily dose of critique:  
1. **Trade, observe, repeat:** Put your capital on the line, watch the outcome, and let the results speak louder than your ego.  
2. **Hire a coach or join a community:** Think of a trading mentor as the bartender who tells you when your cocktail is too salty. Their honest take can save you from a pricey hangover later.  
3. **Self‑review:** After market close, pull up your trade journal and ask, “What did the market just tell me?” Write down the lesson, thank the market for its brutal honesty, and move on.  

The more data points you collect about your own behavior, the easier it becomes to spot patterns—both good and bad. And as you start welcoming criticism (instead of treating it like a surprise dentist bill), you’ll notice your decision‑making gets smoother, your risk‑management tighter, and your profit‑curve less jittery.  

So, go ahead: ask for the hard truths, admit your limits, and let the market’s feedback loop become your personal trainer. Before you know it, you’ll be trading with the confidence of someone who’s already survived a few bruises and knows exactly how to patch them up—profitable, skillful, and maybe even a little smug (in the best, non‑arrogant way). Cheers to getting roasted and coming out roasted‑chicken‑perfect!  