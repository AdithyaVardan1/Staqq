# 34. Free and Easy Trading  

**Source:** https://zerodha.com/varsity/chapter/free-and-easy-trading/  

---  

Ever notice how you breeze through a mountain of tiny choices every single day without breaking a sweat? You drop the kids at school, then you’re suddenly the **Grandmaster of Route‑Selection**: left turn, right turn, “take the scenic route because I’m craving a coffee,” or “pull over for gas before the tank screams.” Later, you swing by the grocery store, stare at the cereal aisle, and decide whether to splurge on the artisanal oat‑milk or stick with the budget brand. Do you spend hours mulling over those decisions? Nope. You just roll with them because the stakes are, well… pretty low.  

Now, imagine someone who treats each of those mundane choices like they’re auditioning for *Survivor*. That’s the world of obsessive‑compulsive disorder (OCD). For folks with OCD, even the tiniest decision can feel like a life‑or‑death showdown. Thank goodness you’re not stuck in that loop—unless, of course, you’re a brand‑new trader who finds picking a stop‑loss as terrifying as choosing a Netflix series for a 3‑hour binge.  

Here’s the kicker: seasoned traders often look at you and think you might have a *trading‑specific* form of OCD. You bail on a position because you’re impatient, you second‑guess every candle, and you’re convinced the market is out to get you. The veterans, on the other hand, treat each trade the way you treat that coffee stop‑off: “Just another decision, nothing to write home about.” They’ve cultivated a **free‑and‑easy** style that makes even a volatile market feel like a Sunday stroll. Wouldn’t it be nice to trade with that same chill vibe?  

![Image](https://zerodha.com/varsity/wp-content/uploads/2019/12/20050324.png)  

---

## Why We Over‑Drama Trading Decisions  

Let’s get real: when your hard‑earned cash is on the line, it’s natural to feel a little jittery. You start treating every tick like a personal insult and every rally like a personal victory. Some traders even anthropomorphize the market, assigning it the same emotional weight they give to their relationships. Mark Douglas, the author of *Trading In the Zone*, likens this to a kid who believes a parent’s scolding is punishment for breaking a rule—only the “parent” is the market, and the “rule” is “don’t lose money.”  

When you see a losing trade as a personal failure, you’re basically letting the market **talk to you like a disapproving mother**. That makes every loss feel monumental, and every win feels like a rare birthday cake. Spoiler alert: that drama doesn’t help your bankroll; it only makes you sweat more than a marathon runner in a sauna.  

---

## The Chill‑Pill Approach: Detach, Diversify, and Manage Risk  

### 1. Zoom Out, Don’t Micromanage One Trade  

First rule of the free‑and‑easy club: **stop obsessing over any single trade’s outcome**. Think of each trade as a grain of rice in a massive bowl of biryani. One grain might be burnt, but the whole dish can still be delicious. If your strategy has a high probability of success—say, a win rate of 55‑60% with a decent risk‑reward ratio—then a few losing trades won’t sink the ship.  

Veteran traders plan for **lots of trades**, not a handful of “big‑ticket” ones. They know the law of large numbers is their best friend: over many repetitions, the edge shows up. In other words, you don’t need every trade to be a winner; you just need the **aggregate** to be positive. That mental shift alone takes a huge chunk of pressure off your shoulders.  

### 2. Risk Only What You Can Afford to Lose (And Then Some)  

Second rule: **risk a tiny slice of your capital on each play**. Most pros stick to 1‑2 % of their total trading account per position. Why? Because if you lose that trade, you’ve only shaved a sliver off your bankroll—not a whole slice of pizza. This tiny‑risk mindset does two things:  

* It **keeps emotions in check**—losing 1 % feels a lot less catastrophic than losing 20 %.  
* It **forces you to be selective**, because you’ll only take trades that meet your edge criteria.  

When you know the worst‑case scenario is a modest dip, the trade stops looking like a life‑changing event and more like a routine pit stop.  

---

## Bottom Line: Trade Like It’s a Casual Friday  

There’s absolutely no need to turn every trade into a Shakespearean tragedy. By **capping your risk per trade** and **focusing on the long‑run edge**, you shrink the personal significance of each individual decision. In the grand scheme, you’re just another commuter on the highway of the markets—making lane changes, adjusting speed, and occasionally stopping for coffee.  

So the next time you’re staring at a chart, remember: **it’s just another decision, like picking a cereal**, and you’ve got the tools to handle it without breaking a sweat. Trade free, trade easy, and let the market do its thing while you sit back and enjoy the ride. Cheers to keeping it light!