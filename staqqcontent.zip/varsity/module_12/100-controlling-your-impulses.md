# 100. Controlling Your Impulses  

**Source:** <https://zerodha.com/varsity/chapter/controlling-your-impulses/>

---

## The Zen of the Winning Trader  

The traders who consistently beat the market have one secret weapon: they can **mute the inner heckler** that screams “BUY NOW!” or “SELL‑EVER‑THING!”  They sit at their desks like monks—calm, relaxed, and free from the nagging self‑doubt that makes most of us feel like we’ve just tripped over our own shoelaces.  

When they trade, it feels almost magical: the order flows out **intuitively** (as if the computer whispered the numbers to them) and **effortlessly** (no sweat, no drama). The real magic, however, is the *extreme* self‑control they wield. Instead of letting a sudden urge dictate their next move, they sit down, draft a solid trading plan, and then **stick to it like gum on a shoe**.  

If you’re the type who gets antsy at the sight of a chart, you’ll probably find this discipline a bit of a stretch. Whether you’re a naturally disciplined type or someone who needs to wrestle a hamster on a wheel before you can stay focused, the good news is: **you can train your brain**. Think of it as a financial gym—only you’ll be lifting the heavy dumbbells of patience instead of actual iron.

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/02/20070601-300x300.png)

## The Classic Impulse: Ditching the Plan  

The most common way traders betray themselves is by **abandoning the trading plan** they spent hours (or at least 15 minutes) polishing. You’ve already plotted when to jump in, when to hop out, and maybe even where to sip your coffee. The hard part? **Sticking to it when the market starts doing the cha‑cha‑cha**.  

When you first scribble that plan, it looks tidy—like a freshly made spreadsheet. But the moment you’re in the thick of a trade, the market can look like a rave party, and you start thinking, “There’s no way my plan works here; I need to bail!”  

A veteran trader might actually have the experience to **recognize a genuine breakdown** in the logic of his own plan and gracefully exit. A newbie, on the other hand, often treats the plan like a disposable napkin—crumpling it at the first sign of trouble and later lamenting, “If only I’d let it ride a little longer, I’d be sipping margaritas on a beach now.”  

**Bottom line:** The novice’s biggest battle is the urge to **close a trade prematurely**—the financial equivalent of cutting a pizza slice before the cheese even melts.

## Step 1: Know *Why* You’re Fighting the Impulse  

Before you can train your brain, you need to give it a **good reason** to stay put. In plain English: *What’s the downside of ditching the plan?*  

The answer most traders give is **profit maximisation**. A winning trade’s profit needs to **cover the losses of the losers**—think of it as paying the rent with the earnings from a few lucky tenants. A well‑defined plan is the blueprint that makes that happen.  

If you keep reminding yourself that **the big picture** (i.e., your overall P&L) looks a lot prettier when you honor your plan, you’ll find it easier to resist that little voice begging you to “just get out now.”  

**Pro tip:** Write that reminder on a sticky note, slap it on your monitor, and stare at it whenever you feel the itch to deviate. Something like:  

> “Discipline = Dollars. Stay the course, or the market will take you for a ride.”  

Seeing that every time you glance at the screen works like a tiny pep‑talk from your future, richer self.

## Emotional Landmines: Guilt, Frustration, Fear  

Sometimes the impulse isn’t just a rational calculation; it’s an **emotional grenade** that detonates at the worst possible moment. The usual suspects are:

| Emotion | How it sabotages you | Quick antidote |
|---------|---------------------|----------------|
| **Guilt** | “I shouldn’t be risking my hard‑earned cash.” | Challenge the belief: “I’m only risking money I’ve set aside for trading.” |
| **Frustration** | “Why isn’t this working? I’m wasting time!” | Pause, take a breath, and recall the original plan’s logic. |
| **Fear** | “What if the market flips and I lose everything?” | Re‑frame: “I’ve already accounted for risk; fear is just noise.” |

By **self‑monitoring**—i.e., checking in with yourself every few minutes—you’ll start to see the pattern: guilt → premature exit, frustration → chase the next setup, fear → tighten stops too much. Once you spot the pattern, you can **refute the belief** (e.g., “I’m not gambling, I’m executing a strategy”) and keep your cool.

## Building Self‑Control: It’s Like Losing Weight, But for Your Brain  

Developing self‑control isn’t a one‑night miracle; it’s a **gradual habit‑forming marathon**. Imagine you’re on a diet. You eat that extra slice of pie, feel guilty, and then you *don’t* throw the whole cake away—you just **cut back a little** next time. Same principle here.

1. **Start Small** – Pick one micro‑discipline: maybe *don’t check the news* while a trade is live.  
2. **Track the Slip‑Ups** – Keep a tiny journal: “Closed at 10 am because I felt nervous; plan said hold till 12 pm.”  
3. **Reward Progress** – When you stick to a plan for a full day, treat yourself (maybe a coffee, not a margarita).  
4. **Iterate** – Adjust the plan if you notice a systematic flaw, but *don’t* abandon it because the market got a little spicy.

It’s normal to **slip**—just as you wouldn’t quit a diet after one cheat meal. The key is to **get back on track** as quickly as possible. Over weeks and months, those tiny victories compound, and before you know it you’ll have the self‑control of a seasoned trader who can stare at a 20% dip without breaking a sweat.

---

**TL;DR:**  
- Winning traders are calm, stick to a plan, and show iron‑clad self‑control.  
- The biggest impulse trap? Dropping the plan mid‑trade.  
- Remind yourself *why* the plan matters (profits, long‑term edge).  
- Spot guilt, fear, and frustration, then neutralise them with logic.  
- Build discipline slowly, track slip‑ups, and celebrate the small wins.  

Stick to the script, keep emotions in check, and you’ll turn those impulsive urges into disciplined profits—plus you’ll finally stop explaining to your friends why you “just had to close that trade at 9:03 am.” Cheers to a calmer, richer you!