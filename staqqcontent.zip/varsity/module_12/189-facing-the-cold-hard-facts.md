# 189. Facing the Cold, Hard Facts  

**Source:** https://zerodha.com/varsity/chapter/facing-the-cold-hard-facts/  

---  

One of the biggest headaches for rookie traders is the sheer terror of actually looking at *how* they’re doing. When you’re just starting out, you haven’t yet built the toolbox that lets you profit whether the market is throwing tantrums, whispering sweet nothings, or doing a full‑blown rave. Naturally, confidence feels as elusive as a unicorn on a bull run. You keep asking yourself, “Am I riding a lucky wave, or have I actually learned something useful?”  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/03/20061227-300x300.png)  

The bottom line (and the only line that matters) is that you need to sharpen your trading chops until you have the kind of rock‑solid confidence that would make a mountain climber jealous. The secret sauce? **Monitoring your own performance** like a detective watching a suspect’s every move. In other words, stare unflinchingly at the cold, hard facts about your own ability, then tweak your game plan until you start making money consistently.  

## Why the Mirror Is Scary (But Necessary)  

Admitting that you might be a little *sh*‑t at something is never fun. Most of us would rather pretend we’re a prodigy than actually open the notebook where we logged yesterday’s loss. Ironically, our imagination often inflates the problem: we picture ourselves as the worst trader ever, even when the numbers say otherwise. The real tragedy is spending more energy **avoiding** the performance review than actually doing the work to improve.  

## Self‑Monitoring: The Not‑So‑Secret Weapon  

Enter the trade diary—your personal therapist that never judges (unless you forget to write). If the idea of opening the diary now makes you break out in a cold sweat, try this: record everything *today*, seal it in an envelope, and promise yourself you’ll read it next week when you’ve built up enough courage. On separate sheets, jot down:  

- **Market conditions** (was it a calm sea or a hurricane?)  
- **Strategy employed** (did you follow the plan or wing it?)  
- **Mood** (were you Zen or a caffeinated squirrel?)  
- **Rationale** (what made you think this was a good trade?)  
- **Outcome** (profit, loss, or “I need a new calculator”)  

Capture the data **before** and **after** the trade, then file it away. Knowing you won’t peek right away reduces the dread and lets you keep the emotional thermostat at a tolerable level. If it still feels too heavy, schedule a “review day” when you feel mentally strong enough to face the numbers.  

## Setting the Stage for a Clean Review  

When the day finally arrives to crack open that diary, treat it like a first‑date dinner: you want to be relaxed, well‑fed, and free of distractions. Pick a quiet corner, maybe a coffee shop that isn’t buzzing with indie‑rock bands, and make sure you’ve had enough sleep. If you dive in while you’re still angry, exhausted, or on the third espresso, you’ll likely overreact to every red line and miss the patterns that actually matter.  

After you’ve dissected your performance, give yourself a **recovery window**. It’s perfectly normal to feel a sting—maybe you realized you entered a trade because you were bored, not because the setup was solid. Don’t rush back into the market with a shaky mindset; that’s the perfect recipe for chasing losses and making low‑probability bets.  

## Digest, Accept, and Move On  

The goal isn’t to wallow in self‑pity; it’s to let the feedback settle, acknowledge the gaps, and then plot a concrete, long‑term improvement plan. Think of it as a “training camp” for your brain: you’ll emerge stronger, more disciplined, and less likely to throw a tantrum when a trade goes sideways.  

## Embrace the Facts, Don’t Run From Them  

There’s no magic shortcut that lets you skip the uncomfortable part of looking at your own track record. Trading, like any high‑skill craft, demands brutal honesty with yourself and the willingness to adjust the sails when the wind changes. It may feel painful at first, but the more you practice objective self‑analysis, the more you’ll start turning those cold, hard facts into warm, sweet profits.  

So, raise a glass to the truth—no matter how chilly it is. Your future self (probably sipping a margarita on a profitable trade) will thank you for the hard work you put in today. 🍹📈