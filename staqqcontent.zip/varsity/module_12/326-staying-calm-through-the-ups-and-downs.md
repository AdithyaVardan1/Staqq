# 326. Staying Calm Through the Ups and Downs  

**Source:** https://zerodha.com/varsity/chapter/staying-calm-through-the-ups-and-downs/

---

If you’ve ever been a rookie trader, you probably know the feeling of being on an emotional roller‑coaster that makes the *Merry‑Go‑Round* look like a lazy Sunday stroll. One minute you’re on cloud nine because a trade went “ka‑boom!” and you’re picturing yourself buying a private island, the next you’re sobbing into your coffee because a single bad ticket wiped out half your account—and you’re suddenly convinced that the market is secretly conspiring against you.  

Seasoned pros, on the other hand, seem to glide through the chaos like they’re sipping chamomile tea on a quiet balcony, even when a string of losing trades would make most mortals want to hurl their laptops out the window. They don’t let the natural ebb and flow of the market mess with their emotional GPS.

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/06/20060803-300x300.png)

---

### The “Rational‑and‑Unemotional” Ideal (and Why Even the Best Can Slip)

In a perfect world, every winning trader would be as stoic as a monk on a mountaintop—no sweat, no tears, just pure, cold‑blooded logic. Reality, however, loves to throw a banana peel in front of even the most disciplined. It’s perfectly normal to start questioning your strategy after a losing streak. As Manuel, a hedge‑fund guru interviewed by Innerworth a few years back, confessed:  

> “It’s easy to start doubting my approach and wonder about the validity of what I’m doing.”  

And when the market hands you a series of wins, the opposite extreme rears its head:  

> “During winning periods, it’s easy to become over‑confident, and that can lead to trouble. While overconfident, I feel a false sense of security. I’m tempted to take unnecessary risks, and I start to think that I don’t have to do any more research to find and figure out new ways to extract money from markets. It is easy to fall into a sense of complacency.”

In plain English: when you’re winning, you start feeling like a wizard who can summon cash with a wave of a hand. The danger? That wizard soon discovers his wand is actually a cheap plastic stick and the next spell blows up his portfolio.  

---

### Rookie Pitfalls: The High‑Risk, High‑Emotion Combo

New‑bie traders are especially prone to this emotional whiplash because they often skip the most important rule of the trading world: **risk management**. They gamble with a chunk of their capital on a single ticket, thinking they’re about to become the next Warren Buffett. When the trade works, they’re dancing like nobody’s watching; when it blows up, they’re left with a bruised ego and a bank account that looks like a diet soda—full of bubbles but no real substance.

The key difference between a “big win” and a “big loss” for a rookie is the *size* of the capital at stake. A tiny win feels like a championship, while a massive loss feels like you just handed the market a loaded gun and watched it turn on you.

---

### How Proper Risk Management Saves Your Feelings (and Your Wallet)

Enter **proper risk management**, the unsung hero that turns a jagged equity curve into a relatively smooth, Netflix‑binge‑able line. When you limit the amount you can lose on any single trade—say, 1‑2 % of your total account—you’re essentially putting a safety net under the tightrope you’re walking. If the trade goes south, you only lose a bite‑size piece of cake, not the whole bakery.  

Because the loss is modest, the emotional punch is also modest. You won’t be crying into your pillow at 2 a.m. over a $500 slip‑up if your account is $50,000. Instead, you’ll stay level‑headed, think “Okay, that’s a data point,” and move on to the next opportunity. A smoother equity curve means fewer dramatic peaks and valleys, which in turn means fewer mood swings.  

Remember: **trading is a business, not a casino night.** In a business, you wear a suit, keep receipts, and stay objective. In a casino, you wear a funny hat, shout “come on!” and hope Lady Luck is on your side. The more you treat your trades like a business—keeping receipts (journals), sticking to a risk plan, and reviewing performance—the easier it is to keep the brain’s “creative analysis” mode on instead of the “panic‑button” mode.

---

### Manuel’s Secret Sauce: Embracing the Cycle

So how does a veteran like Manuel keep his cool? He’s mastered the art of *cycle awareness*. He knows that trading performance is cyclical—one day you’re riding a wave, the next you’re paddling in a sea of red. By accepting this up‑and‑down rhythm, he stops treating a winning streak as a guarantee and a losing streak as a personal failure.  

> “I realize that if I have a big winning period I shouldn’t get overly excited because most likely, I’ll have a flat or losing period just around the corner. That’s the way the market works. No style of trading makes money all the time. The odds are that after you have a big winning period, you’ll go through a period of losing money shortly thereafter. I try to make enough money to give myself a cushion to handle the losses when they come.”

In other words, he builds a “cushion”—a buffer of profits that can absorb the inevitable bumps. It’s like keeping a spare tire in the trunk: you hope you never need it, but you’re grateful when you do.

---

### Bottom Line: Keep Your Cool, Keep the Cash

Trading can be an emotional roller‑coaster that leaves you screaming, laughing, and occasionally vomiting (metaphorically, we hope). But with disciplined risk management, a smooth equity curve, and an acceptance that markets move in cycles, you can turn that wild ride into a gentle, scenic train trip.  

Winning traders stay calm, objective, and rational—think of them as the zen masters of Wall Street. If you can adopt that state of mind, you’ll not only reduce the stress‑induced hair loss but also boost your odds of long‑term financial success. So next time the market tries to mess with your mojo, remember: a little risk control, a dash of humility, and a good sense of humor go a long way. Cheers to calm profits and fewer midnight panic attacks!