# 252. Increasing Discipline and Self‑Control  

**Source:** https://zerodha.com/varsity/chapter/increasing-discipline-and-self-control/

---

Winning traders are disciplined. They keep their impulses and feelings on a short leash, which lets them follow a trading plan as smoothly as a bartender pouring a perfect draft. A disciplined trader makes decisions with the confidence of a poker player who just read the opponent’s tells, while an undisciplined trader wavers like a karaoke singer who can’t decide whether to sing “Bohemian Rhapsody” or “Baby Shark.” The latter might stick to the plan on a good day, then go off‑track on the next, chasing every shiny chart pattern that flashes by.  

Discipline is a cornerstone of trading success, but not everyone is born with a self‑control superpower. First, figure out where you sit on the “discipline meter.” If you discover you’re more “free‑spirited” than “laser‑focused,” treat it as a workout plan for the mind: you can build those mental muscles just like you’d bulk up your biceps at the gym.

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/04/20060531-300x300.png)

## The Personality Science Behind Discipline  

Psychologists have been poking around discipline and self‑control for decades. Some people are the human equivalent of Swiss watches: they pay credit‑card bills on the due date, never miss an appointment, and can plan a vacation itinerary down to the exact minute they’ll eat a croissant. Those traits sound like a trader’s dream, right?  

**But here’s the catch:** hyper‑disciplined folks often hate risk like a cat hates water. They crave certainty, and trading is about as certain as a weather forecast in the middle of a hurricane. The market loves to throw curveballs, and if you’re only comfortable with “sure things,” you’ll end up watching the action from the sidelines while others make the money.  

Most traders, even the good ones, sit somewhere in the middle. They don’t actively hunt danger like a stunt‑driver, but they’re comfortable flirting with it. This is why you’ll hear countless coaches preaching the gospel of self‑control—because a modest amount of discipline is the sweet spot, not an ironclad, never‑break rule‑book.

## How Do You Stack Up?  

- **Do you stick to your trading plan, or does it feel like you’re playing “choose your own adventure” every day?**  
- **Do you wish you had more discipline and self‑control when it comes to the markets?**  

If the answer is “yes,” try a simple yet powerful awareness exercise: become a detective of your own behavior. Watch how much control you actually have over everyday decisions, and then practice tightening that grip.

### Everyday Audit  

Ask yourself these brutally honest questions:

1. **Punctuality:** Are you regularly the one who shows up late, or do you arrive early enough to snag the best seat?  
2. **Spending:** Do you consistently spend more than your budget, or are you the master of the “envelope system”?  
3. **Promises:** How often do you break a promise—whether it’s to a friend, a partner, or yourself?  

You don’t need to be a perfect monk in every aspect of life for trading success, but the habits you cultivate in daily life tend to bleed into the market. If you’re constantly over‑spending, binge‑eating, or indulging in endless Netflix marathons, you’ll likely find it harder to say “no” to that extra lot of a volatile stock when the hype hits.

## A Mini‑Boot‑Camp for Your Life  

Here’s a practical experiment you can run for a few weeks (or longer if you’re feeling masochistic):

| Area | What to Control | How to Measure |
|------|----------------|----------------|
| **Calories** | Limit your daily intake to a realistic target (e.g., 2,200 kcal). | Use a food‑tracking app; note any slip‑ups. |
| **Money** | Stick to a strict weekly budget for discretionary spend. | Record every purchase in a spreadsheet or budgeting app. |
| **Leisure** | Cap the amount of time you binge‑watch or scroll social media. | Set a timer; note the actual minutes spent vs. goal. |

Pick one or two of these to start with—don’t try to juggle all three at once unless you enjoy watching yourself implode. Track your performance daily. You’ll quickly discover whether you’re a “control‑aholic” who can say “no” to a third slice of pizza, or a “control‑phobe” who caves at the sight of a sale sign.

### What to Expect  

- **Shifted reference point:** After a couple of weeks, the things that once felt “hard” (like refusing a latte) will start feeling normal, and you’ll notice a new baseline for self‑control.  
- **Better impulse awareness:** You’ll start recognizing the internal “I want that now!” voice in real time, giving you a chance to pause before you act.  
- **Positive spill‑over to trading:** When you prove to yourself that you can stick to a budget, you’ll be more inclined to stick to a stop‑loss or a position size rule. The mental muscle you’ve built in the kitchen or the closet will flex when you’re staring at a candlestick chart.

## Bottom Line: Discipline Is the Secret Sauce  

Trading is a marathon, not a sprint, and discipline is the water bottle you keep sipping from along the way. The more you practice self‑control in the mundane corners of life, the easier it becomes to apply the same rigor to your charts, risk‑management rules, and exit strategies.  

So, give yourself a mini‑challenge: pick a life area, tighten the reins, and watch how that newfound firmness nudges you toward a tighter, more reliable trading plan. If you can master the art of not eating the whole pizza, you’re a step closer to not over‑trading the whole market.  

In short, discipline isn’t just a nice‑to‑have—it’s the key that unlocks consistent, profitable trading. Put in the effort now, and you’ll thank yourself later when your portfolio is humming along and you’re still on time for brunch. Cheers to a more disciplined you!