# 275. Emotion Control Isn’t Emotional Suppression  

**Source:** https://zerodha.com/varsity/chapter/emotion-control-isnt-emotional-suppression/  

---  

Picture this: Jack, our favorite mouse‑smashing maestro, whacks his gaming‑grade mouse against the office wall with a *thwack* that could wake the dead. He’s fuming. He’d been watching a trade like a hawk, ready to pop a quick profit, when a horde of other traders decided to do a little “price‑shuffling” that totally derailed his master plan. Ten minutes later—after a deep‑breathing session that resembled a yoga class for the chronically stressed—he’s back to his usual self‑same‑old‑self. His desk‑mate, who’s already counting the number of mice Jack has turned into modern art, asks, “Aren’t you sick of breaking four mice a month just because a few trades bite you in the butt?” Jack grins, shrugs, and says, “What’s the big deal? I like to let out my anger. Feels better.”  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/05/20060327-300x300.png)  

Jack’s a classic case of “I‑think‑I‑need‑emotion‑control‑but‑I‑don’t‑really‑get‑it.” Winning traders *can* look like they’re auditioning for a drama series—furrowed brows, clenched jaws, the whole nine yards—but the *ideal* trader actually behaves more like a Zen monk on a coffee break: calm, objective, and oddly unbothered by the market’s mood swings.  

## The Mis‑Interpretation: “Suppress Everything!”  

Here’s where most people go off the rails. They hear “emotion control” and immediately think, “Ah, I’ll just bottle everything up, like a fermented kombucha of feelings, and never let it escape.” Spoiler alert: that’s not only unhelpful, it’s downright unhealthy. Scientific studies (yes, the nerdy ones that actually measure cortisol levels) have repeatedly shown that trying to shove angry or frustrated feelings into the emotional closet *doesn’t work*. Your body stays on high alert—heart racing, muscles tensed—while the feelings sit there, festering like a bad pizza left in the oven too long.  

So, in a twisted way, throwing a mouse at the wall *does* release the pressure. At least the emotion gets a physical outlet. But even that is a half‑baked solution; you might end up with a broken mouse **and** a reputation for office vandalism. Plus, the “smash‑and‑run” habit can set you up for bigger blow‑ups later (think of it as emotional constipation).  

## Why Do We Get Angry? The Expectation Trap  

Emotions are the brain’s way of translating events plus the *interpretation* of those events into a feeling. When a trade doesn’t go your way, the brain says, “Hey, this sucks!” and serves up a hearty helping of anger or frustration. Why? Because, deep down, we’ve convinced ourselves that the market *should* behave the way we want it to. It’s like expecting every barista to remember your name and your exact coffee order without fail. When reality (or the barista) deviates, you feel cheated.  

If you cling to the belief that “everything must go my way,” you’re signing up for a lifetime subscription to “Frequent Flyer” anger and frustration. You’ll either become the guy who hurls mice and keyboards (Jack’s future), or you’ll bottle it up until your doctor hands you a prescription for ulcer medication. Neither is a winning trade.  

## Active vs. Passive: The Real Deal of Emotional Control  

Good emotion control isn’t a passive “let‑it‑be” approach; it’s an **active** one. Think of it as being the detective in a crime drama, but the crime is *your own* emotional hijacking. You need to interrogate the *events* that sparked the feeling and the internal chatter that followed.  

Take Jack again. He got angry because he assumed other market participants *should* behave like polite guests at a dinner party—i.e., not mess with his carefully‑crafted entry point. It’s natural to *wish* for that, but it’s unrealistic. Traders don’t have a universal “Do Not Disturb” sign for your positions. Most of them are just as clueless as you are, chasing their own profit targets.  

When you cling to the belief “they must not interfere,” you set yourself up for a **belief‑induced** emotional explosion. A smarter mental script is: “Hey, there’s a decent chance something will go sideways—be it a slippage, a latency glitch, a sudden news bomb, or a rogue algorithm.” If you can **philosophically** accept that setbacks are part of the game, you’ll dodge the anger bullet.  

## The Optimistic Reframe: Expect Setbacks, Not Catastrophes  

Instead of living in a fantasy where the market bows to your wishes, adopt an optimistic realism. “Sure, setbacks will happen, but that doesn’t mean the whole ship is sinking.” Over the long haul, a single loss is just a ripple; a series of well‑managed ripples can become a tide that lifts you to profitability.  

If you rehearse this mental mantra—like a rock‑star rehearses a setlist—you’ll be ready the next time a trade goes south. You’ll feel less like a wounded animal and more like a seasoned sailor who’s seen a few storms and knows how to trim the sails. The less you’re rattled, the easier it is to stay in the game, keep persisting, and eventually turn those setbacks into stepping stones.  

## Persistence Over Frustration: The Trader’s Survival Kit  

Trading is a marathon, not a sprint through a candy store. The ability to keep plugging away after a loss separates the “I‑quit‑after‑my‑first‑bad‑trade” crowd from the “consistent‑profit‑machine” crowd. The less mental bandwidth you waste on anger and frustration, the more you can allocate to analyzing charts, refining strategies, and—most importantly—sleeping soundly at night.  

In short: stop trying to lock your emotions in a tiny closet. Instead, **recognize** the trigger, **question** the belief that caused the flare‑up, and **replace** it with a realistic, optimistic expectation. Do that often enough, and you’ll find yourself breaking fewer mice, keeping your sanity intact, and moving steadily toward that elusive, consistent profit line. Cheers to a calmer, richer trading life—preferably with fewer broken peripherals!  