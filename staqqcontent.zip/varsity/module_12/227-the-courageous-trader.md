# 227. The Courageous Trader  

**Source:** https://zerodha.com/varsity/chapter/the-courageous-trader/  

---  

Winning traders aren’t just lucky; they’re downright brave—think of them as the Navy SEALs of the market, only their “parachute” is a stop‑loss and their “mission” is to turn a candle chart into cold, hard cash.  
They summon courage when they **put real money on the line**, fully aware that the market could chew that cash up and spit it out like a bad taco. They also need gumption to stick to their own convictions, even when their ego starts shouting, “Hey, you’re wrong!” and their pride threatens to file a restraining order.  

But don’t go picturing them as reckless daredevils doing wheelies on a Harley while shouting “YOLO!” at the exchange floor. Courageous trading is a lot subtler than a Hollywood stunt. It’s not about chasing adrenaline; it’s about **choosing the right battles** and arming yourself with a solid risk‑management toolkit.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/04/20061011-300x300.png)  

## The Fine Line Between Bold and Foolhardy  

A brave trader can stare down a volatile setup the way a cat watches a laser pointer—focused, patient, and not about to pounce until the odds look tasty. Yet, that same trader also knows how to **protect the downside**. Think of risk management as the trader’s seatbelt; you might never need it, but when the market does a 180‑degree spin, you’ll be glad it’s there.  

So, courage in trading isn’t a free‑for‑all “let’s throw everything at the market and hope for the best.” It’s a disciplined, **prudent bravery**: you go after the trade you believe in, but you also put a stop‑loss, size your position properly, and have an exit plan that isn’t just “maybe I’ll get lucky later.”  

## Why Even Getting Into a Trade Takes Guts  

Every trade is a little emotional roller‑coaster. You’re essentially saying, “I’m willing to risk my hard‑earned cash *and* a sliver of my self‑esteem.” It’s natural to feel a sting when the market decides to bite you back. The trick isn’t to **pretend you don’t care**—that would be as fake as a “no‑spike” energy drink—but to keep the ego from taking over the steering wheel.  

If you can summon enough courage to **press that “Buy” or “Sell” button** even after a string of losers, you’re already ahead of the pack. The more bravado you can muster, the easier it becomes to keep your cool when the market tries to give you a wedgie.  

## When the Risk Is Too High, Back Off (Smartly)  

Let’s be honest: sometimes the market looks scarier than a haunted house on Halloween. If a trade feels **excessively dangerous**, your brain will naturally start playing the “nope” anthem. That’s not cowardice; that’s common sense. Instead of forcing yourself to be a hero, **lower the danger level**.  

The higher the potential loss, the louder the fear‑meter ticks, and the more courage you’ll need to stay in the game. By trimming the risk, you shrink the fear, and suddenly the trade feels more like a friendly jog than a marathon through a swamp.  

### How to Shrink the Financial Threat  

1. **Size your position** so that even a 100 % loss would only shave off a tiny slice of your capital (think 1–2 % of your total account).  
2. **Pre‑calculate your risk** before you even click “Enter.” If your stop‑loss is 50 pips away, know exactly how many lots that translates to in rupees.  
3. **Chase setups with a positive expectancy**—those that, on paper, give you a higher probability of profit than loss.  

If you’re only risking a few bucks on a trade, the market’s “oops” won’t feel like a personal catastrophe, and you won’t need to summon the courage of a gladiator just to stay seated.  

## Protect Your Brain, Not Just Your Wallet  

Financial risk isn’t the only villain; **psychological risk** is the sneaky sidekick that can wreck you faster than a sudden market crash. Many traders turn a modest loss into a personal tragedy by attaching unnecessary meaning to it. “If I lose this trade, I’m a failure” is the kind of self‑sabotage that turns a simple dip in the market into an existential crisis.  

### Ego‑Free Trading Tips  

- **Detach your identity** from the trade. Treat it like a grocery purchase: you might get a bad avocado, but you still have a fridge full of other veggies.  
- **Limit the narrative** you tell yourself. Instead of “I’m the smartest trader on the floor,” think “I’m a work‑in‑progress with a solid process.”  
- **Don’t chase the “I’m right” reflex.** The market doesn’t care about your bragging rights; it only cares about price action.  

When you strip away the drama, the trade becomes a **neutral event**, not a life‑changing moment. Your ego gets a vacation, your stress levels drop, and you can approach the next setup with the calmness of a monk sipping chai.  

## The Illusion of Courage (And How to Turn It Real)  

Sometimes what looks like bravery is just **a clever illusion**. You can appear fearless by **pre‑emptively cutting the potential harm**. If a trade looks like a tornado, you either wait for it to calm down or put on a protective shield—i.e., a tight stop‑loss and a tiny position size.  

When you shrink the downside, the fear factor drops, and the “courage” you feel is actually the market whispering, “Hey, you’re good to go.” In other words, **courage is often the by‑product of good risk management**.  

So, next time you’re eyeing a trade that feels like a high‑stakes poker hand, ask yourself:  

- *Did I size this properly?*  
- *Do I know exactly how much I could lose?*  
- *Am I trading because I truly believe in the setup, or because I want to prove I’m the next Warren Buffett?*  

If the answers line up with prudence, you’ll find that the courage you need is already in your toolbox—no superhero cape required.  

---  

Bottom line? **Courageous trading = smart risk control + ego detox + a dash of daring**. Keep the risks small, keep the ego in check, and you’ll be the trader who walks into the market like it’s a casual brunch—not a battlefield. Cheers to brave (but sensible) trading!