# 198. The Competitive Spirit: Learn to Tame It  

**Source:** https://zerodha.com/varsity/chapter/the-competitive-spirit-learn-to-tame-it/  

---  

We’ve been handed the “competitive spirit” on a silver platter since we could first scribble a name on a scoreboard. As kids we’re told, *“Run faster, jump higher, be the MVP!”* In school the mantra becomes, *“Get higher grades or you’ll end up living in your parents’ basement.”* Then, after we slip into the 9‑to‑5 grind, the boss shouts, *“Out‑sell, out‑think, out‑perform—otherwise you’re toast!”*  

All that hype makes sense when you’re playing football or fighting for a promotion, because there really *are* opponents. But in trading the only opponent that matters is… **you**. Yep, the market is a wild beast, but the real battle is between the you‑who‑thought‑he‑knew‑everything and the you‑who‑still‑needs‑a‑plan. Letting a hyper‑charged competitive spirit run wild in your portfolio can actually *hurt* more than it helps.  

---

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/03/20060921-300x300.png)  

---

## Why the “Compare‑and‑Conquer” Playbook Looks Good on Paper  

Seeing someone else hit a sweet 20 % return can feel like a neon sign screaming “That could be you!”  In psychology, that’s called *social proof*: we get a jolt of motivation when a goal suddenly looks reachable. History is littered with breakthroughs that only happened after someone proved the “impossible” wasn’t so impossible—think the first moon landing or the invention of the internet.  

So the idea of peeking at a fellow trader’s track record seems harmless, even helpful. *“If they can do it, why not me?”* you think, while sipping a latte that’s probably too expensive for a college student budget.  

## The Dark Side of the Comparison Game  

Here’s the kicker: the very people who end up writing history are usually the **loners**. They don’t waste time scrolling through other people’s Instagram feeds; they’re too busy building their own empire. The same is true for trading.  

When you constantly check someone else’s P&L, a few nasty side‑effects creep in:  

| Mood Swings | What Happens | Why It’s Bad |
|------------|--------------|--------------|
| **Jealousy** | “Why does Alex have a 30 % win‑rate and I’m stuck at 12 %?” | Turns your brain into a hamster wheel of self‑criticism. |
| **Envy** | “I wish I’d taken that trade yesterday.” | Distracts you from the *present* trade set‑up. |
| **Self‑doubt** | “Maybe I’m not cut out for this.” | Undermines confidence—essential fuel for disciplined trading. |

Those thoughts don’t sharpen your edge; they just make you stare at the wall while the market keeps moving.  

## Stop Staring at the Neighbor’s Garden – Tend Your Own  

The easiest way to break the habit is to **stop looking at anyone else’s record**. Yes, it’s like trying to quit that childhood habit of copying everyone’s homework. It won’t happen overnight, but you can train yourself like a muscle.  

Remember: **Everyone’s learning curve is a different roller‑coaster.** One person might zip up a steep hill in seconds; another takes a leisurely crawl. What works for them probably won’t work for you, because you have a different risk tolerance, schedule, and brain chemistry.  

### The “You‑Only‑Matter” Checklist  

1. **Pull up your own trade journal.** (If you don’t have one, start now—your future self will thank you.)  
2. **Identify the “winning DNA.”** What did you do right on those profitable trades?  
3. **Spot the “losing DNA.”** Which setups consistently bite you?  
4. **Ask the tough questions:**  
   - *When do I feel most confident?*  
   - *Which market conditions suit my personality?*  
   - *Am I trading because I see an edge, or because I’m bored?*  

Once you have answers, craft a **personal action plan**. For instance, if you discover you’re a beast at the market open when the overall trend is bullish, double‑down on that niche. Treat it like a specialty pizza—don’t try to be a sushi‑and‑taco‑fusion restaurant unless you’re prepared to master both.  

### Who Cares About Being 50 % Behind the “Super‑Trader”?  

If a fellow trader is raking in half‑a‑million while you’re making a modest 10 % return, does that mean you’re a failure? **No.** What matters is **consistency** and **risk‑adjusted returns**, not who’s shouting the loudest on social media.  

Focus on making *your own* profit curve smooth and upward. In the long run, the market doesn’t care whether you’re the fastest or the slowest; it only cares whether you stay in the game.  

## The Bottom Line: Turn the Competitive Beast into a Coach  

Think of your competitive spirit as a personal trainer, not a rival boxer. Let it **push you to improve**, but keep it from **turning into a bully** that beats you down every time a trade goes sideways.  

- **Scrutinize your own history** the way a detective examines a crime scene.  
- **Isolate the variables** that lead to success or failure for *you*, not for the guy on the next desk.  
- **Adjust your strategy** based on those findings.  

If you can do that, you’ll eventually see the profits roll in—maybe not overnight, but steadily, like a well‑aged whiskey. And the best part? You’ll be doing it *your* way, free from the noise of everyone else’s brag‑board.  

So, next time you feel the urge to peek at a rival’s spreadsheet, remember: the only competition that matters is the version of yourself from last month. Keep that version in check, keep your eyes on the chart, and let the market do the rest.  

**Bottom line:** Tame the competitive spirit, make it your personal cheerleader, not your toxic ex. Cheers to trading yourself into the winner’s circle—your circle! 🍻  