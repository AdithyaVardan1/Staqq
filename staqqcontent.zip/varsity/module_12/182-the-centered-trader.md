# 182. The Centered Trader  

**Source:** https://zerodha.com/varsity/chapter/the-centered-trader/

---  

Profitable traders are basically emotional ninjas. 🥷 They don’t let a sudden dip or a “why‑me?” feeling yank them off the tightrope of concentration. Instead they stare at the charts like a hawk eyeing a worm, and that laser‑focus lets them catch even the tiniest market wiggle‑wiggles without breaking a sweat. Trading guru Dr. Ari Kiev gave this mental state a snazzy name: **centered trading** – think “zen master meets Wall Street” in one tidy package.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/03/20070222-300x300.png)  

During a series of “real‑talk” interviews with a handful of seasoned traders, the common thread was crystal‑clear: the best of the best treat setbacks like a bad joke—laugh, brush it off, and move on.  

> **Scott**, a battle‑hardened trader, puts it bluntly: “You can’t let what just happened ruin what’s about to happen.” His mantra after a losing trade is basically, “Oops, my bad. What’s next?”  

> **Mark**, a hedge‑fund head honcho, likens recovery to a soccer match: “The moment you lose the ball you sprint the other way. No time for a sob story. Your awareness of the field tells you where to run, and you keep playing until the final whistle.”  

In other words, the moment you realize you’ve dropped the ball, you don’t sit on the bench and cry. You get up, look at the scoreboard (the market), reposition, and keep the game rolling.  

## What a Centered Trader Looks Like  

- **Laser‑focused on the trade at hand** – No day‑dreaming about the next vacation or the last bad trade.  
- **Unfazed by consequences** – If the trade goes south, they don’t replay the disaster on loop like a bad sitcom.  
- **Past‑mistake free** – They treat every loss as a closed chapter, not a haunting ghost.  
- **Future‑free** – No frantic Googling of “will the market crash tomorrow?”  
- **Emotionally detached** – Thoughts drift through like clouds; they watch, don’t cling.  

It’s practically a meditation session with candlesticks. The more centered you become, the fewer the “hey, look at that shiny thing!” distractions.  

## How to Get There (Dr. Kiev’s 4‑Step Blueprint)  

1. **Spot the sneaky negative thoughts** – Those self‑defeating whispers (“I’m terrible at this”) slip in faster than a trader’s coffee order. By shining a mental flashlight on them, you can shoo them away.  

2. **Ditch the war‑zone metaphors** – Trading isn’t a gladiator arena; it’s more like a calm lake. Swap “attack the market” for “navigate the currents.” Your brain will thank you for the reduced adrenaline spikes.  

3. **Kick the ego to the curb** – Dr. Kiev says, “Stop obsessing over your image and surrender to the Tao (or the market’s flow).” In plain English: don’t trade to prove you’re a genius; trade because the market *is* the teacher.  

4. **Practice a meditative habit** – This is the pièce de résistance. You don’t need to sit cross‑legged for hours unless you enjoy that. Anything that quiets the mental chatter works:  
   * **Formal meditation** – 5‑10 minutes of breathing, eyes closed, “I am a calm, profitable trader.”  
   * **Praying or chanting** – “Lord, give me good entries and exits, amen.”  
   * **Reading a short story** – Let a narrative pull you away from the ticker.  
   * **Humming or singing** – Your own “trading anthem” can be oddly grounding.  
   * **Dance or light exercise** – A quick jig around the office can reset the nervous system faster than a coffee refill.  

With regular practice, you’ll start to notice that the automatic, negative, emotional chatter fades into background noise. Your mind will stay glued to the present market action, and—bonus!—your profit‑and‑loss statement will thank you for it.  

So, next time the market throws you a curveball, remember: be the zen‑like surfer who rides the wave, not the panicked swimmer who flails. 🌊📈