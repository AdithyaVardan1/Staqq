# 130. Addicted to Trading  

**Source:** https://zerodha.com/varsity/chapter/addicted-to-trading/

---  

Winning traders *love* what they do. The moment they spot a setup they feel a little buzz, like the first sip of a perfectly‑chilled beer after a long day. That spark is healthy—it’s the fuel that keeps you glued to the charts.  
But there’s a thin line between “I’m excited about this trade” and “I’m chasing a roller‑coaster high that could send my account into a free‑fall.” Some folks slip over that line and become **trading addicts**. They toss caution to the wind, not because they’ve discovered a secret money‑printing algorithm, but because the *thrill* feels better than the profit.  

Ari K. Keiv (2002) summed up the addictive trader as someone who is “constantly seeking a sense of power and control; competitive, restless, and easily bored.” In plain English: they’re the adrenaline junkies of the brokerage floor. Those traits make them keep upping the ante—until the inevitable *boom* (read: account‑wipeout) hits.

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/02/17-242x300.png)

### Trading for the Rush, Not the Return  

Trading is supposed to be fun—think of it as a sophisticated game of chess, not a night‑club bungee jump. There’s nothing wrong with a little excitement, but an addict treats every trade like a slot‑machine pull. They’re **gamblers with a screen**.  

For instance, an addictive trader might actually *enjoy* a deep draw‑down. While most sane humans would break out a stress ball if they saw a $100,000 loss staring back at them, the addict says, “Bring it on!” They relish having $200,000 to claw their way out of the hole because the *danger* feels more alive than a calm profit. It’s the same reason some people watch horror movies—if you’re not scared, you’re not really living, right? Wrong. In finance, being scared usually means you’re about to get *scared* out of your money.

### The “I’m‑Better‑Than‑You” Complex  

Another, equally pesky, flavor of trading addiction is the **super‑ego‑complex**. Deep down, these traders feel a pinch of inferiority (maybe because their boss still calls them “Junior Analyst”). To patch that hole, they convince themselves they’re the *Einstein* of equities, the *Ninja* of options.  

They refuse to accept the market’s obvious signals and instead try to out‑wit it. Picture someone short‑selling a roaring bull market just because “being contrarian makes me look cool.” They’re not looking for profit; they’re hunting validation. When the crowd is right (and, spoiler alert, the crowd is *usually* right), they’ll still stick to their lone‑wolf path just to keep that ego puffed up.

### Logic vs. Emotion: Who’s the Real Boss?  

Addiction‑prone traders hand the steering wheel over to **emotion**, letting mood swings dictate position size and entry timing. Winning traders, on the other hand, lock the emotional doors and let **logic** drive. They sit down, study the market, and craft a **detailed, realistic trading plan**—whether that plan says “follow the herd” or “go solo” is secondary to the fact that it’s *rational*.  

In practice that means:  

- **Map it out** – chart support/resistance, risk‑reward, and stop‑loss before you even think about clicking “Buy.”  
- **Test the hypothesis** – does the trade make sense on paper, or are you just feeling “spicy”?  
- **Stick to the script** – if the plan says “no trade after 2 PM,” you don’t suddenly decide to “go big” because the market looks “tempting.”  

When an emotional itch hits, a disciplined trader says, “Hold up, I’m not trading on impulse. I’m going to breathe, maybe grab a coffee, and revisit this with a clear head.”  

### How to Break the Addiction Cycle  

If you catch yourself loading up on ultra‑risky, “just‑for‑the‑kick” trades, it’s time to pull the emergency brake and re‑educate yourself:

1. **Stop chasing the crowd just to be different.** Being contrarian is fine when the data backs it; it’s not a personality statement.  
2. **Ban impulsive entries.** Create a pre‑trade checklist (e.g., “Is my stop‑loss ≤ 2 % of account? Is the risk‑reward ≥ 1:2?”). If you can’t answer “yes” without sweating, step away.  
3. **Write a concrete trading plan** – include entry criteria, exit targets, position sizing, and contingency rules. Treat it like a contract with yourself.  
4. **Ask the “why” before you trade.** Is the motive “I need $200 K to get out of this draw‑down” or “I’ve identified a high‑probability setup?” If it’s the former, you’re chasing a thrill, not a trade.  
5. **Practice the “pants‑off” rule.** If you feel the urge to trade “by the seat of your pants,” literally put your pants on the chair and walk away until the urge passes.  

Addictive traders usually crash in the long run because their strategy is built on *excitement* instead of *edge*. The sooner you recognize the problem and replace the dopamine‑hit with disciplined, data‑driven decisions, the better your chances of keeping both your capital **and** your sanity intact.

---  

*Bottom line:* Trading is a marathon, not a midnight rave. Love the market, but don’t let the love turn into a reckless love‑affair. Keep your brain in the driver’s seat, and let the profits (not the thrills) be the ultimate reward. Cheers to smarter, steadier, and far less “addicted” trading!