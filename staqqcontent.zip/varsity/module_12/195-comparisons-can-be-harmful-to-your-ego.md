# 195. Comparisons Can Be Harmful To Your Ego  

**Source:** <httpshttps://zerodha.com/varsity/chapter/comparisons-can-be-harmful-to-your-ego/>

---

We’ve all been there: scrolling through a friend’s Instagram story and suddenly feeling like the world’s biggest under‑achiever because they just posted a picture of a yacht, a marathon medal, and a “just closed a 5‑digit trade” screenshot. From the moment we learn to tie our shoes, someone (usually a well‑meaning adult) tells us that life is a **competition**.  

- As toddlers on the playground we’re told to “run faster, swing higher, be the star of the team.”  
- In school the mantra becomes “higher grades = higher‑paying job.”  
- In the corporate arena it morphs into “beat the competition or be beat.”  

Ironically, the people who end up *really* successful—think Warren Buffett, Elon Musk, or that quiet accountant who quietly turned a modest portfolio into a six‑figure nest egg—rarely spend their days measuring themselves against anyone else. They set their own tempo, craft their own playbook, and generally ignore the noisy crowd chanting, “You’re not good enough!”

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/03/20061120-300x300.png)

---

### When a Little Comparison Isn’t a Crime  

Let’s be clear: a **tiny, purposeful** dose of comparison can be the rocket fuel we need. Seeing that a peer managed to turn a modest $5,000 investment into $15,000 in a year tells us, “Hey, that’s possible!”—and that little spark can kick‑start real, disciplined effort. History is littered with breakthroughs that seemed impossible until someone proved it could be done. Think of the first folks who flew a plane, sent a man to the Moon, or even just figured out that you could *sell* a stock you didn’t own (yes, short‑selling). Their peers’ achievements gave them the confidence to push forward.

The problem starts when we **let the comparison run wild** and start treating other people’s results as a mandatory yardstick for our own self‑worth. If you try to meet an external benchmark without the same capital, experience, or even the right market conditions, you end up feeling like a flop. You’ll start blaming the universe, your luck, or that “unfair” system—while ignoring the assets you *do* have at your disposal. Many spend their whole lives nursing a bitter grudge against what life “should” have handed them, rather than making the most of what *is* in their hands.

---

### The Emotional Landmine: Jealousy, Envy, and “Why Me?”  

Every time you glance at a fellow trader’s shiny track record and think, “Why can’t I pull that off?” you’re basically feeding a **psychological gremlin**. The gremlin whispers things like, “I’m not cut out for this,” or “I’m a terrible trader,” and before you know it, you’re stuck in a loop of self‑doubt. That mental chatter does nothing for sharpening your strategy; it just distracts you from the one thing that truly matters—*skill development*.

In contrast, the high‑flyers you admire aren’t glued to anyone else’s leaderboard. They’re too busy **running their own marathon**, listening to their internal GPS, and adjusting the pace based on how they feel, not based on the speed of the guy next to them. Their secret sauce? Treating every trade as a personal experiment, not a public performance.

---

### Your Own Timeline, Your Own Playbook  

Trading (or any craft, for that matter) is a **personalized** journey. Your background, your risk tolerance, the amount of capital you can risk, even your favorite coffee order—all of these shape the method that will work best for you. Think of it like buying a suit: you wouldn’t buy a size‑large off the rack and expect it to fit perfectly; you’d get something tailored to your measurements. The same goes for trading strategies.

- **Capital** – Someone with a $100,000 bankroll can survive a few losing streaks that would wipe out a $5,000 account.  
- **Personality** – A risk‑averse individual may thrive on long‑term, low‑volatility positions, whereas a thrill‑seeker might gravitate toward short‑term, high‑beta plays.  
- **Life Experience** – A former engineer might be comfortable with systematic, rule‑based approaches, while a former marketer might excel at reading sentiment‑driven moves.  

Because every trader’s “ingredients” differ, the only fair comparison you can make is **you vs. you**.

---

### Stop Staring at Their Scoreboard; Check Your Own  

It’s tempting to peek at the scoreboard of the “top dogs” and think, “I should be there too.” That habit is as ingrained as the habit of checking the thermostat every five minutes. Changing it overnight is about as likely as learning to speak Mandarin fluently in a day—possible in theory, but not realistic. However, you can **train the brain** to pause the comparison impulse and redirect the focus inward.

1. **Log Your Own Trades** – Keep a journal. When you see a win, note *why* it worked. When you see a loss, note *what* you learned.  
2. **Set Personal Milestones** – Instead of “make $10k this month,” try “reduce my average losing trade size by 15%.”  
3. **Celebrate Small Wins** – Bought a position at the right entry? Great! That’s progress, even if the trade is still open.  

Remember, each trader carries a **unique history**: different market cycles, personal stressors, and even differing definitions of “success.” Trying to beat someone who started with a $500,000 cushion while you’re juggling a part‑time gig is, frankly, a recipe for a bruised ego.

---

### Bottom Line: Compare Only With Your Past Self  

In the grand arena of life and markets, the only opponent you *should* be trying to outdo is the version of yourself from last week, last month, or last year. If you find yourself still tempted to glance at someone else’s record, ask yourself:

- “Did they have the same starting capital?”  
- “Did they trade under the same market conditions?”  
- “Do they share my risk tolerance and time horizon?”

If the answer is “no” to any of those, the comparison is **meaningless**. Focus on tightening your own edge, and you’ll discover that the real competition is a moving target—*your own* improvement curve.  

So the next time you feel that sting of envy, take a deep breath, pour yourself a coffee (or a cocktail—no judgment), and ask: “What can *I* do today that will make *me* a better trader tomorrow?” That’s the only scoreboard that truly matters. Cheers to your own progress! 🍻