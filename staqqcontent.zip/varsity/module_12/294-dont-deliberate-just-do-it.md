# 294. Don’t Deliberate; Just Do It  

**Source:** <https://zerodha.com/varsity/chapter/dont-deliberate-just-do-it/>

---

James is weighing two shiny trading strategies. Both look like they could turn his account from “meh” to “heck‑yeah,” but he’s got the classic analyst‑in‑the‑room vibe: “Let’s stare at the pros and cons until the coffee runs out.” In other words, James is stuck in the *deliberative* zone—methodically chewing over every what‑if, every upside, every downside, trying to be the most rational human on the planet.

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/05/20050218-294x300.png)

Great minds have been on the same page. Benjamin Franklin, the original “don’t be a fool” guru, preached the merit of weighing pros and cons like a courtroom judge. Fast‑forward to the 21st‑century decision‑science labs, and researchers still tell us that an even‑handed, “let’s look at every angle” approach can keep us from slipping into the usual cognitive traps (confirmation bias, over‑confidence, you name it). The data even show that a deliberative mindset makes you more open to new info and less prone to self‑serving rationalizations. So far, so sensible.

Enter the contrarian duo: psychologists **Dr. David Armor** and **Dr. Shelly Taylor**. Their latest experiment throws a wet blanket on endless rumination. Sometimes, the smartest move is to *stop* the mental ping‑pong and just pick a side—then throw yourself at the goal like a caffeinated squirrel on a power line. In plain English: **just do it**.

### The experiment in a nutshell (no lab coat required)

- **Participants**: Randomly split into two groups.
- **Deliberative group**: Given two *equally effective* strategies, told to deliberate, pick one, then execute.
- **No‑choice group**: Told, “Here’s a strategy. Use it. No debate.” They dove straight into execution.

**Result?** The no‑choice crowd walked away with a swagger. They reported higher **determination**, **commitment**, **curiosity**, and **confidence**. They also rated the task as *easier* and, crucially, **performed better**. In short, the fewer the options you mull over, the more energy you have to actually *do* something.

### So, what does this mean for trading?  

Trading is a high‑octane sport where split‑second calls can be the difference between a sweet profit and a bitter loss. Yet, nobody wants to be the guy who throws a trade into the market because he saw a meme about “buy low, sell high.” That’s the impulsive end of the spectrum.  

The research above tells us there’s a **sweet spot**: enough information to be *informed*, but not so much that you end up in analysis‑paralysis. Psychological energy is a finite resource—think of it as a battery that drains faster the more you stare at a spreadsheet. Over‑deliberating can leave you with a depleted battery just when the market throws you a juicy opportunity.

**Bottom line:** When you’ve done your homework and the odds look solid, shut the deliberation door, click “execute,” and pour your focus into the outcome. You’ll likely find that the profit curve is steeper than the one you’d get by endlessly debating “Strategy A vs. Strategy B.”

So next time you feel the urge to spin the decision wheel for the fifth time, remember: **don’t deliberate—just do it.** Your future self (and your trading P&L) will thank you, possibly with a celebratory “cha‑cha‑cha” as the market moves in your favor. 🍻📈