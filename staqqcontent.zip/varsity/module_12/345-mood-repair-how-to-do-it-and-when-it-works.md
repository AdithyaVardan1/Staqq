# 345. Mood Repair: How To Do It and When It Works  

**Source:** https://zerodha.com/varsity/chapter/controlling-your-mood-and-maintaining-discipline/

---

Winning traders are basically the **Yoda** of the market: they keep their cool, stick to the plan, and never let the Dark Side (a.k.a. impulsive urges) win. Discipline, in this context, is the art of not pulling the plug on a trade the moment the charts start doing a happy dance. It’s a lot easier to say “I’ll stay disciplined” than to actually **not** slam the exit button the second your position is in the green and your broker sends you a “Congrats, you’re rich!” notification.

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/06/20050711-300x300.png)

Even the most “winning” of traders have a loss‑to‑win ratio that looks more like a seesaw than a straight line. When a trade finally decides to be a winner, the temptation to **lock‑in profits** right away is as strong as the urge to finish the last slice of pizza. The catch? Winners are rarer than unicorns, so you have to *resist* the urge to sell at the first sign of green and let the trade run long enough for it to hit the exit target you meticulously penciled in your plan. Think of it as delaying gratification—like waiting for that perfectly ripened avocado instead of snapping up a rock‑hard one. Patience = bigger profits; impatience = “I could’ve had more if only I’d not been a nervous‑Nelson”.

Your mood is the sneaky side‑kick that can either **fuel** your discipline or **sabotage** it faster than a toddler with a crayon. When you’re feeling down, it’s like trying to trade with a fogged‑up windshield—everything looks hazy and you’re more likely to slam the brakes at the first bump. A classic study by Knapp and Clark (1991) showed just how much emotional distress can mess with your self‑control. In their lab, participants played a pretend‑fishing game where each fish caught earned them cash.

Here’s the kicker: If you yank fish out of the lake **too early**, you get an instant cash splash, but you also **deplete the breeding stock**. Fewer fish mean fewer future hauls. The most profitable strategy turned out to be the opposite—**wait** and let the fish population replenish, then harvest later for a bigger payout. The mood of the participants mattered: those who were **sad** or cranky couldn’t sit still. They kept reaching for the early‑catch reward, convinced that a quick win would cheer them up.

Translate that to trading: a bad mood makes you crave an instant “feel‑good” hit. The market offers two quick‑fix routes—**cashing out a winner early** or **making a rash, adrenaline‑pumping trade** hoping for a rapid gain. Both are mood‑driven shortcuts that usually end up costing you in the long run. The opposite is true when you’re in a good vibe: you’re more likely to trust your plan, let the trade breathe, and avoid the impulse‑triggered exit.

So, what’s the prescription? Besides the obvious—*have a detailed trading plan* (think of it as your GPS, not a doodle on a napkin)—you also need a **mood‑check** before you fire up the charts. If you’re feeling like a grumpy cat, maybe skip the high‑frequency hustle and do some light reading instead. A sunny mood can be the difference between “I’m trading on autopilot” and “I’m trading with purpose”.

**Bottom line:** Discipline is the backbone of trading success, but a good mood is the vitamin D that keeps that backbone from getting brittle. Keep the plan tight, keep the vibes right, and you’ll be the trader who lets winners run, not the one who flings them out at the first sign of profit. 🍻📈