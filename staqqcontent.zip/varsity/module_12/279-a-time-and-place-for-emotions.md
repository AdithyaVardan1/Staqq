# 279. A Time and Place For Emotions  

**Source:** https://zerodha.com/varsity/chapter/a-time-and-place-for-emotions/  

---  

Winning traders are the kind of folks who treat the market like a disciplined gym routine: they show up, do their homework, stick to a plan, and never skip leg day—no matter how tempting a “quick sprint” to the finish line looks. They keep their impulses in check, don’t bail on a plan because the market hiccups, and refuse to let fear or greed hijack the steering wheel. But let’s be honest—emotions get a bad rap in the trading world, as if they’re the villain in every finance‑film sequel. In reality, there are moments when you need a cold, robotic head, and there are moments when you can let your inner drama queen have a solo.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/05/20060321-300x300.png)  

Think of trading as two distinct episodes of a TV series: **Planning** and **Execution**. In the Planning episode, you’re the mad scientist mixing potions, hunting for that next big idea, and scribbling wild charts on napkins. Feel free to ride the emotional roller‑coaster here—let the excitement flow, let the anxiety spark curiosity. When you move to the Execution episode, however, you need to switch the channel to “no‑nonsense news anchor” mode. The plan you’ve crafted must be executed *exactly* as written; otherwise, you’ll be the star of a tragic comedy instead of a profit‑making drama.  

During the planning stage, your mission is to unearth fresh trading strategies. It’s a creative jam session, and you can’t be a robot holding a “No‑Feelings” sign. In fact, letting your emotions guide you can be a secret weapon. Pump yourself up: “I’m a brilliant idea‑factory; if I let my imagination run wild, I’ll discover a gem!” Whether you’re back‑testing a mean‑reversion model, scanning for breakouts, or poring over a company’s 10‑K, you need that extra spark of enthusiasm. So go ahead—talk yourself up, cue the motivational soundtrack, and let the dopamine fuel the homework marathon.  

As you hunt for concepts, feel free to bounce from one brainwave to the next like a kid switching TV channels. Mix, match, mash‑up—what’s the harm? You’re in the discovery zone, not the firing zone. Even a dash of self‑doubt or paranoia can be useful: play Devil’s Advocate, ask “What if this crashes and burns?” A sprinkle of scepticism helps you spot hidden pitfalls before they become full‑blown catastrophes. In the planning phase, a little nervous energy is like a safety net, not a shackles.  

Eventually, the brainstorming party must end. You need to lock down a concrete plan: entry point, exit point, stop‑loss levels, and the indicators that will tell you when the plan is working (or not). Once the blueprint is set, it’s time to flip the switch from “creative‑storm” to “laser‑focus.” Your emotions and impulses must take a back seat. Enter the trade exactly as you scripted, monitor the market with a cool‑head, and exit gracefully—whether that means cutting losses early or riding the trend to the promised profit.  

Emotions aren’t forever the party‑crasher in trading; they’re the life of the brainstorming lounge. The key is knowing when to let the inner fire roar and when to lock the door and let discipline run the show. Master that timing, and you’ll discover that the disciplined trader—yes, the one who can separate the creative chaos from the execution calm—is the one who consistently cashes the checks. Cheers to trading with both heart **and** brain in the right rooms!