# 136. Alternative Rewards: A Way to Keep Trading During Setbacks  

**Source:** https://zerodha.com/varsity/chapter/alternative-rewards-a-way-to-keep-trading-during-setbacks/  

---  

## Why Do We Need a Reward Before We Do Anything?  

Let’s face it: even a hamster won’t spin that wheel unless there’s a treat waiting at the other end. The same goes for us humans—except we’ve upgraded the carrot to a **paycheck, a “like” count, or the sweet, sweet feeling of beating the market**. Our most primitive motivators are things like hunger, thirst, and the urge to find a cozy nest. When a lion spots a gazelle, it doesn’t think, “Should I run? Maybe later.” It *just* runs—because the reward (a juicy steak) is too good to ignore.  

Humans, however, are a bit more “civilized.” We can **delay gratification**. You can feel a rumble in your stomach at 9 a.m. and still decide to wait until lunch (or, if you’re a true trader, until the market closes) before you actually eat. This ability to postpone the immediate pleasure is what lets us **plan, save, and, crucially, trade**.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/02/12-186x300.png)  

Now, replace that literal carrot with a **symbolic one**—money. Money is the universal “I’ll buy you a steak later” token, and it’s why **fear and greed** are the two most powerful emotions in a trader’s toolbox. When we imagine the horror of “starving” (i.e., a depleted account), we instinctively hoard cash like a squirrel with a nut stash. Conversely, when the balance looks like a small fortune, we get that **euphoric high** that feels a lot like winning a round of Monopoly with real dollars on the line.  

Trading, therefore, is a built‑in reward machine: **profits = happiness** (at least until the next loss hits). That’s why many of us become hooked—our brain’s dopamine receptors start sending us thank‑you notes after every winning trade.

## The Emotional Rollercoaster of Profit‑Driven Trading  

Picture this: you’re on a trading floor (or your couch) and the charts are flashing green. You’re **riding high**, feeling like the next Warren Buffett. Suddenly, a red candle appears, and you’re suddenly **clutching your chest** as if you just saw the price of avocados double overnight. This swing from **euphoric “I’m a genius!”** to **despairing “I should have never left my day job!”** is the classic profit‑centric emotional rollercoaster.  

If you let **profits** be the sole driver of your mood, you’ll spend more time **checking your account balance** than you do actually **learning the market**. One minute you’re celebrating a 5 % gain; the next you’re crying over a 2 % loss, even though both figures could be *perfectly normal* in the grand scheme of things.  

That’s why we need to **decouple** our feelings from the dollar signs flashing on the screen. Instead of letting each tick dictate whether you’re smiling or sulking, you can build a **secondary, more stable reward system** that keeps you motivated even when the market decides to be moody.

## What Is an “Alternative Reward System” Anyway?  

Think of it as a **loyalty program for your brain**, but the points aren’t earned by buying coffee—they’re earned by *behaving like a disciplined trader*. The idea is simple: **reward yourself for sticking to the process**, not for the outcome.  

- **Process‑based reward:** “I followed my entry and exit rules for three consecutive days—time for a celebratory pizza!”  
- **Learning‑based reward:** “I spent an hour reading about Fibonacci retracements—let’s treat myself to a new book or a movie night.”  

These rewards are *independent* of whether you made a profit that day. So even if your portfolio is doing the “tug‑of‑war” between green and red, you still get a high‑five from yourself for **doing the right thing**.  

Why does this work? Because our brains love **consistency**. When we consistently receive a positive signal (the reward) after a desired behavior (following the plan), the neural pathways that link the two get stronger. Over time, the **habit of discipline** becomes its own source of satisfaction—no need to chase the fleeting dopamine hit from a random win.

## How Emotions Hijack Your Trading Plan (And How to Stop It)  

Let’s get real for a second: you’ve got a solid trading plan, you’ve back‑tested it, and you’re ready to roll. Then a **big win** hits and you think, “I’m unstoppable—let’s double my position size!” Or a **big loss** makes you think, “I need to recoup everything now, or I’ll never be rich!” Both scenarios are classic **emotional overrides** that make you deviate from the plan.  

If you keep letting profits and losses dictate your actions, you’ll end up **chasing your tail**—the very thing the plan was designed to prevent. The key is to **stay calm** and **focus on the long‑term picture**:  

- **Big‑picture mindset:** “I’ll be profitable over the next 12‑month horizon; today’s dollar figure is just a blip.”  
- **Abstract metrics over absolute cash:** Track things like **win‑loss ratio, average risk‑reward, and expectancy** instead of obsessing over “I made $200 today.”  

When you shift your attention to **justified wins**—those that happen because you followed a well‑crafted plan rather than because you got lucky—you’ll start to feel *proud* of your discipline, not just your profit.

## Patting Yourself on the Back (Literally)  

Imagine you’ve just **stuck to your plan for a whole week**. No impulsive “let’s add a new indicator” moves, no midnight “I’m going to double‑down because the market looks sad.” That’s a **win in the truest sense**. So what do you do? **Reward yourself**!  

- **Small reward:** A nice dinner, a new pair of socks, or a fancy coffee—something that says, “Hey, you’re doing great!”  
- **Bigger reward:** If you manage to follow the plan for a month, maybe splurge on a weekend getaway or a tech gadget you’ve been eyeing.  

The point isn’t the size of the treat; it’s the **association**: *discipline → pleasure*. Over time, you’ll start to **feel good simply by doing the right things**, even when the market is being a drama queen.

## Rewarding the Learning Process  

Trading isn’t just about **buy‑low, sell‑high**. It’s also about **continuous education**. Every hour you spend dissecting a chart pattern, watching a webinar, or reading a research report is an investment in your *future* profitability.  

So, make a habit of **rewarding learning** just like you reward execution:  

- **Finished a course on options?** Treat yourself to a new game or a night out.  
- **Spent two evenings back‑testing a strategy?** Celebrate with a favorite snack and a binge‑watch session.  

These “learning rewards” reinforce the idea that **knowledge is a valuable asset**, just like cash in your brokerage account.

## The Long‑Term Payoff of an Alternative Reward System  

At the end of the day (or after you’ve closed those 3 p.m. candles), the **only thing that truly matters** is whether you’ve built a **reliable, repeatable process** that can survive any market regime. The **short‑term profit or loss** is just a side effect—think of it as the *tip* you get when you’ve already delivered a great service.  

If you keep your focus on **process and learning**, you’ll eventually become that trader who can **stay calm during a market crash and stay disciplined during a rally**. Your mood won’t swing like a pendulum anymore; instead, it’ll be as steady as a **bond‑fund yield**.  

So, stop treating every trade like a personal drama and start treating **discipline and education as the real rewards**. Set up that alternative reward system, give yourself a high‑five for each disciplined step, and watch your trading confidence (and eventually, your profits) climb—without the emotional rollercoaster that makes you want to scream “I’m out!” at every red candle.  

**Bottom line:** When you reward *how* you trade, not *what* you make, you become the kind of trader who can **laugh at a loss, smile at a win, and still stay in the game** for the long haul. Cheers to that! 🍻  