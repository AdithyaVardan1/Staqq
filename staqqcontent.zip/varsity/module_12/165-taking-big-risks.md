# 165. Taking Big Risks  

**Source:** https://zerodha.com/varsity/chapter/taking-big-risks/

---

Some folks spend their whole lives treating risk like it’s a daily latte—just another habit they can’t quit. They swagger around with rock‑solid confidence, acting as if the universe has already handed them the cheat code and they’ve got *nothing* to lose. Then there are the other half of humanity, the “I‑don’t‑like‑roller‑coasters‑and‑I‑never‑bet‑on‑the‑stock‑market” crowd. Their aversion to risk usually stems from a cocktail of past missteps, a modest tally of wins, and a mental scrapbook full of roadblocks they’ve *almost* cleared.  

Fear of taking a gamble isn’t just a lack of confidence; sometimes it’s a sneaky, subconscious dread of **success** itself. Yep, you heard that right—people can be scared of doing well. It’s like being terrified of getting a promotion because now you have to learn how to use the fancy office espresso machine.

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/03/20061212-300x300.png)

### Why would anyone want to dodge success?  

Let’s be honest: most of us day‑dream about the classic “happily‑ever‑after” package—an attractive partner, kids who actually clean their rooms, and a bank account that makes the IRS weep. Even the most zen monk would probably whisper, “If I found a genie, my first three wishes would involve a yacht, a private island, and a tax‑free retirement.”  

I’m not saying money is the holy grail, but if a magic lamp appeared, the majority of us would probably wish for a *lot* of it. The point is, people **do** want success. The snag appears when the shiny, ideal‑world version of ourselves (the “I can have it all” fantasy) collides with the gritty reality of what we can actually achieve with our current skill set, capital, and time.  

### The hidden love‑hate relationship with winning  

Humans are weird creatures: we love the thrill of winning, but we absolutely loathe the sting of losing. Behavioral economists call this “regret aversion,” which basically means we’d rather stay home than risk a decision that could haunt us later. In trading, this shows up as a sneaky self‑sabotage habit: “I’ll just pick the first trade that shows up, because if it blows up I can blame the market, not my own laziness.”  

People with shaky confidence often cling to a safety net made of *excuses*. The classic line? “I could have made it if I’d just tried harder.” It’s a comfortable story because it lets you preserve face while still feeling like a potential winner. Why would you voluntarily jump into a risky trade, risk a loss, and then have to live with the regret that follows?  

### The “never‑risk‑anything” paradox  

If you never take a risk, you can forever chant, “I could’ve been a millionaire if I’d only tried that one trade.” That mantra might sound motivational, but it’s actually a long‑term career‑killing mantra. Instead of hunting for high‑probability setups, risk‑averse traders grab the first shiny signal that flashes on their screen, then rationalize any failure with, “If only I’d put in more effort.”  

Other classic self‑sabotage tricks include trading “by the seat of your pants” (aka wing‑it‑style) instead of drafting a solid trading plan, sticking to it, and reviewing it later. The excuse becomes a protective shield against regret, but the shield is as flimsy as a paper umbrella in a monsoon.  

### How to outwit your inner excuse‑generator  

1. **Adopt a realistic optimism.** Think of it as the Goldilocks approach: not too naïve, not too cynical—just *just right*.  
2. **Don’t buy the “I’ll turn $10,000 into a few million in 12 months” fairy tale** unless you’ve actually found a genie. Statistically, turning a modest sum into multi‑millions in a year is about as likely as being hit by a meteor while winning the lottery.  

   - The math is simple: to grow $10,000 to $2,000,000 in 12 months you’d need a **20,000%** return—roughly a 200‑times multiplier. Even the most aggressive hedge funds rarely achieve a 30‑40% annual return over a full year.  

3. **Embrace the “winning trader” mindset, not the “virtuoso trader” fantasy.** You don’t have to be the Wolfgang Amadeus Mozart of market charts; you just need to be consistently on the right side of the trade more often than not.  

4. **Put in the work.** Realistic expectations + disciplined effort = a recipe for satisfaction (and a healthy bank balance).  

### Bottom line: Stop the day‑dream‑loop, start the action‑loop  

- **Quit fantasizing** about buying a private jet tomorrow if you can’t even afford the monthly Netflix subscription today.  
- **Kick the sabotage habit** out the door. When a trade goes south, own the mistake, learn from it, and move on.  
- **Celebrate the wins**, however modest. Got a 2% profit on a $5,000 position? That’s a win—high‑five yourself!  
- **Align expectations with reality.** If you’re realistic, you’ll avoid the bitter aftertaste of disappointment and, paradoxically, you’ll join the elite club of *profitable* traders—those rare unicorns who actually make money after the fees.  

In short, keep dreaming (just not about turning pocket‑change into a billionaire’s fortune overnight), stop feeding your inner excuse‑machine, and treat trading like a marathon, not a sprint. With a clear plan, realistic goals, and a sprinkle of humor, you’ll find yourself on the path that most people *talk* about but few actually walk. Cheers to taking the right kind of risk—one that’s big enough to grow your account, but not so big that it makes you need a therapist after every loss. 🍻