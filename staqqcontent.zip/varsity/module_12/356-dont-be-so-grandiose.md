# 356. Don’t Be So Grandiose  

**Source:** https://zerodha.com/varsity/chapter/dont-be-so-grandiose/  

---  

## The mindset you need (and why it matters)  

Think of trading like a long‑distance road trip with a temperamental GPS. Even the best‑crafted route‑planner can throw you off a cliff if you ignore the warning signs. A confident, optimistic attitude is the fuel that keeps the engine humming, but **confidence without a reality check is like putting premium gasoline into a lawn mower – it just won’t work.**  

Every trading strategy, no matter how back‑tested, is fallible. Markets are messy, news‑driven, and sometimes just plain moody (think of them as the teenage version of your uncle’s stock‑picking advice). When losses hit, traders with a shaky mindset tend to spiral into disappointment faster than a cat on a hot tin roof. If you can’t step back, objectify the process, and keep your cool, your emotions will swing in lock‑step with the numbers in your account— and that’s a recipe for sleepless nights and questionable haircut choices.  

The antidote? **Become a skill‑machine.** The more you practice across different market climates—bull, bear, sideways, “what‑the‑heck‑is‑this‑crypto‑crash‑again”—the more you’ll trust your own competence. That trust isn’t some mystical aura; it’s the hard‑earned self‑confidence that comes from *actually* being good at what you do. Yes, it’s hard work, it takes time, and it demands persistence (and maybe a few extra espresso shots). But it’s the only proven path to consistently profitable trading. Some folks seem to be born with rock‑solid self‑esteem—like that friend who never flinches when the bartender drops the tray—and they handle the market’s tantrums like it’s nothing.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/06/20060407-300x300.png)  

## When self‑esteem wavers like a cheap Wi‑Fi signal  

Not everyone is blessed with that unshakeable ego. Many traders have tried a new hobby—say, salsa dancing or pottery—and flopped harder than a pancake in a windstorm. Those early failures stick around like that one bad song you can’t get out of your head, dragging down self‑worth long after the activity is over.  

When such a person steps into the trading arena, they’re juggling **two** heavy burdens: a lingering feeling of personal inadequacy **and** the chaotic, unpredictable nature of the markets (which even the world’s sharpest minds sometimes misread). To survive this double‑whammy, the brain whips out a set of “ego‑protective” tricks. One popular (and painfully obvious) trick is to **pretend you’re a natural‑born trader**—think “I was born with a built‑in chart‑reading radar.”  

These grandiose self‑portraits act like a flimsy shield. Internally, the trader whispers, “I’m not incompetent; look how self‑assured and naturally skilled I am.” The problem is, **they’re not genuinely confident**. Their swagger is a costume, and the moment a loss appears, the mask slips. The resulting emotional explosion can be as dramatic as a reality‑TV showdown: anger, frustration, and a sudden urge to throw the computer out the window.  

Because the grandiosity is just a **defensive plaster over a fragile ego**, any contradiction (i.e., a loss) feels like a personal attack. The swing from “I’m invincible!” to “I’m a complete disaster!” can be faster than a high‑frequency trade.  

## Science backs up the drama (thanks, psychologists)  

Psychologists **Rhodewalt and Morf (1998)** ran a clever experiment that reads like a plot twist in a sitcom. They sorted participants into two camps:  

1. **Grandiose group** – people who view themselves as super‑competent.  
2. **Accurate‑view group** – people with a realistic self‑assessment.  

Each participant took **two consecutive intelligence tests** that were deliberately tough (think “find the hidden pattern in a sea of nonsense”). Because the items were hard, nobody could be sure they’d gotten any of them right.  

Here’s where the researchers got sneaky: they **controlled the feedback**. Some got told, “You bombed Test 1 but aced Test 2.” Others heard the opposite—“You crushed Test 1 and flunked Test 2.”  

**Result:** The grandiose folks erupted with **extreme anger, frustration, and disappointment** when they were told they had failed—especially when the failure came **after** a supposed success. In contrast, the accurate‑view participants kept their cool, shrugging it off like a seasoned poker player after a bad hand.  

What does this mean for traders? People who **puff themselves up** to hide low self‑esteem become emotionally volatile. After a winning trade they feel “unstoppable,” but a losing trade can plunge them into a black hole of despair. Those mood swings are the exact opposite of what you need when the market throws you a curveball.  

## How to shrink that ego balloon (without popping it)  

The first step is to **admit** you’re using grandiosity as a crutch. Think of it as catching yourself mid‑self‑praise and saying, “Whoa, hold up—am I really that good, or am I just covering up a fear of being wrong?” Once you own that, you can start building a **realistic self‑image** grounded in data, not daydreams.  

One of the most **foolproof, ego‑friendly tools** is a **trading diary**—your personal, unbiased referee. Jot down every trade: entry, exit, position size, reason for taking it, and the exact outcome (including slippage, commissions, and the occasional “I swear I saw a bullish divergence”). Then calculate **objective metrics** such as:  

- **Win‑loss ratio** (e.g., 45 wins vs. 55 losses = 0.82).  
- **Average R‑multiple** (how many times your target profit you actually captured).  
- **Maximum drawdown** (the biggest dip in equity, expressed as a percentage).  

Seeing these numbers laid out in black and white strips away the rose‑colored glasses. You’ll discover where you’re truly excelling and where you’re just “winging it.”  

Relying on **subjective self‑assessments** is like asking a mirror that only tells you “You look great!”—it’s biased and serves the ego’s need for validation. By confronting the hard facts, you free up **psychological bandwidth** that was previously spent defending a fragile self‑image. That energy can now be redirected toward **skill development**, risk management, and maybe even a better coffee blend.  

In short: **admit your flaws, log them, and work on them.** The moment you stop hiding behind a grandiose façade, you’ll feel lighter, calmer, and—most importantly—more profitable.  

---  

*Bottom line:* Grandiosity is a fancy word for “I’m wearing a superhero cape because I’m scared of being ordinary.” Take the cape off, grab a notebook, and let the numbers tell you who you really are. Your future self (and your trading account) will thank you.  