# 210. The Quest for Consistency  

**Source:** https://zerodha.com/varsity/chapter/the-quest-for-consistency/  

---  

Two buzz‑words that pop up every time you wander into a trader’s chatroom are **consistency** and **discipline**. Think of a winning trader as that friend who always shows up to the potluck with a perfectly baked cake—every single time. In trading terms, that means *consistent profits*.  

Now picture the rookie trader’s equity curve. It looks a lot like a roller‑coaster that a five‑year‑old built from popsicle sticks—big spikes, deep valleys, and a lot of screaming. The line is jagged, mostly heading downhill, and every high feels like a one‑night‑stand: fun while it lasts, but you wake up with a headache.  

A seasoned trader, on the other hand, draws a smooth, upward‑sloping line—more “slow‑cooker” than “microwave”. That doesn’t mean they never get a hot streak or a cold snap; they just don’t let those moods run the show.  

> ![Image](https://zerodha.com/varsity/wp-content/uploads/2020/04/20060831-300x300.png)

They don’t **throw** their trading plan out the window in a panic, they don’t flail around like a cat on a hot tin roof, and they certainly don’t rack up a shopping list of trading errors. When the market hands them a golden opportunity—say, a perfectly timed breakout—they grab it, hold it, and let it do the heavy lifting. Over months and years, those small, disciplined grabs add up, and the profit meter ticks upward. The more you can trade like a robot programmed for consistency (but with a human brain for the jokes), the fatter your wallet gets.

## How to Trade More Consistently  

### 1. Write a trading plan that even your grandma could read  

The first step toward consistency is to **draft a crystal‑clear trading plan** and then *pretend* you’re a secret agent who never deviates from the mission. Discipline, in this context, simply means *following* that plan day in, day out.  

Veteran traders have the luxury of intuition—they can glance at a chart and instantly know whether to stick to the script or toss it aside. A newbie, however, is still learning the language of “intuition” and must rely on **well‑defined entry and exit rules**. Think of it like a recipe: you can’t just throw in a pinch of salt and hope for a Michelin star.  

### 2. Embrace the law of large numbers (your new best friend)  

Trading, at its core, is a numbers game. The **law of large numbers** tells us that if you make enough *independent* trades, the average result will converge toward the expected value. In plain English: make many trades, do it *consistently*, and the randomness will smooth out. It’s like flipping a coin a thousand times—you’ll get roughly 50% heads, not “all heads after the first ten flips”.

So the goal: **enter trades with discipline, repeat the process over and over, and let probability do the heavy lifting**. Some of those trades will be winners, some will be losers, but if your edge is positive, the winners will outnumber the losers enough to keep you in the black over a series of trades.

## The Emotional Minefield  

### 3. Why novices get tripped up  

Here’s the classic sitcom plot: a trader feels a *twinge* of excitement, decides to jump in before the market is ready, or slams the exit button because fear whispers, “Don’t lose that money!” Even a perfectly engineered plan can be tossed aside when **greed** or **fear** barges in like an over‑enthusiastic party guest.  

The result? You lose money **even when the market is doing exactly what your strategy loves**—because you quit early. Then, when the market shifts to a regime that *doesn’t* suit your method, you lose even more because you’re now playing a losing game with a nervous mind.

Sure, every now and then you’ll catch that “everything clicks” moment and ride a profit wave. But those moments are as fleeting as a good Wi‑Fi signal in a crowded cafe.  

### 4. Taming the beast inside  

- **Spot the red flag**: If you feel a knot in your stomach or a sudden urge to “just go for it,” pause.  
- **Take a breather**: Some traders swear by a day off—just step away, binge‑watch a sitcom, or take a walk. Others hit the gym or meditate. The idea is to lower the cortisol level so your brain can think, not just react.  
- **Risk management is the ultimate chill pill**: If a single trade can’t wipe out a meaningful chunk of your account, you’ll stay calmer. Think of each trade as a tiny coffee sip instead of a full‑on espresso shot that could jitter you into a panic.  

And remember: **never trade beyond your skill level**. Trying to pull a rabbit out of a hat you’ve never practiced with is a recipe for disaster.

## Building a Bullet‑Proof Arsenal  

### 5. Start small, stay safe  

When you’re just starting, stick to what you *know*. That builds **confidence** and **skill**—two ingredients you’ll need when the market throws curveballs.  

Seasoned pros carry a few “foolproof weapons” in their trading toolbox:  

- **A reliable setup** that has shown edge over many market cycles.  
- **Position sizing rules** that keep risk per trade low (often 1–2% of equity).  
- **A stop‑loss strategy** that limits the downside before you even realize you’re in trouble.  

Knowing you have a plan to **recoup** a loss (e.g., by scaling back, adding a contrarian trade, or simply waiting for the next high‑probability setup) gives you a sense of freedom. It’s like knowing you have an extra set of keys hidden under the mat—less panic when you lock yourself out.

### 6. Practice, practice, practice (but not with your rent money)  

Treat the early stages like a **sandbox**: trade with money you can afford to lose, keep the stakes tiny, and focus on *process* over *profit*. Over time, you’ll notice your **discipline muscle** getting stronger.  

When you finally feel comfortable, you can slowly increase position size—still respecting your risk limits—until you’re ready to handle larger swings.  

## Bottom Line: The Long‑Run Profit Playbook  

- **Trade with money you can afford to lose** – no one likes a sleepless night worrying about rent.  
- **Manage risk like a cautious accountant** – small, consistent bets keep the heart rate low.  
- **Stick to a written plan** – think of it as your trading bible; read it, love it, obey it.  
- **Control emotions** – whether you meditate, lift weights, or binge‑watch cat videos, find a habit that keeps the fear‑greed seesaw balanced.  
- **Build skills before scaling** – master a few high‑probability setups before adding complexity.  

If you can weave all these threads together, you’ll eventually become that trader who shows up to every market “potluck” with a perfectly baked cake—again and again. And that, my friend, is the sweet taste of **consistency** and **discipline** that keeps the profit meter climbing for the long haul. Cheers to steady gains and fewer heart attacks! 🍻