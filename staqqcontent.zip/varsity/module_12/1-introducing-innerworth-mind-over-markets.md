# 1. Introducing **‘Innerworth – Mind over Markets’**

**Source:** https://zerodha.com/varsity/chapter/introducing-innerworth-mind-over-markets/

---

Most folks dip their toes into the market because they’ve seen the glittering promise of “easy money” on Instagram reels and think “Hey, I can be the next Warren Buffett in my pajamas.”  The harsh reality, however, is that the stock market is arguably the toughest gym for your wallet—no fancy equipment, just pure emotional cardio. To survive, you need a solid strategy that can evolve faster than a teenager’s TikTok trends, and you have to keep it profitable over **hundreds** of trades. Every single trade is a little psychological experiment: you must keep greed, fear, and pride from hijacking your decisions, make the winners count more than the losers, and still wrestle with sky‑high transaction costs and market impact.  

As you might have guessed, the success rate is about as slim as the line at a food‑truck that only serves avocado toast. Think of it this way: for every thriving restaurant on your street, there are probably a **hundred** that have turned their ovens into storage closets. The same pattern shows up in trading— for each consistently profitable trader, there are **hundreds** who end up eating dust. What makes trading especially risky is its low barrier to entry. Anyone with a laptop and an internet connection can start, unlike opening a brick‑and‑mortar business that demands permits, capital, and a lot of sleepless nights.  

Most traders obsess over charts, balance sheets, and the latest “guru” who promises the perfect buy‑sell signal. Spoiler alert: there is no *holy grail* here. Every system, every advisor, every crystal‑ball‑looking indicator can lose money when the market decides to be a drama queen. The truly decisive factor isn’t *when* you click “buy” or “sell,” but **what you do before, during, and after**. The price of the stock you’re eye‑balling is out of your hands—what *you* do with it is the only thing you control. Yet, the whole “psychology” bit is the wallflower of trading talk. Understanding how your own mind works—your identity, beliefs, and habits—while you’re in the thick of the market is just as crucial as mastering fundamentals, technical patterns, or finding the next hot tipster.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2019/11/M12C1.png)

Back in the day when I was still glued to the screen, a US‑based brokerage called **Marketwise** ran a daily newsletter titled **“Innerworth — Mind over Markets.”** Think of it as the “Daily Planet” for trading psychologists, authored by some of the sharpest minds in the biz. The newsletter kicked off in **2002** and ran like a well‑oiled machine until **2007**, when Marketwise was sold and the beloved Innerworth series vanished, taking its treasure trove of wisdom with it. Those articles were my lifeline during those dreaded drawdown periods; they reminded me to stay rational instead of panic‑selling, to rein in greed when the market was humming, and essentially turned me from a jittery rookie into a more composed trader. The content was the Goldilocks of trading psychology—concise, easy‑to‑read, peppered with humor, and always driving home the point that a mental edge is worth its weight in gold.  

I’ve harbored a quiet obsession with sharing this gem with Indian traders for years. After a treasure‑hunt that would make Indiana Jones proud, we finally tracked down **David Nassar**, the original promoter of Marketwise, and managed to convince him to part with the publishing rights to every single Innerworth article.  

Fast‑forward through a few more years of waiting (and a few extra cups of chai), and we’re **ecstatic** to re‑launch *Innerworth — Mind over Markets*—a brand‑new series of articles dedicated to the psychology side of trading. To start the party, we’re rolling out **50** fresh articles across various categories in the Innerworth module on Varsity, and we’ll keep adding more as we go.  

A massive shout‑out to **Prateek from LearnApp** (our learning partner) for playing the diplomatic role, tracking down David, and sealing the deal with a handshake and a smile. 🙂

**Start reading now!**  

Happy Trading,  
*— Nithin Kamath*  