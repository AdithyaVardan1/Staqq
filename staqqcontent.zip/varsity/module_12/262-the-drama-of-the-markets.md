# 262. The Drama of the Markets  

**Source:** https://zerodha.com/varsity/chapter/the-drama-of-the-markets/

---

> *“Drama is the antidote to the soul‑crushing monotony of everyday life.”* – Dr. Karl E. Scheibe (probably while sipping a latte)

If you’ve ever tried to count the number of psychological theories that try to explain why we do what we do, you’d think someone’s been tossing dice into a vat of ink and calling the resulting blobs “theories.”  Every new psych professor seems to want a shiny, one‑of‑a‑kind model to out‑shine the rest.  A handful of those brainiacs have taken a detour into finance, slapping their theories onto stock‑market behaviour and calling it *investment psychology*.  

But Dr. Karl E. Scheibe, a professor at Wesleyan University, decided to flip the script.  Instead of using the market to prove his ideas, he used **investor behaviour** to bolster a grand, all‑encompassing theory about what makes humans tick.  His book *The Drama of Everyday Life* argues that life is basically a series of sitcom episodes we keep re‑watching because—let’s face it—plain old routine is a snooze‑fest.  “Drama relieves human beings from the boredom and sameness of repetition,” he writes, and he points to the stock market as the ultimate stage for our nightly melodrama.

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/05/20060515-300x300.png)

### Fear, Greed, and the “More‑Than‑Just‑Greed” Twist  

You’ve heard it a thousand times: *“Markets are driven by fear and greed.”*  Scheibe says, “Hold my coffee, there’s a twist!”  He spots an **asymmetry**—losses sting harder than gains feel good.  This isn’t just poetic fluff; it’s backed by the Nobel‑winning work of Tversky and Kahneman on risk aversion.  Their classic experiment shows that when given a choice between a guaranteed $100 profit and a 50 % chance of $200, most people pick the safe $100.  Why? Because the pain of possibly walking away empty‑handed outweighs the joy of possibly doubling your money.

What does that mean for the average trader?  In plain English: **people lose more than they win**.  The fear of a loss pushes us to slam the “sell” button the moment a paper‑cut starts bleeding, while the ever‑hungry greed monster whispers, “Buy it back, you’ll make it up later!”  The result is a perpetual loop of premature exits followed by fresh entries—essentially a financial version of “I’ll be back” that rarely ends in a profit.

### Why Keep Jumping Into the Fray?  

If the math says we’re bleeding, why do we keep buying tickets to the circus?  It isn’t pure greed—greed is actually the weaker sibling in this family.  Scheibe’s answer: **drama**.  We’re bored, we crave excitement, and the market provides a ready‑made soap opera.  

1. **Excitement**: The prospect of a big win makes our hearts race.  
2. **Terror**: The thought of a big loss makes us clutch our wallets.  
3. **Sell‑and‑Buy Cycle**: Fear forces us to bail; boredom later nudges us back in.  

And so the drama repeats, episode after episode, like a Netflix series you can’t stop binge‑watching even though you know the plot’s going nowhere.

### Even the Pros Need Their Fix  

You might think, “Hey, at least the big‑shot fund managers are immune—they just sit on a spreadsheet and let the index do the work.”  Nope!  Scheibe notes that **even professional money managers chase drama**.  They know, deep down, that **most active funds underperform their benchmarks**.  Statistically, a lazy, low‑cost index fund will match or beat the majority of actively managed portfolios over a year.  

So why don’t they just buy a basket of stocks, go on a beach vacation, and let the money grow while they sip piña coladas?  Because **the drama of trying to beat the index is way more thrilling than doing nothing**.  The title “Fund Manager” sounds cooler than “Passive Investor,” and the daily grind of market‑watching satisfies that craving for excitement—much like a reality‑TV star who can’t quit the spotlight.

### Is Scheibe’s Take Anything New?  

Probably not a breakthrough for the seasoned behavioural economist—everyone knows markets are a mirror of collective fear and greed.  What **is** fresh is the *why*: we’re not just chasing money; we’re hunting drama to stave off boredom.  That’s a reasonable, if slightly theatrical, explanation for why the “average Joes” keep dangling their savings on Wall Street.

### What Can the Professional Trader Do With This Insight?  

1. **Read the Crowd**: Understand that the masses are looking for thrills.  When panic sells, they’re selling too early; when euphoria peaks, they’re buying at inflated prices.  
2. **Position Yourself**: Anticipate those irrational swings and set up trades that profit from the predictable panic‑sell‑and‑buy‑back cycle.  Think of yourself as the bartender who knows when the regulars are about to order another round.  
3. **Self‑Check**: Remember, you’re **human too**.  The same drama‑seeking impulse that drives a rookie trader can also tug at a veteran’s sleeve.  

The key is to **channel your own need for excitement elsewhere**.  Trading, at its core, is a disciplined, often repetitive process—think of it as a marathon, not a roller coaster.  If you feed your thrill‑seeker with a hobby (skydiving, salsa dancing, extreme couponing), you can keep the trading plan nice and boring, exactly how it should be.

### Bottom Line  

The markets will always be a stage for human drama; the lights are bright, the stakes feel huge, and the plot twists are endless.  As long as you keep your **personal drama** out of the spreadsheet, you can stay professional, stick to your strategy, and let the market’s own theatrical antics work for—rather than against—your pocket.

So go ahead, enjoy the show, but remember: **your trading plan is the script, not the improv**.  Keep the drama on the dance floor, the movie theater, or the next adventure sport you try, and let the market be the background music to your financial life. Cheers! 🍻