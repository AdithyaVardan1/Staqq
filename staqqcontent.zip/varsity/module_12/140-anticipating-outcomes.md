# 140. Anticipating Outcomes  

**Source:** https://zerodha.com/varsity/chapter/anticipating-outcomes/  

---  

Our emotions are basically the side‑effects of the expectations we set for the world.  
Picture this: you’ve just survived an extra‑hour‑long slog through rush‑hour traffic, you’re still half‑caffeinated, and you’re dreaming of a warm hug and a plate of your spouse’s famous lasagna. Instead, you walk in to a “where‑were‑you‑when‑dinner‑was‑ready?” scolding that could melt the cheese on that lasagna. You’re angry, you’re hurt, you’re *why‑did‑I‑even‑bother*‑level upset. The mismatch between what you **expected** (love, food, applause) and what actually **happened** (reproach, empty stomach) triggers an emotional—often impulsive—reaction.  

Trading is a textbook case of this expectation‑versus‑reality drama. Humans are wired to love winning, to chase that dopamine hit, yet the markets love to hand out loss after loss to the unprepared.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/02/01-218x300.png)  

In the trading world you should start every day with the **assumption that you’ll see more losers than winners**. If you go into the market thinking you’ll win every trade, you’re basically signing up for a disappointment‑festival rather than a celebration. For a rookie trader, that reality check can feel like a slap in the face and a source of chronic stress.  

But hey, trading isn’t the only job that hands you a steady diet of “no‑thank‑you” outcomes. Lots of professionals have to swallow daily doses of distress and learn to live with it. By peeking into how other folks deal with their own unpleasant realities, you might discover a fresh way to stare down a string of losing trades without turning into a nervous wreck.  

---

## Expectations shape coping, outcomes shape mood  

Think about a classic commuter gripe: **“Other drivers are terrible!”**—they cut you off, speed like they’re auditioning for *Fast & Furious*, and change lanes like they’re playing musical chairs. If you cling to the belief that **“Everyone should obey every traffic rule perfectly”**, you’re setting yourself up for a full‑blown case of road‑rage the moment a car merges without signalling.  

Now imagine a police officer or a long‑haul truck driver who starts the shift with that same crystal‑clear expectation. The world would be a utopia if every driver behaved like a textbook example, but reality loves to sprinkle a few rule‑breakers into the mix. Assuming that flawless behavior is realistic just makes the inevitable slip‑ups feel *personal* and intensifies frustration.  

The same principle pops up in hospitals. A nurse or ER doctor who expects a calm day with a handful of minor cuts and sprains will feel **extra** stressed when the trauma bay suddenly fills with gunshot wounds, severe heart attacks, and a chorus of “I can’t breathe!” alerts. Their original expectation turns the actual chaos into a personal failure rather than a job‑hazard.  

Firefighters aren’t immune either. Picture a fire‑crew chief who thinks a raging Santa‑Ana‑wind fire can be doused with a few generous hose blasts. When the flames keep licking the sky despite heroic effort, the chief’s disappointment is magnified because the expectation was *unrealistic* rather than *challenging*.  

These examples show a universal truth: **If you set expectations that are too rosy, setbacks become paralyzing.** The right mindset is the antidote.  

---

## The trader’s reality check  

As a trader, you need to adopt the same pragmatic lens. Don’t stroll into the market thinking you’ll make easy money by tossing a few half‑baked trades into the ether. The truth is that **good trading opportunities are out there, but you have to hunt for them like a detective on a cold case**—research, chart, back‑test, and rehearse.  

Even after you find a solid setup and execute it, the trade won’t always turn into a win. That’s not a sign that your system is broken; it’s just the market reminding you that randomness is part of the game. If you **realistically anticipate setbacks**, you won’t get blindsided emotionally.  

* Expect a loss → you accept it like a bad haircut—unpleasant but not life‑changing.  
* You’ll be more likely to use proper risk control (stop‑losses, position sizing, etc.) so a single loss can’t annihilate your account.  
* A string of losing trades won’t gnaw at your psyche because you entered each trade with the mental note: “I might lose this one; that’s okay.”  

When you view every trade as a **probability** rather than a guarantee, you bounce back faster, stay in the game longer, and eventually let the winners carry you to the long‑run profit zone.  

---

### Bottom line (served with a side of humor)  

- **Expect the unexpected.** Markets, traffic, ERs, and fire‑stations all love surprises.  
- **Set realistic expectations.** Think “Most days I’ll be fine, some days I’ll be a mess.”  
- **Prepare like a pro.** Research, risk‑manage, and keep a trade journal—your secret weapon.  
- **Accept losses gracefully.** They’re the market’s way of saying “Nice try, pal!”  
- **Stay the course.** Consistency beats occasional glory every single time.  

So the next time you’re staring at a red candle that just ate your stop‑loss, remember: you’ve already done the mental homework. You expected the loss, you managed the risk, and you’re still in the game. That’s the sweet spot where traders turn disappointment into a stepping‑stone rather than a stumbling block.  

Happy trading, and may your expectations be as calibrated as a well‑tuned guitar—just enough tension to make beautiful music, not so much that it snaps! 🎸📈