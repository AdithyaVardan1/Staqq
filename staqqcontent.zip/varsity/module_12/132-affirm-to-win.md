# 132. **Affirm To Win**  

**Source:** https://zerodha.com/varsity/chapter/affirm-to-win/  

---  

Trading can feel like a roller‑coaster that you built yourself—thrilling when the dip turns into a soaring loop, soul‑crushing when the brakes screech and you end up upside‑down on the tracks. One minute you’re high‑fiving your screen because the plan you painstakingly drafted finally clicks, the next you’re muttering “What the heck was I thinking?” while staring at a red‑inked P&L that looks more like a horror movie script. Confidence wobbles, doubts creep in, and before you know it you’re Googling “How to stop being a terrible trader.”  

Enter **affirmations**—the mental equivalent of putting on a superhero cape when the market decides to throw a tantrum. An affirmation is simply a positive, present‑tense statement that reminds you what you’re actually trying to achieve, instead of the catastrophic narrative your brain loves to spin.  

> **Example:** You just blew a few trades, feel like you’ve been punched in the gut, and the whole “I’m a loser” chant is looping in your head. Pull out a sticky note (or your phone) and repeat something like:  

```
I’m human, I make mistakes, and losing trades are just the market’s way of saying “Nice try, buddy.”  
My ultimate goal is steady, enduring profitability—not a single perfect trade.  
The big picture is what matters; a couple of losses are peanuts on a Thanksgiving feast.  
Through hard work, experience, and a dash of humility, I’ll hit my financial milestones.  
```  

Say it enough times and those words start to feel less like a cheesy pep‑talk and more like a genuine reminder of who you are—a trader who’s in it for the long haul, not a one‑hit‑wonder. Suddenly that massive loss feels like a blip, not a career‑ending apocalypse.

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/02/16-300x202.png)

### Crafting Your Own Battle‑Cry  

Affirmations are as customizable as a pizza topping list—pick what you need, ditch what you don’t.  

* **Patience Problem?**  
  *If you keep checking the charts every five seconds like a nervous toddler, try something like:*  

  ```
  I have willpower. I am in control.  
  Disciplined traders stick to their plans, and I’m no different.  
  My trading plan is my roadmap; I’ll follow it until the destination appears.  
  Each time I wait for the plan to play out, my self‑control muscles get stronger.  
  Over time I’ll become decisive, steady, and the master of my emotions.  
  ```  

* **Low Self‑Esteem?**  
  *When your self‑worth is tied to the last trade’s profit/loss, untangle that knot with:*  

  ```
  I am a human being, not a spreadsheet. My value isn’t measured by dollars or pips.  
  Wins are nice, losses are learning opportunities—neither defines my identity.  
  Trading is a part of my life, not the whole story.  
  My self‑worth is constant, whether the market smiles or frowns.  
  ```  

### Why They Work (Even If They Sound Silly)  

1. **Re‑programming the Inner Critic** – Your brain loves shortcuts; it will latch onto a repeated phrase and start treating it as truth.  
2. **Shift from “What‑If” to “I‑Am”** – Instead of “What if I lose again?” you get “I am capable of handling loss.”  
3. **Automatic Recall** – After a few weeks of consistent repetition, the statements surface on their own—no sticky notes required.  

Think of it like a muscle. At first, flexing your “positivity bicep” feels odd, but after a few reps the soreness fades and you start seeing gains.  

### How to Make Them Stick  

| Step | What to Do | Bar‑Friend Analogy |
|------|------------|--------------------|
| **1️⃣ Identify the pain point** | Pinpoint the exact mental snag (e.g., “I’m scared to hold a trade overnight”). | “What’s the one thing that makes you spill your beer?” |
| **2️⃣ Write a present‑tense, positive statement** | Keep it short, specific, and actionable. | “Instead of ‘I hope I don’t spill,’ say ‘I keep my drink steady.’” |
| **3️⃣ Repeat, repeat, repeat** | Say it aloud, write it on a post‑it, set a phone reminder. | “Shout it every time you walk past the bar tab.” |
| **4️⃣ Pair with action** | Align the affirmation with a concrete habit (e.g., “I’ll review my trade journal after every session”). | “Every time you finish a drink, you’ll also check your tab.” |
| **5️⃣ Review weekly** | Adjust wording if it feels stale or inaccurate. | “If the joke’s old, swap it for a fresher punchline.” |

### The Bottom Line (No, Not the Market Bottom)  

Affirmations aren’t magic beans that instantly turn a losing streak into a profit parade, but they are the *mental fertilizer* that helps your confidence grow. By consistently feeding your brain with statements that echo your true goals—steady profitability, disciplined execution, and a healthy self‑image—you train yourself to react to market noise with calm rather than panic.  

Give it a shot: pick one affirmation that resonates, repeat it for a week, and notice how the “what‑if” chatter quiets down. Before you know it, you’ll be walking into the market with the swagger of someone who knows that a single loss is just a speed bump, not a cliff.  

*Cheers to a winning mindset, and may your trades be as smooth as a perfectly poured draft!* 🍻