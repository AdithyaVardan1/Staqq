# 249. Winning Traders Are Disciplined  

**Source:** <https://zerodha.com/varsity/chapter/winning-traders-are-disciplined/>

---

## The Big Gap Between the “Pro” and the “No‑No”

Picture this: one guy treats the market like a high‑stakes poker night, the other treats it like a math class he never wanted to take. The first is the rookie who thinks “buy low, sell high” means “buy the moment the price dips a teeny‑weeny bit, then sell the instant it wiggles up a smidge.” The second? He’s the seasoned, winning trader who can stare at a screaming candle chart and still keep his cool like a monk on a mountain top.

Why does that happen? It all boils down to **unwavering self‑control** when the market throws a tantrum. Trading isn’t a weekend hobby you dabble in while scrolling TikTok; it’s a serious business that demands a plan, a process, and the gumption to stick to them—no matter how many “once‑in‑a‑lifetime” setups flash on the screen.  

Novices love the thrill. They’ll jump in “by the seat of their pants” faster than a bartender serving a shot at last call. The moment a candle turns green, they’re already reaching for the next trade, convinced they’ve just discovered the secret sauce.  

Seasoned traders, on the other hand, are methodical. They spend nights (and sometimes weekends) sketching a **trading plan**, then they execute it with the same precision a chef uses to flip a perfect omelet. They’re disciplined, they’re controlled, and they understand that **discipline is the secret sauce of success**.  

> **Bottom line:** If you want to win, you’ve got to behave like an accountant on a deadline, not a frat boy at a keg party.

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/04/20060605-300x300.png)

## Why Discipline Is the Golden Ticket

Trading, at its core, is a game of odds. Imagine you have a strategy that, during back‑testing, made money **85 % of the time**. That’s a pretty sweet win‑rate, but it’s still a probability, not a promise. The future could look exactly the same, or a sudden policy change, a geopolitical shock, or even a surprise tweet from a celebrity could flip the odds on its head.  

If you’re sloppy, those occasional “bad days” will turn into **big, ugly losses** because you’ll be tempted to deviate from the plan when things get uncomfortable. That’s where discipline steps in like a bouncer at a club: **it keeps the riff‑raff out** (i.e., impulsive, emotion‑driven trades) and lets only the well‑vetted moves through.

Assuming your edge truly has a high probability of persisting—something you’ve verified with **robust back‑testing, out‑of‑sample checks, and maybe a sprinkle of forward‑testing**—the only way to let the **law of large numbers** work for you is to **apply the strategy over many, many trades**. The more you repeat a high‑probability edge, the closer your real‑world results will hug the theoretical expectation (think of it as the market finally paying you back for all the homework you did).

- **Disciplined trader:** “I trust my system, I allocate the pre‑determined position size, I set the stop‑loss, I walk away.”  
- **Undisciplined trader:** “Whoa, the market’s jittery, let me cut my stop tighter, double the size, and maybe add a side‑bet just for fun.”  

That wavering is the fastest route to a blown account. In short, **discipline is the lever that converts a good edge into a great profit stream**.

## The Personality Side‑Show: Discipline vs. Risk Appetite

Psychologists have been chewing on discipline and self‑control for decades. Some folks are naturally **hyper‑disciplined**—they pay every credit‑card bill on the exact due date, their socks are color‑coordinated, and they have a spreadsheet tracking the exact number of minutes they spend on YouTube each week.  

These people would be dream candidates for a trading desk—if they could also tolerate a **tiny sprinkle of uncertainty**. The problem? Over‑discipline can make you **risk‑averse**. Trading isn’t about “sure things”; it’s about **probabilistic things**. You need to be comfortable with the idea that a 70 % winning strategy will still lose 30 % of the time, and that those losses can be bigger than the wins on a per‑trade basis if you don’t size correctly.

Most successful traders sit somewhere in the middle: they **respect the rules** but also **embrace calculated risk**. They’re like that friend who always orders the same craft beer because they know they love it, yet they’ll try a new IPA once a month just to keep things interesting.

So ask yourself: **where do you land on the discipline‑risk spectrum?**  

- Do you **pay your rent on time** but **blow your entire account on a single “sure‑fire” trade**?  
- Or are you the type who **never misses a deadline** but **refuses to take any position larger than 0.1 % of your equity**, even when the odds are in your favor?

## Self‑Check: How’s Your Discipline Game?

Let’s bring the bar vibe to a quick “drink‑order” self‑audit. Grab a notebook (or the back of a napkin) and answer these, honestly:

1. **Trading Plan Commitment** – Do you have a written plan that covers entry, exit, position sizing, and risk management?  
2. **Plan Adherence** – In the past month, how many times did you deviate from that plan? (Give yourself a score: 0 = never, 5 = every trade.)  
3. **Everyday Discipline** – Are you **late for appointments** more than once a week?  
4. **Budget Discipline** – Do you **spend more than your monthly budget** on pizza, gadgets, or spontaneous vacations?  
5. **Promise‑Keeping** – How often do you **break promises** you make to friends, family, or yourself?  

If you’re ticking “yes” on the last three, you might have a **discipline deficit** that could bleed into your trading. The good news? **Discipline is a muscle**—the more you work it, the stronger it gets.

## The “Control‑Everything” Experiment

Here’s a fun (and slightly terrifying) challenge: **pretend you’re a “discipline ninja” for the next 2‑3 weeks**. Pick three non‑trading arenas where you usually let impulses run wild, and put a lock on them. Some ideas:

| Area | What to Control | How to Track |
|------|----------------|--------------|
| **Calories** | Eat only what you’ve pre‑planned for the day (no midnight pizza raids). | Log meals in a phone app or on paper. |
| **Spending** | Stick to a **strict budget**—no impulse Amazon buys. | Keep receipts, or use a budgeting app that flags over‑spending. |
| **Leisure Time** | Limit binge‑watching to **1 hour per night**. | Set a timer on your phone and shut down the TV when it rings. |

**Why does this help?** Because discipline in one domain reinforces the neural pathways that make self‑control easier elsewhere. Think of it as cross‑training for your willpower. After a few weeks you might be amazed at how much more **“in‑the‑zone”** you feel when you sit down at your trading screen.

### A Quick Reality Check

- **You might discover you’re a “control‑phobe”**—someone who goes off the rails the moment a rule feels too tight. That’s a clue that you need to **gradually tighten the reins**, not yank them all at once.  
- **You could also find you’re actually pretty disciplined**, just not aware of it. In that case, give yourself a high‑five and channel that confidence into a solid trading plan.

## Bottom Line: Discipline Is the Secret Sauce (Again)

If you’ve made it this far, you already know that **discipline isn’t a fancy buzzword**—it’s the **engine** that turns a statistical edge into real‑world profits. The market will always be chaotic, emotional, and occasionally cruel. The only thing you can control is **your own behavior**.

So here’s the action plan, served on a cocktail napkin:

1. **Write a concrete trading plan** (entries, exits, risk per trade, max daily loss).  
2. **Commit to it**—no matter how “perfect” a setup looks, if it’s not in the plan, stay out.  
3. **Train your self‑control** in everyday life for a couple of weeks.  
4. **Review weekly**: Did you stick to the plan? Did your non‑trading discipline improve? Adjust accordingly.  

Remember, a disciplined trader is not a robot; he’s a **human who has learned to tame his inner monkey**. The next time the market tries to pull your hair, you’ll be the one calmly sipping a coffee and saying, “Nice try, market, but I’ve got a plan and I’m sticking to it.”  

**Cheers to disciplined trading—and to finally getting that “late‑to‑appointments” habit under control!** 🍻