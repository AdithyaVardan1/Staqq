# 265. Just Drop It and Move On  

**Source:** https://zerodha.com/varsity/chapter/just-drop-it-and-move-on/

---  

We all know the old chestnut: *learn from your mistakes*—otherwise you’ll end up making the same blunder twice and wonder why your portfolio looks like a roller‑coaster after a kid’s birthday party. In everyday life that advice is gold; you don’t want to drive into a pole twice, you don’t want to wear white after a spaghetti dinner twice, right?  

But in the wild, fast‑paced world of trading, the “don’t repeat the mistake” mantra can sometimes become a **paralysis‑by‑analysis** nightmare. Sure, you shouldn’t be the guy who throws 80 % of his capital at a single, sinking position—one such disaster is enough to teach you that betting the farm on a losing trade is a bad idea. However, there’s a point where you start turning your post‑trade journal into a crime‑scene investigation, replaying every tick in your head like a bad Netflix binge. You’ll waste hours, brain‑cells, and probably a few beers, and you’ll still be exactly where you started: staring at the same red candle.  

When it comes to trading, the healthiest thing you can do is often to **just drop it and move on**.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/05/20060210-300x300.png)

---

### The “Think‑Everything‑Through” Trap  

A good decision‑maker does their homework—research, compare alternatives, run the numbers—before signing the dotted line. In trading, that homework has a deadline that’s usually measured in minutes, not months. Once you’ve scoped out the obvious red flags (think looming Fed rate hikes, an earnings beat‑or‑miss that could swing sentiment, or a geopolitical flare‑up), you’ve already spent the bulk of your useful analysis. The market won’t wait for you to finish your 500‑page dissertation on why the S&P 500 might dip tomorrow.

What you *don’t* have is an infallible crystal ball. If you could magically pull “perfect, comprehensive information” out of a hat, you’d probably be the next Warren Buffett and you’d never have to worry about a stop‑loss. Unfortunately, short‑term trading works on **time‑sensitive windows**—you get a few seconds to minutes to act, not a week to draft a PowerPoint. So the moment you’ve filtered out the big‑picture risks, it’s time to click that “Buy” or “Sell” button and let the trade run its course.

---

### Practice Makes… Actually, It’s Not Just About Practice  

Think about learning a golf swing or a tennis serve. You don’t spend a year staring at your own video replay, wondering whether you should have turned your hips a half‑degree more. You go out onto the green or the court, you hit balls, you make mistakes, you adjust, and you repeat. The repetition builds muscle memory; the mistakes become data points.  

Trading is the same, only the “ball” is a market order and the “court” is a constantly shifting price chart. The more **real‑world trades** you execute—preferably across different market regimes (bull, bear, sideways, you name it)—the better you’ll internalise the feel of a tight spread, the sting of a slippage, the rush of a clean fill.  

That said, many of us have a natural tendency to hit the brakes. “What if I lose money?” becomes a mantra louder than the market’s ticker tape. Human psychology is hardwired for loss aversion: we hate the pain of losing more than we love the joy of gaining. That fear can freeze you at the decision point, turning you into a spectator instead of a participant.

---

### Winners Embrace the Risk (and the Tuition Fee)  

The good news? Winning traders have learned to **lean into that risk** rather than dodge it like a toddler avoids broccoli. They’re comfortable putting a modest slice of capital on the line, because they know experience is the only thing that can’t be bought on Amazon.  

Every trade you take—whether it ends in a modest profit, a small loss, or a “what‑the‑heck‑did‑that‑just‑happen?”—adds a line to your personal textbook. If you cap your risk (say, a 1‑2 % loss per trade) the “tuition” you pay stays manageable. Think of each loss as a tuition fee for the School of Hard Knocks; the more you pay, the quicker you graduate to a seasoned trader.  

---

### The Skill‑Master Analogy (With a Dash of Humor)  

Picture this: you decide to become a master chef. You don’t spend months debating whether to use a whisk or a spatula for your first omelette. You crack a few eggs, you over‑salt a few, you maybe set off the smoke alarm, but you keep cooking. Over time, you learn which pan heats evenly, how to taste and adjust, and eventually you can whip up a soufflé without breaking a sweat.

Trading works the same way. Mastery = **practice + reflection + iteration**. The reflection part is crucial, but it’s a *quick* post‑mortem, not a full‑blown therapy session. “What went wrong?” → “What can I tweak next time?” → **Back to the market**.  

If you let a single loss linger in your mind like a bad song stuck on repeat, you’ll never get to the next “track.” So when a trade goes south, give it a polite nod, tip your hat, and say, “Thanks for the lesson,” then **drop it and move on**.

---

### Bottom Line: Keep the Momentum Going  

- **Analyze just enough:** Spot the big‑picture risks (rate hikes, earnings, news) and stop there.  
- **Act fast:** The market’s window is short; hesitation costs you more than a slightly imperfect entry.  
- **Trade often:** Volume builds intuition; trade across different market climates to become versatile.  
- **Control risk:** Limit each trade to a small percentage of your capital; think of losses as tuition.  
- **Short‑term reflection:** Do a quick debrief, adjust your plan, and get back in the game.

Remember, the market won’t reward a perpetual analyst who’s forever stuck in “what‑if” land. It rewards the trader who learns, adapts, and keeps moving forward—one trade (and one laugh) at a time. So the next time a position bites you, just give it a little wave, thank it for the lesson, and **drop it and move on**. 🍻