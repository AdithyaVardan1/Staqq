# 129. Be Adaptive  

**Source:** https://zerodha.com/varsity/chapter/be-adaptive/  

---  

It’s a classic bar‑room debate among short‑term traders (the folks who spend most nights staring at a flat P&L and dreaming of that next “big move”). The question is simple‑looking but sneaky: **Should you have an opinion or not?**  

- **Team “Blank Slate”** – These traders swear they walk into the market with a mind as empty as a freshly‑opened beer can. No preconceived ideas, no “I‑know‑this‑stock‑is‑gonna‑pop” thoughts. They claim this mental tabula‑rasa lets them *read* and *react* to whatever the market shouts at them. In their world, the market is the bartender, and they’re just listening for the next order.  

- **Team “Opinionated”** – The other camp says, “Of course I have an opinion! I breathe market data 24/7, it’s practically my second language.” Their brains are constantly churning scenarios, like a Netflix binge of “What‑If‑The‑Fed‑Does‑This‑Again.” The trick for them is not to let that internal monologue become a stubborn roadblock; they must still be able to *make money* even when the market says, “Nah, not today.”  

Both camps share a secret weapon: **adaptability**. The “no‑opinion” crowd is adaptable because they *know* their edge lies in staying fluid, like a yoga‑master‑trader who can bend with every price twist. The “opinionated” crowd is adaptable because they can *park* their gut feeling, toss it on the back‑seat, and let the data on the screen drive the car.  

---

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/02/18-300x230.png)

What ties these two seemingly opposite approaches together is a willingness to pivot on a dime. The “blank‑slate” crew claims their flexibility is the reason they can chase whatever the market whispers. The “opinion‑holders” claim they can *override* their morning gut‑check when the charts start screaming something else. In short, they’re both playing the same game—just with different cheat codes.  

---

### A Real‑World Example: The Dollar’s Mood Swings  

Over roughly the **last six months**, we’ve watched the US dollar act like a moody teenager: sometimes weak, sometimes strong, and rarely caring about what its older sibling—the US equity market—does. In many of those weeks, a dip in the greenback barely nudged stocks, even on days when the dollar’s slide was as dramatic as a roller‑coaster drop.  

My trading crew and I kept a mental Post‑It of this weirdness: “Dollar down → stocks stay chill.”  

Fast forward to the present: the dollar’s recent weakness has started to *actually* move stocks. Suddenly, every “I‑told‑you‑so” pundit who’s been shouting “A falling dollar is poison for US equities” can’t help but pop a celebratory champagne bubble.  

**The catch?** For months they clung to that conviction, ignoring the fact that the market wasn’t buying the story. The *opportunity cost*—the profit they could've made by playing the real‑time relationship—was probably higher than any eventual “we were right” payoff.  

The moral here is simple: **In short‑term trading, “it only matters when it matters.”** If you keep clutching a stale opinion, you’re basically trying to surf a wave that’s already gone.  

---

### The Daily Question: “What’s Working **TODAY**?”  

I love to start every trading day with the same mental checklist, but with a twist of humor:  

> “What’s actually *working* in the market right now? Not what *should* work according to my favorite textbook.”  

Answers change faster than a bartender’s cocktail menu:  

- **Long‑only day** – The market’s been chewing on the “buy the dip” narrative, so I’m loading up on bullish positions.  
- **Mini‑contracts sell‑downtick** – Bonds are ticking up, my mini‑futures are ticking down, so I’m selling those downticks like a discount at a garage sale.  
- **Mid‑cap short‑interest play** – Even if the big indices are sulking, some mid‑caps with massive short interest are popping like popcorn when the market shows any strength.  

By treating each day as a fresh episode of “What’s the Plot Twist?”, I stay adaptable and increase my odds of ending the day with a smile (and preferably a positive P&L).  

---

### Bottom Line for Short‑Term Traders  

- **Enter the day with an open mind** – Think of yourself as a curious kid at an all‑you‑can‑eat buffet, not a picky eater who only wants the same dish.  
- **If you do have an opinion, tuck it away like a spare tire** – Keep it handy for emergencies, but don’t let it slow you down on the highway.  
- **Make adaptability your superpower** – The market is a living, breathing beast that changes moods faster than you can say “stop‑loss.” The more you can bend without breaking, the longer you’ll stay in the game.  

So whether you’re the “blank‑slate” type or the “opinion‑anchored” type, remember: **being adaptive isn’t just a nice‑to‑have, it’s the difference between sipping a cocktail on a sunny balcony and being stuck in a rainstorm without an umbrella.** Cheers to staying flexible! 🍸