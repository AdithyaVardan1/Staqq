# 184. What Do You Do When the Markets Change?  

**Source:** https://zerodha.com/varsity/chapter/what-do-you-do-when-the-markets-change/

---

> “Be a rugged individualist. Think independently. Take the contrary position occasionally. Anticipate changes in market conditions, and be ready with alternative plans.”  
> – (Sounds like a mantra a philosopher‑trader would shout while sipping a latte at 2 a.m.)

These lofty sound‑bites pop up a lot in investment psychology textbooks. They’re nice to read, but they can feel as abstract as “the meaning of life” when you’re staring at a red‑ink‑splattered P&L. To make them less like a philosophy lecture and more like a chat over nachos, let’s strip the jargon down to a few bite‑size stories. Even if the examples feel a tad “simplified,” they’ll still illustrate the point. For today’s newsletter, we’ll compare two eras that could not be more different: the frothy late‑1990s boom and the post‑2000 reality‑check.

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/03/20070220-300x300.png)

### When the world was a “Buy‑Everything‑Now” playground  

The way traders acted before the year 2000 versus after it is a textbook case of how market conditions can flip on their head—like a pancake that suddenly decides it wants to be a soufflé. In a handful of our **Master Interviews**, we heard from folks who raked in eye‑popping profits in the late‑90s, only to watch those gains evaporate when the dot‑com bubble burst. Back then, you didn’t need a Ph.D. in behavioral economics or a crystal ball; you just needed to hop on the hype train.

Picture this: walk into any office in ’98‑99 and you’ll hear a chorus of “I made a killing on XYZ.com!” It was the era of **“everyone’s a trader”**. Optimism was so high you could almost see it floating above the desks like a helium balloon. The market narrative was simple: “Prices will keep climbing—up, up, up!” This was the kind of environment that lures a lot of bright‑eyed newbies (and a few seasoned pros who thought they could ride the wave forever).  

All you really had to do was **spot a stock the crowd was gushing over**—think early‑stage Internet firms, the original “unicorns”—buy it at what felt like a discount, and sit back while the price kept climbing. Why did it climb? Because **a flood of amateur investors kept pouring cash into the market**, each convinced they were about to become the next Warren Buffett. The more people bought, the higher the price went, which in turn attracted even more buyers. In that environment, the age‑old adage “buy high, sell low” was turned on its head—**the real rule was “buy low, sell higher, and repeat.”**  

You’ll also hear the mantra **“the trend is your friend.”** In a bull‑run powered by a herd of eager first‑timers, following the crowd actually *helped* you. Imagine you’re at a concert and everyone is dancing to the same song; you can’t be too wrong if you join in, right? The same logic applied to stocks. As long as you got in early enough—before the crowd’s enthusiasm turned the price into a fireworks show—you could ride the momentum and cash out when the party started to fizzle.

Sure, it wasn’t a guaranteed free‑ride; there were losers, missed opportunities, and the occasional “I‑should‑have‑sold‑earlier” panic. But the core point is that **the market’s structure itself was giving you a helping hand**. The “herd instinct” was actually an asset because the herd was *big*, *greedy*, and *relatively clueless*. If you were uncertain, you could simply watch the crowd, see if they were still buying, and hop on the bandwagon.  

### Fast forward to today – the waves are now tiny ripples  

Fast‑forward to the 2020s, and you’ll notice the ocean has turned into a choppy pond. The “waves” are **much shorter**, the participants are **far more sophisticated**, and the pool of naïve amateurs ready to keep buying as prices rise has shrunk dramatically. In other words, the market no longer hands you a free‑handed “follow‑the‑crowd” cheat code.

Now you have to be **creative**, **independent**, and—yes—**a little bit rugged**. Think of it as moving from a game of “follow the leader” to a solo improv comedy act where you have to make up jokes on the spot, and the audience (the market) can heckle you at any second.

### The classic “bull‑market‑training” trap  

A recurring anecdote from our **Master Interviews** goes something like this:  

> “I learned to trade in a bull market, and I thought I’d cracked the code.”  

Spoiler alert: they hadn’t. When the market turned sideways or down, those traders often discovered they *couldn’t* make a dime. The pattern is clear—**strategies that performed spectacularly in one regime can become downright disastrous when conditions shift**.  

If you dig into the track record of those who made “big wins” before 2000, you’ll see a common story: many of them haven’t been able to replicate that success consistently after the bubble popped. The moral? **A single‑track trading approach is like wearing flip‑flops in a snowstorm—comfortably wrong**.

### So, what’s the take‑away?  

When markets change, you can’t just cling to the old rulebook and hope the “trend will be your friend” forever. The modern landscape demands **multiple lenses**, **personal instincts**, and **a healthy dose of skepticism toward the herd**.  

- **Evaluate from many angles** – technical, fundamental, macro, sentiment… basically, treat the market like a mystery dinner where you have to guess the ingredients from every possible clue.  
- **Trust your own analysis** – it’s okay to be contrarian, as long as you have a solid rationale (not just because you want to be the “rebel” of the trading floor).  
- **Stay ready with Plan B (and C, D, and maybe even Z)** – markets are fickle; having backup strategies is like keeping an umbrella handy in London—sometimes you’ll need it, sometimes you won’t, but you’ll thank yourself when the rain shows up.  

In short, the era of “just buy what everyone’s buying and watch the price rocket” is over. To thrive today, you need to **think independently, act like a rugged individualist, and keep a backup plan tucked in your back pocket**—just like a bartender who always has an extra bottle of bitters ready for the unexpected cocktail request.  

So the next time you hear the market whisper “the trend is your friend,” give it a polite nod, then double‑check the weather forecast before you jump onto that surfboard. 🌊🏄‍♂️