# 26. Focused on the Trade  

**Source:** <https://zerodha.com/varsity/chapter/focused-on-the-trade/>

---  

### Keep Your Eyes on the Ball (or the Candle)

So you’ve finally gotten that trade on the screen and hit the “go” button. Great! 🎉 Now comes the part most people skip: actually *watching* the trade like a hawk that just discovered an all‑you‑can‑eat buffet.  
You need to be able to spot the little warning signs that say, “Hey, the market is about to give you the finger,” and you have to react fast enough to pull the hand‑brake before you end up in a ditch.  

But here’s the kicker – your brain loves to throw a few party‑crashers into the mix: self‑doubt, wobbly confidence, or that vague feeling that maybe you should have stayed in bed. Those mental gremlins can yank your attention away from the chart, making it harder to execute the plan you painstakingly wrote out last night (or the one you scribbled on a napkin during lunch).  

You can’t completely evict every psychological squabble from the mind’s penthouse, but you can definitely give the most obnoxious ones the boot before they start shouting “I’m the boss!” in the middle of a trade. The goal is to keep those inner hecklers from hijacking your focus when the market decides to be a drama queen.

![Image](https://zerodha.com/varsity/wp-content/uploads/2019/12/20070502.png)  

---

### Deal With Your Inner Drama ASAP  

When a mental conflict pops up, treat it like a spilled drink at a bar: clean it up **now** or you’ll end up slipping on it later. If you let it sit in the back of your head, it’ll chew up valuable psychological bandwidth – the same kind of mental horsepower you need to read a candlestick pattern in 2.5 seconds.  

**Pro tip:** Do a quick “psych‑check” before the market opens. Ask yourself, “Do I have any lingering worries about that argument with my partner, the overdue tax return, or whether I left the stove on?” If you can name them, you’ve already reduced their power. The less mental clutter you carry into trading hours, the fewer surprises you’ll have when the price suddenly does a 180.  

You can’t simply *pretend* the problem isn’t there – it’s like trying to ignore a buzzing mosquito while you’re trying to enjoy a pint. The more you swat at it, the louder it gets. In fact, research (and a few seasoned traders) tell us that simply **acknowledging** a worry makes it lose its grip. Dr. Ari Kiev, a legend in the mind‑gym world, says: “If you name the issue, you can kick it out the door.” So, give that anxious thought a name—“Mr.‑I‑Might‑Lose‑Money”—and then politely show it the exit.

---

### Even the Calmest Trader Has Ghosts to Chase  

You might be the type who doesn’t carry any emotional baggage (maybe you’re a Zen monk in a trader’s body). Still, there are universal “trader ghosts” that pop up for everyone at some point.  

One of the most common is the **“lucky streak” delusion**. Picture a newbie who just rode a wave of winning trades and starts thinking, “I’m the Wolf of Wall Street!” The truth? Sometimes luck masquerades as skill, and it’s way easier to keep that ego inflated than to ask, “Did I actually *know* what I was doing?”  

Admitting that you might have been riding a lucky tide isn’t a sign of weakness; it’s a chance to upgrade from “fluke‑trader” to “skill‑trader.” The mental energy you waste pretending you’re a prodigy is better spent on learning new setups, reading more charts, or even taking a solid trading‑course. Think of it like swapping a cheap beer for a well‑aged whiskey—you’ll feel the difference.  

Another spooky belief is the **“out‑of‑date‑skill”** nightmare: “I was a solid trader five months ago, but now the market has turned into a different beast.” Whether it’s true or just a fear of the unknown, letting that thought simmer in the back of your mind saps focus.  

If you sniff out the truth, you have two options:

1. **If it’s false** – remind yourself that markets are cyclical, and your core edge (risk management, discipline, etc.) still applies.  
2. **If it’s true** – roll up your sleeves, learn a new strategy, or adjust your risk parameters. In short, adapt or become a market dinosaur.

---

### The Sneaky “Back‑of‑Mind” Gremlins  

Most of these mental hiccups hide in the subconscious, waiting for a moment when you’re feeling vulnerable – say, after a string of losses or when a trade goes *against* you. That’s when the inner critic decides to throw a full‑blown karaoke performance of “I’m a failure!” right into your ear.  

Ignoring the gremlins is like ignoring a leaking roof during a storm; you’ll end up soaked. The smarter move? Shine a flashlight on them **before** they get a chance to ruin the party.  

When you do that, you can tell yourself, “Okay, maybe that fear is legit, but right now I’m in the middle of a trade, and I’ve got a plan.” Then you can park the emotional drama for “off‑hours” (e.g., after the market closes, while you’re sipping a cold brew).  

In practice, this looks like:

| Situation | What to Say to Your Inner Gremlin |
|-----------|-----------------------------------|
| “I’m not good enough” | “I’ve got a plan, I’m following it, and I’ll improve with each trade.” |
| “The market will always beat me” | “Markets are random; my edge is consistency, not perfection.” |
| “I should have taken that other trade” | “I made the best decision with the info I had at the time.” |

---

### Wrap‑Up: The Winning Trader Mindset  

Bottom line: **Unresolved mental conflicts are like hidden fees on your brokerage account – they drain you without you noticing.**  

1. **Spot them early** – do a quick mental inventory before the market opens.  
2. **Name them** – give each worry a label; you’ll weaken its grip.  
3. **Deal with them** – either reassure yourself (if the belief is false) or take concrete action (if it’s true).  
4. **Save the heavy lifting for off‑hours** – you don’t need to solve world peace while the price is ticking.  

If you can master this mental housekeeping, you’ll find yourself in the sweet spot where focus meets confidence. That’s the place where winning traders live, breathe, and occasionally celebrate with a celebratory high‑five to the screen. Cheers to a clear mind and a sharp chart! 🍻  