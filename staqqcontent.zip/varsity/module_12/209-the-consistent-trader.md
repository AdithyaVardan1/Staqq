# 209. The Consistent Trader  

**Source:** https://zerodha.com/varsity/chapter/the-consistent-trader/  

---  

The winning trader is, in a nutshell, a **consistent** trader. Imagine a surfer who catches wave after wave without wiping out—each ride adds a little more sand to the beach towel of profit. A “winning” trader does the same: they hop on trade after trade with a breezy, almost non‑chalant swagger, and the cash starts to pile up like laundry after a weekend binge‑watching session.  

But “consistently” isn’t just a fancy buzz‑word. It means you approach **every** trade with a logical game plan, a tidy prep checklist, and the kind of decisive confidence you’d expect from someone who’s already ordered the third round of drinks. For newbies, chasing consistency should be the North Star—everything else (like chasing the next “big win”) is just a glittering distraction.

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/04/20060901-300x300.png)

### Probabilities are your new BFF  

Trading profitably is a probability party. If you follow a **sound** trading method—think of it as a well‑tested recipe that’s survived a dozen kitchen disasters—success is largely about odds. Toss enough trades into the pot and the odds tip in your favor, and the profit pie starts looking delicious.  

It’s like flipping a coin or rolling dice. Flip a fair coin an infinite number of times under *exactly* the same conditions and you’ll get heads about **50 %** of the time. The trick is the phrase “under identical conditions.” In a lab, you can control the temperature, the humidity, the coin’s weight. In the market, you can’t. Markets are the mischievous cousins who change the playlist every five minutes.  

Because you can’t force the market to be a perfectly repeatable experiment, you have to **look inward** for consistency. The first step on this self‑discovery journey is to sniff out what makes your own performance wobbly. Remember the coin‑flip analogy: you want to flip that coin the same way every single time, otherwise you’ll end up with a weird pattern like “heads, tails, tails, heads, heads, tails…”, which is just a fancy way of saying “I have no idea what I’m doing.”

### How to keep the ride smooth (and not a roller‑coaster)  

1. **Risk the same slice of the pie every time.** A classic rule of thumb is to risk **about 2 % of your total trading capital** on any single trade. Think of it as putting only a bite‑size piece of your pizza on a plate—if the pizza burns, you still have plenty left for later.  

   New traders often get giddy after a lucky streak and start betting larger slices, hoping to “milk” the run. That creates a jagged equity curve that looks more like a mountain‑range silhouette than a smooth upward slope, and it turns your emotions into a wild amusement‑park ride. Keep the risk steady, and the curve will look more like a gentle hill you can actually climb without nausea.  

2. **Stick to familiar market conditions—at least at first.** Elite traders can surf a tsunami, a calm lagoon, or a choppy river with equal finesse. For beginners, it’s wiser to stay in the kiddie pool you know how to navigate. Maybe you’ve discovered that you’re most profitable **in a bull market, two hours after the market opens**. That’s a perfectly legitimate “sweet‑spot” to practice your craft, even if it feels a bit like playing the same level of a video game over and over. Mastering that niche builds confidence, and confidence is the secret sauce that keeps you from panicking when the market throws you a curveball.  

### The roadmap for the rookie  

Your **initial mission** as a fledgling trader is simple: **establish consistency**. Nail that down, and you’ll naturally start gathering skills that let you trade in more chaotic environments later on. Think of it as learning to walk before you run a marathon.  

When you finally graduate from the “consistent‑only” phase, you’ll be ready to experiment with different market moods, time‑frames, and strategies. But by that point, the habit of treating each trade with a disciplined, repeatable process will be ingrained, and the profits you earn will feel good not just in your bank account but also in your headspace.  

In short: trade like you’re flipping a coin—**the same way, every time**—and watch the odds do the heavy lifting. Your wallet and your sanity will thank you. Cheers to consistent wins!