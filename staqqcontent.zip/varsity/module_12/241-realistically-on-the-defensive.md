# 241. Realistically on the Defensive  

**Source:** https://zerodha.com/varsity/chapter/realistically-on-the-defensive/

---

When you’re up against a heavyweight opponent, the smartest move is to go **full‑metal‑armor**. Think of an NFL quarterback: he straps on a helmet, shoulder pads, and relies on his offensive line to keep the blitzers at bay. The goal isn’t to look cool; it’s to **avoid getting sacked and to keep the playbook intact**. The same logic applies to trading.  

A rookie trader often dives into a position without a battle‑plan, as if “winging it” were a legit strategy (spoiler: it isn’t). A seasoned, profit‑making trader, however, treats each trade like a high‑stakes chess match. He writes down *exactly* where he’ll enter, where he’ll exit, how much capital he’ll risk, what the worst‑case scenario looks like, and even what he’ll do if the market decides to pull a prank. In other words, every single element of his trading plan is spelled out **with the meticulousness of a wedding planner arranging napkin colors**.

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/04/20061106-300x300.png)

---

## Optimism vs. Defensive Pessimism – The Academic Showdown  

The rookie’s optimism is like a kid looking at a roller‑coaster and thinking, “That’s just a gentle hill.” The veteran, on the other hand, is a **defensive pessimist**—the type who checks the safety harness twice, reads every warning sign, and still rides the coaster because they know the thrill is worth the risk—*if* they’ve prepared for it.

A study by Dr. Nancy Cantor (yes, the same Dr. Cantor who once convinced us that “pessimism can be a super‑power”) split a group of University of Michigan students into two camps:

| **Group** | **Mind‑set** | **How they saw the semester** |
|----------|--------------|------------------------------|
| **Rosy‑Glow Optimists** | “This is challenging, but I’ve got this!” | Academic tasks felt like a puzzle, not a threat. |
| **Defensive Pessimists** | “Whoa, this could be a disaster—let’s bring the fire‑hoses.” | Tasks seemed difficult and a tad stressful, so they loaded up on precautions and heroic effort. |

At the semester’s start, everyone predicted their final grades. The optimists painted a sunny picture, while the pessimists deliberately **under‑promised** (think “I’ll probably get a B‑, but I’ll study like a mad scientist anyway”).  

Why the lowball? Because by setting the bar low, defensive pessimists dodge the nasty *over‑confidence trap*. They stay disciplined, keep the ego in check, and avoid the classic “I’m a genius, I don’t need a stop‑loss” syndrome.

### The Emotional Trade‑Off  

Throughout the term, defensive pessimists reported **more stress and anxiety** than their rosy‑glow buddies—kind of like feeling the pressure of a tight‑rope walk. But here’s the kicker: that anxiety **didn’t cripple them**. In fact, for the pessimists, higher stress correlated with **higher GPA** at semester’s end. Their gloom‑iness was not a performance‑killing curse; it was a **performance‑enhancing catalyst**.

---

## What This Means for Traders  

If you’re the type who thinks, “I’ve got a 99% chance this trade will skyrocket,” you might be walking the line of *dangerous optimism*. Behavioral finance research has repeatedly shown that **traders love to over‑estimate their skill** (it’s almost a sport).  

So, before you click “BUY” or “SELL,” ask yourself a few defensive‑pessimist‑style questions (don’t ask them *mid‑trade*; that’s like checking the weather after you’ve already left the house in a rainstorm):

1. **“Am I really that sure this trade will be a home run, or am I just feeling lucky?”**  
2. **“Did I actually spend enough time dissecting the chart, the fundamentals, and the macro backdrop, or did I just skim the headlines?”**  

If the answer is “maybe,” it’s time to **dial back**. Toss in a tighter stop‑loss, shrink the position size, or—best of all—walk away and revisit the plan tomorrow with fresh eyes. A dash of caution won’t hurt; it’s the financial equivalent of wearing a helmet on a bike ride to the office.

### Bottom Line  

In the world of trading, **defensive pessimism isn’t about being a doom‑and‑gloom doomsayer**. It’s about *anticipating* the worst, *preparing* for it, and then *executing* with confidence that you’ve covered your bases. Think of it as wearing a raincoat on a day that *might* drizzle—if it’s sunny, you’ll still look sharp; if it rains, you’ll stay dry.  

So, channel your inner defensive pessimist, write that battle‑plan down to the last decimal, and remember: the market loves a bold player, but it **respects** a player who’s **prepared for the unexpected**. Cheers to staying safe, staying realistic, and maybe—just maybe—making a few extra bucks while you’re at it!