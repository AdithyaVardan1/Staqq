# 128. An Action‑Oriented Approach  

**Source:** <https://zerodha.com/varsity/chapter/an-action-oriented-approach/>

---  

Jim is a brand‑new trader who has just taken three losing trades in a row. He sits there thinking, *“I’m such a failure. I can’t stand losing. I’m disappointed. I just don’t want to think about it. I think I’ll go out for a beer.”*  
Sound familiar? Every rookie (and even a lot of seasoned pros) will hit a losing streak. Losses and other setbacks **aren’t the problem**—how you bounce back **is**.  

If you can say, *“It’s okay, I’ll draft a fresh plan and keep moving,”* you’re probably coping alright and might even be on the road to success. If you’re more like Jim—spending hours ruminating on the mistakes, dodging responsibility, and waiting for a miracle to appear out of thin air—you’ll waste a ton of mental energy and likely stay stuck. The key is to stare the setback dead‑in‑the‑face, take concrete steps to fix it, and keep grinding until you’ve built the trading chops needed for consistent profits.

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/02/19-277x300.png)

## Two Ways People Deal with Setbacks  

1. **Passive denial** – “It didn’t really happen,” or “It’s just bad luck.”  
2. **Active problem‑solving** – “Okay, here’s what went wrong and how I’ll fix it.”  

Most of us assume denial is the easy road. When you’ve just watched a big chunk of your capital disappear, the mind floods with doom‑laden thoughts:  

- *“Maybe I’ll never be a successful trader.”*  
- *“I’m just fooling myself.”*  
- *“I don’t have the talent or the natural gift to make money.”*  

These mental gremlins are normal for any high‑skill pursuit. The danger is that they drag you into a swamp of sadness, self‑pity, and avoidance. Your psyche will try to shield itself by *ignoring* the problem. Ironically, the act of denial **costs more psychological energy** than simply acknowledging the loss, admitting you might have questions about your skill set, and—most importantly—taking decisive action to crush those fears.

## Why Active Problem‑Solving Beats Wall‑Staring  

Let’s return to our pal Jim. He’s taken a few losing trades and now his confidence is on a diet. Instead of stewing over the numbers and thinking about throwing in the towel, Jim should adopt an **action‑oriented mindset**.  

### Scenario A – His method is solid  

If Jim has data that shows his trading edge works in the long run (think “law of averages” rather than “law of instant gratification”), he shouldn’t internalise the loss. He should keep **mechanically** executing the same edge‑based trades, trusting that over a large enough sample size the probability will swing back in his favour. In other words: *let the math do the heavy lifting, not your emotions.*

### Scenario B – His method is shaky  

If his edge feels flimsy, it’s time to **hit the pause button**, hunt for a sturdier framework, and test it on a tiny scale. He might also **lower his expectations temporarily**. Perhaps he’s aiming for a 20 % monthly return but lacks the experience to pull that off. In that case, a better objective could be:

- **Learning goal:** “Spend 20 hours per week reading, back‑testing, and paper‑trading.”
- **Performance goal:** “Aim for a modest 2‑3 % weekly profit while I get the hang of things.”

Switching the focus from “how much money can I make right now?” to “how much can I learn right now?” rewires the brain from panic to progress.

### The Bottom Line  

Whatever the route, Jim must **act**, not just *think*. He needs a clear, decisive game plan that tackles the setback head‑on. When you move from “I’m stuck” to “I have a plan,” the anxiety melts away, replaced by a sense of mastery, control, and a healthy dose of optimism.  

## The Bigger Picture for All Traders  

Every trader—no matter how seasoned—will hit rough patches, especially in the early days. The difference between those who survive and those who bail out is not the frequency of the setbacks but the **response** to them.  

If you let pessimism, self‑doubt, and passivity take the driver’s seat, you’ll end up parked in the “Never‑Gonna‑Make‑It” lot. If, instead, you strap on the problem‑solving helmet, you’ll feel:

- **Energised** – because you’re doing something, not just worrying.  
- **Empowered** – because you’ve turned a loss into a learning experiment.  
- **Ready** – because you now have a repeatable process for the next inevitable dip.

In short, adopt an **action‑oriented approach** and you’ll transform every setback into a stepping‑stone toward becoming a consistently profitable trader. Cheers to that—preferably with a beer *after* you’ve nailed the plan, not before! 🍻