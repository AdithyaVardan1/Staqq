# 253. Discipline Takes Practice  

**Source:** https://zerodha.com/varsity/chapter/discipline-takes-practice/  

---  

Trading is a bit like trying to keep a toddler on a leash while you both walk through a fireworks show – you *need* a plan, and you *need* to stick to it, but even the most seasoned pros end up chasing after their own shoelaces. They bail out early, ignore that stop‑loss you drew in crayon, or toss risk limits out the window like yesterday’s pizza box. The sad truth? Most traders wrestle with discipline, and the market eventually serves them a bill they can’t afford to ignore.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/04/20060530-300x300.png)  

Some folks are the human embodiment of a Swiss watch – tick‑tock, rule‑obeying, and so tight they could double as a spreadsheet. They’ll even turn down a hot tip if it means breaking their own rulebook. Others are the free‑spirited artists of the trading world: creative, charismatic, and occasionally profitable, but when the market throws a curveball they might fling their plan out the door like a bad Tinder date. In reality, **every** trader sits somewhere on this discipline spectrum – maybe a little too rigid, maybe a little too loose.  

Why is that? Because markets are chaotic, unpredictable, and love to keep us on our toes. One second you’ve executed a trade, the next you’re staring at a price chart that looks like a toddler’s finger painting. That uncertainty can stir up a cocktail of anxiety and “what‑if” thoughts, and before you know it, you’re reaching for the impulsive “sell now!” button.  

## How to Beef Up Your Discipline Muscle  

### 1️⃣ Treat discipline like a bicep – you have to **work it out**  

Think of discipline as a mental gym. The more you lift (i.e., practice sticking to your plan), the stronger it gets. Psychological energy is a finite resource – like the battery on your phone. When you’re drained, you’ll swipe right on every “quick profit” temptation. Building stamina means deliberately exercising self‑control in low‑stakes situations, so when the big‑ticket trades roll around, you’ve got the mental muscle to resist the siren song of impulsivity.  

### 2️⃣ Sleep like a champion, not a night‑owl barista  

If you’re running on fumes, your brain’s decision‑making circuitry turns into a spaghetti junction. Fatigue slashes your “will‑power bandwidth,” making it painfully easy to ignore stop‑losses or chase a breakout that’s already busted. Aim for 7‑9 hours of quality shut‑eye, and sprinkle in short power‑naps if you’re pulling late‑night charts. A well‑rested trader is a disciplined trader – it’s that simple.  

### 3️⃣ Emotional Bouncer: Keep the drama out of the trading floor  

Stress, anger, excitement – they’re all welcome guests at a party, but they’re **not** welcome at your trading desk. When you’re fuming because the market moved against you, your brain goes into “fight or flight” mode, and the “flight” part often looks like a hasty exit from a position. Practise mindfulness, deep‑breathing, or even a quick walk to the kitchen for a glass of water. The goal is to keep the emotional thermostat at a comfortable 68°F, not a scorching 100°F.  

### 4️⃣ Write your plan on the wall (literally)  

A vague, “I’ll buy low, sell high” scribble on a napkin won’t cut it. Draft a **clear, step‑by‑step** trading plan: entry criteria, position size, stop‑loss level, profit target, and exit rules. Then plaster it next to your monitor like a motivational poster. When you feel the urge to improvise, that sticky note will smack you with a reminder: “Hey, remember what you promised yourself?”  

### 5️⃣ Cement your “why” in ink  

Why do you want to stick to this plan? Because you hate regret? Because you want to fund your next vacation? Write those reasons down and keep them handy. When the urge to deviate creeps in, read them like a cheat sheet:  

> *“If I bail on my plan now, I’ll be the one buying a round of regret later. I’m here to stick to the game plan, no matter how tempting the side hustle looks.”*  

Seeing your own words in black‑and‑white makes the temptation feel a lot less tasty.  

### 6️⃣ Live in the **now**, not the “what‑if” future  

Your brain loves to time‑travel to worst‑case scenarios (“What if this trade tanks tomorrow?”). That’s the perfect recipe for panic‑selling. Instead, zero in on the **next actionable step**: “I’ll monitor the price until it hits my stop‑loss or target, then I’ll move on.” By breaking the trade down into bite‑size tasks, you keep your focus razor‑sharp and your discipline intact.  

## Bottom line: Discipline isn’t a myth, it’s a habit you can train  

Most traders flirt with the idea of “trading by the seat of their pants,” but that’s a romance novel with a tragic ending. The winners? They’re the disciplined ones who show up every day, follow a vetted plan, and treat their psychological stamina like a prized gym membership. If you can keep that discipline muscle pumped, the market’s volatility will feel less like a roller coaster and more like a gentle, profitable glide.  

So, raise a glass (of water, not whiskey) to the practice of discipline – the real MVP of trading success. 🎉