# 18. Loss is Feedback, Not Failure  

**Source:** https://zerodha.com/varsity/chapter/loss-is-feedback-not-failure/  

---  

Trading, like any high‑octane hobby (think extreme ironing or competitive dog‑show‑judging), needs a **thick skin**—the kind of hide that would make a rhino jealous. You can’t let every little jab or “oops‑I‑lost‑again” sting you, because the market won’t wait while you’re busy crying into your coffee. Instead, you have to stay wide‑open to criticism—usually disguised as a loss—so you can tweak your strategy **before** the red numbers start looking like a horror‑movie budget. The secret sauce? Treat every loss as **objective feedback**, not a personal indictment.  

---  

### How We Grow Up With (or Without) a “Criticism‑Proof” Personality  

Psychologists love to spin stories about why we react the way we do. Sigmund Freud (the original “dad‑joke” psycho‑analyst) once suggested that the whole criticism‑thing starts when kids are being toilet‑trained. Yep—while they’re learning to hold in pee, they’re also learning to hold in ego bruises. Other brainiacs argue that the real turning point is when the kid steps foot into school and is forced to deal with grades, lunch‑line politics, and the occasional “You’re the last one to finish your math worksheet!”  

The upshot? Some of us graduate from kindergarten with a **sense of mastery** (we’re the cool kids who can tie their shoes on the first try), while others walk away with a **sense of inferiority** (we’re the ones who still can’t figure out how to open a juice box without spilling). Either way, the way we handle criticism as adults is largely set in those early years. Some people practically **bathe in criticism**, while others treat it like a stray cat—avoid at all costs.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2019/11/20050321.png)  

---  

### The Thin‑Skinned Trader: A Cautionary Tale  

Imagine a trader whose skin is so thin you can see the veins. This person spent most of their childhood perfecting the art of self‑protection because, let’s face it, the world can be a brutal place (think “no dessert until you finish your vegetables” level of punishment). As a result, they become adults who **anticipate punishment** for every little slip‑up.  

What does that look like in practice?  

* **Black‑and‑White Vision** – Every decision is either “right” or “wrong.” There’s no gray area, no “maybe I can try a hybrid approach.”  
* **Praise‑Or‑Punish Mode** – You either get a gold star or a timeout. No in‑between.  
* **Risk‑Averse to the Core** – Since the fear of “wrong” looms like a thunderstorm, they avoid taking chances.  

The downside? By refusing to gamble (even a tiny one), they never **make big mistakes**—and more importantly, they never **learn how to bounce back**. When a loss does happen, they treat it like a personal apocalypse rather than a data point. It becomes a *personal failure* instead of **objective feedback** that can be dissected, learned from, and, most importantly, used to adjust the next trade.  

---  

### Turning the “Setback‑Is‑Failure” Switch Off  

If you recognize yourself in the thin‑skinned description, it’s time for a mental reboot. Here are some **no‑nonsense, bartender‑level** tips to help you see losses for what they really are:  

1. **Remember the Crowd Isn’t Watching** – Nobody’s perched on your shoulder with a clipboard. The market doesn’t care about your self‑esteem, it only cares about price movements.  
2. **Treat Trading Like Driving** – When you drive to work, you don’t spend the whole trip worrying about whether you turned the steering wheel “perfectly.” You focus on the road ahead, adjusting speed and lane as needed. You don’t berate yourself for a missed turn; you simply correct it.  
3. **Embrace the Process Over the Outcome** – Your **process** (your entry criteria, risk management, exit plan) is the real hero. The profit or loss is just the side‑effect, like the smell of coffee after a good brew.  
4. **Collect Feedback Relentlessly** – Every loss is a data point. Write it down, analyze it, and move on. Think of it as a “review” on a movie you just watched—maybe the acting was bad, maybe the plot was confusing, but you still learned something about your taste.  

---  

### The “Driving‑Lesson” Analogy (Extended Edition)  

Picture yourself learning to drive a stick‑shift for the first time. At first, you’re terrified of stalling, you’re terrified of burning the clutch, and you’re terrified of every red light. You make a lot of **mistakes**—you stall, you roll back a hill, you hit the curb once or twice. Do you quit driving and become a lifelong Uber passenger? No. You **learn** from each mishap:  

* **Stalling?** → Maybe you released the clutch too early.  
* **Rolling back?** → Perhaps you didn’t give enough gas.  
* **Curb hit?** → Time to check your blind spot.  

You keep practicing, you adjust, you get better, and eventually you can glide through traffic like a boss.  

Now, swap the car for a **trading platform**. The “road” is the market, the “clutch” is your position size, the “gas pedal” is your risk tolerance. When you take a loss, ask yourself the same questions:  

* Did I **enter** with a solid setup?  
* Was my **stop‑loss** placed logically, or was it just “close enough”?  
* Did I **manage** the trade (e.g., trail stop, scale out) or sit there like a deer in headlights?  

Just as you’d eventually become a confident driver after enough miles, you’ll become a confident trader after enough **feedback loops**.  

---  

### The Bottom Line: Feedback ≠ Failure  

Profitable trading is **rarer than a unicorn on a skateboard**, but it’s not mythical. It’s a skill that can be honed—provided you treat every loss as a **piece of objective information**, not a scar on your ego.  

* **Don’t personalize the loss.** It’s the market saying, “Hey, that wasn’t the right move right now.”  
* **Welcome the feedback** like you’d welcome a free refill at the bar—because it helps you keep the party going.  
* **Iterate, adjust, and keep the process tight.** Over time, those tiny adjustments compound into a robust, profitable strategy.  

So the next time your account flashes red, take a deep breath, pop a mental “feedback received” sticker on it, and move on to the next trade. Remember: **losses are just the market’s way of giving you a free lesson—no tuition required.** Cheers to learning, laughing, and (eventually) earning!