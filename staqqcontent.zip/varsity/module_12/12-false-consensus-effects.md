# 12. False Consensus Effects  

**Source:** https://zerodha.com/varsity/chapter/false-consensus-effects/

---

### The “I‑think‑everyone‑does‑this” Illusion  

Picture this: you’re sitting at the bar, a half‑empty pint in front of you, and you’ve just decided to **go long on Sears** because you heard a rumor that their “retro‑trolley” line is about to become the next big thing. You glance around the room and think, *“Wow, everybody here must be buying Sears stock too – it’s practically a party trick!”*  

When ordinary folks (and even seasoned traders) are asked **how many other people would make the same choice**, the answer usually comes out **way inflated**. Psychologists call this the **false consensus effect** – a fancy way of saying we over‑estimate how much our opinions and actions reflect the crowd.  

It doesn’t matter whether the decision is about buying a stock, voting for a candidate, or picking a pizza topping. **Across the board, people think their choices are “normal” and that the majority of their peers would have made the same call.** We treat our own decision as an **anchor** and then swing the mental pendulum to guess where the rest of the world lands – and that pendulum is heavily weighted toward us.  

The side‑effect? **Over‑confidence.** Once you’ve committed to a trade, you feel a warm glow that says, *“I’m right, and everyone else will see it too.”* Spoiler alert: they probably won’t.

![Image](https://zerodha.com/varsity/wp-content/uploads/2019/11/20041104.png)

---

### Why Our Brains Play the “I‑Know‑What‑Everyone‑Does” Game  

Let’s pull back the curtain on the mental movie that runs when we decide to buy (or sell) something.  

1. **Evidence‑gathering stage** – You start pulling data, news headlines, analyst opinions, maybe even that meme about Sears’ “future of retail.”  
2. **Selective‑assembly stage** – As you sift, you **latch onto** pieces that *fit* your budding thesis and **push aside** the bits that contradict it. Think of it as a scrapbook where you only keep the flattering photos.  
3. **Memory‑availability stage** – After you finally click “BUY,” the supporting evidence is **fresh in your mind**, like that catchy jingle you can’t stop humming. The contradictory evidence, meanwhile, is tucked into a dusty attic of memory.  

Now, when someone asks, *“How many other traders will also go long on Sears?”* you instinctively **reach for the easy, vivid memories** – the headlines you loved, the charts that looked like a rocket. Because those memories are **readily available**, you assume they’re **representative** of what the whole market thinks. In reality, you’re just projecting **your own biased recall** onto the entire investing universe.

---

### Confidence: The Double‑Edged Sword  

Research by **Dr. Gary Marks and Dr. Norman Miller** (the guys who love tinkering with confidence levels) shows a neat pattern:  

| **Confidence Level** | **Accuracy of “How Many Others?” Estimate** |
|----------------------|---------------------------------------------|
| Low (uncertain)      | More realistic – you admit “maybe I’m wrong.” |
| High (certain)       | Way off the mark – you *believe* everyone’s on your side. |

In other words, the **more certain you feel**, the **greater the gap** between your estimate and reality. It’s like a magician’s trick: the louder the claim, the more skeptical the audience should be. This inflated consensus then **feeds back** into your ego, making you feel even **more invincible**.  

---

### How to Keep Your Ego in Check (and Not End Up Buying Sears at the Bottom of a Pit)  

1. **Play the Devil’s Advocate** – After you’ve gathered all your “buy” evidence, **force yourself** to hunt for the opposite. Pretend you’re a rival trader whose job is to *prove you wrong*.  
2. **Take a “Cold‑Water” Break** – Step away from the screen, grab a coffee, stare at a plant, or watch a cat video. Give your brain a chance to **reset** before you finalize the trade.  
3. **Ask the “Bias Check” Questions**  

   - *“Am I just cherry‑picking data that supports my view?”*  
   - *“Did I actually look at the studies that say Sears is in decline, or did I skim past them?”*  
   - *“What would a completely unbiased observer say about this decision?”*  

4. **Seek Outside Opinions** – Talk to someone who doesn’t share your investment circle. A fresh set of eyes can spot the blind spots you’ve been staring at for hours.  
5. **Quantify, Don’t Guess** – Instead of saying “I bet 70 % of traders will buy this,” look for **hard data**: analyst coverage percentages, institutional ownership stats, or even sentiment scores from reliable platforms.  

Remember, **your brain loves shortcuts**, and the false consensus effect is just one of those sneaky shortcuts. By **questioning the shortcut** and deliberately looking for contradictory evidence, you give yourself a better shot at making *objectively* sound decisions—rather than just feeling *subjectively* right.

---

### Bottom Line (Serve It With a Shot of Humor)  

- **We all think we’re the “average Joe” of the investing world**, but we’re actually more like the quirky cousin who wears socks with sandals.  
- **Confidence can be a liar**; the louder it shouts, the more likely it’s stretching the truth.  
- **Combat the bias** by being skeptical, seeking disconfirming data, and treating your own judgment as a hypothesis—not a gospel.  

So next time you’re tempted to shout, *“Everyone’s buying Sears, right?!”* take a breath, check your mental tape recorder, and maybe ask yourself, *“Or am I just the guy who thinks his pizza topping choice is the universal favorite?”*  

If you can laugh at the tendency to over‑estimate, you’ll be far less likely to let it steer your portfolio off a cliff. Cheers to smarter, bias‑aware investing! 🍻