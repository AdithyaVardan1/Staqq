# 257. The Disconnected Self  

**Source:** https://zerodha.com/varsity/chapter/the-disconnected-self/

---

The champion trader treats every trade like a boring meeting with the IRS –‑ just a number on a screen, nothing personal. Your ego, your “I‑am‑awesome‑because‑I‑made‑that‑money” complex, stays safely tucked in the pantry. The only thing on the line is cold, hard cash – an abstract, meaningless stake that can’t steal your favorite hoodie or ruin your karaoke reputation. A classic mantra to tattoo on the back of your mind (or at least write on a sticky note): *“Don’t let your net worth define your self‑worth.”*  

If you can channel your inner Spock, stare at charts with the same dead‑pan logic you’d use to decide whether to bring a fork to a soup‑only dinner, trading becomes a breeze. Profit will follow like a loyal dog after you toss a ball. In theory, it’s a slam‑dunk. In practice, it’s a bit more like trying to keep a cat on a leash while it’s being chased by a laser pointer.  

Performance peaks when the outcome truly **doesn’t** matter to you, but setting up that utopia is tougher than convincing your grandma to switch from butter chicken to kale smoothies. Most of the time, the result does matter, and the brain starts pulling emotional strings that tie each trade to your sense of self.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/04/20060522-300x300.png)

### When the Stakes Get Personal  

A stack of academic papers (the kind that make researchers look like they’re trying to solve the meaning of life) shows that tying performance to self‑esteem or to the satisfaction of basic psychological needs is a recipe for disaster. Imagine a sales rep whose paycheck evaporates unless they hit a *crazy‑hard* quota. The pressure is the financial equivalent of a treadmill set at 30 km/h – you’ll either sprint like a cheetah or face‑plant spectacularly.  

It’s the same as a college kid pulling an all‑night cram‑session for a final. The brain is fried, the coffee is gone, and the odds of pulling an A‑plus drop faster than the stock price of a meme coin after a tweet. When a trade’s outcome threatens your sense of security, identity, or ability to buy the next batch of avocado toast, the pressure cooker turns on, and you’re more likely to choke than to close a perfect position.  

### Lighten the Load – Or at Least Pretend It’s Light  

If you could be a multi‑millionaire who can afford to lose $5,000 a day without a single scar on your ego, the whole “I’m losing money, I’m a failure” narrative would evaporate like cheap vodka on a hot day. Unfortunately, most of us aren’t rolling in cash like a sitcom character who inherited a gold mine.  

The next‑best scenario is a modest account that funds your monthly “treat‑yourself” budget: gourmet tacos, a new pair of sneakers, that fancy coffee maker you’ve been eyeing. When the losses are small enough that they won’t make your landlord send a “friendly reminder” notice, the psychological pressure drops dramatically. But, let’s be honest, most traders don’t have this safety net.  

### When Trading Becomes Your Day Job  

Now, picture the “trader‑for‑a‑living” crowd –‑ the lone wolf who has to put food on the table, the hedge‑fund wizard juggling other people’s money like a circus performer with flaming swords. In these high‑stakes environments, every trade is a potential life‑changing event. Lose too much and you’re not just hurting your portfolio; you’re threatening your ability to pay the mortgage, your kids’ school fees, and your own self‑esteem.  

Your identity often hinges on being the *provider* or the *successful professional*. When a trade tanks, the internal voice goes, “I’m a terrible dad, I’m a bad husband, I’m a failure.” That voice is louder than the market’s noise, and it can snowball into a full‑blown anxiety episode that makes you want to hide under a blanket and binge‑watch cat videos.  

### How to Pull the Plug on the “Me‑=‑Money” Equation  

**1. Master Risk Management** – Think of it like buying insurance for your emotional health. If you set your stop‑losses so that a string of losing trades can’t wipe out a chunk of your life savings, you’ll sleep better. Knowing that the worst‑case scenario is “I’ll miss my latte today” rather than “I’ll have to sell my house” gives you the mental space to stay calm and logical.  

**2. Diversify Your Identity Portfolio** – You wouldn’t put all your retirement money into a single stock, right? Same logic applies to who you think you are. Don’t let “trader” be the only ticker on your personal balance sheet. Add other assets: *great friend*, *loving spouse*, *mediocre karaoke singer*, *avid Netflix binge‑watcher*, *responsible citizen*. The more “stocks” you own in yourself, the less any single loss (like a bad trade) can dent your overall net‑self‑worth.  

**3. Build a “Loss Buffer” Ritual** – Create a habit that makes losing $X feel as harmless as spilling a drop of water on the floor. Maybe it’s a quick dance move, a meme you send to a friend, or a reminder that “this loss is just a tuition fee for my market education.” The key is to re‑frame the pain into something trivial.  

**4. Separate the Clock** – When the market is open, treat it like a work shift: you’re on the clock, you follow the rules, you get paid (or not) for the hour. When the market closes, you clock out. Don’t let the after‑hours thoughts of “what if I’d taken that trade?” bleed into dinner conversation or bedtime stories.  

**5. Keep a “Self‑Worth Ledger”** – Write down three non‑trading achievements every week. It could be anything from “helped my kid with homework” to “finally fixed that leaky faucet.” Review it when you feel the temptation to equate your self‑esteem with the P&L. Seeing a list of real‑world wins reminds you that you’re worth more than a green candle on a chart.  

### Bottom Line  

The more you can uncouple your trading results from the narrative you tell yourself about who you are, the more you’ll be able to trade like a logical robot (or a very witty robot, if you’re feeling fancy). Risk management gives you the safety net; a diversified self‑identity gives you the emotional cushion; and a dash of humor keeps the whole thing from feeling like a funeral.  

So next time a trade goes south, picture yourself as a sitcom character who just spilled coffee on his shirt – embarrassing, but not life‑ending. Adjust your stop‑loss, take a breath, and remember: you’re still the same awesome human who can make a killer lasagna, crack a dad joke, and (most importantly) keep showing up at the market with a clear, Spock‑level mind. Cheers to trading with a *disconnected* self and a *connected* smile! 🍻