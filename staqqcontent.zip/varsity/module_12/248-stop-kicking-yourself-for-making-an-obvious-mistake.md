# 248. Stop Kicking Yourself For Making An Obvious Mistake  

**Source:** https://zerodha.com/varsity/chapter/stop-kicking-yourself-for-making-an-obvious-mistake/  

---  

John is literally giving himself a one‑person slap‑dance right now. He just watched a trade he thought would be a fireworks show turn into a soggy sparkler, and his ego is bruised. He’d spent the night visualising a champagne‑popping celebration, had crunched the moving‑average, plotted two months of highs and lows, and even set a stop‑loss that would make a safety‑first‑obsessed mom proud.  

But in his desperate quest to *feel* the win, he missed the one thing that would have saved the day: an upcoming earnings announcement. The company missed analysts’ consensus, the stock nosedived faster than a cat after a laser pointer, and John’s stop‑loss swooped in just in time to keep the damage from turning into a total catastrophe. Still, the sting is real—he built up the hype, and the reality was a deflated balloon.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/04/20060606-300x300.png)  

John’s misery isn’t a “new‑broke‑trader” exclusive. Even veterans get tripped up by the same brain‑snarl. Humans have a built‑in optimism chip that keeps us humming “I’ve got this!” even when the data is whispering “maybe not.” John isn’t clueless—he knows earnings can swing a price like a toddler swinging a swing set. Yet his desire to catch a big win was so fierce that his subconscious turned into a bouncer, barring any inconvenient info from the club of his thoughts. In other words, he was so busy seeing a unicorn that he ignored the horse standing right in front of him.  

### Why does John feel like he’s been punched by a brick wall?  

1. **Hope‑inflated expectations** – When you imagine a massive payout and the market says “nah,” the disappointment hits harder than a bad haircut.  
2. **Perfectionist self‑talk** – John’s inner critic is probably wearing a graduation cap and a “No Mistakes Allowed” badge, convincing him that a trader must be a crystal‑ball‑reading, all‑seeing oracle. The reality? If he’d remembered that earnings report, he could've saved a chunk of capital. But humans aren’t infallible; we’re prone to emotional hijacks that leave the rational brain in the backseat.  

### How does John stop the self‑flagellation?  

He needs to *re‑frame* the whole situation.  
When most of us mess up, our superego (that inner “parent” who still thinks we should eat our vegetables) jumps in, scolding us like a teacher who just caught us cheating on a pop‑quiz. The resulting feelings—shame, guilt, a vague sense of being “bad”—are relics of childhood discipline, not useful tools for a modern‑day trader.  

Instead of letting the unconscious equate a losing trade with a parental punishment, John should adopt the *trader’s perspective*:  

- **Traders are human** – They mess up, they learn, they move on.  
- **Full‑time, profitable traders are rarer than a unicorn in a cornfield** – The odds are stacked against anyone who thinks “everyone can trade profitably.” If you assume that the market is a playground for the elite few, a single mistake feels like a minor bump rather than a catastrophic crash.  

### The reality check that every trader needs  

1. **Mistakes are inevitable** – The market throws more data at you than a Netflix binge throws at your attention span. Your brain, already wired to chase money, will inevitably miss a piece of the puzzle now and then.  
2. **Trading is a marathon, not a sprint** – A single trade is a drop in a vast ocean of positions. If you obsess over one loss, you’ll feel like you’ve been hit by a freight train; if you view it as a tiny wave in a sea of trades, the impact is much more manageable.  
3. **Lower the hype, raise the resilience** – By keeping expectations realistic, you reduce the emotional “knock‑down” factor. When you stop building castles in the air, the occasional gust of wind (i.e., a losing trade) won’t flatten everything.  

### Bottom line: embrace the imperfect trader within  

When you finally accept that trading is about as easy as walking a tightrope while juggling flaming swords, you’ll start to **appreciate the wins** instead of **obsessing over the losses**. A losing trade isn’t a moral failing; it’s a data point. Treat it like a badly timed joke—note why it fell flat, learn the punchline, and move on to the next round.  

So, John, put down the self‑inflicted foot‑kicking, grab a coffee (or a mocktail if you’re feeling fancy), and remind yourself:

- **Few people actually make a living from day‑trading.**  
- **Every trade is one pixel in a massive picture.**  
- **Your brain will always try to convince you that you’re the star of a blockbuster—sometimes it just forgets the script includes “earnings report” as a plot twist.**  

With that mindset, the next time you spot a potential trade, you’ll still get excited—but you’ll also double‑check the calendar, set a stop‑loss, and maybe, just maybe, spare yourself the post‑trade drama. And if you do slip up? Good—another lesson for the “trader‑school‑of‑hard‑knocks” syllabus.  

Happy (and slightly less self‑punishing) trading!  