# 303. Goal Setting: Don’t Set Performance Goals Too High  

**Source:** https://zerodha.com/varsity/chapter/goal-setting-dont-set-performance-goals-too-high/

---

Sam rolled into the trading world three months ago, fresh‑off the “buy‑low‑sell‑high” YouTube binge. He’s read the golden rule: *set specific goals and chase them like a dog after a steak.* His brain, however, decided that the only way to stay motivated is to crank the expectations up to “rocket‑ship” level. “I’ll lock in a 20 % profit every month,” he declares, waving his imaginary cape. “If I don’t aim for the stratosphere, I’ll never get off the ground.”  

Big, glittering dreams are the fuel that can get the engine humming, but there’s a fine line between “I’ll be a billionaire by 30” and “I’ll become a competent trader without blowing up my account.” The former is a *vision*; the latter is a *goal* with a realistic, step‑by‑step roadmap.

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/05/20050207-294x300.png)

### The science‑savvy side of goal setting  

Industrial psychologists have been poking around this topic for decades, and the verdict is clear: **sky‑high performance goals aren’t always the best targets.** Why? Because most of us start out with a skill set that’s more “couch‑potato” than “marathon runner.” Imagine trying to sprint a 20‑mile marathon when you can’t even jog to the fridge without getting winded—sounds ridiculous, right? The same principle applies to trading. If you haven’t yet mastered the basics, aiming for a 20 % monthly return is like trying to fry an egg on a snowball: technically possible, but you’ll end up with a cold mess and a bruised ego.

Novices love the “shoot for the stars” mantra. It feels safe to say, “I’ll make 20 % a month,” because if you *don’t* even think about it, you might never try. High standards can be a good thing, but research shows that **how you chase a lofty goal matters more than the lofty goal itself.** When you chase a goal that outpaces your current abilities, you’re more likely to stumble, get discouraged, and bail on trading altogether.

### Performance goals vs. learning goals – the real showdown  

Most rookie traders, Sam included, default to **performance goals**: “I want X % profit this month.” They’re crisp, quantifiable, and sound impressive on a résumé. Yet for someone still figuring out the difference between a “stop‑loss” and a “stop‑coffee‑break,” a **learning goal** is the smarter companion.

A learning goal is modest, achievable, and—crucially—**builds competence**. Think of it as breaking a massive pizza into bite‑size slices so you don’t choke. For example:  

> “I’ll devote 30 hours a week to studying a new trading technique, and I’ll back‑test it on historical data before risking real money.”

That goal won’t magically slap a 20 % profit on your account the next day, but it will give you a sense of progress, a dopamine hit for every hour logged, and, over time, the skill foundation needed to chase higher returns without pulling your hair out.

### Your action plan: win now, win big later  

If you’re a fresh‑face trader, set yourself up for *wins*—the kind that feel good and keep you in the game. Here’s a cheat‑sheet:

1. **Swap the 20 % performance goal for a learning goal.**  
   *Example:* “Study 2‑hour video lessons on candlestick patterns three times a week.”
2. **Break the learning goal into micro‑tasks.**  
   *Example:* “Identify 5 bullish reversal patterns on a daily chart, write a short note on each.”
3. **Reward yourself for each micro‑win.**  
   *Idea:* Treat yourself to a fancy coffee or a new playlist after you log 5 study sessions.
4. **Re‑evaluate every month.**  
   When you can consistently spot patterns and execute trades with a low error rate, upgrade to a modest performance goal—say, “aim for 5 % profit this month while maintaining a max 2 % drawdown.”
5. **Scale up only when skill catches up with ambition.**  
   Once you’ve logged a few successful months, the 20 % target becomes less of a fantasy and more of a calculated stretch.

Bottom line: **Don’t let your imagination outrun your education.** High‑flying performance goals are great for day‑dreaming, but learning goals are the runway that actually gets you airborne. Focus on building the chops, celebrate the tiny victories, and when you’re finally ready, those big‑ticket returns will feel less like a gamble and more like a well‑earned paycheck.

So, dear novice, keep the cape, but start with the training wheels. The market will respect you more when you’re competent than when you’re just over‑optimistic. Happy learning—and may your charts be ever in your favor!