# 259. Extreme Patience  

**Source:** https://zerodha.com/varsity/chapter/extreme-patience/  

---  

Did you jump on the stock‑market hype train earlier this year, only to watch the ride sputter and wonder why you ever thought “buy low, sell high” was a good idea? If you’re the type who lives for quick‑in‑and‑out trades, the instinct might be to cut your losses, shake hands with the market and move on. But if you’ve pledged allegiance to the “buy‑and‑hold” flag, you’ll probably feel a tug‑of‑war between “I’m a patient investor” and “My portfolio looks like a sad‑face emoji right now.”  

The last few months have been a bit of a market‑wide snooze‑fest, with most indices sliding down a few notches. That’s the perfect recipe for the “sell‑now‑or‑wait‑forever?” dilemma. Long‑term investors often have to sit on a seat for months, hoping that the companies they love will eventually hit their target price. It’s not easy to stare at a chart for that long without starting to imagine the numbers as a horror‑movie villain: “Will it ever come back?”  

While you’re staring at that red‑inked line, it’s normal for your brain to start playing the “what‑if” game—*what if I’m just fooling myself?*—while simultaneously whispering, “Hey, maybe this dip is a bargain!” Only you can decide whether a particular position will resurrect and give you a sweet profit, but remember: a lot of analysts are still bullish on the macro‑economy. In other words, the market’s got a lot of hidden upside this year—if you can survive the waiting‑room.

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/04/20060518-300x300.png)

If you’re a bona‑fide buy‑and‑hold devotee, patience isn’t just a virtue; it’s the *secret sauce* that makes the whole dish taste good. Unfortunately, many investors have the attention span of a goldfish on a caffeine binge and end up pulling the plug on a position far too early. Think about it: would you sell your house because the neighborhood’s house‑price index dropped a few percent last month? Probably not—your home isn’t on a daily ticker tape, and the local paper doesn’t scream “Your house is now worth $200,000 less!”  

Stocks, on the other hand, are the clingy ex‑partner that sends you a text every five seconds. You can check the price every market open, every lunch break, and every time you scroll through Instagram. Those minute‑by‑minute fluctuations turn a calm investor into a roller‑coaster rider, swinging from “I’m on a roll!” to “I’m doomed!” The more you stare, the higher the chance you’ll do something impulsive—like selling at the bottom because you’re “fed up” with the dip.  

So how do you master the art of Zen‑like waiting? The simplest trick is to **stop looking**. If you can’t see the price, you can’t panic about it. Sounds easy, right? Spoiler alert: it’s not. The nightly news loves to sprinkle market updates like confetti, and the morning paper is practically a billboard for the S&P‑500’s latest mood swing. If you’re the type who can’t resist a headline like “Stocks Plummet—Is This the End?” you’ll be tempted to pull up your broker app faster than you’d grab the last chicken wing at happy hour.  

If you truly struggle with patience, treat the market like a candy bowl you’re trying not to raid. You don’t keep the bowl on the kitchen counter and stare at it— you **put it in the cabinet**. In investing terms, that means:  

- **Turn off market alerts.** No push notifications flashing “Your stock is down 5%!”  
- **Skip the finance‑section scroll.** If you can’t find it, you can’t obsess over it.  
- **Set a reminder, not a watch‑list.** Write down *why* you bought the stock, tuck the note away, and revisit it only when your original timeline arrives.  

Your first reaction might be, “What? That sounds ridiculous!” but think of it this way: you’re trying to wait six months for a trade plan to bloom. If the only way to survive those six months is to lock the candy bowl in a safe, then lock the ticker in a safe.  

Long‑term investing isn’t a sprint; it’s more like a slow‑cooked stew. The longer you let it simmer, the richer the flavor (and the fatter the profit). So, give your positions the space they need, stop checking the price every five minutes, and trust that, in a few months, you’ll be toasting the gains instead of crying over the losses. Cheers to extreme patience—may your patience be as strong as your favorite bourbon and your returns as sweet as a perfectly timed punchline. 🍻