# 22. The Flexible and Disciplined Trader  

**Source:** https://zerodha.com/varsity/chapter/the-flexible-and-disciplined-trader/  

---  

Flexibility and discipline are the peanut butter and jelly of successful trading – you can’t have one without the other, or you’ll end up with a sad, dry sandwich.  In the classic *Electronic Day Traders’ Secrets* (yes, that’s a real book, not a Netflix series), Friedfertig, West, and Burton sum it up nicely:  

> “Discipline is saying ‘I’m wrong, I’m getting out of the stock and actually doing it.’ Sometimes you’ll be long on a stock and all of a sudden it’s falling. Undisciplined people get stubborn and say, ‘It’s going to go up,’ or ‘It’s going down, I’ll buy more and eventually it will go back up.’ The discipline to admit when you are wrong, get out, and not take a big loss is what makes a great trader.”  

Picture a trader who’s as flexible as a yoga instructor on a cruise ship. He looks at each trade from a dozen angles, and he isn’t afraid to ask, “What if the market decides to go rogue today?” He knows that being wrong isn’t a personal affront—it’s just part of the game, like spilling your beer at the bar. In fact, the best traders *expect* to be wrong sometimes; they keep a spare “I’m wrong” hat handy.  

Why does owning the “I’m wrong” badge feel so liberating? Because it strips away the defensive armor. When you’re not busy defending a position like a knight protecting a castle, you can relax, sip your metaphorical espresso, and close a losing trade without the drama of a soap‑opera cliff‑hanger. No more clinging to a losing position like a toddler to a balloon, hoping it’ll magically float back up. No more letting fear and greed turn your account balance into a roller‑coaster that makes theme‑park engineers jealous.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2019/12/20070621.png)  

### Fear: The Trader’s Worst Frenemy  

Fear is the ultimate party pooper for a trader. When it shows up, you become as stiff as a boardroom‑style PowerPoint slide—rigid, unbending, and impossible to read. In the wild, that “fight‑or‑flight” reflex is a lifesaver; you either swing a club at a lion or sprint away from a pack of wolves. But in the market, the “lion” is usually just a candlestick pattern, and the “club” is a stop‑loss order.  

When fear hijacks your brain during a trade, you freeze. Your subconscious whispers, “Something’s wrong, abort mission!” and you zoom in on that single, terrifying scenario—like selling a winner too early because you’re terrified it’ll turn into a pumpkin, or hugging a loser for dear life because you’re convinced it will miraculously rebound. In both cases you’re playing a one‑track mind game, ignoring the fact that the market is a 24‑hour buffet of possibilities.  

Fear also sneaks into the *planning* stage. The rigid trader, trembling under the weight of a secret doubt, thinks, “What if my plan blows up?” Instead of drafting a contingency plan, he writes a single‑track script that assumes everything will go exactly as imagined. Imagine betting that a stock will climb all week while secretly wondering whether an earnings report, a surprise rate hike, or a sudden meme‑stock frenzy will dump it like a sack of potatoes.  

A rigid, fear‑driven trader will shy away from those “what‑if” scenarios. He’ll pretend the market is a perfectly predictable sitcom where every episode ends the same way. The flexible trader, on the other hand, rolls up his sleeves, grabs a notepad, and lists every plausible twist: earnings, macro‑policy shifts, geopolitical fireworks, you name it. He then assigns probabilities, decides how each scenario would affect his position, and builds backups—like stop‑losses, hedge legs, or even a Plan B (or C).  

That openness to every possible outcome is the secret sauce that lets a flexible trader pivot on a dime, recover from a setback faster than you can say “margin call,” and keep his sanity intact.  

### The Payoff: Effortless, Objective, Profitable Trading  

When you master the art of flexibility, trading stops feeling like a high‑stakes poker game with a blindfold on. You become the calm bartender who can read a room (or a market) at a glance, serve the right drink (or trade), and keep the bar (your account) humming profitably.  

Objectivity rises to the surface because you’re no longer fighting an inner battle of “I’m right!” vs. “I’m wrong!”—you’re simply observing the market’s mood swings and responding like a seasoned improv comedian: quick, witty, and never stuck on the same joke.  

In the long run, that blend of disciplined “I’m wrong, I’m out” reflexes and flexible, scenario‑testing foresight translates into higher win‑rates, smaller drawdowns, and a portfolio that feels more like a well‑tuned band than a screeching siren. So, next time you’re tempted to clutch a losing trade like a security blanket, remember: the real power lies in the freedom to let go, adapt, and keep the party (your capital) going strong.  

---  

*Bottom line:* Be the trader who can bend like a reed in a storm **and** snap back like a rubber band when the wind changes. Your future self (and your bank account) will thank you.  