# 264. Don’t Make a Drawdown Even Worse  

**Source:** <https://zerodha.com/varsity/chapter/dont-make-a-drawdown-even-worse/>

---

Stan’s been in a slump. He’s made very few winning trades in the past month. He’s starting to question his skills as a trader and wondering if he will ever return to profitability. He has taken it hard. Usually, Stan is energetic and ready to face the trading day with enthusiasm and vigour. But recently, he has approached the start of the trading day with dread and skepticism. Stan usually gets up early, changes into a comfortable pair of jeans and a golf shirt, and goes to his favorite diner for a light breakfast.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/05/20060213-300x300.png)

But these days, he stays in his bathrobe and doesn’t bother going out. He reasons, “I might as well save the money on food and dry‑cleaning and just stay home. I’ll need the extra cash to recover from this drawdown.” There’s a problem with Stan taking the drawdown so hard: he’s just making matters worse.

Slumps and drawdowns are a fact of trading. One should expect them. But Stan is over‑interpreting the significance of a drawdown. He’s letting it shake his confidence and he is changing his attitude and his behaviours to reflect a bleak, pessimistic outlook. However, it’s vital to stay optimistic in such times. **Don’t make a drawdown even worse.**

---

## When the market throws a tantrum, we all get a little shaky  

When events don’t go our way, we are especially vulnerable. Everyone has the potential to feel a little uneasy and question one’s skills and confidence when nothing seems to be going right. Suddenly, all the memories of our past glories may be forgotten and all our defeats brought to the forefront.

At that point, the **availability heuristic** may bias our outlook. This fancy‑sounding psychology term simply means that we judge the probability of future events by how easily examples pop into our heads. If the most recent memories are of losing trades, those loss‑scenes become the mental wallpaper and we start predicting more loss. Conversely, if the most vivid snapshots are of that time we turned a ₹10,000 position into a ₹100,000 windfall, we may become cocky enough to bet the farm on a single candle.  

A little over‑confidence when you’re already in a pit of despair can actually be the better evil than spiralling into full‑blown dread. It’s the “fake‑it‑til‑you‑make‑it” version of trading psychology—just don’t let the “fake” turn into a full‑blown gamble.

---

## Stan’s spiral: a masterclass in self‑sabotage  

Stan has taken the availability heuristic, tossed it into his blender, and hit “puree.” By changing his behaviours to match his pessimistic outlook—skipping the morning coffee, staying in pajamas, and treating his trading desk like a dusty attic—he amplified his own misery.  

What he *should* have done is the exact opposite: act **as if** the routine that usually works is still the best weapon in his arsenal. Put on the same jeans and golf shirt, order the same bacon‑egg‑cheese on a toasted bun, and walk to the diner like a man on a mission (even if the mission is just to get caffeine).  

Sticking to the ritual does two things:

1. **Keeps the brain anchored** – Our nervous system loves patterns. When you repeat a familiar pattern, the brain releases a modest dose of dopamine, reminding it that “hey, this is the way we win.”  
2. **Stops the negative feedback loop** – If you keep acting like a depressed hermit, you feed the brain the narrative “I’m a loser, I’ll stay home.” If you keep acting like a normal trader, you deny that narrative the chance to take root.

Sure, he’d still feel a little jittery. That’s normal—just like you still feel nervous before a first‑date even if you’ve dressed to the nines. But at least the jitter won’t be amplified by a self‑fulfilling prophecy that says “I’m doomed, so I’ll do nothing.”  

In all likelihood, the slump would have passed, the drawdown would have started to shrink, and Stan would have been back to turning his “green” candles into green‑backed profits. Instead, his pessimistic view and corresponding pessimistic behaviours created extreme feelings of despair, which in turn poisoned his trade‑execution decisions—leading to *even more* losses.  

---

## The bottom line: keep the ship sailing, even in a storm  

Trading is a challenging business. It’s essential that you maintain an objective, rational approach to trading. But there are times when slumps and drawdowns can shake the confidence of even the most astute trader. It’s at these times that one must be especially careful to avoid falling prey to pessimism and despair.  

Think of a drawdown like a rainstorm on a road trip. You can either pull over, stare at the puddles, and convince yourself you’ll never finish the journey, or you can roll down the windows, crank up the playlist, and keep the wheels turning. The latter won’t magically make the clouds disappear, but it *will* get you to the next sunny stretch.  

So, when the numbers turn red and the market whispers “nope,” remember:

- **Don’t trade the emotions** – keep your routine, keep your coffee, keep your jokes.  
- **Use the availability heuristic wisely** – remember that a single loss isn’t the whole story; your winning trades are still stored somewhere in the mental attic.  
- **Stay optimistic, not reckless** – a pinch of confidence is good, a pinch of “I’m the next Warren Buffett after one trade” is hazardous.  

In short: don’t make a drawdown even worse. Dress up, eat breakfast, log in, and trade like the trader you *usually* are. The storm will pass, the green will return, and you’ll have a funny story to tell at the bar about the time you almost let a little red line ruin your whole wardrobe. Cheers! 🍻