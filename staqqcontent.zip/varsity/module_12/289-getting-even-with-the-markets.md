# 289. Getting Even With the Markets  

**Source:** https://zerodha.com/varsity/chapter/getting-even-with-the-markets/  

---  

Trading decisions are rarely born in a sterile lab of logic; they’re usually the love‑children of fear, hope, greed, regret … and, oh yeah, good old‑fashioned anger. After you watch a trade go south faster than a cheap airline’s Wi‑Fi, you’ve probably heard (or muttered under your breath) “I’m going to get even with the markets.” Maybe you’ve even shouted it at the screen like a pirate cursing a storm. That urge to settle the score is pure anger‑fuelled revenge. Anger pops up when we feel someone—or something—has slapped us unfairly. In the trader’s mind, the market (and the swarm of humans behind it) *should* hand out profits on a silver platter. When the platter is empty, the brain automatically blames the market for “wronging” us.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/05/20060307-300x300.png)  

## Why Anger Is a Bad Trading Buddy  

Anger is like that rowdy friend who shows up at a quiet dinner and starts a food fight. It gets you ready to battle, eyes glued to any perceived slight, and drains the part of your brain that’s good at counting risk‑reward ratios. When you’re fuming, you’re more likely to swing at the first “enemy” you see—usually a sudden dip or a whiff of volatility—rather than pausing to ask, “Hey, is this actually a problem?” Good decision‑making, especially in markets, demands a cool head; otherwise you’re just trading on fumes.  

## Chill Out: No Need to Hold a Grudge Against the Market  

### 1. Stop Treating the Market Like a Petulant Ex  

Anger is an *interpersonal* emotion. We get mad at people because we think they meant to hurt us on purpose. The market, however, is a massive, impersonal mechanism—think of it as a giant, indifferent weather system, not your grumpy roommate. Sure, there are millions of humans placing orders, but none of them are out there personally trying to sabotage your portfolio. If you picture the market as a faceless, abstract force (like gravity or the internet), the urge to “take it out on it” evaporates faster than a cheap cocktail on a hot night.  

### 2. Dump the Pre‑Game Fantasies  

Most anger erupts when reality smacks our expectations into the wall. “I’m *sure* this trade will make me rich!” is a classic setup for a disappointment‑driven tantrum. The markets don’t owe you any profit; they’re neutral. Assuming you’ll win on every ticket is like betting the house on roulette because “the wheel looks friendly today.” Accept the fact that loss is part of the game—statistically, a trader will lose more often than win. By wiping the slate clean of lofty expectations (think “I’ll double my money in a week”) you remove a major trigger for rage.  

### 3. Make Peace with Losing  

Admitting a loss is tougher than admitting you still binge‑watch cartoons on a Saturday night. The old trading mantra, “Cut your losses short and let your profits run,” is really a polite way of saying, “Don’t let a losing position turn into a full‑blown tragedy.” If you can’t swallow a modest loss, you’ll keep chasing revenge trades, which usually end up more expensive than the original mistake. Train yourself to treat a loss like a spilled drink—unpleasant, but not worth ruining the entire night over.  

## Bottom Line: Keep Your Cool, Keep Your Capital  

If you manage to dial down the anger, you’ll notice three pleasant side‑effects: less stress (your heart won’t feel like it’s doing a marathon), sharper, more rational decisions (your brain will actually use the stop‑loss you set), and—most importantly—trading becomes enjoyable again instead of feeling like a personal vendetta. So next time the market throws you a curveball, don’t reach for the boxing gloves; reach for the coffee, take a breath, and remember that the market isn’t out to get you—it’s just… indifferent. And that, my friend, is the sweetest revenge of all.  