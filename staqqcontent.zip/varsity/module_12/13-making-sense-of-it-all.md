# 13. Making Sense of it All  

**Source:** https://zerodha.com/varsity/chapter/making-sense-of-it-all/  

---  

Social psychologists love to call us “lay scientists.” Why? Because, just like the lab‑coat crowd, we spend our free time forming hypotheses about the world, testing them, and (usually) writing them down on a napkin over a beer. The only difference is that we don’t have fancy equipment or grant money—we have our daily market charts, a cup of chai, and a healthy dose of curiosity.  

When we try to figure out how the market works, we’re basically doing informal experiments with the data that scrolls across our screens. We create personal theories—maybe “oil price spikes always push energy stocks up” or “the market hates news about hurricanes.” Since we’re not running controlled experiments, our brains are prone to a few classic psychological potholes. One of the biggest is the **false consensus effect**: we *incorrectly* assume that everyone else thinks and acts the way we do. In other words, we think our perspective is the “normal” one, and that can lead us straight into a trading blind‑spot.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2019/11/20041118.png)  

### The short‑term trader’s crystal ball: “What will the masses do?”  

Short‑term trading is basically a game of “Guess What the Crowd Is Going to Do Next.” Will they all rush to buy? Will they collectively sprint for the exit? It sounds simple until you remember that human crowds are about as predictable as a cat on a hot tin roof.  

Take the last two weeks, for instance. The world was throwing a triple‑threat combo at us: a war in the news, a hurricane making landfall, and oil prices doing their best impression of a roller‑coaster. Logically, you’d expect everyone to dump their positions and run for the hills. Yet the markets kept on marching. The point? **You can’t always forecast the collective reaction to world events**—no matter how many headlines you read or how many doom‑scrolling sessions you have. Getting the “right” perspective is like finding a clean bar stool at happy hour: possible, but you might have to look a little harder.  

### Why is reading the crowd so tricky?  

Part of the difficulty is that we’re just **mortals**—not omniscient, all‑seeing AI bots. Our brains have a limited bandwidth for processing complex, high‑dimensional information. Sometimes we’re better than a computer (think pattern‑recognition in noisy charts), and sometimes we’re worse (think remembering that one time you lost 10 % on a penny‑stock). To cope, we lean on mental shortcuts called **heuristics**—the “rules of thumb” that keep us from drowning in data.  

One such shortcut is the **false consensus effect**. Social psychologists have repeatedly shown that, regardless of the decision at hand, people *over‑estimate* how many others share their view. We love to think, “My decision is normal, sensible, and everybody else would do the same.” That’s the mental anchor we hang our confidence on. After we make a trade, we become **over‑confident**, convinced that our call is the gold standard and that the crowd will eventually catch up. In reality, if we could swap shoes with a fellow trader for a day, we might discover that they would react in a completely different way.  

### The brain’s storytelling habit  

Why does this bias happen? It’s all about how we **construct memories**. When we decide on a position, we cherry‑pick evidence that backs up our choice and shove contradictory data into a mental drawer labelled “irrelevant.” Once the decision is made, the supporting evidence becomes *hyper‑available* in our memory—like that one song you can’t get out of your head.  

Later, when someone asks, “How many people will take the same trade?” we reach into that same memory shelf, pull out the evidence that *we* found convincing, and assume it’s the evidence everyone else is using. In short, we base our estimate on **our biased recollection**, not on any objective survey of the market’s mood.  

### The trader’s daily dance with false consensus  

In the trading arena, this bias shows up more often than you’d think. Every time you stare at a chart and try to guess the next wave of buying or selling, you’re projecting your own mental model onto the crowd. Your data interpretation is filtered through the lens of “what I think should happen,” which may be wildly off‑base.  

### How do we kick the false consensus out of the trading room?  

1. **Awareness is the first line of defense.** Knowing that the bias exists is like putting a “wet floor” sign on a slippery patch—you’ll watch your step.  
2. **Accept imperfect information.** Markets are messy; your data will always be incomplete. Embrace that fact rather than pretending you have a crystal ball.  
3. **Stay a touch skeptical.** Even if your analysis feels airtight, ask yourself, “What would a contrarian say? What am I missing?”  
4. **Manage risk like a pro.** Use stop‑losses, position sizing, and diversification so that a single wrong guess doesn’t blow up your account.  
5. **Be ready to admit you’re wrong.** Human beings are prone to bias; that’s just biology. Instead of beating yourself up, treat each mistake as a data point for the next experiment.  

In short, the false consensus effect is a sneaky roommate that loves to hog the couch of your decision‑making. By keeping the lights on (i.e., staying aware), checking the thermostat (i.e., managing risk), and occasionally kicking the roommate out (i.e., questioning your assumptions), you’ll navigate the market with a little more humility—and a lot more profit potential. After all, you’re only human, not a mind‑reading superhero. Cheers to learning, laughing, and trading smarter!  