# 277. Emotional Influences on Trading Decisions  

**Source:** https://zerodha.com/varsity/chapter/emotional-influences-on-trading-decisions/  

---  

We all know the market loves to mess with our nerves. When the “fear monster” whispers, “What if I lose everything?” we sprint to the exit and sell. When the “greed gremlin” shouts, “Buy now, you’ll be rich!” we throw cash at the ticker like it’s a confetti cannon. Behavioural economists, however, think the drama is a bit richer than a simple “fear‑vs‑greed” sitcom. Enter the supporting cast: **regret** and **hope**. You might hold onto a loser because you can’t stand the idea of “I should’ve sold earlier,” or you keep a sinking ship alive, hoping it will magically turn into a yacht.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/05/20060323-300x300.png)  

Emotions are the backstage crew that pull the levers on every trade decision.  Some of them are loud and obvious—like the panic that hits when a position tanks and you feel like crying into your coffee.  Others are sneaky background noises: a bad night’s sleep, a traffic jam, or a toddler’s tantrum can make you click “Buy” when you meant to click “Cancel.”  When the drawdown gets deep enough, you might start feeling a blend of depression and “I’m done with this whole trading thing” that could make a monk reconsider his vows.  Those are the **obvious** emotional influences.  

But recent lab‑coat‑wearing research tells us that even the most **subtle** feelings can nudge our economic choices.  Dr. Jennifer Lerner of Carnegie Mellon has been playing emotional‑Jenga with traders for years.  One of her classic experiments found that folks who are quick to feel **anger**—the hot‑head who gets offended when the market “snubs” them—are also more willing to roll the dice on risky bets.  Why?  Because anger fuels a desire for control and revenge: “If the market won’t respect me, I’ll *show* it.”  The result?  Impulsive, over‑leveraged trades that you’d normally flag as “bad idea, buddy.”  

Other feelings—**disgust** and **sadness**—also tip the scales, even though they have nothing to do with money at all.  In a 2016 paper in *Psychological Science*, Lerner’s team gave participants a little emotional “cocktail” by showing them two very different short films.  One was a tear‑jerker about a loved one passing away (sadness), the other a cringe‑fest of a man using a filthy public toilet (disgust).  After the tissues were wiped away, each participant was handed a pen, told to keep it, and then asked: “If you were to sell this pen, how much would you get?”  

Here’s the kicker:  
* **Neutral‑mood participants** estimated the pen’s worth at **≈ $4.50**.  
* **Sad** and **disgusted** participants both slashed that number to **≈ $3.00**.  

No logical link exists between a crappy toilet or a heartbreaking story and the price of a writing instrument. Yet the mood swing **under‑valued** the pen, making the participants more eager to “sell” it cheap.  In trader‑speak, it’s like watching a sob‑fest right before the market opens, then dumping a perfectly good position because you *feel* it’s worth less—even though the fundamentals haven’t moved a hair.  

So, while we’d love to be Spock—cold, logical, and impervious to sentiment—our human circuitry is wired for drama.  Fear, greed, hope, and regret are the headline acts that most traders recognize.  The real surprise is that **incidental emotions**—the ones you pick up from a bad movie, a spicy burrito, or a traffic jam—can also bias the numbers you put on a trade.  That’s why trading is as much a psychological marathon as it is a numbers game.  

**Bottom line:** keep the extreme emotions on a leash.  The calmer and more objective you stay, the less likely you’ll sell a winning stock too early, hold onto a loser forever, or gamble away your capital because you’re angry at the market for “disrespecting” you.  In other words, treat your brain like a well‑tuned trading algorithm—run it on clean data, not on the drama of the day.  

---  

*Remember: the next time you feel a pang of sadness after a Netflix binge, ask yourself whether you’re about to price‑tag your portfolio with the same gloom.* 🍿📈