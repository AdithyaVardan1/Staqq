# 141. Avoid a Potential Disaster: Anticipate Earnings Reports  

**Source:** https://zerodha.com/varsity/chapter/avoid-a-potential-disaster-anticipate-earnings-reports/

---

When you sit down with a bunch of short‑term traders and ask them whether they ever glance at a company’s fundamentals, you’ll usually get an eye‑roll that could power a wind turbine. And honestly, for the pure‑day‑trader, that reaction isn’t completely off‑base. Fundamentals tend to move at a glacial‑tortoise pace, while day‑traders are busy riding the cheetah‑fast price spikes that happen every few minutes.  

But here’s the kicker: the longer you keep a position open, the more you expose yourself to the *slow‑but‑deadly* side‑effects of those fundamentals. Think of it like staying out past curfew—sure, you might have fun, but the risk of getting caught (or worse, a “home‑coming” surprise) rises with every extra hour. For anyone whose time horizon stretches beyond a single trading session, earnings season is the **big‑bang** of corporate news that you simply can’t ignore.

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/02/05-233x300.png)

## Why earnings are the “volatility volcano” of a single stock  

Earnings releases are basically the market’s version of a surprise birthday party—except instead of cake, you might get a massive price swing. The moment a company is scheduled to spill the beans on revenue, profit, and that mysterious “guidance” line, traders start twitching like cats near a laser pointer. If you’re not watching the calendar, you’ll be the one left holding a stock that just decided to do a 180‑degree pirouette.

Ignore the earnings calendar and you’re basically gambling **blindfolded**, hoping the dealer won’t pull a rabbit out of the hat. Real‑world evidence shows just how nasty this can get:

| Company | What Happened? | Numbers to Remember |
|---------|----------------|---------------------|
| **Microsoft (MSFT)** | Missed estimates → stock dropped **~7%** overnight. | No bounce‑back yet; still nursing the wound. |
| **IBM** | Earnings disappointment → **4%** plunge, still recovering two weeks later. | |
| **JCOM** | Night before earnings: closed at **₹43.84**. Next morning opened at **₹36.71**; now trading **under ₹30**. | A textbook “earnings‑day disaster”. |
| **Netease (NTES)** | Revenue up **97% YoY**, but missed the estimate by **two pennies**. Stock fell **>14 points** (about **21%**). | Proof that even a *tiny* miss can be catastrophic. |

These aren’t isolated flukes; they’re the warning lights flashing “don’t ignore earnings”.  

## Strategy #1: Stay home (or stay flat) until the fireworks are over  

The simplest, most “no‑brainer” approach is to **avoid holding any position overnight** when an earnings release is due. It’s like not drinking the punch at a party when you know the bartender is about to drop a surprise ingredient. You stay sober, you stay safe, and you avoid the hangover of a sudden price crash.

But let’s be real—sometimes you *want* exposure because you think the stock is about to pop like a champagne bottle. So we need backup plans that let you stay in the game without getting knocked flat.

## Strategy #2: Insurance‑style protection with a protective put  

Imagine you’re long a stock and you’re nervous about a potential earnings‑day nosedive. You can buy a **protective put**—the options equivalent of buying a “raincoat” for a forecasted storm.  

- **What is a put?** It’s a contract that gives you the *right* (but not the *obligation*) to sell the underlying stock at a predetermined strike price before expiration.  
- **How does it work as insurance?** If the stock tanks after earnings, you can still sell at the strike price, limiting your loss. If the stock stays afloat, the put expires worthless, and you’re out the premium you paid—just like an insurance premium you never collect back.

The same logic flips for short positions: a **protective call** caps your upside risk if the stock unexpectedly rallies after a bad earnings surprise.

## Strategy #3: Play the upside with limited downside – buy calls instead of the stock  

Sometimes you’re **bullish** on a company but you don’t want to risk a full‑blown stock purchase. Enter the **call option**.  

1. **Buy a call** with a strike near the current price and an expiration after the earnings date.  
2. **If the earnings beat expectations** and the share price rockets, the call’s intrinsic value climbs, and you can sell the contract for a tidy profit.  
3. **If the earnings bomb** and the stock crashes, your loss is capped at the **premium** you paid for the call—no more, no less.

Because the premium is usually a **fraction** of the cash needed to own the same number of shares, your risk is **defined** and much smaller.  

**Caveat:** Options are not free lunches. Two things can still eat your premium away:

- **Time decay (theta):** As the clock ticks toward expiration, the option’s extrinsic value erodes, even if the stock sits still.  
- **Volatility crush:** If the market’s implied volatility spikes before earnings (which it usually does) and then collapses after the results, the option can lose value even if the stock moves in the right direction.

So, while a call caps your downside, you still need to be comfortable with the possibility of *losing the entire premium*.

## Bottom line: Plan, don’t panic  

The most bullet‑proof way to survive earnings day is to **avoid overnight exposure**. If that’s not feasible (because you’ve already committed capital or you simply love the thrill), then **manage the risk** with one of the options tricks above.  

- **Know the calendar.** Mark every earnings date on your trading diary.  
- **Decide your risk appetite.** If a 7% surprise loss would make you lose sleep, hedge or stay flat.  
- **Have an exit plan.** Whether it’s a stop‑loss, a protective option, or a pre‑planned exit after the earnings announcement, don’t be caught flat‑footed.

Earnings reports are *big‑ticket* events that can move a stock as dramatically as a roller‑coaster’s first drop. Treat them with the respect they deserve, and you’ll dodge the “earnings‑related disaster” headline. Your portfolio will thank you, and you’ll still have stories to tell at the bar—minus the regret‑filled “I should’ve known better” punchlines. Cheers to smarter trading!