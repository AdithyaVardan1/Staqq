# 223. Learn the Rules Before You Decide to Break Them  

**Source:** <https://zerodha.com/varsity/chapter/learn-the-rules-before-you-decide-to-break-them/>

---  

Seasoned traders love to whisper in your ear, “Question everything you hear as a trader.”  It’s the kind of advice that sounds like a fortune‑cookie warning, but it’s worth more than the cookie itself.  The internet is full of self‑proclaimed “trading gurus” who will gladly hand you a shiny system, a miracle indicator, or a secret sauce that will turn you into the next Warren Buffett overnight.  Spoiler alert: most of those sauces are either *mystery meat* or plain old hot sauce that only burns your pocket.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/04/20061130-300x300.png)

The reason trading feels like wandering through a maze of half‑truths and outright lies is that **valid and invalid information coexist in the same market**.  If you’ve been in the game long enough you’ll start recognizing the classic tale: a bright‑eyed rookie latches onto a “guru” who promises a 90 % win‑rate, only to discover that the guru’s method was either built on a market regime that vanished in 2002 or simply never produced the advertised numbers.  

In our Innerworth chats with veteran traders we heard a lot of “I was killing it before Y2K, now I’m just killing time” stories.  The moral? A strategy that works when interest rates are flat, oil is cheap, and the Fed is sipping lattes may crumble the moment the macro‑environment flips.  **Rule #1:** Always be on the lookout for the *context* in which a method succeeds or fails.  

---

## Why the “Read‑One‑Book‑Become‑a‑Wunderkind” Myth Doesn’t Hold Up  

For a newcomer, the sea of advice can feel like a bad Tinder date—every profile claims to be “the one”.  In most professions you can go to a top‑ranked university, learn the textbook, get a certification, and start earning a steady paycheck.  Trading, however, is the rebellious teenager of careers: it refuses to let you graduate by simply memorizing a few formulas.  

Sure, you can devour classics like **_Market Wizards_** or **_Trading in the Zone_**.  Those books will hand you a toolbox of concepts—risk‑reward ratios, the importance of edge, the psychology of loss aversion, etc.  The catch is that those concepts are usually illustrated with a *specific* market backdrop: a bullish tech bubble, a low‑volatility commodities phase, or a high‑frequency, algorithm‑driven environment.  If you try to apply “buy the dip” from a 1999 tech rally to today’s crypto‑driven chaos, you’ll probably end up buying a dip that never resurfaces.  

**Bottom line:** You need a reference point, but that reference point will be *imperfect*—just like learning to ride a bike with training wheels that are a little too wobbly.

---

## “Learning Something Slightly Wrong Is Better Than Learning Nothing at All”  

Remember how you learned to read?  Your kindergarten teacher didn’t toss Shakespeare at you on day one.  She gave you “The Cat in the Hat” because the words were simple, the sentences short, and the rhymes memorable.  You stumbled over “s” and “c” a few times, but you eventually got the hang of it.  The same principle applies to trading.  

Most trading books contain a blend of **half‑truths and context‑specific nuggets**.  A case study on a 2008 market crash, for instance, will describe how “sell the rally” worked like a charm—*but only because the Federal Reserve was about to unleash QE*.  In a world where interest rates are now negative and central banks are playing musical chairs, that exact playbook might backfire spectacularly.  

That’s why it’s perfectly fine—*even advisable*—to start with a method that’s a little off the mark.  Take **Elliott Wave Theory**: many newbies fall in love with its promise of “predictable wave counts” and spend months drawing waves on price charts like a surfer mapping out swells.  The theory is elegant, but it’s also notoriously subjective; two seasoned analysts can look at the same chart and label the waves completely differently.  Still, by wrestling with those waves you learn to spot *patterns*, to respect *structure*, and, most importantly, to understand why **the market sometimes behaves like a toddler on a sugar rush**.  

---

## Assume Repetition Until Proven Otherwise  

Markets have a habit of behaving like that one uncle at family gatherings: **they repeat the same stories over and over—until they decide to go off‑script**.  In the early days of your trading journey, it’s pragmatic to **assume that markets do have cycles**, because that assumption gives you a working framework.  You can then test it, break it, and refine it as you gather experience.  

Think of it like learning to walk before you run.  Your first attempts at trading might involve **simple, rule‑based strategies**—maybe a moving‑average crossover or a basic breakout on a daily chart.  Those methods are easy to code, easy to back‑test, and, most importantly, easy to *understand* when they fail.  As you accumulate “trade‑journal calories,” you’ll start noticing under which market regimes those simple rules thrive (e.g., trending, low‑volatility environments) and where they sputter (e.g., choppy news‑driven sessions).  

Once you have that mental map, you can start **questioning the rules** you once obeyed blindly.  That’s when the fun (and danger) of breaking the “rules” begins.

---

## The “Do‑Not‑Break‑This‑Rule‑Or‑Your‑Portfolio‑Will‑Explode” List  

1. **Never risk more than X % of your capital on a single trade.**  
   *Why it exists:* Protects you from a single catastrophic loss wiping out your account.  
   *When traders break it:* Some veterans will go “all‑in” on a high‑conviction event (think “buy before the Fed’s rate‑cut announcement”).  If the market moves opposite, they can survive because they have a large enough bankroll and a diversified portfolio.  For most of us, however, that’s a fast‑track ticket to the “I‑should‑have‑listened‑to‑my‑mentor” club.  

2. **Stay out of the market during major, unpredictable macro events (e.g., surprise rate hikes, geopolitical shocks).**  
   *Why it exists:* Volatility spikes, slippage spikes, and your stop‑losses become meaningless.  
   *When traders break it:* Some seasoned pros love the “news‑trade” adrenaline rush.  They’ll set a tight entry before a scheduled announcement, hoping the market will swing in their direction and they’ll catch a quick profit.  If the news goes the other way, they may end up with a margin call faster than you can say “stop‑loss”.  

These examples illustrate a larger truth: **conventional wisdom in trading is situational**.  What works for a 10‑year‑veteran with a $5 million portfolio may be a reckless gamble for a newcomer with a $2,000 account.  

---

## The Bottom Line: Learn the Rules, Then Decide Which Ones to Break  

Trading isn’t a polite, buttoned‑up profession where you can dress up in a suit, follow a handbook, and expect a steady paycheck.  It’s a chaotic, ever‑shifting arena where **rules are more like guidelines that need a constant reality check**.  

- **Start with the basics** (risk management, position sizing, simple technical patterns).  
- **Treat every new method as a hypothesis**, not a gospel.  
- **Collect data**—your own trade journal is the most honest professor you’ll ever have.  
- **Identify the market regime** (trending vs. range‑bound, high‑volatility vs. low‑volatility) before you decide which rule to obey or toss out.  
- **When you finally feel comfortable breaking a rule**, do it deliberately, with a clear edge, and always have a contingency plan.  

In short, **master the rules first**, then, like a skilled chef who knows when to add a pinch of salt *and* when to skip it, decide when the market invites you to bend them.  The more experience you rack up, the better you’ll become at distinguishing the “rules that are truly universal” from the “rules that are just good advice for a particular time and place.”  

Happy trading, and may your stop‑losses be tight and your coffee strong! ☕📈