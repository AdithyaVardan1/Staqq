# 361. Giving Into the Markets  

**Source:** https://zerodha.com/varsity/chapter/giving-into-the-markets/

---

When there’s cold, hard cash hanging on a trade, our brain suddenly turns into a control‑freak. We want the market to behave like a well‑trained dog that obeys every command we bark. The craving for total domination is so intense that, the moment we feel we’re not in the driver’s seat, we start pulling a classic psychological trick called the **“illusion of control.”** In plain English: even when the outcome is as random as a lottery draw, we convince ourselves we’ve got the reins. The bigger the illusion, the easier it is to take a gamble—because we *think* we’re steering the ship, not just floating on a wave.

So we cling to the belief that we can wrangle every price movement. It’s a neat mental band‑aid for the uncomfortable sting of uncertainty, especially while we’re waiting to see whether our trading plan will sprout a profit or wilt like a wilted lettuce. But here’s the harsh reality that even the most seasoned pros whisper over a beer: **you can’t boss the market around.** No matter how many charts you study or how many “buy‑the‑dip” mantras you chant, the market will still do its own thing. You can’t force a price to obey your will; you can only decide how you’ll respond when it decides to dance.

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/06/20060414-300x300.png)

In his no‑nonsense manual *Trading to Win*, Dr. Ari Kyiv sums it up nicely:  

> “It’s important to distinguish between the tape and your interpretations of the tape. View as neutral both the events and your inclination to impose your interpretations on them. Enter the market without expectations, surrendering to it rather than struggling with it for personal gain.”

In other words, treat the price‑action tape like a TV news broadcast—watch it, but don’t start narrating a drama about it in your head. Staying objective isn’t just a nice‑to‑have; it’s the **gatekeeper to profitability**. Of course, we’re human, and humans love to win. When the market starts giving us the cold shoulder, we instinctively start stretching the truth, painting the loss in rosy colors (“It’s a learning experience,” we say) or magnifying a tiny win into a life‑changing breakthrough. Dr. Kyiv’s warning is simple: **find a way to keep your brain from turning every tick into a personal drama.**

## How to Keep Your Cool (and Your Wallet)  

### 1. Trade With Money You Can Afford to Lose  

Picture this: you put your entire retirement nest egg on a single trade. Suddenly, every price dip feels like a personal betrayal, every tick up is a fleeting high, and every news headline becomes a personal attack. The result? Anxiety that could make a yoga instructor twitch, self‑doubt that would make a philosopher weep, and frustration that could turn you into a grumpy cat.  

Now flip the script. Risk only a tiny slice of your capital—say, **1‑2 % of your total trading fund**—on any given trade. If the trade tanks, you’ll feel a brief sting, not an existential crisis. It’s the old trader’s mantra:  

> *“Risk so little on a trade that you can honestly ask yourself, ‘Why am I even bothering to put on this trade?’”*  

When the amount at stake is modest, the emotional stakes drop dramatically. You can sleep, you can smile, and you can keep your brain from turning every loss into the end of the world.

### 2. Kick Your Ego Out of the Equation  

If you’ve ever tried to control the market, you’ve probably also tried to control the weather—both are equally impossible and both leave you soggy and humbled. So why let your ego ride shotgun? Your ego loves a win and hates a loss, which makes it an unreliable co‑pilot.  

Sometimes you’ll stumble upon a brilliant strategy after months of tinkering; other times a lucky break (a serendipitous confluence of indicators) will give you a win. And often, the best ideas come from borrowing a proven approach from another trader—think of it as “copy‑and‑paste” for profitability.  

But at the end of the day, **trading is a probability game**. It’s as close to rolling a die or flipping a coin as you can get in the financial world. If you run enough trials, a sound edge will surface as a positive expectancy. Yet in the short run, even a winning system will hand you a string of losers—just like getting 50 heads in a row on a fair coin is *possible* (the probability is \( (0.5)^{50} \approx 8.9 \times 10^{-16}\), astronomically tiny, but not zero). Those streaks are the market’s way of reminding you that luck still plays a part.

### 3. Detach, Don’t Depersonalize  

Ask yourself: **why do we make every trade feel like a personal reputation test?** Why do we brag when luck smiles and sulk when it frowns? From a probability perspective, each trade is just one data point in a massive dataset. It’s not a reflection of your self‑worth; it’s a single flip of a coin in a sea of flips.  

When you see the market through this statistical lens, the emotional charge evaporates. You stop treating a loss as a personal failure and a win as a heroic feat. You become a *observer* rather than a *combatant*. The only things you can actually control are **your risk management** (position size, stop‑loss levels, etc.) and **your strategy’s logic** (entry criteria, exit rules). Everything else—price direction, timing, macro news—belongs to the market’s wild side.

## The Payoff: Calm, Focus, and Peak Performance  

Ironically, the moment you accept what you can’t control (the outcome of each trade) **and** double‑down on what you can (sound risk management and a well‑tested strategy), you’ll notice two things:

1. **Your heart rate steadies.** No more sleepless nights obsessing over a single candle.  
2. **Your mind sharpens.** You can focus on the next setup instead of replaying the last loss on a mental loop.

That calm, laser‑focused mindset is the secret sauce of top‑tier traders. It’s the same state athletes call “flow” and investors call “rational optimism.” When you’re not busy defending your ego, you can actually *play* the market—spotting edges, adapting to new information, and letting the odds do the heavy lifting.

So, next time you feel the urge to grab the market by the throat, remember: the market is a wild horse, not a pet. You can’t force it to sit; you can only decide how to ride it—preferably with a small, well‑secured saddle (risk) and a calm, confident grin. Cheers to giving the market its space and giving yourself the peace of mind to trade like a pro! 🍻