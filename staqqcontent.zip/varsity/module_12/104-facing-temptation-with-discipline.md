# 104. Facing Temptation With Discipline  

**Source:** <https://zerodha.com/varsity/chapter/facing-temptation-with-discipline/>

---

### The Slot‑Machine Effect

Staring at your trading screen is a lot like walking past a neon‑lit slot machine in a casino. You hear that little “ding‑ding‑ding” in your head and suddenly you’re wondering, “What if I just drop a buck in and pull the lever? What if today’s the day I hit the jackpot?”  
In reality, the “jackpot” is often just a *quick* dopamine hit that leaves your account a little lighter and your ego a little heavier. The battle you’re fighting isn’t against the market; it’s against that human urge to chase instant excitement and a fast reward.  

So, **yes**, you need to keep your hand off the virtual lever and let discipline do the heavy lifting.  

---

### Click‑Happy Platforms = Click‑Happy Trouble

When electronic trading platforms first arrived, they were like the invention of the microwave: a *godsend* for busy people. You could fire off a trade in the time it takes to brew a cup of coffee. Unfortunately, that same speed also turned many rookies into *click‑happies* who fire off orders faster than a teenager swipes right on a dating app.  

Even seasoned traders aren’t immune. The temptation to stare at the screen 24/7, second‑guess every pip, and abandon a carefully‑crafted plan after a single candle is a classic case of “analysis paralysis meets impulse overload.” The antidote? Patience—yes, that same patience you promise yourself while waiting for pizza delivery. Stick to your plan long enough for it to actually work.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/02/20070530-300x300.png)

---

### Boredom: The Silent Partner in Impulsive Trading

Impulse doesn’t appear out of thin air. One of the biggest culprits is **boredom**. When the market is moving slower than a turtle on a lazy Sunday, you start feeling a little *blah*. Your brain whispers, “Hey, why not spice things up? Let’s peek at that trade and see if it’s finally doing something cool.”  

The problem is that every glance fuels the urge to act. If your strategy says “hold for a week (or longer),” each peek is like poking a beehive—you’ll either get stung or become obsessed with the buzzing. The cure? Remove the temptation altogether.  

---

### No, You’re Not a Super‑Human (Sorry, Batman)

Let’s be honest: most traders think they have the self‑discipline of a monk on a mountaintop. Remember that “Got Milk?” ad where a kid is staring at a frosted cupcake and can’t stop thinking about the milk? That’s you when a chart starts flashing green. You could *try* to resist, but it’s about as easy as not eating the cupcake while it’s right in front of you.  

Instead of putting yourself in that sugary showdown, **avoid the cupcake**—or in trading terms, avoid looking at the market unless your plan explicitly says you should. If you don’t need to be glued to the screen, don’t be.  

---

### How to Build a Discipline Muscle (Without Getting a Gym Membership)

1. **Admit Your Limits** – Self‑control is a muscle, not a superpower. If the farthest you’ve run in the past year is from the couch to the fridge, don’t expect to marathon a 26.2‑mile trade plan tomorrow. Start with tiny reps: resist the urge to check the chart every 5 minutes, then every 15, and so on.  

2. **Make a Commitment Worth Keeping** – Think of discipline like a diet or quitting smoking. You can’t lose weight by “maybe” cutting carbs; you have to *declare* you’re doing it. Write down your discipline goals, set reminders, maybe even put a sticky note on your monitor that says, “You’re not a hamster on a wheel.”  

3. **Use Psychological Hacks** – Your inner monologue is the real puppet master. When you hear, “I need a little excitement—let’s see how my position is doing,” counter it with a calming mantra: “I’m a patient investor. I can wait.” It’s like telling your brain, “Hey, we’re on a Netflix binge, not a reality‑TV drama.”  

4. **Run (Away) From the Screen** – The moment the impulse to click arises, physically step away. In the pre‑internet era, you had to **call a broker** to place a trade—an in‑built cooling‑off period that forced you to actually think, “Do I really want to look like a jittery day‑trader in front of the guy on the other end?” Today you can click “Buy” faster than you can say “margin call,” so recreate that buffer: set a rule that you must wait 5 minutes after an impulse before you can act.  

5. **Enlist a Human Gatekeeper** – If you really struggle, let a broker (or a trusted friend) be your gatekeeper. When you have to pick up the phone, you’ll think twice: “Do I want to sound like a nervous wreck to my broker?” It’s a subtle but powerful social check.  

---

### The Quick‑Exit Playbook

If you *do* catch yourself glancing at the chart, don’t linger like a cat on a windowsill. Slip out of the room, grab a coffee, do a few push‑ups, or stare at a picture of a calm beach. Anything that breaks the visual feedback loop. The goal is to let the emotional surge subside before you make a move you’ll later regret.  

---

### Bottom Line: Discipline Wins the Day (and the Wallet)

The most successful traders aren’t the ones who can predict every market swing; they’re the ones who can **stay calm, stay rational, and stay in control** when the market tries to tempt them with fireworks. Treat discipline like a good pair of shoes—wear them every day, and you won’t be caught flat‑footed when a sudden impulse tries to sprint you into a loss.  

Remember: the market will always have its shiny, click‑bait moments. Your job is to be the sober friend who says, “Nah, I’ll stick to the plan.” The more you master that, the more profit you’ll bring home—plus, you’ll finally stop feeling like you’re living in an episode of *The Bachelor* where every rose is a new trade. 🍷📈  