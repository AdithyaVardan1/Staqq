# 125. When Intuition Fails  

**Source:** https://zerodha.com/varsity/chapter/when-intuition-fails/  

---  

Trading can feel like being on a roller‑coaster that’s also a treadmill—fast, noisy, and you never know if the next dip is a loop or a pothole. The “sharp‑eyed” trader prides himself on snapping decisions in a heartbeat, relying on gut feelings that have been honed over years of watching candle charts, news flashes, and the occasional meme stock. Those veterans have a massive mental library of market anecdotes, so they can scan a flood of data and spit out a verdict faster than a barista pulling espresso shots.  

But here’s the kicker: trusting your intuition isn’t always the smartest move, especially if you’re still learning the ropes. When you’re a rookie, you haven’t yet built that massive archive of market memories, so leaning on cold, hard facts beats guessing based on a vague “I’ve got a feeling.” In other words, keep the crystal ball in the attic until you’ve earned a PhD in price action.

**Enter Dr. Tom Gilovich**, a psychology professor at Cornell who spends his days figuring out why we humans love to see patterns where none exist (think “the universe is a giant conspiracy” vibes). He says intuition is a handy sidekick most of the time, but it can also be a mischievous gremlin. Our brains are wired to hunt for connections—so much so that we sometimes spot a “relationship” between two events even when the data says otherwise. Gilovich splits our mental machinery into two systems:

* **System 1** – the snap‑judgment, “I‑know‑it‑when‑I‑see‑it” part of the brain. It’s fast, emotional, and built for survival. Imagine walking down a sketchy alley; your System 1 instantly flags a shady figure, prompting you to duck into a shop or sprint away. In trading, that’s the part that shouts “SELL!” the moment a sudden dip appears on the screen.  
* **System 2** – the slow‑poke, logical analyst that likes to chew on every piece of information before reaching a conclusion. It’s the part that would sit down with a spreadsheet, a cup of coffee, and a calculator before deciding whether that dip is a buying opportunity or just a market sneeze.

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/02/20070321-300x300.png)

System 1 is a double‑edged sword. Its speed is a blessing when the world (or market) is behaving as we expect. But drama loves to hijack attention. Picture this: you’re sipping your morning chai, the market suddenly erupts in a sell‑off, and your heart does a little jump‑rope routine. System 1 screams “Panic! Sell everything!” If your trading plan says “wait for the bigger move,” you’ve just tripped over your own reflex. In other scenarios, that same reflex could save you from a genuine crash, but more often it leads you to abandon a well‑crafted strategy for the sake of a fleeting emotion.

Research shows we’re also prone to *seeing* correlations that simply aren’t there. It’s called “illusory correlation”—the mental habit of cherry‑picking data that supports a story while ignoring the mountain of evidence that contradicts it. So a trader might convince themselves that a particular news headline “must” cause the price to jump, even when historical data says the ticker is indifferent to that headline.

Mood matters, too. **Dr. Nalini Ambady** of Tufts University ran an experiment where participants made intuitive choices while in either a good‑vibes or a down‑in‑the‑dumps mood. The happy crowd made *more* accurate gut calls. When you’re feeling glum, confidence in your hunches wanes, and you either over‑think or, worse, act on a misguided intuition.

All this sounds like a sobering lecture on why our brains are terrible, right? Not quite. The studies simply tell us that intuition is *conditional*—it shines when you’ve earned it, and it sputters when you haven’t.  

### So, should you banish intuition altogether?

* **If you’re a novice:** Treat your hunches like that mysterious “new‑friend” on a dating app—interesting, but you shouldn’t move in together just yet. You lack the experience to differentiate a genuine signal from a market mirage. Stick to concrete analysis: look at price action, volume, fundamentals, and your own trading plan.  

* **If you’re a seasoned pro:** Your brain has been through enough market storms to develop a reliable System 1. You can glance at a chart, read a headline, and the “feel” of the market tells you whether the move is a blip or a trend. Think of it like driving a car. When you’re learning, you’re constantly checking mirrors, speed, the GPS, and the radio. After a few thousand miles, you can glide through traffic while simultaneously humming a tune and planning your next coffee stop. The same applies to trading—experience lets you synthesize multiple inputs without needing to consciously dissect each one.

The path from rookie to veteran is essentially a *muscle‑building* routine for your brain. The more trades you take (preferably with disciplined risk management), the more data points you collect, and the sharper your intuition becomes. It’s not magic; it’s statistical learning, packaged as a gut feeling.

### Bottom line

Intuition isn’t the enemy; it’s a tool that can be either a scalpel or a sledgehammer. The danger lies in **impulsively trusting unfounded hunches** when you haven’t yet built the mental scaffolding to support them. Conversely, once you’ve logged enough wins (and, crucially, losses) to understand why the market behaves the way it does, you can let System 1 do the heavy lifting—*as long as* System 2 is still on standby to double‑check when the stakes are high or the situation feels “off.”

Until you reach that sweet spot, treat every trade like you’d treat a first‑date conversation: listen carefully, ask questions, and don’t rely on a single glance to decide whether you’ll stick around. Over time, you’ll graduate from “I think I feel something” to “I *know* the market is doing X,” and that’s when intuition stops being a gamble and becomes a genuine competitive edge. Happy trading, and may your gut be as seasoned as your coffee!