# 263. The Drawdown Mentality  

**Source:** https://zerodha.com/varsity/chapter/the-drawdown-mentality/  

---  

It’s a lot harder to climb out of a hole when you’re already **down**.  When you’re winning, trading feels like a breezy Sunday brunch—you’re not sweating the bill, you can experiment with a splash of spice, and the whole thing feels *fun*.  No one’s breathing down your neck demanding you “make up” yesterday’s mis‑steps.  Your brain is relaxed, your creativity is humming, and you can afford to take a calculated gamble without it feeling like a life‑or‑death decision.  

Flip the script and you’ve got a whole month (or more) of **break‑even‑or‑worse** slogging.  Suddenly the emotional roller‑coaster decides to bring its whole family: anxiety, frustration, self‑doubt, and that nagging voice that keeps whispering, “Did I just lose my lunch money again?”  Those feelings can push you into doing things you’d normally swear off—like chasing a trade that looks *just* a little too good, or, worse, **doing nothing at all**.  The road back to profitability isn’t a sprint; it’s a disciplined marathon where you keep your emotions on a leash, control risk like a hawk, and place trades one‑by‑one, methodically, until the balance sheet finally says “hello, I’m back.”  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/05/20060214-300x300.png)  

## How Different Traders React to a Brutal Losing Streak  

Seasoned pros often treat a string of losses like a rainy day—grab a cup of coffee, keep typing, and wait for the sun to pop out.  They understand that the market is a fickle beast and that persistence usually beats panic.  

Other folks, however, take the drawdown personally, as if the market just slapped them in the face.  They start asking, “What did I do wrong? Am I a failure?”  Pessimism sneaks in, denial follows, and before you know it they’re Googling “How to disappear from the market forever.”  This retreat‑into‑the‑blanket‑of‑avoidance may feel comfy, but it also **drains the psychological fuel** you need to fight back.  Creativity fizzles, confidence evaporates, and the whole recovery plan collapses under the weight of self‑criticism.  

The antidote? Keep a **winning attitude**—the same one you’d wear to a karaoke night, even if you can’t hit the high notes.  Trust that your skill set is still there, and convince yourself that with a heroic, steady effort you can climb out of the hole.  (Spoiler: you don’t need a cape, just a good risk‑management plan.)  

## The Revenge‑Seeker’s Trap  

Some traders flip the script again and adopt a **revenge mentality**, as if the market were a rival boxer they have to KO.  At first, the idea of “getting even” feels empowering—like a superhero discovering a new power.  The danger? It inflates your sense of control, making you believe you’re the puppet master pulling the strings of every price move.  

Fear is the hidden engine of this revenge drive.  Accepting a big loss is tough; the brain tries to compensate by fantasizing, “If I pull off ten massive wins next week, I’ll be back on top!”  Soon you’re **risk‑overloading** your account, chasing unicorn trades, and ignoring the very risk parameters that kept you alive in the first place.  In the short term you might feel a rush, but the long‑run payoff is usually a deeper, messier drawdown—think of it as trying to put out a fire with gasoline.  

## The Only Safe Path Out of a Drawdown  

The sensible, boring, but ultimately victorious route is simple: **manage risk like a tight‑rope walker** and use the most reliable, battle‑tested methods to recoup losses.  Emotionally, this feels like walking on a tightrope over a canyon while juggling flaming torches—hard, but doable if you keep your cool.  

You can’t stay perpetually *down* (that’d be a depressive spiral), but you also can’t swing to an irrational optimism that says, “I’ll double my account tomorrow!”  The sweet spot is a **calm, determined, rational mindset**.  Stick to your edge, keep position sizes modest, and let the compounding effect do its quiet magic.  Over time, those small, disciplined wins will add up, the balance sheet will tip back to the positive side, and you’ll emerge wiser, tougher, and with a fresh set of stories to brag about at the next trader‑meet‑up.  