# 213. Contagious Moods: Don’t Catch a Bad Mood  

**Source:** <https://zerodha.com/varsity/chapter/contagious-moods-dont-catch-a-bad-mood/>

---  

Traders who can think for themselves are the ones who usually end up with the fattest profit sheets.  Of course, marching solo in a market that’s basically a giant digital zoo is easier said than done.  Our brain is a bit of a couch‑potato: it loves a warm blanket of “someone else already did it” before it dares to jump off a cliff (or into a trade) by itself.  This double‑whammy—our natural aversion to risk **and** our craving for crowd‑approved validation—leaves us wide‑open to what psychologists call *emotional contagion* and *thought contagion*.  In plain English: moods and ideas spread faster than a viral cat video, and if you’re not careful you’ll end up catching a bad one.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/04/20060828-300x300.png)

## The “Follow‑the‑Crowd” Loop (and Why It’s a Bad Party Trick)

Picture this: an analyst on a live‑stream starts waxing poetic about a hot‑tech stock, calling it the next **Apple** of the century.  A few traders, smelling free‑range profit, hop on the bandwagon and buy.  Suddenly, there’s a mini‑queue of green candles, and a few more traders say, “Hey, look at those buying hands—let’s join them!”  The cycle repeats, each new purchase nudging the price a little higher, and the crowd gets bigger.  

If you happen to be the **first** to spot the spark, you can ride the wave as the herd pushes the price upward.  But most of us are the “late‑arriving” folks who only notice the party after the music’s already blasting.  We jump in **right before the reversal**, because that’s when the crowd feels most “validated.”  Then, when the party starts to fizzle and everyone panics, we end up selling at the bottom—right alongside the rest of the herd, clutching our losses like a soggy umbrella in a downpour.  

In everyday life, blending in is a survival skill.  The socially savvy can read the room, nod at the right moments, and generally avoid becoming the weird uncle at the wedding.  But the stock market isn’t a wedding; it’s a high‑speed dance floor where the music changes every 30 seconds.  The very instinct that keeps you from stepping on someone’s toe can also keep you from stepping onto the *right* trade.  

## Be the Rebel With a Cause (or at Least a Slightly Unruly Stomach)

The champion trader does something almost heretical: they **step back** from the crowd, stare at the chart like a detective eyeing a crime scene, and try to pinpoint the sweet spot where the price is about to flip.  In practice, that usually means **buying right after a reversal** (when the market has already started to turn) and **selling at the very beginning of an up‑trend** (before the crowd catches on).  In short, you become the party pooper who leaves the room **just before** everyone else decides the party’s over—except you’re doing it because you’ve spotted the exit sign.  

That sounds easy until you remember that humans are *hard‑wired* to follow the majority.  So you need a two‑step defense plan:  

1. **Know the crowd’s pull.**  Recognise that the herd has a magnetic force field.  When you’re aware of that, you can deliberately **push against it**—like a bouncer who says “No entry” when the line gets too long.  
2. **Know yourself.**  Are you a glass‑half‑full optimist who gets giddy when the market cheers, or a doom‑sayer who sees red everywhere?  Your personality will amplify the crowd’s mood.  An over‑optimist may get swept up in a buying frenzy, while a chronic pessimist might dump positions the moment a few traders start selling.  

If you have a tendency toward **irrational exuberance**—the kind of optimism that makes you shout “Buy the dip!” every time the price dips a teeny‑weeny 2%—you’ll probably end up buying **with** the crowd instead of **against** it.  Without a reality‑check, you’ll match the crowd’s emotions, not your own analysis.  The antidote is simple but requires discipline: **anticipate** the crowd’s thoughts, then **trade the opposite**.  That usually translates to **selling when everyone else is buying**, waiting for the turning point, and then **buying when the masses are fleeing**.  

## How to Stop Catching the Crowd’s Bad Mood

Think of the market like a party where everyone’s mood is contagious—if you’re not careful, you’ll catch the same flu that makes the DJ play “Baby Shark” on repeat.  Instead of letting yourself be a passive carrier, become the *immune system* of your own portfolio:  

- **Stay vigilant** about the herd’s influence.  Write it down, set a reminder, or even put a sticky note on your monitor that says, “Don’t be a lemming!”  
- **Do a personality audit** every quarter.  Ask yourself: *Do I tend to get overly excited when the market’s up? Do I panic and sell at the first sign of a dip?*  Knowing the answer lets you pre‑empt the mood swing.  
- **Create a rule‑based checklist** that forces you to check the price action, volume, and a few technical signals *before* you let the crowd’s cheer guide you.  When the checklist says “No,” treat it like a bouncer at a nightclub—no entry.  

By turning the volume down on the crowd’s emotional broadcast, you give yourself room to hear the quieter, more reliable signal: **your own analysis**.  The more you practice independent thinking, the more you become “vaccinated” against the market’s emotional viruses.  In the end, you’ll find yourself making money **because** you’re not a slave to the herd’s whims, but a savvy trader who knows exactly when to dance with the crowd and when to slip out the back door with a tidy profit.  

So, next time you feel the urge to jump on the latest hype train, remember: **don’t catch a bad mood—catch a good trade**. 🍻