# 147. Dare To Be Average  

**Source:** https://zerodha.com/varsity/chapter/dare-to-be-average/

---  

When you actually **put your cash on the line**, the inner perfectionist in most rookie traders goes into full‑blown “Nobel‑prize” mode. They act like there’s a secret cheat‑code hidden somewhere that will tell them the *exact* entry, the *perfect* stop‑loss, and the *flawless* exit for every single ticker. In Mark Douglas’ classic **“Trading in the Zone,”** he points out a sad truth: traders who are so busy polishing their dream‑trade that they never **actually press the button** end up with a portfolio that looks more like a museum exhibit than a profit‑making machine.  

It’s a bitter pill for the hyper‑analytical trader to swallow, but **trading isn’t a profession where you can keep demanding perfection**. There is no such thing as a guaranteed profit. Data can be stale, news can be mis‑quoted, and even the most meticulously crafted trade plan can be knocked flat by an unexpected “black‑swan” event (think “Brexit‑shocks‑the‑market” or “Tesla‑suddenly‑stops‑making‑cars”).  

Want to be a sloppy, impulse‑driven trader? No, thank you. You also don’t want to be the **extreme perfectionist** who freezes at the sight of a candle wick. There’s a sweet spot somewhere between “I’m a reckless gambler” and “I’m a control‑freak spreadsheet wizard.”  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/03/20061020-300x300.png)  

> “The harder you strive for perfectionism, the worse your disappointment will become,” — Dr. David Burns (1980)  

Perfectionism sounds noble until you realize it’s basically **a high‑maintenance relationship** that never gives you a good night’s sleep. When you set your standards so high that you’re constantly on edge, you become about as productive as a cat that’s been told to guard a laser pointer. You start **avoiding risk** because the thought of a loss feels like a personal insult. You’ll sit on the sidelines, watching the market dance, while the “average‑Joe‑trader” scoops up the cheap, tasty crumbs.  

Trading is a **risk‑taking, opportunity‑exploring** game. If you keep polishing your perfect‑trade statue, you’ll never actually **play** the game. You’ll keep muttering, “I could have done better,” while the market keeps moving on without you.  

---

## Is your perfectionism out of hand?  

Dr. Burns (the same guy who warned us about perfectionism turning us into human pressure cookers) gave us a neat little experiment: **“Dare to be average.”**  

1. **Feel the average.**  
   - Close your eyes and imagine you’re just another trader who lands a *reasonable* setup—nothing spectacular, just “good enough to be profitable.”  

2. **Compare the vibes.**  
   - **High standards** → heart racing, palms sweating, you’re basically auditioning for a reality‑show “Trader Survivor.”  
   - **Moderate standards** → you’re relaxed, maybe sipping a coffee, and you can actually think about the trade instead of your own breathing.  
   - **Low standards** → you’re basically gambling on a coin toss, which is fun until you lose the house money.  

Most people discover that **moderate standards feel… well, better**.  

---

## What happens when you *actually* make an average trade?  

Sure, you won’t be buying a private island with the profit from a single trade, but you’ll **feel a lot less like a nervous wreck**. And that feeling matters. Here’s why:  

- **More trades, more chances.**  
  The law of averages isn’t a mystical fairy; it’s basic probability. The more *reasonable* trades you take, the more the **expected value** of your edge can manifest. Think of it like flipping a fair coin—one heads in a row feels lucky, but ten flips give you a clearer picture of the coin’s bias.  

- **Risk stays in check.**  
  If you stick to a **sound risk‑management rule** (say, 1‑2 % of your capital per trade), you can survive the inevitable losers and let the winners do the heavy lifting.  

- **Winning trades get the spotlight.**  
  When you’re not obsessing over the “perfect” entry, you can focus on what *actually* works: the strategy that has been back‑tested, the market condition you understand, and the discipline to cut losses early.  

On the other hand, an **extreme perfectionist** spends half their day Googling “how to predict a market crash with 100 % certainty” and the other half **paralyzed**, missing the very setups that would have been “good enough.” They also miss out on *new* opportunities because they’re too busy polishing the same old playbook.  

---

## The upside of easing up  

Relaxation isn’t just a spa‑day perk; it’s a **cognitive enhancer**. When your brain isn’t busy screaming “Don’t mess up!” it can start to **think creatively**—spotting patterns, adjusting positions on the fly, and even enjoying the market’s quirks (yes, that’s a thing).  

Ironically, by daring to be **average**, you might end up **more profitable** than the obsessive perfectionist who never actually trades.  

So here’s the challenge:  

- **Take a deliberately average setup** (maybe a 2:1 risk‑reward ratio instead of the lofty 4:1 you’ve been dreaming about).  
- **Execute it** with the same discipline you’d apply to a “perfect” trade.  
- **Observe** how you feel, how many trades you take, and how your equity curve behaves over a few weeks.  

You might be surprised to find that the market **doesn’t care** whether you call yourself a “perfectionist” or a “average‑joe.” It only cares about **your risk, your edge, and your consistency**.  

**Bottom line:** Stop polishing the crystal ball and start **throwing darts** at the board—just aim for the *bullseye’s general area* rather than the exact millimeter. You’ll be calmer, you’ll trade more, and—most importantly—you’ll stop that nagging voice that says, “I could have done better.”  

Dare to be average. The market will thank you (or at least, your bankroll will).  