# 178. Staying Calm Under Pressure  

**Source:** https://zerodha.com/varsity/chapter/staying-calm-under-pressure/

---

Trading days can feel like you’ve been tossed into a mosh pit while trying to read a novel. One moment you’re in a sour mood, the next the market decides to play “Simon Says” with your trading plan. It’s perfectly human to feel your brain short‑circuit under that pressure. The difference between a trader who ends the day with a grin and one who ends up Googling “how to melt stress away” is that the successful folks treat each trade like a casual stroll in the park—relaxed, focused, and **not** sweating the small stuff.  

They don’t act like the universe owes them a win on every single ticket. Instead, they keep their eyes on the long‑run picture, accept that being “right” isn’t a prerequisite for profit, and stop trying to muscle the market into a shape it refuses to take. Predicting the future? That’s a hobby for fortune‑tellers, not traders. The winning approach is: **observe the market objectively, sketch out a battle‑plan, then let the market decide whether you get to ride the wave or bail out early.**  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/03/20070105-300x300.png)

When they’re in this sweet spot, they’re said to be “in the zone,” a phrase borrowed from performance‑psychology legends Mark Douglas and Ari Kiev. Think of it as the mental equivalent of being so relaxed you could nap on a roller‑coaster and still know when to pull the emergency brake. Seasoned traders stop second‑guessing themselves, glide in and out of positions like a well‑timed punchline, and, because they’re not choking on anxiety, they can spot and pounce on opportunities that would make a rookie’s head spin. Bottom line: mastering your emotions isn’t just feel‑good fluff—it’s the secret sauce behind lasting financial success.

Even the most seasoned pros admit they’re not emotion‑immune. Take **Russ** from the Innerworth Master Interview. He confessed, “It’s been a rocky road, to be honest. It’s a constant struggle. I’d say I’m pretty good at it, but I’d be lying if I said I never have moments when I get upset.” In other words, the market can still make him want to scream at his screen like a sitcom character after a bad coffee.

Russ points out the scenarios that push his buttons the hardest. **Slippage** tops the list: “Imagine I set an exit at 49, but the market only lets me out at 48. That one‑point difference on a full lot feels like a tiny knife to the ego, especially after a day that’s already been a series of bad jokes.” Then there’s the dreaded **gap**: “You hold a position overnight, wake up, and thanks to some overnight news, your position is worth half of what it was.” It’s the trading equivalent of waking up to find your favorite pizza place has shut down—heart‑sinking, but also an opportunity to learn not to leave your pizza (or position) unattended.

So how does Russ keep his cool? He does a quick **mirror check**. “When I’m in a tough spot, I stop trading until I can look at myself in the mirror and actually smile. If I can’t manage that, I sit out until I can.” It’s a simple but brutally honest self‑audit: if you can’t even grin at your reflection, you’re probably about to make a trade that’s more about ego than edge. Stress and emotions can turn a solid strategy into a roller‑coaster of bad calls, so stepping back until you feel “okay-ish” is not cowardice—it’s tactical patience.

Trading “in the zone” demands laser‑like concentration, but that concentration evaporates when you’re riding an emotional roller coaster. Staying cool and in control isn’t just a nice‑to‑have; it’s the **profit‑protecting, loss‑limiting, sanity‑saving** part of the job. The calmer you are, the better you can let the market do its thing, and the more cash you can bring home—plus the fewer nights you’ll spend muttering curses at your computer screen.  

In short: **treat each trade like a casual chat at the bar, not a high‑stakes poker game.** Keep the jokes flowing, the emotions in check, and you’ll find yourself not just surviving the market’s chaos, but actually *enjoying* the ride. Cheers to staying chill and cashing in!