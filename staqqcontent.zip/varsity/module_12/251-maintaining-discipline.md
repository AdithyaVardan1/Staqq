# 251. Maintaining Discipline  

**Source:** https://zerodha.com/varsity/chapter/maintaining-discipline/  

---  

The winning trader is a disciplined trader. Discipline means **controlling impulses and controlling emotions**—think of it as the mental equivalent of not eating the whole pizza before the party starts. As every rookie trader will tell you (usually after a night of “just one more trade”), keeping that self‑control intact is a lot easier to preach than to practice. The market is a massive, noisy cocktail party where fear and greed are the DJs spinning the same two tracks on repeat. If you’re not careful, you’ll end up dancing to the “panic” beat or the “I‑just‑lost‑my‑shirt‑money” waltz.  

Trading isn’t a get‑rich‑quick scheme where you open a brokerage account, click “Buy,” and watch the cash flow in like a waterfall. It’s more like learning to ride a bull: you need **practice, hard work, and a stubborn determination to stay on** when the beast bucks. Discipline is the saddle, and you’ve got to tighten the straps before you hop on.

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/04/20060601-300x300.png)  

## Chaos Meets the Checklist  

The markets are chaotic and unpredictable—like trying to forecast the next meme that will go viral. When you’re staring at a screen of flashing numbers and a chart that looks like a toddler’s doodle, it’s natural to feel **unsure and unsettled**. After you hit “Enter,” the next few seconds feel like waiting for a pizza delivery in the middle of a thunderstorm: you never know if it’ll arrive hot, cold, or not at all.  

Some traders thrive on that adrenaline rush, treating each trade like a roller‑coaster selfie. Others, however, get the queasy‑in‑the‑stomach feeling. The antidote? **Organise your perception and actions** the way a good barista organizes espresso shots—precision and repeatability.  

If you trade with a **detailed trading plan**, you’re basically putting a fence around the wild jungle of price action. A plan gives you:

| Element | Why It Helps |
|--------|--------------|
| **Target profit objective** | Gives you a finish line so you don’t keep running forever. |
| **Entry strategy** | Tells you exactly when to jump in, instead of “maybe later.” |
| **Exit strategy** | Saves you from the “I‑can’t‑let‑go‑of‑this‑trade” syndrome. |

The more structure you embed, the less the market feels like a mystery novel written in a foreign language. You’ll know **what to do and when to do it**—like a Netflix series with a predictable episode order. When each piece is defined, sticking to the plan becomes as easy as following a recipe for instant noodles (but far more profitable).

## Mood Swings: The Real‑World Volatility  

Your **mood and attitude** are hidden variables that can make or break a trade, just like a hidden fee can wreck your holiday budget. An **optimistic yet realistic** outlook is the sweet spot—think of it as the “just‑right” porridge from Goldilocks. Too much optimism and you’ll ignore red flags; too much realism and you’ll become a wet blanket.  

Successful trading demands an **intuitive feel** for the market, but that intuition must stay as objective as a judge on a talent show—no personal bias, no drama. Unfortunately, the market’s roller‑coaster nature often throws us into frustration or disappointment faster than a bad Wi‑Fi connection drops a Zoom call.

Many traders wrestle with maintaining a **neutral or positive mood**. It’s a skill that needs daily practice, much like brushing your teeth (except you can skip the floss sometimes). If you let your guard down, a **pessimistic mood** can swoop in like a stray cat stealing your fish. The first line of defence? **Monitor your self‑talk**. Replace “I’m terrible at this” with “I’m learning the art of the trade.”  

But here’s the kicker: **psychological energy isn’t infinite**. Think of it as your phone’s battery—once it’s at 5 %, every extra app (or negative thought) drains it faster. When the mind’s limits are hit, staying upbeat feels like trying to run a marathon in flip‑flops.

## Recharge, Don’t Run on Empty  

The best cure is to **stockpile psychological energy** before you even step onto the trading floor. The most efficient way? **Plenty of rest and relaxation**. A tired trader is like a drunk driver—more likely to crash into a negative mood and make impulsive decisions. Sleep deprivation shrinks your emotional bandwidth, turning a calm “hold” into a frantic “sell‑everything!”  

So, treat sleep like a non‑negotiable part of your trading strategy. Aim for 7‑9 hours of quality shut‑eye, schedule regular breaks, and indulge in hobbies that refill your mental tank (reading, walking the dog, or perfecting your karaoke rendition of “Don’t Stop Believin’”).

## Bottom Line (with a Side of Humor)  

Maintaining discipline is **vital for trading success**, but it’s also the part that feels like trying to keep a toddler from eating crayons. The most reliable ways to stay on the straight‑and‑narrow are:

1. **Trade with a detailed, written plan** – your roadmap through market mayhem.  
2. **Guard your psychological energy** – get enough sleep, relax, and keep the mental batteries charged.  

When you combine a solid plan with a well‑rested brain, you give yourself the best shot at **profitable, consistent trading**—and maybe even enough free time to finally learn how to make a proper cup of coffee. Cheers to disciplined profits!