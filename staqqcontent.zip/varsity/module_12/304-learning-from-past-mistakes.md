# 304. Learning From Past Mistakes  

**Source:** https://zerodha.com/varsity/chapter/learning-from-past-mistakes-2/

---

Losses and setbacks are a fact of life. It is necessary to experience setbacks and recover from them in order to achieve success. The trader who has never experienced a severe drawdown, or blown out his or her trading account, has never learned to realize the worst‑case scenario and recover from it. Setbacks, even severe ones, can be important learning experiences and opportunities for growth. It is vital to extract a lesson from past mistakes and learn to turn a negative event into a positive event. That said, it is important not to become paralyzed by setbacks. Rather than mull over past defeats, or trading losses, winning traders use the setback as a motivator, an opportunity to hone their skills and improve. They examine what they did wrong, learn from their mistakes, and view the temporary setback as a new and refreshing starting point from which to achieve higher levels of future performance.

---

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/05/20050204-294x300.png)

### When the market slaps you, don’t stay on the floor

Winning traders don’t get **bogged down** with self‑doubt, regret, and defeat. Instead, they treat the “loss” like a spicy salsa—burning at first, but it wakes you up and makes you dance. They pull their magnifying glass out, stare at every losing trade like it’s a crime scene, and hunt down the sneaky culprits: over‑confidence, fatigue, or that impulse you felt after your third espresso.  

They aren’t scared of a brutally honest selfie‑check; they **welcome** it. After the forensic analysis, they’re itching for fresh opportunities to sharpen their edge, because they know the next trade is just another chance to prove they’ve learned the lesson. In short, a loss is their personal trainer—hard, relentless, but ultimately making them stronger.

### Keep a “trade‑diary” that would make Sherlock jealous

As traders, it’s crucial to keep **accurate records** of every factor that could have nudged the outcome of a trade. Think of it as a backstage pass to your own trading drama. From a psychological viewpoint, jot down whether you were in a bad mood (maybe you just lost a game of Mario Kart), or if you were acting on impulse instead of the calm, Zen‑like state you brag about on Instagram.  

Other variables to capture:  

- **Market conditions** – was the market choppy like a bad hair day or smooth like a freshly waxed surfboard?  
- **Trading strategy** – did you follow your plan, or did you improvise like a jazz solo?  
- **Preparation** – did you back‑test the setup, or did you wing it after a horoscope reading?  
- **Risk management** – how much of your capital did you risk? Did you set a stop‑loss, or did you hope the market would be nice?

Armed with this data, you can line up a series of losing trades like a photo album and spot the common villains. Maybe you notice that 70 % of your losses happened when you traded after a 2‑hour Netflix binge, or that every time you ignored your stop‑loss you lost an average of 1.5 % of your account. Identify those patterns, flip the switch, and watch the improvement roll in. The secret sauce is a **upbeat psychological approach**—treat each failure as a “level‑up” rather than a game‑over screen.

### Turn a loss into a launchpad, not a landfill

Viewing a loss as a growth experience changes your perspective **instantaneously**—like swapping a pair of cheap sunglasses for prescription lenses. Suddenly you’re not obsessing over that one $200 slip‑up; you’re focused on the bigger mission: becoming a seasoned, consistently profitable trader.  

Remember, you’ll make **hundreds** of trades over your career, and a few bruises are inevitable. Keep the **big picture** front and centre, like a poster on your wall that says “Stay Hungry, Stay Foolish.” If you keep chiseling away at the factors that drag your performance down, you’ll eventually craft a trading style that’s as reliable as your favorite pair of socks.  

In the end, the recipe for long‑term success is simple:  

1. **Track** every trade and every mood, market vibe, and strategy tweak.  
2. **Analyze** the data with the curiosity of a cat watching a laser pointer.  
3. **Adjust** the weak links—whether that means tightening risk, revisiting your back‑testing, or taking a breather before you trade.  
4. **Repeat** the loop, because consistency is the only thing that makes the market stop looking like a roller coaster.

Do this, and you’ll turn those painful “oops” moments into stepping stones toward profitable, consistent trading. Cheers to learning, laughing, and finally getting that sweet, sweet edge! 🍻