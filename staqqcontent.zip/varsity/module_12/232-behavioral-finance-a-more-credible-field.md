# 232. Behavioral Finance: A More Credible Field  

**Source:** https://zerodha.com/varsity/chapter/behavioral-finance-a-more-credible-field/

---

In this little “bar‑side” column we love to take the hottest research papers from the ever‑growing playground of **behavioral finance** and serve them up in a shot glass of plain English.  
Unlike the ivory‑tower crowd of traditional finance and economics—who act like they can divine the future by staring at spreadsheets and macro‑charts—behavioral economists start with a humbler premise: **forecasts are messy because people are messy**.  

Humans aren’t flawless crystal balls; we’re prone to slip‑ups, shortcuts, and downright irrationality. Instead of crunching every data point like a math‑loving robot, we reach for “rules of thumb” (also known as heuristics) that feel good in the moment. Those mental shortcuts are the culprits behind many of the “oops‑I‑did‑it‑again” market blunders we see on Wall Street and Main Street alike.

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/04/20061004-300x300.png)

From the behavioral crowd’s point of view, stock prices are less a mirror of cold‑hard fundamentals and more a **reflection of collective investor psychology**—think of the market as a giant mood ring that changes color depending on how investors feel that day. A huge intellectual boost came from Daniel Kahneman (who, FYI, nabbed the Nobel Memorial Prize in Economic Sciences back in **2002**, not “last week”) and his late partner in crime, Amos Tversky. Their lab‑coat experiments showed that we’re **risk‑averse** (we’d rather lose $10 than gamble for a $12 gain) and that we process information about as efficiently as a toddler sorting LEGO bricks.

Two classic heuristics they uncovered are worth keeping in your mental toolbox:

| Heuristic | What it looks like in the market |
|-----------|-----------------------------------|
| **Availability** | You hear a tech stock rally on the news, it’s fresh in your mind, and you assume the whole sector will keep climbing—just because it’s easy to recall. |
| **Representativeness** | You see a small‑cap company with the “look” of a former high‑flyer, so you bet it’ll soar, even if the fundamentals are shaky. |

A psychologist peering at this circus would nod sagely and say, “No wonder economists keep missing the mark—people are about as predictable as the weather in London.” Back in the 1940s, behaviorist Clark Hull tried to write a crystal‑ball equation for human action and promptly hit a wall. Since then, the consensus has been: **if you can’t predict a toddler’s tantrum, good luck forecasting a market rally**.

Enter the economists, armed with gaudy, multi‑dimensional mathematical models that look prettier than a Christmas tree but often forget the one thing that drives markets: **human emotion**. They spend years tweaking differential equations, hoping to capture the next bubble, while most of us are just trying to decide whether to buy the dip or wait for the next meme stock.

A lot of folks still cling to the idea that a tidy model can out‑smart human folly, and they treat investment psychology as a fringe “New‑Age” side‑show. But here’s a reality check: the very same Kahneman who proved that we *systematically* misjudge probabilities was awarded a Nobel. (Don’t let the fact that the prize went to him in 2002 throw you off—Nobel committees are a bit slower than Twitter trends.) And while a Nobel doesn’t magically turn a theory into gospel (remember the Long‑Term Capital Management debacle that still haunts the 1998‑99 crisis despite the brilliance of Scholes and Merton), it does give behavioral insights a seat at the big‑kids’ table.

So, raise a glass to the growing respect for **investment psychology**. May more traders and analysts start listening to the inner monologue of the crowd, instead of just the cold numbers on the screen. After all, the market might be a sophisticated algorithm, but it’s still run by humans who occasionally binge‑watch reality TV and then decide to “buy the dip” at 3 a.m. Cheers!