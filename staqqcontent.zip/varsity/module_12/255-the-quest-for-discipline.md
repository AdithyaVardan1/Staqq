# 255. The Quest for Discipline  

**Source:** https://zerodha.com/varsity/chapter/the-quest-for-discipline/

---  

Trading with discipline is the *Mount Everest* of the trader’s world—except there’s no Sherpa, and the weather changes every time you open a chart. You’ll hear newbies whine, “I just can’t stick to my plan!” and you’ll nod, because it’s as relatable as a kid refusing to eat broccoli. You can spend weeks carving out a meticulous trading plan, jotting down entry‑criteria, stop‑loss levels, profit targets, and a whole “what‑if‑I‑feel‑like‑doing‑something‑crazy” clause. Yet the moment the real money is at stake, many of us suddenly develop a severe case of “plan‑amnesia.”  

Why does this happen? For some, the mere thought of a loss triggers a stress response that feels like a roller‑coaster without a seatbelt. For others, discipline is a muscle that’s been on a permanent vacation. Think of trading like a sport: you need a game plan, but you also need the flexibility to call an audible when the defense changes. The sweet spot is a *Goldilocks* level of discipline—neither “I’m trading once a month when the stars align” nor “I’m a robot that never deviates from a spreadsheet.”  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/04/20060525-300x300.png)

Some folks are practically born with a ruler in their pocket. They love rules, relish checklists, and get a warm, fuzzy feeling when they tick the last box on their trading plan. Others, however, are the rebel‑type who would rather write their own rulebook on a napkin in a noisy bar. The trading community tends to attract the latter—people who love risk, enjoy carving their own path, and think “discipline” is a four‑letter word that belongs in a therapist’s office. Those traits can be gold for generating big moves, but they’re also the Achilles’ heel for staying consistent.  

If you recognize yourself in the “I‑just‑can’t‑stop‑clicking‑the‑buy‑button‑because‑it‑looks‑pretty” camp, don’t panic. You can train your self‑control like you’d train a puppy—lots of patience, treats, and occasional “no‑no’s.” Here are three bar‑room‑approved tips that actually work:

1. **Discipline isn’t a 24‑7 job, it’s a part‑time gig.**  
   The universe isn’t demanding you to be a monk from sunrise to sunset. You only need to be disciplined **when you’re about to place a trade**. Think of it like wearing a seatbelt: you don’t strap yourself in when you’re walking down the street, but the moment you sit in a car, you snap that belt on. Keeping this in mind takes a lot of pressure off your shoulders—no need to monitor your breathing while you’re watching Netflix.  

2. **Write a trading plan so detailed it could double as a novel.**  
   Specify every signal that tells you *when* to jump in and every cue that tells you *when* to jump out. “If the 20‑EMA crosses above the 50‑EMA and the RSI is below 30, I buy; if the price hits my 2% stop‑loss or the MACD histogram turns negative, I exit.” Leaving gaps is like going on a road trip without a GPS—you’ll end up asking strangers for directions and probably take a wrong turn into a ditch. The more concrete your rules, the less room there is for on‑the‑spot improvisation that usually ends in regret.  

3. **Be a high‑energy, low‑stress machine.**  
   Discipline is a mental muscle that needs fuel and rest. If you’re dragging a coffee‑stained pillow under your eyes and your stress level is higher than a teenager’s Wi‑Fi bill, you’ve already handed the market a free ticket to your wallet. Aim for a state where you’re **rested, relaxed, and raring to go**—think of it as pre‑game warm‑up for your brain. Get enough sleep, do a quick meditation, or even a goofy dance to release tension. When you’re running on fumes, the odds of making a sloppy mistake skyrocket faster than a meme stock on a Reddit thread.  

In short, discipline isn’t some mystical, unattainable virtue reserved for monks on mountaintops. It’s a practical, learnable skill—like learning to ride a bike without training wheels (except the bike is a chart and the training wheels are impulsive “buy now!” thoughts). The more you practice the three habits above, the tighter your trading *muscle* becomes, and the fatter your profit “muscles” will look at the end of the month. So raise a glass, write that detailed plan, get your sleep schedule back on track, and remember: **the only thing more profitable than a winning trade is a disciplined trader who can repeat it**. Cheers to staying sharp, staying sane, and staying profitable!