# 138. A Must Trade: Sometimes It’s Better To Stand Aside  

**Source:** https://zerodha.com/varsity/chapter/a-must-trade-sometimes-its-better-to-stand-aside/

---

Picture this: a bright‑colored lottery ticket, a unicorn‑riding day‑trader, a “I‑just‑made‑$400‑today‑‑‑boom!” meme.  That’s the fantasy most people have about the market.  They think it’s a glamorous shortcut to riches and that anyone who actually *does* trade must be throwing cash into a black hole.  Unfortunately, the reverse is true for many rookie traders: they treat the market like a slot‑machine and then get shocked when the reels stop spinning.

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/02/10-300x245.png)

It’s almost a cliché now: “I’m gonna make **$400 a day**, that’ll add up to **$100 000 a year**.”  Sounds neat, right?  The problem is that the math forces you into a daily‑grind mindset—*trade every single session* to hit that $400 target.  But what if the market decides to take a nap?  What if the day’s price action is flatter than a pancake after a Thanksgiving feast?  Do you suddenly become a “range‑trade wizard” just because the universe isn’t giving you a juicy swing?  Or do you sit back, sip your coffee, and wait for the next decent setup?

If you’ve ever tried to hit a daily cash goal, you know the cascade effect:

1. **Monday**: You sit tight, the market is quiet, your P/L line stays at zero.  
2. **Tuesday**: The pressure spikes. “I need to make **$800** today to stay on track!” you think.  
3. **Tuesday** (still quiet): You start chasing low‑probability setups, racking up commissions like a vending‑machine hoarder.  

Soon you’re on a treadmill of stress, paying more in broker fees than you’re earning, and your blood pressure starts resembling a stock ticker in a flash‑crash.  If the next day also turns out to be a snoozefest, you might feel forced to jump into an overnight gap—only to watch the market jitter around for half an hour like an over‑caffeinated squirrel, then go into a deep sleep again.  The frustration compounds, the “I’m falling behind my $400 goal” narrative becomes a mental loop, and before you know it you’re trading on adrenaline, not analysis.

### Why a Rigid Daily Target Is a Rookie Trap  

Having a **ballpark** idea of what you’d like to earn on a good day is perfectly fine—think of it as a “north star.”  What trips you up is turning that star into a **hard‑wired deadline**.  Psychology research tells us that *specific* goal‑pushing only works when you already have the skillset to back it up.  In plain English: if you’ve consistently turned $100 000 a year into a reality, go ahead and write “$100 000” on the top of your vision board.  

But if you’re still in the “I made $15 000 last year because I bought a couple of meme stocks and held them for a week” club, setting a six‑figure target is like promising to run a marathon after only ever walking to the fridge.  You’ll end up **self‑sabotaging**: missing the target, feeling bitter, and then making impulsive trades just to “prove” yourself.  That’s the emotional roller‑coaster no one signed up for.

### Professional Wisdom: Think Year‑Over‑Year, Not Day‑Over‑Day  

Seasoned pros swear by the “one‑day‑at‑a‑time” mantra.  They might have a **$100 000‑a‑year** ambition, but they understand that the market is a fickle beast that doesn’t care about their spreadsheet.  On any given morning, the universe may serve up a buffet of high‑probability setups—or it may hand you a single boiled carrot.  The good traders **wait** for the buffet.  

When they do trade, they’re not yelling, “I *must* get $400 out of you today!” to the market.  They’re more like, “Hey, if you’re feeling generous, give me a clean 2% move on my risk‑adjusted size; otherwise, I’ll be right over here with my beer.”  And if the market refuses, they simply **don’t trade**.  That sounds counter‑intuitive, but it’s the same principle that a poker player folds when the cards are bad—better to lose a small ante than to go all‑in on a dud hand.

### The “Patience Pays” Playbook  

1. **Accept that no‑trade days exist.**  Treat them like a free gym rest day—your portfolio gets to recover, and you avoid unnecessary wear and tear.  
2. **Focus on *edge*, not volume.**  If your edge (probability‑weighted expectancy) is +0.5 R per trade, a single good trade can wipe out three mediocre losers.  Quality beats quantity every time.  
3. **Track performance across a *series* of trades, not a single session.**  Even the best traders lose 60 % of the time; they just make the 40 % winners big enough to cover the losers and then some.  
4. **Align goals with skill.**  If you’re consistently making $5 000‑$10 000 a year, aim for a realistic incremental target (say, $15 000 next year).  When you hit that, you’ll feel motivated—not crushed.  

### Bottom Line: Let the Market Set the Pace  

Your goals should be **flexible** enough to accommodate the market’s mood swings.  You can’t force a bull to charge when it’s feeling shy; you can only be ready to ride when it decides to charge.  That means:

- **Don’t chase** a daily dollar figure.  
- **Don’t over‑trade** just because you feel “behind.”  
- **Don’t let commissions gobble up your potential profit** on low‑probability setups.  

Instead, give yourself permission to **stand aside** when the market is quiet.  Use those quiet days to sharpen your chart‑reading, review past trades, or simply enjoy a cold brew without the anxiety of a blinking P/L.  In the long run, those days of *not* trading will be the secret sauce that keeps you **consistently profitable**—because you’re preserving capital, protecting your sanity, and waiting for the market to hand you the kind of setups that actually let you hit that $400 (or whatever number feels realistic) *without* turning every trading day into a high‑stakes gamble.

So the next time you hear a buddy brag about “making $400 a day, every day,” just smile, raise your glass, and say, “Cheers to the traders who know when to stay out of the party.”  Your portfolio (and your blood pressure) will thank you.  