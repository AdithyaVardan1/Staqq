# 208. You Can Go Your Own Way  

**Source:** <https://zerodha.com/varsity/chapter/you-can-go-your-own-way/>

---

Sergeant Friday, that no‑nonsense cop from the ’50s TV classic *Dragnet*, was famous for insisting on “just the facts.” He imagined the world as a giant traffic‑law handbook—stop at the stop sign even if you’re alone in the Sahara and the nearest car is ten miles away. Sure, a strict‑rule‑police‑state keeps the streets orderly, but life (and markets) are rarely that tidy.

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/04/20060814-300x300.png)

### Rules are what we *pretend* they are

In the real world, rules only work when a whole tribe decides to obey them. Think of a “no‑shoes‑inside” sign at a beach bar—if everyone kicks off their flip‑flops, the rule feels natural; if a lone surfer insists on sandals, the rule crumbles. Novice traders often fall into the same trap: they try to carve the market into a set of crystal‑clear, universal laws. Spoiler alert: the market never got the memo. Participants act on fear, greed, gossip, and that weird urge to check the price at 2 a.m., so predictability is a myth. What you end up with is a cocktail of intuition and an educated guess about what the crowd will do next.

### A trading plan is a *guide*, not a prison sentence

Sure, sketching out entry and exit points feels comforting—like writing a to‑do list before a Saturday night binge. But remember, those “rules” are really just friendly signposts. Stick to your plan *while you’re executing and monitoring a trade*, not when you’re day‑dreaming about the next big move. Markets don’t dance to any universal choreography; history only repeats itself when the right conditions line up, and even then the steps change. Don’t become a robotic rule‑zombie. The real edge comes from letting your personal intuition take the wheel, even if that means occasionally ignoring the GPS.

### Humans love a good herd

From the moment we learned to make fire, we discovered safety in numbers. It’s why we look to the crowd for clues—“If everyone’s buying avocado toast, it must be good, right?” That herd mentality gave us a survival advantage, and it still makes us feel cozy to follow the pack. Some folks are hyper‑conformists (think “I’ll wear whatever the office orders”), others are lone wolves, but most successful people have learned a middle ground: respect the crowd, but don’t become its slave.

Blind obedience to authority is a recipe for disaster (remember the “Tulip Mania” or the “Enron” fiascos). Compromise works better—listen, learn, then decide if the crowd’s advice fits your own risk appetite and values.

### Know thyself, then go rogue

Success in trading (and life) demands protecting your own interests while staying within socially acceptable limits. That sounds like a paradox, but it boils down to having a crystal‑clear sense of personal values and a sturdy identity. When you know who you are, you can be self‑sufficient enough to sprint off the beaten path when the situation calls for it. Flexibility and open‑mindedness are the secret sauce of a good trader; rigidity is the diet coke of the trading world—sweet at first, but it leaves you thirsty for real results.

### Short‑term trading = riding the chaos carousel

If you’re a short‑term trader, you’re basically a thrill‑seeker who profits from volatility. That usually means you have to march to the beat of your own drum. Occasionally you’ll feel like a contrarian at a party, guessing what the crowd will do next and positioning yourself to cash in on the after‑party swing. The big challenge? Knowing when to join the chant and when to whisper “nah” and go the other way.

The crowd is usually right—until the market trend flips. When almost every trader has bought into a bullish narrative, there are hardly any fresh buyers left to push the price higher. At that moment, a counter‑trend can spring up, like a sudden rain at an outdoor concert. Spotting the exact moment when the party crowd starts heading for the exits is the trader’s version of a superhero landing. That’s where intuition shines brighter than any rulebook.

There are no neat, bullet‑point formulas for “sell at 3 % profit” that work every time. You must creatively assess the situation, trust your gut, and be ready to swing your own style. It may demand courage, swagger, and the confidence of someone who can order a triple‑shot espresso at 2 a.m. without blinking. But trusting your intuition and carving your own path is the only roadmap that leads to consistent success for short‑term traders.

So, next time you hear the market whisper “follow the herd,” grin, take a sip of your drink, and ask yourself: “Do I want to be the sheep or the shepherd?” The answer, my friend, is the one that keeps your portfolio—and your sanity—alive. Cheers to going your own way!