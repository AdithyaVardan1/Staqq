# 314. Taking a Loss: Getting Over It Isn’t Always Easy  

**Source:** https://zerodha.com/varsity/chapter/taking-a-loss-getting-over-it-isnt-always-easy/  

---  

So there you are, staring at your trading screen, and *bam* – a neat $1,000 has vanished faster than the last slice of pizza at a frat party. Your first instinct? Guilt, anger, and a sudden urge to call your therapist (or maybe just the bartender). You try to soothe yourself with the classic “It’s just tuition for becoming a master trader” line. “You have to expect to lose, it’s the nature of the game,” you mutter. Handy mantra? Sure. But replaying it in your head isn’t exactly the soothing lullaby you hoped for.  

Instead, your mind does a rapid‑fire slideshow: the car payment due next Tuesday, your kid’s birthday cake that’s now a $200 liability, the shiny new car stereo you just bragged about on Instagram. “A grand is a lot of cash,” you think, “I can’t just wave it away like a bad hair day.”  

Here’s the brutal truth: you *do* have to wave it away (or at least put it in a mental drawer). As a trader, you need to zoom out, picture the whole board, and trust that if you grind enough good trades under decent market conditions, the sum of the wins will outweigh the occasional whopper of a loss. Easy to say, harder to live, because our brains are wired to freak out when the “loss‑aversion” alarm lights up.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/06/20041203-292x300.png)  

## Who else can’t take a loss?  

You’re not the only one whining about a busted trade. Even Fortune‑500 behemoths have a hard time swallowing losses. Behavioral economists have documented that companies sometimes go belly‑up rather than admit their core business model is broken. Remember Pan Am? The airline folded because its execs wouldn’t accept that the hotel arm was the real cash cow.  

Bankers cling to bad loans like a child holding onto a broken toy – they don’t want to tell the boss, “Hey, we loaned to the guy who can’t even afford a latte.” Institutional money managers, too, will sit on paper losses for months, terrified that selling would be an admission of failure.  

So, a short‑term trader feeling the sting? Totally normal. It’s just the same ancient, evolutionary drama playing out on a screen instead of a savanna.  

## The primal wiring behind guilt  

Feeling guilty over a loss isn’t some irrational quirk; it’s a survival‑grade feature. For our hunter‑gatherer ancestors, losing food meant famine for the whole tribe. Fast‑forward to today, and losing cash translates to jeopardizing rent, groceries, or that Netflix subscription you pretend you don’t need.  

Your parents and teachers reinforced the “protect the clan” script: make money, save it, don’t waste it. When a trade bites the dust, your brain interprets it as you’re endangering the clan’s safety. It’s natural to panic, to imagine the wolves (or the landlord) at the door.  

But if you want to trade professionally, you have to *re‑program* that ancient alarm. You need to become the calm, seasoned hunter who knows the odds, not the scared kid who dropped his spear.  

## How to out‑wit a lifetime of “don’t lose” conditioning  

1. **Own the guilt, and name its source.**  
   Sit down, maybe with a coffee, and admit: “I’m guilty because I risked money that could feed my family.” Naming the feeling takes away some of its power, like calling out a heckler in the crowd.  

2. **Separate “risk money” from “life‑money.”**  
   If the $1,000 you just lost was earmarked for rent, your heart will pound like a drum solo. If it was money you set aside *specifically* for trading – cash you can afford to see disappear – the anxiety drops dramatically. The golden rule: never trade with money you need for basic living expenses.  

3. **Build a risk‑management safety net.**  
   Before you even think about entering a trade, ask yourself: *What’s the worst‑case scenario?* If you’ve sized your position so that a 2% drop wipes out only a tiny slice of your capital, you can actually *sleep* after a loss. Knowing you’ve done everything possible to cap the downside makes the psychological hit feel more like a paper cut than a broken bone.  

4. **Create a mental “trading compartment.”**  
   Picture two jars on a shelf: one labeled “Bills & Groceries,” the other “Trading Capital.” When you move money into the trading jar, you mentally agree that it belongs to a different universe with its own rules. When the jar leaks, you don’t scream at the landlord; you just note that the jar needs a tighter lid next time.  

5. **Challenge the myths you tell yourself about loss.**  
   Write down a cheat‑sheet of loss‑affirming mantras and keep it on your desk:  

   - “A loss is a business expense – like a tax on learning.”  
   - “I’m paying tuition for the School of Hard Knocks; graduation is inevitable.”  
   - “Every loss is a data point that makes my strategy sharper.”  

   At first these may feel as forced as a dad joke, but reading them repeatedly rewires the brain. Over weeks, they become the mental equivalent of a warm blanket rather than a cringey sweater.  

6. **Practice, then practice some more.**  
   No one becomes a Zen trader after one meditation session. Run paper‑trade simulations where you deliberately *lose* on purpose. Treat each loss as a lab experiment. The more you expose yourself to controlled failures, the less shocking a real‑world loss will be.  

## Bottom line  

Losses are inevitable – they’re the price of admission to the trading arena. Your ancestors would have laughed at you for feeling *too* comfortable with a loss, because in their world, a missed hunt could mean death. Modern traders have the luxury (and responsibility) to separate primal fear from rational risk.  

So, next time you watch $1,000 evaporate, remember: you’ve already paid the tuition, you’ve built a safety net, you’ve compartmentalized the money, and you’ve got a list of badass mantras ready to recite. Take a deep breath, pat yourself on the back for not selling the car, and get ready for the next trade. After all, the market’s a rollercoaster, and you’re strapped in for the ride – screams and all.  