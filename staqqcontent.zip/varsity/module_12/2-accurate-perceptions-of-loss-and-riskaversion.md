# 2. Accurate Perceptions of Loss and Risk‑Aversion  

**Source:** <https://zerodha.com/varsity/chapter/accurate-perceptions-of-loss-and-risk-aversion/>

---

Emotions are the *real* “broker” behind most of our trades.  The old trading folklore is full of cautionary tales about the “fear‑and‑greed” duo that makes the crowd buy high, sell low, and then wonder why their portfolio looks like a roller‑coaster after a night at the fair.  Modern behavioural economists add a third, even sneakier side‑kick: **regret‑avoidance**.  The fear of that gut‑wrenching “I‑should‑have‑sold‑earlier” feeling pushes many of us into two classic blunders:

1. **Clinging to losers** – hoping the market will miraculously turn around, like a drunk friend who insists “the next round’s on me!”  
2. **Selling winners too early** – cashing out the moment you see a modest profit, as if you’re trying to lock in a “quick‑win” before the bartender runs out of drinks.

The tug‑of‑war between our feelings and our appetite for risk makes us second‑guess more often than a cat at a cucumber convention.  When the next trade *feels* like a slam‑dunk, we’re itching to hit the “Enter” key.  When uncertainty creeps in, we stall, and—boom!—the market swings past us like a train we just missed because we were too busy checking the time.

So what’s the secret sauce?  **Accurately perceiving risk, taming the emotional beast, and executing the trade with the cool composure of a seasoned bartender shaking a martini**.  Unfortunately, over‑confident traders often have the emotional radar of a cheap metal detector: they can’t tell when they’re about to hit a big “no‑go” zone.

> *Enter the study by Karin Tochkov and Edelgard Wulfert (University at Albany, SUNY).*

The researchers wanted to see how well people could *forecast* their own feelings after a financial loss.  They ran a two‑stage experiment:

| Phase | What the participants did | What they were asked |
|-------|---------------------------|----------------------|
| **1️⃣** | Imagined taking a gamble and *pretended* they’d lost $150. | Rated how disappointed they thought they’d feel. |
| **2️⃣** (a week later) | Actually placed the same gamble and *actually* lost money. | Compared their real‑life disappointment to the imagined one. |

![Image](https://zerodha.com/varsity/wp-content/uploads/2019/11/20070611.png)

The verdict?  **Frequent gamblers (and, by extension, many active traders) consistently *under‑estimated* how bad they’d feel after a loss**.  In other words, they thought, “Losing $150? That’s barely a paper cut.”  Non‑gamblers, on the other hand, were better at predicting the sting.  The ability to *accurately* anticipate that sting correlated strongly with **risk‑aversion**: the more you know you’ll feel like you’ve been punched in the gut, the less likely you are to step into the ring.

What does this mean for the over‑confident, over‑trading crowd?  Their brain is basically whispering, “It’ll be fine, I’ll just brush it off.”  If you *don’t* expect to feel bad after a loss, you have no internal brake and you’ll happily sprint into any risky setup.  The flip side is also true: **people who over‑estimate the misery of a loss tend to stay on the sidelines**, sometimes missing good opportunities, but they also avoid the heart‑attack‑inducing draw‑downs that ruin accounts.

### How to use this insight (without turning into a nervous wreck)

1. **Play the “future‑regret” game** – Before you click “Buy” or “Sell,” close your eyes and vividly imagine the moment you look at your account after a loss.  Picture the sour taste in your mouth, the sigh, the “why‑did‑I‑do‑that?” mantra.  The more sensory detail you add, the stronger the deterrent.  

2. **Flip the script for winners** – When a position is humming profit, instead of racing to lock in the gain, ask yourself how *not* taking the profit would feel *later*.  Will you regret missing out on a bigger win, or will you be glad you let it ride?  This balanced mental rehearsal curbs the impulse to “cash‑out early” like a kid grabbing candy before dinner.  

3. **Set concrete risk thresholds** – Treat your stop‑loss like a “no‑more‑drinks” rule at the bar.  If the price hits that line, you walk away, no arguments, no second‑guessing.  Knowing you have a pre‑planned exit reduces the emotional load when the market moves against you.  

4. **Track your emotional predictions** – Keep a simple journal: “Predicted disappointment level (1‑10) vs. actual after loss.”  Over time you’ll see whether you’re a chronic under‑estimator (danger!) or an over‑estimator (maybe you’re too cautious).  

In short, if you find yourself making too many risky trades and your account balance is bleeding, **stop pretending losses are painless**.  Visualise the sting, respect the regret, and you’ll start treating each trade like a well‑planned toast—raised with intention, not with reckless abandon.  Your future self (and your bank balance) will thank you with a smile that isn’t just “I‑got‑lucky” but “I‑actually‑knew‑what‑I‑was‑doing.”  



---  



*Remember: markets are unpredictable, but your reaction to them doesn’t have to be.*