# 212. Contagious Behavior of the Mass  

**Source:** https://zerodha.com/varsity/chapter/contagious-behavior-of-the-mass/  

---  

People love to copy each other – it’s practically a built‑in feature of the human operating system. Think about it: you see someone slip on an icy sidewalk, and your inner “self‑preservation bot” instantly tells you to tip‑toe like you’re on a catwalk made of gelatin. That’s not just good sense, it’s an evolutionary shortcut. Psychologists call the whole “hey‑look‑what‑they‑did‑I‑should‑do‑the‑same” thing **contagious behavior**. In plain English, it’s the unconscious spread of actions or feelings from one person to the next, like a meme that never dies. In the trading world we get hit by this a lot, especially when we start echo‑chamber‑listening to the loudest voices on the street and end up doing exactly what the herd is doing – whether that’s buying the hype or panic‑selling the dip.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/04/20060829-300x300.png)  

## The social side of the contagion  

Contagious behavior isn’t just a quirky footnote in a psychology textbook; it’s backed by solid social science. Researchers have found that humans run on “scripts” – pre‑written mental movies that kick in automatically when we see a pattern repeat. Imagine you’re watching a trader rave about a hot stock. A handful of folks hop on the bandwagon, the price ticks up, and suddenly a whole subreddit is shouting “BUY!” You don’t even need to read the analyst’s report; the sight of a buying frenzy is enough to make your brain say, “Yep, that’s the thing to do.” This automatic “copy‑cat” reflex works so well that people often follow the crowd without ever realizing they’ve been pulled in.  

## Bad vibes travel faster than good vibes  

If you’ve ever been in a crowded room where someone screams “Fire!” and everyone bolts for the exit, you’ve witnessed the dark side of contagion. Studies in lab settings show that we’re **more likely to catch negative emotions** – fear, panic, anxiety – than we are to “catch” joy or excitement. In a market context, when you see a wave of red candles and a flood of sell orders, your own fear sensor lights up, and you’re tempted to dump your position even if the fundamentals are still solid. In other words, the herd’s fear can be as contagious as a cold in winter, and it often leads us to act on an irrational, gut‑level alarm that isn’t serving our portfolio.  

## The biology behind the mimicry  

There’s a reason our grandparents warned us not to “follow the crowd” – it’s literally wired into our brains. Mirror neurons fire not just when we *do* something, but also when we *watch* someone else do it. That’s why you laugh when a friend chuckles, and why you instinctively flinch when you see someone else jump back from a sudden car honk. Evolution gave us this built‑in social radar so we could learn faster (don’t reinvent the wheel, just copy the one that works) and stay safe (run when the pack runs). The flip side is that the same neural circuitry can make it hard to stay calm when the market collective goes into a panic‑mode.  

## Why breaking away is a trader’s super‑power  

If contagious behavior is a virus, then the winning trader is the one who’s been vaccinated. Successful market participants often have to *play the rebel* – step back from the noise, sip their coffee, and ask themselves, “What does the chart really say?” By refusing to be a mindless follower, they can spot the sweet spot where risk and reward are actually aligned, not just where the crowd is shouting. Building immunity isn’t about becoming a hermit; it’s about recognizing the pull, acknowledging it, and then deliberately choosing a different path.  

### 1. Anticipate the herd’s pull  

The first line of defense is awareness. If you know that the crowd has a magnetic force, you can treat every surge in volume or every hype‑filled headline as a *potential trap* rather than a golden ticket. Think of it like spotting a “wet floor” sign in a supermarket – you don’t have to step around it if you’re already watching where you’re going.  

### 2. Get to know your own susceptibility  

Not everyone is equally prone to catching the market’s emotional cold. Some folks are naturally more “empathy‑rich” and will feel another trader’s fear like it’s their own. If you notice that a single headline can send your heart racing, you’re probably a high‑risk “catcher.” In that case, double‑down on a systematic plan (stop‑losses, pre‑written entry rules) so that you’re not left steering the ship with your emotions at the helm.  

### 3. Don’t stare at the crowd – stare at the chart (or the “third‑eye”)  

You can’t avoid the herd if you’re glued to the social feed, the news ticker, or the endless stream of meme‑stock tweets. Instead, take a step back and adopt the perspective of a neutral observer – the “third‑eye” that watches the market’s drama unfold without getting a ticket to the party. When you look at price action, volume, and fundamentals with a detached mindset, you’re far less likely to be swept up in the collective panic or euphoria.  

## Building your market‑immunity, one mindful trade at a time  

It’s true, shaking off contagious market behavior isn’t a one‑day miracle. The trick is to **increase your meta‑awareness**: notice when you’re feeling a sudden urge to jump on a trade because everyone else is, pause, and ask whether the move makes sense on its own merits. The more you practice this internal check‑in, the stronger your “immune system” becomes against the herd’s emotional virus. In the end, the trader who can think independently – who can sip a beer, watch the market’s drama, and still stick to a rational plan – ends up with a portfolio that’s far less likely to catch a cold from the crowd.  

So next time you feel the market’s pulse trying to sync with yours, remember: you’re the DJ, not the backup dancer. Keep the beat, stay cool, and let the herd do the chanting while you quietly plot the next winning move. 🎧🚀