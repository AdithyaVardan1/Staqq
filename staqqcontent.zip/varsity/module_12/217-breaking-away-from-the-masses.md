# 217. Breaking Away From the Masses  

**Source:** https://zerodha.com/varsity/chapter/breaking-away-from-the-masses/  

---  

> “Don’t follow the crowd!” – the line you’ve heard more times than the bartender’s “Last call!” It sounds simple, but trying to act like a lone wolf while the market’s a bustling nightclub is tougher than convincing your grandma to switch from cable to streaming. We all love the archetype of the rebel who smashes every rule and the hermit who never steps out of the house. On the opposite pole sits the ultra‑conformist, who treats every analyst’s tweet like a personal command. Neither extreme wins you a Nobel in trading. The sweet spot sits somewhere between “I’m the next Warren Buffett” and “I’m the next TikTok meme stock guru.” Getting there demands a cocktail of experience, soul‑searching, and a stubborn streak of independence—plus a dash of humility so you don’t end up buying Bitcoin at $60,000 because “everyone’s doing it.”  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/04/20061221-300x300.png)  

## Humans: The Original Herd Animals  

From the moment our ancestors figured out that a mammoth‑sized herd was safer than a solo sprint, we’ve been wired to stick together. Think of it as evolutionary group chat: “Hey, everyone, let’s stay together, eat together, and avoid being dinner.” This built‑in safety net works a lot of the time, which is why most of us feel a warm, fuzzy security when we see a line at the coffee shop or a rally on Wall Street.  

People differ in how much they hug the herd—some cling tighter than a toddler to a balloon, while others wander off like they’re on a solo road trip. Still, most “successful” folks have learned to **borrow** the herd’s wisdom when it makes sense, and to **ditch** it when it doesn’t.  

### The Schoolyard Lesson  

Remember school? The rulebook was your survival guide: wear a uniform, sit in your assigned seat, and turn in homework on time. Ignoring it usually landed you a detention, not a diploma. The point wasn’t to turn you into a robot; it was to teach you the art of compromise. You learned to protect your own interests (e.g., getting that extra credit) while staying within the boundaries of what the teacher called “acceptable.”  

That balancing act—protecting self‑interest while respecting the collective—helps you build a solid personal value system. Once you know who you are, you can **follow the crowd when it’s profitable** and **break away when the herd’s heading for a cliff**.  

## When Following the Crowd Isn’t a Crime  

We’ve all been warned that herd‑mentalities can lead to disaster—think “Tulip Mania” or “the Great Pumpkin Bubble of 2008.” Yet, most of the time, the crowd does a decent job of **minimizing unnecessary risk**. We pick safe neighborhoods, buy insurance, and—yes—invest in blue‑chip stocks that have the financial equivalent of a solid credit score.  

If a sizable crowd believes that a company will churn out steady profits for the next decade, there’s a good chance they’re onto something. In that case, hopping on the bandwagon isn’t just safe; it’s smart. Think of it as the market’s version of “if everyone’s ordering the chicken, maybe it’s good.”  

## The Trader’s Dilemma: Safe or Spicy?  

A trader, however, isn’t the type who wants a “safe as houses” portfolio. You crave **volatility** (the market’s version of a roller coaster) because that’s where the big payoffs hide. In other words, you’re looking for the *right* amount of risk, not the “I’ll never lose sleep” kind.  

That usually translates to **going your own way**—or at least looking like you are. To do this, you must think like a contrarian: **guess what the crowd will do next, then position yourself to profit from the crowd’s inevitable stumble**. The trick is to recognize when the herd is still marching forward and when it’s about to slip on a banana peel.  

### The Turning Point Theory  

The crowd is usually right—until **every single person** in the room has taken the same side of the trade. At that moment, there are **no fresh legs** left to push the price further. That’s the market’s equivalent of a “last call” sign flashing overhead. Once the supply of eager buyers (or sellers) dries up, the trend often **reverses**.  

Your job? Spot that **turning point** before the bartender (the market) starts serving the next round. Anticipate it, craft a plan, and be ready to ride the opposite wave.  

## So… How Do You Actually Do It?  

In theory, it sounds like a breezy night at the pub: “I’ll just watch the crowd, then do the opposite when they look tired.” In practice, it’s more like trying to predict when the karaoke machine will break down—tricky and prone to embarrassing moments.  

* **Predicting the pivot:** Some traders claim it’s near‑impossible; others swear they have a crystal ball (or a very good indicator). The reality is you’ll never have a 100 % success rate.  
* **Develop a method that works most of the time:** Whether you swear by moving‑average crossovers, the RSI, or the occasional headline about a CEO’s love for avocado toast, pick a framework, test it, and **respect its limits**.  
* **Put money on the line:** No paper‑trading fantasy here. You have to **risk real capital** (even if it’s a modest amount) to see if your edge holds up under pressure.  
* **Count on luck—just a pinch:** Even the best strategy needs a favorable roll of the dice now and then. If you trade enough, the odds can tilt toward you, but never count on luck as your primary weapon.  
* **Control risk:** This can’t be emphasized enough. Think of risk‑management as your designated driver. Without it, you’ll end up in a ditch (or a margin call) before you even finish the first drink.  

## The Kind of Person Who Walks Away From the Pack  

Going against the crowd isn’t for the faint‑hearted or the attention‑seekers. It’s for the trader who:

* **Doesn’t chase risk**—they’re comfortable with it, but they’re not gambling on a slot machine.  
* **Trusts their own analysis** more than a meme on a Discord server.  
* **Enjoys solitary study sessions** (or at least can pretend to while scrolling through charts).  

In short, you need to be a bit of a market‑psychologist, a data‑geek, and a creative problem‑solver—all rolled into one. With enough experience, a well‑honed perspective, and a disciplined trading plan, you can **break away from the masses** and start making money *because* you’re not just following the herd, you’re *leading* it (or at least sneaking past it with a profit in hand).  

So, next time you hear “buy the dip” shouted from the front of the room, ask yourself: *Is the dip a genuine bargain, or just another pothole the crowd is about to drive over?* The answer might just be your ticket to trading consistently and profitably—without having to explain to your friends why you own 200 shares of a company that makes... well, whatever it is they make. Cheers to thinking for yourself! 🍻  