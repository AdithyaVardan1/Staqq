# 298. Keep It to Yourself  

**Source:** https://zerodha.com/varsity/chapter/keep-it-to-yourself/  

---  

In the cult classic *Broadcast News* the aspiring anchor‑star Tom asks his weary‑but‑wise colleague Aaron, “What do you do when your life exceeds your dreams?” Aaron dead‑pans, “Keep it to yourself.”  It sounds like something you’d mutter to a bartender after a wild night, but it’s actually solid advice for anyone who’s managed to turn the chaotic world of trading into a profit‑making machine.  One thing many rookie traders gloss over is how their whole *lifestyle* can shift the moment the numbers on their screen start looking less like a lottery ticket and more like a steady paycheck.

In a little research project we ran at Innerworth (yes, we love making up fancy names for our data‑crunching labs), we discovered that only a **small slice** of our subscriber base expected any negative fallout from hitting the big‑time. In plain English: most of you don’t seem to suffer from a “fear of success” complex.  That said, a surprisingly large chunk of newly‑rich traders later confessed that the reality of winning was **nothing like the glossy day‑dream** they’d been living on.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/05/20050214-294x300.png)  

The internet is littered with cautionary tales of traders who finally cracked the code, only to find that their “extra cash” attracted a **whole new breed of relatives**—the envious aunt who suddenly remembers you exist, the friend who now asks for “just a little loan” every other week, and the cousin who assumes you’ve discovered a secret shortcut to “easy money.”  People tend to think that because you’re making money from a screen, you must have some sort of sorcery up your sleeve, and that you *don’t* deserve the hard‑won gains.  

In the most dramatic (and slightly melodramatic) scenarios, successful traders feel like strangers in their own lives.  The applause they imagined from family and friends never materialises; instead, they get the *silent* stare of a brother who now wonders why you still wear the same hoodie.  Some even feel an urge to **re‑invent their social circle**—as if the only way to protect their ego is to find people who haven’t seen the “new you.”  If you’ve ever caught yourself whispering, “The more I make, the messier my life gets,” you’ve already let that thought sit in the back of your mind, quietly sapping your trading mojo.  

Here’s the cheat code: **keep your success to yourself.**  There are a handful of very legit reasons to zip your lips.  

Most traders who taste success discover that it’s **as fleeting as a good meme**.  Sustaining it over months or years is a lot harder than scoring that first big win.  One of the chief culprits? **Stress**—especially the social stress that comes from feeling the need to flaunt your gains or upgrade your lifestyle to match your new “rich trader” brand.  When you start bragging or buying that flashy sports car just to keep up appearances, you create a **social pressure loop**: you’ve got to keep the car shiny, the house bigger, the Instagram feed “inspired,” and the anxiety levels through the roof.  

These dynamics are more potent than most traders realise.  They can sneak up on you like a market crash at 3 a.m.  The simplest, most effective antidote is to **stay low‑key**.  Don’t make a habit of posting your P&L on social media, don’t turn every coffee catch‑up into a “look at my latest trade” lecture, and certainly don’t announce to Uncle Raj that you’ve “finally made it.”  The quieter you are, the less you’ll feel the tug of external expectations, and the easier it will be to stay laser‑focused on the charts.  

Remember, the **best traders don’t chase profits**—they chase the *process*.  Trading, for many, is a blend of psychology, pattern‑recognition, and that little buzz you get when a trade clicks.  Paradoxically, when you **forget about the money**, your performance often spikes.  When you **obsess over the dollars**, your edge usually erodes faster than a sandcastle at high tide.  

So, resist the urge to overhaul your lifestyle the moment the numbers start looking pretty.  In the long run, the smartest move is to **tuck your wins away**—save them for a rainy‑day drawdown, a vacation, or that emergency pizza fund.  Keep the thrill of the trade alive, stay humble, and let the profits be a quiet, private bonus rather than a public spectacle.  That’s the recipe for **lasting profitability**—and a lot fewer awkward family dinners.  