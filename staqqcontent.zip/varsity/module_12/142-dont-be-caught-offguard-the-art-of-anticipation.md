# 142. Don’t Be Caught Off‑Guard: The Art of Anticipation  

**Source:** <https://zerodha.com/varsity/chapter/dont-be-caught-off-guard-the-art-of-anticipation/>

---

### How do you react when the trading day throws you a curve‑ball?  

Picture this: you’re trying to “squeeze” into a position and the order book just won’t give you a full fill. Do you slam your desk and mutter, “Why me?”?  
Or imagine your DSL decides to take a coffee break right when you need that live chart—do you explode in a fit of techno‑rage?  
And what about that *oops‑I‑just‑bought‑at‑the‑top* mistake—do you berate yourself like a drill sergeant on a bad day?  

When real cash is on the line, it’s natural to want everything to be as smooth as a freshly buttered biscuit. If only we could program the universe to run on “perfect‑execution‑mode,” we’d all be sipping margaritas on a beach of certainty. Spoiler alert: the universe ran out of that software years ago.  

So what’s the game plan? Accept that uncertainty is the default setting, then learn to **anticipate** every plausible outcome and keep your emotional thermostat from overheating.

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/02/04-226x300.png)

---

### Expectations are the puppet masters of our feelings  

Our brain loves making predictions—think of it as the internal weather app that constantly says “Sunny” or “Stormy.” When reality hands us a sudden downpour, we either grab an umbrella (stay cool) or start screaming at the clouds (go wild).  

Trading is a bit like a slot‑machine that *prefers* to spit out more reds than greens. The profession’s math says you’ll see **more losing trades than winners** over any sizable sample. Expecting a perpetual win streak is like assuming every pizza you order will be extra‑cheese and never burnt—delicious in imagination, disastrous in reality.  

For rookies, this mismatch between hope and hard numbers can feel like a bad Netflix binge: you keep hitting “next episode” hoping the plot will improve, only to get more disappointment. But you don’t have to let it become a full‑blown mental soap opera.  

If a loss catches you off‑guard, you’ll probably feel the sting of frustration. Anticipate that sting, however, and you’ll stay as chill as a cucumber in a freezer, ready to pull the right lever (or stop‑loss) without breaking a sweat.

---

### Reacting vs. Anticipating: a traffic‑jam analogy  

Let’s take a daily‑life scenario that even the most seasoned day‑trader can relate to: rush‑hour traffic. You’re cruising along, minding your own business, when a rogue driver decides to cut you off, rev the engine, and flash their headlights like they’re auditioning for a Fast & Furious sequel.  

If you cling to the belief that *“everyone should obey the law and drive like angels”*, you’ll probably feel a surge of **road‑rage** that could make a bull see red. Too much anger = tunnel vision = higher chance of a fender‑bender.  

Flip the script. Assume that **bad drivers exist** and **they’ll probably try to mess with you today**. Suddenly, you’re not a victim of injustice; you’re a strategic ninja. You slow down, check your blind spot, maybe even take an alternate route. You avoid the collision, keep your blood pressure low, and still get to that coffee shop (maybe a few minutes later, but you’re alive).  

Trading works the same way. You can’t stop the internet from hiccuping, but you can **have a backup plan**—maybe a mobile hotspot or a pre‑saved screenshot of the chart. Anticipate the glitch, and you won’t waste mental bandwidth screaming at the router; you’ll calmly switch gears and keep the trade engine running.  

Remember: psychological stamina is a limited resource, like the battery on your phone. If you let a surprise drain it, you’ll be left scrolling aimlessly in panic mode instead of executing a clean exit.

---

### Bad news travels fast, good news takes its sweet time  

In the trading universe, **adverse events are the rule, not the exception**. Think of it as a rule‑of‑thumb: for every 10 trades, at least 6 will bite you a little. If you *realistically* picture those setbacks ahead of time, they won’t hit you like a surprise party you didn’t want.  

When you’re mentally pre‑wired for the worst, you bounce back quicker than a rubber ball off a concrete floor. Your portfolio may still take a dip on a bad day, but your psyche stays intact, and over the long haul you’ll be the one smiling at the chart while everyone else is still nursing bruised egos.

So, the next time the market throws you a curve‑ball, a DSL outage, or a surprise “you‑just‑bought‑at‑the‑top” moment—take a deep breath, flash that anticipatory grin, and deal with it like a seasoned driver who knows the road will always have potholes, but he’s got the perfect suspension to glide over them. 🚗💨  

---  

*Bottom line:* **Anticipate, don’t react.** It’s the difference between being the calm captain steering through a storm and the panicked passenger screaming at the windshield. Keep that mental seatbelt buckled, and you’ll cruise through the market’s turbulence with style (and maybe a few dad jokes along the way).