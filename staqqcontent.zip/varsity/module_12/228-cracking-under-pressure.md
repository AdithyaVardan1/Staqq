# 228. Cracking Under Pressure  

**Source:** https://zerodha.com/varsity/chapter/cracking-under-pressure/

---

Whether you’re trying to land a trade or land a triple‑axel, pressure can turn even the most seasoned pro into a nervous wreck. Take the 2002 Winter Olympics, for instance. Michelle Kwan walked onto the ice with a mountain of expectations and, well… she slipped a few steps and settled for silver. Sarah Hughes, on the other hand, showed up with a “let’s‑just‑have‑fun” vibe. She famously said,  

> “Realistically, there was this little window, but I didn’t think I would win. I went out and just skated.”

That laid‑back attitude let her glide, improvise, and ultimately snag the gold. It’s the same principle as saying, “I’m not obsessing over how much cash I’ll make, I’m just going to trade.”  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/04/20061010-300x300.png)

Andy Bushak—who you might know from the Advanced GET crew—once told the Innerworth Master interview that the best floor traders at the Chicago Mercantile Exchange “don’t write a novel of rules for themselves. They keep it simple, do a little homework, and react to what the market throws at them.” In other words: they just trade, like a kid at a candy store who knows exactly which sweet to grab.

### The Carefree Trader’s Secret Sauce  

Successful traders behave like they’re at a backyard BBQ, not a high‑stakes poker tournament. They refuse to **force** a win, they don’t pretend they can read the market’s mind, and they certainly don’t act like they have to be right 100 % of the time. Instead, they become **objective observers**, watching price action the way a hawk watches a field mouse—quiet, patient, and ready to pounce when the moment feels right.  

Mark Douglas, the guru behind *Trading in the Zone*, describes this state as being “in the zone.” When you’re in the zone, you don’t second‑guess every entry or replay every exit in your head like a broken record. You simply **enter** and **exit** trades, trusting the process, not the outcome. That mental freedom makes opportunities pop out like popcorn in a hot pan.

### How Do You Get Into the Zone?  

1. **Think in Probabilities, Not Certainties** – Treat each trade as a roll of the dice. One flip might land tails, another heads, but over a large series you’ll see the odds even out.  

2. **Risk Management is Your Safety Net** – Decide *before* you click “Buy” how much of your capital you’re willing to lose on that single play. Most pros risk **1 %–2 %** of their account per trade. That way, even a string of losers won’t decimate your bankroll.  

3. **Believe in Your Edge** – Your strategy (or “edge”) is the reason you’re in the market at all. Trust that, over hundreds of trades, the edge will tip the scales in your favor.  

When you internalize these three points, the pressure drops like a hot potato. You become more **open‑minded**, because you stop trying to wrestle the market into doing what *you* want. Remember: the market is always right; you’re just a passenger on its wild ride.  

### Go With the Flow (Literally)  

- **Observe**: Let the price tell you what it’s doing.  
- **Adapt**: Shift your position if the market changes direction.  
- **React**: Execute quickly when the odds line up with your edge.  

By giving yourself a breather—thinking in odds, capping risk, and trusting your edge—you’ll feel lighter, sharper, and more likely to spot those sweet setups. The market will guide you, you’ll ride the wave, and before you know it, you’ll be taking home the profits *and* the stories you’ll brag about at happy hour. Cheers to trading without the pressure cooker!