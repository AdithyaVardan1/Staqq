# 102. Impulse Control Strategies  

**Source:** https://zerodha.com/varsity/chapter/impulse-control-strategies/

---

The single biggest disease that turns bright-eyed newbies into broke‑and‑bitter traders is… drum roll, please… **lack of discipline**. Instead of marching dutifully down the yellow‑brick road of their own trading plan, many rookies sprint off the path, chase shiny “quick‑profit” mirages, and end up paying the price with spotty P&L statements—or worse, a black hole in their account. In the world of psychology, discipline is often labeled *impulse control*, and there’s a whole bookshelf of classic experiments that show how you can train your brain to say “no thanks” to that instant‑gratification urge. As a trader, you’ll find these tricks surprisingly useful—think of them as the mental version of a stop‑loss order.

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/02/20070521-300x300.png)

### The classic “pretzel‑or‑pretzel‑bowl” test

Back in the 1960s, the legendary Dr. **Walter Mischel** (yes, the same guy behind the “marshmallow test”) set up a snack‑based experiment with a bunch of hungry kids. Instead of a marshmallow, he offered them **pretzels**—because nothing says “temptation” like salty, crunchy goodness. The rules were simple:

1. Ring a bell → a lab assistant hands over a single pretzel **right now**.  
2. Stay quiet → after a short wait, the kid gets a **bowl of pretzels** (a much larger reward).

The twist? The kids could *choose* when to ring the bell. The longer they held out, the bigger the eventual prize. What the researchers discovered (and what you can steal for your trading life) were three key levers that dictated how long a child could resist the crunchy call.

### 1️⃣ Visibility matters – “Can’t see it, can’t crave it”

If the pretzel sat on the table, gleaming in the fluorescent light, the kids went full‑blitz and rang the bell within seconds. If the pretzel was **out of sight**—tucked in a box, covered by a napkin, or simply imagined—many held out much longer.  

**Trading parallel:** When you’re swing‑trading a position, constantly staring at the chart is the financial equivalent of a pretzel on a plate. Every tick whispers “Buy!” or “Sell!” and your brain fires off dopamine faster than a high‑frequency bot. The solution? Give your screen a “do not disturb” badge. Set alerts, use stop‑losses, and then **walk away**. Think of your monitor as a slot machine: you can stare at it all night, but the odds of a “big win” don’t improve just because you’re watching.

### 2️⃣ Re‑framing the reward – “It’s a log, not a snack”

Mischel noticed that kids who started **re‑labeling** the pretzel could wait longer. One kid pretended the pretzel was a **log** for a campfire; another imagined it was a **picture** on a wall rather than edible. Suddenly, the urge to gnaw evaporated.  

**Trading parallel:** Many novices treat their trading capital like the rent money for their dream apartment, the down‑payment on a sports car, or the tuition for a fancy MBA. That emotional attachment makes every loss feel like a personal catastrophe. The antidote? **Objectify** your capital. View it as *10,000 abstract points*, *a percentage of your risk budget*, or even *just a number on a spreadsheet*. When the trade goes sideways, you’re not “losing money”; you’re “seeing a temporary dip in a data series.” The less you human‑ize the cash, the easier it is to stick to the plan.

### 3️⃣ The “frame” trick – “I’m just watching a movie”

Another clever maneuver was to imagine a **frame** around the pretzel—like looking through a glass window. The child realized the pretzel was *outside* the immediate decision space, which lowered the craving.  

**Trading parallel:** Put a “mental frame” around your trade. Pretend you’re a **spectator** watching a sports game on TV, not the player on the field. You can comment on the action, but you don’t get to change the rules mid‑play. Most platforms let you set **auto‑executions** (stop‑loss, target, trailing stop). Activate them, then step back and let the algorithm do the heavy lifting while you enjoy a coffee (or a nap). If you feel the itch to intervene, remind yourself: “I’m just watching the drama unfold, not writing the script.”

### Turning theory into practice – Your personal impulse‑control toolkit

If you’ve read this far, you probably already know the answer to the age‑old trader’s dilemma: *“Why do I keep breaking my own rules?”* The good news is that impulse control isn’t a mystical super‑power reserved for monks; it’s a muscle you can train. Here’s a **cheat‑sheet** you can keep on your desk (or pin to your fridge):

| **Strategy** | **Why it works** | **How to apply it** |
|--------------|------------------|---------------------|
| **Hide the reward** | Less visual cue = less craving | Use chart‑blocking tools, turn off live tickers, set price alerts instead of constant monitoring. |
| **Re‑label capital** | Detaches emotion from cash | Convert every position size into “risk‑points” or “% of equity” rather than “₹10,000”. |
| **Add a mental frame** | Creates psychological distance | Imagine you’re a referee, not a player; let stop‑losses act as the whistle. |
| **Write a bullet‑proof plan** | Ambiguity invites improvisation | List entry, exit, stop‑loss, position size, and *why* you chose each. No blanks! |
| **Reward yourself for patience** | Positive reinforcement strengthens the habit | If you let a trade run according to plan, treat yourself to a small, non‑financial reward (like a favorite snack). |

### Bottom line: Discipline isn’t a curse; it’s the cheat code

Impulse control isn’t about turning yourself into a robot. It’s about **giving your brain the right environment** to make the rational choice it already wants to make. By:

* **Keeping the screen out of sight when you don’t need it**,  
* **Seeing your capital as abstract numbers instead of your future yacht**, and  
* **Framing each trade as a “scene” you’re merely watching,**

you’ll find yourself pulling fewer “I‑just‑have‑to‑sell‑now!” moves and more “Ah, that’s exactly what the plan said—nice!” moments. Stick to a **fully fleshed‑out trading plan**, avoid any “blank spaces” that could become loopholes for impulsive decisions, and you’ll gradually transform from a “lottery player” into a **steady‑earning, disciplined trader**.

Remember: the market will always have its ups and downs, but your impulse‑control muscles can stay as steady as a lighthouse on a stormy night—if you keep training them. 🚀📈