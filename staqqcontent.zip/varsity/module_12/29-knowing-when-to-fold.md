# 29. Knowing when to Fold  

**Source:** https://zerodha.com/varsity/chapter/knowing-when-to-fold/  

---  

Finding a trading strategy that actually *works* is like hunting for a parking spot in a crowded mall on Black Friday – you know it exists somewhere, but you might have to circle a few times before you spot the perfect one. Traders have a buffet of options. Some of us geek‑out over back‑testing, feeding historical price data into spreadsheets and praying that the pattern that made a profit in 2008 will still be humming in 2026. Others trust their gut, swearing they can feel when the market is “overbought” – kind of like knowing when the bartender’s about to run out of the good whiskey and the cheap stuff comes out. No matter which road you take, you eventually have to *believe* in your plan when it’s time to pull the trigger. You can prep until the night before, run the numbers, rehearse the entry and exit in your head, but once the candle lights up, you’ve got to jump in and follow the script you wrote.  

That’s easier said than done. When a strategy keeps spitting out winning trades like a broken vending machine that only dispenses candy bars, confidence balloons faster than a birthday cake in a bakery. But every once in a while the same strategy starts acting like that vending machine after a power surge – it spits out random junk or nothing at all. Your faith wavers, and the inner voice says, “Maybe I should just dump this and try something shiny.” If you keep hopping from one method to the next, you’ll be as consistent as a weather forecast in London. The law of averages needs a *steady* sample size to tip in your favor, so you have to give any approach enough runway to prove itself. The perpetual tug‑of‑war between “stick or quit” is the rite of passage for every trader who’s ever stared at a screen and thought, “Maybe tomorrow will be different.”  

![Image](https://zerodha.com/varsity/wp-content/uploads/2019/12/20040929.png)  

### Ride the Good Luck Train  

When you finally stumble upon a strategy that clicks, treat it like a limited‑time happy hour – you want to drink it all while it lasts. Sometimes the odds tilt heavily toward you, and you’re handed a string of winning trades that feels like a casino slot machine stuck on the jackpot. To a lab‑coat investor this might look like reckless gambling, but probability theory tells us that even a fair coin can land heads ten times in a row; it’s rare, but it happens. Markets are no different – a hot streak can materialize out of thin air. The smart move? *Capitalize* on it.  

But you can’t just sit back with a beer and hope the wins keep rolling. Execution errors, nervous tremors, or a sudden loss of confidence can turn a hot streak into a cold shower. This is where polishing your trading chops pays off. The more tools you have in your arsenal – clean order entry, tight stops, a clear mental checklist – the smoother you’ll glide through each trade, extracting every ounce of profit the market offers. Think of it like a skilled bartender who can pour a perfect martini while the club is screaming “last call!” – the skill makes the chaos manageable.  

### When the Bad Luck Bus Arrives  

Just as the market can hand you a winning streak, it can also serve up a side of “what the heck?” A strategy that looked bullet‑proof on paper can suddenly start losing like it’s on a diet of lemons. In those moments the market feels like a mystery novel with missing pages – you have no clue why the plot is going off the rails. The reality is that markets are a tangled web of macro data, sentiment, algorithmic noise, and random events; no single trader can decode every variable on the fly.  

The psychological hurdle is deciding *when* to bail and *when* to stay the course. Pulling the plug too early is like leaving a party before the cake arrives; sticking around too long can empty your wallet faster than a magician’s disappearing act. One practical way to dodge the extremes is to pre‑define how much of your capital you’re willing to stake on any one strategy.  

#### A Numbers‑Based Example  

Imagine you have crunched the numbers and found a strategy that historically wins about **80 %** of the time. You decide to give it a trial run of **12 trades** and allocate **25 %** of your total account to this experiment. What does that mean in plain English?  

- **Best‑case scenario:** The 80 % win‑rate holds, you’ll likely end up **up** (the exact figure depends on your risk‑reward ratio, but you’re not losing the whole 25 %).  
- **Worst‑case scenario:** You hit a string of bad luck, lose the full **25 %** you earmarked, and your overall account stays intact because you never risked more than that slice.  

This “risk‑a‑quarter” approach gives you a buffer. You’re not throwing the whole kitchen sink at a single idea, yet you’re committing enough juice to let the strategy breathe. It’s a neat compromise between the two temptations of quitting too soon and clinging on until you’re flat‑broke.  

### No Crystal Ball, Just Good Ol’ Judgment  

Even with the smartest math and the cleanest risk plan, there’s no bullet‑proof rulebook that tells you exactly when to dump a strategy or double down. In the end, you’ll be making a call based on a blend of experience, intuition, and sometimes that gut feeling you get after a few drinks. That’s why trading is as much a **psychology** game as it is a numbers game.  

Being a winning trader, therefore, isn’t just about spotting a perfect entry point or having a flawless algorithm. It’s about developing the *discipline* to recognize the right moment to act – whether that means opening a position, tightening a stop, or pulling the plug altogether. Master the art of timing, keep your emotions in check, and you’ll find yourself saying “fold” at the right moment, just like a seasoned poker player who knows when the chips are hot and when they’re about to burn. Cheers to making the right call at the right time!  