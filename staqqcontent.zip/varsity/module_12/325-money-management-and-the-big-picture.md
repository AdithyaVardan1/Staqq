# 325. Money Management and the Big Picture  

**Source:** https://zerodha.com/varsity/chapter/money-management-and-the-big-picture/

---

Ever notice how a trader’s mood can swing faster than a swing‑trading candle? One day you’re on fire, the next you’re freezing your assets into a solid block of “what‑the‑hell‑just‑happened.” The reasons for those roller‑coaster rides are as many as the coffee shops you’ll haunt while chart‑watching. Maybe you’ve had a bad day (or a bad week—hey, who’s counting?), maybe the market decided to behave like a moody teenager, or maybe your strategy is stuck in a “needs‑a‑tweak” limbo.  

Bottom line: **performance is never guaranteed**. That means you have to start thinking about the worst‑case scenario before it shows up at your door, wearing a hoodie and a “sell‑everything” sign. Most people cringe at the thought of a massive drawdown, but ignoring it is like refusing to wear a seatbelt because you “feel the car more that way.” Spoiler alert: you’ll probably end up in a ditch.  

Seasoned traders keep telling us the same mantra, over and over, like a bartender reminding you to pace the drinks: **money management is the lifeline**. Below is a quick‑fire roundup of what a few of them said when we asked them to spill the beans on risk‑control.

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/06/20060804-300x300.png)

### Mark’s Two‑Cents

> “You can have a crummy trading strategy, but if you have good money management, you can make money. If you have poor money management, it doesn’t matter how good the trading strategy is, you’re going to lose in the end.”

Think of it this way: a brilliant strategy with terrible risk‑control is like a sports car with a busted brake system—pretty to look at, but you’ll crash before you reach the finish line.

### Chris Throws a Reality Check

> “You must have a survivability element so that if you literally wished to select stocks by throwing darts at a board, you would continue to survive market‑to‑market.”

Chris is basically saying, “Even if you’re picking stocks the way you pick pizza toppings—randomly—your bankroll should still be able to weather the next market storm.”  

### Alex’s Formula (No, Not That One)

> “I base it upon the equity in my account, first of all. Also, I look at the volatility of the stock and how much money I want to put at risk on any one position. I won’t risk more than a couple of percent on any position.”

In plain English: Alex looks at three things—**account size**, **stock volatility**, and **desired risk per trade**—and then caps his exposure at, say, **2 %** of his total equity per position. If your account is ₹10 lakhs, you’d risk at most ₹20,000 on any single trade. Simple, right?

### Mike’s War‑Room Strategy

> “You’ve got to consider the commitment size of your capital. What percentage do I commit? At the beginning of the year, I’ll risk maybe two and a half, three per cent. I may have a slew of positions on, but I’ll only risk two and a half to three per cent. I also have a reserve amount. I have war stories, so I keep a reserve as protection.”

Mike treats his capital like a military supply line. He allocates **2.5 %–3 %** of his total capital to risk on any given trade, no matter how many open positions he’s juggling. On top of that, he keeps a “reserve”—think of it as an emergency stash of popcorn for those inevitable market fireworks.

---

## The Takeaway (Spoiler: It’s About Not Getting Wiped Out)

Across the board, these veterans echo the same rule of thumb: **limit the amount you risk on any single trade**. The most common suggestion hovers between **1 % and 3 %** of your total equity. There’s no universal law that says “you must risk exactly 2 %,” but staying inside that corridor dramatically improves your odds of surviving a market swing that would otherwise turn your account into a cautionary tale.

Why does this work? Because risk‑limiting makes sure that even a string of losing trades won’t shave your account down to nothing. Imagine you start with ₹1 lakh and risk 2 % per trade. After ten consecutive losers, you’d still have roughly ₹81,900 left—enough to keep trading and, more importantly, enough to keep your sanity intact.

So, channel your inner survivalist: **size your positions, respect volatility, keep a reserve, and never bet the farm on a single idea**. In the grand scheme of things, disciplined money management is the silent partner that turns a volatile hobby into a sustainable, (maybe even profitable) gig.  

> **Bottom line:** Manage risk like you’d manage a first‑date conversation—keep it light, stay within limits, and always have an exit strategy. Your future self will thank you, and your portfolio will probably last longer than your favorite pair of jeans. 🍻