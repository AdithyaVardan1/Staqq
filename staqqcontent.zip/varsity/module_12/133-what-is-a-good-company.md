# 133. What Is a Good Company?

**Source:** https://zerodha.com/varsity/chapter/what-is-a-good-company/

---

When you’re hunting for the next stock to add to your “buy‑the‑dip” list, the phrase **“good company”** gets tossed around like a party hat at a New Year’s bash. But what does “good” actually mean? Is it the shiny logo, the CEO’s killer hair, or that glossy ad that makes you think the company is the next Apple? Too often, traders let image and hype do the heavy lifting, forgetting that the real money‑making engine is hidden in price patterns, volume spikes, and momentum cues—not in a CEO’s pep‑talk or a glossy brochure.

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/02/15-300x247.png)

### The Cisco‑Cautionary Tale

Take **Cisco Systems (CSCO)** as a cautionary cocktail. Back in the late‑90s, Cisco was the rock‑star of the dot‑com bull market. Its CEO, John Chambers, was treated like a rock‑star front‑man—analysts hung on his every syllable, and investors waited for his “how‑much‑money‑we‑will‑make‑tomorrow?” soliloquies. When the stock was climbing, Chambers was the hero, and everyone was chanting “Buy, buy, buy!” 

Then reality knocked on the door in late 2000. The market’s lofty expectations hit a wall, and Cisco’s price chart started drawing a classic down‑trend shape—think of it as a sad, sloping line that says “no more free drinks.” Once a stock is stuck in a prolonged bearish march, the rational answer for a long‑term investor is usually, “maybe we should walk away.” Yet, a swarm of analysts kept waving the “good company” flag, insisting the lower price was just a **value** opportunity, not a warning sign.

The result? A lot of poor souls clinging to their positions, watching their portfolios hemorrhage while the analysts kept smiling for the camera. Was the falling share price a symptom of a fundamentally broken business? Not exactly. Cisco still dominates networking hardware, and John Chambers (still a decent guy) remains a respected figure. But those facts did little to soothe investors who bought at $50‑$60 per share and saw the price plunge. They became victims of **biased analyst chatter**, **media hype**, and the era’s reckless optimism—much like someone who buys a tuxedo because it looks good, even though they can’t afford the rent.

### So, What *Actually* Makes a “Good” Company?

Cisco might be a “good” company on paper—big market share, strong brand, solid cash flows. But does that guarantee future profits or higher stock prices? Not necessarily. The “true value” of any firm is a moving target, debated by economists, hedge fund wizards, and that uncle who always says, “Buy low, sell high.” No one can peer into the future and say with certainty that Cisco’s potential will turn into actual earnings and a soaring share price.

### The Trader’s Reality Check

Here’s the kicker for us traders: **We care about dollars and cents in our own pocket, not about whether a company is “nice.”** Media hype, glossy PR, and the sentimental attachment investors feel for a brand can jiggle the price a bit, but they belong in the background—like the garnish on a cocktail, not the alcohol itself.

Ask yourself:

- **What’s the current price pattern?** Is the chart drawing higher highs, or is it making a sad, descending staircase?
- **How’s the volume behaving?** A price move on thin volume is like a whisper in a noisy bar—easy to miss. Heavy volume gives the move credibility.
- **What’s the momentum?** Are short‑term indicators (RSI, MACD, etc.) screaming “buy” or “run for cover”?

If the answer to those questions is “yes, we have a clean, bullish setup,” then you might consider a trade, regardless of whether the company’s logo looks cool. If the chart is a mess and the news is just hype, stay out—no amount of CEO charisma can rescue a busted technical setup.

### Bottom Line (served with a splash of humor)

Treat a company’s reputation like a **bartender’s recommendation**: it might point you toward a decent drink, but you still need to taste it before you commit to the whole bottle. In trading, let the **price, volume, and momentum** be your primary ingredients, and let the media hype, CEO selfies, and glossy annual reports be the garnish. Mix them wisely, sip responsibly, and you’ll avoid the hangover that comes from buying a “good” company that’s actually just a good story. Cheers to profitable trades!