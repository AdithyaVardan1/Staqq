# 280. Emotions in Context  

**Source:** <httpshttps://zerodha.com/varsity/chapter/emotions-in-context/>  

---  

Putting your hard‑earned cash on the line is a bit like stepping onto a rickety stage and doing karaoke in front of strangers – you’re bound to get a little **emotional**. The rookie trader especially rides a roller‑coaster of feelings: one minute they’re popping champagne after a winning streak, the next they’re Googling “how to cry in a professional manner” after a string of losses.  

So, how good are you at handling those mood swings? The winners in the market don’t just *control* their emotions; they make sure the emotions don’t end up pulling the reins. But emotions don’t live in a vacuum. They’re heavily shaped by **context** – the market environment you’re swimming in, your recent track record, even whether you’ve had your coffee.

---

## Market conditions matter

Think about the late‑1990s. The market was climbing like a kid on a trampoline with the spring stuck on “maximum bounce.” When everything seems to be going up forever, staying calm is as easy as sipping a lukewarm latte.  

Fast‑forward to the bubble burst of 2000, and suddenly the floor feels as slippery as an ice‑rink after a hurricane. Many traders discovered that trading can feel *a lot* tougher when the green lights start flickering red.  

To illustrate, let’s meet **Dustin**, a young trader we interviewed once a year for three consecutive years – 2000, 2001, and 2002. His emotional landscape shifted dramatically depending on what the market was doing and how seasoned he was feeling.

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/05/20060320-300x300.png)

---

### 2000 – The “I‑Am‑Unemotional” Phase  

Before the dot‑com crash, stocks were marching upward with barely a whisper of resistance. In that golden glow, Dustin described himself as a **relatively unemotional** trader. He told us,  

> “It takes a lot to shake me up. Even if I have one of those bad days, it just doesn’t hurt that bad because I know I’ll probably make it up.”  

When the market is basically a friendly giant handing out free candy, it’s easy to stay chill. Dustin’s confidence was buoyed by the fact that gains seemed *guaranteed* – a feeling many of us have when our favorite sports team is on a winning streak.

---

### 2001 – The Post‑Bubble Reality Check  

A year later, after the bubble burst, Dustin’s tone turned from breezy to… well, **greedy‑frustrated**. He said:  

> “The days that I lose a lot are the days that I am too greedy. Maybe I’ll have one bad trade in the morning, then I’ll be down, and it is frustrating. And then I’ll just want to climb my way out. My worst days always start out like that. Then I’ll just dig my hole a little deeper all day long. Those are my worst days. That will usually carry over until at least one more day. By then, though, I realize what I did wrong the day before.”  

He continued with a self‑help plan that would make any therapist nod:  

> “I take smaller positions at first and just try to get myself a little bit in the positive. I’m fine if I just end up making four or five hundred bucks that day because I’m just slowly climbing my way out of the hole I dug the day before. I’m not out to recapture my losses in one day.”  

Notice the shift? **Frustration** spiked because the market was no longer a guaranteed money printer. Dustin confessed,  

> “I get more frustrated than I used to, obviously just because it didn’t use to matter so much when I was making money because I knew that I could make it back.”  

The moral here? When the market turns into a grumpy cat, even the most stoic trader can feel the sting.

---

### 2002 – The Flat‑Market Enlightenment  

By 2002 the market had flattened, giving Dustin a chance to look back with a bit of distance. When we asked what he’d learned, he answered with the wisdom of someone who’s just survived a hurricane:  

> “To make me realize whether or not I was emotional, I had to go through hard times with trading. I think it’s crazy how the market can take you from a high to a low, and back to a high and then back to a low. You think you’ve got it all worked out, and then six months later, you’re thinking of finding a new job. What I realized is that when I’m doing okay, I’m totally unemotional when it comes to trading, like when a new trading strategy has been working.”  

He went on:  

> “I just sit there and have a good time. Even if I have a bad trade, it doesn’t bother me. But when I was having trouble, like earlier this year and late last year, when I was only able to keep my head barely above water, it was really frustrating. I guess that’s when you learn more about how emotional you are when it comes to the market. I’m not the kind of guy who is going to throw my keyboard around, but it definitely has a psychological impact on the rest of my day.”  

In plain English: **Good periods = Zen; Bad periods = a tiny bit of inner drama (no keyboard‑tossing required).**  

---

## The big takeaway: trading reveals your true nature  

Seasoned traders often say that the market is a **mirror** for your personality. It shows how you cope with stress, how you respond when you’re wrong, and whether you can keep your cool when the numbers start screaming.  

Dustin’s journey perfectly illustrates this evolution:

| Year | Market Mood | Dustin’s Self‑Assessment |
|------|--------------|--------------------------|
| 2000 | Bullish, easy money | “I’m unemotional; a bad day won’t hurt.” |
| 2001 | Post‑bubble crash, volatile | “I’m greedy, frustrated, digging deeper.” |
| 2002 | Flat, reflective | “I’m a mix – calm when okay, emotional when struggling.” |

He moved from *thinking* he was a robot to *accepting* that his emotional state is a **dynamic cocktail** of experience, market context, and personal temperament.  

When we asked him to sum it up, Dustin said:  

> “Obviously, when you’re doing better, it’s much easier to relax and trade. I now see that I can’t say I’m always an unemotional trader. It all depends on how I’m doing. I’ve heard that if you were to see the most successful traders who have been trading for 20 years, you couldn’t tell if they had a good day or a bad day. They are supposedly that unemotional. You read that all the time. But I have a hard time believing it. Let’s see how they would feel after eight months of losses.”  

So, the next time you feel your heart race after a trade, remember: **Your emotions are not a bug; they’re a feature of the market’s context.** The key is to recognize the situation, adjust your position size, and maybe keep the keyboard firmly on the desk (or at least away from the edge).  

Happy (and emotionally aware) trading! 🍻