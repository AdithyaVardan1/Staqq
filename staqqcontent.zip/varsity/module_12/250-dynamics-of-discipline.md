# 250. Dynamics of Discipline  

**Source:** https://zerodha.com/varsity/chapter/dynamics-of-discipline/  

---  

The trader who consistently ends up on the winner’s podium is, almost by definition, a disciplined one. In plain English that just means you write yourself a clear‑cut trading plan and *actually* follow it—no wing‑it‑and‑hope‑for‑the‑best gymnastics. People differ wildly in how well they can keep their inner “self‑control thermostat” turned up to eleven. You’ve probably noticed it at the office coffee line: there’s the person who lines up their mug, napkin, and sugar packet like a military parade, and then there’s the guy who just shoves his cup in and hopes the caffeine will sort everything out.  

Neil Simon’s classic duo, Felix Ungar and Oscar Madison, are the cartoon‑ish embodiment of that spectrum. Felix is the tidy‑freak who could probably alphabetize a bag of mixed nuts, while Oscar is the lovable slob whose idea of “organized” is “I’ll find it when I need it.”  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/04/20060602-300x300.png)  

Even Oscar, though a chronic mess, could pull off a respectable streak of discipline when the job demanded it. As a sportswriter he had to crank out a column *every single day*—no excuses, no “I’ll get to it later.” That fictional example proves a point that’s as real as your brokerage balance: you can be a scatterbrain by nature, yet still lock down laser focus for a specific mission, like executing a pre‑written trade plan. Below are a few battle‑tested tricks to keep your self‑control muscles in shape.  

---

## 1. Discipline Isn’t a 24/7 Commitment (It’s a “when‑the‑trade‑happens” one)

First, relax. You don’t need to be a monk chanting “Om” while you stare at the sunrise *every* minute of the day. The universe only asks for discipline at the moments that actually matter—namely, when you’re about to click that “Buy” or “Sell” button. Remember that: the pressure eases dramatically when you treat discipline as a “switch‑on” skill rather than a constant background hum. Think of it like putting on a superhero cape **just** before you leap off a building; you don’t wear it to the grocery store (unless you’re into that).  

---

## 2. Write a Trade Plan So Detailed It Makes a Cookbook Jealous  

If you’ve ever tried to navigate a road trip with a vague “head north sometime” instruction, you know why specifics matter. Your trading plan should spell out, in bullet‑point perfection, *exactly* what signals get you to the entry gate and what signals usher you out. Example: “Enter long when the 20‑day EMA crosses above the 50‑day EMA **and** RSI is below 30.” Likewise, “Exit when price drops 2 % below entry **or** MACD histogram flips negative.”  

Some traders think they can improvise, like jazz musicians who “just feel the market.” Unfortunately, that “feel” often turns into “feel‑bad” when you’re staring at a red‑ink loss. Leaving blanks in your plan is an invitation for the brain’s inner couch‑potato to take over, and that couch‑potato rarely makes profitable decisions.  

---

## 3. Keep Your Energy High and Your Stress Low—Like a Well‑Tuned Sports Car  

Self‑control is a mental muscle that needs fuel. When you’re running on three hours of sleep and a mountain of unread emails, the brain’s “discipline budget” is practically bankrupt. Think of yourself as a high‑performance sports car: you need premium fuel (rested mind), proper oil (low stress), and a clean air filter (clear focus). If any of those go missing, you’ll stall at the starting line, or worse, spin out on the highway of market volatility.  

Practical tips:  
- **Sleep** at least 7 hours—your brain’s warranty expires after that.  
- **Exercise** a few times a week; a brisk walk can boost dopamine and lower cortisol.  
- **Meditate** for 5‑10 minutes before trading; even a short mindfulness session can sharpen attention like a laser pointer.  

When you’re refreshed, you’ll notice you make fewer “oops‑I‑did‑that‑by‑accident” mistakes, and more “aha‑I‑got‑this‑right” high‑fives.  

---

## 4. Confidence is the Secret Sauce (But Don’t Mistake It for Arrogance)  

There’s a fine line between healthy skepticism and full‑blown paranoia. While you’re crafting your trade plan, be the cautious detective—question every assumption, double‑check every indicator. Once the plan is locked, flip the switch to **confidence**. Walk to your broker like you’re buying a round of drinks for the whole bar; you *know* you’ve got the right move.  

Don’t second‑guess mid‑trade. That mental “what‑if” chatter is the same thing that makes you check your phone every two seconds during a movie. Let the plan run its course, then evaluate the outcome after the trade is closed. If it worked, pat yourself on the back; if it didn’t, treat it like a lesson rather than a personal indictment.  

---

## 5. Bottom Line: Discipline = More Profits (It’s Not a Myth, It’s Math)  

The bottom line is simple: the tighter you keep the reins on your trading behavior, the more likely you are to stay on the profit side of the ledger. Discipline isn’t some mystical virtue reserved for monks; it’s a practical, repeatable process you can train—just like learning to ride a bike, except the bike sometimes tries to throw you off a cliff.  

So, write that detailed plan, get enough sleep, keep stress at bay, and walk into each trade with the swagger of someone who *knows* they’ve done the homework. Your future self (and your trading account) will thank you with a fatter smile—and maybe an extra cocktail at the bar when you celebrate those hard‑earned wins. Cheers to disciplined trading!