# 226. Coping Skillfully To Achieve Success  

**Source:** https://zerodha.com/varsity/chapter/coping-skillfully-to-achieve-success/

---  

The markets love to play hard‑ball. One minute they’re whispering sweet nothings, the next they’re screaming “Buy! Sell! BUY! SELL!” like a toddler with a megaphone. Some traders crumble like a soggy cookie, while others surf the chaos like they’re on a private jet with a personal butler. So, what separates the trader who puts on a cape and battles the market‑monster from the one who runs for the nearest exit? Spoiler alert: it’s **how you deal with stress**.  

The “storm‑riders” usually end up with a treasure chest of profits, whereas the “storm‑avoiders” often find themselves broke, bewildered, and wondering why they ever thought a chart looked like a work of art. To the untrained eye, the market may look like a random‑number generator that got drunk at a party. Vulnerable traders stare at that apparent chaos, see only panic, and start making the kind of impulsive moves you’d make when you’re five and trying to grab the last slice of pizza.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/04/20070212-300x300.png)  

Those panic‑driven folks hop on an emotional roller‑coaster that goes from “I just lost everything, I’m a failure” to “I’m the next Warren Buffett, buy everything!” in the time it takes to say “stop‑loss”. Meanwhile, the winning traders stare at the same data and see a hidden rhythm—like spotting the beat in a noisy club. They trust that the odds are on their side **if** they keep taking well‑planned trades under decent market conditions.  

In his book *The Psychology of Trading*, Dr. Brett Steenbarger recounts a little experiment he ran on **64 active traders** (yes, a nice round number that fits neatly on a PowerPoint slide). He wanted to know whether the way traders coped with stress could actually predict who would be cash‑rich and who would be cash‑poor. He measured personality traits, stress‑handling styles, and then let the market do its thing.  

### The “Problem‑Focused” Heroes  
A chunk of those traders turned out to be *problem‑focused copers*. What does that mean? Think of them as the MacGyvers of the trading floor. When stress knocked on their door, they didn’t just whine; they **gathered data**, built a plan, and executed it step‑by‑step.  
* Example: “I’m losing money because the VIX spiked.” → “Alright, let’s pull up the implied volatility chart, see if the spike is a one‑off or a trend, and adjust my position size accordingly.”  

These traders kept their eyes on the *process* rather than the *pain*. They asked, “How can I fix this?” instead of, “Why does everything hate me?”  

### The “Emotion‑Stuck” Strugglers  
The rest of the cohort were more like kids who stare at a broken toy and cry, “It’s broken! It should work!” They spent all their mental bandwidth **feeling** the bad vibes and trying to *force* the market to behave the way they wanted. In other words, they tried to make reality bend to their expectations, rather than accepting the market’s reality and adapting.  

Result? Their attention was glued to the *unpleasant emotions* instead of the *trade plan*. They abandoned or constantly tweaked their strategies, and, predictably, their profit‑and‑loss statements looked like a toddler’s finger‑painting—messy and hard to read. Dr. Steenbarger’s data showed that these “emotion‑stuck” traders were **less profitable** and more likely to bail on their own trading rules.  

---

## So, What’s the Playbook?  

### 1️⃣ Admit That Stress Is a Thing  
First thing’s first: **own up**. Pretending you’re a Zen monk while the market is doing a back‑flip is like pretending you’re not allergic to peanuts while munching on a bowl of satay. You’ll waste more time dodging the inevitable than you’d save by simply saying, “Hey, I’m feeling the heat, let’s deal with it.”  

### 2️⃣ Switch to a Problem‑Solving Mindset  
Now that you’ve stopped denying the elephant in the room (or the bull on the chart), it’s time to become a *creative problem‑solver*.  

* **Stay optimistic, but keep your shoes on the ground.** Think of optimism as the fuel and realism as the brakes.  
* **Put in the work.** If you’d rather spend an hour reading a meme page than dissect why a particular sector is under pressure, you’re probably not going to solve the stress.  
* **Don’t let the market’s drama freeze you.** Use the same curiosity you have when you discover a new Netflix series: “What’s the plot twist? How can I adapt?”  

When you tackle stress head‑on, you’ll feel lighter, trade sharper, and—most importantly—watch the profit meter climb.  

---

### TL;DR (Because We All Love a Good Summary)  

| Stress‑Handling Style | What They Do | Typical Result |
|----------------------|--------------|----------------|
| **Problem‑Focused** | Gather data, make a plan, act step‑by‑step | Higher profitability, calmer mind |
| **Emotion‑Stuck** | Dwell on feelings, try to force the market to fit expectations | Lower profitability, frequent plan‑abandonment |

Bottom line: **Stress isn’t the enemy; the *wrong* reaction to stress is.** Admit the pressure, become a tactical fixer, and you’ll turn those market thunderstorms into a breezy afternoon stroll—complete with a side of extra cash.  

Now go forth, sip that coffee, and remember: the market may be wild, but you’ve got a secret weapon called *skillful coping*. Use it wisely, and the profits will follow like a loyal dog after a squirrel. 🐶📈