# 296. Justified versus Unjustified Wins  

**Source:** https://zerodha.com/varsity/chapter/justified-versus-unjustified-wins/

---  

Jack is a green‑horn trader who’s just discovered the sweet taste of a “win” and is practically doing a victory dance in his kitchen.  
> “I’ve just made a big profit on a trade by pure chance,” Jack proclaims, eyes sparkling like a kid who just found the hidden chocolate bar. “I went long on a stock, expecting it to climb about **0.90 points**. I was wrong. It slipped **0.50 points** lower, but I thought, ‘Hey, why not ride this roller‑coaster and see where it ends?’ By the close, the price was **0.60 points** above my entry and I sold for a profit.”  

His pal, who’s been watching Jack’s trading antics like a reality‑TV audience, asks, “Did you have any inkling the stock would bounce back?”  
Jack shrugs, “Nah, I was just lucky.”  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/05/20050216-294x300.png)

---

## Does this sound familiar?  

Picture this: Jack *thought* the stock would go up, but when it didn’t, he abandoned any semblance of a plan and just let fate decide. “All’s well that ends well,” he mutters, sipping his celebratory soda.  

Sure, the cash in his pocket is bigger, but at what **psychological** cost? He entered the trade without a crystal‑clear game plan, rode the wave of pure luck, and walked away with a profit. Short‑term euphoria? Absolutely. Long‑term discipline? Not so much.  

---

## When luck gets a gold star…  

Instead of **crafting a detailed trading plan**, executing it, and letting the plan earn its keep, Jack tossed a dart at a board, hit the bullseye, and thought, “I’m a natural!” In reality, a *lack of discipline* was the one that got the reward.  

That **unjustified reward** is a sneaky little gremlin: it whispers, “Hey, you don’t need a plan; just wing it and you’ll keep winning.” The problem? Those lucky moments are usually **short‑lived**. Over time, the gremlin’s encouragement turns into a habit of haphazard trades, which—spoiler alert—tends to produce **losses**.  

---

## The showdown: Justified vs. Unjustified Wins  

| **Justified Win** | **Unjustified Win** |
|-------------------|----------------------|
| ✔️ Built on a **detailed trading plan** (entry, stop‑loss, target, risk‑reward, etc.) | ❌ No plan, or the plan was *abandoned* mid‑trade |
| ✔️ Profit arrives **because** the plan was followed | ❌ Profit arrives **by chance** |
| ✔️ Reinforces **discipline** – you’re basically patting yourself on the back for doing the work | ❌ Reinforces **undiscipline** – you start thinking luck is a strategy |
| ✔️ Sets the stage for **consistent, long‑term profitability** | ❌ Sets the stage for **inconsistent, short‑term thrills** |

In short, a win that’s earned through a solid plan is a *justified* win and acts like a high‑five to your disciplined self. A win that pops up because you threw the rulebook out the window is an *unjustified* win—it’s a fleeting pat on the back that quickly turns into a slap when the next trade goes south.  

---

## Discipline = Consistency = Profit (the holy trinity)  

Trading, at its core, is about **capitalizing on chance**—but not the “flip a coin and hope for the best” kind. It’s about **repeating proven strategies** over and over so that, across a series of trades, the odds tilt in your favor. Think of it like a basketball player who keeps shooting free throws. The more attempts you make, the more points you’ll rack up—*provided* you actually **make the shot**.  

The **winning player** isn’t the one who once nailed a three‑pointer and then started dribbling randomly. He’s the one who has honed his form so that each shot has a high probability of swishing through the net. Same principle applies to markets: develop a strategy, stick to it, and let the **law of averages** do its magic.  

---

## Consistency is the secret sauce  

If you use one approach for trade #1, a completely different approach for trade #2, and a third, random method for trade #3, you’re basically running a circus with no ringmaster. Performance becomes **haphazard**, and the probability of success **dilutes**.  

Let’s get concrete:  

- Suppose you have a strategy with a **track record of 80 %** (i.e., historically, it wins 8 out of every 10 trades).  
- In an *ideal* world, you’d expect to win roughly **80 %** of the time.  
- Reality, however, is a bit of a prankster. Market conditions shift, slippage occurs, and you’ll probably win **less than 80 %** over a given sample.  
- If you **don’t execute the strategy the same way each time**—maybe you skip the stop‑loss on a whim, or you double the position size because you “feel lucky”—you’re effectively **eroding those 80 % odds**.  

Fewer winning trades translate to **lower overall profitability**, and you might even flip into the red despite having a solid edge on paper. That’s why discipline isn’t just a nice‑to‑have; it’s the **engine** that lets your edge breathe.  

---

## Bottom line: Let discipline pay the bills  

When you experience an **unjustified win**, it feels like a freebie—like finding a $20 bill in an old coat pocket. It’s tempting to let that feel dictate future behavior, but the **long‑term price** is steep: you’ll start ignoring your own rules, and the next time the market doesn’t swing in your favor, you’ll be left with a **big, ugly loss** (and probably a bruised ego).  

Instead, treat every trade as a **test of your plan**. If you stick to the plan, the math says you’ll **come out ahead** over enough trades. If you abandon it, you’re gambling on luck, and luck is a fickle roommate—great when it’s there, awful when it’s not.  

So, here’s the bartender’s advice:  

1. **Write down** your entry, stop‑loss, target, and risk‑reward **before** you press the buy/sell button.  
2. **Execute** exactly as you wrote it—no improvisation unless your plan explicitly allows for it.  
3. **Celebrate** the wins that came because you *did* the work (those are the justified wins).  
4. **Ignore** the “I got lucky” wins; they’re just free drinks that will make you sloppy later.  

In the end, a string of justified wins builds an **unshakable pattern of disciplined trading**, and that pattern is what turns a hobbyist into a *profitable* trader. Cheers to discipline—and may your future wins be justified, not just lucky!