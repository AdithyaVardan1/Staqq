# 28. Focusing on the Positive  

**Source:** https://zerodha.com/varsity/chapter/focusing-on-the-positive/  

---  

When you’re wrestling with the wild beast called “trading,” the easy trap is to stare at every little mistake like it’s a stain on your favorite shirt. You start thinking, “I’ll never get the market to love me,” and before you know it you’re drowning in self‑critique.  
**Instead, flip the script:** first give yourself a high‑five for the stuff you’re actually doing right. Identify the strengths in your toolbox, then—once you’ve got that warm, fuzzy feeling—pinpoint the exact cracks that need a little patchwork. If you begin with the negatives, you’ll probably end up feeling frustrated, maybe even a bit defeated. Starting with the positives, however, pumps you up with optimism. And a happy trader is a trader who can actually *look* at the flaws, dissect them, and start building the skills needed to cover those blind spots.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2019/12/20070614.png)  

## Why we’re all “failure‑phobics” (and why that’s a problem)  

From the moment we learn to walk, someone is pointing out what we can’t do: “Don’t touch the hot stove!” “Watch your tone!” “You’re not supposed to draw on the walls!” The result? We grow into adults who scan for limitations like a detective looking for clues in a crime scene—only we hide the clues from ourselves because we’re scared of the “punishment” that might follow.  

The fallout? We keep our mistakes under a rug, and only when the rug catches fire do we finally admit, “Hey, maybe I should’ve done something different!”  

A better approach is to *welcome* failure the way a kid welcomes an extra slice of pizza—enthusiastically and without guilt. Think of it as: “I trust my overall skill set. I’ll throw a trade at the market, see what bites, and then use that bite as a lesson.” When you treat a loss as a growth opportunity instead of a personal apocalypse, you automatically switch from a doom‑and‑gloom mindset to a problem‑solving mode.  

## The power of a positive outlook (and why it matters for traders)  

Trading is a mash‑up of many moving parts: chart analysis, risk management, position sizing, psychology, and a handful of other skills that would make a Swiss‑army knife jealous. Expecting to nail every piece on the first go is like expecting to run a marathon after only walking to the fridge. You’ll just end up stressed, burnt out, and probably muttering curses at your screen.  

The smarter way is to **break the beast down**:  

1. **Isolate each sub‑skill** – treat entry timing, exit strategy, and risk control as separate mini‑games.  
2. **Master one mini‑game at a time** – practice until it feels as natural as breathing.  
3. **Combine the pieces** – once a few mini‑games are solid, start stitching them together into a full‑blown trading plan.  

Picture a trader who’s got discipline nailed down—he never impulsively adds to a losing position, he respects his stop‑losses, and his capital management is on point. Yet his account is still in the red because his *strategy* is about as reliable as a weather forecast from a fortune cookie.  

If that trader can see his disciplined capital, his solid risk rules, and his unwavering plan as assets, he’ll feel a surge of confidence. That optimism fuels the energy needed to dig into the one missing piece: a winning entry/exit strategy. In other words, he can focus on learning *better* setups while resting easy knowing the rest of his system isn’t the problem.  

## Everyone’s mix of strengths and weak spots is unique  

Some folks have razor‑sharp strategies but can’t stick to the plan—think “great recipe, but they keep adding extra salt.” Others can follow a plan to the letter but haven’t figured out the entry signal—like a diligent driver who never knows when to hit the gas.  

Whatever the “wrong” part is, it must be identified and corrected. But if you spend the entire day wallowing in what’s broken, you’ll end up feeling like a sad trombone solo at a jazz club. Flip the focus: celebrate the things that are already working. That optimism acts like a mental caffeine boost, letting you look at the limitations with a clear, objective eye and actually *fix* them.  

In short: start with the positives, get your morale up, then tackle the negatives with the same precision you’d use to slice a perfectly cooked steak. Your trading journey will feel a lot less like a bleak hallway and a lot more like a lively bar conversation—full of laughs, learning, and a few good stories to tell later.