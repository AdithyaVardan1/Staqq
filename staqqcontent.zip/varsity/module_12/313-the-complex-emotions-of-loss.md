# 313. The Complex Emotions of Loss  

**Source:** https://zerodha.com/varsity/chapter/the-complex-emotions-of-loss/

---  

Jim just pulled a classic “high‑stakes gamble” and the market handed him a one‑way ticket to **Lossville**. He’d been eye‑balling a stock for a month, watching it slide like a kid on a playground slide. Then—boom!—the earnings report dropped. The night before, Jim was convinced the company would crush analyst forecasts, so he loaded up on **1,000 shares**, betting the price would rocket after the numbers came out.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/06/20041206-292x300.png)

He was *so* sure the trade would go his way that he **forgot to put a stop‑loss** on the order—basically telling the market, “Hey, I’m *not* scared of you.”  
When the actual earnings arrived, they missed the consensus by a comfortable margin, and the crowd (read: the market) reacted like a cat on a hot tin roof. The share price nosedived, and Jim’s account took a massive hit. He’s now a cocktail of anger, guilt, fear, and disbelief. The cocktail is strong, but unless Jim learns to sip it responsibly, that loss could haunt him longer than that ex‑girlfriend who still texts “u up?” at 2 a.m.

---

## The “Why Me?” Monologue  

Jim starts blaming everything from fate to his own brain. He mutters:

> “Why couldn’t the universe bend to my will? I should’ve been more skeptical. I shouldn’t have trusted my gut. I shouldn’t have risked this much. I should’ve set a stop‑loss.”  

His reasoning isn’t nonsense—he’s disappointed that his confidence didn’t pay the bills, and he’s angry at the market for pulling the rug out from under him. The guilt feels like a personal failure, as if he let his own ego down a peg.  

He then goes into full‑blown “what‑if” mode: “Maybe I could’ve risked less, or done more homework on why the price was already falling. I should have crunched every possible factor.” Those thoughts are natural; the brain loves to replay a loss on loop, trying to rewrite history like a bad sitcom rewrite.

---

## Step 1: Pull the Emotional Fire‑Extinguisher  

First, Jim needs to **step back and stare at the trade like a detective at a crime scene**, not like a drama‑queen at a soap opera. Right now his emotions are the loudest voice in the room, and they’re not exactly helpful.  

A little **positive self‑talk** can work wonders. Something like:  

*“Sure, I over‑leveraged this time, but that doesn’t make me a villain. Taking extra risk isn’t automatically a crime; it’s just a higher‑stakes poker hand.”*  

Even seasoned traders occasionally stretch their risk limits—think of it as a “cheat day” in a diet. It’s not a moral failing, just a data point.  

Jim could ask himself: *Did I ignore any red flags?* Maybe he should have factored in the recent downtrend, the looming macro‑risk, or the fact that earnings surprises are notoriously fickle. If he had **objectively evaluated the evidence** instead of riding a gut feeling, the odds might have tipped in his favor.  

That said, **hunches aren’t illegal** in the trading world. Many pros swear by them—just don’t make them the only pillar of your strategy. And remember, even a perfect deep‑dive into every news release won’t guarantee certainty; markets love to surprise you, especially when you’re not looking.

Bottom line for this step: **Pat yourself on the back for the bravery** of putting capital on the line, acknowledge the missteps, and remind yourself that being human includes making mistakes.  

---

## Step 2: Turn the Loss Into a Lesson (or at least a funny story)  

Now that the emotional smoke has cleared, Jim must decide **what the trade taught him**. There isn’t a universal “one‑size‑fits‑all” checklist—trading is part art, part science, part circus.  

Possible takeaways for Jim:  

* **Never trust an unsubstantiated hunch** without a backup plan.  
* **Never risk more than X % of your account** on a single idea (many traders cap it at 1–2 %).  
* **Always, always use a stop‑loss**—think of it as a safety net for when the market decides to play “who can fall faster.”  

Other traders might draw the opposite conclusions:  

* “Hunches are right 70 % of the time; I’ll keep using them, just with a tighter stop.”  
* “Losses are part of the game; I’ll stay chill and stop treating every dip like a personal betrayal.”  
* “There was nothing I could have done; I’ll just pray to the market gods next time.”  

Whatever the conclusion, the key is **self‑determination**. Jim gets to choose his own moral of the story, whether it’s “stop‑losses are my new BFF” or “I’m a risk‑tolerant tiger who can handle the jungle.”  

The overarching rule when a trade goes south:  

1. **Neutralize extreme emotions** by monitoring your self‑talk and replacing “I’m a failure” with “I’m a learner.”  
2. **Extract (or consciously decide not to extract) a lesson** and then **move on** faster than a cat chasing a laser pointer.  

---

## The Bottom Line: Don’t Let the Guilt Eat Your Lunch  

When a loss hits, it’s tempting to drown in guilt and anxiety, replaying the trade like a broken record. Those feelings, while human, **don’t improve your next entry**. Instead, they keep you stuck in the past, scrolling the same loss‑inducing meme over and over.  

Treat losses like a **bad haircut**: it looks terrible in the moment, but it grows out. Take the hit, learn what you can, and get back to the market with a fresh perspective (and maybe a new haircut).  

In short, **lose with dignity, laugh at the absurdity, and keep your trading game moving forward**. Cheers to the next trade—may your stop‑loss be tight and your hunches be spot‑on! 🍻  