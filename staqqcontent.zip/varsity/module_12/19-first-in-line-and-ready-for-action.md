# 19. First in Line and Ready for Action  

**Source:** <https://zerodha.com/varsity/chapter/first-in-line-and-ready-for-action/>

---  

There’s a certain comfort in numbers. Ever watched a school of fish doing synchronized swimming in an aquarium? Those little swimmers stick together because if a bigger, teeth‑filled predator circles the tank, a fish in the middle of the pack is far less likely to become dinner than a lone wanderer on the edge. Humans do the same thing every day, only our “predators” are often traffic cops or that one coworker who always steals the last donut.  

Take a lonely stretch of highway at 80 km/h. You’ll feel a lot more confident when you’re sandwiched between a sea of metal boxes rather than cruising solo in a desert of asphalt. The logic people tell themselves is, “the highway patrol can’t ticket every car, so why bother?” That “safety in numbers” mindset pops up everywhere – even on the trading floor. “The trend is your friend,” they whisper, as if the market were a loyal golden retriever that never bites. Spoiler alert: the market can be a very mischievous cat.

![Image](https://zerodha.com/varsity/wp-content/uploads/2019/11/20050325.png)

---

### Why following the crowd is sometimes a good idea (and why it’s terrible for trading)

It feels natural to hitch a ride on the herd train. If none of your affluent aunties live on the west side of town, you’ll probably wonder, “What’s the deal there?” and simply set up shop on the east side with everyone else. That kind of social‑proof shortcut can save you a lot of research time in everyday life.  

But when it comes to markets, that shortcut becomes a trapdoor. You have to *predict* what the crowd will do next, then jump ahead of them like the eager kid at a roller‑coaster who cuts in line. In trading, the core activity is buying low and selling high—usually within a short window. If you spend all your time trailing the crowd, you’ll be the last one off the ride, and the only thing you’ll be selling is a sore ankle.

---

### A concrete example: the “wait‑for‑the‑crowd” pitfall

Imagine you’ve scooped up a hefty block of XYZ stock because you think it will pop a few points higher. You’re planning to unload when the price hits your target. If you sit on your hands and wait for the masses to stampede in, confirming your hunch, you might be playing catch‑up with a *down‑trend* wave.  

Prices move in cycles—think of them as the market’s version of a tide. If you hold out for the price to crest at the very top, you could be trying to sell right as the tide is turning back out. By the time the crowd finally rushes in, the excitement has faded, fear has set in, and the market is suddenly a “sell‑everything‑you‑own” clearance sale. Your profit dreams get trampled under the weight of panic sellers.

---

### The ideal scenario: be the first in line, not the last

What you really want is to **anticipate** the moment the herd gets a sudden burst of buying power, buy *before* they do, and then be the first to unload when the frenzy peaks. In other words, you’re the early‑bird who catches the worm while everyone else is still snoozing.  

That means you have to be in a completely different “line” than the crowd—your line is the one that sells when the masses are *buying*. It sounds like a paradox, but it’s the classic “buy low, sell high” play, just with a timing twist. The trick is to spot the upcoming trend **before** the crowd spots it, then do the opposite of what the crowd is doing at that very moment.

---

### How to pull off this stunt (without pulling a hammy)

1. **Momentum indicators** – Think of them as the market’s gossip column. Tools like the Relative Strength Index (RSI), Moving Average Convergence Divergence (MACD), or the simple 20‑day moving average can give you early hints that a pivot is about to happen. When the RSI spikes above 70, the market might be *overbought* (crowd is about to panic sell). When it dips below 30, it could be *oversold* (crowd is about to rush in).  

2. **Psychology check** – This is the harder part. We spend a lifetime being taught that safety equals conformity. In the trading arena, those lessons are *exactly* what you need to un‑learn. Treat the crowd not as a safety net but as an opponent you can out‑maneuver.  

3. **Plan your exit** – Even if you get the timing right, you still need a clear exit strategy. Set a target price, a stop‑loss, or a trailing stop. Think of it as a pre‑written punchline—you know when the joke lands, you deliver it, and you don’t have to improvise under pressure.

---

### The crowd is your *enemy*, not your ally

Remember that during the California Gold Rush, the million‑dollar mansions weren’t built by miners who struck gold. They were erected by the folks who ran the general stores, saloons, and laundry services—people who sold *to* the hordes of hopeful prospectors. Those prospectors were driven by greed, fear, and a serious lack of financial literacy.  

As a trader, you’re in the same position as those savvy merchants. Your job is to spot the herd’s emotional state (greed when they think the market will keep climbing, fear when it looks like it might crash) and position yourself to profit from it. Be the first to think, “Hey, everyone’s about to panic‑sell—time to buy,” or “Look, the crowd is about to binge‑buy—time to unload.”  

In short, treat the herd’s *herd mentality* as a market inefficiency you can exploit. Be the early‑bird line‑cutter who walks away with the goodies while everyone else is still stuck waiting for the gate to open.

---

**Bottom line:** Numbers may give you comfort, but in trading, comfort is often a mirage. The real edge comes from *anticipating* the crowd’s moves, positioning yourself ahead of the curve, and having the guts to act when everyone else is still chewing on the same old “trend is your friend” mantra. Be the first in line, and let the herd’s fear and greed do the heavy lifting for your profit. 🚀