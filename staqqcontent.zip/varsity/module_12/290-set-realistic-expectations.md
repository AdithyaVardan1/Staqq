# 290. Set Realistic Expectations  

**Source:** https://zerodha.com/varsity/chapter/set-realistic-expectations/

---  

Trading is basically a high‑stakes emotional‑gymnastics act. If you let disappointment or fear run the show, you’ll end up more frazzled than a cat in a room full of laser pointers. Those extreme feelings suck up your mental bandwidth and keep you from concentrating on the charts, the orders, the *actual* work of trading. The culprit is often not some mysterious market conspiracy but the **expectations** you’ve piled on yourself. When your goals are out of sync with where you actually stand skill‑wise, you set yourself up for a roller‑coaster of panic and let‑down.

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/05/20050224-294x300.png)

Common sense (and every motivational poster ever) screams, “Aim high!” because, let’s face it, you won’t win a gold medal if you only aim for the participation ribbon. But there’s a twist: aim *so* high that you’re constantly tripping over the bar, and you’ll spend more time bruised on the floor than basking in glory. The paradox is that over‑ambitious standards can actually **sabotage** you. You keep trying, keep missing, and eventually you might throw in the towel—perhaps dramatically, perhaps with a “I quit” meme.

What research tells us (thanks, Dr. E. Tory Higgins) is that we judge ourselves in two main ways:

1. **Ideal expectations** – “What would be *awesome* if it happened?”  
2. **Ought expectations** – “What *I should* achieve according to my own rulebook.”

Whenever reality fails to match either of those, the brain pulls a classic emotional switch: disappointment for the unmet ideal, fear for the missed “ought.”  

### The “Ideal” Trap  

Picture a trader who day‑dreams about ditching the 9‑to‑5 and becoming a full‑time chart‑guru, sipping espresso while the market does the heavy lifting. That lofty vision can be a massive motivator—until the numbers on the screen refuse to cooperate. To protect the ego, the trader might slip into denial, convincing himself that the dream is still within arm’s reach. Eventually, the market’s cold hard truth bites, and the trader is forced to admit: “Okay, maybe I’m not ready to replace my salary tomorrow.”  

That realization triggers **disappointment**. It’s the emotional equivalent of realizing the pizza you ordered is actually a cauliflower crust—still pizza, but not the cheesy nirvana you imagined. The trader feels inadequate, and those feelings are a distraction bigger than a meme thread during market hours.

### The “Ought” Pressure Cooker  

Now flip the script: suppose the trader tells himself, “I **ought** to hit a 20 % annual return because that’s what respectable traders do.” When the year ends with a modest 3 % gain (or a loss, even better for drama), **fear** swoops in. Fear is the sneaky cousin of panic that makes you press “buy” on a meme stock at 3 am because you’re terrified of looking like a loser. It pushes you into impulsive, ill‑timed trades—exactly the opposite of disciplined, profitable trading.

### Why “Just a Few Wins” Beats “Fortune 500”  

If you set a more modest, skill‑aligned target—say, “I’ll aim for a handful of winning trades each quarter”—you sidestep that crushing disappointment. You’ll actually *feel* satisfied when you hit those modest milestones, which in turn fuels confidence and keeps you in the game longer. In other words, the less you over‑promise, the more you over‑deliver (to yourself, at least).  

### Success Is a Staircase, Not a Magic Elevator  

Every trader who now enjoys a consistent profit line didn’t get there by buying a one‑click “overnight success” potion. They clocked in the hours, made mistakes, learned the quirks of their own psyche, and gradually built the toolbox needed to read markets without freaking out. Think of it like leveling up in a video game: you start in the tutorial, grind a few quests, and only later face the boss.  

If you keep setting the boss level as your day‑one target, you’ll be stuck in a loop of fear and disappointment, and those emotions will bleed into your trade tickets—resulting in slippage, over‑trading, or just flat‑out quitting.  

**Bottom line:** Keep your emotions in check by giving yourself **realistic expectations** that line up with where you actually are today. When you do, you’ll cultivate the cool‑headed, objective mindset that lets you trade *consistently* and, eventually, profitably.  

So, next time you feel the urge to declare, “I’m going to turn $5 k into $500 k by next month,” take a breath, grab a coffee, and rewrite that goal to something like, “I’ll improve my win‑rate by 2 % this quarter.” Your future, less‑anxious self will thank you—maybe even buy you a drink. Cheers!