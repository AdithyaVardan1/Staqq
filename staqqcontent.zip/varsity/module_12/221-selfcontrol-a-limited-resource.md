# 221. Self‑Control: A Limited Resource  

**Source:** https://zerodha.com/varsity/chapter/self-control-a-limited-resource/  

---  

Trading is a lot like trying to keep a toddler from eating the last cookie — you need discipline. A trading plan is about as useful as a map if you keep tossing it out the window the moment a “big move” screams at you. The disciplined trader follows the plan, reins in the emotions, and waits until the plan reaches its destination. Most of us can nod sagely and say, “Yeah, discipline is key,” but when the market throws a curveball, many aspiring traders end up flailing like a fish out of water.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/04/20061215-300x300.png)  

Drs. **Baumeister, Muraven, and Tice** (2000) famously compared self‑control to a **limited‑edition battery**. Use it to resist that extra slice of pizza, and you’ll find you’ve run out of juice when it comes time to stick to your trading plan. Don’t get me wrong—this isn’t a license to dump your diet and become a “free‑spirit trader.” It’s a reminder that humans have a finite stash of willpower, and that stash behaves a lot like a **muscle**.  

If you try to bench‑press a 200‑kg barbell on day one, you’ll be on the floor whining in a heap of sweat. The same happens with self‑control. Modern life is a relentless series of “please‑don’t‑eat‑that‑donut,” “don’t‑spend‑all‑your‑rent‑money,” “don’t‑forget‑Mom’s‑birthday,” and “keep‑the‑house‑clean‑or‑the‑spider‑will‑win” requests. Depending on how well‑trained your self‑control biceps are, you might find yourself dropping the dumbbell (or the plan) before you even get to the second rep. Something’s gotta give—either you lighten the load, or you risk a full‑blown breakdown.  

A 2005 study by **Megan Oaten and Ken Cheng** put this theory to the test. Participants were split into two groups: one did a task while under stress, the other did it in a calm environment. The stressed‑out crowd not only flunked the lab task but also complained they could barely keep their diet or tidy the house. In plain English: **stress robs you of self‑control**. If you try to trade while your personal life feels like a pressure cooker, you’ll probably abandon your plan faster than a cat jumps off a hot stove—especially if you’re a rookie who hasn’t yet built a sturdy discipline foundation.  

**Bottom line:** know your own self‑control bandwidth. Treat it like any other muscle: over‑train it, and you’ll pull a metaphorical hamstring. Instead of trying to lift the whole market‑weight at once, start light, master the form, and gradually add plates.  

## How to Pump Up Those Self‑Control Muscles  

1. **Trim the daily stressors** – If your inbox looks like a fireworks show, consider scaling back on trading until you’ve cleared some mental clutter. Think of it as a “self‑control diet”: fewer stress calories = more willpower for the market.  

2. **Do self‑control workouts** – Just like you wouldn’t expect to run a marathon after one jog, you won’t become a disciplined trader after a single successful trade. Practice makes perfect (or at least less terrible). One handy drill: close your eyes and **visualize** yourself executing a trade while a storm of “what‑ifs” whirls around you. Picture the market moving, your emotions flaring, and *you* staying as cool as a cucumber in a freezer. Replay that mental movie a few times a day; your brain will start treating it like a rehearsal.  

3. **Start small and stack up** – Begin with micro‑trades or even paper‑trading sessions when your personal life is relatively calm. As you see your self‑control “muscle” get a little more tone, you can gradually increase position size, complexity, or frequency.  

4. **Reward the effort, not just the outcome** – Celebrate a day you stuck to the plan even if the trade didn’t make you rich. That positive reinforcement is like adding protein shake after a workout—helps the muscle grow.  

## The Takeaway  

The winning trader is the one who can **stay disciplined** when the market tries to tempt them with shiny, volatile promises. Discipline isn’t some mystical super‑power you either have or don’t; it’s a skill that can be **trained, stretched, and bulked up**—provided you respect your own limits.  

Don’t set yourself up for a spectacular flop by assuming you can be 100 % disciplined 24/7. Think of discipline as a **gym routine for the brain**: the more you practice, the smoother the execution, the less you’ll look like a nervous toddler on a roller‑coaster. Build those self‑control muscles, and you’ll find yourself sliding through trades with the grace of a salsa dancer and the decisiveness of a seasoned chess grandmaster.  

So, next time you feel the urge to binge‑watch a series *instead* of reviewing your charts, remember: you’re just giving your willpower a rest day. Use the downtime wisely, hit the self‑control gym later, and you’ll be back in the trading arena—stronger, steadier, and maybe a little less likely to devour the whole pizza. 🍕💪  