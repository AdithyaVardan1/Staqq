# 311. Losing Your Money and Objectivity  

**Source:** https://zerodha.com/varsity/chapter/losing-your-money-and-objectivity/

---

Ever had a buddy spill his guts about a trade that turned into a dumpster fire? Maybe he **over‑leveraged** a tiny position, or he **forgot to set a stop‑loss** and kept whispering “just one more candle” to the empty air. Before you know it, denial slides in like a bad sitcom plot twist. Your pal, eyes wide and voice trembling, starts describing the elaborate cover‑up he’s staging to keep his spouse from discovering the missing cash.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/06/20041209-297x300.png)

You, on the other hand, are sipping a latte, cash untouched, and can see the whole charade for what it is: a **classic “I’m not losing money”** performance. You wonder why he can’t just **accept the loss, cut his losses, and move on** to the next trade. Both rookies and veteran traders get the sweats when the red numbers start piling up. Fear grabs the steering wheel, and logical thinking gets tossed out the window. At that point you’re not just **bleeding cash**—you’re also **losing your objectivity**.  

When you hit that emotional quicksand, it’s time to **claw your way out**, regain composure, and give your options a hard, honest stare.

---

## The “Disposition Effect” – Fancy Talk for “I’ll Hold On To My Loser”

Holding onto a losing trade is so common that economists gave it a snazzy name: the **disposition effect**. Humans are wired to **protect what we own**, and we’re equally wired to **pretend the problem doesn’t exist** when a trade goes south. Most of us entered the trading arena because we **want to win**, we **detest being wrong**, and we **hate watching our capital evaporate**.

But the **need to be right** is a trader’s sneakiest enemy. When you refuse to admit a mistake, you’re basically putting a **self‑inflicted roadblock** on your own success highway. Flexibility and open‑mindedness are the **real MVPs** of trading. If you can be flexible enough to own up to the fact that you’re human (and therefore fallible), you can **take losses in stride**, keep a clear head, and read the market with the precision of a hawk on a caffeine high.

---

## How to Put the “Control” Back in “Emotional Control”

Let’s be real: **controlling your emotions while money is at stake** is about as easy as teaching a cat to do your taxes. Yet, you’re not a helpless puppet. Here are some **battle‑tested tricks** to get your feelings back on a leash.

### 1. Flip Your Assumptions About Losses

New‑bies often chase **perfection** in a game where **losses are the norm**. After every bad trade they mutter, “How could I be so *dumb*?” That inner critic is about as helpful as a GPS that always says “recalculating” even when you’re on a straight road.  

**Reality check:** In volatile markets, you should **expect more losers than winners**. It’s perfectly fine (and actually common) to finish the month **profitable even if fewer than 50 % of your trades win**. Knowing that the odds are stacked against you keeps the panic button from going off every time a candle turns red.

### 2. Risk Only What You Can Afford to Lose

This is the **golden rule** that even your grandma’s cookie recipe would agree with. If you truly **know you can survive a loss**, your heart won’t start doing the Macarena when a trade dips. This doesn’t mean you should throw caution to the wind; it means you **size your positions** so a single blow‑out won’t leave you sleeping on the couch.

> **Pro tip:** Use a **fixed‑fraction** approach (e.g., never risk more than 2 % of your account on a single trade). That way, even a string of losers leaves you with enough capital to keep the lights on.

### 3. Never Underestimate Risk Management

Think of risk management as the **seatbelt** on a roller coaster. You might never need it, but when the ride goes sideways, you’ll thank yourself. Set **stop‑losses**, define **position sizes**, and keep a **trading journal** to remind yourself why you entered the trade in the first place.

### 4. When the Brain Smokes, Exit Early (Even If It’s Winning)

If the market’s turning your mind into a **shredded notebook**, consider **closing the trade** even when it’s still in profit. Thanks to today’s **penny‑cheap commissions**, popping out of a position costs almost nothing compared to the peace of mind you gain. Once the money is out of the equation, your brain stops screaming “don’t lose!” and starts listening to “what’s next?”.

---

## Bottom Line: Keep Your Cool, Keep Your Cash

Trading is **stress‑central**. The pressure to perform can hijack the very mindset you need to **stay calm, creative, and profitable**. But if you stay **optimistic**, **manage risk like a seasoned accountant**, and give yourself permission to **be human**, you’ll keep your objectivity intact.  

When you finally reach that Zen‑like state—where you’re neither a **crying wreck** nor a **greedy shark**—you’ll find the markets a little less hostile and your chances of **mastering them** a lot higher. So, next time a trade starts looking like a sinking ship, remember: **pull the plug, breathe, and maybe order a pizza**. Your future self (and your portfolio) will thank you.