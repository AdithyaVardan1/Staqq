# 330. Media News and the Behavior of the Masses  

**Source:** https://zerodha.com/varsity/chapter/media-news-and-the-behavior-of-the-masses/  

---  

Picture yourself as the bartender of a bustling financial lounge. Your patrons – the “masses” – are constantly shouting orders, spilling drinks, and reacting to every headline like it’s the last call for a free round. As a short‑term trader, your job is to stay one step ahead of that chaotic chorus and quietly scoop up the tips they leave behind. The sharper you are at predicting how the crowd will over‑react to a piece of news, the faster that money will slosh from their pockets into yours.  

In the world of behavioural finance, the masses have a reputation for **over‑reacting** to anything the media throws at them. To see how deep this rabbit hole goes, behavioural economist **Dr. John Nofsinger** ran a clever experiment that peeled back the curtain on media‑driven herd behaviour. Spoiler alert: it’s not as tidy as “good news = buying, bad news = selling.”  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/06/20060728-300x300.png)  

---  

## The Pride‑Regret Playbook  

One of the headline‑grabbing ideas in behavioural economics is that the crowd’s buying and selling is mostly driven by two emotional cravings:  

1. **Avoiding regret** – “I don’t want to look like a fool who bought high and sold low.”  
2. **Chasing pride** – “I want the bragging rights when my stock rockets and I cash out at the top.”  

These feelings are the financial equivalent of a kid who can’t resist the last slice of pizza even though he’s already stuffed. They often push investors into **irrational decisions**.  

- **Regret‑avoidance in action:** A trader clings to a losing position because the thought of admitting “I was wrong” feels like a punch to the ego. So the loss lives on the paper, like a bad haircut you keep hoping will grow out.  

- **Pride‑fuelled exits:** When the news is sunny and the price climbs, most people scramble to sell, lock in profits, and imagine themselves on a beach sipping a cocktail while shouting “I told you so!”  

But Dr. Nofsinger’s research suggests the story is a bit more tangled. The **type** of news—company‑specific vs. macro‑economic—matters more than the simple “good/bad” label.  

---  

## Good News, Bad News – Does It Matter Who’s the Star?  

Let’s set the stage with two scenarios:  

| **News Type** | **Typical Market Reaction** | **What the Masses Actually Do (per Nofsinger)** |
|---------------|----------------------------|----------------------------------------------|
| **Company‑specific good news** (e.g., a tech firm beats earnings) | Stock price jumps. Expect everyone to buy more. | **Masses tend to *sell*** – they want to lock in the glory and ride the pride wave. |
| **Broad economic good news** (e.g., GDP growth beats expectations) | Market‑wide rally. Expect a buying frenzy. | **Masses tend to *hold* or even buy more** – they’re comfortable staying in the game, basking in the collective optimism. |
| **Company‑specific bad news** (e.g., a product recall) | Price drops. Expect panic selling. | **Masses often sell** – but they also blame themselves (“I should've done my homework”). |
| **Broad economic bad news** (e.g., recession fears) | Market drags down. Expect a sell‑off. | **Masses are largely indifferent** – they feel there’s nothing personal to fault, so they just sit tight. |

In short: **the same “good” or “bad” headline can provoke opposite reactions depending on whether it’s about a single firm or the whole economy.**  

---  

## Why the Split? The Psychology of Self‑Blame vs. Systemic Guilt  

When a **company‑specific** story hits the wires, the crowd instantly asks themselves, “Did I pick the right horse?”  

- **Bad company news** → “I’m a loser; I should have done my due‑diligence.” The sting of self‑blame pushes them to **sell** quickly, hoping to cut the embarrassment.  
- **Good company news** → “I’m a genius! Look at this stock I own!” Pride spikes, and they scramble to **cash out** before the party ends.  

Contrast that with **economy‑wide** news. If the whole market is wobbling, the blame game collapses because *everyone* is in the same boat. You can’t say, “I should’ve avoided this sector,” when the entire ocean is choppy. The only logical self‑reproach would be, “Maybe I should have stayed out of the market altogether.” That’s a much deeper existential crisis, so most investors simply **do nothing**—they wait for the tide to turn.  

Think of it like this: you can blame yourself for a bad pizza topping you chose, but you can’t really blame yourself for a city‑wide power outage. The former makes you scramble for the menu; the latter makes you stare at the darkness and wait for the lights back on.  

---  

## The Bottom Line for the Savvy Trader  

Emotions are the **secret sauce** that makes the masses’ decisions so deliciously predictable—if you know how to read the recipe.  

1. **Don’t let pride or regret dictate your own moves.** Your job is to stay as cool as a cucumber in a freezer, even when the crowd is doing the cha‑cha‑cha around you.  
2. **Watch the news lens, not just the headline.** Is the story about a single company or the whole economy? That distinction often tells you whether the crowd will **sell, hold, or buy**.  
3. **Let the herd over‑react.** When the masses panic‑sell a stock because a company missed earnings, you might consider stepping in and buying the dip—provided your fundamentals still look sound.  
4. **Profit from the emotional lag.** The crowd usually reacts a few minutes (or hours) after the news hits. That lag is your playground.  

So, next time a headline blares “Tech Giant Beats Forecast!” remember: the crowd will likely be sprinting to the exit, while a savvy trader can stay seated, sip a cheap beer, and wait for the price to keep climbing. And when the economy announces a slowdown, expect the masses to stare blankly at the screen, hands in pockets, while you quietly tighten your position—because you know they’ll stay put until the next big panic hits.  

**Bottom line:** Let the masses wear their emotions on their sleeves; you keep yours tucked neatly into your pocket and let the market’s drama fuel your profit. Cheers! 🍻  