# 256. Maintaining Discipline: When Past Choices Influence Future Decisions  

**Source:** <https://zerodha.com/varsity/chapter/maintaining-discipline-when-past-choices-influence-future-decisions/>

---

Traders and investors have a *hard‑time* “letting their profits run.”  
Picture this: you buy a stock, it starts climbing, and the little voice in your head screams, “Sell now! Lock that cash before it disappears!” The urge to bail out early is as strong as the craving for the last slice of pizza at a party.  

But here’s the cold, hard truth: not every trade ends in a champagne‑pop celebration. Some will sting, some will sizzle, and a few will make you want to shout “I’m a genius!” from the rooftop. When you finally *do* land a winning trade, you need to **milk that profit** for as long as the market lets you. In plain English: you must earn **more on your winners than you lose on your losers**. If you keep cashing out the moment you see a green number, you’ll never build the edge needed for long‑term success.

> **Bottom line:** Early exits = short‑term comfort, long‑term regret.

---

## The Self‑Control Tug‑of‑War

Waiting for your price target is a test of willpower that would make a monk jealous. You have to stare at that rising chart and fight the impulse to slam the “Sell” button like it’s a panic button on an elevator.  

Enter Professor Kris Kirby from Williams College, who decided to give this brain‑muscle a scientific makeover. In a 2001 paper with Guastello (Kirby & Guastello, 2001), he proposed a **thinking‑strategy** that basically tells your brain, “Hey, these decisions are linked—what you do now shapes what you’ll do later.”  

In other words, the market isn’t a series of isolated snap‑decisions; it’s a **choose‑your‑own‑adventure novel** where the early chapters set the tone for the whole story.

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/04/20060524-300x300.png)

---

## “I’ll Sell Early This Time, Then I’ll Let It Ride Later” – A Bad Habit in Disguise

Let’s get honest: have you ever thought, *“I’ll cut my losses early on this trade, but next time I’ll let my profits run to the moon?”* It sounds reasonable, right? Like promising your future self you’ll start a diet after this last slice of cake.  

The problem is that **behavioural economics calls that a “pre‑commitment trap.”** The brain loves consistency. If you start a pattern of early exits, you’ll start *expecting* early exits. It’s a slippery slope that quickly turns into a “sell‑everything‑at‑the‑first‑sign‑of‑profit” habit.  

Kirby’s experiment turned this abstract idea into a pizza‑party analogy that even a hungry student could grasp.

### The Pizza Experiment

- **Scenario:** Participants were asked to choose between **one slice of pizza now** (instant gratification) or **two slices in a week** (delayed, bigger reward).  
- **Link to trading:** One slice now = taking a small profit early. Two slices later = letting the trade run and harvesting a bigger gain.  

Some volunteers were instructed to **think of each decision as part of a chain**. By *delaying* the tiny slice on the first few rounds, they built a mental habit that made it easier to delay again later. In short, “practice restraint early, reap restraint later.”

### What Happened?

The results were crystal clear: **participants who were reminded of the “linked‑choices” mindset showed more self‑control in later rounds.** In trading terms, if you train yourself to *hold* on the first few green candles, you’re more likely to hold on when the real money’s on the line.

---

## How to Translate This Into Your Trading Routine

1. **Declare the Chain Out Loud**  
   Before you even open a position, say something like, “This trade is the first link in a chain of disciplined decisions.” Saying it out loud (or to your cat) tricks the brain into treating the upcoming choices as connected.

2. **Set a *Real* Profit Target, Not a “Feel‑Good” Target**  
   Write down the exact price you’ll exit at, and *stick* to it. If the market passes it, you’re not “missing out”— you’re *following the plan* you committed to earlier.

3. **Use a “Delay‑Reward” Cue**  
   Put a sticky note on your monitor that reads, “Two slices later → Bigger reward!” Every time you feel the itch to sell early, glance at the note and remember the pizza analogy.

4. **Track Your “Chain” Performance**  
   Keep a simple spreadsheet:  
   | Trade # | Planned Exit | Actual Exit | Was it an early sell? | Discipline Score (1‑5) |  
   |--------|--------------|------------|----------------------|-----------------------|  
   Fill it in after each trade. Seeing a pattern of early exits will make the cost of the habit painfully obvious.

5. **Reward Yourself for Discipline (Not for Profit)**  
   If you successfully ride a trade to its target, give yourself a non‑financial treat: a fancy coffee, a new episode of that series you binge‑watch, or an extra slice of pizza *after* the week is over (yes, you can still have the two slices, just later).

---

## The Big Picture: Why “Sell Early, Promise Later” Doesn’t Work

Your brain is *not* a spreadsheet that can separate “today’s decision” from “tomorrow’s outcome.” Neuroscience tells us that **the prefrontal cortex (the part that handles self‑control) gets a workout when you practice restraint early**. Skipping that workout means the muscle stays weak, and future temptations feel even more like a “must‑sell” reflex.

If you keep giving in to the “sell now” siren, you’ll set a **negative precedent** that erodes your ability to hold when it truly matters. Over months and years, those tiny, premature exits compound into a **significant profit bleed**—the same way a leaky faucet can flood a basement if you never fix the first drip.

---

## TL;DR (Because We’re All in a Hurry)

- **Profits need to run**; cutting them short is like eating the first slice of pizza and never getting the rest.  
- **Kirby’s study** shows that treating decisions as linked helps you stay disciplined later.  
- **Don’t fall into the “sell now, be disciplined later” trap**; the brain doesn’t compartmentalize that way.  
- **Create a habit chain**: decide to wait now, remind yourself it builds future patience, and actually *do* it.  
- **Track, reward, repeat**—your future self (and your portfolio) will thank you with fatter gains and fewer “what‑ifs.”

So the next time your heart starts pounding at a green candle, pause, breathe, and think: *“Two slices later, buddy. Two slices later.”* Your future self will be sipping a margarita on a profit‑rich beach, not staring at a chart that says “Sold early – profit lost.” Cheers to disciplined trading! 🍕📈