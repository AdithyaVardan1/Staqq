# 346. Mood Repair: How To Do It and When It Works  

**Source:** <httpshttps://zerodha.com/varsity/chapter/mood-repair-how-to-do-it-and-when-it-works/>

---

If you want to be a winning trader, you have to wear optimism like a favorite hoodie—comfortable, snug, and impossible to take off once you’ve slipped it on. Trading isn’t a stroll through a park; it’s more like a marathon where the finish line keeps moving while you’re juggling flaming torches. You’ll churn out trade after trade, and many of those will be losers before the big‑ticket winners finally roll in. The golden rule? Focus on the **big picture**—the net profit across a swath of trades, not the single‑trade heartbreak that feels like a bad first date.

That sounds simple enough, right? Except that on some days the market decides to treat you like a toddler throwing a tantrum, and no matter how hard you try, the “win” button stays stubbornly out of reach. Disappointment creeps in, pessimism knocks on the door, and before you know it you’re replaying every losing trade like a broken record. That’s when you need to **repair your mood** and give your brain a fresh cocktail of positivity. Psychologists Jutta Joormann and Matthias Siemer have done the heavy lifting for us, and their research points to a handful of surprisingly practical (and sometimes downright goofy) mood‑repair tricks.

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/06/20050708-300x300.png)

### The Mood‑Memory Tango  

Joormann and Siemer set out to understand how people bounce back from a gloomy mindset. Turns out, our moods and memories are like two drunk friends at a bar—when one’s feeling down, it drags the other into the same slump. If you’re sulking after a string of losing trades, your brain is more likely to pull up the mental file “All My Bad Trades” than the one titled “That One Time I Turned $500 into $5,000.” It’s a wiring quirk: **bad moods cue bad‑trade memories**, while good moods cue the glory moments.

So, when you’re in a sour mood, you’re basically replaying a highlight reel of your worst trades, and that’s a recipe for more anxiety, poorer decision‑making, and possibly a few more losses. The good news? You can flip the script—if you can get your brain to surf the “good‑trade” wave instead.

### Classic (and Not‑So‑Classic) Mood‑Repair Hacks  

1. **Shift the Spotlight** – The simplest idea is to *think about something else*. Unfortunately, that’s about as effective as trying to ignore a mosquito buzzing right next to your ear—it just ends up being more irritating.  

2. **Acknowledge the Bad Thought** – Dr. Ari Kiev, a member of the Innerworth advisory board, suggests giving that sour thought a brief cameo. Say to yourself, “Yep, I just had a crappy trade. No biggie. On to the next one.” By **recognizing** the negative, you let it run its course instead of wrestling it into a mental corner. It’s like inviting the annoying cousin to the party, then politely showing them the door after they’ve said their piece.  

3. **List Your Wins** – Another Innerworth favorite: keep a running list of your winning trades. When the gloom hits, flip through that list like a greatest‑hits album. Seeing concrete proof that you *can* win (and have) gives your confidence a quick caffeine boost.  

All of these tricks can be useful, but they’re not magic bullets—sometimes they work, sometimes they flop like a bad joke at a wedding.

### What the Lab Says: Distraction vs. Pleasant‑Recall  

In their experiment, Joormann and Siemer put participants into a mildly depressed mood (think “I just watched my favorite team lose in the last minute” vibe). Then they handed them one of two assignments:

| **Task** | **What participants did** |
|----------|---------------------------|
| **Distraction** | Imagine strolling through a shopping mall, window‑shopping, mentally trying to *ignore* the bad mood. |
| **Pleasant‑Recall** | Write down happy events that happened to them in the past (like “Won a free coffee” or “Got a promotion”). |

When participants were **not** particularly down, both strategies gave a modest mood lift—kind of like a light‑beer after a long day. But when the participants were **deeply distressed** (the emotional equivalent of a market crash), the pleasant‑recall method barely moved the needle. Instead, the **distraction** task—thinking about an engaging, enjoyable activity—proved far more effective. In plain English: if you’re really moping, it helps to **imagine** you’re doing something fun *right now* (maybe binge‑watching a sitcom or planning a beach vacation) rather than trying to dredge up past good times.

The takeaway? The **earlier** you catch a bad mood, the more tools you have at your disposal. In the early stages, you can:

* **Recall past wins** (your “highlight reel”).  
* **Talk yourself up** (“Everything will smooth out; I’ve survived worse.”).  

But once the gloom has taken hold, you might need to **shift your mental focus** entirely—think of a pleasant activity you *could* be doing instead of the one you’re stuck on.

### Why Mood‑Monitoring Matters for Traders  

When you’re down in the dumps, your brain starts throwing out trading errors like confetti at a parade. A sour mood can make you:

* **Enter trades too early** (because you’re desperate for a win).  
* **Exit too late** (because you’re hoping the market will “fix itself”).  
* **Misread signals** (your eyes glaze over like a spreadsheet after three hours of candles).  

Staying **upbeat yet calm** is the sweet spot. It lets you keep your eyes on the charts, your fingers on the keyboard, and your brain from spiralling into “what‑if” nightmares. Over time, that steady, positive headspace translates into **more disciplined execution**, **fewer emotional blunders**, and—yes—**lasting profitability**.

---

#### Quick‑Reference Mood‑Repair Cheat Sheet  

| **When you’re slightly down** | **When you’re deep‑down** |
|------------------------------|---------------------------|
| • List recent winning trades. <br>• Recall a few happy memories. <br>• Give yourself a pep talk. | • Imagine yourself doing a fun activity (shopping, beach, pizza night). <br>• Acknowledge the bad trade, then let it go. <br>• Distract with a vivid mental scene, not just “think of something else.” |
| *Goal:* Reinforce the “I’ve won before” narrative. | *Goal:* Pull your brain out of the “doom loop” and into a neutral/positive channel. |

---

**Bottom line:** Mood isn’t just a feeling; it’s the *filter* through which you interpret every tick, every candle, every profit‑and‑loss statement. Keep that filter clean, or at least tinted with a little optimism, and you’ll be far more likely to spot the next big win instead of stumbling over the next loss. So the next time the market throws you a curveball, remember: **repair the mood, then swing back hard**—just like a pro baseball player who dusts off his gloves, cracks a smile, and steps back up to the plate. 🎯📈