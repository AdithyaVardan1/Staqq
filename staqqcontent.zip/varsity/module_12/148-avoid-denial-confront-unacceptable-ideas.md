# 148. Avoid Denial: Confront Unacceptable Ideas  

**Source:** https://zerodha.com/varsity/chapter/avoid-denial-confront-unacceptable-ideas/  

---  

Let’s face it: most of us deal with uncomfortable thoughts the way we deal with a bad haircut—by hoping nobody notices and pretending it never happened. In the trading world this “pretend‑it‑doesn’t‑exist” reflex is especially tempting because the market can be a brutal truth‑teller. But here’s the kicker: denial is a sneaky energy‑vampire. Trading already burns through every ounce of your limited psychological bandwidth, so squandering any of it on mental gymnastics is a recipe for a nervous breakdown (and a very empty brokerage account). Whether you’re consciously rolling your eyes at a nasty idea or subconsciously pushing it into the dark corners of your brain, you’re stealing precious focus that could have been spent spotting the next breakout.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/03/20061026-300x300.png)  

## The Easy Way Out: Admit It, Then Move On  

The fastest (and cheapest) way to free up that mental cash is to simply **own** every idea that makes you squirm. For some folks, a quick mental “Yep, that’s probably true, let’s move on” does the trick—like admitting you’ve got two left feet before the first dance. Others need a little more structure: grab a notebook, write the uncomfortable thought in big, bold letters, list concrete examples that prove it could be legit, and then jot down a one‑sentence plan for how you’ll keep trucking forward despite the truth.  

The crucial point is: you can’t start the detox until you’ve identified the most “unacceptable” ideas lurking in your head. Below are a handful of classic examples that many traders (including the one who once thought “buy high, sell higher”) wrestle with.  

### 1️⃣ “Maybe I’m not that skilled; I’ve just been riding a lucky wave.”  

Picture a rookie surfer who catches a perfect swell on his first day. He’ll swear he’s a natural until a gnarly set knocks him flat. The same thing happens in trading: early wins can be pure luck, not skill. If you’ve ever felt that a string of profitable trades might just be the market being nice to you, give that thought a nod. Pretending you’re a wizard because you’ve only ever won a few duels will drain you faster than a leaky faucet.  

Why waste brain‑power denying a skill gap when you could spend it sharpening your edge? Accept the possibility that you’re still learning, then double down on **experience**: paper‑trade, review your charts, dissect every loss, and build a toolbox of strategies. The more you practice, the less “luck” will matter, and the more *skill* will shine through.  

### 2️⃣ “I can grind for hours, yet I might still flunk.”  

This one is the trading equivalent of studying for a marathon and still tripping at the finish line. Many eager beavers pour endless hours into webinars, books, and back‑testing, only to discover that effort alone doesn’t guarantee success. It’s a bitter pill: hard work ≠ guaranteed profit.  

If you’re wrestling with this, acknowledge the harsh reality: **effort ≠ outcome**. Then ask yourself what you can tweak—maybe it’s your risk‑management, maybe your entry criteria, maybe your sleep schedule (yes, you need more than caffeine). By confronting the fact that hard work can still end in a loss, you free up mental bandwidth to experiment, iterate, and actually *improve* your odds.  

### 3️⃣ “I was a hot‑shot trader once, but the market’s changed; I can’t keep my rep up.”  

Ah, the ego‑trip. Nothing feels sweeter than bragging about a 30% monthly run to your cousin who still thinks “Bitcoin” is a brand of cereal. But reputation is a fickle friend—today’s hero can be tomorrow’s cautionary tale. The moment you start trading to *prove* something to others, you’re feeding the same denial monster that steals focus.  

Admit that the need for applause is a distraction. The market doesn’t care whether you’re famous; it only cares about your next entry price. Humble traders tend to keep more of the pie because they’re not constantly worried about looking cool in the next Instagram post. So, drop the “I must stay on top of the leaderboard” narrative, and instead focus on *consistent* performance. The only reputation that matters is the one you give yourself when you close a trade without sweating.  

### 4️⃣ “Trading isn’t a legit job.”  

This is the philosophical heavyweight of the bunch. Some traders silence the inner critic by chanting, “I’m providing liquidity, stabilising prices, doing a public service!” Others need a deeper sense of purpose—maybe it’s funding your kid’s college, building a safety net for Mom, or donating a slice of your gains to a cause you love.  

Whatever your justification, the key is **not to deny** that this doubt exists. Pretending the question never surfaces is like putting a band‑aid on a broken dam. Recognise the existential wobble, then stitch it with a personal “why.” When the market throws a curveball, you’ll have a solid, non‑flimsy reason to keep your head in the game.  

## The Sneaky Power of Unacknowledged Beliefs  

Unacceptable ideas are like that stray cat that sneaks into your kitchen at night—you might not see it, but it’s there, ready to knock over a glass of milk (or in our case, your concentration). If you keep pushing them to the back of your mind, they’ll pop up the moment you’re vulnerable (say, after a string of losses) and hijack your decision‑making.  

By **explicitly naming** these thoughts, you rob them of their secret‑weapon status. Once you’ve admitted, “Hey, maybe I’m lucky, maybe I’m not good enough, maybe I’m just chasing fame,” the thoughts lose their mystique and become manageable data points. The result? Your mental thermostat cools down, you reclaim the limited psychological fuel you have, and you can channel it straight into spotting those high‑probability setups instead of wrestling with self‑doubt.  

---  

**Bottom line:** Denial is the silent thief that robs traders of focus, energy, and, ultimately, profits. Shine a flashlight on every uncomfortable idea, write it down, accept its possible truth, and then give it a polite “thanks, but I’ve got work to do.” Your brain will thank you, your trades will thank you, and the market will—well, the market will stay the same, but you’ll be in a better position to ride its waves. Cheers to confronting the ugly thoughts and turning them into fuel for the next big win! 🍻  