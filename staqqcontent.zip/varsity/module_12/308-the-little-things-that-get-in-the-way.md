# 308. The Little Things That Get In The Way  

**Source:** https://zerodha.com/varsity/chapter/thinking-of-the-big-picture/

---

New‑bie traders love to blame their own “inner saboteur” when their trading plan goes poof. They spin wild stories like, “I’m secretly unworthy of winning” or “there’s a hidden demon inside me ruining everything.” The truth? Most of them simply ignore the tiny gremlins that trip them up every day.

What they **don’t** realize is how much **mental horsepower** and **physical stamina** trading actually devours. You can’t expect to stick to a plan if you’re running on fumes, and you can’t expect to become a plan‑following robot without putting in the grunt work. Even if your goals are modest, you’ll sabotage yourself by demanding unrealistic perfection. For the majority of rookie traders, the culprit isn’t some subconscious vendetta; it’s the **little things** that quietly pile up like spilled peanuts on a couch.

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/06/20041214-292x300.png)

### Look under the rug – what’s actually tripping you up?  

Maybe you skimped on shut‑eye, or you’re trading on an empty stomach. Don’t take my word for it—run a little experiment. For a full week, add **an extra hour of sleep** each night (yes, that means actually going to bed earlier, not just scrolling TikTok in the dark). Or skip a chunk of the market session for a few days and see how your focus sharpens. More rest translates into sharper alertness, steadier nerves, and a brain that can actually follow a plan instead of day‑dreaming about pizza.

If you’re a night‑owl, consider nudging your circadian clock a bit earlier. Your body loves routine, so give it a consistent bedtime and wake‑up time. It may feel like a tiny lifestyle overhaul, but the payoff—clearer decision‑making and fewer “I’m too tired to think” moments—can be massive. Get the Z’s you need, no matter how many coffee cups it takes to get there.

### Stress: the sneaky energy thief  

Trading is a pressure cooker, and coping with that pressure gobbles up **psychological energy**—a resource most of us overestimate. Getting angry, frustrated, or even mildly annoyed is like letting a leaky faucet drain that energy bucket. Never underestimate how much a bad mood can drain your “mental battery.”

When stress has drained you, you must **recharge** before you can concentrate again. If the market moves against you while you’re wiped out, the urge to bail out and binge‑watch Netflix is natural. But that fatigue often hides below the surface; you might *think* you’re fine, while your brain is still running on low‑power mode. A proper recharge—whether it’s a nap, a walk, or a solid night’s sleep—will restore the focus needed to stick to the plan.

### Practice makes (almost) perfect  

Think mastering a trading plan is a one‑time thing? Think again. Just like perfecting a tennis serve, you have to **train your concentration muscle**. You need to practice staying present, watching your emotions like a hawk, and re‑centering yourself after every market swing. It’s not a walk in the park because, hey, real money and a sprinkle of ego are at stake.

So the next time you catch yourself flinging the plan out the window, don’t immediately blame a hidden self‑sabotage monster. Often the fix is as simple as **lowering stress**, **catching enough shut‑eye**, and **giving yourself the practice time** to turn plan‑following into second nature.  

In short: tame the tiny annoyances, fuel up with sleep, keep stress in check, and rehearse your discipline like you’d rehearse a karaoke set. Your future self (and your trading account) will thank you.