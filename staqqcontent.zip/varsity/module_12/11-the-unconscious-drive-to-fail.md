# 11. The Unconscious Drive to Fail  

**Source:** https://zerodha.com/varsity/chapter/the-unconscious-drive-to-fail/  

---  

Ask any trader why they got into the markets and you’ll hear a chorus of “I’m here to make huge profits.” Sure, the lure of turning a modest bankroll into a fat‑stack of cash is the main advertisement on every broker’s landing page. Yet the statistic that makes most analysts wince is that **over 90 % of retail traders lose money** and a sizeable chunk “blows out” their accounts faster than a fireworks factory on the Fourth of July.  

So why do so many bright‑eyed newbies end up flat‑lining their capital? The textbook answer is simple: they lack the basics. No risk‑management plan? Check. No enough cash cushion to survive a few losing streaks? Check. No solid, back‑tested strategy? Double‑check. No reliable broker or proper education? You bet. Add a dash of “I have no clue how markets actually work” and you’ve got a recipe for disaster that even a reality‑TV chef would reject.

But let’s not pretend we have to dive into Jung’s cellar to unearth the *real* cause. Some traders swear there’s a sneaky, subconscious gremlin that loves to sabotage their trades. It’s the kind of inner voice that whispers, “You’re better off buying a lottery ticket than risking your hard‑earned savings on a chart pattern.” Seasoned pros love to chew on this idea because—surprise!—even the most successful traders sometimes end up with their accounts looking like a bad haircut: uneven, painful, and impossible to fix. A few have even gone completely dark, never to be seen again in the market. Is there a hidden self‑sabotage switch? Grab a drink; we’ll explore it for fun **or** for serious self‑inspection, depending on how much you enjoy psycho‑analysis over profit‑analysis.

![Image](https://zerodha.com/varsity/wp-content/uploads/2019/11/20041007.png)

### Freud’s “Wrecked by Success”  

Back in the day, Sigmund Freud penned an essay titled *“Those Wrecked by Success.”* He argued that some people feel a guilty, queasy sensation the moment they achieve a lifelong dream—think of it as the emotional equivalent of a bad case of the “I’m not worthy” flu. In Freud’s view, success can be so unsettling that the unconscious mind starts pulling the rug out from under you, essentially *punishing* you for doing well.

Fast‑forward to modern psychology, and most researchers shrug and say, “Nah, people don’t *want* to fail, even subconsciously.” Instead, they blame the harsh reality that trading is a **hard** skill: you need capital, a robust strategy, emotional discipline, and a sprinkle of good luck. The majority of repeated losses are attributed to missing one or more of those ingredients, not to a secret desire to watch your own portfolio implode.

### The “Success‑Is‑Failure” Twist  

Enter Roy Shaffer, a psychoanalyst who likes to stir the pot a bit more. Shaffer suggests that for some folks, **success itself feels like a kind of failure**. Picture a kid who grew up watching his dad flunk every job, and suddenly the kid gets a promotion. The unconscious mind might think, “Whoa, I’m turning into the *opposite* of Dad. That can’t be good!” In a case study, a young man actively avoided climbing the corporate ladder because he feared outshining his perpetually failing father.

Veteran traders echo this sentiment. Some rookies aren’t just chasing dollar signs; they’re secretly trying to prove something to Mom, Dad, or that obnoxious cousin who always says, “I told you you’d never make it.” The problem? When you’re trading to *show* someone else you’re a winner, you’re playing with stakes that are astronomically higher than when you trade for *yourself*. The pressure cooker effect turns rational decision‑making into a nervous tic, and before you know it, you’ve turned a $10,000 account into a $100‑ish memory.

### Don’t Let Your Inner Critic Be the Broker  

If you recognize any of these narratives in your own life, pause the chart‑watching and do a quick mental inventory:

1. **Am I trading because I genuinely love the game, or because I want to brag?**  
2. **Do I have an internal voice that says I don’t deserve success?**  
3. **Is my family’s opinion the fuel that’s making my engine over‑rev?**  

The answer to any of those should be a decisive “Nope, that’s not why I’m here.” If you catch yourself slipping into “prove‑them‑wrong” mode, you’re basically putting your entire bankroll on a high‑stakes dare. The market will punish that faster than a hangover after a three‑day festival.

### Bottom Line: Keep the Psyche in Check  

We’ve hammered this point before: unconscious motivations are **not** the villain for every trader. For many, it’s simply a lack of preparation. But if you suspect a deeper, “I’m doomed to fail because I’m secretly allergic to success” vibe, consider bringing in a trading coach, therapist, or at the very least a sober friend who can call out your drama before you post‑mortem your trades.

**Action checklist:**  

- **Identify** any hidden agenda (write it down, no shame).  
- **Talk it out** with a neutral third party.  
- **Trade for yourself**—profit for your own pocket, not for the next family dinner brag.  

When you strip away the subconscious baggage, you’ll find trading becomes less about emotional gymnastics and more about disciplined execution. And hey, if you can laugh at your own quirks while you’re at it, you’ll probably enjoy the ride a lot more. Cheers to trading freely, effortlessly, and (hopefully) profitably!