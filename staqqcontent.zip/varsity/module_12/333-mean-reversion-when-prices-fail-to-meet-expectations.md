# 333. Mean Reversion: When Prices Fail to Meet Expectations  

**Source:** https://zerodha.com/varsity/chapter/mean-reversion-when-prices-fail-to-meet-expectations/  

---  

### A (Very) Short History Lesson (Because Everybody Loves a Good Anecdote)

Back in the Victorian era, Sir Francis Galton decided to play match‑maker with numbers and genetics. He asked the age‑old question: *Do tall dads give birth to tall sons?* His intuition was spot‑on—genes are the ultimate “family heirloom.” But when he actually crunched the data, the plot thickened like a bad romance novel. Tall fathers tended to have **shorter** sons, and short fathers produced **taller** offspring. The relationship was far from perfect; it was more like “some‑what‑related” than “identical twins.”  

Galton, being the clever (but occasionally over‑confident) Victorian he was, leapt to a grand‑scale conclusion: over generations, the human race would “regress toward mediocrity.” In other words, the giants would shrink and the hobbits would grow—until everyone ended up at the statistical sweet spot of average height.  

What Galton *forgot* was that mothers also contribute DNA, and that mating isn’t a controlled laboratory experiment but a chaotic, love‑driven lottery. A tall‑gene‑carrying chap might end up with a petite partner, and the offspring’s height becomes a roll of the genetic dice. This oversight birthed the term **“regression toward the mean,”** a phrase that’s as misleading as a diet soda promising zero calories. In reality, the phrase is a pure statistical description of how actual data points scatter around a fitted straight line—how close the line’s **predicted** values match the **observed** values used to draw the line.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/06/20060713-300x300.png)  

### So, What Does This Have to Do with Your Portfolio?  

Enter the world of trading, where everyone thinks they’re a modern‑day Galton, only with charts instead of family trees. **Mean reversion** is the buzzword that pops up whenever a stock shoots up like a rocket or crashes like a sack of potatoes. The idea is simple: when a price gets *extremely* high (or low), it will eventually swing back toward its “average” or “typical” level. It’s a blend of cold‑hard statistics and the warm‑fuzzy psychology of market participants—think of it as the market’s version of a “hangover cure” after a wild night out.  

But let’s not get too cozy. Mean reversion can also be framed as a **“failure to meet expectations.”** In statistics, you draw a regression line and treat it like a fortune‑teller: it predicts future outcomes based on past patterns. Imagine you run a call‑center and use the number of cold calls you make each week to predict total sales. Because not every call converts, the line will never be perfect—your sales forecast will *under‑ or over‑estimate* the reality.  

If you try to use that same line to predict a stock’s next‑day price, you’ll quickly discover it’s about as reliable as a weather forecast in the Sahara. Prices don’t march hand‑in‑hand from one tick to the next; they jiggle, wobble, and sometimes do a full‑blown cartwheel. For mean reversion to matter, those price moves can’t be *consistently* predictable—otherwise, we’d all be swimming in yachts.  

### The Three “We‑Hope‑They‑Hold‑True” Assumptions  

When you apply “regression toward the mean” to market prices, you’re essentially making three bold assumptions:  

1. **The “true” intrinsic value of the stock is identical at time A and time B.**  
2. **The quoted market price at either moment is a noisy, imperfect reflection of that true value.**  
3. **All of the discrepancy between the two quoted prices is pure, random noise—no systematic driver.**  

Let’s unpack these one by one, with a splash of sarcasm for flavor.  

#### 1️⃣ The Intrinsic Value Is Frozen in Time  

In an ideal world, a company’s fundamentals—cash flow, earnings power, competitive moat—stay exactly the same forever. In reality, firms launch new products, lose key customers, or get hit by a cyber‑attack. Still, on very short horizons (think intraday or a few days), the *core* value often doesn’t shift dramatically. So for a quick‑trade scenario, assuming a static “true” value isn’t a terrible stretch.  

#### 2️⃣ Market Price = Noisy Approximation  

Most of the time, the market price is a reflection of collective sentiment: optimism, fear, gossip, and occasional meme‑stock mania. It’s like the group chat of Wall Street—everyone’s shouting, and the final number is a noisy mash‑up of all those voices. On short time‑frames, that noise can dominate, making the price a *poor* proxy for the underlying value. This is where the second assumption often holds water.  

#### 3️⃣ All Discrepancies Are Random  

Here’s where the rubber meets the road (or the chart meets the candle). If every price swing were just random chatter, we’d see mean reversion everywhere, all the time. But markets are also driven by *real* information: earnings beats, regulatory changes, macro‑economic data releases, and good old‑fashioned supply‑and‑demand shocks. When a genuine catalyst moves the needle, the price change isn’t random—it’s *informational*. In those cases, the mean‑reversion playbook falls apart.  

### When Does Mean Reversion Actually Show Up?  

- **Random Noise‑Driven Moves:** Imagine a stock that spikes because a rogue analyst tweets “Buy XYZ!” without any real basis. The hype is a short‑lived, random mood swing. Once the crowd calms down, the price tends to drift back toward its pre‑tweet level.  
- **Psychological Over‑Excitement:** At the end of a bull run, investors can get “elated” (read: hyper‑optimistic) and push prices beyond what fundamentals justify. When the euphoria wanes—perhaps after a coffee‑break or a news cycle—prices often settle back toward a more reasonable mean.  

In both scenarios, the driver is *psychology* rather than *fundamentals*, so the third assumption (pure randomness) is close enough for the mean‑reversion hypothesis to have legs.  

### When to Throw the Mean‑Reversion Playbook Out the Window  

- **Fundamental Shifts:** A biotech firm lands a blockbuster drug, or a retailer files for bankruptcy. Those are *systemic* changes, not random noise. The new “true” value has moved, so expecting the price to snap back to the old mean is like waiting for a dead phone to ring.  
- **Structural Market Changes:** Think interest‑rate hikes, regulatory overhauls, or a shift from a growth‑to‑value regime. Those are macro forces that rewrite the “average” level itself.  

In such cases, clinging to a mean‑reversion expectation is like insisting you’ll still be sober at 2 am after a night of “just one drink.” Spoiler: you won’t.  

### Bottom Line: Mean Reversion Is a Useful Lens, Not a Crystal Ball  

Mean reversion is a *mathematical* observation, not a *guaranteed* law of nature. It works best when price deviations are mostly the product of human error, herd mentality, or fleeting information—essentially, when the market is being a little *noisy*. Because traders are human, and humans are delightfully imperfect, those noisy moments happen often enough to make mean‑reversion strategies viable—*if* you respect the underlying assumptions and stay vigilant for genuine fundamental shifts.  

So the next time you see a stock rocket to the moon on a rumor, ask yourself: “Is this just a temporary mood swing, or have the fundamentals actually changed?” If it’s the former, you might be looking at a classic mean‑reversion setup—just remember to set your stop‑loss, because even random noise can sometimes keep dancing for a while before it finally settles down.  

In short, mean reversion is the market’s version of “what goes up must come down… unless it’s a rocket ship, then we need physics.” Treat it as a *probabilistic* tool, sprinkle in some good risk management, and you’ll be laughing (and possibly profiting) at the market’s inevitable wobble back to reality. Cheers!  