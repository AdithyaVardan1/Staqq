# 117. Insufficient Justification  

**Source:** https://zerodha.com/varsity/chapter/insufficient-justification/  

---  

Ever notice how you’re the first one to **sell a winner** and the last one to **dump a loser**? It’s like you have a Pavlovian reflex for cash‑out‑early and a stubbornness‑for‑loss‑holding that would make a mule jealous. The longer a losing position sits in your account, the louder the inner voice says, *“I *must* have a good reason for this!”* That inner voice is the **insufficient‑justification effect** in disguise, and it’s more persuasive than a late‑night infomercial promising you’ll “lose weight while you eat pizza.”  

---

## The Classic Psychology Experiment (and why you should care)

Imagine a group of volunteers being handed a **one‑hour “thrill‑ride” of pure boredom** – basically, looking at pictures and deciding whether they’re “interesting” or not. Spoiler alert: everyone agrees the task is as exciting as watching paint dry.  

After the snooze‑fest, the researchers tell the participants to **recruit new volunteers** for the same mind‑numbing job. They have to give a *hard sell* – i.e., convince a stranger that the task is actually “fun and fascinating.”  

![](https://zerodha.com/varsity/wp-content/uploads/2020/02/20070313-300x300.png)  

Now, here’s where the money comes in (because nothing changes human behavior like cash):

| Group | Payment for the pitch |
|------|-----------------------|
| **Low‑pay** | **$1** |
| **High‑pay** | **$200** |

After they’ve delivered their pitch, the participants are asked again: *“How interesting was the task, really?”*  

- **The $200 crew**: No change. They still think the task is about as interesting as a tax audit. They can comfortably say, “I was paid a lot, so I’m allowed to lie.”  
- **The $1 crew**: Suddenly the task looks *kinda* interesting. Their brain can’t reconcile, “I sold a boring task for a buck” with “I’m a rational human.” So it rewrites reality: *“Maybe it wasn’t *that* boring after all.”*  

That, dear trader, is **insufficient justification** in action. When the external reward (the $200) is big enough, you don’t need to change your belief. When the reward is tiny, you *must* convince yourself that the task *was* worthwhile, because otherwise you’d be stuck with a glaring inconsistency—aka cognitive dissonance.  

---

## How This Shows Up in Your Trading Desk

Let’s translate that lab into a real‑world chart:

| Lab Situation | Trading Analogy |
|---------------|-----------------|
| Boring task = “boring” | A losing trade that keeps bleeding |
| Hard‑sell for $1 | Holding the loss because you *think* it will reverse |
| Hard‑sell for $200 | Holding the loss because you *paid* a lot (margin, commissions, ego) to stay in it |

When you’ve been **clinging to a loser for days**, the brain starts a mental monologue that sounds something like:

> “I’ve been watching this trade crawl downhill for 72 hours. Why am I still here? Why have I wasted $X in commissions and sleepless nights? The only way to make this make sense is to **believe** the market will magically turn around.”  

Add a dash of **self‑esteem protection** (“If I admit I’m wrong, I’m a *bad* trader”) and you’ve got a perfect recipe for a *self‑justification spiral*.  

---

## Breaking the Cycle: Adopt a “Good‑Trader” Mantra

The easiest way to stop the mind‑games is to **rewrite the internal script** before the dissonance ever appears. Try telling yourself:

- “A good trader **cuts losses**; that’s a sign of strength, not weakness.”  
- “My strategy will have losers; that’s normal. The key is **exiting before the loss snowballs**.”  

If you can *internalize* those beliefs, the moment a trade starts to lose you won’t need to invent a heroic comeback story. You’ll simply think, “Time to exit, because that’s what a disciplined trader does.”  

### Practical Tools  

1. **Pre‑define your exit** – Set a stop‑loss level *before* you enter. When the price hits that line, you’ve already given yourself permission to leave.  
2. **Use a “loss‑cut” checklist** – For example:  
   - Is the price beyond my stop?  
   - Did the market break my trade’s premise?  
   - Have I already lost more than X% of my account?  
   Tick the boxes and walk away.  

3. **Put a “justification budget” on paper** – Write down the *only* acceptable reasons to stay in a trade (e.g., “new fundamental data released”). Anything else is a red flag.  

---

## The Preventative Play: Stop Self‑Justification Before It Starts

Think of self‑justification like a virus: once it’s inside, it replicates fast. The best defense is a **pre‑emptive vaccine**—a set of rules that make the “I must stay because I’m right” narrative impossible.  

- **Set a hard stop‑loss** (e.g., 2% of account equity). When it’s hit, the trade is automatically closed. No mental gymnastics required.  
- **Schedule a post‑trade review** *right after* you exit. Write down why you exited; later you’ll see the logic was sound, reinforcing the good habit.  

By the time you’d feel the urge to say, “But what if it rebounds?” the trade will already be *out of the way*, and the brain can’t cling to a phantom profit.  

---

## Bottom Line: Spot the Insufficient‑Justification Gremlin

- **When you’re paid a lot** (big margin, big ego), you can rationalize staying in a loser without changing your belief.  
- **When the payoff is tiny** (a few dollars, a tiny potential gain), your brain *forces* a belief shift: “Maybe this isn’t that bad after all.”  

In trading, the “payoff” is usually *not* cash for the justification—it’s the *hope* of a reversal. That hope is **tiny** compared to the money you’re losing, so your brain will twist reality to keep you in the position.  

**What to do?**  
1. **Acknowledge the bias** (the first step to any good habit).  
2. **Adopt a loss‑cutting identity** (“I’m a trader who cuts losers”).  
3. **Lock in exits with stops, checklists, and post‑trade journals**.  

When you can see the insufficient‑justification effect for what it is—a mental shortcut that *lies* to protect your ego—you’ll be better equipped to shut the door on losing trades before they become expensive lessons.  

So next time you feel the urge to hug a loser tighter than a long‑lost lover, remember: **the only thing you’re really protecting is your own narrative, not your capital.** And that, my friend, is the most expensive justification of all. Cheers to cleaner charts and lighter consciences! 🍻  