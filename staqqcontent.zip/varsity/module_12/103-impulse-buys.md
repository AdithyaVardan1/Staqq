# 103. Impulse Buys  

**Source:** https://zerodha.com/varsity/chapter/impulse-buys/  

---  

Ever had one of those “just‑one‑more‑thing” moments at the checkout? You went in for a loaf of bread and a gallon of milk, you’re stuck in the eternally‑snaking line, you glance at the glossy magazines, you spy a rainbow‑colored pack of gummy bears, maybe a shiny new phone charger, and before you know it you’re pushing a cart that looks like a mini‑department store—candy, batteries, tabloids, and a novelty‑scented candle you’ll never light. Retailers *know* that placing those little temptations right where you’re waiting to pay is a psychological trap, and they count on you to make an impulse purchase.  

Now, swap the grocery aisle for the trading screen. Have you ever caught yourself buying a stock just because a slick TV ad made you feel all warm and fuzzy about the brand? Or maybe you were at the PTA meeting and noticed every kid sporting the same neon sneakers, and suddenly you’re convinced the shoe‑maker’s stock is about to “take off.” That gut feeling that a product is about to become the next big thing can feel electrifying, and the idea that the share price will follow suit is tempting. Your hunch could be spot‑on, but the key is to **keep your cool** and not let the impulse train run away with your portfolio.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/02/20070518-300x300.png)  

In “*Mind Over Money*,” Harvard‑affiliated psychiatrist Dr. John Schott coins the term **“The Impulsive Investor.”** These are the folks who get dazzled by a company’s image—maybe it’s the snazzy storefront, the celebrity endorsement, or the sleek logo on a T‑shirt—and they sprint to buy the stock without a playbook. Imagine walking into a boutique, falling head‑over‑heels for the designer jacket, and swiping your card before you even check the price tag. That’s the investment equivalent. The impulsive investor’s strategy is “feel‑good first, think‑later later.”  

Sometimes the universe rewards that kind of reckless romance (think of early‑stage tech winners that skyrocketed), but more often the honeymoon ends quickly. Dr. Schott points out that impulsive investors not only **buy too fast** they also **sell too soon**—they dump the shares the moment the initial sparkle fades, much like a lover who disappears after the first date. He likens it to “love at first sight” with a financial twist: “I’ve fallen for this stock; it better return the favor with a quick profit.” When the stock fails to “love them back,” they bail, often at a loss.  

You don’t have to be a full‑blown “impulsive investor” to feel a personal attachment to a ticker. Many of us have a soft spot for the old‑school giants—IBM, GM, Coca‑Cola—because we grew up watching their ads, maybe even had a GM truck in the driveway. Emotionally they feel safe, like a childhood blanket. But if you stop and look at the hard numbers, you’ll see that GM’s recent earnings margins have been under pressure, or IBM’s revenue growth has stalled. **Feelings ≠ fundamentals.** The market cares about earnings, cash flow, and future outlook—not about how many nostalgic commercials you loved as a kid.  

Even if you consider yourself a rational, data‑driven trader, it’s worth pausing to ask yourself: *Was this trade born out of a genuine analytical edge, or did I just get a warm‑fuzzy feeling and act on it?* Intuition can be a useful spice, but it should never be the main course. Draft a **clear, written trading plan**: define why you’re going long or short, list the specific catalysts you’ll watch, set entry and exit levels, and decide on stop‑losses. Dr. Schott advises that the goal is to **insert a “thinking buffer”** between the impulse and the execution—give yourself a few minutes (or hours, or days) to double‑check the numbers. In short, **don’t impulse‑buy**; give your brain a chance to catch up with your heart. What looks like a golden opportunity in the moment may turn into a “what‑was‑I‑thinking?” after a second look.  

---  

So next time you feel the urge to add another ticker to your watchlist because it just feels right, remember the candy aisle, the love‑at‑first‑sight syndrome, and the power of a solid plan. A little patience now can save you a lot of regret (and a few sleepless nights) later. Cheers to smarter, less impulsive investing!