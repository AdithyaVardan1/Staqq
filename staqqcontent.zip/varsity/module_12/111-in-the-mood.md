# 111. In the Mood  

**Source:** https://zerodha.com/varsity/chapter/in-the-mood/  

---  

Jason is stuck in a trading slump. The poor kid thinks his performance is “meh” even though he’s only been dabbling in the markets for a few months. One tiny loss and he’s got his face pressed against the screen like it’s a bad breakup. He keeps asking himself, *“Why can’t I rake in the big bucks? When am I ever gonna be rolling in cash unless I start stacking profits like a kid stacking LEGO bricks?”*  

The truth? Jason’s got a hefty serving of attitude‑itis. He’s convinced himself that the universe is conspiring against his *future* billionaire self, and that little self‑talk is doing him more harm than good. The good news? He can actually flip the switch to a brighter, more productive mindset—one that makes it easier to slide into the coveted “zone.”

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/02/20070228-300x300.png)

### 1️⃣ Reset the reference point – don’t compare yourself to the market’s Michael Jordan  

Right now Jason is holding a mirror up to a fantasy version of himself: “I’m a **Market Wizard** who never misses a trade.” In reality, he’s a fresh‑out‑of‑college rookie still learning which way the wind blows. If you keep measuring yourself against the *best* traders on Wall Street, you’ll spend most of your life feeling like a sad trombone soloist at a jazz concert.  

A smarter move is to set goals that are a shade lower than “world‑domination.” It takes years—think a decade or more—of grind, trial‑and‑error, and sleepless nights to acquire the chops of a seasoned pro. Until then, keep your comparison radar focused on **you**: look at how you performed last month *when the market was behaving similarly.* Even the most legendary traders have a bad day when the market decides to behave like a toddler on a sugar rush.  

### 2️⃣ Swap performance goals for learning goals – become a scholar, not a gold‑grabber  

Instead of obsessing over the dollar amount or the percentage return on your latest trade, ask yourself: *“What did I actually learn today?”* Did you discover why a breakout failed? Did you practice proper position sizing? Did you manage your emotions when the price jittered like a nervous cat?  

Counting “hours of study” and “quality of analysis” is a far more stable yardstick than a volatile P&L statement. Skill‑building is the real currency; the cash will follow once the habit is ingrained.  

### 3️⃣ Experience is the best teacher – but don’t try to sprint a marathon  

If you keep chasing unrealistic profit targets, you’ll end up as stressed as someone who’s trying to eat a whole pizza in one bite. That stress makes you dodge the market, which means fewer trades, slower learning, and ultimately a stagnant skill set.  

Instead, treat each trade like a rehearsal for a big performance. The more you practice—preferably in a variety of market climates—the sharper your instincts become. Think of it as a gym membership for your brain: the heavier the weights (i.e., the more complex the market condition), the stronger your trading muscles get—*as long as you don’t quit after the first sore day.*  

### 4️⃣ Focus on the **process**, not just the profit headline  

Trading should feel a bit like a good game of darts: you aim, you release, you watch the dart fly, and you enjoy the *act* of throwing, not just the scoreboard. When you obsess over every cent gained or lost, you become a nervous wreck—eyes darting, heart pounding, hands trembling. Those nerves are the perfect recipe for sloppy entries, premature exits, and a whole lot of regret.  

Conversely, if you zero in on the *experience*—the research, the setup, the execution—you’ll stay calmer, think clearer, and even have room for a little creativity. Over time, this mindset trains you to trade “effortlessly” (read: with confidence), and the profits will start to look like a happy side‑effect rather than the sole purpose.  

### 5️⃣ Stay the course – the market will throw you curveballs, but you can still swing  

Trading is a roller‑coaster that loves to surprise you with loop‑de‑loops. It’s easy to get stuck in a rut, especially when you’re staring at a red candle that refuses to turn green. But by nurturing a resilient mindset—setting realistic, bite‑size goals, and savoring the intrinsic rewards of the trade—you’ll be able to keep moving forward even when the market is being a drama queen.  

Bottom line: ditch the “I must be rich tomorrow” fantasy, start treating each trade as a lesson, and enjoy the ride. Your future self (who will probably be sipping a decent coffee while checking a modestly growing portfolio) will thank you for the patience you built today. Cheers to a happier, healthier trading mood!  