# 164. The Big Picture  

**Source:** https://zerodha.com/varsity/chapter/the-big-picture/  

---  

Jim has just slotted a monster trade into his screen. He’s got **25 % of his whole trading capital** hanging on the line, and his brain is doing somersaults like a caffeinated squirrel. “If I don’t make a tidy profit, this is going to be a disaster!” he mutters, eyes glued to the chart, heart thudding louder than a drum solo at a rock concert. The pressure is so thick he can barely think; his emotions have taken the driver’s seat, and the rational part of his brain is stuck in the back‑seat, scrolling through Instagram memes instead of watching the price action.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/03/20061213-300x300.png)  

---

### Why Jim’s panic makes sense (and why it’s a bad habit)  

Putting a quarter of your bankroll on a single ticket is like walking into a casino with a $10,000 chip and betting the whole thing on one spin of the roulette wheel. Sure, a big win would be sweet, but the downside is a *real* gut‑punch. Jim is paying both a **financial** price (the possible loss of 25 % of his capital) **and** a **psychological** price (sleepless nights, sweaty palms, the sudden urge to binge‑watch calming yoga videos).  

When you risk that much, two things happen:  

1. **Your brain starts screaming “don’t lose!”** – cortisol spikes, you get tunnel vision, and the only thing you can focus on is the fear of losing, not the probability of winning.  
2. **Your decision‑making gets hazy** – you might start adding more money, chasing the trade, or even closing out early just to “stop the bleeding,” even if the trade is still perfectly valid.  

A smarter, more tranquil way to trade is to **cap your risk per trade**. Think of it as putting a tiny safety net under a tightrope walker; the walker can still perform spectacular stunts, but if they slip, they won’t plummet to the ground. The net (i.e., a small risk size) eases the pressure, and your brain can stay in “analysis mode” instead of “panic mode.”  

---

### The pros and cons of “big‑ticket” trading  

**Seasoned pros** – veteran traders sometimes go for the big‑ticket rides. Why? Because they have:  

* **Sharpened edge** – years of back‑testing, paper‑trading, and surviving market tantrums have given them a robust edge.  
* **Rock‑solid confidence** – they know that even if they lose a chunk, their overall system will eventually recover. It’s like a seasoned sailor who isn’t scared of a single wave; the ocean is just part of the job.  

If a veteran loses that 25 % slice, it hurts, but they usually have **enough capital and diversified edges** to rebuild the bankroll over time.  

**Novice cons** – the rookie, on the other hand, is still learning where the icebergs hide. Even if they *feel* they’ve found a “sure‑fire” setup, the reality is that **no strategy is 100 % foolproof**. Markets love to surprise you, and a strategy that’s been killing it for months can flip overnight because of a surprise Fed decision, a geopolitical flashpoint, or a meme stock frenzy.  

If you’re a newcomer, the back‑of‑your‑mind whisper that “I might never make this money back” is not just a nervous tick; it’s a genuine risk. Ignoring it won’t make it disappear—it’ll just sit there, ready to pop up as a sleepless night or a frantic “sell‑everything” button press.  

**Rule of thumb for the greenhorn:** stick to a **2 % (or even 1 %) risk per trade**. That way, even a string of losers won’t wipe you out, and you’ll still have enough capital to keep learning and applying new strategies.  

---

### The hard truth about “perfect” strategies  

You might have heard the phrase “find the perfect trading system and you’ll be set for life.” Spoiler alert: **there isn’t one**. Even the most statistically solid system—say, a mean‑reversion algo with a 70 % win rate and a 2:1 reward‑to‑risk ratio—will eventually hit a losing streak when market dynamics shift.  

*Markets are like weather: today’s sunny forecast can turn into a thunderstorm tomorrow.*  

When the climate changes (think regime shifts, liquidity crunches, or a sudden surge in algorithmic activity), your beloved strategy may start underperforming. The kicker? **You never know exactly when the regime will flip.** That’s why the only reliable weapon in a trader’s arsenal is **risk control**.  

---

### Big‑picture thinking: why the sum of many trades matters more than any single one  

Imagine you’re playing a long‑term board game of Monopoly. One disastrous roll that lands you on Boardwalk with a hotel might set you back a few million, but if you keep buying properties, collecting rent, and making smart trades, you’ll still end up with a tidy portfolio in the end. The same principle applies to trading:  

* **Your ultimate goal** = **profitability over a *series* of trades**.  
* **A single trade’s outcome** = a tiny blip on a massive radar screen.  

If you limit each trade to a modest slice of your bankroll, even a **run of losing trades** won’t blow your account to bits. You stay in the game, you keep collecting data, and you give your strategies the chance to prove themselves over time.  

---

### Psychological perks of keeping the risk tiny  

When you put only a small amount on the line, you get a *mental cheat code*:  

* **Less “blood on the floor”** – you know, “Hey, even if this goes south, I’m still standing with 98 % of my cash.”  
* **Higher confidence** – you can walk away from a losing position without feeling like you just watched your life savings evaporate.  
* **Better sleep** – because your brain isn’t replaying the trade like a bad Netflix series at 3 a.m.  

In short, a modest risk size lets you **stay rational**, **avoid emotional swings**, and **maintain a growth mindset**—the exact ingredients for a consistently profitable trader.  

---

### TL;DR – Keep your eyes on the horizon, not the pothole  

1. **Don’t let emotions hijack your decisions.** Your brain loves drama, but your bankroll loves discipline.  
2. **Think of the big picture:** profitability is the sum of many trades, not the heroics of a single monster bet.  
3. **Limit risk per trade** (2 % or less for beginners) to survive inevitable losing streaks.  
4. **Accept that no strategy is infallible.** Markets change; your risk management should stay constant.  
5. **Enjoy the psychological peace** that comes with knowing you can survive any one trade (or a few).  

By keeping each bet small, you give yourself the breathing room to learn, adapt, and ultimately **cultivate the winning mindset of a consistently profitable trader**—all while still having enough cash left over to treat yourself to a celebratory beer when the series of trades finally tips into the green. Cheers to the big picture!