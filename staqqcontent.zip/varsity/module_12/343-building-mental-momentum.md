# 343. Building Mental Momentum  

**Source:** https://zerodha.com/varsity/chapter/building-mental-momentum/  

---  

When the market puts the heat on you, it’s easy to feel like you’re trying to fry an egg on a sidewalk. The pressure builds, you start choking on your own thoughts, and every decision looks as fuzzy as a bartender’s “one more round” after a few drinks. It’s way more pleasant to feel like you’re cruising ahead of the pack than scrambling to catch up after a nasty draw‑down.  

A draw‑down can hit you like a surprise karaoke performance—embarrassing, a little shocking, and you’re not quite sure how to get back on stage. You might feel a mix of disappointment and that stunned “I just fell off the bike” vibe, making it hard to stand up again. On the flip side, after a string of winning trades you start to feel like the guy who just nailed the last “Last Call” joke—relaxed, confident, and ready to spin new, winning strategies.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/06/20050713-300x300.png)  

When you’re in that “ahead of the game” zone, everything clicks. You trade as smoothly as a well‑shaken martini and the profits start flowing. Being ahead puts you in a prime mental state, but it’s a lot tougher to summon that swagger when you feel stuck in a rut, staring at a screen that looks more like a “Help! I’m lost” sign.  

That’s when you need to remember that trading has **two kinds of momentum**:  

1. **Profit momentum** – the cold, hard cash that makes your bank account do a happy dance.  
2. **Mental momentum** – the inner buzz that tells you, “Hey, I’m doing great, even if the numbers aren’t screaming yet.”  

Both are powerful, and you can (and should) crank up the mental side just as much as the profit side.  

We all know profit momentum. It’s the sweet feeling when your portfolio looks like it’s been on a winning streak at a casino. Mental momentum, however, is the quiet confidence you get when you know you’ve given it your all—when you’ve done everything in your power, even the boring prep work. In those moments, it’s totally fine to give yourself a mental high‑five.  

Too often traders act like a kid who only cares about the candy at the end of the line, ignoring the fun of the ride itself. We obsess over profit numbers and forget to celebrate the effort that *could* lead to those numbers. In other words, we chase **performance goals** (e.g., “Make 20 % profit this month”) while neglecting **learning goals** that are just as vital.  

Instead of zeroing in on a single performance target—say, “20 % profit per month”—think about complementary goals that demand effort but don’t always translate instantly into cash. Tiny, achievable milestones deserve a pat on the back (or a celebratory sip of your favorite brew). Break the massive “make a fortune” dream into bite‑size steps, and reward yourself after each one.  

**Example:**  
- **Study 30 hours a week** or master a fresh trading technique. Even if the only “profit” you get is a warm fuzzy feeling, that’s still a win. This goal isn’t a direct shortcut to 20 % profit, but it’s easy to hit, gives you instant satisfaction, and over time builds the foundation for that big‑picture profit target.  

The more modest goals you crush, the more mental momentum you rack up.  

It’s crucial to give yourself credit for every ounce of effort you pour into trading. Sure, it’s tempting to pat yourself on the back *only* when a trade ends in green, but remember: the mental gymnastics you perform on a losing trade are just as demanding as on a winner. Whether a trade ends in profit or loss, reward yourself for the work you put in. The more consistently you celebrate *effort* (not just results), the stronger your mental momentum becomes.  

That mental boost translates into feeling stronger, more empowered, and ultimately trading with the same effortless grace as that perfectly timed “cheers” at the bar. In short, build that mental momentum, and you’ll find yourself trading more fluidly—and, yes, more profitably—without the usual brain‑fry. Cheers to that!