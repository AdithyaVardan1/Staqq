# 150. One More Thing in the Back of Your Mind  

**Source:** https://zerodha.com/varsity/chapter/one-more-thing-in-the-back-of-your-mind/  

---  

### Why you should kick unresolved conflicts to the curb – yesterday  

Picture this: you’ve got a nagging thought that’s hanging out in the attic of your brain like an unwanted houseguest. If you keep pretending it isn’t there, it’ll start stealing your snacks (aka mental bandwidth) and eventually burst out in a dramatic “surprise!” right when you’re trying to place a trade. Freud already warned us a century ago that “unresolved conflicts are just one more thing in the back of your mind, taking up space and time.” Modern cognitive psychologists have taken his couch‑potato theory and turned it into hard‑science: the brain has a finite amount of *psychological energy*—think of it as mental gasoline. The more unresolved baggage you stash away, the more of that gasoline you waste just keeping the luggage from rolling onto the floor.  

If you let those mental suitcases pile up, they’re likely to tumble out when you’re least prepared—like when you’re staring at a candlestick chart and the market decides to do a back‑flip. Not every trader’s unconscious is a haunted house, but it’s a safe bet to make sure you’re not walking around with invisible bricks in your backpack.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/03/20060714-300x300.png)  

### “Do I have a secret mental gremlin?” – the science of denial  

Research tells us that you can’t simply “shove” a conflict into the dark corner of your mind and hope it disappears. In fact, the harder you try to ignore it, the more mental calories you burn—like trying to hold your breath while running a marathon. The paradox is delicious: denial = more energy spent, resolution = energy saved. So instead of playing hide‑and‑seek with your inner demons, give them a polite nod and a quick “hey, I see you.” Often that simple acknowledgment is enough to dissolve the tension faster than you can say “stop‑loss.”  

Even if you’re the kind of person who feels you’ve got a squeaky‑clean conscience, every trader eventually bumps into a few universal mental speed‑bumps. Some of these are the “nice‑to‑know” beliefs that feel true enough to keep you comfortable, but they’re also the ones that can trip you up when the market decides to be a drama queen.  

### Luck vs. skill – the uncomfortable truth for newbies  

Let’s get real: a rookie trader who strings together a handful of winning trades might be riding a wave of pure luck, not a newly discovered trading superpower. Accepting that your recent success could be a cosmic coin‑flip is like admitting your favorite pizza place occasionally serves a mediocre slice—unpleasant, but honest. Pretending you’re a wizard because you hit a few bullseyes actually drains more psychological juice than admitting, “Okay, I need to study more.” Once you own up to the possibility that you’re still learning, you can redirect that saved energy into sharpening your strategy, reading more charts, or finally watching that “Risk Management 101” video you’ve been ignoring.  

### “Am I past my prime?” – the market‑evolution anxiety  

Another classic brain‑tickler is the “I was great once, but the market’s changed, and I’m old news.” This thought can creep into the back of your mind like an unwanted sequel to a bad movie. Whether it’s a legitimate concern or just an over‑active imagination, the very act of letting it linger sucks up mental bandwidth. The smarter move? Bring the thought into the spotlight, give it a quick assessment, and then decide:  

- **If it’s nonsense** – give yourself a mental high‑five and tell the thought, “Nice try, but you’re not welcome here.”  
- **If it’s got a grain of truth** – treat it as a signal to upskill, perhaps by learning new instruments, exploring different time‑frames, or simply brushing up on macro trends.  

Either way, you’ve prevented that mental mumbo‑jumbo from turning into a full‑blown anxiety attack while you’re trying to set a stop‑loss.  

### When the gloom hits – those back‑of‑mind beliefs that surface  

We’ve all had those days when the market looks bleaker than a Monday morning after a weekend of binge‑watching. On such days, the quiet, dusty beliefs you’ve been ignoring can leap from the back of your mind to the front seat, shouting, “You’re a terrible trader!” Ignoring them is like putting a blindfold on a screaming baby—doesn’t help anyone. The better approach is a quick mental check‑in:  

1. **Spot the belief** – “I’m a loser right now.”  
2. **Label it** – “Okay, that’s a negative self‑talk thought.”  
3. **Give it a reality check** – “Maybe I’m down today, but that doesn’t erase the good trades I’ve made.”  
4. **Park it for later** – “That may be true, but it’s not urgent right now.”  

By doing this, you’re essentially putting that belief on a “to‑do later” list, freeing up mental horsepower for the trade you’re actually executing.  

### Bottom line: declutter your mental attic  

Unresolved conflicts are the mental equivalent of that half‑finished IKEA bookshelf gathering dust. If you keep shoving it into a corner, sooner or later it’ll wobble and collapse, possibly on top of your favorite trading setup. The cure? Face those thoughts, give them a quick once‑over, and either toss them out or store them neatly where you can deal with them later.  

When you do the mental housekeeping, you’re essentially pulling one more thing out of the back of your mind, freeing up precious psychological energy for the things that truly matter—like spotting the next high‑probability setup or finally mastering the art of the perfect coffee‑to‑screen ratio. So next time a nagging thought tries to set up camp, invite it over for a brief coffee chat, decide its fate, and then send it on its way. Your brain (and your P&L) will thank you.  