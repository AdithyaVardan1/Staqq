# 110. Information Anxiety  

**Source:** https://zerodha.com/varsity/chapter/information-anxiety/  

---  

Ever get that nagging feeling that no matter how many coffee‑fueled hours you put in, the universe is tossing you more data than a Netflix binge‑watch queue? If you’ve shouted “yes!” in your head, congratulations – you might be suffering from **information anxiety**. In the age of smartphones, Twitter storms, and 24‑hour news cycles, the sheer volume of stuff we can absorb is mind‑boggling. Trading, in particular, feels like trying to drink from a fire hose while balancing on a unicycle. Compare today’s trader to the poor soul from two decades ago and you’ll see a mountain of extra data that would make even a seasoned accountant break out in a cold sweat.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/02/20070227-300x300.png)  

You’ve got the internet, the financial newspaper, the cable news pundits, the Twitter bots that scream “BUY! BUY! BUY!” and the market data that arrives faster than a pizza delivery on a Friday night. Every tick, every candlestick, every indicator is now just a click away. It’s no surprise that many traders start to feel like they’re drowning in a sea of numbers, charts, and “expert” opinions – cue the dreaded information anxiety. And just like any other anxiety, it can hijack your brain, turn your confidence into a shaky Jenga tower, and ruin that laser‑sharp, peak‑performance mindset you’re trying to cultivate. The cure? Learn to keep the anxiety in check so it doesn’t become the third wheel on your trading journey.  

### More Isn’t Always Better (Especially When It’s Information)  

Sure, we can now download enough data to fill a small library, but if you can’t turn that avalanche into a crystal‑clear insight, it’s as useful as a chocolate teapot. Back in the day of Jesse Livermore, the “tape” – essentially a ticker‑tape of price quotes – was the whole world. Some modern pros still swear by just watching price and volume, proving that a minimalist diet of data can be just as nutritious as a five‑course feast.  

Today’s trading platforms flash a parade of indicators: moving averages, Bollinger Bands, stochastic oscillators, MACD, and the list goes on. The funny part? Many of them are just repackaging the same underlying information (think of them as different flavors of the same ice cream). Staring at every single one is like trying to read every book in a library to find the one sentence that tells you whether it’s going to rain tomorrow. It wastes time, burns brain calories, and gives you a false sense of control.  

Even if you could perfectly understand every single data point—past, present, and future—remember that markets are chaotic by nature. Perfect hindsight doesn’t guarantee a crystal‑ball forecast. In other words, having a Ph.D. in “Everything‑Everything‑Data‑Science” won’t magically make you a Nostradamus of the S&P 500.  

The smarter move is to **trim the data diet**. Human brains, despite being glorious, are not super‑computers; we can only juggle a limited number of variables before the mental plates start crashing. Overloading yourself leads to that dreaded “information overload” feeling, where you stare at charts like a deer in headlights and your decision‑making slows to a snail’s pace. Acknowledging this limitation isn’t a defeat—it’s a strategic advantage. Focus on a handful of high‑impact metrics you truly understand, and let the rest take a back seat.  

### The Myth of “Perfect” Knowledge  

In our hyper‑connected world, there’s a seductive whisper that if you could just amass **perfect knowledge**, you’d become an invincible trading wizard. Spoiler alert: that whisper is a siren song designed to keep you scrolling forever. There is no such thing as perfect knowledge—unless you’ve discovered a time‑traveling crystal ball, in which case, please share. Even if you somehow did obtain omniscience, it probably wouldn’t help you much because markets are influenced by human emotions, geopolitical surprises, and the occasional meme stock frenzy.  

Chasing that mythical “perfect” data set is a classic distraction. It’s like hunting for the perfect avocado: you’ll spend hours at the grocery store, get frustrated, and end up with a bruised one anyway. The more you chase, the more you feel inadequate, the more you doubt yourself, and the deeper the information anxiety worm burrows into your brain.  

The antidote? **Pick a few reliable sources** (maybe a trusted news outlet, a solid charting tool, and a disciplined watchlist) and **master them**. When you’ve internalized those sources, you’ll move from “information‑overwhelmed” to “information‑empowered.” Your trading mindset will shift from anxious and indecisive to relaxed, decisive, and—most importantly—consistent.  

In short, stop trying to drink the ocean. Sip a well‑chosen glass, savor it, and let the rest stay on the shore. Your brain (and your P&L) will thank you. Cheers to a calmer, sharper trading self!