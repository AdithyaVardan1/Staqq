# 338. The Disciplined Mindset  

**Source:** https://zerodha.com/varsity/chapter/the-disciplined-mindset/  

---  

Picture this: you’re sipping a cold brew, eyes glued to the chart, and everything is *chef’s kiss* perfect. You entered the trade exactly where your plan said you would, you’ve got a crystal‑clear exit at 53, and the only thing standing between you and that sweet profit is a little patience. The price, however, is playing hide‑and‑seek around 50‑51, taking its sweet time like a teenager dragging out a weekend. Your stomach starts doing the cha‑cha, you feel the “what‑the‑heck‑is‑this‑still‑not‑moving?” panic creeping in, and *boom* you smash that sell button. Ten minutes later the market decides it’s finally feeling generous, rockets to 53, and you’re left staring at the screen like, “Did I just watch my profit walk out the back door?”  

Why did you bail on your own plan? Why did the inner‑impulse‑monster get the better of you? If you’ve ever been there, congratulations—you’re part of the “I‑thought‑I‑was‑a‑rational‑human‑being” club, which has a 100 % attendance rate.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/06/20050720-300x300.png)  

## The Plan‑Vs‑The‑Panic Gap  

It’s entirely possible to craft a flawless trading blueprint while simultaneously being a terrible follower of that blueprint. When you sketch the trade out in a calm, logical headspace, you swear by every entry, stop‑loss, and target. You’re basically the Gandalf of your own portfolio—*you shall not pass*… without a plan.  

But then the market throws a curveball, your heart starts drumming like a rock‑concert, and that well‑rehearsed script gets tossed out the window. Something in the subconscious‑machinery goes haywire, and you abandon the very plan you swore to honor.  

## The “It’s‑Too‑Fast‑For‑Me” Illusion  

Why do we act like a hamster on a wheel and regret it later? Some traders argue that the market moves at the speed of light, leaving no room for contemplation. To a degree, they’re right: the brain‑body combo is wired for split‑second survival responses, and the trading arena looks a lot like a jungle where the first scream often wins.  

The good news? You can *train* those reflexes, just like you can train a puppy not to chew your shoes. Every action you take is preceded by a thought‑bubble, a little inner chat that most of us barely notice because it happens at warp speed.  

## Talk to Yourself (But Make It a Nice Conversation)  

What you whisper to yourself in that internal monologue is the director of the movie playing in your head, and it decides whether you’re starring in “The Calm Trader” or “Panic‑At‑The‑Stock‑Exchange.”  

*Example A (the doom‑and‑gloom script):*  
> “The price isn’t moving the way I want. It never does. I’m such a fool for thinking it would.”  

Cue the furrowed brows, sweaty palms, and an urgent urge to exit before the market even thinks about moving.  

*Example B (the Zen‑master script):*  
> “The price isn’t where I’d like it to be yet, but it’s still early. I’ll breathe, trust my plan, and let the market do its thing.”  

Now you’re more likely to sit back, sip that coffee, and let the trade play out as intended. It sounds elementary, but the power of self‑talk is the financial equivalent of a hidden turbo‑boost.  

## Catch Those Rogue Thoughts Before They Go Full‑Throttle  

Most traders don’t realise that intrusive thoughts can pop up like unwanted pop‑ups on a website—right when you’re about to click “Buy.” If you’re not actively monitoring your mental chatter, those unproductive thoughts can hijack your decisions faster than a flash‑sale.  

**The habit to build:**  
1. **Observe** the thought as it surfaces.  
2. **Label** it (“Ah, there’s the ‘I’m losing money, panic!’ voice”).  
3. **Counter‑script** it with a healthier line.  

For instance, you might catch yourself thinking, *“I should be making money right now, why is this so uncomfortable?”* Swap it for, *“It’s not panic‑time. I can sit tight, my plan covers this scenario, and I’ll reap the reward when the market aligns.”*  

## From Theory to Reality: Scripts, Cheat‑Sheets, and Sticky Notes  

In theory, this is as easy as reciting a mantra before bedtime. In practice, it feels more like trying to remember a 12‑step dance routine while the floor is shaking. One pragmatic hack: write down a short “panic‑plan” script and keep it where you can see it—on a sticky note, your phone wallpaper, or even a Post‑it on the monitor.  

When anxiety starts nudging you toward the exit, read that script aloud (or silently, if you’re in a library‑quiet office). You’ll notice a shift from “I’m about to lose it” to “I’ve got a plan, and I’m sticking to it.”  

## Market’s Mood Swings vs. Your Emotional Weather  

Markets love drama—unexpected news, sudden volatility spikes, and the occasional meme‑stock frenzy. It’s tempting to try and force the market to behave the way you want, like trying to get a cat to fetch a ball. Spoiler: the cat will look at you, flick its tail, and walk away.  

Instead, accept that the market will do *its* thing, and focus on controlling *your* feelings. By keeping tabs on your thoughts and emotions, you become the calm captain of a ship that occasionally sails through stormy seas. You won’t control the weather, but you can decide whether to bail out or tighten the sails.  

## Bottom Line: Discipline Is a Muscle, Not a Myth  

If you consistently monitor your internal dialogue, replace the “I’m screwed” narrative with a constructive one, and have a ready‑made script for those “what‑if” moments, you’ll gradually strengthen your discipline muscle. The more you practice, the less likely you’ll snap that impulsive sell button when the price is flirting with your target.  

In short, treat discipline like a gym routine: start with light reps (a few minutes of self‑talk), add weight (harder market scenarios), and keep showing up. Over time you’ll notice higher “profit‑completion” rates, fewer regret‑ful exits, and a calmer mind that can actually enjoy watching that price finally hit 53—without the heart‑attack soundtrack.  

Stay witty, stay patient, and may your internal dialogue always be your biggest cheerleader, not your worst heckler. Cheers to disciplined trading! 🍻  