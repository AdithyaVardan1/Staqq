# 312. Cutting Your Losses  

**Source:** https://zerodha.com/varsity/chapter/cutting-your-losses/  

---  

Winning traders have a secret super‑power: they bail out of a sinking ship **before** it turns into a Titanic‑level disaster. In fact, most of them run their numbers on the premise that *the universe will hand them more losing trades than winners*. Yep, you heard that right—think of it as a “loss‑heavy diet” that keeps the portfolio trim. The art of shrugging off a loss and marching on to the next trade is not a talent you’re born with; it’s a muscle you have to pump at the gym of experience.  

The catch? It’s a lot easier to *talk* about “cutting losses” than to actually click that stop‑loss button when your position is bleeding. Behavioral economists have catalogued a whole zoo of mental quirks that keep traders glued to a losing ticket longer than a Netflix binge. Sometimes several of those quirks team up like a villainous crossover event, making it feel almost impossible to exit. The good news? Once you shine a flashlight on those sneaky processes, you can neutralize them the way you’d mute a noisy neighbor—suddenly they stop dictating your trading choices.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/06/20041207-297x300.png)  

---  

## Humans are naturally risk‑averse (and that’s why we love pizza)

Our brains are wired to dodge pain—financial or otherwise—so watching a paper loss grow is like watching your favorite pizza get sliced away, piece by piece. Most of us would rather roll the dice on a **big** loss than admit to a **tiny** one right off the bat, because the former feels like “high‑stakes drama” while the latter feels like a boring footnote.  

Take the classic “amateur‑investor‑holds‑on‑for‑weeks” scenario: they cling to a losing position hoping that somewhere, sometime, the market will perform a miracle and turn that red line green. Spoiler alert: markets aren’t magicians. More often than not, the loss deepens, the anxiety spikes, and the trader’s internal monologue turns into a loop of “I’ve got to wait a little longer… I’m *so* close to breaking even!” It’s the financial equivalent of staying at a bad party because you’ve already spent $50 on the cover charge.  

---  

## The sunk‑cost effect: the “I’ve‑already‑spent‑my‑rent‑on‑this‑trade” trap  

Ever bought a concert ticket for a band you’ve never heard of, only to realize the venue is a parking lot? You still show up because you don’t want the money to go to waste. That’s the **sunk‑cost effect** in a nutshell, except the ticket is your capital and the “concert” is a losing trade.  

The more you pour into a position—whether it’s cash, time, sleepless nights, or endless chart‑watching—the heavier the mental ballast becomes. It’s like whispering to yourself, “I’ve already watched this stock tumble for three months; I can’t just throw away the effort now!” The brain craves *justification*: “I’m not a quitter; I’m a *strategist* who believes in a comeback!”  

The irony is that the very act of rationalizing the loss makes it *harder* to cut it. You end up treating the trade like a bad relationship: you keep texting, hoping they’ll change, even though you know deep down they’re probably moving to a different state. The longer you cling, the bigger the eventual hit when reality finally slaps you in the face.  

---  

## Social dynamics: bragging rights, ego trips, and the “I‑got‑you‑covered” crowd  

Trading isn’t a solitary sport—unless you’re a hermit who lives off‑grid and only talks to a cactus. Most of us need a tribe, a Slack channel, or a Discord server where we can brag about that sweet 3:1 risk‑reward trade we just nailed. The flip side? Those same folks can become the *unofficial judges* of your every misstep.  

Imagine you post, “Just nailed a 5% gain on XYZ!” and a fellow trader replies, “Cool story, bro. Wait ’til I see you choke on your next loss.” Suddenly, admitting a mistake feels like handing your opponent a trophy. The need to **save face** becomes a powerful deterrent to acknowledging a loss.  

The antidote? Stay **humble**—think of yourself as the friend who tells you the pizza place has a terrible crust before you order. If you keep your ego in check, you’ll be more comfortable saying, “Okay, that trade went south; I’ll learn, adjust, and move on.” Humility also flips the social dynamic: your peers become supportive coaches rather than rival saboteurs, cheering you on when you take the painful but necessary loss.  

---  

## Why cutting losses is the *real* secret sauce  

Let’s get to the meat (or tofu, if you’re plant‑based). The bottom line is simple: **you will lose more often than you win**. That’s not a pessimistic prophecy; it’s a statistical reality. Think of it like playing a video game where you have to die a few times to learn where the hidden cheat codes are.  

If you treat every loss like a personal affront—*“I’m a terrible trader, I must be worthless!”*—you’ll drown in self‑doubt and start making impulsive, revenge‑driven trades (the kind that end up in the “what‑not‑to‑do” section of any trading manual). Instead, adopt a **care‑free, almost zen‑like attitude** toward each trade’s outcome.  

- **Expect to lose.** Set your mental thermostat to “cool” before you even open a position.  
- **Don’t personalize.** A loss is a *trade result*, not a *character assessment*.  
- **Stay humble.** Keep your head out of the clouds so you can see the stop‑loss line clearly.  
- **Acknowledge human bias.** Recognize that your brain hates loss and will try to trick you into holding on.  

When you master the art of saying “thanks for the lesson, buddy” to a losing trade and instantly moving on, you free up capital, mental bandwidth, and emotional stability for the next opportunity—one that, statistically speaking, has a higher chance of being a winner. Over time, those small, disciplined exits compound into a **fat, juicy profit account** that would make even the most stoic accountant weep with joy.  

In short: the easier you make peace with a loss, the more room you create for the profitable trades that *do* happen. And that, my friend, is the ultimate win‑win. Cheers to cutting losses faster than a barber cuts hair on a Monday morning! 🍻  