# 344. It’s For the Money  

**Source:** https://zerodha.com/varsity/chapter/its-for-the-money/  

---  

Ever leaf‑through a glossy mag like *GQ* or *Vanity Fair* and get hit by a barrage of slick ads? Shiny sports cars, runway‑ready threads, the newest gizmos—all posed beside people who look like they were hand‑picked by a Hollywood casting director. Those pictures are like a neon sign flashing “Earn a fortune, buy all this!” They poke at your imagination, stir up desire, and whisper, “Trade, my friend, trade—so you can afford the good life.” After all, isn’t the whole point of trading to line your pockets?  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/06/20050712-300x300.png)  

### The “Boring” Myth – Spoiler: It’s Not

Trading sounds like the plot of a high‑octane movie, right? Yet a surprising number of people who try to make a living off charts end up calling it *boring*. Not us, though—those are their words, not ours. How can a game where you stake your ego (and sometimes your cash) on an outcome that’s as certain as a weather forecast in the Sahara be boring? The very risk‑and‑reward loop is what gives your adrenal glands a tiny workout.  

Why do people actually trade? There isn’t a one‑size‑fits‑all answer. For some, it’s the rush of flirting with danger; for others, it’s the promise of a lifestyle that lets their family sip espresso in a beach house; and for a lucky few, it’s simply “because the family has been doing it for generations.”  

### Untangling the Motives

Human motivation is messier than a spaghetti junction. You could be chasing money, status, excitement, a sense of obligation, or a mixture of all three. But here’s the kicker: the *primary* driver needs to be a genuine love for the craft itself. Successful traders often say they’d keep the lights on even if the market only paid them a modest, “just‑enough‑to‑pay‑the‑rent” wage.  

Trading is more than a job; it’s an art form, a puzzle, a living laboratory. The markets are a never‑ending source of fascination—like a Netflix series that never gets cancelled. Mastering it takes skill, and that skill is rarer than a unicorn at a dog show.  

### What the Winners Think (and What the Research Says)

We’ve chatted with hundreds of traders over at Innerworth, hunting for that secret sauce that separates the champs from the chumps. The pattern? The top dogs treat trading as an intellectual sport, not a money‑making scheme. They get a buzz from cracking a tough chart pattern the way a detective cracks a cold case.  

Robert Koppel and Howard Abell nailed it back in 1994 in *The Inner Game of Trading*:  

> “The top traders all love to trade…for them it is their true mission.”  

These winners don’t feel a “should‑trade” pressure; they feel *chosen*. It’s like being handed a lightsaber in a galaxy far, far away—except the lightsaber is a spreadsheet and the galaxy is the S&P 500.  

### Passion > Profit (But Profit Still Shows Up)

When you’re truly passionate, boredom is a foreign concept. Sure, there are days when you’re juggling more data points than a DJ mixes tracks, and you might feel a tad stressed. But to the elite trader, that stress is just another flavor of the fun—like adding hot sauce to an already tasty taco.  

They thrive on the relentless challenges, savor the fact that over 90 % of would‑be traders throw in the towel, and they keep grinding because they *love* the game. Money, fame, and glory are nice side‑effects, not the main course.  

It’s a delightful paradox: they don’t chase the cash, yet their obsessive practice makes them *extremely* profitable. So, if you want to join the winners’ circle, stop staring at the profit line like a love‑struck teenager. Let the passion do the heavy lifting; the profits will eventually RSVP to the party.  

**Bottom line:** Cultivate a genuine love for trading, let that fire push you to sharpen your edge every single day, and watch the money follow like an obedient puppy. 🎉  