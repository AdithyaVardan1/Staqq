# 246. Detached and Objective  

**Source:** https://zerodha.com/varsity/chapter/detached-and-objective/  

---  

Picture this: you’re at a noisy bar, the TV is flashing ticker symbols, and the bartender is shouting “Buy low, sell high!” A **winning trader** is the one who sips his drink, watches the chaos, and *doesn’t* let the market’s roller‑coaster make his heart race. He isn’t glued to the screen like a teenager scrolling TikTok, and he certainly isn’t letting every little price wiggle tug at his emotions.  

New‑bies, on the other hand, tend to get the **“I‑can’t‑stand‑losses”** bug. It’s a perfectly human reflex: our ancestors needed fear to dodge wolves, and today we need it to dodge a bad trade. When danger (or a losing position) looms, fear spikes, we act on instinct, and—just like that—impulsive decisions and trading blunders are born. The more you practice staying cool, calm, and *detached*, the easier it gets to keep those emotional gremlins in check.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/04/20061030-300x300.png)  

If humans never felt anything when markets swung, there would be **zero volatility**—and that would be as boring as a silent disco. Fear and greed are the twin engines that push the masses to buy at the top of a hype wave or sell at the bottom of a panic dip. The secret sauce that separates you from the herd is simple: **don’t let those engines drive your car**. Master traders are like seasoned bartenders who can handle a rowdy crowd without spilling a drop; they keep their emotions in the back‑room and let the *plan* run the show.  

When a stock hits your protective stop‑loss, a seasoned trader **closes the position on the spot**—no drama, no guilt, no midnight existential crisis. Small, pre‑planned losses are just the “cover charge” you pay for entry into the market club. Likewise, when the price reaches the profit target, the veteran trader calmly decides whether to take the whole profit, scale out, or even add to the position while nudging the stop‑loss higher. In all cases, the trade is **executed exactly as the plan dictates**, with a calm confidence that feels more like a relaxed toast than a frantic sprint.  

Staying emotion‑free isn’t a walk in the park—especially when you’re fresh‑off‑the‑boat and everything feels new and unpredictable. The first few trades are like trying a new cocktail: you’re not sure if you’ll love it or hate it. That uncertainty naturally spikes fear. The trick is to *stack the odds* in your favor:  

- **Limit your risk** – make each trade’s potential loss so tiny that it feels like losing a few bucks on a cheap beer. If a single trade can’t dent your bankroll, you’ll find it much easier to stay detached.  
- **Trade with money you can afford to lose** – think of it as the “tip jar” you’re willing to empty without breaking the bank. If a loss would actually hurt your rent payment, you’ll be glued to the screen, heart hammering.  

The more you convince yourself that *any single outcome truly doesn’t matter*, the more you’ll be able to trade with the same breezy confidence you have when you order a second round. And when detachment and objectivity become second nature, trading stops feeling like a high‑stakes drama and starts feeling like a smooth‑sailing cruise—effortless, enjoyable, and, most importantly, consistently profitable.  