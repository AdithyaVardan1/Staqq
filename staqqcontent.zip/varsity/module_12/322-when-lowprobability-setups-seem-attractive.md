# 322. When Low‑Probability Setups Seem Attractive  

**Source:** https://zerodha.com/varsity/chapter/when-low-probability-setups-seem-attractive/

---

> “I’ll worry about it later.”  

That little phrase is the mental equivalent of hitting the snooze button on a 7 am alarm—you convince yourself you’ll deal with the dreaded task **later** and keep scrolling. We all do it. Imagine you’ve been putting off that 2005 tax return for a decade. The deadline was last Saturday, but why start now? Most of us wait until the calendar screams “tax day” before we even think about digging out the receipts from the shoebox labeled “Misc Stuff.” The same procrastination‑monster shows up in the world of investing.

A research team led by Dr. Michael Sagristano (Sagristano, Trope & Liberman, 2002) discovered something that sounds like a financial‑psychology version of a magic trick: people *will* gamble on a low‑probability, high‑payoff scenario **as long as they don’t have to see the outcome right away**. In other words, the farther the result is in the future, the more willing we are to bet on a long shot.

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/06/20041122-230x300.png)

### The experiment in a nutshell  

Participants were asked to picture themselves making two different economic choices:

1. **High payoff, low probability** – Think “lottery ticket” vibes.  
2. **Low payoff, high probability** – Think “steady‑as‑she‑goes bond.”

But here’s the twist: the researchers varied *when* the payoff would be delivered—either **right now** or **way down the road**.  

- **When the reward was far in the future**, people said, “Sure, I’ll take that 1 % chance of winning a million dollars. I’ve got time to let the suspense brew.”  
- **When the reward was imminent**, the same folks switched to the safe bet: “Give me the 90 % chance of getting $10 right now.”  

In plain English: we love a glittering, low‑probability jackpot **only if we can postpone the heartbreak (or the jubilation) indefinitely**. The moment we have to confront the result soon, we become the sensible, risk‑averse version of ourselves.

### Why this matters for your portfolio  

Long‑term investments—think retirement accounts, real estate, or that “next‑big‑thing” crypto—often look like the high‑payoff, low‑probability option. The research suggests we’ll pour money into these glittering ideas simply because the pain (or pleasure) of the outcome is scheduled for “sometime later.” That’s a slippery slope, because probability still matters. Whether you’re holding a stock for five years or day‑trading a swing, **the odds of success should be on your side**.

If you chase a unicorn startup because the upside looks massive, but the odds of it turning into a unicorn are slimmer than a model’s waistline, you’re flirting with a losing proposition. The temptation to “go big or go home” is especially strong when greed whispers, “What if this is the one that finally pays off?” But greed, like a mischievous bartender, will keep pouring you shots of optimism until you’re too drunk to see the low odds.

### Bottom line: Play the probabilities, not the fantasies  

- **Always vet the odds.** A 70 % chance of a modest gain beats a 5 % chance of a life‑changing windfall in the long run.  
- **Give the future its distance.** If you can’t stand the idea of waiting months or years to learn whether you won or lost, the setup is probably too risky for you.  
- **Patience beats greed.** It’s better to sit on the sidelines, sipping a cold beer, than to dive into a low‑probability trade that will likely drain your account over time.

In short, the next time a “once‑in‑a‑lifetime” investment opportunity winks at you from the horizon, ask yourself: *Do I really like the idea of waiting years to find out if it works?* If the answer is a hesitant “maybe,” you might be better off sticking to high‑probability setups— even if that means you have to watch a lot of boring, steady gains. After all, it’s far more satisfying to watch your portfolio grow reliably than to chase a mirage that disappears the moment you get close. Cheers to making decisions that your future self will thank you for!