# 211. Don’t Catch a Bad Mood  

**Source:** https://zerodha.com/varsity/chapter/dont-catch-a-bad-mood/  

---  

### The Eternal Optimist’s Club (aka “Winning Traders”)  

If you’ve ever watched a trader who never seems to lose his smile, you’re probably looking at a member of the **Eternal Optimist’s Club**. These guys (and gals) have a super‑power: they stay upbeat even when the market is doing the cha‑cha‑cha. Why? Because the market is a shape‑shifter. One day it’s a calm lake, the next it’s a raging river, and the next it’s a roller‑coaster built by a caffeinated engineer.  

What worked in a bull‑run last year won’t automatically work in a sideways market this month. You can’t sit on your couch, perfect a single strategy, and then expect it to be a forever‑green “set‑and‑forget” button. Yet many traders act like they’ve discovered the holy grail and then cry, “It’s a scam! No one makes money anymore. The pros have taken all the cake and left the crumbs for us amateurs!”  

> *“It’s all a sham. There’s no way to make money in trading anymore. The amateurs have left and there’s no way to take profits from professionals.”*  

That line sounds like a friend who just watched a horror movie and now refuses to step outside. It can shake your confidence faster than a surprise 10 % market dip. You might feel tempted to toss your charts, hug a mutual‑fund brochure, and say, “I’ll just let someone else do the hard work.” But if you really want to dance with the market and bring home the bacon, you have to **ignore the doom‑and‑gloom crowd** and keep your own optimism tank full.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/04/20060830-300x300.png)  

### Why the Pessimists Are Wrong (and Why That’s Good News for You)  

Seasoned traders have been around the block more times than a delivery driver on Christmas. They’ve seen markets swing from **boom‑town** to **bust‑city** and back again, like a sitcom that never stops rebooting. Their mantra? *“If you want to stay profitable, you have to keep looking for fresh ways to make money.”*  

So when a buddy whines, “Everything’s changed, there’s no more profit to be had,” you can politely nod and say, “Sure, it’s not a walk in the park, but it’s still a park with plenty of hidden paths.” Recognizing that **trading is hard** is actually a soothing mantra. It’s like admitting you’re not a superhero—then you stop feeling guilty every time you have to wear your cape.  

If you understand that the market’s mood swings are **not your personal fault**, you won’t waste energy beating yourself up. The market isn’t a spiteful ex; it’s just a giant, impersonal beast that follows its own rules—supply and demand, interest rates, geopolitical drama, and occasionally, a meme‑stock craze. Your job is to **refuse the pessimism**, pick yourself up after each tumble, and meet the next challenge with a grin (and maybe a cup of coffee).  

### Optimism Isn’t a Magic Pill—It’s the Fuel for the Engine  

Let’s get one thing straight: **being upbeat won’t magically turn you into Warren Buffett overnight**. But it is the *necessary* oil that keeps the profit‑making engine from seizing up. When you’re in a good mood, you’re more likely to:

1. **Think creatively** – you’ll experiment with new setups instead of staring at the same old candle pattern like a bored cat.  
2. **Adapt your style** – maybe you can’t squeeze a 10 % gain from a single trade anymore, but you could stack a series of 1‑2 % wins and still come out ahead.  
3. **Diversify** – you might move from tech stocks to commodities, or dip a toe into bond futures, just because the market is whispering “hey, I have other toys.”  

It won’t be a walk in the park, but with practice you’ll learn to **morph your trading personality** to fit the current market climate, rather than catching the collective pessimism that spreads like a bad cold when a lot of traders start losing money.  

### When the Grumps Start Gabbing, Keep Your Cool  

Picture this: a junior trader or an old‑timer (who’s probably been through the 2008 crash, the 2020 COVID swoop, and a few other “what‑the‑heck‑just‑happened?” episodes) mutters, “It’s impossible to profit now.” Instead of letting that **bad mood** infect your own vibe, remember:

* **Everyone’s unique** – you have a different account size, risk tolerance, and trading schedule than the guy next to you.  
* **Their problems aren’t yours** – maybe their account is too big for the strategies they love, or too small for the position size they need. Maybe they’re simply burnt out.  
* **Your mission is to stay on your own path** – keep hunting for tools, indicators, or setups that click with your style. The market is a massive buffet; there’s always something new on the menu if you’re willing to keep looking.  

So the next time you hear the “It’s over, give up!” chant, **don’t let it rattle your resolve**. Keep your optimism on standby, keep sharpening your edge, and keep scrolling through the sea of strategies until you find the one that makes you smile. After all, the best traders aren’t the ones who never lose hope; they’re the ones who **refuse to catch a bad mood** and instead keep dancing to the market’s ever‑changing beat. Cheers to that! 🍻