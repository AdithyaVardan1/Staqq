# 172. Out with the old and in with the new  

**Source:** https://zerodha.com/varsity/chapter/out-with-the-old-and-in-with-the-new/  

---  

> “Old habits are hard to break.”  
> “It’s hard to teach an old dog new tricks.”  

Both sayings are basically market‑psychology textbooks in rhyme.  We all love the cozy blanket of a routine, even when that blanket is made of yesterday’s losing trades.  A successful trader, however, has to be part‑time psychologist: keep the tricks that earn, toss the ones that burn.  So, why do our brains cling to the familiar, and how can we nudge them into trying something that isn’t *exactly* the same old song?  Grab a drink, and let’s break it down—one laugh‑filled step at a time.

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/03/20070306-300x300.png)

## 1. Self‑monitor like a hawk (but without the talons)

First thing’s first: you can’t fix what you can’t see.  Think of your trading habit as a leaky faucet.  If you never watch the drip, you’ll keep walking around with a wet floor and wonder why your socks are soggy.  The same goes for a trader who refuses to glance at the win‑loss ratio—maybe because the numbers look scarier than a horror‑movie marathon.

**Pro tip:** Pull up your trade journal, your broker’s P&L sheet, or even that screenshot you took three months ago and stare at it like you’re trying to spot a UFO.  The uncomfortable truth is often less terrifying than the imagined catastrophe you’ve been running from.  Most of us spend more mental energy **denying** a losing streak than we would spending on actually **fixing** it.  

When you finally give yourself a hard, honest look, you’ll probably discover two things:  

1. You’re not as terrible as the inner critic keeps telling you.  
2. You have enough mental bandwidth to actually devise a plan—because you stopped using that bandwidth to rehearse worst‑case scenarios in your head.

So, self‑examination isn’t a punishment; it’s a free therapy session that ends with a clear action list instead of a box of tissues.

## 2. Conquer Neophobia (the fancy word for “new‑thing‑phobia”)

Humans are hard‑wired to repeat actions that *feel* rewarding and to avoid those that feel like stepping on a LEGO.  Often the “reward” we’re chasing is the *absence* of pain—think “I won’t lose money on a market I don’t understand.”  That avoidance is called **neophobia**, and it’s the same instinct that makes a cat stare at a cucumber like it’s the end of the world.

In trading, neophobia shows up in two classic disguises:  

- **“I only trade X market, because that’s where I made my first profit.”**  
- **“New strategy? Too complex, I’ll stick to my trusty (but broken) moving‑average‑crossover.”**

Both may have a grain of truth—maybe X really *is* your strong suit, maybe the new strategy *does* have a learning curve.  The problem is when the fear **inflates** the downside to the size of a skyscraper.  If you let that fear run the show, you’ll miss out on the fresh opportunities that keep markets from becoming a boring, stagnant pond.

**The antidote?** Dip your toes, not dive head‑first.  Open a tiny position in an unfamiliar market or allocate a minuscule slice of your capital to a brand‑new system.  The loss, if any, will be so small that you can laugh about it over a beer, and the win—if it happens—will feel like a secret handshake with the universe.

## 3. Practice alternatives (and keep your expectations in check)

Now that you’ve stared down the fear monster, it’s time for the *real* work: practicing the new stuff.  This is where the “trial‑and‑error” dance becomes a “trial‑and‑*learning*” waltz.

- **Track everything.**  Just like you logged your old habits, log the new ones.  Did you enter a trade on the Nifty after a breakout?  How much did you risk?  What was the outcome?  Numbers don’t lie, even when your ego does.  
- **Set realistic expectations.**  Expecting to turn $10,000 into $100,000 in a week is about as realistic as expecting a cat to fetch your slippers.  Aim for incremental gains—maybe a 1‑2 % improvement over your baseline over a month.  When you meet—or even slightly miss—those goals, reward yourself with a small treat (like an extra slice of pizza).  When you miss by a wide margin, don’t beat yourself up; instead, ask, “What did the market teach me today?”

Remember, mastery is a marathon, not a sprint.  The more you practice, the more your brain rewires itself to treat the new strategy as “normal” rather than “scary.”  Before you know it, you’ll be adding fresh tactics to your toolbox the way a bartender adds new cocktail recipes to the menu—confident, creative, and a little bit cheeky.

---

**Bottom line:** Old habits cling tighter than a sticky note on a monitor, but they’re not indestructible.  By shining a brutally honest light on your performance, daring to step into the unknown with tiny, measured bets, and keeping your expectations human‑scale, you’ll turn that old‑dog‑phobia into a sleek, high‑performance trading machine.  Now go forth, try something new, and may your P&L be ever in your favor—cheers! 🍻