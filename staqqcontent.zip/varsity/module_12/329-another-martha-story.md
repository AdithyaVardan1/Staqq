# 329. Another Martha Story  

**Source:** https://zerodha.com/varsity/chapter/another-martha-story/  

---  

We’ve been hit with a *Martha‑Stewart‑apalooza* all weekend. The press can’t stop talking about the former lifestyle guru who got herself in a pickle by feeding the FBI a tall tale about a stock trade. Was she an easy scapegoat? Could she have dodged the cuffs with a different move? How does her little white‑lie stack up against the grand‑scale corporate frauds we read about in movies? You’re probably thinking, “Ugh, not another Martha column!” but hey, we’re hooked, and we’ll give you the low‑down with a side of snark.

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/06/20060731-300x300.png)

Martha’s saga is a masterclass in the **human‑error** that traders (and anyone who ever owned a pet rock) wrestle with daily. It’s not about pointing fingers at the domestic‑diva; it’s about spotting three simple habits that could have saved her a courtroom and saved us all a lot of popcorn:  

1. **Write off a tiny loss instead of nursing it to death**  
2. **Own up to your blunders instead of playing “I‑don’t‑know‑what‑you‑mean”**  
3. **Don’t let your ego’s “reputation‑police” sabotage sound decision‑making**  

We’ve chewed on these three in earlier chapters, but they’re worth a fresh look because—just like a bad haircut—they keep coming back if you don’t treat them. Let’s break each one down, bartender‑style.

---

### 1. Write off a relatively small loss – “cut your losses, not your hair”

Humans are **loss‑averse**—we’d rather stare at a blank wall than watch our net worth dip a few bucks. In Martha’s case, her broker tipped her off that ImClone CEO Sam Waksal was offloading his own shares. The savvy move? Flip the switch, admit the loss, and move on.  

Why? Because the dollar amount she’d have lost was *piddly* compared to her fortune. Imagine spilling a drop of water on a swimming pool; you’re still swimming. If she’d simply sold the ImClone shares after the FDA gave the drug a “no‑thanks” and the stock tumbled, she’d have locked in a **tiny** loss and avoided the whole circus.  

Instead, she clung to the idea that a tiny dip was unacceptable—like refusing to drink a cheap beer because it isn’t a single‑malt scotch. The result? A mountain of legal trouble that dwarfed the original, minuscule loss. Moral of the story: **write it off now, thank yourself later**.  

---

### 2. Admit your mistake – “the truth hurts, but the lie hurts more”

Another human quirk is the **need to be right**. We all love to be the guy who “knew it all along” (even when we were just guessing). When a trade goes sideways, the reflex for many is to **deny**—to tell yourself, “I’m fine, the market is just being weird.”  

In Martha’s drama, the smarter play would have been to own up to the FBI that she’d made a *bad* call on ImClone. The immediate sting—maybe a slap on the wrist or a brief PR crisis—would have been a *lot* less painful than the long‑term nightmare of obstruction charges.  

For traders, this translates to: when the market throws you a curveball, **acknowledge the miss**, re‑calibrate, and act. The longer you pretend everything’s A‑OK, the more you let a small mistake snowball into a **big‑bad‑wolf** of a problem. Think of it like spilling coffee on a shirt: clean it up right away, or you’ll end up with a permanent stain (and a very angry spouse).  

---

### 3. Guard your ego, not your empire – “reputation is nice, but jail‑time isn’t”

The final, most dangerous impulse is the **obsession with reputation**. Whether you’re a solo trader trying to impress your mother‑in‑law or a multinational conglomerate polishing its logo, the fear of looking “stupid” can make you do *crazy* things.  

Martha built an empire on the “Martha‑knows‑best” brand. Letting that brand get a blemish felt like watching your favorite superhero get a bad haircut—unthinkable! So she tried to **cover** the mistake, which only made the FBI and the courts dig deeper.  

In the trading world, you might be tempted to hide a losing position from your spouse, your friends, or even yourself. “I’m a *natural‑born* trader!” you proclaim, then refuse to admit the inevitable drawdown. That swagger can blind you to reality and keep you from taking the corrective action you need.  

The antidote? **Stay humble**. Nobody is a trading god; even the best have off‑days (yes, even Warren Buffett has a bad quarter now and then). Keep your feet on the ground, admit that you’re human, and you’ll survive the inevitable “storm of loss” without losing your mind—or your freedom.  

Martha’s reputation, once a glittering crown, ended up as a cautionary footnote. In hindsight, she would have been better off saying, “I messed up, and I’ll take the hit,” rather than trying to keep the sparkle at any cost.  

---

## Bottom line: Learn from Martha, not just for the drama, but for your own trading sanity  

The Martha Stewart episode isn’t just tabloid fodder; it’s a **psychology textbook** for anyone who ever places a bet on a chart. Human motives—loss‑aversion, ego, the need to look good—are powerful forces that can hijack rational decision‑making.  

- **Admit your limits** (you’re not a wizard, you’re a mortal with a spreadsheet).  
- **Stay honest** (the FBI, your broker, and your future self will thank you).  
- **Keep humility in your toolkit** (it’s cheaper than a PR crisis and works better than a lawyer).  

If you can laugh at Martha’s missteps, internalize the lessons, and apply them to your own trades, you’ll be on the road to **consistent, long‑term profitability**—and you’ll avoid the kind of headline that makes you wish you’d stayed home and watched reruns instead.  

So next time you’re tempted to cling to a losing position, pretend you’re Martha at a courtroom: “I *could* keep fighting, or I could just… **sell**.” Your future self will raise a glass in appreciation. Cheers! 🍸  