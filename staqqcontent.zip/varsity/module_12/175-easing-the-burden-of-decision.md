# 175. Easing the Burden of Decision  

**Source:** https://zerodha.com/varsity/chapter/easing-the-burden-of-decision/  

---  

Do you ever get that jittery feeling when you’re about to click “Buy” or “Sell,” as if your heart just booked a one‑way ticket to the edge of a roller‑coaster? You’re not alone. Even the most battle‑scarred trader—someone who’s survived a thousand‑plus round‑trips—gets a little case of the butterflies when the market finally bites. Think of it like a pianist who has been hammering away at a Chopin scherzo for weeks; the moment the lights go up and the audience’s stare turns into a silent “please‑don’t‑mess‑up” you can feel the nerves shimmying in the fingertips. The hard‑won lesson from experience is simple: you can’t polish yourself into a robot that never feels a pinch of anxiety.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/03/20070213-300x300.png)  

### Admit You’re Human (and a Bit Anxious)  

Owning up to the fact that you’re fallible is the first rung on the ladder to mastering the *inner game* of trading. If anxiety is the gremlin that keeps you from even placing a trade, you have to shine a flashlight on it and figure out a work‑around. Some rookies get so glued to the fear of “what‑if‑I‑lose‑everything” that they can’t even muster the courage to press that sweet little “Enter” key.  

One popular cheat‑code is to hand the heavy lifting over to a mechanical trading system. Think of it as a trusty sidekick that makes a lot of the micro‑decisions for you, so you can keep your stomach from doing somersaults. The system tells you when to jump in, when to jump out, and roughly how often those jumps turn into profit. By watching the system’s playbook, the mystery of “when does a trade actually work?” starts to fade, and with it, a chunk of the anxiety monster.  

### But No System Is a Magic Crystal Ball  

Let’s be clear: even the slickest algorithm can’t erase the uneasy feeling that comes from not knowing how a trade will end. And if a system *could* predict outcomes with 100 % accuracy, the market would soon get a collective case of motion‑sickness from the resulting traffic jam. Picture an S&P‑500 algorithm that spits out a “Buy at market close” signal every single day. If you obey it blindly, you’ll create a buying pattern that other bots (or crafty humans) will sniff out faster than a dog finds a dropped hotdog.  

Those observant traders will start front‑running you—buying just before your order hits the tape—while another opportunist might leapfrog both of you. That’s not a condemnation of mechanical systems; many of them genuinely work and can be a lifesaver for the emotionally‑fragile. The key is to remember that no system is a perpetual motion machine that lets you lounge on a beach while profits rain down like confetti for years on end.  

### The Fine Print on Mechanical Magic  

If a mechanical system were truly fool‑proof, its creator would probably lock it in a vault and never release it to the public (unless they wanted to fund a private island). So, if you decide to adopt a rule‑based strategy that looks solid on historical data, **stick with it long enough to “replicate” those past results**. Don’t bail the moment you see a single losing trade—think of it like a diet: you won’t see a six‑pack after the first salad, but you also won’t give up after the first slice of pizza.  

A mechanical approach gives the hyper‑nervous trader a sandbox to play in without the constant dread of “Did I just lose my shirt?” It lets you develop a feel for market rhythms, position sizing, and exit timing while the system handles the grunt work. So, if you’re a green‑horn who finds anxiety louder than the market’s chatter, give a well‑tested mechanical system a spin for a few weeks. It might just be the training wheels you need to graduate from wobbling on the bike to cruising the highway of the markets.  

---  

**Bottom line:** Anxiety is as inevitable as a coffee spill on a Monday morning, but you can soften its sting. A mechanical system isn’t a silver bullet, but it’s a solid starter pistol that can launch you toward a calmer, more confident trading mindset. Cheers to less sweat, more strategy, and maybe a few laughs along the way!