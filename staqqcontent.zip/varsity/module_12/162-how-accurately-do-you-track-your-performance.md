# 162. How Accurately Do You Track Your Performance?

**Source:** https://zerodha.com/varsity/chapter/how-accurately-do-you-track-your-performance/

---

Jim and Sam, two part‑time online investors who meet every Thursday for “stock‑soup and speculation,” were chewing on their burgers when the topic of portfolio returns came up. Jim, ever the skeptical sidekick, asked, “So, Sam, how did you *actually* do last year?”  

Sam, puffing out his chest like a peacock that just discovered a dividend, answered, “I nailed a 20 % return!”  

Jim raised an eyebrow that could double as a candlestick chart. “Really? That sounds a little… *too* good. Are you sure you didn’t just add a zero to your calculator?”  

Sam, confident that his laptop was the holy grail of proof, said, “I’ve got the numbers right here. Let me pull them up.”  

A few frantic clicks later, the screen revealed a sobering truth: Sam’s portfolio had actually grown **15 %**. He had overshot his own performance by roughly **5 %**—a classic case of “I‑think‑I‑did‑better‑than‑I‑did” that shows up in almost every investor’s memory when they try to recall results without a spreadsheet.

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/03/20070129-300x300.png)

---

### The Ego‑Shield: Why We See Ourselves Through Rose‑Coloured Glasses  

Let’s face it—nobody wants to be the guy who bought the dip on a stock that kept diving. Our egos love to dress up our track record in a tuxedo, even when the numbers are still in pajamas. When we don’t have a spreadsheet staring us in the face, it’s ridiculously easy to let **self‑serving bias** rewrite history.

Research in the wild world of behavioural finance shows that when people are asked to **predict** how well they’ll perform on a task, they sprinkle a little optimism on top, like extra sugar on their coffee. And when they’re asked to **remember** how they performed in the past, they tend to replay the highlight reel (the winning trades) while the blooper reel (the losers) gets fast‑forwarded or, worse, deleted.

The result? A rose‑coloured view of our own performance that’s about as accurate as a fortune‑telling hamster.  

---

### The “I‑Did‑Better‑Than‑I‑Did” Study  

A neat experiment by two Yale behavioural finance gurus—**Dr. William Goetzmann** and **Dr. Navav Peles**—puts numbers on this bias. They asked a decent‑sized sample of investors to recall their **return on investment for the previous year**. The answer? On average, investors remembered a performance **about 6 % higher** than the actual figure.  

In plain English: if you really earned 10 % last year, you’d probably swear you earned **16 %**. That’s a whole extra latte’s worth of confidence for free! The takeaway is crystal clear: **memory alone is a terrible accountant**.

---

### Why We Inflate Our Numbers (and Why It’s Not Just Bragging)

The psychological engine behind this optimism is simple: **self‑preservation**. No one enjoys admitting they bought at the top and sold at the bottom—it's a bitter pill, and our brains are programmed to avoid it. To keep our self‑image as “smart investor,” we subconsciously **up‑grade** our performance figures until they line up with the flattering narrative we like to tell ourselves.

If you keep letting this bias run wild, you’ll end up chasing phantom profits, tweaking strategies based on fantasies, and ultimately, **making the same mistakes over and over**. In other words, you’ll be the captain of a ship that thinks it’s sailing on a calm sea while it’s actually heading straight for an iceberg.

---

### The Simple (and Slightly Nerdy) Fix: Record‑Keeping Like a Pro  

Here’s the antidote that veteran traders swear by: **keep a meticulous trade journal**. Write down:

| What to Log | Why It Matters |
|------------|----------------|
| **Date & time** of each trade | Helps you spot patterns (e.g., “I always lose money on Mondays”). |
| **Ticker / instrument** | So you can later group performance by sector, style, etc. |
| **Entry & exit price** | The raw material for calculating real P/L. |
| **Position size** | Reveals whether you’re over‑leveraging yourself. |
| **Reason for trade** (setup, news, etc.) | Lets you test which strategies truly work. |
| **Profit / loss** (in cash & % terms) | The ultimate performance metric. |
| **Emotions** (e.g., “felt nervous”) | The secret sauce for behavioural analysis. |

When you **regularly calculate objective performance measures**—like total return, Sharpe ratio, win‑rate, average win/loss—you stop leaning on that unreliable, ego‑inflated memory. Instead, you get a **hard‑cold, numbers‑driven view** of where you stand.

---

### Seasoned Traders Don’t Fear the Mirror  

Professional traders treat their own performance record like a **daily health check‑up**. They know that the fastest way to survive (and thrive) in the markets is to **spot a problem early** and fix it before it becomes a chronic condition. That could be anything from a leaky risk‑management habit to a recurring “buy the dip at the bottom” syndrome.

So, **don’t let your biased recollection run the show**. Keep your actual numbers front‑and‑center—on a spreadsheet, a dedicated app, or a good‑old‑fashioned notebook—so you can glance at them at the end of each trading day and say, “Hey, that’s the real me, not the me who thinks I’m a wizard.”

---

### Bottom Line (with a Side of Humor)

- **Memory is a lousy accountant.** It likes to inflate your gains and shrink your losses.
- **Studies show we over‑estimate by ~6 %** on average—so your “20 % return” might really be “14 %.”
- **Ego loves a good story** about being a rock‑star investor; your trade journal loves the cold hard truth.
- **Record‑keeping isn’t just for tax season**—it’s the antidote to self‑delusion.
- **Check your numbers daily**. If your portfolio looks like a roller‑coaster, at least know whether you’re on the upswing or the downswing.

So the next time you’re at lunch bragging about your “stellar” returns, pull out that notebook (or screen) and let the numbers do the talking. Your ego will thank you, your bank account will thank you, and—best of all—you’ll finally stop confusing “I made 20 %” with “I *actually* made 15 %.” 🍻