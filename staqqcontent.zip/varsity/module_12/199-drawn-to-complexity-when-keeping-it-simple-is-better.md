# 199. Drawn to Complexity: When Keeping it Simple Is Better  

**Source:** <https://zerodha.com/varsity/chapter/drawn-to-complexity-when-keeping-it-simple-is-better/>

---

### The Woz‑story: When a Fancy Computer Was Over‑Engineered for a Recipe

Back in the **mid‑1980s**, the guy who helped birth the Apple II—Steve **Wozniak**—was asked to gaze into his crystal ball and predict the future of computing. In hindsight (and after a few decades of memes about “smart fridges”), he admitted he’d been **“too excited about the home‑computer hype.”**  

He argued that for ultra‑simple chores—think “store my grandma’s lasagna recipe” or “keep track of my sock inventory”—the good‑old **card‑file** (the original “Google Sheets” made of index cards) would do just fine. To drive the point home, he recounted a personal anecdote from when he went back to college to finish his **B.S. Electrical Engineering (BSEE)**.  

He lugged his beloved Apple II into the campus computer lab, only to spend **more time fiddling with the machine** than actually using it to solve the problem at hand. He’d built a whole computer to do something a **piece of paper and a pen** could accomplish faster. Of course, he didn’t foresee the **Internet** (or the fact that today’s smartphones can run a full‑blown spreadsheet while you’re waiting in line for coffee).  

The moral? **Complexity can be a shiny distraction**; sometimes the simplest tool is the most effective one.

---

### Are We Addicted to Fancy Gadgets, or Is It Just a Phase?

Fast‑forward to the **2020s** and we’re still in a love‑affair with tech. Every new gadget promises to make life easier—**PDAs, smart watches, AI‑powered to‑do lists**—but do we *really* need to stash our appointments on a pocket‑sized computer when a sticky note on the fridge does the trick?

In the world of **trading**, technology has indeed been a game‑changer. Real‑time charts, order‑book depth, and instant news feeds give us a **microscopic view** of market pulse that our granddad could only dream of. Yet, veteran traders keep waving a caution flag: “Don’t let the bells and whistles **drown out the raw price action**.”  

If you skim through a glossy trading magazine, you’ll see a parade of **hyper‑complex indicators**—some look like the output of a NASA launch console. The seasoned pros, however, often swear by the **bare‑bones duo of price and volume**. They claim you can rake in **big profits** with nothing more than a clear view of where the market is moving, not where some algorithm says it “should” be.

---

### The “Stat‑Snooze” Problem: When Fancy Formulas Feel Like a Magic Show

Anyone who survived an introductory statistics class knows the feeling: **“Why does this formula have a Greek letter in it?”** The same sentiment shows up in trading literature. Some authors seem to think that the **more letters and symbols** you sprinkle into a formula, the **more innovative** it looks.  

Take a look at the **Simple Moving Average (SMA)**—the poster child for “simple” indicators. Before we dive into its mystique, let’s ask the age‑old question: **What *is* an average?**  

In plain English, an average (or **mean**) is just the **center point** of a set of numbers. It tells you, “If we spread everything evenly, where would the middle land?” Your stats professor probably warned you that the mean is **fragile**—a single outlier can yank it away from the true center. In the trading world, that outlier is often a **price spike** (think “flash crash” or “overnight news bomb”).

**Lesson #1:** If a huge price jump sneaks into the window you’re averaging, the SMA gets **pulled toward that spike**, giving you a distorted picture. It’s not sorcery; it’s just a **summary** of the raw price series.

---

### Peek Behind the Curtain: The Data That Powers the SMA

When you stare at an SMA line on a chart, resist the urge to treat it like a **prophetic oracle**. Instead, **zoom out** to a higher timeframe—say, from a 5‑minute chart to a daily chart—and **inspect the actual price points** that fed the calculation.  

Remember:  

1. **Mean ≠ Magic** – It’s just a summary.  
2. **Outliers Matter** – One rogue candle can skew the whole line.  
3. **Context Is King** – Look at the underlying price action, not just the smoothed curve.

If you find yourself obsessing over the SMA’s “crosses” while ignoring the **real price spikes and volume surges**, you’ve fallen into the same trap that makes some traders buy a $500 indicator that does the same job as a free spreadsheet.

---

### The “Wizard of Oz” Rule: Don’t Be Fooled by the Curtain

There’s a **basic data‑analysis principle** that applies whether you’re measuring the **average temperature in July** or the **average price of a stock**:  

> **Always examine the raw data that generated the statistic.**  

If you only stare at the summary (the SMA line, the RSI curve, the “Super‑Duper‑Trend‑Predictor‑3000”), you’re basically watching a **movie trailer** and claiming you understand the whole plot.  

Complex indicators often masquerade as **black‑box wizardry**. In reality, they’re just **re‑packaged price and volume numbers** dressed up in fancy math. The more layers you add, the higher the chance you’ll **miss the obvious**—like a price breakout that a simple **price‑plus‑volume** check would have caught instantly.

---

### Bottom Line: Keep It Simple, Stupid (But Make It Fun)

- **Complex ≠ Better** – More lines of code don’t automatically mean more insight.  
- **Simplicity Wins** – A clean chart with price, volume, and perhaps a single moving average can be more powerful than a dashboard full of blinking lights.  
- **Stay Curious** – Ask yourself, “What raw numbers am I summarizing?” before you hand over your hard‑earned cash to an over‑engineered tool.  

So next time you’re tempted to download the latest “AI‑powered, quantum‑enhanced, blockchain‑secured trading app,” remember Steve Wozniak’s Apple II saga: **sometimes a pencil and a piece of paper (or a humble spreadsheet) will get the job done faster, cheaper, and with fewer headaches**.  

And that, dear reader, is why **simple can be spectacular**—especially when it saves you from accidentally buying a $1,000 “trend‑detector” that’s really just a glorified average. Cheers to keeping things **simple, smart, and a little bit sassy**! 🍻