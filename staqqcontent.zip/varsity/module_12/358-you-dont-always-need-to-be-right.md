# 358. You Don’t Always Need To Be Right  

**Source:** <https://zerodha.com/varsity/chapter/you-dont-always-need-to-be-right/>

---

### The “I‑must‑be‑right‑every‑time” myth  

If you’ve just started dabbling in the market, you’ve probably heard the gospel: *“If you’re not right, you’re dead.”* It’s like a trader’s version of “Don’t talk to strangers.” The reality? You can be wrong a lot and still finish the night with a smile (and maybe a tiny profit). The secret sauce is **risk management**, not psychic powers.  

To prove the point, let’s walk through a deliberately simple—almost cartoonish—example. Grab a coffee, because the math is so gentle it’ll feel like a lullaby.

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/06/20060411-300x300.png)

---

### Meet John, the (hypothetical) cautious cowboy  

- **Capital:** $150,000 (that’s about the price of a decent used car, or a small island in the Caribbean if you’re optimistic).  
- **Risk per trade:** 3 % of the whole pot → $150,000 × 0.03 = **$4,500**. John tells himself, “If I lose this, I can still afford the next round of tacos.”  
- **Stop‑loss rule:** Sell if the price drops **8 %** below the entry.  
- **Take‑profit rule:** Sell if the price climbs **20 %** above the entry.  

> **Disclaimer:** We’re not saying “copy‑John.” These numbers are just a sandbox to illustrate a concept, not a trading prescription.

---

### Crunching the numbers (with a dash of humor)  

- **If the trade goes south:** 8 % of the $4,500 stake disappears → **$360 loss**.  
- **If the trade goes north:** 20 % of the $4,500 stake appears → **$900 gain**.  

Now imagine John fires off **10 trades** with those exact rules.

| Outcome | # of trades | Profit / loss per trade | Total |
|--------|-------------|------------------------|-------|
| Winners | 3 | +$900 | **+ $2,700** |
| Losers  | 7 | –$360 | **– $2,520** |
| **Net** |   |                        | **+$180** |

So even with a **70 % losing‑trade rate**, John ends the session **$180 richer**. That’s not enough to buy a yacht, but it’s a proof‑of‑concept that you don’t have to be a prophet to stay afloat.  

*Side note:* All of this assumes you’re paying **less than $5 round‑trip** in commissions (think discount broker, not your friendly neighborhood full‑service firm). Otherwise the $180 evaporates faster than a cheap cocktail on a hot night.

---

### “That’s boring” – how to turn the modest profit into something worth bragging about  

The above setup is deliberately conservative—like wearing a raincoat in a drizzle. If you crank the odds up a bit, the math gets a lot sweeter.

#### 50 % win rate scenario  

- **Winners:** 5 × $900 = $4,500  
- **Losers:** 5 × $360 = $1,800  
- **Net profit:** **$2,700**

That’s a 1.8 % return on the original $150k capital in a single batch of ten trades—nothing to write home about, but you can see the slope is steeper.

#### Let the winners run  

In the original plan, John sells as soon as he hits a 20 % pop. What if he lets a few trades ride to **50 %** instead?  

- New profit per successful trade: 50 % of $4,500 = **$2,250**.  
- Keeping the same 3‑out‑of‑10 win ratio: 3 × $2,250 – 7 × $360 = $6,750 – $2,520 = **$4,230**.  

Now the same “mostly wrong” trader walks away with a **$4,230** gain—over **23 times** the original $180! The moral? A well‑placed exit rule can turn a modest “I’m okay” into a “Whoa, not bad!”

---

### The big takeaway (served with a side of wit)  

1. **You don’t need to be right all the time.** A solid risk‑to‑reward ratio (here, $900 vs. $360) lets you survive a sea of losers.  
2. **Mechanics matter more than mysticism.** Stick to a pre‑defined stop‑loss and take‑profit, and you’ll keep emotions like fear and greed from hijacking the ship.  
3. **Start small, think modest.** When you’re a rookie, the goal is *survival* and *skill‑building*, not turning $150k into a trillion.  
4. **Upgrade as you learn.** As you identify “high‑probability setups,” you can risk a tad more or tighten stops, but always keep the math in front of you.  

In other words, treat your trading like a well‑behaved bar‑tab: you set a limit, you know how much you’re willing to lose on each round, and you walk away before the bill gets embarrassing.  

**Bottom line:** With disciplined risk management, you can be wrong a lot, lose a few dollars on each misstep, and still end the night with a profit. That’s the kind of “right” that matters—quiet, steady, and a little less stressful than trying to be a market oracle. Cheers to the wrong‑but‑profitable trader in all of us!  