# 254. Discipline and Self‑Control: Monitor It and Increase It  

**Source:** https://zerodha.com/varsity/chapter/discipline-and-self-control-monitor-it-and-increase-it/  

---  

You’ve probably heard it a thousand times while sipping coffee at a broker‑convention: *“Discipline is the secret sauce of trading success.”* In fact, the word shows up in almost every trading textbook and even makes cameo appearances in book titles (think *“Discipline‑Driven Trading”* or *“The Disciplined Trader”*). So why does everyone keep beating the drum about discipline?  

Because trading is, at its core, a game of odds. Imagine you’ve found a strategy that, over the last two years, has nailed a **85 %** win‑rate. That sounds like a golden ticket, right? The math says you have an 85 % chance that the next trade will be a winner **if** the conditions stay the same. In other words, the law of large numbers will eventually reward you—*if* you keep playing the game the same way over and over.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/04/20060526-300x300.png)  

But life (and markets) love plot twists. A sudden shift in volatility, a surprise policy announcement, or even a rogue meme stock can knock the wind out of your strategy’s sails. When that happens, a trader who lacks discipline is like a kid in a candy store who suddenly spots a donut—*they’ll abandon the plan and chase the shiny thing.*  

If the strategy truly does have a high probability of future success, the only way to harvest the “law of large numbers” is to **execute the trade exactly as the plan dictates—again and again**. The disciplined trader trusts the edge enough to put money on it, follows the rules to the letter, and lets probability do its heavy lifting. The undisciplined trader? They dip in and out, sometimes following the plan, sometimes winging it because “the vibe feels right.”  

That wobble is the difference between a steady‑as‑she‑goes portfolio and a roller‑coaster that makes you scream “I’m out!” at every loop. Discipline is indeed a key ingredient, but not everyone is born with a superhero‑level self‑control. First, you need to figure out **where you stand** on the discipline meter, and then you can start cranking it up like a volume knob.  

---

## The Personality Side of Discipline (and Why It’s Not All Sunshine)

Psychologists have been poking at discipline and self‑control for ages. Some folks are practically monks of routine: they pay off every credit‑card bill on the due date, never show up late for a meeting, and have a spreadsheet for everything from grocery trips to bedtime. Those traits sound like a trader’s dream, right?  

**Except**—and this is the plot twist—people who are ultra‑disciplined in daily life often *shy away* from risk. They love the “sure thing,” but trading is rarely a sure thing (unless you’re a time‑travelling wizard). The market rewards those who can tolerate a little uncertainty, and that’s why many traders are a bit more *“wild child”* than the spreadsheet‑obsessed accountant.  

They’re not out there looking for a bungee jump off the Golden Gate every night, but they’re comfortable with a little edge‑of‑your‑seat excitement. In other words, they have **relatively lower discipline** when it comes to risk‑taking. That’s why trading coaches keep preaching the virtues of self‑control: they want you to be the kind of person who can **both** stick to a plan *and* sit calmly while the market does its dramatic soap‑opera.  

So, how do you stack up? Do you find yourself constantly *“just checking the chart one more time”* instead of pulling the trigger? Do you wish you could lock the door on impulse buys like you lock the fridge after midnight? If you’re nodding, keep reading—you’re about to get a free (and slightly entertaining) exercise to boost your self‑control muscles.  

---

## A Reality Check: How Disciplined Are You Outside the Charts?

Take a mental inventory of your everyday habits.  

| Habit | Typical Outcome | Trading Parallel |
|-------|----------------|------------------|
| **Being late** | Missed trains, annoyed colleagues | Missing entry windows or exiting too early |
| **Overspending** | Empty wallet, regret at checkout | Over‑sizing positions or chasing losses |
| **Breaking promises** | Trust issues with friends/family | Ignoring stop‑loss rules or deviating from the plan |

You don’t have to be a *perfect* monk to be a good trader, but the habits you nurture in daily life tend to spill over into the market. If you’re constantly battling the urge to buy that third latte, you might also battle the urge to add an extra lot when the price dips. The good news? **You can train yourself.**  

### The “Control‑Everything‑For‑Two‑Weeks” Challenge

1. **Pick three life‑domains** where you’re a bit lax. (Examples: calories, cash, screen time.)  
2. **Set a concrete, measurable rule** for each.  
   * *Calories*: No more than 2,200 kcal per day.  
   * *Spending*: No discretionary purchases over $20.  
   * *Leisure*: No more than 1 hour of video games per evening.  
3. **Track relentlessly**—use an app, a notebook, or a sticky note on your monitor.  
4. **Review weekly** and note the “wins” and the “oops moments.”  

What you’ll discover is often eye‑opening: you probably *underestimate* how much impulse‑driven you are. And when you start tightening those bolts in life, you’ll notice a shift in your trading psyche. Your brain gets accustomed to saying “no” in low‑stakes situations, making it easier to say “no” when the market whispers “just one more trade.”  

---

## Why This Exercise Works (A Tiny Bit of Science)

When you repeatedly practice self‑control in one area, you’re actually **strengthening a neural pathway** that governs willpower. Think of it like a muscle: the more you flex it, the stronger it gets. Psychologists call this the *“self‑control strength model.”*  

By forcing yourself to stick to a calorie limit or a budget, you’re training the prefrontal cortex (the part of the brain that says “stop, think!”) to fire more reliably. Later, when you’re staring at a chart that’s doing the cha‑cha‑cha, that same brain region helps you resist the urge to deviate from the plan.  

In short, the discipline you build at the dinner table can become the discipline you need in the trading arena. And the best part? You get a healthier waistline *and* a healthier portfolio. Win‑win!  

---

## Bottom Line: Discipline Isn’t a One‑Time Gift, It’s a Skill You Can Grow

Trading success isn’t about having a crystal ball; it’s about **playing the odds** and **doing it consistently**. Discipline is the gatekeeper that lets you reap the statistical edge your strategy offers. If you feel your self‑control is more “yo‑yo” than “yoga,” treat it like any other trading skill: practice, monitor, and improve.  

- **Monitor**: Keep a journal of both trading and everyday decisions.  
- **Measure**: Note when you stick to the plan vs. when you stray.  
- **Increase**: Use the two‑week life‑control challenge (or a longer version) to beef up that willpower muscle.  

Remember, even the most disciplined traders have off‑days. The goal isn’t perfection; it’s **progress**. So grab a notebook, set a few modest life rules, and watch how that extra ounce of self‑control starts to show up in your trade‑execution.  

In the grand casino of markets, discipline is the *only* thing that keeps the house from winning every single round. Keep polishing it, and you’ll be the one laughing all the way to the bank—preferably after a well‑earned, disciplined trade. 🍻