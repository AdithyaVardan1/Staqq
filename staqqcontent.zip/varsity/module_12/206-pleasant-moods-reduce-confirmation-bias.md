# 206. Pleasant Moods Reduce Confirmation Bias  

**Source:** https://zerodha.com/varsity/chapter/pleasant-moods-reduce-confirmation-bias/

---

Whether you’re the kind of investor who dreams of holding a stock until you’re old and gray, or the type who flips charts faster than a bartender flips bottles, you’re constantly drowning in a sea of data. Charts that look like abstract art, analyst ramblings that could double as bedtime stories, and financial statements longer than a Netflix binge‑watch list—all of it has to be filtered, weighted, and fed into that magical gut feeling of yours. In the end, even the most seasoned trader is basically making an educated guess. Let’s face it: humans are not sterile, logical robots; we’re a messy blend of emotions, ego, and occasional brilliance.

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/04/20060816-300x300.png)

One of the sneakiest mental gremlins that haunts every market participant is **confirmation bias**. Picture this: you’ve cooked up a trading plan, the stakes feel as high as a skyscraper, and the fear of a costly mistake is humming in your ear like a cheap ringtone. Under that pressure, instead of playing detective and weighing every clue impartially, you start gravitating toward anything that whispers, “Yep, I was right!” while conveniently tuning out the dissenting voices. It’s the brain’s version of only listening to the people who say you look good in that shirt—useful in dating, disastrous in finance.

If you genuinely want to make decisions that aren’t just wishful thinking in a fancy suit, you have to **fight the urge to hunt for supporting evidence**. A good rule of thumb is to spend *more* time hunting for data that **challenges** your hunch than data that pats it on the back. Think of it as playing devil’s advocate for yourself—except the devil wears a spreadsheet and a skeptical eyebrow.

### How do we kick confirmation bias to the curb?

Enter a 2006 study by Jonas, Graupmann, and Frey (yes, those are real scholars, not just random usernames on a forum). The experiment went something like this:

1. **Step 1 – The Decision:** University students were handed a decision to make—nothing too life‑changing, just enough to get their competitive juices flowing.  
2. **Step 2 – Mood‑Manipulation Movies:** After picking a side, they were shown short clips designed to put them in one of three emotional states: *bad mood* (think “I just spilled coffee on my shirt”), *pleasant mood* (think “I just found a forgotten $20 in my coat”), or *neutral* (the emotional equivalent of staring at a wall).  
3. **Step 3 – Information Buffet:** They were then given a smorgasbord of statements—some that bolstered their original pick, others that argued against it. The experimenters also dangled a “right answer = reward” carrot in front of them.

Predictably, **everyone** showed the classic bias of gravitating toward confirming info. But—and this is the juicy part—those who were in a **pleasant mood** behaved differently. They were *more likely* to skim past the feel‑good, self‑affirming tidbits and actually chew on the contrary evidence. In other words, a happy brain is a more open brain, at least when it comes to double‑checking a trade.

### What does this mean for your trading (or life) strategy?

First, congratulations—you’ve just earned a scientific excuse to listen to your favorite feel‑good playlist before market open. When you’re in a good mood, you’re less prone to the tunnel‑vision that makes you see only green lights on your chart and ignore the red ones.

So, here’s a cheeky, actionable checklist:

- **Start your day with something that lifts you:** a funny meme, a quick walk, or that third cup of coffee that *actually* makes you smile (not just jittery).  
- **Deliberately seek the opposite:** For every bullish signal you love, find at least one bearish counter‑argument before you hit “buy.”  
- **Reward yourself for being contrarian:** If you manage to spend 60 % of your research time on disconfirming evidence, treat yourself to a small victory—maybe a fancy latte or an extra episode of that show you pretend you don’t binge.  
- **Remember the stakes:** The “right” decision in the study was tied to a reward, just like your real‑world profit goal. A pleasant mood nudges you toward the more accurate path, but you still have to do the legwork.

In short, **cultivate a winning attitude** the way you’d tend a a garden—water it, give it sunlight, and pull out the weeds of bias whenever they sprout. When your mood is bright, your intuition becomes a sharper, less‑biased compass, pointing you toward decisions that are grounded in reality rather than wishful thinking.

So next time you feel the urge to scroll only the headlines that say “XYZ stock is going to moon,” ask yourself: *Am I in a good mood, or am I just craving a dopamine hit?* Flip a mental switch, chase the dissenting data, and watch your trading confidence (and perhaps your portfolio) climb—without the nasty side‑effects of confirmation bias. Cheers to happy brains and smarter trades!