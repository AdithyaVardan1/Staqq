# 239. Decision‑Making Biases: A Primer  

**Source:** <https://zerodha.com/varsity/chapter/decision-making-biases-a-primer/>

---

Our “common‑sense” brain is a pretty decent off‑the‑cuff decision‑maker—most of the time it gets us from the kitchen to the office without a crash. But every now and then it steers us straight into a wall of wrongness. That oddball behaviour caught the eye of a couple of psychology rockstars, Amos Tversky and Daniel Kahneman, who started whispering that ordinary thinking isn’t always the picture‑perfect, data‑driven robot we’d like to imagine.  

In an ideal world you’d have a cold, hard‑as‑a‑rock decision engine that only ever looks at numbers, charts, and verified facts. Humans, however, are more like improv comedians: we improvise when the script (i.e., the data) isn’t on hand. When the numbers are missing, we lean on **heuristics**—fancy talk for “rules of thumb,” “mental shortcuts,” or “my gut says…”.

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/04/20061108-300x300.png)

## The classic “A or B” brain‑teasers

Let’s walk through a couple of the favorite Tversky‑Kahneman demos that make you go, “Whoa, my brain is pulling a fast one on me.”  

1. **Which is more common in English?**  
   - (A) Words that *start* with the letter **K** (think *kind, kite, kangaroo*).  
   - (B) Words that have **K** as the *third* letter (think *make, lake, bark*).  

2. **If you’re wandering around the Middle East, which scenario is you’re more likely to bump into?**  
   - (A) A terrorist attack.  
   - (B) A traffic accident.  

Ask a random group of volunteers these two questions and watch the majority shout “**A**!” as the obvious answer. Why do they do that? Because, as Tversky and Kahneman point out, we rarely have the actual frequency tables memorized in our heads. We have to **dig into memory**, and that’s where the fun (and the bias) begins.

### The word‑game illusion

When the brain tries to decide how many English words start with K, it instantly summons a handful of vivid examples—*kangaroo, ketchup, karaoke*—because they’re perched right at the front of the mental alphabet shelf. Finding a word where K hides in the third slot is a lot tougher; you have to rummage through *make, break, balk* and the like, which feels like looking for a needle in a haystack of letters.  

Because it’s easier to **recall** the “K‑at‑the‑beginning” examples, we *feel* there are more of them. The reality check? A quick scan of a dictionary (or a simple script) shows that **there are actually more words with K in the third position** than words that start with K. Our memory, not the dictionary, was pulling the strings.

### The Middle‑East mis‑perception

Same story, different stage. The news cycle (and, let’s be honest, binge‑watching thriller series) floods us with dramatic footage of terrorist attacks—explosions, dramatic chases, the whole Hollywood‑style montage. Traffic accidents? Those are the everyday “meh” stories that slip under the radar unless you’re stuck in a jam yourself.  

So when asked which is more common, our brains pull the **vivid, emotionally charged** terrorist‑attack memories to the fore, leading us to conclude that they happen more often than fender‑benders. The hard data, however, show a very different picture: **traffic accidents far outnumber terrorist incidents** in the region. Once again, memory is masquerading as statistics.

## The Availability Heuristic – Your Brain’s “What’s Easy to Recall” Shortcut

Tversky and Kahneman gave this mental shortcut the snazzy name **availability heuristic**. If a memory pops up quickly, easily, and with a lot of emotional sparkle, the brain treats it as if it were *more frequent* in the real world.  

In many day‑to‑day scenarios that’s perfectly fine—if you can’t look up the exact number of coffee beans you’ve consumed, you might just estimate based on the last few cups you remember. But the heuristic becomes a trap when the stakes are higher than choosing a latte size. If you need a solid decision (say, whether to invest in a certain stock, or whether to wear a helmet on a bike ride), you should **pause, chase the hard data, and not let the most vivid memory dictate the outcome**.

## Why Behavioural Economists Care (And Why You Should Too)

The financial world fell head over heels for Tversky and Kahneman’s insights because markets are basically giant, noisy versions of those brain‑teaser experiments. Traditional economists assumed markets were made of perfectly rational agents crunching numbers like souped‑up calculators. Reality? Traders panic when a headline screams “Oil Crisis!” even if the underlying fundamentals haven’t moved a hair.  

Behavioural economists sniff out these “irrational” decision patterns to explain why markets wobble, why bubbles form, and why you sometimes buy a stock just because you *remember* a friend bragging about it last week. If you can spot when your own mind is pulling the availability heuristic (or any other bias) on you, you can dodge a lot of costly mistakes—like buying a “sure thing” that’s actually a hype‑driven mirage.

### Bottom line for the bar‑side philosopher in you

- **Memory is a slick magician:** it makes the most dramatic (or alphabet‑friendly) examples appear more common than they really are.  
- **Hard data beats hot gossip:** when the decision matters, pull up the spreadsheet, the official stats, or at least a reliable source—don’t rely on the most Instagram‑ready story in your head.  
- **Spot the bias, save the cash:** knowing that your brain loves the availability heuristic lets you catch yourself before you make a pricey “gut‑feel” move.

So next time you’re about to decide whether to jump on the latest crypto hype, or whether to assume a new tech startup is a unicorn because a friend’s tweet made it look shiny, ask yourself: *Is this based on something that’s actually easy to count, or just something that’s easy to remember?*  

If it’s the latter, it might be time to grab a coffee, fire up a spreadsheet, and give your brain a polite “thanks, but I’ll need the real numbers.” Cheers to smarter (and funnier) decisions!