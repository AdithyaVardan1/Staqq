# 196. The Detrimental Comparison  

**Source:** https://zerodha.com/varsity/chapter/the-detrimental-comparison/

---  

Jim has been trading for six months. His performance isn’t spectacular, but it isn’t too bad either. He’s made a decent return. But Jim isn’t satisfied. He’s been reading “Market Wizards” and reading posts on trading websites, and he can’t understand why his performance isn’t better. “Why are my profits so small compared to everyone else? I must really be a loser,” he thinks. Jim has made an understandable, but a fundamental mistake.  

He has compared himself to other traders, noted that he isn’t doing as well, and has concluded that he is inadequate. Although comparing ourselves to others can help motivate us to do better, it is often so discouraging that it tends to be more detrimental than beneficial. It’s useful to avoid making such comparisons.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/03/20061117-300x300.png)  

## Why do we compare ourselves to others?  

There are a variety of possible reasons. It could be out of sibling rivalry. It could be because our parents or teachers taught us that we should do better than our peers, and gauging the performance of others is the best way to do that. It could be that many times, we don’t know what “good” performance is and it makes sense to see how others are doing so as to get an accurate picture of what is acceptable performance.  

When it comes to trading, it makes sense to wonder about other traders’ performance. Since most novice traders blow out within a year, many are curious as to whether it is even possible to achieve profitability. (It is possible, but it is extremely important to understand the conditions under which consistent profitability occurs.) It is useful to know that some traders are able to maintain a consistent level of profitability after years of hard work and skill‑building. Knowing that trading consistently is feasible will motivate you.  

## The double‑edged sword of comparison  

By knowing that it is indeed possible to make a profit, you’ll work hard because you know that there is a certain payoff in the end. But usually, comparing ourselves to others can do more harm than good. If we are doing more poorly, we’ll feel inadequate. And it isn’t always the case that we are performing below par. Each trader has his or her own personal history or circumstances that he or she brings into trading. People differ in terms of personality, investment capital, life experiences, and the market conditions under which they trade. Any or all of these factors can influence one’s trading performance. It makes little sense to beat yourself up because you haven’t achieved a level of performance equal to someone else who had advantages that you didn’t have.  

> **Pro tip:** Think of traders as different flavors of ice‑cream. Some are pistachio, some are double‑chocolate, and some are “I‑only‑eat‑vanilla‑because‑I‑don’t‑like‑risk.” Comparing a pistachio scoop to a double‑chocolate one isn’t fair—both are delicious in their own right, but they’re made with different ingredients.  

## The only sensible benchmark: You, yourself  

In the end, the only person you can compare yourself to is you. If you make any comparisons at all, it should be against your own past performance, not someone else’s. In addition, you should only examine your past performance in relation to similar market conditions. If you made a 30 % profit in the up‑trending market of the past year, for example, you shouldn’t berate yourself for performing less well in the markets of recent weeks. Again, comparisons must be made with caution, and in the end, they can do more harm than good.  

### A quick sanity‑check checklist  

1. **Same time‑frame?** Compare a 6‑month run‑up to a 6‑month run‑down, not a 6‑month run‑up to a 1‑year bull run.  
2. **Same capital?** A trader with ₹10 lakh can ride larger positions than someone with ₹50 k; the risk‑adjusted return will differ.  
3. **Same market regime?** Trend‑following systems shine in bull markets, mean‑reversion systems shine in sideways markets. Compare apples to apples, not apples to oranges.  

## Why the successful don’t obsess over others  

Successful people in all fields avoid making comparisons to others. In the end, the only person’s opinion that matters is your own. If you believe you are doing well, then that is all that matters. So when you find yourself comparing yourself to others, stop. Look inward. It is just you, the markets, and no one else. The more you can focus on your own standards, the more profitable you’ll be.  

> **Bottom line:** Stop stalking your “trading idols” on social media like a jealous ex. Instead, keep a trading journal, review your own edge, and celebrate the little wins. Your future self will thank you—maybe even buy you a celebratory drink when you finally crack that elusive 20 % annual return without losing sleep over someone else’s shiny P&L.  

---  

*Remember: the market doesn’t care whether you’re better than Bob or worse than Alice. It only cares whether your strategy is profitable enough to keep you from living off instant noodles. So keep the comparison game in the locker, and let your own numbers do the talking.*