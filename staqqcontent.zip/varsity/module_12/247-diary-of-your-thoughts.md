# 247. Diary of Your Thoughts  

**Source:** https://zerodha.com/varsity/chapter/dairy-of-your-thoughts/  

---  

Ever pulled a classic “oops‑I‑did‑it‑again” move in the markets? Picture this: you’re about to jet off on a two‑day road‑trip with the kids, the car’s packed, the snacks are questionable, and you think, *“I’ll just set a protective stop and swing by an internet café once a day to keep an eye on the trade.”*  

Spoiler alert: the café never materialised. Between wrangling toddlers, navigating traffic‑induced road‑rages, and debating whether the GPS should be set to “scenic route,” you forget to glance at the screen. The stock you were watching decides to take a nosedive, and you end up losing more than the modest 1‑2 % you’d pencilled in as your “acceptable‑loss” budget.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/04/20061027-300x300.png)  

### The “I‑knew‑it‑but‑I‑didn’t‑care” Realisation  

Later, sipping a latte and scrolling through the loss chart, you mutter, *“Yeah, I knew this could happen, but I just didn’t give a hoot.”* For many traders the culprits aren’t massive market swings but the tiny, everyday annoyances that creep in: a heated spat with the spouse, a late‑night Netflix binge that robbed you of sleep, or a surprise “hey, can you pick up the kids?” text right before the market opens.  

These micro‑stressors add up, turning you into a jittery, half‑asleep version of yourself. In that state, you start making the kind of blunders that would be laughable if you weren’t the one losing the cash.  

### Enter the Trading Diary (Your Personal “Therapist‑in‑a‑Notebook”)  

So, how do you stop the little things from hijacking your trade? One surprisingly low‑tech solution is to **keep a diary of your thoughts and emotions throughout the trading day**.  

Here’s a sample entry that could have saved a trader from a painful loss:  

> **Date:** 12 Oct 2025 – “The Day of the Unwanted Fax”  
>   
> **Personal backdrop:**  
> - Dinner at the neighbour’s place; conversation drifted into a deep dive on interest‑rate policy and the fact that the market has been down for the second straight week.  
> - Got stuck in a “what‑if‑the‑next‑day‑drops‑even‑more” spiral.  
> - Sleep? Minimal. Woke up feeling like a zombie after a night of tossing and turning.  
> - Spouse misplaced an important set of papers; I had to run to the office and fax them before the market opened.  
>   
> **Emotional snapshot:**  
> - Annoyed that my day was being hijacked by paperwork.  
> - Tired, a touch irritable, and with a lingering sense that I wasn’t operating at 100 %.  
> - Not exactly pumped to place a trade; my enthusiasm was somewhere between “meh” and “maybe tomorrow.”  
>   
> **Trading outcome:**  
> - Followed the plan on paper, but the price plunged sharply.  
> - I was caught off‑guard, didn’t wait to see if it was a temporary dip, and closed the position at a loss.  
> - In hindsight, a patient “wait‑and‑see” could have hit my profit target.  

### What the Diary Tells You  

That entry lays bare the truth: **the “little things” were the real villains**. The trader’s mental bandwidth was drained by a sleepless night, a marital‑paper‑fiasco, and a side‑conversation about macro‑economics that left him in a perpetual state of worry.  

When you **log trades— even just a handful—** you create a searchable trail of context. Over weeks or months you’ll start spotting patterns, such as:  

- **Late‑night binge‑watching → groggy mornings → sloppy entries**  
- **Spousal arguments → heightened irritability → premature exits**  
- **Skipped gym sessions → low energy → failure to stick to stop‑losses**  

Identifying *which* events consistently erode your edge is the first step toward shielding yourself from them.  

### Pinpointing Your Personal “Trade‑Killer” Triggers  

Every trader has a unique set of mood‑swing generators. For the diary‑writer above, the trouble‑makers were **poor sleep and interpersonal hassles**. Others might find that:  

- Missing a regular morning run makes them feel sluggish.  
- Hearing distressing news about a family member saps their concentration.  
- A sudden caffeine‑free morning leaves them jittery and indecisive.  

Whatever the trigger, once you’ve named it, you can start **building buffers** around it.  

### Practical “Do‑Not‑Disturb” Strategies  

Seasoned traders and coaches often preach a simple mantra: **If the little things have tipped you off‑balance, step away**. Here are some concrete, bar‑room‑friendly tips to keep the chaos at bay:  

1. **Guard your sleep like it’s a limited‑edition whiskey.**  
   - Aim for 7‑8 hours of solid shut‑eye before a trading day.  
   - Set a “lights‑out” alarm on your phone (yes, even the one that keeps you up scrolling).  

2. **Schedule your workouts like you schedule a trade.**  
   - If a 30‑minute jog is your mental reboot, don’t cancel it because the market is opening.  

3. **Create a “no‑surprise” zone for paperwork.**  
   - Prepare all necessary documents the night before a trade‑day; keep a dedicated folder labelled *“Do Not Disturb – Trading Day.”*  

4. **Use a “mental‑check‑in” before you click ‘Buy’.**  
   - Ask yourself: *“Am I doing this because the chart says so, or because I’m angry about the coffee being cold?”*  

5. **When in doubt, take a “trade‑pause.”**  
   - If you feel a storm of emotions, close the laptop, take a walk, or grab a snack. Return only when you feel neutral again.  

### Bottom Line: The Little Things Really Do Matter  

It’s easy to shrug off a missed coffee or a traffic jam as “just life.” But in the world of trading, **those tiny disturbances can compound into a massive edge‑loss**. By treating your diary like a therapist who never charges a fee, you’ll start catching the subtle mood swings before they translate into costly mistakes.  

So, next time you’re about to embark on a two‑day family road‑trip, **write it down**: *“Leaving on Friday, kids in the back, I’ll set a protective stop and check the trade at the café at 9 am.”* Then, **actually** set that stop, and **actually** check the café (or your phone).  

Your future self—who’s hopefully sipping a celebratory drink after a series of well‑executed trades—will thank you for the extra minutes you spent scribbling in that notebook.  

*Trade smart, sleep well, and remember: the only thing you should let “slip” is the occasional bad joke.*