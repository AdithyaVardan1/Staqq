# 276. The Emotionally Controlled Trader  

**Source:** https://zerodha.com/varsity/chapter/the-emotionally-controlled-trader/  

---  

Winning traders don’t let their feelings run the show.  
Trading is a job for the logical part of the brain, not the drama‑queen.  
If you go from “I’m on top of the world!” after a winning trade to “I’ve lost my soul” after a loss, you’re basically on an emotional roller‑coaster that makes the market’s ups and downs look like a kiddie ride. And guess what? Your account balance will start doing the same loop‑de‑loop.  

Most newbies can *talk* the talk. They can picture an emotion‑free robot—think Mr. Spock calmly adjusting his tricorder while the market swings like a hurricane. The trouble starts when they have to *walk* the walk. One rookie summed it up nicely:  

> “How can you not get excited when you make a win and disappointed when you lose? It’s natural, and you can’t beat nature.”  

That’s a fair point. It’s not a piece of cake; it’s more like a piece of gym‑equipment you have to learn to use. With enough practice, though, you can train yourself to think like a spreadsheet instead of a soap‑opera.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/05/20060324-300x300.png)  

## External levers: make the numbers do the heavy lifting  

The quickest way to keep your feelings in check is to put concrete, external rules in front of you. The star player here is **risk management**. If you gamble money you can’t afford to lose—or you risk a chunk that makes your heart race faster than a caffeine‑infused squirrel—you’ll feel the pressure mount.  

On the flip side, if you size your positions so that even a total wipe‑out would leave you with enough cash to buy a decent pizza, the fear factor drops dramatically. You can tell yourself, “Even in the worst‑case scenario, I’m still alive and can still afford my Netflix subscription.”  

A solid, written‑down **trading plan** works like a safety net. Spell out exactly how you’ll enter, where you’ll exit, and when you’ll bail out with a protective stop. Knowing that a stop‑loss is waiting to catch you if the market decides to take a nosedive gives you a feeling of security comparable to wearing a seatbelt on a bumpy road.  

## Stress: the silent account‑killer  

External stressors have a sneaky way of sapping the mental bandwidth you need for disciplined trading. Whether it’s dealing with a family bereavement, moving houses, or an argument about who left the lights on, those life events drain the psychological energy you’d otherwise devote to watching price action.  

Emotion control and discipline are **energy‑intensive** activities—think of them as the mental equivalent of a marathon, not a sprint. If you’re already running on fumes, you’ll be more likely to panic‑sell or over‑leverage. The rule of thumb? If you’re under severe, ongoing stress, **hit the pause button on trading** until the storm settles. Your future self (and your bank account) will thank you.  

## Internal triggers: the stories you tell yourself  

Even if the outside world is calm, your own thoughts can light a fire under your emotions. Believing that you must be perfect on every single trade creates a pressure cooker. Minor slip‑ups feel like catastrophes, and a small loss feels like a personal failure.  

The antidote is simple: **accept imperfection**. You’re not a superhero; you’re a human with a finite amount of brainpower. Allow yourself a few mistakes—just make sure they stay within the risk parameters you set. As long as you keep your risk low and stick to a well‑crafted plan, those “mistakes” become just another data point on your learning curve, not a reason to throw your laptop out the window.  

## Bottom line: be kind to the human inside the trader  

Remember, you’re only human. No amount of willpower can turn you into a cold‑blooded algorithm overnight. Patience and consistent practice are the twin engines that will eventually get you to a place where profits are the norm rather than the exception.  

So, next time a trade makes your heart do a jitterbug, ask yourself: “What external rule can I lean on?” and “Am I letting life’s drama hijack my trading screen?” Treat your emotions like the occasional background music—notice it, don’t dance to it, and keep your trading decisions rooted in logic, risk control, and a well‑written plan. Cheers to calmer, more profitable trading!