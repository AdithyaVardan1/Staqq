# 17. Getting Worked Up For Nothing  

**Source:** https://zerodha.com/varsity/chapter/getting-worked-up-for-nothing/  

---  

Jack has been at the trading grind for **five solid years**—and not the “five‑minute‑a‑day” kind. He literally pulled a double‑shift, juggling two jobs just to scrape together enough seed money to give his trading a fighting chance. Weekends? Forget brunch; he was buried in books, webinars, and the occasional “secret sauce” strategy that promised to turn his modest account into a champagne‑popping empire.  

**Did the money roll in?** Nope. Not a single extra digit to brag about. Jack is now staring at his screen with the same look you get when you realize the last slice of pizza is gone. He’s poured sweat, sleepless nights, and a heroic amount of sacrifice into the market, only to wonder if his goals are just a fantasy novel in disguise.  

Ever been there? If you’ve been wrestling the markets for a few years, you’ve probably felt the same blend of excitement and existential dread. It’s precisely these moments—when you’re tempted to toss your laptop out the window—that you need to swap the drama‑queen vibe for a **strategic, cold‑blooded** approach. In other words, crank up the hustle, not the hysteria.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2019/11/20050311.png)  

At Innerworth we’ve sat down with **over a hundred traders** and discovered a comforting (or terrifying) truth: the elite performers have all tasted the bitter broth of massive loss. Some have watched **thousands**, even **millions**, of rupees evaporate before finally tasting the sweet nectar of success.  

> *Note:* This doesn’t mean you need to go bankrupt to become a master; it’s just a reminder that the road to the top is often littered with financial potholes.  

When a setback slams into you, you have **two** options:  

1. **Quit** and find a “normal” job (one that doesn’t involve staring at candlesticks at 2 a.m.).  
2. **Pull yourself up by the bootstraps**—or, if you’re short on bootstraps, by sheer stubbornness—and keep grinding until the tide turns.  

A **can‑do attitude** is the secret sauce of every winner, but maintaining that sunshine‑state‑of‑mind when the market keeps throwing curveballs feels like trying to stay optimistic while stuck in an elevator with a mime. It’s natural to feel fed up. Your brain starts looping the classic “It’s not fair! I’ve worked my tail off, I deserve a big payoff!” mantra.  

If only the market were a polite waiter who always served exactly what you ordered—unfortunately, it’s more like a mischievous chef who loves surprise ingredients. The only thing you can control is **how you react** to whatever the market dishes out. Succumb to pessimism, and you’ll never get to taste any profit; cling to optimism, and you’ll at least have the mental energy to keep playing the game.  

## How to Keep Your Cool (and Your Wallet)  

1. **Own the Challenge** – Don’t act like you’re starring in a Disney movie where everything works out after the first kiss. Accept that trading is a grind. “Hard” ≠ “Impossible.” When you recognize the inherent difficulty, you can draft a realistic, step‑by‑step battle plan instead of day‑dreaming about instant riches.  

2. **Label Your Frustration** – Dr. Ari Kiev, a brain‑science guru for traders, says that naming your feeling is like putting a price tag on it; it loses its power. So when you feel that surge of annoyance, whisper to yourself, “Okay, I’m frustrated right now,” and watch it dissolve faster than a sugar cube in hot tea.  

3. **Cultivate Optimism (the Productive Kind)** – Think “positive” not “delusional.” Visualize a future where you’ve learned from every loss, not a fantasy where you never lose.  

4. **Remember Learning is a Marathon, Not a Sprint** – Trading skills compound like compound interest. Put in consistent effort, and success will eventually show up—maybe not tomorrow, maybe not next week, but **eventually**. You don’t have to be born with a sixth sense for price action; you just need persistence.  

5. **Strategize, Don’t React** – Treat every setback as a puzzle, not a punch. Focus on problem‑solving rather than emotional outbursts. When the market throws a tantrum, you respond with a game plan, not a scream.  

So, the next time you feel the urge to throw your chart sheets into the fire, take a deep breath, remind yourself that every great trader has survived at least one epic crash, and **keep moving**. With enough grind, the profits you’ve been day‑dreaming about will eventually materialize—preferably with a side of brag‑worthy stories for your next bar‑room trading session. Cheers to staying strategic, staying funny, and staying **cash‑positive**!