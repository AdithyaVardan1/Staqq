# 216. Going Your Own Way  

**Source:** https://zerodha.com/varsity/chapter/going-your-own-way/

---  

The last fortnight has felt like a roller‑coaster that forgot it was supposed to have brakes. One minute the market is doing a nosedive that would make a skydiver jealous, the next it snaps back up like a cat that heard a can of tuna open. Then—just when you think you’ve got a handle on the chaos—some fresh earnings report drops, and the whole thing does a 180 again. If only the market were a well‑behaved toddler that listened when you said “sit,” you could sit back, sip your coffee, and watch the profit meter climb. The reality? To cash in on those wild swings you have to stop dancing to the same tune as everyone else and start humming your own (maybe slightly off‑key) melody.

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/04/20061222-300x300.png)

### The Comfort of the Herd (and Why It’s a Double‑Edged Sword)

There’s something oddly soothing about joining the crowd—think of it as the financial equivalent of ordering the same pizza as the table. It feels safe, it feels normal, and you get that warm fuzzy “we’re all in this together” vibe. The problem is that the herd often wanders into the forest of fear and greed without a map, and ends up tripping over its own feet. Yet, humans are wired like that: we love the security of numbers, the nods of approval, the “yeah, we all think the same thing” chorus. It’s why we line up for the latest smartphone launch even if we already have a perfectly good one.

But here’s the kicker—sometimes that chorus is being conducted by a few puppeteers who are more interested in pulling the strings (and your cash) than in honest market economics. If you always march behind the band, you’ll probably end up buying high and selling low, the classic “buy the dip, sell the rally” nightmare. To truly profit, you need to try to *anticipate* the band’s next move, or better yet, *step out* and catch the beat before anyone else does. That’s easier said than done; it’s like trying to guess the plot twist of a movie before the director even finishes shooting.

### When Following the Crowd Isn’t a Crime

Don’t go thinking we’re calling the herd a villain in every scenario. Even the most successful people in history have learned to read the room and sometimes sit politely at the back of the class. Think back to school: you didn’t become a valedictorian by refusing to follow the syllabus, did you? Blind obedience to authority can be a trap, but a little compromise—knowing which rules are worth respecting—keeps you from getting a permanent seat in the detention wing.

In the investment world, that translates to “smart conformity.” If you’re a long‑term investor who prefers the slow and steady (think turtles, not hares), it makes sense to pile into stocks that are as calm as a monk on a mountaintop—low volatility, solid fundamentals, and a track record of earnings that could fund a small country for years. When a sizeable crowd believes that a company will keep churning out profits for decades, jumping on that train can be a safe bet. You’re basically hitching a ride with a convoy of sensible investors, and the road is less likely to have potholes.

### The Rebel Trader’s Playground

Now, if you’re the type who gets a rush from watching price charts flicker like a neon sign at 3 a.m., you’re not after safety—you’re after *volatility*, that sweet, jittery risk that can turn a modest stake into a fireworks display of profit (or a spectacular bust, but hey, that’s part of the drama). In that world, going solo isn’t just a fancy phrase; it’s a survival strategy. You need to think like a chess grandmaster who’s constantly guessing the opponent’s next move while simultaneously plotting three moves ahead of yourself.

That means you have to figure out what the herd *will* do next, and then position yourself *before* they do. It’s a bit like arriving at a party early, grabbing the best snack, and then watching everyone else scramble for the crumbs. The secret sauce is timing: knowing when to ride the crowd’s wave and when to step off the surfboard and paddle in the opposite direction.

### The Turning Point: When the Crowd Gets It Wrong

The crowd usually gets it right—most of the time they’re simply reflecting the prevailing sentiment. The trouble starts when *everybody* has already taken a position, say “the market is going up,” and there are barely any fresh buyers left to push the price higher. At that moment, the market becomes a tired marathon runner who’s run out of steam. A counter‑trend starts to form, and the price can swing the other way faster than you can say “stop‑loss.”

Spotting that inflection point is the holy grail of trading. It’s like trying to guess when the last slice of pizza will be snatched up at a party—if you’re too early, you get a cold slice; too late, and it’s gone. Predicting it with perfect accuracy is basically a unicorn in the finance world. Some sages claim it’s impossible; others swear they’ve found a crystal ball in a stack of moving‑average crossovers.

### Build a Method, Trust It (But Keep a Safety Net)

What can you actually do? Develop a strategy that *usually* works and be brutally honest that it will occasionally flop. Whether you’re a fan of technical indicators (RSI, MACD, the whole gang) or you’ve got a knack for turning news headlines into trade ideas, you must back it with conviction. Put your skin in the game, set your stop‑loss, and act decisively—no endless dithering over whether the market will “maybe” go up.

Going it alone can feel like shouting into a canyon: you hear your own echo, but the rest of the world is mum. It’s a bit lonely, a touch scary, and sometimes you’ll wonder if you’ve just jumped off a cliff without a parachute. But remember, the winners are the ones who’re willing to step off the well‑trodden path and carve their own trail—preferably one that leads to profit, not a dead‑end.

So, next time the market looks like a jittery teenager on a sugar rush, ask yourself: *Am I going to blend in with the crowd and hope for a safe ride, or am I going to grab the bull by the horns and ride the chaos to the other side?* The answer, my friend, is the difference between watching the fireworks from the bleachers or being the one lighting the fuse. 🚀