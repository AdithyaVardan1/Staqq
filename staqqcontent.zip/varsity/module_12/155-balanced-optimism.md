# 155. Balanced Optimism  

**Source:** <https://zerodha.com/varsity/chapter/balanced-optimism/>

---

Trading is a bit like that friend who keeps inviting you to karaoke night even after you’ve butchered every song. You’ll be hammering out trade after trade, and most of the time you’ll feel like you’ve just sung “Living on a Prayer” in a bathroom stall—plain, painful, and full of “oops” moments. Yet, somewhere between the loss‑after‑loss and the occasional “yeah‑that‑was‑good!” you have to keep the show going. In other words, you need the kind of stubbornness that makes a cat keep trying to fit into a box that’s obviously too small.

Enter Dr. **Martin Seligman**, the optimism‑guru who spent years poking around the heads of high‑flyers—athletes, CEOs, and the folks on the chaotic trading floor—to figure out why some people keep dancing after they’ve stepped on a Lego. Spoiler: it’s because they’re *optimists*. Optimists, according to his research, tend to ace school exams, win more elections, and generally get the “you‑can‑do‑it” badge at work more often than their gloom‑laden cousins.

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/03/20070412-300x300.png)

### The “Ruthless” Optimist: Insurance Agents  

Seligman didn’t stop at athletes; he also stalked (in a totally ethical, academic way) insurance agents—people who literally have to smile while getting a “no thanks” for the hundredth time. The urban legend in that world goes something like: “Make nine cold calls, get nine polite brush‑offs, then maybe, just maybe, close a sale on the tenth.”  

Turns out that legend isn’t just a bar‑room joke. Met Life, a giant in the industry, hires about **5,000** bright‑eyed agents every year. By the end of the first twelve months, **≈50 %** have already hung up their badges, and by year four the attrition balloons to a whopping **≈80 %**. That’s a lot of optimism being tossed out the window.  

Seligman wanted to know whether the few who survive are just luckier, or whether they’re *actually* more optimistic. He gave them a questionnaire that measured something called **explanatory style**—the mental script you whisper to yourself after a flop.  

### Explanatory Style: The Internal Narrative  

*Pessimists* tend to write a drama that’s **global**, **internal**, and **stable**. In plain English, they think:  

- **Global** – “I’m terrible at everything.”  
- **Internal** – “It’s my fault, I’m the problem.”  
- **Stable** – “This will never change.”  

That cocktail of self‑defeat makes you want to curl up with a tub of ice‑cream and never trade again.  

*Optimists*, on the other hand, craft a more nuanced script: “That trade sucked, but it was a bad setup, and I can learn from it.” Their failure is seen as a *specific, external, and temporary* event—exactly the opposite of the pessimistic trifecta.  

When Seligman ran his optimism‑test on the Met Life sales crew, the numbers spoke louder than any pep talk:  

- Optimistic agents sold **37 %** more insurance than the gloomy lot.  
- The top‑10 % of optimists (the crème de la crème) sold a jaw‑dropping **88 %** more than the bottom‑10 % pessimists.  

Even more interesting, his optimism questionnaire out‑performed the industry’s standard hiring tests. In other words, a good dose of sunny‑side‑up thinking is a better predictor of sales success than a polished résumé.

### What This Means for You, the Trader  

If you want to beat the market, you need to *grow* that optimistic explanatory style. Expect to encounter more losers than winners—think of a roulette wheel that’s stuck on red for a while. The secret sauce is persisting *through* the red streak until you finally hit a streak of black that actually pays off.

But—hold the confetti—optimism isn’t a free‑pass to reckless optimism. Seligman warns that perpetual rose‑colored glasses can blind you to real risks. Pessimists, while sometimes mopey, are often **wiser** about the limits of their control.  

Research shows that pessimists are better at **calibrating** how much influence they truly have over a situation. They’re more realistic, which can be a lifesaver when you’re about to jump into a trade that looks great on paper but is actually a house of cards.

### The Sweet Spot: Balanced Optimism  

New traders love to wear confidence like a superhero cape—sometimes it’s more *delusion* than *confidence*. The trick is to blend the **persistence‑fuel** of optimism with the **reality‑check** of healthy skepticism. Think of it as a cocktail: two parts optimism, one part doubt, shaken (not stirred).

**Practical tip:** Before you hit “Enter” on a trade, interrogate your plan like a skeptical detective. Ask yourself:

- “Did I consider every possible market nightmare that could turn this trade into a loss?”
- “Is my risk‑management tight enough to survive a sudden 20 % swing?”
- “If the trade goes sideways, do I have an exit strategy that won’t make me scream at the screen?”

Answering these questions honestly is the equivalent of putting on a seatbelt before a roller‑coaster ride—your optimism will still let you enjoy the thrill, but your skepticism will keep you from flying off the tracks.

### Bottom Line: Use Optimism, But Don’t Marry It  

Optimism is the fuel that keeps you grinding when the market throws you curveballs. It’s the voice that says, “Hey, I’ll learn from this loss and come back stronger.” Pessimism, on the other hand, is the voice that asks, “Are we sure this plan isn’t a disaster waiting to happen?”  

When you marry the two, you get a **balanced optimism**—the sweet spot where you stay motivated without getting blindsided. It’s the mental equivalent of having a trusty GPS (optimism) while also checking the rear‑view mirror (pessimism).  

So, be that trader who smiles at a losing streak, learns from it, and still double‑checks the risk numbers before the next entry. That’s the recipe for long‑term survival…and, eventually, those sweet, sweet profits you’ve been day‑dreaming about at the bar. Cheers to staying optimistic, staying skeptical, and staying in the game!