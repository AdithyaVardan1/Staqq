# 261. They Say It Couldn’t Be Done  

**Source:** https://zerodha.com/varsity/chapter/they-say-it-couldnt-be-done-2/

---

Picture this: a family reunion, the kind where Aunt Maya brings enough biryani to feed a small army and Uncle Raj shows up in his “I’m‑still‑cool‑at‑40” polo. Jake, who’s been grinding the markets for a while, finally meets his second cousin Ron for the first time. Ron, a freshly‑minted insurance agent with a briefcase full of “policy‑punchlines,” leans in and asks, *“So, what do you do for a living?”*  

Jake straightens his back, flashes a grin that says “I’m kind of a big deal,” and replies, *“I’m a trader.”*  

Ron, whose idea of a “big deal” is probably a 2‑year‑old car with a dented bumper, smirks and says, *“There’s no way you can make a living trading. What are you really doing?”*  

Welcome to the Ron‑Club, the unofficial society of cynics who have heard the market hype, maybe tried a few “buy low, sell high” memes, and walked away with a balance sheet that looks like a sad face. They’re the folks who think making money in the markets is as likely as finding a unicorn in their backyard. And that’s fine—cynicism is the default setting for anyone who’s never seen a trader actually turn a profit.

But here’s the cold, hard truth: **if trading were a get‑rich‑quick vending machine, the line would be a mile long and everyone would be pulling out $1,000 a day.** The winning trader doesn’t waste time asking, “Can it be done?” He’s already bought the ticket, taken the seat, and is now yelling, “How the heck do I master this thing?”  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/05/20060516-300x300.png)

---

## Optimism Isn’t a Magic Wand—It’s the First Brick

I’m not saying that a sunny disposition alone will turn you into the next Wall Street wizard (unless you’ve got a secret potion hidden somewhere). But think of a **can‑do attitude** as the foundation of a sturdy house. Without it, you’re just building a sandcastle that the next wave of market volatility will wash away.

You’ll have to wade through a sea of hype, shiny‑object “guru” webinars, and promises that sound like they were written by a fortune‑cookie factory. The trick is to keep your eyes on the prize: **find something that actually works for you.**  

In the five years Innerworth has been stalking—erm—studying traders, we’ve collected enough cautionary tales to fill a Netflix true‑crime series. People who handed their life savings to a “trading guru” only to watch their account go from “green” to “ghost town” faster than you can say “stop‑loss.”  

### The Winning Trader’s Playbook (Spoiler: It’s Not a Cheat Code)

1. **Never‑Stop‑Learning:** They treat the market like a Netflix series—always watching, binge‑reading, and occasionally re‑watching the classics to catch hidden Easter eggs.  
2. **Read About the Real Heroes:** Not the ones who claim they turned a $100 loan into a yacht, but the ones who honestly dissect their wins *and* their losses.  
3. **Match Personality to Style:** Whether you’re a calm‑as‑tea‑sipping swing‑trader or a jitter‑y‑jazzed day‑trader, you find the rhythm that feels natural.  
4. **Stay Open‑Minded:** Markets evolve, algorithms get smarter, and the next big opportunity could be hidden in a meme stock or a crypto‑linked ETF.  

In short, they **don’t lock themselves into one rigid “how‑to‑trade” script**. They understand that the market is a living, breathing beast that changes its stripes—sometimes daily, sometimes yearly. If you want to stay profitable, you have to keep hunting for fresh angles, new setups, and better ways to slice that profit pie.

---

## The Unlikely Super‑Trader Who Came Out of the College Dorm

Now, let’s talk about the kid who made the rest of us look like we were still stuck in dial‑up internet mode. One of Innerworth’s case studies featured a college sophomore who started trading his dad’s account—yes, the same dad who still thinks “Bitcoin” is a typo.  

His routine? Think “trading nerd meets Sherlock Holmes.” He devoured **two trading books per week** (the kind with more footnotes than a legal contract) and stayed up late parsing balance sheets like they were thriller novels. He wrote **detailed trading plans** that would make a project manager weep with joy, joined chat rooms, and even debated with strangers about whether a certain ticker was a “buy‑the‑dip” or a “dip‑the‑buy.”  

Fast forward two years, and the lad posted a **track record of over 100 % profit**—a figure that would make most seasoned pros raise an eyebrow and a glass of whiskey.  

### What Did the Cynics Say?

- **Trading chat rooms**: “He’s faking it; no one can pull that off.”  
- **Corporate interviews**: “We appreciate your enthusiasm, but we’re looking for… experience.” (Cue polite rejection.)  

Did he fold? Nope. He turned to his **family and friends**, pitched a **hedge‑fund idea**, and managed to convince a handful of private traders to hand over cash. In his **first year of running the fund**, he **cranked out a 300 % profit**.  

Sure, you could label this story a “once‑in‑a‑blue‑moon” anecdote, but the moral is crystal clear: **If you let your beliefs become a self‑fulfilling prophecy of “I can’t,” you’ll never even try.** And if you never try, you’ll never discover the next hidden gem, the next algorithm, or the next market quirk that could make you a winner.

---

## The “Reality Gap”—A Tragic Comedy

Trading psychologist **Mark Douglas** coined a neat term for this mental trap: the **“reality gap.”** Imagine you think you can juggle flaming torches because you saw it on a YouTube video, but in reality you can’t even keep a single balloon from popping. That gap—between **what you *think* you can do** and **what you actually can do**—is the silent killer of many aspiring traders.  

The markets are **ripe with profit‑making opportunities**—like a farmer’s market on a sunny Saturday. The difference between a farmer who sells a handful of carrots and one who sells out the whole stall is **hard work, diligent scouting, and a willingness to get dirty** (metaphorically speaking; no actual carrots were harmed in this analogy).  

### Bottom Line: Choose Your Seat

- **Side‑line spectator:** You sit back, mutter “It couldn’t be done,” and watch the market’s drama from a safe distance.  
- **Active participant:** You jump in with confidence, roll up your sleeves, and **work tirelessly**—because, yes, it can be done.  

There are traders out there who **make profits day after day**, not by luck, but by **relentless effort, constant learning, and a refusal to let cynicism write the script**. The choice is yours: keep the “couldn’t be done” mantra as your anthem, or crank up the volume on “I’ll figure it out” and start dancing to the market’s ever‑changing beat.  

Grab that attitude, sharpen those skills, and remember—**the next super‑trader could be you, the kid in the dorm, the barista who reads market blogs between coffee shots, or even the cousin who thinks “stocks” are a type of dinosaur.** The market doesn’t care about your résumé; it cares about your **willingness to show up, learn, and adapt**.  

So, what’ll it be? 🎲