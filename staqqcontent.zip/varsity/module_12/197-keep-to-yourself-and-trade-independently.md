# 197. Keep to Yourself and Trade Independently  

**Source:** https://zerodha.com/varsity/chapter/keep-to-yourself-and-trade-independently/

---

Ever found yourself sneaking into a trading chat just to drop the “I turned my account into a small‑fortune today” line? Or maybe you called a buddy “just to vent” and ended up turning the conversation into a brag‑fest about the 12% gain you pulled off last night? A little self‑praise now and then feels like a confidence‑boosting protein shake, but over‑drinking it will give you a nasty “reputation hangover.” The moment you start curating an image of “the winning trader” in the heads of others, trading morphs from a quiet, solitary craft into a high‑maintenance social performance. Suddenly, you’re not just worrying about the market – you’re worrying about what the guys on Discord think of your “skill set.”

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/03/20060922-300x300.png)

Before you know it, you’ve swapped the “independent‑minded trader” badge for a “reputation‑slave” badge. The pressure to keep up that glossy façade can crack you faster than a poorly timed stop‑loss. Remember: in trading, the only opponent you truly have to beat is… yourself. Sure, you’re buying and selling against a sea of other market participants, but they don’t know you, they don’t know your strategy, and they certainly aren’t keeping score on your Instagram story. Their orders are just anonymous blips on a chart; there’s no personal vendetta when the market moves against you. The more you can detach from the audience and trade on your own terms, the freer, more creative, and ultimately more profitable you’ll become.

### Why the “solo‑artist” approach wins

The crème de la crème of traders act like solo musicians at a jam session: they tune their own instrument, follow their own rhythm, and ignore the applause (or boos) from the crowd. They set their own timelines, chase the strategies that make *their* hearts race, and look inward for the next cue. In other words, you are the one who must sharpen the knives of skill, find a method that fits your temperament, and keep polishing it. No one else’s opinion should be the GPS for your journey—unless you enjoy getting lost in someone else’s traffic jam.

### Comparisons are the thief of joy (and profits)

Seeing a fellow trader’s screenshot flash “+18% this week” can feel like watching the neighbor’s barbecue while you’re stuck with a microwaved burrito. It sparks jealousy, self‑doubt, and that nasty inner monologue: “Why can’t I pull that off? Maybe I’m not cut out for this.” Those thoughts do nothing but distract you from the real work—improving your own edge.  

Your performance has zero causal link to anyone else’s performance. The market isn’t a popularity contest; it doesn’t care whether you’re the talk of the town. Comparing yourself to others is like measuring your height with a ruler that’s been stretched—totally unreliable.  

**Bottom line:** Stop scrolling through other people’s “win boards.” Focus on the one chart that matters: *your own* track record.

### Embrace your personal learning curve

We’ve all been conditioned to compare—school grades, sports stats, even who gets the biggest slice of pizza. Breaking that habit overnight is about as easy as teaching a cat to fetch. But in trading, it’s a non‑negotiable survival skill. Everyone’s learning curve is its own quirky roller‑coaster, with loops, drops, and that one part where you scream “why me?”  

Instead of looking at someone else’s smooth ascent, keep your eyes on your own past trades. What went right? What flopped? Which part of your method is a squeaky wheel? By digging into *your* data, you’ll uncover the personal quirks—maybe you’re over‑trading after a win, or perhaps you’re letting fear dictate your stop‑loss placement. Those are the levers you can actually pull.

### The freedom formula: No ego, no comparison, just you

- **Don’t make trading a status update.** If you’re more concerned about “keeping up with the Joneses” than mastering your strategy, you’re already losing.
- **Guard your mental real‑estate.** Every minute you spend worrying about what a friend’s P/L looks like is a minute you’re not analyzing the next entry point.
- **Trade for yourself, not for applause.** When you’re immune to the crowd’s opinion, you can execute with the calm of a monk and the confidence of a gambler who knows his odds.

In short, tuck that brag‑mail into the drafts folder, mute the “trading brag” group chat for a while, and let your own results speak. When you stop treating the market like a stage, you’ll find yourself trading with the freedom, creativity, and profitability that only an independent mind can muster. So keep to yourself, stay true to your own compass, and watch the profits (and the peace of mind) grow together. Cheers to solo success! 🍻