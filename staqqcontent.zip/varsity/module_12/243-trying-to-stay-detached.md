# 243. Trying to Stay Detached  

**Source:** https://zerodha.com/varsity/chapter/trying-to-stay-detached/

---  

Winning traders treat the market like a cool‑handed bartender: they pour the drink, sip it, and never get sloppy. In other words, they stay **detached, unemotional, and rational**. We’ve hammered that point a million times in this series, but hearing “don’t get attached” from a screen isn’t the same as actually feeling it in the heat of a trade. For a rookie, the market can feel like a roller‑coaster that you built yourself, and the ticket price is your hard‑earned cash. You tell yourself, “I’ll take losses in stride,” yet when the red numbers start marching across your screen, the mantra “losses are normal” can sound as flat as yesterday’s soda.

Don’t throw in the towel just yet. With a bit of prep, self‑awareness, and rehearsal, you can train your brain to act like a Zen monk on a trading floor—minus the incense.

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/04/20061102-300x300.png)

## The “I’m on a Losing Streak, Send Help” Feeling  

Ever had a string of losing trades that left you feeling like you’d just been dumped by your favorite pizza place? You’re not depressed enough to quit trading, but you’re certainly not ready to start a career as a professional napper. You know it’s a temporary slump, yet at that moment it feels like the market has taken a permanent vacation from you. The feeling is distracting, and it can push you into **impulsive trading**: “If I just catch one win, I’ll feel like a rock‑star again.” That rush is intoxicating, but acting on it is like drinking a triple espresso before a marathon—you might sprint ahead, but you’ll also crash hard, turning disappointment into full‑blown pessimism.

There are a few tricks to keep your inner drama queen from stealing the show.

### 1. Police Your Inner Chatter (Yes, Even the Sarcastic One)

It sounds as cliché as “eat your veggies,” but the way you talk to yourself matters. Drop the “I’m a terrible trader” soundtrack and replace it with something like, “Losses are part of the game, just like traffic jams on the way to work.” Reminding yourself that **losses are expected** does two things:

1. **Normalises the pain** – you realize you’re not the only one getting the short end of the stick.  
2. **Pre‑activates your psychological defense squad** – you’re already braced for a hit, so the blow won’t knock you flat.

Think of it as putting on a helmet before you hop on a bike. It doesn’t stop the crash, but it prevents a nasty head injury.

### 2. Visualise the Worst‑Case (and Walk Away Cool)

Don’t mistake this for “pessimistic trading.” You’re not trying to jinx the market; you’re just **pre‑paring** for a possible loss. Before you even fire up the charts for the day, run a mental rehearsal:

> “If the price goes the wrong way, I’ll calmly click ‘close,’ take the loss, and move on.”  

Picture it in vivid detail—watch the candle bar crawl opposite your position, feel the slight sting, then imagine yourself taking a deep breath, pressing the exit button, and giving the market a polite nod: “Nice try, buddy.”  

When the scenario actually unfolds, you won’t be shocked; you’ll already have a mental script that says, “Alright, that happened. On to the next trade.” The emotional sting is blunted, and you stay on your feet instead of sprawling on the floor.

### 3. Risk Management: The Real Hero in This Story

If you stake more than you can comfortably lose, every loss feels like a personal affront. It’s like borrowing your roommate’s car, crashing it, and then having to pay the repair bill *and* the parking ticket. When you’re constantly on edge, your emotional thermostat spikes, making impulsive decisions even more likely.

Set a **hard stop** on how much of your capital you’re willing to risk per trade—most pros keep it under 1‑2 % of the total account. By doing this, a loss becomes a **manageable dent** rather than a catastrophic blow. The internal dialogue shifts from, “I’m ruined!” to, “That’s fine, I can recover this.”  

When the risk is contained, you regain the mental bandwidth to stay rational. The winning trader isn’t a robot, but he *does* behave like one when the market tries to rattle him.

---

## Bottom Line: Detachment Is a Muscle, Not a One‑Time Stretch

1. **Talk the talk** – replace self‑criticism with realistic, calming mantras.  
2. **Walk the walk** – rehearse the loss scenario in your head, then act with composure when it happens.  
3. **Guard the bankroll** – keep risk per trade low enough that a loss feels like a bump, not a crash.

When you blend mental rehearsal, a tidy risk‑management plan, and a habit of constructive self‑talk, you give yourself the tools to stay cool, calm, and collected—exactly the vibe a winning trader needs. So the next time the market tries to throw a tantrum, you’ll be the one sipping your coffee, smiling, and saying, “Nice try, market. I’ve got this.”  

Remember: **Detach, rehearse, manage risk, repeat** – and you’ll turn those dreaded losses into just another footnote in your trading diary, not the headline. Cheers to staying zen while the numbers dance!