# 181. Cautious Optimism  

**Source:** https://zerodha.com/varsity/chapter/cautious-optimism/

---

Dan has been stalking IBM like a sitcom‑loving detective for the past five months. He can read its price‑action like a teleprompter—knowing the little hops, the belly‑flops, and the “just‑before‑the‑coffee‑break” moves that usually cue a fresh trend. All that’s left is the mental gymnastics: he has to slip into a Zen‑master state, press the trade button with the calm of a cat on a sunny windowsill, stay hopeful, but also keep one eye peeled for that one‑in‑a‑million market curveball that could turn his win into a whimper.

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/03/20070117-300x300.png)

Crafting a winning trading strategy is about as easy as teaching a goldfish to do algebra. Even when the back‑tested numbers look as shiny as a new‑car showroom, there’s always a lurking “what if?” that could wreck the whole thing tomorrow. So, when you finally stumble onto a strategy that actually makes money, you have to deploy it while you’re in peak‑performance mode. Think of it as putting on your superhero cape: discipline, self‑control, and a plan you follow with the stubbornness of a toddler refusing to share a toy.  

Once you’ve got a battle‑tested edge, you can feel the optimism bubbling up—but don’t let it explode like a soda can in the freezer. The sweet spot is “cautiously optimistic.” Your edge will probably work most of the time, but it’s not a magic wand that guarantees a win every single trade. No strategy is a 100 % guarantee; even the best ones have blind spots.

*For the sake of illustration, let’s imagine a wildly improbable—yet mathematically tidy—strategy.* After a five‑month deep‑dive into IBM’s price chart, Dan discovers that **95 %** of the time the stock jumps exactly $1 on Tuesdays and Thursdays at 11:52 AM (yes, that precise). Using basic probability, if the market behaved like a perfect casino and you could repeat the trade an infinite number of times under identical conditions, you’d expect a 95 % success rate.  

Now, “infinite repeats” is a fancy way of saying “theoretical.” In reality, you might only get to try it 20 times. Statistically, you’d expect about 19 wins out of those 20—roughly nine out of ten. The catch? You have to stay optimistic enough to actually give it those 20 tries. Pull the plug after a couple of losses and you’ll never see the long‑run average materialize.

That optimism, however, needs a dose of caution. Probability theory’s golden rule is that every trial must occur under *identical* market conditions. In the wild world of equities, that’s about as likely as finding a unicorn on your morning commute. Even a strategy that’s historically 95 % successful will probably under‑perform that number when the macro‑environment shifts, interest rates wobble, or a rogue tweet from a billionaire shakes things up.  

(And a quick side‑note: even if the market *were* a perfect clone each time, the law of small numbers tells us that 20 trials can still give you a 0 % success rate—just because luck decided to take a coffee break.)

Enter the hero of the story: **risk management**. This is where you ask, “How much of my hard‑earned capital am I willing to lose on a single trade?” The answer should be a modest slice—think 1–2 % of your total equity per position. Pair that with a stop‑loss placed at a level that protects you from a catastrophic swing, and you’ve built a safety net that says, “If the market decides to be a drama queen, I’m still alive to trade another day.”  

In the grand finale, implementing any edge is a balancing act between optimism and realism. You need enough belief in your system to execute trades with a relaxed, confident vibe—like you’d order a second round at the bar because you *know* the bartender’s cocktail is good. At the same time, you must stay razor‑sharp about the fact that markets love surprise parties, and those can eat away at your capital faster than a hangover. By limiting risk, using stop‑losses, and keeping a cool head, you marry the two sides of the coin: **cautious optimism**—the secret sauce that lets you stay in the game long enough for the odds to work in your favor.