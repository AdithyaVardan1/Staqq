# 25. The Fly and the Tree  

**Source:** https://zerodha.com/varsity/chapter/the-fly-and-the-tree/

---  

Flexibility isn’t just a yoga buzz‑word for traders—it’s the secret sauce that keeps you from turning into a nervous‑wreck when the market goes full‑tilt. Imagine trying to solve a trading puzzle while your brain is stuck on a single, tunnel‑visioned track. Your attention narrows, your imagination shrinks, and the next thing you know you’re buying a stock because “it looks cheap” instead of because the math says so. The cure? Test your mental pliability, spot when you’ve gone as stiff as a board, and then deliberately change your surroundings so you can think with the grace of a cat landing on a windowsill.

![Image](https://zerodha.com/varsity/wp-content/uploads/2019/12/20070504.png)

## What is flexibility?  

A classic (and slightly sneaky) way to gauge intellectual flexibility shows up on the WAIS IQ test: *In what way are a **fly** and a **tree** alike?* Most people stare at that pair like it’s a riddle from a fortune‑cookie, wracking their brains for a clever, “deep” connection. You’ll see their mental gears grinding, eyebrows climbing, and a hint of panic as they wonder whether the psychologist will mark them down for missing some high‑falutin answer.

Spoiler alert: the correct response is simply **“Both are living things.”** It’s a bit like realizing the secret to a perfect cocktail is just “add ice.” Once the answer clicks, it feels almost laughable that we over‑complicated it. Yet the very fact that many flinch at this question makes it a surprisingly discriminating test—only those who can step back, relax, and accept a plain answer tend to get it right.

Watch a genuinely flexible thinker tackle the fly‑tree puzzle. They’ll glance at it, shrug, maybe mutter “Hmm…what could it be?” and then, with a grin, say “Both are alive.” No dramatic epiphany, no sweat‑dripping fear of looking dumb. They’ve already lowered the stakes, so the answer arrives almost by accident—like catching a fly with a swatter when you weren’t even trying.

That’s the mindset we want at the trading desk: **casual, low‑ego, angle‑exploring**. Instead of hanging your self‑worth on a single trade outcome, you scan the landscape, consider a few plausible explanations, and settle on a solution that’s *reasonable* rather than *perfect*. You know when to keep it simple (a quick “both are alive” moment) and when to dig deeper (complex technical analysis) because you’re not shackled by the fear of looking foolish.

## How to flex as a trader  

1. **Create a chill‑vibe zone** – Pressure is the enemy of flexibility. If you feel the heat rising, step back. Close that position, take a walk, or sip a coffee that isn’t instantly turned into a nervous tremor. The calmer you are, the more angles you’ll see.  

2. **Delay the “must‑decide‑now” reflex** – Some decisions truly need a split‑second call (e.g., a stop‑loss hit). Others can wait for a breath of fresh air. If you can, give yourself a few minutes to re‑frame the problem. Think of it as letting the dough rise before you bake the pizza.  

3. **Don’t let ego drive the trade** – Treat every trade as a data point, not a judgment of your worth. If you convince yourself that “getting this wrong will prove I’m a terrible trader,” you’re building a pressure cooker that will explode into rigidity.  

4. **Pre‑trade prep is your secret weapon** – Before the market bell rings, sketch out a mental map: key levels, possible news triggers, and contingency plans. When the opening chaos erupts, you’ll already have a calm anchor to cling to, rather than scrambling for a lifeline.  

5. **Practice the “fly‑tree” mental reset** – When you catch yourself over‑complicating, ask: “What’s the simplest truth here?” If the answer is as straightforward as “both are alive,” you’ve likely found a flexible path forward.

## Bottom line  

Flexibility isn’t a fluffy personality trait; it’s the cornerstone of consistent trading success. By curating a low‑stress environment, keeping your ego in the passenger seat, and giving yourself permission to take the simplest viable answer, you unlock a mental elasticity that lets you navigate volatile markets without breaking a sweat. So next time the market throws a curveball, channel your inner fly‑and‑tree guru: stay alive, stay relaxed, and keep the answers coming—no matter how “obviously alive” they may seem. Happy trading!