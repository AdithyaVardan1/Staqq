# 336. It’s About You and No One Else  

**Source:** https://zerodha.com/varsity/chapter/its-about-you-and-no-one-else/  

---  

From the moment we could hold a crayon, the world has been handing us report cards on how *we* should look, act, and succeed. Mom and Dad handed out gold stars, teachers handed out “A‑s” (or the dreaded “C‑” when we doodled in the margins). Our significant others‑‑the ones who swipe right on our quirks‑‑handed out praise when we hit their expectations and a side‑eye when we decide to take a detour on the “road less traveled.” And let’s not forget the whole society, which politely (or not so politely) reminds us that the benchmark for “doing well” is somewhere outside our own backyard.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/06/20050722-300x300.png)  

The media, that relentless hype‑machine, keeps shoving shiny new sports cars, designer shoes, and perfectly‑curated Instagram feeds down our throats. “Buy this turbo‑charged beast and watch the neighbors drool. Slip into the latest runway looks and become a walking billboard.” After a few repetitions, the mantra sneaks into our heads: **“How am I doing?”** followed inevitably by **“How well *should* I be doing?”**  
When the word “should” shows up, it brings a suitcase full of invisible pressure—like a gym‑bro who insists on bench‑pressing your emotional baggage. Too much pressure, and we end up choking faster than a freshman on a hot wing.  

### Why Looking Out Can Be a Trap  

If you keep your compass pointed at everyone else’s scoreboard, you’ll start grading yourself by their standards. “I’m a loser because my neighbor just bought a Ferrari,” you might think, or “I’m a genius because I own a pair of limited‑edition sneakers.” It’s a slippery slope that ends with you either feeling perpetually inadequate or, worse, over‑confident for the wrong reasons.  

The antidote is simple (but not always easy): turn that compass inward. Set **your own** personal benchmarks—what you truly want to achieve, not what the world tells you to chase. In trading, this means focusing on your unique risk tolerance, time horizon, and personality, rather than trying to out‑shine the guy who trades with a crystal ball and a side of astrology.  

### Comparing Yourself Is About as Useful as Comparing Apples to… Spacecraft  

Let’s be brutally honest: comparing yourself to someone else is about as productive as trying to out‑eat a competitive eater at a buffet. You’ll end up either feeling like a hamster on a wheel or, if you’re lucky, learning a new trick you’ll never use. The real profit (pun intended) comes when you **look inward** and define what “good” looks like for *you*.  

Every trader is a hybrid of three things:  

1. **Knowledge** – the stuff you’ve read, watched, and learned.  
2. **Personality** – that quirky mix of patience, risk‑aversion, and caffeine tolerance.  
3. **Method & Tools** – your charting software, your favorite indicator, that secret sauce you swear by.  

When you mash these ingredients together in the right proportion, you get a personalized trading recipe that can actually deliver consistent returns. Think of it as cooking: you wouldn’t try to make a soufflé using someone else’s grandma’s exact measurements without tasting it first.  

### The Long‑Haul: Hard Work, Persistence, and a Dash of Patience  

No, you won’t become a market wizard overnight—unless you’ve secretly signed a pact with a financial deity. Real mastery comes from **trade after trade**, each one leaving you with a nugget of experience (or a bruised ego). Over time, those nuggets pile up and start forming a solid foundation.  

Finding your own talent is like discovering your hidden superpower at a comic‑con. You might be a natural at spotting trend reversals, or you might have a sixth sense for risk management. The key is to **accentuate** what you’re good at and **work around** what you’re not.  

Everyone’s road looks different:  

- **The scenic route** – winding, full of twists, maybe a few potholes, but you get spectacular views (and a great story for the bar).  
- **The straight‑away** – short, fast, and sometimes a little boring, but you get to the finish line quickly.  

Regardless of the shape, the most important rule is: **own the journey** and respect the time and effort it demands. Trying to sprint someone else’s marathon will only leave you flat‑tired and possibly tangled in someone else’s shoelaces.  

### What the Super‑Successful Do (Spoiler: They Don’t Play Comparison Games)  

Research on high‑achievers and creative geniuses shows a common thread: they set **their own internal standards**. Even in cut‑throat competitions, they don’t stare at the leaderboard; they stare at the mirror. Their inner GPS tells them, “Keep moving, keep learning, keep grinding,” and they trust that persistence will eventually cash the check.  

They don’t **force** success like a toddler trying to force a peanut butter sandwich into a mouth that’s not ready. Instead, they let passion be the engine and let the results roll in like a well‑timed punchline.  

If you borrow this mindset for trading—focus on your own rhythm, respect your own limits, and let your personal standards be the North Star—you’ll be far more likely to build **lasting** success. In other words, stop trying to be the next Elon Musk and start being the **best version of your own trader‑self**. Cheers to that!