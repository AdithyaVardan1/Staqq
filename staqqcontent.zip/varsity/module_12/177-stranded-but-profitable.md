# 177. Stranded But Profitable  

**Source:** https://zerodha.com/varsity/chapter/stranded-but-profitable/

---  

Picture this: you’re marooned on a deserted island, the only Wi‑Fi you’ve got is a single satellite dish that streams live market data and lets you click “Buy” or “Sell.” No palm‑tree‑swinging colleagues, no “Did you see that breakout?” shout‑outs from the office chat, no endless pundit‑spam on the news. Would you actually trade *better*?  

Spoiler alert: **yes, you probably would.**  

Think about the usual trade‑floor “support system” that most of us cling to. The buddy who’s always bragging about his latest 10‑% gain, the market‑guru who swears by the “golden cross” he saw on TV, the friend who loves to brag about his new Lamborghini every time he pockets a profit. All that social noise is great for a cocktail party, but when you’re trying to sit in the “zone” with a laser‑focused mind, it’s more like a marching band playing “Baby Shark” in your ear.  

If you could set your own tempo, choose your own snacks, and trade at your own pace, you’d probably be humming a sweeter tune—and making more money while you’re at it.

---

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/03/20070108-300x300.png)

## The (Not‑So‑Subtle) Power of the Trading Crowd  

Social pressure is the invisible hand that keeps nudging you toward the bar‑room‑trader’s version of “peer review.” Ever sat in a room packed with traders, each glued to a screen, their eyes flickering like a school of fish? If a rookie on a hot streak is racking up win after win while you’re stuck in a losing streak, you start feeling the heat.  

> “Whoa, this is getting a little embarrassing. I should step up my game, right?”  

And just like that, you’re sprinting to catch up, firing off trades like a kid on a sugar rush. You add a pinch of *impulse* to your risk‑management recipe, hoping to close the “gap” between you and the guy who just turned a $1,000 account into $1,500 overnight.  

But let’s be real for a second: those extra trades are **unnecessary risks** wrapped in a shiny coat of “I’m trying to keep up.” You might win a couple of pips, feel a fleeting surge of “I’m just as good as him,” and then—boom—your account takes a dip that would make a dolphin look clumsy.  

If you flip the mental switch to *logic*, the internal monologue should sound something like:  

> “Who cares what the guy on the other side of the room is doing? I’ve got a method that’s been back‑tested, vetted, and it’s the one that puts money in my pocket. I’ll stick to it.”  

Unfortunately, the brain’s social circuitry doesn’t always take a logical vacation. The need to belong, to be admired, to avoid the dreaded “look at me, I’m a loser” feeling often trumps good sense. The result? **Lower profitability** and a bruised ego.

## How to Become Your Own Island‑Trader  

The antidote is simple (and slightly dramatic): **stop looking over the fence**.  

1. **Don’t solicit advice from the noise crowd.**  
2. **Ignore the mental chatter of “What will they think?”**  
3. **Stop trying to impress anyone—unless it’s the mirror in your cabin.**  

Sounds easy, right? It’s about as easy as teaching a cat to fetch. But the key is *recognition* and *defence*.  

- **Acknowledge** that social and psychological forces are real, powerful, and love to hijack your trading plan.  
- **Prepare** a mental shield: repeat a mantra louder than a seagull’s squawk, e.g.,  

> “I don’t care what anyone else is doing. I’m here to trade my way, my method, my profit.”  

- **Visualise** yourself on that deserted island—sunset, a hammock, a coconut drink, and a laptop that only shows you the charts you’ve programmed. Picture the bliss of devoting *all* your mental bandwidth to the price action, not to the next meme stock hype.  

When you can channel every ounce of focus into the *present* market, the “zone” isn’t a myth; it’s a beachfront condo you can actually move into.  

So, next time you feel the urge to compare your P&L to the guy who just bought a Tesla on a whim, remember: the most profitable traders are often the ones who act like they’re **the only human on the island**—and they love it. In the long run, that solitary mindset turns you from a “trader” into a **trading maestro**. 🌴📈  