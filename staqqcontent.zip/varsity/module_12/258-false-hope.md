# 258. False Hope  

**Source:** https://zerodha.com/varsity/chapter/false-hope/  

---  

In *The Disciplined Trader*, Mark Douglas famously tells us, “Execute your losing trades immediately upon the perception that they exist. When losses are predefined and executed without hesitation, there is nothing to consider, weigh, or judge and consequently nothing to tempt yourself with. There will be no threat of allowing yourself the possibility of ultimate disaster.”  In plain English: cut the loss the second you see it, or you’ll end up gnawing on the same bad idea longer than a Netflix binge‑watch.  

Sounds crystal‑clear, right? Yet behavioural‑economics research keeps pulling the rug out from under that advice. Too many traders, when they spot a trade sliding downhill, dig in their heels and keep riding the losing train instead of hopping off at the first stop.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/04/20060519-300x300.png)  

## Why do traders cling to the *miracle‑cure* fantasy?  

### 1. “It’s only temporary” – the waiting‑game delusion  
A mountain of academic studies shows that investors love to label a loss as “just a hiccup.” They convince themselves that if they simply *wait it out*, the market will magically swing back in their favour. The market, of course, is a notoriously fickle beast, and its inherent uncertainty is the perfect breeding ground for “maybe‑tomorrow‑will‑be‑better” day‑dreams.  

### 2. The sunk‑cost trap – “I’ve already paid for this!”  
Behavioural economists call this the **sunk‑cost effect**. The original cash you spent to buy a stock is a sunk cost – it’s gone whether the price climbs or collapses. Yet many traders act as if that money is still “in the bank” and must be recovered. As the position shrinks, they start whispering to themselves, “The *real* value is still around my entry price, not this pitiful market price.” In other words, they replace reality with a nostalgic memory of the trade’s first happy hour.  

### 3. Denial, optimism, and the “I’m‑special” syndrome  
Humans are wired to **fear losing what we already have**, but paradoxically we become *gamblers* when we’re already in the red. The logic goes: “If I hold on a little longer, the odds will finally tilt my way.” Some traders even add a dash of self‑importance: “I’ve got the Midas touch; the market just needs a nudge from me.”  

Another, more pedestrian, bias is **post‑decision rationalisation**. After you’ve committed to a trade, your brain goes into detective mode, hunting for any evidence that proves you were right. Contradictory data gets filed under “ignore” while supportive anecdotes get shouted from the rooftops.  

All of the above are perfectly plausible, but our own little detective work at **Innerworth** unearthed a few extra clues.  

## What did our own backyard experiment reveal?  

We surveyed a modest sample of traders, asking them straight up: *Do you ever hold a losing trade hoping it will miraculously reverse?*  

- **≈ 50 %** of respondents admitted they’re guilty of the habit. (Yep, half the crowd are basically holding onto their losses like a clingy ex.)  

When we dug deeper into the personalities of the “hop‑on‑the‑loser‑train” crowd, a pattern emerged:  

| Trait | Typical of the “hop‑on‑the‑loser‑train” traders |
|-------|---------------------------------------------------|
| Discipline & self‑control | Below average – they’re more likely to binge‑watch a series than to binge‑sell a losing position. |
| Decision basis | Intuition over hard facts – they trust their gut more than the balance sheet. |
| Emotional frequency | Higher rates of anger, fear, and disappointment – basically a roller‑coaster of feelings. |

If you see any of those red flags flickering on your own dashboard, you’re probably more prone to clutching a losing trade. The good news? You can **re‑train** that brain‑muscle, just like you can train your biceps (or at least your ability to lift the remote).  

## How to kick the false‑hope habit to the curb  

1. **Accept that losses are a normal part of the game**  
   Think of losses as the broccoli on your trading plate – you didn’t ask for it, but it’s there, and it’s good for your “experience” health. Don’t personalize them; a loss isn’t a judgment on your character, just a data point. The moment you stop taking losses personally, you’ll feel lighter (and your ego won’t need a therapist).  

2. **Pre‑define your risk before you even place the trade**  
   Set a stop‑loss level, a dollar amount, or a percentage you’re willing to lose. Write it down, stick it on your monitor, maybe even tattoo it on your forearm if you’re feeling dramatic. The point is: you decide *ahead* of time, so when the market starts screaming “sell me!” you’re already nodding, “Got it, that’s the plan.”  

3. **Practice the exit with the same zeal you practice the entry**  
   Visualise a losing trade the way you’d picture a bad haircut – you see it, you cringe, and you get it fixed ASAP. Run mental rehearsals: “If price hits my stop, I’ll click ‘sell’ without a second‑guess.” The more you rehearse, the less your brain will try to pull a Houdini act when the real thing happens.  

4. **Don’t feed the “it’ll turn around” monster**  
   The market doesn’t care about your hopes, prayers, or lucky socks. If you keep feeding that monster, it grows bigger and more demanding. Starve it by sticking to your predefined exit.  

5. **Turn the loss into a learning moment**  
   After you’ve exited, jot down a quick post‑mortem: What was the original thesis? Why did it fail? What could you have done differently? Treat it like a post‑game analysis in sports – the goal is to improve, not to wallow.  

---

**Bottom line:** Cutting losses early isn’t a sign of cowardice; it’s a sign of *discipline* – the same discipline that lets you finish a pizza without feeling guilty. By accepting that losses happen, pre‑setting your risk, rehearsing your exit, and refusing to cling to wishful thinking, you’ll free up mental bandwidth for the trades that actually have a chance to make you money. So next time a position starts to look like it’s heading for a cliff, remember Mark Douglas’s advice, pull the trigger, and move on. Your future self (and your portfolio) will thank you. 🍻