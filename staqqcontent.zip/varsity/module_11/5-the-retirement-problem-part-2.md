# 5. The Retirement Problem (Part 2)

**Source:** <https://zerodha.com/varsity/chapter/the-retirement-problem-part-2/>

---  

## 5.1 – Assumptions  

Alright, buckle up – we’re about to turn the “meh‑ish” retirement‑corpus estimate from the last chapter into a full‑blown, numbers‑driven plan.  
In the previous chapter we did a back‑of‑the‑envelope calculation and landed on a **≈ ₹7 crore** corpus that would let us sip masala chai (or a martini, we won’t judge) at ₹50 k a month for 20 years after we stop punching the clock.  

That number was deliberately **conservative** – we left out a few niceties on purpose so we could tighten the estimate later. Think of it as the “starter dough” for a financial pizza; we’ll sprinkle the toppings as we go.

The grand aim here is to **understand personal finance well enough** that we can keep plugging in new data (salary hikes, market returns, surprise inheritance, etc.) and watch the corpus number wobble into the right ballpark.  

In the last chapter we said we need about **₹7 cr**. In this chapter we’ll answer the *how* – how do we actually build that pot of gold by the time we hit the retirement finish line? The answer is simple: **start investing today**, and keep at it every month.  

### The Multi‑Asset Portfolio Idea  

You don’t want to throw all your eggs (or rupees) into one basket, right? That’s why we talk about a **multi‑asset portfolio** – a mix of:

* Fixed deposits (FDs)  
* Gold  
* Real‑estate  
* Equities (stocks or equity‑mutual funds)  
* Cash & cash equivalents  

The total return you’ll experience is just the weighted average of the returns from each of those buckets.

> **Illustration** – imagine your net worth is split like this:  

| Asset | % of Net Worth |
|------|----------------|
| Real‑estate | **50 %** |
| Fixed Deposit | **10 %** |
| Gold | **10 %** |
| Equities | **15 %** |
| Cash | **15 %** |

*(Numbers are purely illustrative – don’t go crying over your spreadsheet yet!)*  

Now each asset class has its own long‑term growth vibe. Here are my **10‑year‑plus CAGR expectations** (I’m being generous, but still conservative enough to keep the night‑mare at bay):

| Asset | Expected CAGR |
|------|---------------|
| Real‑estate | **8 %–10 %** |
| Fixed Deposit | **6 %–7 %** |
| Gold | **8 %–9 %** |
| Equities | **10 %–11 %** |
| Cash | **0 %** (actually negative once you factor inflation, but we’ll pretend it’s a neutral “parking lot”) |

Feel free to tweak these based on your own research – the rule of thumb is to **bias low**. If equities could give you 12 % in reality, using 10‑11 % is still a win; you’ll be pleasantly surprised later.

### Crunching the weighted average  

The portfolio’s overall growth is just the **sum‑product** of each weight and its expected return:

\[
\begin{aligned}
\text{Overall Return} &= (0.50\times10\%) + (0.10\times7\%) + (0.10\times9\%) \\
&\quad + (0.15\times11\%) + (0.15\times0\%) \\
&= 8.25\%
\end{aligned}
\]

So, a diversified basket with the mix above would *on average* earn **≈ 8.25 % per annum**.  

> **Side note:** Shuffling the weights around (say, more equities, less real‑estate) will shift that number up or down – we’ll revisit this later when we talk asset allocation in depth.

If you’re curious how the “high‑net‑worth‑people” actually spread their wealth, check out this infographic (it’s more for inspiration than a rulebook):

![Asset‑allocation infographic for HNIs](https://zerodha.com/varsity/wp-content/uploads/2019/10/image0_distribution-262x300.png)

> *The chart shows the typical split for HNIs and above; most financial planners will give you something roughly similar.*

### One‑Asset Simplification for the Retirement Problem  

All that multi‑asset goodness is fantastic, but for **this chapter** we’ll **zoom in on just one asset** – **equities** – because it’s the fastest‑growing piece of the puzzle when you have a long horizon.  

Our plan will be to **systematically invest** in a **growth‑oriented equity mutual fund** (think of it as a “set‑it‑and‑forget‑it” autopilot that puts money into a basket of stocks).  

If you’re scratching your head about “systematic investments in a growth‑oriented equity mutual fund,” don’t panic. We’ll unpack that later.  

For now, we’ll peg the equity CAGR at **10 %–11 %** – a realistic, yet conservative, figure for a 10‑plus‑year horizon.  

---

## 5.2 – The Setup  

### Quick recap  

* Target corpus: **₹7 crore** (enough to generate **₹50 k/month** for 20 years).  
* Time horizon: **25 years** → **300 months** until retirement.  

We’ll try to reach the target **solely with systematic equity‑mutual‑fund SIPs**. To do that we need a few baseline assumptions:

| # | Assumption |
|---|------------|
| 1 | You have a **steady salaried job** (no freelance‑guru‑in‑the‑making‑it‑up). |
| 2 | You’ll stay **employed until retirement** (i.e., you won’t quit to become a yogi at 45). |
| 3 | Your **primary savings vehicle** is a **monthly SIP into an equity MF**. |
| 4 | You receive **annual salary hikes** (the usual “cost‑of‑living‑adjustment” or “you’re finally good at your job”). |
| 5 | **Every January** you up the SIP amount by **10 %** (because you’re a responsible adult). |
| 6 | Hikes happen **once a year** (January 1st, right after you’ve blown the New‑Year champagne). |

I know “steady job” and “annual hikes” sound like a unicorn‑sighting for some, but we need *some* baseline to do math. Think of it as the “perfect‑world” scenario; we’ll later discuss how to tweak things if reality is messier.

### Visualising the cash‑flow  

Below is the schematic that shows how the SIP amount evolves month‑by‑month.

![SIP timeline illustration](https://zerodha.com/varsity/wp-content/uploads/2019/10/image1_setup.png)

**How to read it:**  

* **Row 1 (January, Year 1):** You drop **₹5,000** into the fund. That pot will sit untouched for the full **300 months** (25 years).  
* **Row 2 (February, Year 1):** Another **₹5,000** goes in, but now it only has **299 months** to grow.  
* …and so on.  

Notice the “months‑away” column? That’s the **compounding window** for each instalment. The earlier you invest, the longer the magic of compounding works for you – a.k.a. the “first‑mover advantage” of SIPs.

### The 10 % annual bump  

When we hit **January of Year 2**, we **increase the SIP** by **10 %**:  

* Year 1 SIP = **₹5,000** per month  
* Year 2 SIP = **₹5,500** per month (₹5,000 × 1.10)  

That pattern repeats each January:  

* Year 3 SIP = **₹6,050** per month (₹5,500 × 1.10)  
* Year 4 SIP = **₹6,655** per month, and so on.  

The table below shows the first few years of this escalation.

![SIP hike illustration](https://zerodha.com/varsity/wp-content/uploads/2019/10/image2_hike.png)

The month‑count continues to shrink as we get closer to retirement. For example, the **₹5,500** you put in **January of Year 2** has **288 months** (24 years) to compound.

### From SIP to future value  

Each monthly instalment grows at the assumed **11 % CAGR** (we’ll use the high‑end for illustration). The future value (FV) of a single payment is given by:

\[
\text{FV}=P\,(1+r)^{t}
\]

where  

* \(P\) = principal (the monthly SIP amount)  
* \(r\) = annual return (11 % = 0.11)  
* \(t\) = time in **years** (months ÷ 12)  

**First instalment (₹5,000, 300 months → 25 years):**  

\[
\text{FV}=5{,}000\,(1+0.11)^{25}=₹67{,}927\;(\text{approx.})
\]

**Second instalment (₹5,000, 299 months → 24.92 years):**  

\[
\text{FV}=5{,}000\,(1+0.11)^{299/12}=₹67{,}339
\]

If you run the numbers for every month, you’ll get a massive table of future values:

![Future‑value table illustration](https://zerodha.com/varsity/wp-content/uploads/2019/10/image3_table.png)

### Summing it all up  

Add up **all** those future values and you get the **retirement corpus** you’ll have at age 60.  

**Quick sanity check:** with a starting SIP of **₹5,000** and a 10 % yearly hike, does the final sum hit **₹7 crore**? Spoiler: **Nope.** It’s way short.

The spreadsheet (or calculator) tells us the total ends up around **₹1.2 crore** – a respectable sum, but not enough to fund ₹50 k a month for two decades.

> **Graphical punch‑line:**  

![Corpus shortfall illustration](https://zerodha.com/varsity/wp-content/uploads/2019/10/image4_ritcorpus-300x129.png)

### Three ways out of the shortfall  

1. **Stretch the timeline** – aim for a 30‑ or 35‑year horizon. Not always feasible if you need a paycheck sooner.  
2. **Chase a higher return** – say 14 % instead of 11 %. That’s basically gambling with your future; we’ll keep the math honest and stick to realistic returns.  
3. **Boost the savings rate** – the good, old‑fashioned “spend less now, enjoy later” route. This is the most controllable lever.

Let’s try #3 and see how the corpus changes when we start with **₹15,000** per month (still with the 10 % yearly hike).

![Corpus with ₹15k SIP](https://zerodha.com/varsity/wp-content/uploads/2019/10/image5_ritcorpus-300x142.png)

Better, but still shy of ₹7 crore.  

Now crank it up to **₹20,000** per month:

![Corpus with ₹20k SIP](https://zerodha.com/varsity/wp-content/uploads/2019/10/image6_ritcorpus-300x160.png)

**Bam!** We’re now flirting with the ₹7 crore target. That means, by retirement, you could comfortably withdraw **₹50 k each month** for 20 years.

---

## 5.3 – Are You Serious?  

Seeing a **₹20 k/month SIP** as a *starting* number can feel like a cruel joke, especially for fresh‑grad engineers who just got their first *“thank‑you for your hard work”* salary slip.  

### The age‑and‑time advantage  

If you’re **24–25 years old**, you have a **35‑year runway** before you hit the classic retirement age of 60. Even if you only invest **30 of those years** (maybe you take a sabbatical or switch careers), the power of compounding can still take you to the finish line.

**What happens if you start smaller?**  

Let’s try a **₹10,000** monthly SIP (still with the 10 % annual hike) and see where you end up after 30 years of contributions.

![30‑year corpus with ₹10k SIP](https://zerodha.com/varsity/wp-content/uploads/2019/10/image7_30yrs-300x135.png)

You’ll notice the final corpus is **still in the ballpark** of the 7‑crore target, thanks to the extra 5 years of compounding.  

**Key take‑aways:**  

* **Time** is the cheapest, most powerful lever. The earlier you start, the less you need to save each month.  
* **Money** (i.e., the SIP amount) is the second lever – you can always crank it up later if you need to catch up.

### Mid‑career reality check  

If you’re **mid‑career** and only have **10–15 years** left, the math changes dramatically. You’ll need to **save a larger slice of your paycheck** (or look for a higher‑return vehicle) to hit the same goal. There’s no magical shortcut; the trade‑off is either a tighter budget now or a leaner retirement later.

### The bigger picture  

Remember, we’re deliberately **simplifying** the world:  

* **Inheritance** could drop a rental property in your lap, giving you free cash flow.  
* **Employer‑provided PF** and **gratuity** will likely add a sizable lump sum at retirement.  
* Those lumps can sit in a **fixed deposit** or a **savings account** to generate low‑risk monthly cash flow.

The purpose of this module is to give you a **framework** – a way to think about the puzzle, not the final answer. Real life will add extra pieces, but the core idea stays: **systematic equity investing + compounding = retirement wealth**.

---

## 5.4 – Next Step  

No matter how much cash you eventually have (whether it’s a windfall property or a tidy PF balance), **equity exposure remains non‑negotiable** for long‑term wealth creation. History shows equities out‑perform everything else over a 10‑plus‑year horizon, and I’m pretty confident that trend will keep on dancing.

The **simplest, most disciplined way** to get that equity exposure is a **Systematic Investment Plan (SIP)** in a **mutual fund**. (Yes, there are other routes – direct stock picking, ETFs, etc. – but we’ll get to those later.)

### What’s coming up?  

Over the next few chapters we’ll **deep‑dive into mutual funds**:

* **Mindset** – why you should think like a long‑term investor, not a day‑trader.  
* **Portfolio construction** – building a mix of funds that match your risk appetite.  
* **Goal‑based investing** – mapping each fund to a specific life goal (retirement, kids’ education, buying a house, etc.).  
* **Fund analysis** – reading a fund’s fact sheet without falling asleep.  
* **Direct vs. regular plans, growth vs. dividend options** – the nitty‑gritty that can shave off a few hundred rupees a year.  

After we’ve mastered funds, we’ll hop over to the **other pillars of personal finance**:

* **Life insurance** (because you don’t want your family to sell the couch to pay off debts).  
* **Health insurance** (medical bills are the real-life version of a black‑hole).  
* **Pension plans, EPF, ETFs**, and more.

So, strap in – we have a **long learning road ahead**, but trust me, the view from the retirement summit is worth every step.  

---

### Key Takeaways  

1. **Weighted‑average returns:** In a multi‑asset portfolio, the overall CAGR is the sum‑product of each asset’s weight and its expected return.  
2. **Equity is king:** A solid equity exposure (via SIPs) is essential for building wealth over a long horizon.  
3. **Small, regular investments compound:** Even modest monthly SIPs, when coupled with compounding and periodic hikes, can snowball into a massive retirement corpus.  

Keep these nuggets in mind, and you’ll be well‑armed to tackle the numbers that matter. Happy (future) retiring!  