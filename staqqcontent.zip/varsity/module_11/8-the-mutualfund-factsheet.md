# 8. The Mutual‑Fund Fact‑Sheet  

**Source:** <https://zerodha.com/varsity/chapter/the-mutual-fund-fact-sheet/>  

---  

## 8.1 – The Mutual‑Fund World  

In the last chapter we played a little “pretend‑bank” game: we pooled some pretend cash, bought a pretend basket of stocks, and discovered that a fund is just a big, friendly pool where many investors toss their money in, hoping the fund manager can turn it into a nice, shiny profit. We deliberately kept the story simple—like a cartoon version of a mutual fund—because the goal was to get you comfy with the *structure* of a fund and why it matters to you.

By now you should also have met **NAV** (Net Asset Value) and its trusty side‑kick, the *unit* of a mutual fund. If those still sound like alien jargon, give the previous chapter a quick reread; the concepts are the foundation for everything that follows.

Now we’re ready to graduate to the star of today’s show: the **fund fact‑sheet**. Think of it as the fund’s résumé, LinkedIn profile, and dating bio all rolled into one—everything a savvy investor needs to know before swiping right (or, you know, investing). In this chapter we’ll pull a fact‑sheet off the screen, walk through every line, and decode the jargon with a side of sarcasm.

![Illustration of a fact‑sheet](https://zerodha.com/varsity/wp-content/uploads/2019/12/M11-C8-Illustration-300x200.jpg)

But before we dive into that one‑pager, let’s take a quick reality‑check on how massive the Indian mutual‑fund industry really is. Knowing the scale helps you see whether you’re dealing with a niche boutique or a financial behemoth.

**Industry snapshot (July 2021):**

| Metric | Figure | What it actually means |
|--------|--------|------------------------|
| **Fund houses (AMCs)** | **45** | 45 companies have the SEBI licence to run mutual‑fund schemes. Think of them as the “restaurants” that cook up different investment dishes – Kotak AMC, HDFC AMC, ICICI Pru AMC, Axis AMC, DSP, etc. |
| **Schemes (individual funds)** | **1,510** | Each AMC can launch multiple schemes, each with its own investment goal. Nippon AMC tops the list with 145 schemes, SBI follows with about 144, and ICICI Pru with roughly 143. |
| **Total assets under management (AUM)** | **₹35.15 Lakh crore** | The whole industry manages this gargantuan sum. For perspective, SBI AMC alone handles about **₹5.23 Lakh crore**, while Axis AMC is at **₹2.08 Lakh crore**. |
| **Retail vs. corporate share** | **₹18.85 Lakh crore** (≈ 53 % retail) | Money that comes from everyday Indians like you and me. |
| | **₹16.30 Lakh crore** (≈ 47 % corporate) | Money that flows in from companies, pension funds, etc. |
| **Unique individual investors** | **2.39 crore** | Over 23 million Indians hold mutual‑fund units across all AMCs. |

These numbers aren’t strictly required for your next SIP, but they’re handy for *perspective*—you’re not buying a one‑person lemonade stand; you’re stepping into a market the size of a small country.  

---  

## 8.2 – The Fund Fact‑Sheet  

An **Asset Management Company (AMC)** is the “chef” that creates and runs a mutual‑fund scheme. An AMC can have dozens of schemes, each with a **specific investment objective**—the fund’s North Star. For example, a scheme might aim to “track the top 100 large‑cap stocks” or “focus on the top 100 small‑cap stocks”. That objective is set at the fund’s birth and the fund manager is contractually bound to stick to it for the life of the fund (or until the fund is closed, but that’s a story for later).

Let’s pull a real fact‑sheet and see what it looks like. I’ll use **Kotak AMC** as our test case. No, I’m not endorsing them—just a random pick, like choosing a random pizza topping to illustrate the menu.

### Getting to the fact‑sheet  

1. Visit the AMC’s website.  
2. Click on the “Funds” section. You’ll see a row of tabs: **Equity, Tax Saver, Hybrid, Debt, Liquid**, etc. Think of them as different food courts in the same mall.  
3. For now we’ll stay in the **Equity** aisle because we’re interested in stock‑based funds.  
4. Scroll through the list and click on **“Kotak Small‑Cap Fund”**. Kotak calls its one‑page summary a **“One‑Pager”**—the fund’s Tinder profile, if you will.  

> **Side note:** SEBI (the regulator) requires the fund’s name to be a clue about its strategy. So “Kotak Small‑Cap Fund” instantly tells you, “Hey, we love tiny companies.”  

### The first page (the “cover letter”)  

![Kotak Small‑Cap fact‑sheet front page](https://zerodha.com/varsity/wp-content/uploads/2019/12/Image2_factsheet-216x300.png)

The opening paragraph spells out the **stated objective**:

> *“Kotak Small‑Cap generates capital appreciation from a diversified portfolio of equity & equity‑related securities by investing predominantly in the small‑market‑capitalisation companies across sectors.”*

Let’s break that down, bar‑style:

| Phrase | What it actually means |
|--------|------------------------|
| **Diversified portfolio** | Not putting all the eggs in a single basket—or even in a single basket of the same size. The fund spreads its money across many sectors. |
| **Equity & equity‑related securities** | Mostly stocks, but could also include things like convertible bonds that behave like stocks. |
| **Predominantly in small‑cap companies** | The fund’s GPS is set to “small‑cap town”. |
| **Across sectors** | It won’t bet everything on, say, biotech; it will also dabble in finance, consumer, etc. |

The next paragraph explains Kotak’s **research methodology**. You don’t need to memorize it—if you already know how to pick a good stock, you could just buy the stocks yourself. Still, here’s the cheat‑sheet for the curious:

| Research focus | Why it matters |
|----------------|----------------|
| **Promoter integrity** | No one wants a promoter who disappears like a magician’s rabbit. |
| **Cash‑flow generation** | Companies that actually make money (instead of just printing it on paper). |
| **Cycle experience** | Surviving a recession is a good sign of resilience. |
| **Simple business model** | If you need a PhD to understand what the company does, run! |
| **Quality metrics** | All the key financial ratios should be in the green. |
| **Business quality** | “Good quality business” – basically, the kind of company your grandma would be proud of. |
| **Low leverage** | Little or no debt; otherwise the company could be a “leveraged house of cards”. |

If you’re not a finance nerd, skim past this. The takeaway: the fund manager claims to be diligent, but you don’t have to verify every bullet point yourself.  

---  

## 8.3 – Other Fund Facts  

The fact‑sheet is a treasure chest of data points, many of which introduce us to the jargon that makes mutual‑fund talk sound like a secret society. Below is the snapshot we’ll decode.

![Fund facts snapshot](https://zerodha.com/varsity/wp-content/uploads/2019/12/Image-3_fund-facts.png)

### Benchmark – the fund’s “rival”  

A fund **must** pick a benchmark index that mirrors its investment universe. This is the yardstick that lets you ask, “Did the fund beat the market or just ride a wave?”  

- For a **small‑cap** fund, the logical benchmark is a **small‑cap index** (e.g., Nifty Small‑Cap 250).  
- If a small‑cap fund were measured against a large‑cap index like the Nifty 50, that’d be like comparing a **Wagon R** to a **Ferrari**—completely unfair and, frankly, a bit of a scam.  

### Scheme type – three quick tags  

| Tag | Meaning |
|-----|---------|
| **Open‑ended** | No expiry date. The fund lives forever (or until the AMC decides to close it). Think of it as a Netflix subscription—keeps rolling unless you cancel. |
| **Equity** | The asset class is stocks. (Other asset classes include Debt, Hybrid, etc.) |
| **Growth** | The fund’s NAV grows by reinvesting profits; you don’t get periodic cash payouts. We’ll talk more about “Growth vs. Dividend” later. |

#### Open‑ended vs. Closed‑ended (quick recap)  

- **Open‑ended** – You can buy or sell units on any business day at the NAV. Most retail investors stick with these.  
- **Closed‑ended** – The fund has a fixed lifespan (e.g., 3‑year fund). At the end, the fund is liquidated and proceeds are returned. Rare for everyday investors.  

### Fund manager – the captain of the ship  

Knowing who’s steering the boat matters. A quick Google search on the manager’s background, experience, and track record can give you peace of mind. After all, you’re trusting this person with **your hard‑earned rupees**.  

### Allotment date – fund’s birthday  

The **Allotment Date** tells you when the fund launched. Older funds have a longer performance track record, making it easier to compare them against peers. Not a deal‑breaker, but useful for context.  

### Plans & Options – the “menu”  

#### Regular vs. Direct  

| Plan | Who pays the commission? | Effect on you |
|------|--------------------------|----------------|
| **Regular** | The distributor (agent) gets a commission from the AMC. | Slightly lower returns because the commission is baked into the expense ratio. |
| **Direct** | No middle‑man. You deal straight with the AMC. | Higher returns (usually 0.5‑1 % less expense). |

> **Pro tip:** When you buy through Zerodha, you’re automatically on the **Direct** plan, so you get the cheaper, “no‑middle‑man” pricing.  

#### Dividend vs. Growth options  

1. **Dividend payout** – The fund receives dividends from its stock holdings and passes the cash to you (or lets you reinvest). This is called **“Payout of Income Distribution cum Capital Withdrawal”**.  
2. **Dividend Re‑investment Plan (DRIP)** – Same dividend, but the cash is automatically used to buy more units of the same fund. Technically it’s **“Reinvestment of Income Distribution cum Capital Withdrawal.”**  
3. **Growth** – No dividends are paid out; all earnings stay inside the fund, compounding over time. Most long‑term investors (including yours truly) love the growth option because it maximises compounding.  

#### SIP (Systematic Investment Plan)  

A **SIP** is like a disciplined Netflix binge: you commit to investing a fixed amount every month for as long as you can. Example: **₹5,000** into the Kotak Small‑Cap Fund on the **5th** of each month.  

- **Minimum SIP amount:** **₹1,000** per month.  
- **Minimum SIP tenure:** **6 months**.  

SIPs are a *big* deal—so much so that we’ll give them an entire chapter later. For now, just remember they turn a lump‑sum investment into a manageable habit.  

#### Minimum investment (non‑SIP)  

If you don’t want to set up a SIP, you can still get in with a **one‑time** investment of **₹500** (or **₹1,000** if you prefer the monthly SIP route).  

#### Load structure – the “exit fee”  

| Load type | What it is | Current status (as per sheet) |
|-----------|------------|------------------------------|
| **Entry load** | A fee you pay **when you buy** the fund. | **Nil** – entry loads were banned years ago, but AMCs still list “0 %” for legacy compliance. |
| **Exit load** | A fee you pay **when you sell** before a certain period. | **1 %** if you exit **within 1 year**; **0 %** thereafter. |

Think of exit loads as a “break‑up penalty” for leaving too soon.  

---  

## 8.4 – The Riskometer  

SEBI forces every AMC to give a **self‑assessment of risk** so investors aren’t fooled into buying a “low‑risk” product that’s actually a roller‑coaster. The visual tool is the **Riskometer**—a needle that points to a risk band.

![Riskometer illustration](https://zerodha.com/varsity/wp-content/uploads/2021/08/Riskometer.png)

For Kotak Small‑Cap, the needle sits squarely in **“Very High”**. The accompanying text confirms it: this is a high‑volatility, high‑potential‑return fund.  

Does that mean you should run away? Not necessarily. Remember the timeless mutual‑fund mantra: **time is the antidote to risk**. The longer you stay invested, the more the compounding effect smoothes out the bumps. We’ll revisit risk‑adjusted returns in later chapters.  

---  

### Key Takeaways  

- A **fund fact‑sheet** is the all‑you‑need‑to‑know cheat sheet for any mutual‑fund scheme.  
- The **investment objective** is the fund’s mission statement; the manager should stick to it like a GPS.  
- **Open‑ended** funds have no expiry date; **closed‑ended** funds are time‑boxed.  
- **Regular plans** pay distributor commissions → slightly lower returns. **Direct plans** skip the middle‑man → higher returns.  
- Investors can choose between **dividend payout**, **dividend reinvestment**, or **growth** (no cash payouts, all compounding).  
- The **Riskometer** is a self‑rated risk gauge required by SEBI; higher risk isn’t a death sentence, just a signal to stay the course.  

Now that you’ve mastered the fact‑sheet, you’re ready to stalk any mutual‑fund like a savvy investor at a cocktail party—knowing exactly what you’re ordering before you raise the glass. Cheers! 🍻