# 26. The Mutual‑Fund Portfolio  
*Source: <https://zerodha.com/varsity/chapter/the-mutual-fund-portfolio/>*  

---  

## 26.1 – Assumptions  

We’ve finally crawled to the last stop on the Mutual‑Fund Express: **portfolio construction**. I’ve been chewing on how to explain this for days, and honestly it feels like trying to teach a goldfish to do algebra – a *herculean* task, but hey, we’ll give it a whirl! 😊  

Before we start the fun part, let’s get a couple of **ground rules** out of the way. When you talk about building **any** portfolio (mutual‑fund, equity, or even a collection of exotic houseplants), you need two safety nets already in place:  

| ✅ | What you need first |
|---|----------------------|
| **1️⃣ Cover for the risk** | A proper insurance umbrella (life + health). |
| **2️⃣ Cover for emergencies** | A cash‑ready emergency corpus. |

### Why these two?  

#### 1️⃣ Cover for the risk  
Life loves to throw curveballs – a busted knee, a sudden job loss, a surprise “I’m pregnant!” (if you’re not ready), or a broken heart that needs therapy. You can’t insure *everything* (sorry, there’s no “bad‑decision‑insurance”), but you *must* protect against the two biggest financial black‑holes:  

| Risk | Typical product | Why it matters |
|------|----------------|----------------|
| **Loss of life** | **Term life insurance** – cheap, pure protection. | Keeps your family from having to sell the couch to pay bills. |
| **Hospitalisation** | **Health insurance** – covers big hospital bills, not the coffee shop receipts. | Prevents you from dipping into your retirement pot for a broken leg. |

I won’t dive into the actuarial rabbit hole now, but the takeaway is: **insurance is the foundation of personal finance**. And a quick tip – steer clear of “investment‑linked insurance” policies. They’re the financial equivalent of a “buy‑one‑get‑nothing” deal.  

#### 2️⃣ Cover for emergencies  
An **emergency corpus** is your “just‑in‑case‑the‑universe‑decides‑to‑be‑mean” stash. It’s not the same as health‑insurance; it’s cash you can actually *spend* right now.  

*Real‑life example:* In September 2020, both my parents caught COVID‑19. The hospital demanded a cash‑up‑front admission fee. My insurance later reimbursed them, but I still needed **ready money** to get them through the door.  

Or: because of the pandemic, my 10‑year‑old needed a laptop and a printer for online school. No insurance covered that, but my emergency fund did.  

How much should you stash? The classic rule‑of‑thumb is **six months of expenses**, but I’m not a fan of one‑size‑fits‑all. If your monthly spend is ₹40,000, that’s ₹2.4 lakh. However, each family’s cash‑needs are different – a single‑person freelancer vs. a family of five will have different thresholds. Sit down, run a few “what‑if” scenarios, and pick a number that lets you **sleep at night**.  

Once you have **insurance** and an **emergency corpus**, you’re ready to move on to the *real* fun part: building that mutual‑fund portfolio.  

---  

## 26.2 – Financial Goal  

A **financial goal** is just a fancy way of saying “what the heck am I saving for?” It always has three ingredients:  

1. **The amount of money you need** (the “quantum”).  
2. **The time‑horizon** you have to collect it (the “estimated time”).  
3. **Your current age** (because the younger you are, the more risk you can take).  

If any of these are missing, you’ve got an *incomplete* goal – like trying to bake a cake without flour.  

### Example Goal‑Cards  

| 🎯 Scenario | Age | Goal | Target amount | Time horizon |
|------------|-----|------|----------------|--------------|
| **Newly‑wed couple** | Late 20s | Buy a 2‑BHK downtown | ₹1.5 crore (≈ 150 lakh) | 10 years |
| **Mid‑career professional** | 40 y | Upgrade car | ₹55 lakh | 5 years |
| **Fresh grad** | 21 y | Master’s in UK | ₹20 lakh | 8 years |

No two people will have identical goals (except maybe “retire at 60 with a beach house” – but even then, beach preferences differ).  

### Why mutual funds?  

Because they’re the **Swiss‑army knife** of the investment world: flexible, diversified, and available in a zoo of categories (large‑cap, mid‑cap, ELSS, ETFs, you name it). Other instruments exist, but none juggle risk‑adjusted returns the way mutual funds do.  

#### Two ways to teach you portfolio building  

1. **Case‑study buffet** – I give you 20 different life‑scenario menus; you pick the one that looks most like yours and copy the recipe.  
2. **Ingredient‑kit** – I teach you the basic “flavour profiles” of funds (large‑cap, debt, hybrid, etc.) so you can **mix‑and‑match** your own dish.  

Think of it like this:  

*Approach 1* = “Here’s a platter of 20 samosas; try them all and pick your favourite.”  
*Approach 2* = “Here are the 5 essential spices; learn how to use each and you can cook anything.”  

I’ll go with **Approach 2** because it gives you lasting skills (and fewer crumbs on the sofa).  

---  

## 26.3 – Mutual‑Fund Cheat Sheet  

Below is the cheat sheet I cooked up. It’s a compact table that lists every fund type we’ve covered, plus a few extra columns you’ll actually use. Click the image to zoom in – it’s like a cheat code for your portfolio.  

![Mutual‑Fund Cheat Sheet (click to enlarge)](https://zerodha.com/varsity/wp-content/uploads/2020/12/Image-1_CS-300x77.png)  

**What the columns mean**

| Column | What it tells you |
|--------|-------------------|
| **Fund type** | Large‑cap, Mid‑cap, Debt, Hybrid, ELSS, Index, etc. |
| **Category** | The broader bucket (e.g., “Equity”, “Debt”). |
| **Main constituents** | What the fund actually owns (e.g., “Top‑30 blue‑chips”). |
| **Expected CAGR** | Rough annual growth you might expect (yes, I still put it in, even though I hate chasing numbers). |
| **Min. holding period** | The “stay‑at‑home” rule – you can sell anytime, but exiting before this period often means a painful draw‑down. |
| **Financial Goal fit** | Which type of goal the fund is best for (short‑term, tax‑saving, retirement, etc.). |
| **Special remarks** | Any quirks – high expense ratio, sector bias, lock‑in, etc. |

Keep this table bookmarked like a secret recipe; you’ll refer to it every time you assemble a new portfolio.  

### How many funds should you actually hold?  

I’ve seen people juggle **10–12 funds** for a single goal – 3 large‑cap, 4 mid‑cap, a handful of debt, maybe a hybrid for good measure. That’s the financial equivalent of “too many cooks spoil the broth”.  

**Rule of thumb:** **Minimise overlap**. If you own three large‑cap funds, check their top‑10 holdings – they’ll likely be *nearly identical*.  

| Example large‑cap funds | Overlap in top holdings |
|------------------------|--------------------------|
| Axis Bluechip          | 10 % HDFC Bank, 8 % Infosys, … |
| Mirae Asset Large‑Cap  | 10 % HDFC Bank, 7 % Infosys, … |
| Canara Rob Bluechip    | 9 % HDFC Bank, 8 % Infosys, … |

The picture below (click to enlarge) shows the overlap – roughly **half** of the portfolio is the same across all three. That means you’re paying extra expense ratios for *the same exposure*.  

![Overlap of three large‑cap funds (click to enlarge)](https://zerodha.com/varsity/wp-content/uploads/2020/12/Image-2_ct-300x241.png)  

**When is duplicate ownership justified?** Only if you’re terrified that a single AMC might go belly‑up (unlikely, but possible). In that case, spread the money across two *different* AMCs **and** across **different market‑caps** (e.g., one large‑cap from HDFC, one mid‑cap from DSP).  

Bottom line: **Aim for a clean, non‑overlapping portfolio**. It won’t be perfect (you can never get 0% overlap), but the lower the better. Otherwise you’re just paying for a “double‑dip” that never happens.  

---  

## 26.4 – Portfolio, by the Method of Elimination  

Now let’s roll up our sleeves and apply the **elimination method** to three real‑life cases. Think of it as a *financial version of “Who’s the Spy?”* – we keep crossing out the wrong suspects until only the guilty (i.e., the right funds) remain.  

### Case 1 – The Dream‑Home Couple  

**Profile**  

| Detail | Value |
|--------|-------|
| Age | Late 20s (young, can take risk) |
| Monthly savings | ₹30 k each (₹60 k total) |
| Target corpus | ₹1.5 crore |
| Time horizon | 10 years |

**Step 1: Eliminate the obvious** – With a 10‑year horizon, **debt‑only** isn’t needed as the primary engine (though debt will have a side‑role later).  

**Step 2: Scan the Equity menu** – Which equity buckets survive a 10‑year stretch?  

| Fund type | Why we *might* drop it |
|-----------|------------------------|
| Large‑&‑Midcap (mixed) | Usually a “mid‑cap‑heavy” blend – not pure large‑cap exposure. |
| Small‑cap | Very volatile; okay for 10 years but can be a roller‑coaster you might not enjoy. |
| Multi‑cap | A mash‑up of large, mid, small – adds complexity, no clear edge. |
| Focused | Concentrated bets – if the manager messes up, you feel the pain fast. |
| Thematic | Sector‑specific; a sector slump could wreck the plan. |
| ELSS | Tax‑saving is nice, but you’re not chasing a tax break here. |
| Index | Great for **very long‑term** (20‑30 years) – 10 years may be too short to ride the market’s ups & downs. |

**Result:** All the above get *crossed out*.  

**Step 3: What’s left?**  

| Remaining options |
|-------------------|
| Large‑cap fund |
| Mid‑cap fund |
| Value fund (but…) |

I’d also **drop the Value fund** – unlocking “value” can take ages, and you already have a mid‑cap component that captures growth.  

**Final pick:** **One large‑cap** + **one mid‑cap**. They’ll give a balanced mix of stability (large‑cap) and upside (mid‑cap).  

**How does the math look?** Assuming a **10 % CAGR** for both funds (a reasonable, not wildly optimistic, figure):  

| Year | SIP (₹60 k) | Accumulated value at 10 % |
|------|-------------|---------------------------|
| 1 | 7,20,000 | 7,92,000 |
| 2 | 14,40,000 | 18,00,000 |
| … | … | … |
| 10 | 7,20,00,000 | **≈ 1.21 crore** |

*(Full table omitted for brevity; the gist is you end up near ₹1.21 crore, only a tad shy of the ₹1.5 crore target. A modest home‑loan can bridge the gap.)*  

**What about market crashes near the end?**  

When you’re in the **final 2–3 years**, consider **parking a chunk** of the corpus into an **ultra‑short‑term debt fund** (or even a liquid fund).  

- **When?** From Year 8 onward.  
- **How?** Systematically withdraw a portion (monthly/quarterly) and shift it to a low‑volatility fund.  
- **Why?** To dodge “sequence risk” – the chance that a market dip hits just as you need the money.  

It’s a “fill‑it‑and‑shut‑it” plan, but **do a yearly check‑up** on fund performance; you might want to rebalance if a fund is lagging its peers.  

**Two golden rules** for this case:  

1. **Conservative return assumptions** – If you end up with higher returns, you’re just lucky.  
2. **Equity returns are lumpy** – Think of them as occasional fireworks, not a steady glow. SIPs smooth out the lumps over time.  

---

### Case 2 – The 40‑Year‑Old’s Kid‑College Fund  

**Profile**  

| Detail | Value |
|--------|-------|
| Age | 40 y |
| Goal | ₹25 lakh (≈ ₹2.5 crore) for children’s overseas PG |
| Time horizon | 8 years |
| Monthly SIP budget | ₹20 k |

Because the horizon is **< 10 years**, a **pure‑equity** approach is too aggressive. We’ll need **debt** for stability, with a dash of equity for growth.  

**Step 1: Dump pure‑equity categories** – Small‑cap, thematic, pure large‑cap, etc., are out.  

**Step 2: Look at the debt side**  

| Debt option | Why it’s (maybe) out |
|-------------|----------------------|
| Liquid / Overnight | Too short‑dated; you’re looking at 8 years, not 30 days. |
| Money‑market | Same problem – not enough yield for an 8‑year goal. |
| Macaulay duration < 2 y | Too volatile for a long‑run plan. |
| Credit‑risk‑heavy bonds | Higher default risk – not ideal for a conservative plan. |
| GILT (Govt. bonds) | Long‑dated, but yields are low; you need something in the middle. |

**Step 3: Keep the survivors**  

| Viable options |
|----------------|
| **Arbitrage funds** – blend of equity‑like returns with low volatility. |
| **Short‑duration debt funds** – 1‑3 year average maturity, decent yield. |
| **Corporate‑bond funds** – higher yield, but you must monitor the portfolio quarterly. |

If you don’t want to dig into individual bond holdings, **split the ₹20 k** 50/50 between an **Arbitrage fund** and a **Short‑duration fund**.  

Assuming a **7 % CAGR** (a modest figure for a mix of debt & arbitrage), you’ll reach the ₹25 lakh target comfortably.  

**Optional equity sprinkle:** Since you still have 8 years, you could allocate **20‑25 % of the SIP** to a **large‑cap fund** for a little extra growth, but keep the core in debt‑heavy funds.  

---

### Case 3 – The 50‑Lakh Lump‑Sum Retirement Stash  

**Profile**  

| Detail | Value |
|--------|-------|
| Lump‑sum | ₹50 lakh (from selling a house, etc.) |
| Goal | Build a retirement corpus (20 + years). |
| Risk appetite | Low – you’re jittery about the market’s current level. |

**Idea:** Use a **“carrier” fund** to park cash safely for the first few months, then *drip‑feed* it into a **long‑term growth fund**.  

**Step 1: Choose the carrier** – **Liquid fund** or **overnight fund** (both have near‑cash safety and ultra‑low volatility).  

**Step 2: Pick the retirement engine** – Since retirement is a **hyper‑long‑term** goal, you can afford the market’s ups & downs. Good candidates:  

- **Index funds** (low cost, market‑return).  
- **Large‑cap funds** (steady blue‑chip growth).  
- **Balanced funds** (mix of equity & debt for smoother ride).  

**Implementation:**  

1. **Park the entire ₹50 lakh** in a liquid fund.  
2. **Redeem** roughly **₹8.3 lakh each month for 6 months** (₹50 lakh ÷ 6 ≈ ₹8.33 lakh).  
3. **Invest each chunk** into your chosen retirement fund(s). If you like two‑fund combos, split the ₹8.3 lakh 50/50 between, say, an **Index fund** and a **Mid‑cap fund**.  

**Maintenance:**  

- **Yearly performance review** – make sure the retirement fund isn’t lagging its peers or becoming overly volatile.  
- **Rebalance** if needed – lock in equity gains and shift a part to debt if your risk tolerance changes.  

After the initial 6‑month “drip” phase, the portfolio is basically **set‑and‑forget** (with an annual health‑check).  

---  

## Key Takeaways  

| ✅ What you should remember |
|-----------------------------|
| **1️⃣ Insurance first** – Term life + health coverage is the non‑negotiable base of any personal‑finance plan. |
| **2️⃣ Build an emergency corpus** – Enough cash to survive 4‑6 months of expenses (or whatever your family needs). |
| **3️⃣ Define the goal clearly** – Amount + time + your age = a *complete* financial goal. |
| **4️⃣ Use elimination to pick funds** – Cross out the categories that don’t fit your horizon or risk profile; the survivors are your candidates. |
| **5️⃣ Be conservative with return assumptions** – If reality beats you, great; if not, you won’t be in trouble. |
| **6️⃣ Avoid redundant funds** – One large‑cap, one mid‑cap, maybe a debt or hybrid – keep overlap minimal. |
| **7️⃣ Retirement is a universal goal** – Treat it as a 20‑plus‑year horizon and give it equity‑heavy, low‑cost funds. |
| **8️⃣ Review once a year** – No need for daily stalking of NAVs; a yearly health‑check is enough. |
| **9️⃣ Simplicity wins** – A tidy, well‑thought‑out portfolio beats a 12‑fund spaghetti mess any day. |
| **🔟 Stay chill** – Markets will wobble; SIPs, diversification, and a solid plan keep you from losing sleep. |

That’s a mouthful, but now you’ve got the **road‑map** to design a mutual‑fund portfolio that actually works for *your* life. Got a scenario you’d like me to dissect? Drop a comment below, and let’s keep the conversation rolling!  

---  

*Next up (in a couple of chapters):* Sovereign Gold Bonds, NPS, deeper asset‑allocation tactics, and the grand finale of this module. Stay tuned, and keep those portfolios healthy!  