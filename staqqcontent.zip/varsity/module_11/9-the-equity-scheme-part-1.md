# 9.  The Equity Scheme (Part 1)

**Source:** https://zerodha.com/varsity/chapter/the-equity-scheme-part-1/  

---  

## 9.1 – October 2017  

If you survived the previous chapter, you should now be able to skim a mutual‑fund factsheet like you skim a menu at a fancy restaurant – you know the “chef’s specials” and you can spot the “extra‑cheesy” marketing fluff. Remember, a factsheet is part‑information, part‑advertisement, so sprinkle a little salt (or sarcasm) on it before you swallow.

From here on we’re swapping the “factsheet‑reading glasses” for a “category‑sorting compass”. We’ll wander through the main mutual‑fund families and dip our toes into a few sub‑families.  

> **Quick note:** “Sub‑category” isn’t a term the regulator uses, but thinking of funds this way is like using a pizza‑slice diagram to understand the world – it makes the chaos a bit more edible.

Can we cram every single sub‑category into one module? No way. The debt‑fund family alone has about 16 flavors, and equity has roughly 10‑11. Trying to catalogue them all would be like trying to list every episode of *Friends* while also explaining quantum physics – we’d lose focus on the real goal: your personal‑finance roadmap. Instead, we’ll build a solid foundation: the big‑ticket categories (and a handful of sub‑categories) so you can later navigate the whole zoo with confidence.

No conversation about mutual‑funds would be complete without a salute to SEBI’s October 2017 circular on fund categorisation. That circular was the “clean‑up crew” that finally gave the MF universe a sensible filing system. To see why it mattered, let’s time‑travel a bit.

### The pre‑Oct 2017 Wild West  

Back in the day, the mutual‑fund world was a bit like a college dorm room after a frat party: **messy** and **over‑crowded**. Asset‑management companies (AMCs) would launch a slew of schemes whose investment philosophies overlapped like bad Tinder dates.  

- **Large‑cap fund ≠ Large‑cap only:** An AMC could label a fund “large‑cap” but then slip in a handful of small‑cap stocks, spiking volatility (and potential returns) like adding ghost peppers to a mild salsa. The investor who signed up for “big‑company stability” suddenly got the roller‑coaster experience they didn’t sign up for.  

Other pre‑2017 headaches included:

| Problem | What It Looked Like | Why It Stung |
|---------|--------------------|--------------|
| **Multiple funds with identical mandates** | AMC A had three “large‑cap” funds, each promising the same thing. | Investors couldn’t tell which was the *real* deal; it was like picking a flavor of ice‑cream when they’re all labeled “vanilla”. |
| **No official definition of market‑cap** | “Large‑cap” could mean anything from the top 10 to the top 500 companies. | No one knew what they were really buying. |
| **Portfolio composition murkiness** | A “mid‑cap” fund sometimes held 60 % small‑cap stocks. | The name mislead, the returns mis‑aligned. |

These messes cascaded into **benchmarking nightmares**. A “large‑cap” fund (with hidden small‑caps) was measured against the Nifty 50 – a benchmark that assumes you’re playing with only the big‑boys. The result? Over‑inflated performance numbers in bull markets that made investors think they’d discovered the next Bitcoin.

SEBI’s October 2017 circular swooped in like a tidy‑up superhero. You can read the original **[circular here](https://www.sebi.gov.in)**.

#### What changed?  

1. **Crystal‑clear market‑cap definitions** – no more guesswork.  
   - **Large‑cap:** Companies ranking **1‑100** by full market capitalisation.  
   - **Mid‑cap:** Companies ranking **101‑250**.  
   - **Small‑cap:** **251 +**.  

2. **One‑fund‑per‑category rule** (except for thematic, index, and FoF). That means an AMC can’t launch three “large‑cap” funds that are essentially twins.  

3. **Portfolio composition mandates** – the regulator even stipulated the *minimum* percentage of stocks that must belong to the declared cap‑segment. So a “large‑cap” fund now *must* hold at least **80 %** large‑cap stocks (we’ll see the exact figure later).  

With those shackles in place, AMCs had to clean up their act, and investors finally got a map that actually matched the terrain.

Now that the dust has settled, let’s dive into the mutual‑fund categories and sub‑categories and see how they fit into our own financial life stages.

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/01/M11-C9-Illustration-1-300x200.jpg)  

---

## 9.2 – The Mutual‑Fund Universe  

At the top level there are **five** broad families, each of which sprouts a whole bunch of sub‑families. Think of it as **category → sub‑category** taxonomy – like “Animal Kingdom → Mammals → Dogs → Labradors”. Here are the big buckets:

- **Equity**  
- **Debt**  
- **Hybrid**  
- **Solution‑oriented**  
- **Other schemes**  

Below is the full “family tree” (the original diagram is reproduced verbatim so you can recognise it when you see it on your phone).

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/01/Image-1_cat-1.png)

For now we’ll zoom in on **Equity**. According to SEBI, an AMC may run *only one* scheme per equity sub‑category (large‑cap, mid‑cap, etc.), but it can have as many **sectoral** funds as it likes (think “Technology Fund”, “Pharma Fund”, etc.).

---

## 9.3 – Equity Category  

Equity funds are the **rock‑stars** of the mutual‑fund world – the most popular among retail investors. By definition, they put your money into listed company shares. Within this category, regulators have carved out **about 11 distinct sub‑categories**, each representing a different investment style, risk profile, and time‑horizon.  

The core philosophy stays the same across all of them: **grow your wealth**. The differences lie in *how fast* you expect it to grow and *how much* sleep you’ll lose at night worrying about volatility.

From my years of chatting with investors (yes, that’s a real job), I’ve noticed a common trend: **people treat equity mutual funds like day‑trading apps**. They expect instant fireworks, chase headlines, and hop from fund to fund faster than a squirrel on espresso. That mindset is a fast track to capital‑erosion.

### The right mindset for equity funds  

Your expectations must match the sub‑category you pick. Below are a few universal “don’ts” that apply across the board:

| Pitfall | Why It’s Bad | Quick Analogy |
|---------|--------------|----------------|
| **Treating equity funds as a short‑term fix** | They need **10 + years** to smooth out volatility. | Expecting a marathon runner to sprint 100 m. |
| **Thinking you can time the market** | Short‑term spikes are random; trying to catch them is like catching a greased pig. | “If I can predict the next market swing, I’ll also become a professional magician.” |
| **Switching funds like you switch TV channels** | Redemption fees, tax consequences, and loss of compounding. | “Why change the channel when the show is already good?” |
| **Reacting to every headline** | News‑driven exits break the compounding chain. | Pulling out of a movie because the trailer looked scary – you’ll miss the Oscar‑winning ending. |

If you can internalise those points, you’ll already be ahead of the crowd.

> **My personal track‑record** (just for bragging rights): I entered an equity fund in **2006** and have been adding to it ever since. As of 2020 that’s 14 years of steady investing. I’m not saying you must hold for a decade, but **10‑plus years** is my rule‑of‑thumb for “real wealth creation”. Anything less is usually a “lottery ticket” mindset.

Below is a snapshot of how my regular‑plan funds performed (remember, “direct” plans weren’t a thing back then, so the returns could have been a bit higher).

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/01/Image-2_per-rt-300x126.png)

I’m now migrating everything to the **direct** option (no distributor commission, more money in my pocket). Over the next decade that chart should look even prettier.  

Side note: I currently own **three large‑cap funds** – probably overkill. I’ll likely swap two of them for a low‑cost index fund later. Stay tuned for the “Asset Allocation & Diversification” sequel.

Alright, enough pre‑game. Let’s unpack the individual equity sub‑categories.

---

## 9.4 – The Equity Mutual‑Fund Sub‑categories  

There are roughly **ten** equity sub‑categories. Their names are mostly self‑explanatory, acting like a “quick‑look” label on a grocery shelf.

### Large‑Cap Fund  

**What it is:** A fund that primarily invests in the **top 100** Indian companies by market capitalisation. Think of these as the **Fortune 500** of India – big, stable, and usually industry leaders. Examples: **TCS, Reliance, Infosys, HDFC Bank**, etc.

**Portfolio peek:** Here’s a slice of the **Axis Bluechip Fund** (a classic large‑cap example).

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/01/Image-3_axis-300x139.png)

- **80 %** of the holdings are large‑cap stocks (as mandated by SEBI).  
- The exact weight of each stock is at the fund manager’s discretion.  

Regulators require AMCs to publish the full portfolio **once a month** in the “statutory disclosure” section of their website. So, if you’re curious, just go poke around their site – it’s free data, no subscription required.

**Why investors pick large‑cap funds:**  
1. **Capital appreciation** that roughly tracks the broad market.  
2. **Lower volatility** compared to mid‑ or small‑cap funds (still volatile, but “less spicy”).  

In plain English: you want growth, but you don’t want to lose sleep over daily market swings. Remember, even “stable” stocks can jitter – the only antidote is **time**.  

**Performance snapshot (10‑year horizon, top‑AUM funds):**

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/01/Image-4_large-300x161.png)

All the funds posted **positive returns** over a decade, confirming that a long‑haul approach works.

---

### Mid‑Cap / Small‑Cap / Large‑&‑Mid‑Cap Funds  

The names say it all:

- **Mid‑cap funds** – mainly **101‑250** market‑cap companies.  
- **Small‑cap funds** – companies **251 +**.  
- **Large‑&‑Mid‑cap funds** – a blend of both segments, usually **≈35 %** each (the rest can tilt either way based on the manager’s style).

**Volatility:** Mid‑ and small‑cap stocks are the *rock‑stars* of volatility – high highs, low lows. Hence, they demand a **long‑term commitment** just like the large‑caps, perhaps even more patience.

**Recent 2‑year performance (mid‑ & small‑caps):**

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/01/Image-5_small-and-mid-300x83.png)

The past two years were rough for these segments (think of a rainy monsoon that just won’t stop). That doesn’t mean they’ll always be down; markets cycle. For a regular investor, trying to predict the next sunny spell is akin to guessing the next cricket world‑cup winner – fun, but rarely profitable.

**10‑year performance (mid‑ & small‑caps):**

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/01/Image-6_small-and-mid-long-term-300x71.png)

Notice the **higher long‑term returns** versus large‑caps. That’s the classic risk‑reward trade‑off: more volatility, higher upside.

**Large‑&‑Mid‑Cap example:** The **DSP Large‑&‑Mid‑Cap Fund** holds a mix such as **Infosys, Airtel, HDFC Bank** (large) and **Hexaware, Hatsun Agro, V‑Guard** (mid). The exact split can vary – some managers tilt 65 % large, 35 % mid, or vice‑versa.

**Performance (10‑year view for large‑&‑mid):**

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/01/Image-7_lm-300x204.png)

As you can see, the returns sit **between** pure large‑cap and pure small‑cap funds, which makes sense given the blended risk profile.

> **How to pick *one* fund among dozens?**  
> That’s a whole other lecture (we’ll cover risk‑adjusted returns, expense ratios, and manager track‑record later). For now, just know that the **category** you choose should match your risk appetite and time horizon.

In the next chapter we’ll finish the remaining equity sub‑categories (like **sectoral**, **thematic**, **ELSS**, etc.) and then swing over to the **debt** side of the fence.

---

### Key Takeaways  

| Point | What It Means |
|-------|----------------|
| **Large‑cap definition** | Companies ranked **1‑100** by full market capitalisation |
| **Mid‑cap definition** | Companies ranked **101‑250** |
| **Small‑cap definition** | Companies **251 +** |
| **Large‑cap fund composition** | **≥80 %** of holdings must be large‑cap stocks; expected lower volatility and steadier returns |
| **Mid‑/small‑cap expectations** | Higher volatility, higher potential returns |
| **Large‑&‑mid‑cap mix** | Roughly **35 %** each of large‑ and mid‑cap stocks (actual split varies by manager) |

Keep these nuggets in your mental toolbox, and you’ll navigate the equity universe with far fewer bruises. Onwards to the next chapter – where we’ll meet the remaining equity cousins and then wade into the calmer waters of debt funds. Cheers!