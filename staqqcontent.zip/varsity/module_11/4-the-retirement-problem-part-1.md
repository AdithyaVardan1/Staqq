# 4. The Retirement Problem (Part 1)

**Source:** https://zerodha.com/varsity/chapter/the-retirement-problem-part-1/  

---  

## 4.1 – Defining the problem  

If you stare at your bank statement long enough, you’ll notice that winning at personal finance really boils down to three things that sound like a superhero’s power‑set:  

| 🔎 | **See‑through‑the‑numbers vision** – the ability to spot the hidden math in everyday spending. |
| 🎲 | **Risk‑taking muscle** – not the reckless‑cowboy kind, but the one that grows every time you read a article, listen to a podcast, or argue with your uncle about SIPs. |
| 🧠 | **Common‑sense radar** – the all‑purpose compass that tells you when a “great” investment is just a fancy way of saying “don’t buy that shiny thing”.  

If the last two chapters have already given you a decent pair of reading glasses, you should be able to peer through most of the numbers that will appear later.  

Your risk‑taking muscle is basically a function of how much you **learn** and **re‑learn**. The more you feed it, the more comfortable you become with volatility, and the better you can decide whether to ride a wave or hop off the board. The amount of risk you finally **assume** can be the difference between sipping a margarita on a beach and sipping instant‑noodles on a balcony. We’ll unpack that later in this module.  

Common sense? That’s the stuff that tells you not to put your whole savings in a “once‑in‑a‑lifetime” crypto that promises to double your money in a week. It applies to everything, from finance to whether you should wear white socks with a tuxedo. We’ll leave it at that, and you can nod in agreement. 😊  

Armed with those three ingredients, we’re about to dive into the **kitchen** of personal finance. The menu is huge, but the best way to avoid food‑coma is to pick a real‑life problem, slice it up, and then figure out the recipe for a solution. The learning “windows” (yes, I’m calling them windows, not “lessons”) that open up while you’re solving the problem will teach you the core concepts you need.  

So, let’s get the ball rolling.  

I’m guessing most of you are somewhere on the employment ladder: some are fresh‑out‑of‑college, some have a few years of experience, and a few are already halfway up the corporate mountain. No matter where you stand, **one universal goal** tends to pop up in the “future‑me” chat group: *Retire like a boss and keep living the lifestyle you think you deserve.*  

If you’re nodding, that means you’ll need roughly the **same amount of disposable cash** in retirement as you have now (maybe a little more, because you’ll be buying all those “senior‑citizen” discounts). If you end up with less, you’ll be forced into a “compromise” mode that none of us signed up for.  

![Retirement Illustration](https://zerodha.com/varsity/wp-content/uploads/2019/09/M11C4-300x200.jpg)  

### Let’s slap some numbers on the scenario  

* **Working horizon:** 25 years of earning (think of it as your “income‑generating” runway).  
* **Retirement horizon:** 20 years of sipping cocktails (or tea) after you stop punching the clock.  
* **Current disposable income:** ₹50,000 per month (after tax, rent, utilities, that daily chai‑latte, etc.).  

That ₹50 k a month translates to **₹600,000 per year**. If you want that same cash flow for 20 years of retirement, you’re looking at:  

\[
₹600,000 \times 20 \;=\; ₹12,000,000 \;=\; ₹1.2 crore
\]

Some of you might raise an eyebrow and say, “I’ll need less, I’ll move to a farm,” or “I’ll need more, I’ll buy a yacht.” That’s fine – **stick with the ₹50 k/month figure for now**; we’ll adjust later if you feel like it.  

Let’s dump this into a quick table so it looks official:  

| Year (post‑retirement) | Annual cash need (₹) |
|------------------------|----------------------|
| 1 (2044)               | 600,000 |
| 2 (2045)               | 600,000 |
| …                      | … |
| 20 (2063)              | 600,000 |
| **Total**              | **12,000,000** |

You’ll agree this is a *real‑life* problem that every adult eventually faces.  

Now break the problem into two bite‑size pieces:  

1. **How big does the retirement corpus need to be at the start of year 2044?**  
2. **How the heck do we build that corpus while we’re still working?**  

Some eager beavers might jump straight to #1 and say, “Easy – just 12 million rupees, done!” But life, unlike a spreadsheet, rarely lets us ignore **inflation**.  

So the real question is: **What lump sum do we need in 2044 so that we can withdraw ₹50 k every month for the next 20 years?**  

In this chapter we’ll tackle the **corpus‑size** part. In the next chapter we’ll talk about the **accumulation** part.  

---  

## 4.2 – Inflation and other realities of life  

If inflation were a mythical creature that lived only in economics textbooks, the math we just did would be perfect. In a *no‑inflation* world, a ₹12 million pile in 2044 would keep you at ₹50 k/month until 2064, no sweat.  

But inflation is the **real‑life gremlin** that makes everything pricier over time. Imagine you love pav‑bhaji. Today it’s ₹50 at your favourite joint. Next year you’re paying ₹55 for the same plate. That extra ₹5 is inflation’s way of saying, “Hey, I’m here, and I’m taking a cut.” In other words, **purchasing power erodes**.  

That’s why a ₹50 k monthly “budget” today will **not** buy the same basket of goods a decade from now. So you can’t simply multiply ₹50 k by 20 years and call it a day. You need to **adjust for inflation** each year.  

---  

## 4.3 – The Future value  

Enter the hero of the hour: **Future Value (FV)**. We learned how to project today’s cash need into the future in the previous chapter. The idea is to ask, “What will ₹600,000 (the annual need) be worth 25, 26, …, 44 years from now given inflation?”  

The table below (conceptually) shows what we’re after:  

| Retirement year | Years from today (2019) | Annual cash need (₹) | Future value of that need (₹) |
|-----------------|--------------------------|----------------------|-------------------------------|
| 2044 (Year 1)   | 25                       | 600,000 | ? |
| 2045 (Year 2)   | 26                       | 600,000 | ? |
| …               | …                        | …       | … |
| 2063 (Year 20)  | 44                       | 600,000 | ? |

We need to compute the **future value** for each year, then add them up. That sum will be the **corpus** you must have on day one of retirement.  

---  

## 4.4 – Estimating the future value of the corpus  

To crank out those numbers we need a **long‑term inflation assumption**. Historically, India’s CPI has hovered around **4‑5 %** per annum. Let’s pick the upper end, **5 %**, to stay on the safe side (because we’re conservative, not pessimistic).  

Now the question becomes:  

*What is the future value of ₹600,000 after 25 years of 5 % inflation?*  

And then repeat the calculation for 26, 27 … up to 44 years.  

Recall the **Future‑Value formula** from the previous chapter:  

\[
\text{FV} = P \times (1 + r)^{n}
\]

where  

* **P** = principal (₹600,000)  
* **r** = inflation rate (5 % → 0.05)  
* **n** = number of years into the future  

### Plug‑in for year 1 (25 years out)  

\[
\text{FV}_{25} = 600{,}000 \times (1 + 0.05)^{25}
                \approx 600{,}000 \times 3.386 \\
                \approx \mathbf{₹2,031,813}
\]

So, **₹2.03 million in 2044** will have the same purchasing power as **₹600 k today**.  

### Year 2 (26 years out)  

\[
\text{FV}_{26} = 600{,}000 \times (1.05)^{26}
                \approx 600{,}000 \times 3.555 \\
                \approx \mathbf{₹2,133,404}
\]

…and you get the pattern.  

Below is a **snapshot of the Excel** we used to churn out the full 20‑year series. Before you stare at it, try guessing the total corpus. Most people’s guesses are way off because they forget that **inflation compounds** just like interest—so the numbers balloon quickly.  

![Future‑Value Table Screenshot](https://zerodha.com/varsity/wp-content/uploads/2019/09/Image-1_cal-300x188.png)

**Drum roll, please…** The **total corpus needed at the start of retirement (2044)** comes out to **≈ ₹7.2 crore** when you assume 5 % inflation.  

That’s a *lot* bigger than the naïve ₹1.2 crore we first guessed, right? Changing the inflation assumption (say, 4 % instead of 5 %) will shift the number, but the principle stays the same: **inflation + compounding = huge corpus**.  

---  

## 4.5 – Oversimplification  

We’ve been a bit **theatrical** with the constant ₹50 k/month assumption. In reality, most people’s spending patterns **dip** as they age. You might trade late‑night clubbing for early‑morning yoga, skip the weekly movie for a Netflix binge, or swap designer sneakers for comfy slippers.  

Studies show that **elderly consumption** is often lower than that of younger adults, because medical expenses can be predictable (thanks to insurance) and the desire for flashy goods wanes. So the “₹50 k every month forever” is a **conservative** (i.e., safe) assumption.  

Why be conservative? Because if you **over‑estimate** your needs, you’ll end up with a buffer that can handle any surprise (like a sudden trip to Bali or an unexpected health bill). If you **under‑estimate**, you’ll be forced into a “budget‑tight” mode you never wanted.  

In the next chapter we’ll explore **how to build that ₹7.2 crore**—through systematic investing, asset allocation, and a sprinkle of luck.  

> **Download** the Excel sheet we used in this chapter [here](https://zerodha.com/varsity/wp-content/uploads/2019/09/Image-1_cal-300x188.png). (It’s a .xlsx file, not a picture—click the link.)  

### Key takeaways from this chapter  

- 🎯 Retirement is a **real‑world financial problem** that everyone eventually faces.  
- 📈 **Inflation** means today’s rupee is worth less tomorrow, so you can’t ignore it.  
- 💸 Inflation **eats away** at purchasing power, making naïve multiplication of cash‑flows wrong.  
- 🧮 Use the **Future Value** formula to translate today’s cash needs into the amount you’ll need *n* years later.  

Stay tuned for Part 2, where we’ll figure out **how to grow that massive corpus** without selling a kidney. Cheers to a financially‑fit retirement! 🍻  