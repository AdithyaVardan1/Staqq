# 2. Personal Finance Math (Part 1)

**Source:** <https://zerodha.com/varsity/chapter/personal-finance-math-part-1/>

---  

## 2.1 – Simple Interest  

When you start playing with personal‑finance numbers, the first thing you need to master is the **math** behind it.  Once the math clicks, the rest is just “press‑play” and watching your money behave (most of the time).  

In this section we’ll crack the most elementary piece of the puzzle—**simple interest**.  I know Varsity spreads this across several chapters, but for the sake of a one‑stop‑shop, let’s cram it all into a single, binge‑readable post.  

### The “friend‑in‑need” scenario  

![Cartoon](https://zerodha.com/varsity/wp-content/uploads/2019/07/M11-C2-Cartoon.jpg)

Picture this: a buddy of yours suddenly needs cash—maybe he’s bought a pet llama or something equally urgent. Being a decent human, you decide to help. But deep down you’re also a tiny bit of a capitalist, so you politely ask for a little “interest” on the loan. (Yes, it’s a bit odd to charge a friend, but pretend it’s a *friendly* interest rate, not a ransom.)

| Detail | Value |
|--------|-------|
| **Amount** | ₹ 100,000 |
| **Tenure** | 5 years |
| **Interest %** | 10 % per annum (simple) |

Your pal promises to hand back the ₹ 100,000 **plus** interest each year, calculated on the original amount.  

### Crunch the numbers  

1. **Principal** = ₹ 100,000  
2. **Interest rate** = 10 %  
3. **Yearly interest** = 10 % × ₹ 100,000 = **₹ 10,000**  

Because it’s *simple* interest, that ₹ 10,000 shows up **every** year, no matter what.  

So after 5 years the total interest earned is  

\[
\text{Total interest} = 5 \times ₹ 10,000 = ₹ 50,000
\]

You can also reach the same answer with the classic school‑day formula  

\[
\text{Interest} = \text{Principal} \times \text{Time} \times \text{Rate}
\]

\[
₹ 50,000 = ₹ 100,000 \times 5 \times 10\%
\]

That’s it—simple interest, as plain as a plain‑cheese pizza.  

> **Pro tip:** Banks *rarely* use simple interest for deposits; they love the extra sparkle of compounding. (We’ll get to that sparkle in a minute.)

---

## 2.2 – Compound Interest  

Now, imagine the same ₹ 100,000 loan, same 5‑year horizon, same 10 % rate—**but this time the interest is compounded annually**. In plain English: you earn interest *on* the interest you already earned. It’s like a snowball that keeps getting bigger because you keep adding more snow *and* the snow you already added also attracts more snow.

### Year 1  

At the end of the first year you get the principal plus 10 % of the principal:

\[
\text{Amount}_1 = \text{Principal} \times (1 + r) = 100{,}000 \times (1 + 10\%) = ₹ 110{,}000
\]

### Year 2  

Now you earn interest on the **₹ 110,000** you have after year 1:

\[
\text{Amount}_2 = \text{Principal} \times (1+r)^2 = 100{,}000 \times (1+10\%)^2 = ₹ 121{,}000
\]

### Year 3  

\[
\text{Amount}_3 = \text{Principal} \times (1+r)^3 = 100{,}000 \times (1+10\%)^3 = ₹ 133{,}100
\]

### General formula  

\[
\boxed{\text{Future Value} = P \times (1+R)^N}
\]

where  

* **P** = principal (₹ 100,000)  
* **R** = annual rate (10 % = 0.10)  
* **N** = number of years  

### Full 5‑year ride  

\[
\text{Future Value}_5 = 100{,}000 \times (1+10\%)^{5}
                     = 100{,}000 \times 1.61051
                     = \mathbf{₹ 161{,}051}
\]

So, with compounding you walk away with **₹ 161,051**—that’s **₹ 61,051** more than the simple‑interest outcome.  

> **Fun fact:** Albert Einstein allegedly called compound interest “the eighth wonder of the world.” (He probably said that while sipping coffee and watching his savings grow.)

---

## 2.3 – Compounded Returns  

Interest and return are basically two sides of the same coin:  
* **Interest** = what you *pay* when you borrow.  
* **Return** = what you *earn* when you invest.

If you’ve got the interest concept down, return will feel like a déjà vu. The only twist is that we measure return differently depending on how long you keep the money invested.

| Horizon | Measurement |
|---------|--------------|
| **< 1 year** | **Absolute return** (simple % gain) |
| **≥ 1 year** | **CAGR** – Compounded Annual Growth Rate |

### Absolute return (short‑term)  

Suppose you plunk down ₹ 100,000 on **January 1, 2019** into an instrument that promises **10 %** annual return, and you cash out exactly one year later.

\[
\text{Gain} = 10\% \times 100{,}000 = ₹ 10{,}000
\]

Your portfolio is now ₹ 110,000—an absolute return of **10 %**. Easy, right?

### CAGR (multi‑year)  

Now keep that ₹ 100,000 invested for **3 years** at the same 10 % **compounded** annually.

\[
\text{Future Value} = 100{,}000 \times (1+10\%)^{3}
                    = ₹ 133{,}100
\]

That’s the same formula we used for compound interest because, mathematically, they are twins.

#### What’s the implied growth rate?  

If you know the start (₹ 100,000) and the end (₹ 133,100) after 3 years, you can reverse‑engineer the CAGR:

\[
\text{CAGR} = \left(\frac{\text{Final}}{\text{Initial}}\right)^{\!1/n} - 1
             = \left(\frac{133{,}100}{100{,}000}\right)^{\!1/3} - 1
             = 10\%
\]

So the “annualized” growth rate that gets you from ₹ 100,000 to ₹ 133,100 in three years is exactly **10 %**, confirming our earlier assumption.

---

## 2.4 – The Compounding Effect  

Einstein’s “8th wonder” line isn’t just a witty quote; it’s a warning to never underestimate time. Compounding is the *time‑magnifier* for money: the longer you let it sit, the more it snowballs.

### A tiny example  

You invest **₹ 100** at a **20 %** annual growth rate (CAGR = 20 %).  

| Year | Starting balance | Growth (20 %) | End‑of‑year balance |
|------|------------------|---------------|---------------------|
| 0    | ₹ 100            | –             | ₹ 100               |
| 1    | ₹ 100            | ₹ 20          | **₹ 120**           |
| 2    | ₹ 120            | ₹ 24          | **₹ 144**           |
| 3    | ₹ 144            | ₹ 28.80       | **₹ 172.80** ≈ ₹ 173 |

**Two choices after Year 1**

1. **Re‑invest** the ₹ 20 profit (stay in the game). → You end up with **₹ 173** after three years.  
2. **Cash out** the ₹ 20 each year (take the profit out). → You’d have only **₹ 60** in cash after three years, plus the original ₹ 100 (if you kept it aside).  

Staying invested gave you an *extra* ₹ 13 (≈ 21.7 % more) compared to the “take‑the‑money‑out‑every‑year” approach. That extra slice is the **compounding effect**.

### Visual proof  

![Compounding Effect chart](https://zerodha.com/varsity/wp-content/uploads/2019/07/Compounding-Effect-image.jpg)

The chart illustrates how ₹ 100 growing at **20 %** each year explodes over a **10‑year** horizon. The curve isn’t a straight line; it’s an upward‑curving beast because each year you’re earning interest on a *bigger* base.

In the next chapter we’ll meet the other superhero of personal finance: **Time Value of Money** (TVM). Spoiler: TVM is basically the principle that a rupee today is worth more than a rupee tomorrow—because you can let it compound!

---

### Key takeaways from this chapter  

- **Simple interest** = interest **only** on the original principal.  
- **Compound interest** = interest on both **principal + accumulated interest**.  
- **Interest** (cost of borrowing) and **return** (earnings on investing) are two faces of the same coin.  
- **Absolute return** measures growth when the holding period is **less than a year**.  
- **CAGR** (Compounded Annual Growth Rate) measures growth for **multi‑year** horizons.  
- **Compounding** works its magic *only* when you give money enough time to grow—so be patient, or at least pretend you’re a patient gardener of cash.  

Now go forth, calculate, and let your money do the heavy lifting while you enjoy the ride (and maybe a cold beer). Cheers!