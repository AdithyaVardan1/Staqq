# 20. Mutual‑Fund Expense Ratio, Direct & Regular Plans  

**Source:** https://zerodha.com/varsity/chapter/mutual-fund-expense-ratio-direct-and-regular-plans/  

---  

## 20.1 – Expense Ratio  

In the previous chapter we geeked out over **rolling returns** and why they’re a lot more honest than that “point‑to‑point” return you brag about at parties. Now we’re moving on to another piece of the mutual‑fund puzzle that most beginners glance over: the **Expense Ratio** (or TER – Total Expense Ratio for those who love acronyms).  

We’ve tossed the term around a few times already, but never gave it a proper introduction. So let’s fix that.  

### The “Netflix‑style” fee for your money  

Think about the services you use every day: Tata Sky, Netflix, Swiggy, Dunzo, etc. You pay a monthly (or sometimes per‑order) fee because **someone has to pay the bills** – bike fuel for the delivery guy, server costs for Netflix, the satellite dish for Tata Sky, the salary of the guy who watches the cat videos so you don’t have to.  

A mutual‑fund portfolio is no different. The **Asset Management Company (AMC)** does the heavy lifting—research, trading, compliance, reporting—and they need to be compensated. That compensation shows up on your statement as the **Total Expense Ratio**.  

#### What does the AMC actually spend on?  

- Custodian fees (the “bank vault” that holds the securities)  
- Trustee fees (the watchdog)  
- RTA/registrar fees (the paperwork ninjas)  
- Portfolio manager salaries (the brainiacs)  
- Administrative costs, broker commissions, advertising, and of course, a modest profit margin  

All that adds up, and the AMC bundles it into a single percentage that it deducts from your holdings **every single day**.  

### Do we need to become a TER‑guru?  

You could dive into the calculus of how TER is computed, but for most investors a **working knowledge** is enough:

1. **How** is the fee taken?  
2. **How much** is taken?  
3. **How can I keep it low?**  

Let’s walk through a “back‑of‑the‑envelope” example—no PhD required.

#### Example: The 1 % daily‑sneak‑peek  

Suppose an AMC advertises a TER of **1 % per year**. That means for every **₹1,00,000** you invest, the AMC expects **₹1,000** a year.  

But they don’t wait till year‑end to swipe the cash; they **prorate it**:

\[
\frac{₹1,000}{365}\approx ₹2.74\ \text{per day}
\]

So while you’re sleeping, the fund is quietly taking **₹2.74** out of your portfolio each sunrise.

**How does that look on the NAV?**  

1. You buy at a NAV of **₹10** → you get  

\[
\frac{₹1,00,000}{₹10}=10,000\ \text{units}
\]  

2. Next day the fund’s assets grow **1 %** → raw NAV becomes  

\[
₹10 \times (1+0.01)=₹10.10
\]  

3. Your gross holding value would be  

\[
10,000\times ₹10.10 = ₹1,01,000
\]  

4. The fund now deducts the daily TER (₹2.74). After the deduction you own  

\[
₹1,01,000 - ₹2.74 = ₹1,00,997.26
\]  

5. The **declared NAV** (the one you’ll see on the website) is the new value divided by the units:  

\[
\frac{₹1,00,997.26}{10,000}=₹10.099726
\]  

Notice the NAV **after** TER is **₹10.09973**, a hair lower than the “raw” ₹10.10.  

**Key take‑aways from the math:**  

- The published NAV already has the TER **baked in**.  
- The fee is taken **daily**, not annually or quarterly.  
- The same deduction happens even if the fund *loses* money; the AMC still needs its cut.  

#### A quick legal‑ese side note  

SEBI (the Indian securities regulator) caps the maximum TER for equity and debt funds and even ties a ceiling to the assets‑under‑management (AUM) of a scheme. Professional fund‑accounting firms crunch these numbers, applying weighted‑average calculations so the AMC stays compliant. As an investor you don’t need to master the spreadsheet—just keep an eye on the headline TER.  

#### When does TER matter?  

If you’re comparing **two identical funds** (same manager, same strategy) and one charges **2 %** while the other charges **1 %**, the cheaper one will almost always win—*ceteris paribus*. But TER is never the only factor; you still need to look at performance, risk, consistency, etc.  

**Example snapshot:**  

| Fund | Direct Plan TER | Regular Plan TER |
|------|----------------|-----------------|
| UTI Core Equity | **2.11 %** | **2.39 %** |

Why the two numbers? That’s what the next section is all about.  

---

## 20.2 – Direct and Regular Plans  

### A nostalgic ice‑cream analogy  

If you grew up in Bangalore in the 90’s, you probably know the local ice‑cream legends: Vadilal, Dollops, Kwality, and the ever‑beloved **Joy**. My personal favourite wasn’t the flavor; it was the **price**.  

Joy had a tiny factory‑run kiosk just 500 m from my house that sold a chocolate‑bar stick for **₹14**. The same stick at the nearby “Anu Stores” (about a kilometre away) cost **₹18**. Whenever Mom gave me pocket money, I sprinted to the factory shop and snagged a couple of sticks. My siblings ate the ice‑cream, Mom saved **₹4** per stick, and I got a mini‑cardio session running up and down the street.  

Why the price gap? Because **Anu Stores needed an incentive** to stock Joy ice‑cream. The manufacturer added a markup to cover that commission. The factory‑shop sold at “cost‑plus” because there was **no middle‑man**.  

### Same story, different product  

Mutual‑funds work on exactly the same principle. You have two ways to buy a fund:

| Purchase route | What we call it | Ice‑cream equivalent |
|----------------|----------------|----------------------|
| Directly from the AMC’s website or branch | **Direct Plan** | Buying straight from the factory kiosk |
| Through a distributor, broker, bank, or online platform | **Regular (or “Advisor”) Plan** | Buying from Anu Stores (or your favourite uncle who loves to sell “schemes”) |

When you go the **regular** route, the distributor expects a **commission**. The AMC therefore **inflates the TER** to cover that commission, and the extra cost is ultimately passed on to you.  

### Real‑world numbers  

Take the **HDFC Top 100 Fund (Growth)** as an example (data lifted from HDFC’s site):

| Plan | TER |
|------|-----|
| **Direct** | **1.28 %** |
| **Regular** | **1.78 %** |

That **0.50 %** difference is the “thank‑you” to the distributor for selling the fund.  

**Remember:** The TER is **paid by you**, the investor, whether you realise it or not. In a direct plan there’s **no middle‑man**, so the fee is lower and more of your money stays invested, compounding over time.  

### Common questions that pop up  

| Question | Quick answer |
|----------|--------------|
| **Who are these “MF agents/distributors”?** | Bank branch managers, financial advisors, online platforms, or that uncle who shows up every Sunday with a brochure. |
| **Why would anyone pick the regular plan with higher TER?** | If you need professional advice, portfolio monitoring, or just don’t have the time/knowledge to manage the fund yourself, paying a bit extra for the service can be worth it. |
| **Why is the NAV of the direct plan higher than the regular plan?** | Because the regular plan’s NAV already reflects the *higher* TER. The price difference isn’t a discount; it’s the **cost** of the distributor’s commission baked into the unit value. |

#### NAV: price tag vs. value tag  

Imagine you see two identical cars on the lot: one for **₹10 Lakh**, the other for **₹9.5 Lakh**. The cheaper one looks like a bargain, right? But if the cheaper car’s price already includes a **₹50,000** dealer commission, you’re really paying the same amount for the car itself.  

The same applies to mutual‑fund units:

- **Direct NAV** (e.g., **₹460.5**) = value of the underlying assets **plus** a lower TER.  
- **Regular NAV** (e.g., **₹438.4**) = same underlying assets **minus** the extra 0.5 % TER that the distributor claims.  

So the “cheaper” unit isn’t giving you more bang for your buck; it’s simply reflecting a **lower net asset value** because part of the fund’s assets have already been siphoned off as distributor fees.  

### Bottom line on Direct vs. Regular  

- **If you’re comfortable navigating fund statements, rebalancing, and tracking performance** → go **Direct** and save the extra TER.  
- **If you want a hands‑off experience, need regular advice, or simply enjoy the comfort of a personal advisor** → a **Regular** plan may make sense, even with the higher fee.  

Either way, always look at the **TER** before you click “Invest”. It’s the silent thief that can erode returns over the long haul.  

---  

### Key takeaways  

- Mutual‑fund investing isn’t free; the service fee is called the **Total Expense Ratio (TER)**.  
- TER is expressed as an **annual percentage** but is **deducted daily** from your holdings.  
- The **published NAV already has the TER deducted**.  
- **Direct plans** have a **lower TER** because there’s no distributor commission.  
- **Regular plans** carry a **higher TER** to pay the middle‑man.  
- The **NAV of a regular plan is lower** than the direct plan’s NAV – not a discount, but a reflection of the higher fee.  
- Choose Direct if you can manage the fund yourself; choose Regular only if you truly need the advisory service and are okay with the extra cost.  

Next up: more mutual‑fund metrics that will make you sound like a Wall‑Street wizard at the next happy hour. Cheers!  