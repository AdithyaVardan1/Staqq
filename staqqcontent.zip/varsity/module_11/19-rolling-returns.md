# 19. Rolling Returns  

**Source:** https://zerodha.com/varsity/chapter/rolling-returns/  

---  

## 19.1 – Point‑to‑point return  

The last chapter was basically a crash‑course on “how do we slap a number on a fund’s performance when we know the start‑date and the end‑date”.  
So imagine I hand you this little cheat‑sheet:  

| Item | Detail |
|------|--------|
| **Fund** | Aditya Birla Frontline Equity |
| **Starting date** | 2 Jan 2013 |
| **Initial cash** | ₹1,00,000 |
| **NAV at start** | 100.83 |
| **Ending date** | 2 Jan 2015 |
| **NAV at end** | 161.83 |

You’re probably already flexing those mental calculators, right? Let’s do the maths together (and feel free to picture us with two mugs of beer while we crunch).  

1. **How many units did you buy?**  

\[
\text{Units}= \frac{₹1,00,000}{100.83}= 991.7683\;\text{units}
\]

2. **What’s the portfolio worth on 2 Jan 2015?**  

\[
\text{Value}=991.7683 \times 161.83 = ₹1,60,497.9
\]

3. **Now turn that into a CAGR (because we love “compound‑annual growth rate” more than we love “compound‑annual *growing* pain”).**  

\[
\text{CAGR}= \Bigl(\frac{₹1,60,497.9}{₹1,00,000}\Bigr)^{\frac1{2}}-1
          = 26.69\%
\]

Boom! A **26.69 %** annualised gain over exactly two calendar years. That’s the kind of number that makes you want to shout “I’m a wizard!” at the bar.

Now picture this: you’re feeling pretty smug, you swagger over to a friend, and you say, “Hey, this fund gave me **26.69 %** over the last two years.” Your friend nods, eyes sparkle, and—*bam*—he throws his life savings at the same fund.  

Hold on a sec. Did you **lie**? No. Did you **mislead**? Not deliberately. But something feels… off, right?  

The snag is that **26.69 % is a *point‑to‑point* return**. It only applies to the exact window from *2 Jan 2013* to *2 Jan 2015*. It’s a **personalized** performance snapshot, like a selfie taken at a specific angle and lighting. Change the angle (i.e., the dates) and the picture looks totally different.  

If I bought the same fund on, say, 15 Mar 2014 and sold on 15 Mar 2016, my CAGR would be a completely different number because the NAV curve isn’t a straight line. So whenever we quote a return that’s tied to a single start‑date and end‑date, we’re really saying, “This is *my* experience, not a guarantee for you.”  

That’s why the point‑to‑point metric is sometimes called a **“point‑to‑point return”** – it only tells you the growth between *those two points*. To see the whole mountain range instead of just one peak, we need something smoother: **Rolling Returns**.  

---

## 19.2 – Rolling Return  

A **rolling return** is the financial world’s version of a “daily highlight reel.” It tells you how a *n‑year* return has **evolved** over every possible *n‑year* window in the history of the fund. “Evolved” sounds fancy, but it just means: *take the return for the first n‑year period, then shift the window one day forward, compute again, keep doing that until you hit the most recent date.*  

If that sounds like a lot of spreadsheet gymnastics, you’re not wrong – but the concept is actually pretty intuitive once you see the math. (And yes, many websites already publish these numbers, but knowing the how‑to gives you a deeper intuition and the ability to double‑check the numbers on your own.)  

### The data set we’ll play with  

I grabbed the NAV history for **AB Frontline Equity Growth‑Direct** from **2 Jan 2013** all the way to **2 Jan 2020** – a solid seven‑year stretch.  

![Historical NAV table](https://zerodha.com/varsity/wp-content/uploads/2020/07/Image-1_data.png)

My mission? Compute the **2‑year rolling return**. In plain English: “What would the CAGR have been if I had bought the fund on any given day and held it for exactly two years?”  

### Step‑by‑step (with a side of coffee)  

1. **Pick the first window** – start on 2 Jan 2015 and look back two years to 2 Jan 2013.  
2. **Apply the CAGR formula** to those two NAVs.  
3. **Shift the window by one day** – now use 3 Jan 2015 vs. 3 Jan 2013, compute again.  
4. **Repeat** until you’ve walked all the way to the latest date (2 Jan 2020).  

That’s a *time series* of daily 2‑year returns.  

#### First rolling return (the “pilot” case)  

- NAV on 2 Jan 2013 = **100.83**  
- NAV on 2 Jan 2015 = **161.83**  

\[
\text{CAGR}= \biggl(\frac{161.83}{100.83}\biggr)^{\frac{1}{2}}-1 = 26.69\%
\]

#### Second rolling return  

- NAV on 3 Jan 2013 = **101.29**  
- NAV on 3 Jan 2015 = **161.45**  

\[
\text{CAGR}= \biggl(\frac{161.45}{101.29}\biggr)^{\frac{1}{2}}-1 = 26.25\%
\]

…and so on.  

I threw the numbers into Excel, slapped a couple of columns side‑by‑side, and voilà – the sheet looks like this:  

![Rolling return table](https://zerodha.com/varsity/wp-content/uploads/2020/07/Image-2_roll.png)

The **left‑most column** is the “current” date (the day you *sell*), the **right‑most column** (shaded pale yellow) is the “two‑years‑ago” date (the day you *bought*). The **blue column** shows the computed CAGR for each pair.  

### A quick sanity check  

Remember the little footnote about weekends? On the 5th Jan 2015 there was no NAV because the market was closed, so I borrowed the 3rd Jan 2013 NAV to keep the series continuous. In practice you’d either interpolate or just skip those days – it’s not a big deal for the big picture.  

If you wanted **1‑year rolling returns**, you’d start the series in 2014 (because you need a full year of history). For **3‑year rolling returns**, you’d start in 2016, and so forth. The logic stays the same – only the window length changes.  

### What can we do with the rolling series?  

1. **Find the range** – the highest and lowest CAGR in the series give you a sense of the best‑case and worst‑case two‑year outcomes.  

   **Maximum**  

   ![Max rolling return](https://zerodha.com/varsity/wp-content/uploads/2020/07/Image-3_max.png)

   **Minimum**  

   ![Min rolling return](https://zerodha.com/varsity/wp-content/uploads/2020/07/Image-4_min.png)

   *Interpretation:*  
   - **Lucky investor**: Bought on **19 Aug 2013**, sold on **19 Aug 2015** → **+37.76 %** over two years.  
   - **Unlucky investor**: Bought on **19 Sep 2017**, sold on **19 Sep 2019** → **‑0.9 %** (i.e., a loss).  

   The moral? **Two‑year returns are NOT identical**; they swing wildly depending on the entry and exit dates.  

2. **Plot them** – a line chart makes the swings crystal clear.  

   ![Rolling 2‑year return chart](https://zerodha.com/varsity/wp-content/uploads/2020/07/Image-5_graph.png)

   The chart shows the 2‑year CAGR oscillating between roughly **+38 %** and **‑1 %** over the period.  

3. **Take the average** – that’s the **Rolling Return Average**. For our dataset it works out to **15.35 %**. This number is a more realistic “what could you expect on average if you lock in a two‑year horizon at a random point in the past” than the single 26.69 % we computed earlier.  

### Putting it to work  

When you’re scouting a mutual fund, treat the rolling return like a weather forecast:  

- **Pick your investment horizon** (e.g., you plan to stay invested for 5 years).  
- **Pull the historical *n‑year* rolling returns** for that fund.  
- **Read the min, max, and average** to gauge the likely spread of outcomes.  

For example, if I’m eyeing a large‑cap equity fund for a **seven‑year** stint, I’ll look up the **7‑year rolling returns**. If the historic range is **+12 % to +25 %** with an average of **+18 %**, I have a much richer mental model than just “the fund gave 20 % over the last decade.”  

In practice, for equity funds I like to examine **rolling windows of at least 5 years** (or longer) because short windows can be noisy and over‑react to a single market crash or rally.  

That’s it for rolling returns. Next up we’ll explore other mutual‑fund metrics that matter, like expense ratios, turnover, and Sharpe ratios.  

### Key take‑aways  

- **Point‑to‑point return** tells you the growth **only** between the two exact dates you chose.  
- It **should not** be extrapolated to “any two‑year period” – doing so is a classic over‑generalisation.  
- **Rolling returns** give you a panoramic view of how a particular *n‑year* return has behaved across **every** possible *n‑year* window in the fund’s history.  
- The **rolling‑return average** is a far more useful benchmark for what you might realistically expect, while the min/max reveal the best‑ and worst‑case scenarios.  

Now go forth, calculate those rolling returns, and impress (or at least not mislead) your friends at the next happy hour! 🍻  