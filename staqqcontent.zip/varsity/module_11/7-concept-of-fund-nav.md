# 7. Concept of Fund & NAV  

**Source:** <https://zerodha.com/varsity/chapter/concept-of-fund-nav/>

---  

## 7.1 – The Family Pot  

First things first – if the previous chapter felt like you just cracked open the wiring diagram of a mutual‑fund corporation, kudos! Understanding that corporate skeleton isn’t mandatory for becoming a fund‑guru, but it does make the whole “why am I paying fees?” thing click later on.  

Now we’re about to jump into the meat (or the *dal* for our vegetarian friends) of mutual‑fund investing: categories, analysis, schemes, and all the other jargon that makes you sound smart at dinner parties. Before we start slicing that financial onion, we need to clear up a tiny, but maddeningly common, confusion: what on Earth does the word **“fund”** actually mean when we talk about mutual funds?  

I’m going to strip the concept down to its bare bones, sprinkle in a few analogies, and maybe crack a joke or two so that the idea sticks. As always, I’ll spin an imaginary story to make the abstract concrete.  

Picture yourself as the resident stock‑market prodigy in the family. You’ve already turned a few modest trades into multi‑bagger fireworks, you’ve called the market top and bottom with the confidence of a weather forecaster, and you’ve even managed to snag a selfie with the legendary Rakesh Jhunjhunwala at a conference (or at least a Photoshop‑enhanced version of it).  

Your sudden fame spreads faster than a viral meme in the family WhatsApp group. Suddenly, uncles, aunts, cousins, and that neighbour who thinks “buy low, sell high” is a phrase from a yoga class, start sliding into your DMs asking you to manage *their* money. Your “quasi‑fund‑manager” badge has been handed to you on a silver platter, and you’re buzzing with excitement.  

But—cue the legal music—**you can’t just start handling other people’s cash unless you have the proper license** (the PMS licence we chatted about in the previous chapter). So you apply, you wrestle with SEBI paperwork, you finally get the green light, and now you’re officially a licensed fund‑manager.  

Your family is ecstatic. They’re ready to dump their savings into your “magic” portfolio, and you’re ready to look like a financial wizard. Here’s the line‑up of eager investors (feel free to imagine a family portrait with everyone holding a sack of cash):  

![Family investors](/wp-content/uploads/2019/11/Image-1_family.png)  

You have **five** distinct investors, each with a different amount of cash. Together they pool **₹275,000**.  

Before you start clicking “Buy” on the stock exchange, you need to set a couple of ground rules:  

- **Equality of return** – No matter who contributed the most, everyone must enjoy the same *percentage* gain (or loss).  
- **Differentiated service** – You can still treat the aunt who put in the biggest chunk to a little better (think coffee & cookies), while the teen cousin who only threw in ₹5,000 may just get a high‑five.  

![Service differentiation](/wp-content/uploads/2019/11/M11-C7-Illustration-300x200.jpg)  

Let’s unpack those two points with a restaurant analogy because who doesn’t love food?  

Imagine you and I walk into a biryani joint. You’re a regular; the owner knows your name, your favorite spice level, and even keeps a secret stash of extra raita for you. I’m a first‑timer, so I get the standard cutlery and a polite “welcome”. Both of us order the same plate of biryani, and the *taste* and *quantity* of the dish are identical. The only difference is the *service* we receive.  

Similarly, a fund manager can give “silver‑spoon” service to high‑net‑worth investors (maybe a personal call or a fancy report), but **the investment performance must be identical for everyone**. In the mutual‑fund universe this is enforced by a single investment objective, a common mandate, and—spoiler alert—something called the **NAV** (we’ll get there).  

Now that expectations are crystal clear, let’s talk logistics. You ask every family member to transfer their money into **one single bank account**. All the cash lives together, like a giant communal pot. That pot belongs to everyone, which explains why we call them **Mutual** Funds—the money is *mutual* (i.e., shared) among all investors.  

---  

## 7.2 – The Fund Logistics  

You’ve got the licence, the cash, and the rules. Your next mission: turn that ₹275,000 into a thriving portfolio while making sure every investor gets the same *percentage* ride on the roller coaster.  

The easiest way to keep track of who owns what slice of the pie is to **issue “shares” (or units) to each investor** at the start of the fund. Think of these shares as the tickets you hand out at an amusement park; the more tickets you have, the more rides you can take.  

You can pick any notional (face) value for a share—₹5, ₹10, ₹50, whatever floats your boat. In practice, most Indian mutual funds start at a **₹10** face value, so we’ll stick with that because it keeps the math tidy and the coffee‑break jokes shorter.  

### How many shares does each person get?  

| Investor | Cash contributed | Shares received (₹10 each) |
|----------|------------------|----------------------------|
| Uncle    | ₹65,000          | 6,500                      |
| Aunt     | ₹80,000          | 8,000                      |
| Cousin 1 | ₹40,000          | 4,000                      |
| Cousin 2 | ₹30,000          | 3,000                      |
| Nephew   | ₹60,000          | 6,000                      |
| **Total**| **₹275,000**     | **27,500**                 |

![Share allocation](/wp-content/uploads/2019/11/Image-2_notional-300x98.png)  

Multiplying the total shares (27,500) by the ₹10 face value reproduces the original corpus of **₹275,000**—just like magic, but with arithmetic.  

Now the fund is *born*. As the captain of this ship, you decide to spread the cash across **ten different stocks**. To keep things simple (and to avoid a headache that would make your aunt’s coffee taste bitter), you allocate an **equal amount to each stock**:  

- Total corpus: ₹275,000  
- Number of stocks: 10  
- Money per stock: ₹27,500  

The portfolio looks like this:  

![Portfolio allocation](/wp-content/uploads/2019/11/Image-3_fund-division-300x169.png)  

Each of the ten stocks gets ₹27,500, regardless of its price per share. This is called an **equally‑distributed portfolio**—think of it as dividing a pizza into ten identical slices, even if some slices have more olives than others.  

At this point two crucial things have happened:  

1. **Shares (units) have been issued** proportional to each investor’s cash.  
2. **The pooled money has been invested** across ten equities.  

Now the market does its thing. Some stocks climb, some tumble, and the *net asset value* of the whole fund wiggles up or down. That wiggle must be passed on to the investors in proportion to how many shares they hold.  

### Let’s watch the fund on Day 2  

Suppose the ten stocks move as follows (numbers are completely made‑up, just for illustration):  

| Stock | Day‑1 price | Day‑2 price | % change |
|-------|-------------|-------------|----------|
| A     | ₹100        | ₹102        | +2 % |
| B     | ₹200        | ₹198        | –1 % |
| C     | ₹50         | ₹51         | +2 % |
| D     | ₹75         | ₹73         | –2.67 % |
| …     | …           | …           | … |

(Full table shown in the original image.)  

Because the prices shifted, the **total value of the portfolio** rises to **₹277,844**. That’s a **₹2,844** gain, or a **1.034 %** daily return.  

Now we need to make every investor’s share value reflect that 1.034 % growth. The simplest way is to **adjust the notional value of each share**:  

- **Old notional value:** ₹10  
- **Growth factor:** 1 + 1.034 % = 1.01034  
- **New notional value:** ₹10 × 1.01034 = ₹10.1034  

So every share is now worth **₹10.1034**. Multiply this by the number of shares each person holds, and you get their updated portfolio value:  

| Investor | Shares | New value per share | New portfolio value |
|----------|--------|---------------------|----------------------|
| Uncle    | 6,500  | ₹10.1034            | ₹65,672.10 |
| Aunt     | 8,000  | ₹10.1034            | ₹80,827.20 |
| Cousin 1 | 4,000  | ₹10.1034            | ₹40,413.60 |
| Cousin 2 | 3,000  | ₹10.1034            | ₹30,310.20 |
| Nephew   | 6,000  | ₹10.1034            | ₹60,620.40 |
| **Total**| 27,500 | —                   | **₹277,844** |

![New fund value](/wp-content/uploads/2019/11/Image-5_new-fund-300x97.png)  

Notice that **everyone’s percentage return is identical** (1.034 %). The *absolute* rupee gain differs because the starting amounts differ—just like the aunt who invested more ends up with a bigger tip at the restaurant.  

If you sum up all the new portfolio values, you get back the fund’s total value (₹277,844). That’s the beauty of the share‑based system: it automatically allocates profit and loss proportionally.  

### TL;DR for the mutual‑fund newbie  

- A **mutual fund** is simply a pool where many people throw in cash.  
- Everyone agrees on the **same investment objective** (e.g., “grow long‑term” or “generate income”).  
- At inception, the fund issues **units/shares** at a **notional value** (₹10 in our example).  
- That unit value changes every day based on the **Net Asset Value (NAV)**, which is the fund’s total assets minus expenses, divided by the number of units outstanding.  

#### The NAV formula (the star of the show)  

\[
\text{NAV} = \frac{\text{Value of all assets} - \text{Expenses}}{\text{Number of units (shares)}}
\]

The fund house computes this at the close of each trading day, publishes it, and investors use it to know the current price of a unit.  

That’s a wrap on Chapter 7. If you’ve followed along, you should now be able to answer this classic quiz question:  

> **On Day 3, your father‑in‑law wants to invest ₹75,000. At what unit price do you issue his shares?**  
> 
>  - The original ₹10 (the “initial” price) **or**  
>  - The updated ₹10.1034 (the “current NAV”)?  

Think about it, because the answer will reveal whether you truly grasp the concept of a **mutual fund’s NAV**.  

---  

### Key Takeaways  

- **Collective pot:** A mutual fund is a common investment vehicle where many investors combine money to chase a shared goal.  
- **Equal percentage returns:** Regardless of how much you put in, every investor enjoys the same *percentage* performance.  
- **Units at a notional value:** At launch, each investor receives units priced at a fixed face value (₹10 in our story).  
- **NAV moves daily:** The unit price (NAV) fluctuates in lock‑step with the fund’s underlying asset values, delivering the proportional gains or losses to every holder.  

Now go forth, impress your family at the next reunion, and remember: the fund may be a “mutual” thing, but the math is absolutely yours. 🎉