# 3. Personal Finance Math (Part 2)

**Source:** https://zerodha.com/varsity/chapter/personal-finance-math-part-2/

---  

## 3.1 – Money today versus money tomorrow  

![Image](https://zerodha.com/varsity/wp-content/uploads/2019/08/M11-C3-Image.jpg)

Alright, picture this: your buddy (let’s call him “Generous Gary”) is in an ultra‑philanthropic mood and tosses **two** offers at you. You can only pick **one** – classic “pick a card, any card” situation, but with cash.

| **Option A** | **Option B** |
|--------------|--------------|
| He hands you **₹10,000** **right now** (you can feel the crisp notes). | He promises to hand you the **same ₹10,000** **exactly two years from today** (think of it as a “future‑gift”). |

You don’t need the cash today – you’re saving up for a shiny new car in two years.  
So, do you:

* **Grab the cash now** and maybe spend it on a fancy dinner you’ll regret, or  
* **Wait two years** and get the money right when you need it?

(And yes, Gary is a stand‑up guy – he’ll keep his promise, no “I‑forgot‑my‑wallet” excuses.)

Which would you pick?  

If I had to guess, most of you would lean toward **Option B**. Why? Because there’s *no* immediate need, so you’d probably blow the cash on something you don’t really need, and that would be a waste. Waiting feels “safer.”

That intuition raises two big questions:

1. **Can we really treat ₹10,000 today the same as ₹10,000 tomorrow?**  
2. **How do we shift money through time so we’re comparing apples to apples?**

The answer lies in a concept that makes every finance nerd’s heart flutter: **Time Value of Money (TVM).** It tells us how to translate money from one point in time to another, letting us decide which offer is truly better.

By the end of this chapter you’ll be able to:

* Slice through the “today vs. tomorrow” debate with math, not gut feelings.  
* Apply TVM to everyday decisions (like Gary’s offer) **and** big‑ticket items like mortgages, investments, or that yacht you pretend you’ll buy one day.

TVM splits into two sides:

* **Present Value (PV)** – what a future sum is worth **right now**.  
* **Future Value (FV)** – what a present sum will be worth **later**.

Let’s dive in, shall we? 🍹  

---

## 3.2 – Present value of money  

We all love buying things that we hope will **grow** in value – whether it’s a plot of land, a vintage car, or that limited‑edition sneaker. Suppose you buy a piece of land **today** for **₹15,00,000** and hold onto it for **15 years**. At the end of that period you sell it for **₹75,00,000**. On paper that’s a **5×** return. 🎉

But before you start popping champagne, ask yourself:

> **How much is ₹75 lakh, received 15 years from now, worth in today’s rupees?**  

What if inflation, opportunity cost, or a world‑ending asteroid make that ₹75 lakh worth **less** than the ₹15 lakh you paid today?

To answer that, we need two pieces of the puzzle:

1. **What’s my “risk‑free” opportunity cost today?**  
2. **Given that cost, how much money must I invest **today** so it blossoms to ₹75 lakh in 15 years?**  

The second answer is, by definition, the **present value** of that future ₹75 lakh.

### Step 1 – Find the risk‑free rate  

The “risk‑free” rate is the return you could earn with **zero** credit risk. In practice we use the **government’s 15‑year bond** as the proxy (governments rarely default). Looking at the current bond ladder, the **2034 sovereign bond** (which is 15 years away) offers a **coupon of 7.5 %**.

> *We’ll ignore bid‑ask spreads for now – they’re a whole other rabbit hole.*

### Step 2 – Add a risk premium  

Real‑world projects aren’t as safe as a sovereign bond, so we tack on a **risk premium** (think of it as extra “thank‑you‑for‑taking‑the‑risk” cash). A modest **1.5 %** works for our example.

```
Opportunity cost = Risk‑free rate + Risk premium
                  = 7.5 % + 1.5 %
                  = 9 %
```

### Step 3 – Discount the future cash flow  

Now we “discount” the ₹75 lakh back to today using the **discount rate = 9 %** and the **time = 15 years**.

\[
\text{PV} = \frac{\text{FV}}{(1+r)^{n}}
          = \frac{75{,}00{,}000}{(1+0.09)^{15}}
\]

Crunch the numbers (or let your calculator do the heavy lifting):

\[
\text{PV} \approx \frac{75{,}00{,}000}{3.642}
           \approx 20{,}59{,}03{,}53
\]

So, **₹75 lakh in 15 years is equivalent to about ₹20,59,035 today** if you could invest at 9 % per annum.

> In plain English: If someone offered you **₹20,59,035 right now**, it would be just as good as waiting 15 years for ₹75 lakh – because you could lock that cash away, earn 9 % annually, and end up with the same ₹75 lakh.

That’s the magic of **present value**. It lets us compare “apples now” with “apples later” on an equal footing.

---

## 3.3 – Future value of money  

If present value is the “what’s it worth today?” side, **future value (FV)** is the flip‑side: “what will this money be worth **later**?”  

Continuing our land‑deal example, let’s ask:

> **If I have ₹20,59,035 today, how much will it be worth in 15 years?**

We already know the opportunity cost: **9 %**. Future value is just the reverse of discounting – we *compound* the present amount forward.

\[
\text{FV} = P \times (1+r)^{n}
\]

Plug in the numbers:

\[
\text{FV} = 20{,}59{,}035 \times (1+0.09)^{15}
          = 20{,}59{,}035 \times 3.642
          \approx 75{,}00{,}000
\]

Boom! We get the original ₹75 lakh. That’s no coincidence; **PV** and **FV** are inverses of each other.  

So, if you’re offered **₹75 lakh in 15 years** *or* **₹20,59,035 today**, the two deals are financially identical (assuming you can earn 9 % elsewhere).

---

## 3.4 – The offer (back to Gary)  

Remember Gary’s two options? Let’s re‑evaluate them with TVM in our toolbox.

| Option | Cash flow | Timing |
|--------|-----------|--------|
| A | ₹10,000 | **Today** |
| B | ₹10,000 | **2 years later** |

If you take **Option A**, you can plonk that ₹10,000 into a **2‑year fixed deposit** (FD) that yields about **7.5 %** (the current 2‑year rate). What does that become in two years?

\[
\text{FV}_{2y} = 10{,}000 \times (1+0.075)^{2}
               = 10{,}000 \times 1.1556
               \approx \textbf{₹11,556.25}
\]

That means **Option A** is effectively worth **₹11,556** after two years, assuming you lock the cash in a risk‑free FD.  

Conversely, **Option B** leaves you with **₹10,000** two years from now, which is **₹1,556** less than what you could have earned by taking the cash today and investing it.

So a **fair** comparison would be:

* **₹10,000 today** **or**  
* **₹11,556** **two years from now**.

That’s the heart‑pounding punchline of TVM: **Money today is more valuable** because you have the *option* to grow it. 🎯

---

## 3.5 – Real‑life applications  

Let’s walk through a couple of everyday (but slightly dramatized) scenarios to see PV and FV in action.

### 3.5.1 – Saving for a kid’s overseas education  

*Your daughter is 10. She’ll head to the U.S. at 25 (i.e., **15 years** from now). The projected tuition + living cost is **₹6,500,000**.*

**Step 1 – Identify the type of problem**  
We know the **future amount** we’ll need, so we need the **present value**—how much should we stash away **today**?

**Step 2 – Choose a discount rate**  
Let’s reuse the 7.5 % 15‑year government bond as our proxy.

\[
\text{PV} = \frac{6{,}500{,}000}{(1+0.075)^{15}}
\]

Crunching:

\[
(1+0.075)^{15} \approx 2.953
\]

\[
\text{PV} \approx \frac{6{,}500{,}000}{2.953}
          \approx \textbf{₹21,96,779}
\]

**Interpretation:** If you could invest **₹21.97 lakh today** at 7.5 % for 15 years, you’d end up with the ₹6.5 million needed for college. That’s the power of PV – it tells you the *starting line* for your savings race.

> *Real‑world note*: You could achieve the same goal via SIPs, mutual funds, or PPF, but the principle stays the same: you need a lump‑sum today that grows to the target amount.

### 3.5.2 – A “too‑good‑to‑be‑true” investment scheme  

*Dad’s friend, a self‑styled “wheeler‑dealer,” knocks on your door with a pitch:*  

> “Give me **₹200,000** now, and I’ll hand you **₹450,000** in 15 years.”

Let’s test it with TVM.

**Option 1 – Future‑value approach**  
Invest the ₹200,000 elsewhere at the safe 7.5 % rate:

\[
\text{FV}_{\text{market}} = 200{,}000 \times (1+0.075)^{15}
                          \approx 200{,}000 \times 2.953
                          \approx \textbf{₹590,775}
\]

The promised ₹450,000 is **far** below the market‑equivalent ₹590,775, so the deal **fails the sanity check**. You’d be better off parking the cash in a regular FD.

**Option 2 – Present‑value approach (for fun)**  
What’s the present value of the promised ₹450,000?

\[
\text{PV}_{\text{deal}} = \frac{450{,}000}{(1+0.075)^{15}}
                        \approx \frac{450{,}000}{2.953}
                        \approx \textbf{₹152,400}
\]

Since the dealer wants **₹200,000** today for a present‑value of only **₹152,400**, the deal is **overpriced** by about **₹47,600**.

Either way, politely decline, thank them for the tea, and keep your money where it can actually earn.

> **Takeaway:** You can swing either the **FV** or **PV** perspective to vet an investment. If the numbers don’t line up, the offer is likely a lemon.

---

### Key takeaways from this chapter  

* **Money today ≠ Money tomorrow** – today’s cash can be invested, so it’s inherently more valuable.  
* **Time Value of Money (TVM)** is the backbone of every personal‑finance decision, from buying a car to planning retirement.  
* TVM splits into **Present Value (PV)** and **Future Value (FV)**.  
* **PV formula**:  
  \[
  \text{PV} = \frac{\text{FV}}{(1+\text{discount rate})^{\text{time}}}
  \]  
* **Discount rate** = **risk‑free rate** + **risk premium** (the extra “thank‑you‑for‑risk” you demand).  
* **FV formula** (aka compound interest):  
  \[
  \text{FV} = P \times (1+\text{opportunity cost})^{\text{time}}
  \]  
* In the FV formula, **R** is the **opportunity cost** (the rate you could earn elsewhere). In plain compound‑interest problems, **R** is simply called the **growth rate** – same number, different label.  
* Use PV when you **know a future cash need** and want to find the present lump‑sum required.  
* Use FV when you **have cash today** and want to project its size in the future.  

Now go forth, wield the power of TVM like a financial Jedi, and impress your friends (and Gary) with decisions that are backed by math, not just gut feeling. 🚀