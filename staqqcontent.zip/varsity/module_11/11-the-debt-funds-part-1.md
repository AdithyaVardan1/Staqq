# 11. The Debt Funds (Part 1)

**Source:** https://zerodha.com/varsity/chapter/the-debt-funds-part-1/  

---  

## 11.1 – The Origins of Debt  

Alright, strap on your thinking‑cap, because over the next few chapters we’re going to dissect **debt mutual funds** the way a bartender dissects a fancy cocktail: layer by layer, with a splash of humour and a garnish of insight.  

You might remember from earlier chapters that the mutual‑fund universe houses roughly **16 different debt categories**. That’s a lot of jargon for most retail investors, so I’m going to cherry‑pick the ones that actually matter to you (and to keep the conversation from sounding like a textbook on “Debt‑ology”). The essential list is:

- Liquid funds  
- Overnight funds  
- Ultra‑short‑term funds  
- Medium‑duration funds  
- Dynamic bond funds  
- Corporate‑bond funds  
- Credit‑risk funds  
- Banking & PSU funds  
- GILT funds (two flavours)

In my humble opinion this is a **near‑exhaustive menu** that will serve most investment appetites. If you spot a missing dish, drop a comment and I’ll gladly serve it up for you.

Now, a quick reality check: **debt‑oriented, liquid and overnight funds together own about 50 % of the ₹27 lakh crore AUM** in the Indian mutual‑fund industry (as of Jan 2020). That’s half the pie, and it’s not a “just‑for‑show” slice—these funds are a core ingredient of many portfolios, especially when you need **capital protection** (think “don’t lose the bread you just baked”).

Before we can talk about *when* to park cash in a debt fund, we need to understand **where debt actually comes from**. The easiest way is to walk through a scenario most of us have at least imagined (or lived through) – buying an apartment.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/03/M11-C11-Illustration-300x200.jpg)

### The Apartment‑Buying Drama  

You’ve scoured listings, filtered on “pool”, “clubhouse”, “tennis court”, and finally zeroed in on **your dream flat** – a swanky 1.5 cr (all‑inclusive) palace of concrete bliss. You’ve saved **₹40 L** for the down‑payment, but you still need **₹1.1 cr** to close the deal.  

What’s the obvious move? Head to the bank and ask for a loan, of course. The bank will pull out its magnifying glass, sniff around your credit report (CIBIL, Experian, etc.) and decide whether you’re a trustworthy borrower or a “high‑risk” candidate.  

Assume you’ve got an **exemplary credit score** (think “superhero‑level”). The bank says “Sure thing, here’s ₹1.10 cr.” The loan terms look something like this:

| Parameter | Value |
|-----------|-------|
| **Credit score** | 850 |
| **Principal** | ₹1,10,00,000 |
| **Tenure** | 10 years (120 months) |
| **Interest rate** | 8.5 % (fixed) |
| **Total interest payable** | ₹53,66,129 |
| **Total repayment (P + I)** | ₹1,63,66,129 |
| **Monthly EMI** | ₹1,36,384 |

*(Numbers come from a handy Bajaj Finserv calculator – credit‑score part is purely fictional, of course.)*  

All of this lands on a **loan agreement** – a thick piece of paper, stamped, signed, and stored somewhere safe. The bank wires the ₹1.10 cr to your account, and your flat gets **hypothecated** (i.e. pledged) as collateral. If you ever decide to stop paying, the bank can seize and sell the flat to recover its money.

From the bank’s point of view this is a **collateralised loan**, which is the financial equivalent of “I’ll lend you my favorite bike, but I get to keep it if you crash”. Safer than an unsecured loan, right?

> **Key Insight:** A **debt obligation** is born whenever someone needs to finance an activity that costs more than the cash they have on hand.

Assuming everything goes smoothly, you’ll be sending **₹1,36,384** every month for a decade. That regular inflow to the bank is called **cash flow**.

### The Dark Side – Risks for the Lender  

Now let’s put on the banker’s night‑vision goggles and think about what could keep them up at 3 am:

| Risk | What it Means |
|------|---------------|
| **Cash‑flow risk** | You miss a few EMIs, turning a smooth river into a bumpy creek. |
| **Default risk** | You become insolvent and stop paying altogether – the dreaded “default”. |
| **Interest‑rate risk** | Market rates fall, the bank’s loan is “stuck” at 8.5 % and looks unattractive. |
| **Credit‑rating risk** | Your CIBIL score nosedives after the loan is disbursed, raising default odds. |
| **Asset risk** | The property’s market value collapses, so even after selling it the bank can’t recover the full amount. |

Those are the usual suspects. The same logic applies when the borrower is a **corporate** instead of an individual.

### Corporate Borrowing – Loans vs. Bonds  

Imagine a manufacturer wants to set up a new plant and needs **₹800 cr**. They have two avenues:

1. **Bank loan** – just like the apartment case. The contract is called a **loan agreement**.  
2. **Bond issuance** – they approach a crowd of investors, raise, say, 20 cr each, and promise to pay them interest (the **coupon**) and return principal at maturity.

A **bond** is essentially a **promissory note** from the company to its investors: “We’ll pay you X % interest every year and give back your money on the due date.”  

The three big risks that stalk bonds are:

- **Credit risk** (will the company default?)  
- **Interest‑rate risk** (will rates move against the bond’s fixed coupon?)  
- **Price risk** (the bond’s market price can swing before maturity).

> **Bottom line:**  
> - **Debt funds** are the *vehicles* that invest in these bonds/loans.  
> - As a *mutual‑fund investor* you only need to worry about **when to invest**, **what the fund does**, and **what risks it carries**.  
> - The *fund manager* worries about picking the right bonds in the **bond market**, which is huge both in India and worldwide.

With that context, let’s dive into the **different categories of debt funds**.  

## 11.2 – The Liquid Fund  

If debt funds were a family, the **liquid fund** would be the most popular cousin at every reunion. By regulation, it can only invest in debt instruments that mature **within 91 days**. In plain English: the borrower promises to return the money **in three months or less**.

### A Quick Example  

Power Finance Corporation (PFC) needs **₹150 cr** for working‑capital. It issues a **50‑day commercial paper (CP)** promising to pay **8.5 %** interest.  

HDFC AMC, sitting on **₹150 cr** of idle cash, says “Take my money, I’ll earn 8.5 %.” After 50 days, PFC pays back **₹150 cr + interest**.

Since the quoted 8.5 % is an **annualised rate**, the actual interest for 50 days is:

\[
\text{Interest} = \frac{50 \times 8.5\%}{365} \approx 1.164\%
\]

So HDFC gets back **₹150 cr + ₹1.746 cr** (≈ ₹151.746 cr). Simple, right?

### How It Works in Reality  

When a corporate borrows for such a short stint, it issues a **Commercial Paper (CP)**. The government, on the other hand, prefers **Treasury Bills (T‑Bills)**. The Indian government issues three flavours:

- **91‑day T‑Bill**  
- **182‑day T‑Bill**  
- **365‑day T‑Bill** (actually 364 days)

> *Side note*: T‑Bills are the “government‑backed” version of a CP – basically “the safest seat at the table”.

### Who Would You Lend To?  

Picture yourself with **₹100 cr** to lend. Two borrowers knock:

| Borrower | Coupon offered |
|----------|----------------|
| Sugar‑maker | 6.5 % |
| Government of India | 6.5 % |

Who gets the cash? **The government**, because there’s **zero credit risk** – they’ll always pay (barring a planetary catastrophe). The sugar‑maker has to **sweeten the deal** with a higher coupon, say **7–8 %**, to compensate you for the extra risk.

Now, suppose there are **two sugar companies**:

| Company | Track record | Coupon |
|---------|--------------|--------|
| **A** – 25 years, steady profits | 8 % |
| **B** – 5 years, break‑even, young founders | 8 % |

Which one do you fund? **Company A**, because its history suggests a **lower default probability**. Company B can still get the money, but only if it offers a **higher coupon** (perhaps **10–11 %**) to offset its riskier profile.

That’s essentially what **credit ratings** do: they translate a borrower’s credit‑risk into a **score** (just like a personal CIBIL score). The higher the rating, the lower the coupon you need to attract investors.

A liquid fund’s portfolio typically contains a **mix of CPs and T‑Bills**. T‑Bills are virtually risk‑free; CPs carry **credit risk** that varies with the issuer’s rating.

## 11.3 – Why a Liquid Fund?  

People stash cash in liquid funds when they need a **short‑term parking spot** for money they’ll use **within a year (or a year‑and‑a‑half at most)**. Think of it as a **secure garage** for your cash, rather than a **shelf‑life** investment.

### Liquid Fund vs. Savings Account  

Why not just keep the money in a bank savings account? The answer is simple: **liquid funds usually pay a higher yield**. As of **Feb 2020**, the average **savings‑account rate** hovered around **3.5 %–4 %**, while the average **liquid‑fund return** was roughly **6 %**. That extra 2 %‑plus can feel like a nice bonus.

But there’s a catch – **higher return = higher risk**. Liquid funds are **not** risk‑free; they can lose money, unlike a guaranteed FD or savings account.

### Real‑World Example: HDFC Liquid Fund  

Below is a snapshot of **HDFC’s liquid‑fund holdings** (excerpt):

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/03/Image-1_HDFCliq-300x153.png)

You’ll notice a **mix of CPs** (credit‑rated corporate paper) and **government securities** (virtually default‑free). While the corporate CPs have decent ratings today, a **downgrade** can cause a **sharp NAV dip**.

HDFC also holds **government securities**, which enjoy an implicit sovereign guarantee – that’s the “safety cushion”.

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/03/Image-2_HDFCliquid-300x71.png)

Even a solid fund like this isn’t immune to loss. Let’s look at a cautionary tale.

### The Taurus‑Fund Crash  

In **Feb 2017**, **Taurus AMC’s liquid fund** saw its **NAV plunge ~7 % in a single day**. All the earlier gains evaporated, and it took **almost a year** to climb back to its pre‑crash level.

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/03/Image-3_taurus-300x153.png)

Why? The fund held **≈ ₹2,000 cr of CPs from Ballarpur Industries**. When rating agencies **downgraded** those CPs, the market reacted violently, dragging the NAV down.

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/03/Image-4_taurus-300x198.png)

If you’re curious, read the news article linked in the original chapter – it puts the whole drama in perspective.

### TL;DR – What to Keep in Mind When Picking a Liquid Fund  

- **Purpose‑first**: Use it only to park *spare* cash you’ll need soon.  
- **Return‑expectation**: Expect a return *slightly* higher than a savings account.  
- **Risk‑acknowledgement**: It’s **not** risk‑free; you can lose money if the issuers default.  
- **Safety‑filter**: Prefer funds with a **higher proportion of government securities** (lower default risk).

That wraps up the liquid‑fund chapter. In the next installment we’ll meet its close cousin – the **ultra‑short‑term fund**. Stay tuned, keep that coffee hot, and happy investing!  

### Key Takeaways from This Chapter  

- Corporates borrow **> 1 year** via **bonds**; **≤ 1 year** via **commercial papers (CPs)**.  
- The government raises short‑term money by issuing **Treasury Bills (T‑Bills)**.  
- Borrowers pay **interest (coupon)** to lenders for the privilege of using their money.  
- Lenders face several risks: **cash‑flow, default, interest‑rate, credit‑rating, and asset risk**.  
- For lenders, **credit risk** and **interest‑rate risk** are the dominant concerns.  
- **Liquid funds** may invest in **CPs, T‑Bills, G‑Sec, SDLs, and corporate bonds** provided the residual maturity ≤ 91 days.  
- A liquid fund is **not** a proxy for a savings‑account; it carries **credit risk**, albeit modest.  

Happy “liquid‑loving” investing! 🚀