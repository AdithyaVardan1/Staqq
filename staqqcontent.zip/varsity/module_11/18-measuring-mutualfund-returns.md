# 18. Measuring Mutual‑Fund Returns  

**Source:** <https://zerodha.com/varsity/chapter/measuring-mutual-fund-returns/>

---  

## 18.1 – Mutual‑Fund Metrics  

By now you’ve probably memorised the alphabet soup of mutual‑fund categories (large‑cap, small‑cap, gilt, liquid …) and you know what makes each of them tick. We might have skimmed over the Balanced fund (oops, my bad – I’ll blame the coffee), but the point is we’ve built a solid mental framework for “what‑the‑fund‑does‑what”.  

Take a few Balanced‑fund fact‑sheets, line them up with SEBI’s classification table, and you’ll see the magic of mixing equity and debt in one pot. If anything looks fuzzy, drop a comment and I’ll untangle it faster than a barista frothing milk.  

Now that we’re one step closer to crafting a mutual‑fund portfolio that actually serves your life‑goals (buy a house, fund a kid’s MBA, retire on a beach), we need a toolbox of numbers that separate the “wow‑factor” funds from the “meh‑factor” ones.  

All the numbers you’ll see in a fund’s fact‑sheet (and the extra goodies on sites like Morningstar or Value Research) are metrics. Some are worth your attention; others are just noise.  

In the next few sections we’ll drill into the metrics most AMCs publish for every scheme they run:

- **Returns** – Absolute, CAGR, XIRR  
- **Rolling Returns**  
- **Expense Ratio**  
- **Benchmarking**  
- **Exit Load**  
- **Portfolio Turnover Ratio**  
- **Standard Deviation**  
- **Beta**  
- **Sharpe Ratio**  
- **Capture Ratios**  

If I stumble upon a hidden gem metric later, I’ll add it to the menu and we’ll chew on it together.  

That’s a lot of alphabet soup, so let’s dig in.  

---  

## 18.2 – Measuring MF Investment Performance  

A common tragedy among mutual‑fund fans is treating every investment like a single‑speed bike: you slap the same return formula on a lump‑sum, a SIP, a dividend‑re‑invested plan, and a pension fund. Spoiler alert – that leads to wrong numbers and, consequently, wrong decisions. Return measurement is the compass you need when you’re navigating the fund‑forest. Let’s start with the basics.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/07/M11-MutualFunds-C18.jpg)  

I’ll assume you already know what a Systematic Investment Plan (SIP) is. The regulators and AMCs have done a decent job preaching SIP‑ology to every taxpayer in India (well… almost everyone). If you’re still clueless, Google “SIP calculator” – you’ll find a million friendly guides.  

For completeness, let’s recap the two big‑ticket investment styles:  

| Investment Style | How It Works | Example |
|------------------|--------------|---------|
| **Lump‑sum** | You drop a one‑off amount (usually from a windfall) into a fund. | You get a Rs 1,00,000 bonus, decide to park Rs 75,000 in a large‑cap fund. |
| **Systematic Investment Plan (SIP)** | You commit a fixed amount at a regular cadence – weekly, fortnightly, monthly, quarterly, or semi‑annual. | Your first SIP is Rs 2,500 on the 5th of each month into Sundaram Mid‑Cap. No end date – it keeps humming as long as you let it. |

Because the cash‑flow pattern is different, the return‑calculation pattern is also different. Most newbies just take “ending value – beginning value” and call it a day. That works for a quick glance, but it ignores the time dimension – and time is the secret sauce of finance.  

### Why Time Matters  

Imagine I brag, “I earned an 80 % return!” You’ll probably raise a glass. But if I add, “…over 15 years,” the sparkle fades, right? 80 % over 15 years is a snail‑pace compared to 80 % in a single year. So we always need to factor *how long* the money was working.  

Let’s bucket investments by horizon and see which return metric belongs where.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/07/Screenshot-from-2021-09-06-10-41-55.png)  

The table tells us:  

- **Lump‑sum < 1 yr** → **Absolute Return**  
- **SIP < 1 yr** → **Absolute Return** (XIRR is possible but confusing)  
- **Lump‑sum ≥ 1 yr** → **CAGR** (Compound Annual Growth Rate)  
- **SIP ≥ 1 yr** → **XIRR** (Extended Internal Rate of Return)  

You don’t have to be a spreadsheet wizard to get these numbers – free calculators abound. Still, knowing the math under the hood makes you a more disciplined investor.  

### Absolute Return (the “quick‑look” metric)  

Absolute Return only matters when the holding period is under a year. It works for a one‑off lump sum **or** a short‑term SIP.  

**Formula:**  

\[
\text{Absolute Return} = \frac{\text{Ending Value}}{\text{Beginning Value}} - 1
\]

#### Example 1 – Lump‑sum under a year  

- **Invested:** Rs 25,000 on Jan 1 2020  
- **Value on July 7 2020:** Rs 30,000  

\[
\frac{30{,}000}{25{,}000} - 1 = 0.20 = \mathbf{20\%}
\]

#### Example 2 – SIP under a year  

- **Monthly SIP:** Rs 5,000  
- **Months:** 6 (so total cash outflow = 5,000 × 6 = Rs 30,000)  
- **Current value after 6 months:** Rs 35,000  

\[
\frac{35{,}000}{30{,}000} - 1 = 0.1667 \approx \mathbf{17\%}
\]

You could crank out an XIRR for a sub‑annual SIP, but most investors find the result non‑intuitive (you’ll see why later). For now, just remember: **if the clock reads < 1 yr, use absolute return.**  

### CAGR – The “average speed” of your money  

CAGR = Compound Annual Growth Rate. It tells you the *steady‑state* yearly growth that would get you from the start value to the end value.  

**Formula:**  

\[
\text{CAGR} = \left(\frac{\text{Ending Value}}{\text{Beginning Value}}\right)^{\frac{1}{n}} - 1
\]

where *n* = number of years (can be a fraction).  

#### Example – Lump‑sum over 3 years  

- **Invested:** Rs 25,000 on 1 July 2017  
- **Value after 3 years:** Rs 40,000  

\[
\text{CAGR} = \left(\frac{40{,}000}{25{,}000}\right)^{\frac{1}{3}} - 1 
= 1.6^{0.3333} - 1 \approx 0.1696 = \mathbf{16.96\%}
\]

That 16.96 % is the *average* annual growth, just like the average speed on a road trip.  

#### Why absolute return (60 %) can be misleading  

If you only look at “Rs 25,000 → Rs 40,000 = Rs 15,000 profit = 60 %”, you’re missing the *when*. Did you earn 60 % in the first year and then stagnate? Or did you crawl 0 % the first two years and explode 60 % in the third? CAGR smooths out those fluctuations and gives you a single, comparable number.  

Think of driving Delhi → Jaipur (≈ 250 km). You could report speeds for every stretch (80 km/h, 110 km/h, 90 km/h…) or just say “average 100 km/h”. Investors usually prefer the latter because it’s easy to compare across funds, just like you compare cars by their average mileage.  

#### Projecting forward with CAGR  

If your investment sits at Rs 40,000 after 3 years and you expect the same 16.96 % growth for another year:  

\[
\text{Future Value}_{1y} = 40{,}000 \times (1 + 0.1696) \approx \mathbf{Rs 46,784.28}
\]

For three more years:  

\[
\text{Future Value}_{3y} = 40{,}000 \times (1 + 0.1696)^3 \approx \mathbf{Rs 64,000}
\]

That’s the **future value** formula in action.  

**Takeaway:** Use **CAGR** when the horizon is ≥ 1 year (lump‑sum).  

### XIRR – The “CAGR for SIPs”  

XIRR = **Extended Internal Rate of Return**. It’s basically CAGR that can handle irregular cash‑flows (think monthly SIPs).  

#### Example – A 19‑month SIP  

| Date | Cash Flow (₹) |
|------|---------------|
| 10‑Dec‑2018 | -5,000 |
| 10‑Jan‑2019 | -5,000 |
| … | … |
| 10‑Jun‑2020 | -5,000 |
| 10‑Jul‑2020 (valuation) | **+1,10,000** |

Total cash outflow: 19 × 5,000 = ₹ 95,000. Current market value (as of 10 July 2020): ₹ 1,10,000.  

If you tried the simple absolute return, you’d get:  

\[
\frac{1,10,000}{95,000} - 1 = 0.1579 = 15.79\%
\]

That’s okay, but it *ignores* the fact that money was poured in gradually. XIRR does the heavy lifting. In Excel you just type:  

```excel
=XIRR(values, dates)
```

where **values** is the range of cash‑flows (negative for outflows, positive for the final valuation) and **dates** are the matching dates.  

Running it on the table above spits out **18.79 %** – the annualised growth rate of that SIP.  

#### Why we don’t use XIRR for sub‑annual SIPs  

Consider a 5‑month SIP:  

- **Monthly SIP:** ₹ 5,000 (total outflow = ₹ 25,000)  
- **Valuation after 5 months:** ₹ 30,000  

XIRR will report **≈ 106 %** annualised! That looks impressive, but it’s a *projection* of a 5‑month gain stretched over a year. Most investors find a plain 20 % absolute return far more intuitive. Hence, platforms usually show absolute return for SIPs < 1 yr.  

---  

## 18.3 – XIRR and CAGR are essentially twins  

Both XIRR and CAGR aim to answer the same question: “What’s the annualised growth rate of my money?” The only difference is the cash‑flow pattern they can digest.  

If you feed a *single* lump‑sum cash‑flow into XIRR, you’ll get exactly the same answer as CAGR.  

#### Example – Lump‑sum over 2 years  

| Date | Cash Flow |
|------|-----------|
| 3‑Jan‑2018 | -1,00,000 |
| 3‑Jan‑2020 (valuation) | +1,25,000 |

- **CAGR**:  

\[
\left(\frac{1,25,000}{1,00,000}\right)^{\frac{1}{2}} - 1 = 0.118 = \mathbf{11.8\%}
\]

- **XIRR** (Excel `=XIRR({-100000,125000},{DATE(2018,1,3),DATE(2020,1,3)})`) also yields **11.8 %**.  

So the two are mathematically identical for a single cash‑flow pair; XIRR just extends the formula to many cash‑flows.  

### Your homework (not the boring kind)  

1. Hop onto an AMC website or **coin.zerodha.com**.  
2. Pick any mutual‑fund scheme.  
3. Locate the **Absolute / CAGR / XIRR** numbers.  
4. Try to map each number to the investment horizon it represents (lump‑sum < 1 yr, SIP ≥ 1 yr, etc.).  

Post your aha‑moments in the comments – I love reading your “I‑finally‑got‑it” stories.  

Next up: **Rolling Returns** – stay tuned!  

---  

### Key Takeaways  

- **Lump‑sum < 1 yr** → use **Absolute Return**  
- **SIP < 1 yr** → use **Absolute Return** (XIRR is possible but not intuitive)  
- **Lump‑sum ≥ 1 yr** → use **CAGR**  
- **SIP ≥ 1 yr** → use **XIRR**  
- **CAGR** = the average annual growth rate of an investment.  
- **XIRR** = CAGR adapted for staggered cash‑flows (SIPs).  
- For a single lump‑sum over a year, **CAGR = XIRR**.  

Now go forth, calculate like a wizard, and may your portfolio grow faster than your favorite meme stocks!  