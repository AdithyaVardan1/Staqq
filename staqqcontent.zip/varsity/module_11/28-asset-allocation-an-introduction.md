# 28. Asset Allocation, An Introduction  

**Source:** <https://zerodha.com/varsity/chapter/asset-allocation-an-introduction/>

---

Dear Readers,  

Just like the chapter before it, this one is a **guest‑star** episode. We’re thrilled that Shyam – the brain behind Stockviz – has swooped in to drop some wisdom on us. Huge thanks to Shyam for sharing his brain‑cells (and a few jokes) on this heavyweight topic. May the Varsity‑verse keep getting richer – both in content *and* in assets! 🍻  

Happy reading!  

*Karthik Rangappa*  

---

## 28.1 – Asset Allocation, an Introduction  

**Asset** = anything you own that can (hopefully) make you richer or at least look cooler.  
**Liability** = anything you owe, which is basically the financial equivalent of a bad haircut – you wish it’d disappear.  

Assets come in every flavor: livestock, gold, stocks, bonds, vintage comic books, Picasso‑level art, copyrights, trademarks, and that weird collection of rubber ducks you’ve been hoarding since college.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2021/01/M11-C28-MF-AssetAllocation-Web-300x200.jpg)

Some assets *pay* you while you sit on them (think bonds spitting out interest), others just sit there looking pretty (think a Mona Lisa that never yields a dividend). The grand, overarching goal? **Transmit wealth through time** – i.e., make sure future you can afford the same avocado toast you love today.  

### Time value of money  

Cash is a bit of a lazy roommate: it loses value just by hanging around. Central banks call this the **inflation target**. For example, when the U.S. Federal Reserve says “We’re aiming for 2 % inflation,” a $100 bill will effectively buy only $98 worth of goods a year from now.  

In India, the RBI tries to keep inflation dancing between 4 % and 6 %. Yet 2020 closed with inflation flirting at roughly **7 %** – a bit of a party‑crasher. So, stuffing cash under the mattress is the financial equivalent of buying a ticket to a movie that never gets released.  

**Solution?** Buy assets that *grow* (or at least don’t shrink) faster than inflation.  

### Different types of assets  

![Image](https://zerodha.com/varsity/wp-content/uploads/2021/01/image-1.assets-300x279.png)

#### Precious Metals  

Since the first humans discovered that shiny rocks could be used for *both* bling and barter, gold and silver have been the OG money‑stores. Why?  

- **Rarity** – there’s only so much gold in the Earth, so it never floods the market like, say, cheap memes.  
- **Mining effort** – extracting, refining, and minting gold is a labor‑intensive process, which puts a natural floor under supply.  
- **Simplicity** – you can weigh it, melt it, and test its purity with a hot needle. No PhD required.  
- **Density** – a tiny gold bar can represent a fortune, making it easy to stash in a safe (or a pirate’s chest).  

Unsurprisingly, when markets get shaky, investors reach for gold like a kid reaches for the last piece of pizza. In countries with a history of socialist‑style property grabs and hyper‑inflation, gold becomes the *couch‑potato* of safe‑havens.  

#### Real‑estate  

Real‑estate is the “Swiss Army knife” of investing:  

- **Land speculation** – buying raw land hoping the next highway will pass by.  
- **Rental‑housing** – becoming a landlord, collecting rent, and occasionally fixing leaky faucets at 2 am.  
- **Commercial property** – office buildings, shopping malls, and warehouses that make you feel like a corporate mogul.  

Each plot is unique – they’re not fungible like gold, and you can’t just ship a house to your cousin in Tokyo. So every investor’s real‑estate journey is a bespoke, sometimes bumpy, adventure.  

#### Collectables  

Think of the **Mona Lisa**, a rare baseball card, an 1800s stamp, or a limited‑edition coin. They’re the *hipster* of assets: they look cool, have a story, and can appreciate over time if you keep them safe from sunlight and nosy relatives.  

In the last decade, the digital cousins of these treasures have stormed onto the scene – **cryptocurrencies** and **NFTs**. The biggest perk? **Divisibility**. One Bitcoin is worth > $40 k, but you can buy $10 worth of it, just like buying a single slice of pizza instead of the whole pie.  

#### Financial Assets  

These are the assets you can trade on an exchange, and they come with a nice side of **standardization** and **regulation**. Think of it as the “civilized” part of the market where everyone follows the same rulebook, and the exchange makes sure nobody cheats you out of your lunch money.  

- **Stocks / Equities** – the most liquid and crowd‑pleasing.  
- **Bonds / Fixed‑income** – the “boring but reliable” grandpa of the market.  
- **Commodities** – raw stuff like oil, wheat, or copper that people need to run the world.  

On top of these sit the **derivatives** (options, futures, etc.), which are essentially *bets on bets* and have now outgrown the underlying assets in sheer size.  

Since the 1980s, electronic exchanges have turned once‑illiquid assets (think “I need a truck to deliver a barrel of oil”) into instantly tradable tokens, thanks to **ETFs** and **derivatives**. Liquidity exploded faster than a soda can left in a sauna.  

---

## 28.2 – Allocation  

**Asset allocation** = the artful (and slightly nerdy) practice of slicing your savings into the different asset buckets we just discussed.  

### Prediction is impossible  

If we could reliably pick the next **Super‑Asset**, we’d all be lounging on private islands. Unfortunately, the future is as predictable as a cat on a keyboard.  

Take a quick look at the last two decades:  

- **2001‑2011:** Indian equities *crushed* U.S. stocks.  
  ![Image](https://zerodha.com/varsity/wp-content/uploads/2021/01/image-2.usa-india-1024x585.png)  

- **2011‑2021:** The tables turned – U.S. stocks surged while Indian equities lagged.  
  ![Image](https://zerodha.com/varsity/wp-content/uploads/2021/01/image-3.usa-india-1024x585.png)  

Who knows what the next ten years hold? Narrative‑builders will keep inventing reasons – “India shining,” “secular stagnation,” “real‑estate always goes up.” The only antidote is **diversify**: own a little bit of everything, so you’re not putting all your eggs in the “next big thing” basket.  

---

## 28.3 – Sequence Risk  

An average investor rarely *sees* the average return.  

Markets have been around for centuries, but a typical human investment horizon is a few decades at most. This mismatch creates a nasty illusion: “If the market gave a 10 % CAGR over 20 years, my 5‑year investment will also give 10 %.”  

**Investor:** “NIFTY gave a 10 % CAGR for the last 20 years, so my ₹1 lac should become ₹1.61 lac in 5 years, right?”  

**Me:** “Only if you’re lucky enough to *never* experience a negative stretch.”  

**Investor:** “But NIFTY was negative only 4 years out of every 10. I can survive two bad years.”  

**Me:** “Enter **sequence risk** – the chance that those 4 bad years *all* fall inside your 5‑year window. That would wipe out most of your gains.”  

![Image](https://zerodha.com/varsity/wp-content/uploads/2021/01/image-4.seq-risk.png)

Most people assume the **law of averages** applies to their personal timeline, which it seldom does. The easy fix? Build a **basket of assets** whose returns don’t move in lockstep, reducing the chance that a single market crash drags you down.  

---

## 28.4 – Diversification vs Diworsification  

![Image](https://zerodha.com/varsity/wp-content/uploads/2021/01/image-5.eggs_.ORNITOLOG82-ISTOCK-GETTY-IMAGES-PLUS-300x160.png)

Imagine a basket full of chicken, turkey, goose, quail, pheasant, and emu eggs. It looks *diverse* on paper, but drop it and you’ll end up with a scrambled mess – that’s **diworsification** (diversification gone wrong).  

A truly diversified portfolio starts with **understanding the drivers** behind each asset class and how those drivers interact.  

### Vectors of diversification  

Different assets are propelled by different forces (or “vectors”). A well‑crafted portfolio spreads across these vectors while minimizing overlap.  

#### Currency exchange rates  

Gold is priced globally in USD. In India, its rupee price is a combo of **global demand** *plus* the **USD‑INR exchange rate**. When the rupee weakens, gold looks pricier domestically – a perfect illustration of a cross‑currency driver.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2021/01/image-6.gold_-1024x585.png)

#### Market composition  

India’s equity market is dominated by “old‑economy” giants (think cement, steel), while the U.S. market is saturated with “new‑economy” tech titans (Apple, Google). Even though both are *stocks*, their underlying dynamics differ, demanding separate allocation.  

#### Flows during panics  

U.S. Treasuries are the classic **safe‑haven**. In a panic, investors sprint toward them, pushing prices up. Indian bonds, however, sit with other emerging‑market debt and often get sold off in the same frenzy.  

The chart below shows how U.S., Developed‑Market, and Emerging‑Market bond funds have behaved over time.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2021/01/image-7.FUSGX-PFORX-GMCDX.cumulative-1024x585.png)

#### Bubble assets  

Digital collectibles love the **boom‑and‑bust** roller coaster. Bitcoin steals the headlines, but remember **CryptoKitties**? They raised **$23 million** in VC cash, and people actually paid to breed pixelated cats.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2021/01/image-8.bitcoin.png)  

![Image](https://zerodha.com/varsity/wp-content/uploads/2021/01/image-9.crypto.png)  

The same feverish chase happens in the art world, where investors scramble to spot the next “Banksy‑in‑the‑making” and drive prices sky‑high.  

---

## 28.4 – Keeping it simple  

If you’re just starting out, stick to **big, liquid asset classes**. Think of them as the “core muscles” of a financial workout plan.  

- **Indian Equities**  
  - Large‑cap Index (e.g., NIFTY 50)  
  - Mid‑cap fund  

- **U.S. Equities**  
  - The S&P 500 gives you exposure to the world’s biggest, most globally‑connected companies. No need to chase obscure European or frontier markets – that’s like hunting for a four‑leaf clover in a desert.  

- **Bonds**  
  - Short‑term government or PSU bond funds for stability.  

- **Gold**  
  - Sovereign Gold Bonds (SGBs) issued by RBI – they actually pay **2.5 % p.a.** on top of any price appreciation.  

- **Real Estate**  
  - Exchange‑traded REITs for a liquid, hassle‑free way into property.  

If you can’t decide on the exact split, an **equal‑weight** allocation across these buckets isn’t a terrible starting point.  

**Practical tips:**  

- **U.S. stocks:** Grab the cheapest S&P 500 index fund you can find (low expense ratio = more money staying in your pocket).  
- **Bonds:** Choose a short‑duration fund that sticks to government or PSU paper – think of it as the “cushion” under your portfolio.  
- **Gold:** Go for RBI’s SGBs; they give you a modest interest plus the price movement of gold.  
- **Real estate:** Look into listed REITs; they trade like stocks and pay dividends, so you get income without the landlord headaches.  

---

## 28.5 – Risks to diversification  

Financialization – the process of turning everything from wheat to water rights into a tradable security – makes diversification **easier** (you can buy a tiny slice of a skyscraper on your phone) but also **riskier**.  

Take **real estate** again: buying a physical plot can take months, involves lawyers, and is illiquid. An **ETF‑style REIT** trades in seconds, but the moment you can buy both with a click, the underlying assets start moving together.  

Why?  

- **Same platform** → investors can leverage one asset to buy another, increasing correlation.  
- **Higher liquidity** → price swings can transmit faster across asset classes.  

Thus, while it’s a breeze to create a “rainbow” portfolio today, the **rainbow’s colors may start to blend** as more assets become financially intertwined, blunt­ing the protective power of diversification.  

---

### Keynotes from this chapter  

- **You can’t avoid owning assets** – they’re the building blocks of any wealth plan.  
- **Know the asset zoo** – understand each animal (gold, real‑estate, equities, etc.) and what feeds it.  
- **Draft an allocation plan** – keep it simple (KISS: Keep It Simple, Stupid!).  
- **Stick to the plan** – because trying to out‑guess the market is like guessing the exact moment a fireworks show will end.  
- **Nothing works forever** – markets evolve, narratives shift, and the only pragmatic strategy is to stay adaptable.  

Now go forth, diversify wisely, and remember: the only thing more certain than death and taxes is that *your portfolio will look better if you don’t put all your money into one shiny thing.* 🍀