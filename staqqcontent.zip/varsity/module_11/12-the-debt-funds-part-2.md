# 12. The Debt Funds (Part 2)

**Source:** <https://zerodha.com/varsity/chapter/the-debt-funds-part-2/>

---  

## 12.1 – Overnight Fund  

Picture this: the market has just taken a 30 % nosedive, and you’re wondering whether you should start a side‑hustle as a professional “panic‑button‑pusher.”  We’ve all seen markets get whacked by recessions, corporate scandals, political drama, wars, and even family feuds over the last slice of pizza.  But a *virus* that nobody could see before 2020? That’s a whole new level of plot twist—thanks, COVID‑19, for making the financial world feel like a bad Netflix series.  

Anyway, after we’ve taken a deep breath (and maybe a third cup of coffee), it’s time to get back to the boring‑but‑important world of **debt funds**.

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/03/M11-C12-Illustration-300x200.jpg)

In the last chapter we talked about bonds, debt structures, and the first kid on the block: the **liquid fund**.  Remember we warned that liquid funds are *not* the “risk‑free” unicorn most investors imagine?  They still carry **default risk** (the borrower might go belly‑up) and **credit‑rating risk** (the borrower’s rating can get downgraded).  The Taurus MF and Ballarpur saga were the cautionary tales that proved the point.  

An **overnight fund** tightens the screws on those risks—though it doesn’t completely eliminate them.  A liquid fund holds securities that mature in up to 91 days, a mix of corporate commercial papers (CPs) and government Treasury bills (T‑bills).  

An overnight fund, by contrast, only holds **one‑day‑old** debt.  Think of it as the “pay‑day loan” of the mutual‑fund world, except it’s *legal*, *regulated*, and doesn’t charge you 400 % APR.  The fund manager hands over cash in the morning, gets it back by the next evening—*voilà*, 24‑hour lending.  

Because the maturity is just a single day, the **credit‑rating risk** of a rating downgrade is practically nil.  The **default risk** is still there, but it’s tiny—like the chance of your toast catching fire when you’re already late for work.  

> **So, who gets the overnight loan?**  
> Enter the RBI‑regulated money‑market instrument known as a **Tri‑Party Repo** (or **TREPs**).  

I’m not going to dive into the mechanics of a TREP—explaining that would be like describing the inner workings of a coffee machine when all you really need to know is that it makes coffee.  If you’re curious, check out the official FAQ here: <https://www.ccilindia.com/FAQ/Pages/TREPS.aspx#1>  

### Let’s peek at the real‑world portfolios  

**HDFC Overnight Fund**  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/03/Image-1_HDFCovernight-300x78.png)

Every single line item is a TREP.  

**UTI Overnight Fund**  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/03/Image-2_UTIovernight-300x162.png)

Again, 100 % TREPs.  

**Bottom line:** All overnight funds basically do the same thing—lend money for a day via TREPs.  The only thing that can set them apart is the **expense ratio** (the fee the fund charges you).  We’ll chat about that later when we finally get to the “cost of living” part of investing.  

### Who should bother with an overnight fund?  

If you need to **park cash for a very short stint** (think *less than three months*), an overnight fund is the perfect “temporary parking spot.”  Anything longer than 90 days?  Grab a **liquid fund** instead.  

Don’t obsess over “returns” for an overnight fund.  You’re not there to chase a high‑flyer; you’re there for **convenience**, safety, and liquidity.  Still, if you’re the type who loves numbers, the current annualised yield hovers around **4‑5 %**.  Do the math, prorate it for a day, and you’ll see why it’s basically a “no‑loss‑no‑gain” (well, a tiny gain) instrument.  

---

## 12.2 – Ultra‑Short‑Duration Fund  

Now we’re getting to the *spicy* part of debt‑fund land.  Meet the **ultra‑short‑duration (USD) fund**—the “sprint” of the bond world, not the marathon.  

### A Day in the Life of a Debt‑Fund Manager  

Imagine you’re the manager of a debt fund.  Your job?  Find the *sweetest* places to park the fund’s money in the debt market.  You can:

1. **Buy at issuance** – snag fresh bonds or commercial papers (CPs) straight from the issuer, just like getting a seat at the front of a concert line.  
2. **Buy on the secondary market** – pick up existing bonds on the exchange, akin to buying a ticket from someone who can’t make it to the show.  

When you buy on the secondary market, the price you pay can be *higher* or *lower* than the original face value, depending on **supply‑and‑demand**, interest‑rate moves, and the overall mood of the market.  

Every bond promises two things:

* **Periodic coupons** (interest payments) during its life.  
* **Principal repayment** at maturity.  

Let’s take a short detour to illustrate why **cash flows matter** for the “time to get your money back.”  

#### The “friend” analogy  

Your buddy asks for **₹10,000** and promises to return it *exactly* one year later—*interest‑free*.  Easy: the *payback period* is 1 year.  

Now, imagine the same friend agrees to pay you **₹2,500 every quarter** as a “thank‑you” (a coupon), plus the ₹10,000 at the end.  Even though the final cash‑in is still after a year, you’ve already received **₹7,500** in coupons before the principal is due.  So, **the effective time to recover your money is *shorter* than one year**.  

You could run the exact math (present‑value equations, etc.), but the intuition is enough: **more cash flow = quicker recovery**.  

### Back to the bond‑manager thought experiment  

| Fund manager | Action | Purchase price | Face value | Coupon | Frequency | Maturity |
|--------------|--------|----------------|------------|--------|-----------|----------|
| **A** | Subscribes at issue | **₹1,000** (par) | ₹1,000 | 8 % | Semi‑annual | 3 years |
| **B** | Buys on secondary market | **₹1,020** (premium) | ₹1,000 | 8 % | Semi‑annual | 3 years |
| **C** | Buys on secondary market | **₹980** (discount) | ₹1,000 | 8 % | Semi‑annual | 3 years |

*How long does each manager take to recover his/her cash?*  

* **A** – Roughly **< 3 years** because the semi‑annual coupons shave off some of the principal each period.  
* **B** – Pays a premium, so it will take **slightly longer** than A to get back the extra ₹20.  
* **C** – Gets a discount, so the recovery time is **a bit quicker** than A.  

The moral?  

* **Bond prices wiggle.**  
* **The price you pay changes the “time to recover” the investment.**  

That “time to recover” has a fancy name: **Macaulay Duration**.  It’s the weighted‑average time until you receive the bond’s cash flows, expressed in years (or months).  

### Why does Macaulay Duration matter for an ultra‑short‑duration fund?  

SEBI (the Indian regulator) defines an **ultra‑short‑duration fund** like this:

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/03/Image-3_USTF-300x130.png)

> The fund may invest in short‑maturity bills and CPs with *individual* maturities between **90 days and 180 days** (3–6 months).  

But there’s a catch: **the rule applies at the *portfolio* level, not to each individual security**.  In plain English, the *average* (Macaulay) duration of the entire basket must sit between 3 and 6 months.  That means the fund can hold a 30‑day CP, a 200‑day CP, a 1‑day TREP, etc., as long as the overall duration stays in the sweet‑spot.  

#### Real‑world example – DSP’s Ultra‑Short‑Duration Fund  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/03/Image-4_DSPmix-300x73.png)

The bulk of the portfolio sits in **money‑market instruments** with maturities ranging **from 1 day up to 365 days**.  

A snapshot of the **money‑market slice**:  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/03/Image-5_mmi-300x123.png)

You’ll also see **NCDs (non‑convertible debentures) and bonds**—essentially the same thing—*with maturities of at least a year*:  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/03/Image-6_ncds-300x135.png)

The fund manager’s juggling act is to **keep the portfolio’s return attractive while also keeping the Macaulay duration inside the 3‑to‑6‑month window**.  

### Credit‑rating reality check  

Money‑market CPs have a spread of credit ratings (AA, A‑, etc.), but the longer‑dated bonds and NCDs are typically **AAA**—the “golden ticket” rating implying *very* low default probability.  The longer the maturity, the more the manager worries about a potential default, so they gravitate toward AAA‑rated securities for the longer leg of the portfolio.  

Nevertheless, **ultra‑short‑duration funds are *not* risk‑free**.  They still carry **default risk** and the chance of a **rating downgrade**.  

### Who should consider an ultra‑short‑duration fund?  

* **Investment horizon:** 1 – 2 years.  
* **Risk tolerance:** Comfortable with a *tiny* chance of a few percent loss.  
* **Goal:** You want something that beats a regular savings account but won’t lock you away for a decade.  

If you’re only looking to park cash **for less than a year**, a **liquid fund** remains the better match.  

On the return side, you can *reasonably* expect yields **close to what a bank fixed deposit offers** (maybe a tad higher, maybe a tad lower, depending on market conditions).  

---

## 12.3 – Franklin and Vodafone saga  

Since we’re already in the “ultra‑short” realm, let’s take a quick detour into a real‑life drama that showed us that **debt funds can get messy too**.  

### The back‑story  

Franklin India had a decent chunk of its **Ultra‑Short‑Duration Bond Fund** invested in **Vodafone India Ltd. (VIL)** debt—**six separate debt schemes**, in fact.  

In **October 2019**, the **Supreme Court of India** delivered a verdict favoring the **Department of Telecommunications (DoT)** in a long‑running dispute over *Adjusted Gross Revenue (AGR)*.  The ruling forced telecom operators to pay massive licence and spectrum‑usage fees based on AGR, which, for VIL, translated into an **unpaid‑dues bill of roughly ₹27,000 crore**.  

In plain English: VIL suddenly needed a **cash infusion the size of a small country’s GDP** to stay afloat.  The cash crunch meant a **high probability of default on its debt obligations**.  

### Franklin’s quick‑thinking (or panic?)  

Franklin’s risk‑management team didn’t wait for the dust to settle.  They **downgraded VIL’s paper to junk internally and wrote it off**—a proactive move to protect the rest of the fund’s assets.  

But here’s the kicker: **4.2 %** of the **Ultra‑Short‑Duration Bond Fund’s** portfolio was tied up in VIL’s debt.  When that slice went *poof*, the fund’s **NAV** (Net Asset Value) took a hit.  

Check out the chart that shows the drop:  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/03/Image-7_franklin-300x249.png)

### What does this teach us?  

* Even “short‑term, low‑risk” debt funds can **suffer sizable losses** if a single issuer defaults.  
* The **recovery** of the NAV to pre‑hit levels could take **12 – 18 months** (or longer).  

The takeaway? **Debt funds aren’t a free‑ride**; you must understand the credit risk baked into each holding.  

---

## Where we’re headed  

We’ve just skimmed the surface of **equity mutual funds** and a few **debt fund categories**.  Next up, we’ll:

1. **Introduce more debt‑fund types** (think gilt‑funds, credit‑risk‑focused funds, etc.).  
2. **Wrap up the “intro” phase** of our debt‑fund tour.  
3. **Dive into fund analysis**—how to pick the right mutual fund (both equity **and** debt).  
4. **Build a goal‑based mutual‑fund portfolio** that aligns with your life plans (buying a house, early retirement, world‑touring, etc.).  

So, buckle up—there’s a *lot* more to learn, and we’ll keep it as entertaining as a trivia night at the local pub.  

Stay tuned, stay safe, and keep those “park‑my‑cash” instincts sharp!  

---

## Key takeaways from this chapter  

- **Overnight funds** lend money for a single day (24‑hour settlement).  
- **Almost every overnight fund** does this via **Tri‑Party Repo (TREP)** instruments.  
- Because the underlying instrument is the same, **performance across overnight funds is virtually identical**; only the expense ratio differentiates them.  
- **Macaulay Duration** tells you the weighted‑average time it takes for a fund to recover the money you put in.  
- An **Ultra‑Short‑Duration fund** must keep its portfolio’s Macaulay duration **between 3 and 6 months**.  
- **Ultra‑short funds** are *not* risk‑free; they carry credit‑default and rating‑downgrade risk, as the Franklin‑Vodafone episode illustrates.  