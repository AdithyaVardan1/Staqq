# 1. Background and Orientation  

**Source:** https://zerodha.com/varsity/chapter/background-and-orientation/  

---  

## 1.1 – What’s in the name?  

If you haven’t tuned into the **Joe Rogan‑Naval Ravikant** marathon, you’re missing out on a two‑hour brain‑stretch that feels like a mental yoga class mixed with a TED talk cocktail party. The conversation jumps from inner peace to why capitalism is basically the universe’s favorite sport, and it lands—right on cue—on the subject of *wealth creation*.  

Naval’s ability to slice complex ideas into bite‑size, crystal‑clear nuggets is the kind of super‑power we all wish we had at family dinner when Auntie asks, “So, when are you buying a house?” (Spoiler: the answer is “later,” but we’ll get there.)  

I hit the replay button a few times because his take on building wealth echoed everything I’d learned the hard way: **start early, stay consistent, and don’t wait for a “big” lump sum to appear**. I’m nowhere near the *financial‑freedom* nirvana he describes, but at least I’m not driving the train off the tracks.  

That’s why I’m pulling up a chair and sharing what I’ve scraped together on the dusty road to personal finance.  

### Why “Personal” Finance?  

Most people picture personal finance as a spreadsheet‑filled crystal ball that tells you how rich you’ll be “tomorrow.” Some brave souls try to DIY it, while others hire a “financial advisor” and hope the suit‑and‑tie wizard will conjure a plan that magically works for everyone—family, pets, houseplants, you name it.  

I’m not a fan of the “hand‑off” approach. Your family is a lot like your favorite pizza: you know exactly how much cheese, pepperoni, and chaos you need. A professional can’t taste that; they can only recommend a generic “extra cheese” option that probably nets them a commission.  

Bottom line: **the onus is on you**. Your “financial advisor” is more likely to push a product that fattens his pocket than yours. So roll up those sleeves, grab a calculator (or the phone’s built‑in one), and treat your money like a pet you actually want to keep alive.  

Good news: this isn’t rocket science. If you can add 2 + 2 without breaking a sweat, you’ve already cleared half the hurdle. The rest is just figuring out which numbers deserve a high‑five and which should be shown the door.  

That’s the mission of this module. By the time you finish, you should be able to:  

- **Decode financial products** – understand what’s under the hood without needing an MBA.  
- **Set a concrete financial goal** – pick a target, map a route, and actually start walking.  
- **Spot setbacks** – catch the financial leaks before they sink your ship.  

If you’re feeling a little jittery, that’s the excitement of a future‑rich you sending a postcard from the other side. Let’s get rolling!  

---

## 1.2 – I’m Not Ready Yet  

### The “First‑Job” Saga  

Picture this: fresh out of college, I was *the* job‑hunt zombie, wandering from one coffee‑shop interview to another for six‑plus months. Finally, after enough “please tell us about yourself” loops, I landed a gig. My first paycheck arrived like a golden ticket—except the chocolate was replaced by a stack of bills and a sudden wave of responsibility.  

I went full‑hero mode: bought my mom a saree (she now calls me “the son who knows fashion”), took my girlfriend (who later became my wife) out for a dinner that made the waiter’s eyebrows rise in awe. After the celebrations, I checked the bank balance: **a teeny‑tiny surplus**—just enough to buy a cup of instant noodles for the next week.  

A good friend, the “investment‑guru” type, nudged me: “Hey, put that spare cash somewhere.” I laughed it off, thinking my leftover rupees were like a single grain of rice—hardly worth the effort. “I’ll start saving next month,” I promised myself, with all the confidence of a cat pretending to be a dog.  

### The Déjà‑vu Loop  

Cue month 2: same paycheck, same spend‑till‑empty routine, **zero** left to save. This pattern repeated like a bad sitcom for years. The only thing that changed was my growing regret—my personal “top‑5 life regrets” list now had a fresh entry: **“I should’ve saved earlier.”**  

If you’ve ever told yourself, “I’ll start saving when I make a *big* chunk of cash,” you’re not alone. Most of us wait for a mythical windfall—like winning the lottery or discovering a hidden treasure in the backyard. Spoiler alert: that treasure rarely shows up.  

### The “Three Sisters” Parable  

To drive the point home, let me introduce you to **Triplet Sisters**—yes, the original “three‑peat” of finance.  

- **Dad’s Promise:** On each daughter’s 20th birthday, he hands over **₹50,000** (≈ $600) and repeats the gift every year until they turn 65. Think of it as a financial version of “you get a cookie, and you get a cookie, and you get a cookie…”  

- **Investment Option:** Dad also suggests parking the cash in a **12 % annual compounded promissory note**, with the catch that once it’s in, you can’t touch it until you’re 65. No withdrawals, no drama—just pure, boring growth.  

Now, each sister treats the cash differently:  

| Sister | Behaviour | Years of Saving | Total Cash Saved (₹) |
|--------|-----------|----------------|----------------------|
| **1️⃣ First** | Starts investing immediately, puts the first **9 × ₹50,000** into the note, then splurges on everything else. | 20 → 28 (9 years) | **₹450,000** |
| **2️⃣ Second** | Party animal until 28, then decides to be “responsible” and saves **₹50,000** each year from 28 → 36, then goes back to the fun life. | 28 → 36 (9 years) | **₹450,000** |
| **3️⃣ Third** | Live‑large until 28, then *goes all‑in* and saves **every** ₹50,000 from 28 → 65. | 28 → 65 (38 years) | **₹1,900,000** |

#### Quick math recap (you’ll see the same numbers later):  

- **First Sister:** 9 contributions, each left to grow **45‑48 years** (depending on exact birthday).  
- **Second Sister:** Same 9 contributions, but each only gets **38‑41 years** of growth.  
- **Third Sister:** 38 contributions, each enjoys **37‑0 years** of growth, with the earliest contributions compounding the longest.  

#### The “Which Sister Wins?” Brain‑Teaser  

At 65, who ends up with the fattest nest‑egg? Most people guess:

1. **First Sister** – saved early, but not much, so “meh.”  
2. **Second Sister** – saved a little, later, so “also meh.”  
3. **Third Sister** – saved a lot *and* for the longest, so “obviously the champ.”  

That’s the **linear** way of thinking: we equate the final amount with the raw cash saved. But we forgot two mischievous variables—**time** and **compound return**—that turn the whole thing into a non‑linear fireworks show.  

### The Numbers (Hold Your Breath)  

Using the 12 % compounded formula **A = P(1 + r)ⁿ**, we get:

| Sister | Final Corpus (₹) | Approx. in Crores |
|--------|-----------------|-------------------|
| **First** | ₹4,89,00,000 | **4.89 Cr** |
| **Second** | ₹1,98,00,000 | **1.98 Cr** |
| **Third** | ₹3,05,00,000 | **3.05 Cr** |

**Shock factor:** The *first* sister, despite investing the *least total cash*, ends up with the **largest** corpus because her money enjoyed **45 years** of exponential growth. The third sister, though she saved the most cash, sits in second place because she started later.  

**Takeaway:**  

- **Time beats amount** (when the interest rate is decent).  
- Starting early gives your money more “time to work out,” and compound interest is the financial equivalent of a marathon, not a sprint.  

If you’re reading this and thinking, “Well, I’m like the second sister—late‑bloomer,” the good news is you can still *play the long game*. The longer you leave money in a decent‑interest vehicle, the more the math does the heavy lifting for you.  

---

## 1.3 – How Did I Crunch Those Numbers?  

The wizard behind the curtain is the **Time Value of Money (TVM)** concept—a cornerstone of personal finance that says a rupee today is worth more than a rupee tomorrow *unless* you let it earn interest. In other words, **money loves to grow, and the longer you give it a chance, the bigger it gets**.  

In the next chapter we’ll unpack TVM, walk through the formulas, and give you a spreadsheet you can actually use (no PhD required).  

**Download the Excel sheet** that powered the sister‑scenario calculations:  

[Download]  

---

### Key takeaways from this chapter  

- **Keep it personal:** Your financial plan belongs to you and your family—no one else’s agenda.  
- **DIY is doable:** With a bit of arithmetic and curiosity, you can chart a solid roadmap without a suit‑and‑tie middleman.  
- **Start early:** Even tiny, consistent savings snowball into massive corpora thanks to compounding.  
- **Time Value of Money:** The secret sauce that turns “a little bit now” into “a lot later.”  

Now go forth, open that Excel file, and start treating your cash like a plant—water it early, and watch it grow into a money‑tree that even your future self will thank you for. 🌳💰  