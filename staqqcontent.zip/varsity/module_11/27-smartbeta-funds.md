# 27. Smart‑beta funds  

**Source:** https://zerodha.com/varsity/chapter/smart-beta-funds/  

---  

## 27.1 – Overview  

Before we dive into the nitty‑gritty, a quick backstage confession: this chapter (and the one on Index funds) wasn’t penned by yours truly, Karthik. It was written by Bhuvan, a colleague who can quote the Fama‑French paper faster than you can say “beta”.  

The next stop on our learning tour – Asset Allocation – will be authored by another industry‑seasoned buddy of mine who knows market finance like a bartender knows cocktail recipes. Big thanks to these two for sharing their brain‑juice and sparing us the endless Googling.  

Read on, and feel free to pretend you’re sipping a cold one while you do.

---  

In Chapters 6 & 7 we covered the basics of mutual funds – what they are, how they work, why they charge you a fee for the privilege of “professional” management. Chapter 16 took a deep‑dive into **index funds**, the lazy‑boy’s dream of tracking a market‑cap‑weighted benchmark (think Nifty 50, Nifty 500, etc.).  

I promised to talk about a newer breed of funds that’s been making the Indian market buzz: **smart‑beta funds** and their ETF cousins. The promise got delayed because life is messy, but here we are.  

> **Smart‑beta = “smart” + “beta”** – a phrase that sounds like a futuristic superhero, but is mostly a marketing buzz‑word. In plain English, it’s any weighting scheme that *doesn’t* follow straight market‑cap weighting. In other words, it’s **factor investing** in a fancy suit.  

If you recall from the index‑fund chapter, a market‑cap index assigns each stock a weight equal to  

\[
\text{Weight}_i = \frac{\text{Market‑cap}_i}{\sum_j \text{Market‑cap}_j}
\]

So the bigger the company, the louder its voice in the index – Nifty 50 is the classic example.  

Smart‑beta, by contrast, may weight stocks on fundamentals (earnings, dividends, profitability) or on *factors* like value, momentum, low volatility, etc. Think of it as a diet plan that says “you’re not getting enough protein, so we’ll give you more chicken and less cake”.  

---

## 27.2 – What is a factor? (You might be wondering…)  

A **factor** is a persistent, broad‑based driver of a stock’s returns. Put another way, factor investing is the art of hunting down securities that share a particular characteristic that historically nudges their performance up (or down). Remember that definition – we’ll circle back to it later.  

### A quick history lesson (because finance loves its origin stories)

Factor investing sprouted from a long line of academic experiments:  

* **CAPM (Capital Asset Pricing Model)** – claimed that a single factor, the market beta, explains all expected returns. Spoiler: markets didn’t like being monogamous.  
* **EMH (Efficient Market Hypothesis)** – said you can’t beat the market because prices already reflect everything. Yet here we are, still trying.  

The real breakthrough came in 1992 when **Eugene Fama** and **Kenneth French** dropped their seminal paper *The Cross‑Section of Expected Stock Returns*. They added two new companions to the market factor:  

1. **Size** (small‑cap vs. large‑cap)  
2. **Value** (cheap‑ish stocks vs. expensive‑ish stocks)  

Thus was born the **Fama‑French 3‑factor model**.  

Fast‑forward to 2014, two more friends joined the party: **Profitability** and **Investment**. The model bloomed into a **5‑factor framework**.  

Beyond the Fama‑French clan, other factors have been identified, notably **Momentum** (the “winner keeps winning” effect) and **Low Volatility** (the “slow and steady” approach). Robeco, a global asset manager, summed up the most commonly used factors in a handy chart – think of it as the “periodic table of smart‑beta”.  

Investors then build **factor portfolios** by loading up on stocks that exhibit the desired trait, just as a chef might stock a pantry with ingredients that fit a cuisine theme.  

### How have these factors behaved in India?  

Data is still a toddler in the Indian market, but the early results are eye‑catching. Below are cumulative returns (courtesy of Shyam from StockViz) for **Momentum**, **Quality**, and **Low‑Volatility** versus the Nifty 50 and Nifty 500.

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/09/Cumulative-factors-1024x585.png)

*Low‑Volatility* looks especially disciplined – modest bumps, shallow drawdowns. *Momentum* (the “Nifty Alpha” proxy) has delivered fireworks, but with some nasty crash‑downs.  

For the granular, year‑by‑year view, see the chart below.

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/09/Annual-returns-factors-1024x439.png)

*All charts courtesy Shyam (StockViz).*

### Why do these factor premiums exist?  

Scholars and market‑practitioners toss around three main explanations:

| School of thought | Core idea |
|-------------------|-----------|
| **Risk‑based** | Investors demand extra compensation for taking on *extra* risk. Cheap (value) stocks may be cheap because they have a higher chance of bankruptcy, especially in recessions. |
| **Behavioural** | Human quirks create mispricings. Investors chase shiny growth stories, ignoring the “ugly duckling” value stocks. Momentum may arise from under‑reaction to good news followed by over‑reaction. |
| **Structural** | Market frictions – illiquidity, high transaction costs, difficulty leveraging – create pockets of return that savvy strategies can harvest. |

In reality, it’s usually a cocktail of all three. Markets are complex adaptive systems, and humans are… well, humans.  

But hold your applause – the charts are tempting, yet **there is no free lunch** (except perhaps the occasional free buffet at a conference).  

---  

## 27.3 – Smart‑beta funds in India  

Smart‑beta (or factor) funds are still toddlers in India. The first smart‑beta ETFs popped up only **4‑5 years ago**. A handful of quant funds from Reliance, Tata, and DSP also claim factor exposure, but unlike transparent ETFs, their exact methodologies are tucked behind corporate curtains.  

Remember: **Indices are just theoretical returns**. Real‑world trading adds slippage, brokerage costs, and market‑microstructure quirks. Since 2005, Indian markets have become far more efficient, so the “paper” returns and the “pocket” returns can diverge.  

Because the rollout is recent, we lack a long‑term performance record. Still, here’s a snapshot of how **Quality**, **Value**, and **Low‑Volatility** ETFs have fared against the popular **NiftyBee** (the ETF that tracks Nifty 50).

![Image](https://www.tradingview.com/x/AGWHyaLA/)

*Data starts 2019 – not a lot, but enough to see that factors have personality swings.*  

### The US perspective – a longer runway  

Across the Pacific, factor ETFs have decades of history. Below is a performance chart comparing several US smart‑beta ETFs to the **S&P 500**. (Beware of **starting‑point bias** – we line them up where data is available for all, which can make the story look smoother than reality.)

![Image](https://zerodha.com/varsity/wp-content/uploads/2021/01/image-1-1024x529.png)

You’ll notice that **factors are cyclical** – they can lag the broad market for years, then surge ahead.  

Here’s an Indian‑centric illustration showing how the “top” factor changes over time.

![Image](https://zerodha.com/varsity/wp-content/uploads/2021/01/image-3.png)  
*ICICI Quant Fund presentation*

Take the **Value** factor (ticker IWD) in the US: it has underperformed the growth‑heavy S&P 500 for over a decade. (We use US data because the Indian dataset is still a baby, and the US market is the granddaddy of factor research.)  

![Image](https://zerodha.com/varsity/wp-content/uploads/2021/01/image-2-1024x529.png)

If you had put **100 %** of your nest egg into a single factor, you’d either be a hero or a tragic hero depending on the timing. Also note: **no two factor ETFs are identical**. The original Fama‑French definition of “value” uses the **price‑to‑book** ratio, but today’s value ETFs might use price‑to‑sales, EBIT/TEV, forward earnings, or a blend of several metrics. This methodological diversity creates a wide spread of returns even among “the same” factor.  

---  

## 27.4 – Do smart‑beta funds work?  

Two camps usually emerge at the bar when you ask this question:

| The Skeptics | The Believers |
|--------------|---------------|
| “Factors are just back‑tests that looked pretty on paper. They’re data‑mined, over‑fitted, and will crumble in real life.” | “Hundreds of billions flow into factor strategies worldwide. Look at **Dimensional Fund Advisors (DFA)** – founded by David Booth (a Fama student) – managing > $500 bn across factor products. Fama himself sits on DFA’s board.” |

My own take? **Factors do work over the long haul**, but the premiums are *not static*. They ebb, flow, and occasionally go on a long vacation. You need to be comfortable with **pain** (drawdowns) and have a **long‑term horizon** to reap the reward.  

### Have the markets “arbitraged” them away?  

Probably not completely, but the landscape has shifted dramatically:

* **1990s** – markets were less efficient, retail investors dominated, and factor inefficiencies were easier to exploit.  
* **Today** – anyone with a smartphone can download price data, run a regression, and publish a factor story. CFAs, hedge funds, HFT desks, and Indian AMCs are all hunting the same alpha.  

The sheer **data explosion** and **computational firepower** have spawned a **“factor zoo”** – hundreds of new, sometimes spurious, factors that look great in back‑tests but often vanish in live trading.  

So, while the zoo is fascinating, don’t assume every exotic animal will win a prize at the stock market circus.  

---  

## 27.5 – Should you invest in smart‑beta funds?  

My advice is **not to put 100 % of your equity bucket into smart‑beta** – that would be like ordering only the “spicy” dish for every meal. Smart‑beta should complement, not replace, a solid core.  

Recall from the index‑fund chapter: most active managers *don’t* beat their benchmarks. Smart‑beta can be a **better alternative to poorly run discretionary active funds**, but the backbone of your equity exposure should still be:

* **Broad, diversified index funds** (e.g., Nifty ETF) **or**  
* **Consistently good active funds** with a track record of out‑performance.  

Then you can sprinkle in a few smart‑beta funds for that extra “kick”.  

A few cautions:

* **Factors can underperform for long stretches** – sometimes decades.  
* **Premia shrink** as more money chases the same factor (supply‑demand dynamics).  
* **Diversify among factors** – multi‑factor funds exist (e.g., ICICI’s low‑volatility ETF blends momentum + low‑volatility; DSP Quant, Tata Quant). Their methodologies are often less transparent than pure ETFs, but they aim to smooth out the roller‑coaster ride.  

The ecosystem is evolving. More AMCs are launching factor products, so the menu will get richer in the next couple of years.  

---  

### Key Takeaways from this Chapter  

1. **Goal:** Give you a working grasp of smart‑beta and factor investing. If you want to actually allocate money, dive deeper – the internet is full of PDFs, research papers, and webinars.  
2. **Marketing hype:** “Smart‑beta” is just a buzz‑word. There’s no such thing as “smart” vs. “dumb” beta – only different weighting schemes.  
3. **Definition:** Smart‑beta funds = factor funds = funds that use *alternative* weighting (not pure market‑cap) – e.g., value‑weighted, earnings‑weighted, etc.  
4. **Real‑world performance ≠ index performance** – transaction costs, slippage, and changing market microstructure can erode the theoretical edge.  
5. **Cyclicity:** Factor premiums are highly cyclical; a factor can lag a diversified broad‑market fund for years.  
6. **Diversify across factors** if you decide to go the factor route – a single‑factor bet is a gamble.  
7. **Past performance ≠ future results** – chasing yesterday’s winners is a recipe for disappointment.  

Happy (and humor‑filled) investing! 🎉  