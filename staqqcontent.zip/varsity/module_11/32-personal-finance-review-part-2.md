# 32. Personal finance review (Part 2)

**Source:** https://zerodha.com/varsity/chapter/personal-finance-review-part-2/

---  

## 32.1 – Investments  

Alright, folks, this is the “sexy” part of the money‑making saga – the part that gets everyone’s eyes all glossy. You’ll see people spend more time agonising over whether to buy XYZ stock or that shiny new mutual fund than they do over deciding what to have for dinner. Spoiler alert: as long as you nail a handful of fundamentals, you’ll be fine.  

**Before you start poking around your portfolio, keep these nuggets in mind:**  

- **Your portfolio exists to serve your goals, not to win a brag‑ging‑contest against the Nifty.** Think of it as a butler – it does what you ask, not what it *wants* to do.  
- **Your benchmark isn’t “beat the market”; it’s “hit the numbers that matter to you.”** If you’re aiming for a beach house in 10 years, that’s your yardstick, not the daily Nifty dance.  
- **Savings rate > investment return.** You can’t control market returns, but you can decide how much of your paycheck you actually stash away.  
- **Asset allocation, risk‑management, and behaviour = the real drivers of returns.** Picking the “best” fund is like hunting for a unicorn in a haystack.  
- **A mediocre, *sticking‑to‑it* portfolio beats a flawless one you’ll never actually use.** Consistency > perfection.  
- **You need a portfolio that *fits* you, not the one you *wish* you had.**  
- **Risk management is the gatekeeper.** As you get older, you want your portfolio to behave like a calm‑old‑man, not a jittery teenager.  
- **Retirement planning isn’t about average life expectancy; it’s about being *over‑prepared*.** A little extra cushion never hurts. (Karthik dives deeper in the video below.)  

[Watch the deep‑dive video →](https://youtu.be/-BU8hyY-ZXk)  

---

## 32.2 – Diversification and asset allocation  

### Diversification  

You’ve heard the old market proverb: “Diversification is the only free lunch.” It’s a cliché, sure, but it’s also the closest thing we have to a cheat‑code. Diversification = spreading your money across *different* asset classes, so you’re not putting all your eggs in a single, possibly cracked, basket.  

**Why bother?** Because humanity still can’t read the crystal ball that tells us which asset class will sprint ahead tomorrow. Until we invent that, the safest way to grow wealth is to *mix* things up.  

![Diversification illustration](https://zerodha.com/varsity/wp-content/uploads/2023/01/Personal-finance-review-4-1024x580.png)  

### Action items  

Make sure your money is spread across these buckets:  

| Asset class | What to include | Quick tips |
|-------------|----------------|------------|
| **Equity** | Domestic & International stocks | Keep a blend of large‑caps, mid‑caps, and maybe a dash of emerging‑market exposure. |
| **Debt** | Short‑ to intermediate‑duration bonds, AAA‑rated govt. securities | Avoid high‑risk credit funds unless you’re a bond‑geek. Stick to funds with lots of government or top‑rated corporate bonds. |
| **Precious metals** | Gold (maybe a sprinkle of silver) | Gold can be a hedge, but remember it can sit still for ages and can drop like any equity. Silver ETFs? Mostly “all risk, no‑return” in my book. |

#### “Diworsification” – the anti‑diversification  

A quick sanity‑check: the average retail investor holds **20‑30 mutual funds**. That’s not diversification; that’s *diworsification* – a fancy way of saying “too many cooks spoil the broth.”  

Why? SEBI says a large‑cap fund can own the 100 biggest companies. If you own three different large‑cap funds, you’re basically paying extra for the *same* basket of stocks.  

- **Direct index fund expense ratio:** ~0.25 %  
- **Direct large‑cap fund expense ratio:** ~1.3 %  

That extra 1 % a year *adds up* like a leaky faucet. If you see multiple funds in the same category, it’s a red flag – time to trim.  

### Review your portfolio  

- **Are you truly diversified?** Check that you have exposure across asset classes *and* sub‑classes (e.g., large‑cap, mid‑cap, short‑term debt).  
- **Is your asset allocation aligned with your goals and risk tolerance?** Young? More equity. Near retirement? Shift toward debt.  

![Asset allocation drawdown chart](https://zerodha.com/varsity/wp-content/uploads/2023/01/p3kmc-asset-drawdowns-3-1024x663.png)  

### Fund performance check  

Don’t judge a fund by its 12‑month Instagram story. Compare each active fund to **its own benchmark**, not the average of its peer group.  

**How to assess?**  

1. **Quantitative yardsticks:**  
   - Rolling returns (consistency across cycles)  
   - Sharpe, Sortino, Information, Capture ratios  
   - Factor‑model decomposition (value, quality, momentum, volatility)  
   - Fees vs. alpha (risk‑adjusted outperformance)  
2. **Qualitative vibes:**  
   - Manager’s temperament & process  
   - Risk‑management framework  
   - Alignment of interests & AMC reputation  

Even with AI, most active managers *still* underperform. In large‑caps, **70‑80 %** of funds lag the S&P BSE 100. Mid‑caps and small‑caps aren’t any better; under‑performance is rising. Picking a winning active fund is basically a coin toss.  

![Active fund underperformance chart](https://zerodha.com/varsity/wp-content/uploads/2023/01/Personal-finance-review-5-1024x475.png)  

#### Core portfolio building blocks  

| Segment | Index | Why it matters |
|---------|-------|----------------|
| **Large‑cap** | Nifty 50 | Captures ~62 % of free‑float market cap – owning this is like owning 62 % of all listed Indian companies. |
| **Large‑cap (next tier)** | Nifty Next 50 | Technically large‑cap, behaves more like mid‑cap; about 10 % of free‑float cap. |
| **Mid‑cap** | Nifty Midcap 150 | Covers the next 150 biggest firms, ~12.9 % of free‑float cap. |
| **Debt** | Various (target‑maturity, G‑Sec ETFs) | Passive debt options are scarce; if target‑maturity funds suit your horizon, give them a look. |

**Note:** Nifty Next 50 often tracks Nifty Midcap 150, so the extra diversification benefit may be limited.  

If you still want an active mid‑cap fund:  

- Give it **≥ 5 years** before judging.  
- A short‑term under‑performance of **> 5‑10 %** vs. benchmark is a red flag.  
- Watch for governance issues, manager changes, or AMC acquisitions – those may force a decision.  

### Reviewing individual stocks  

If you hold **direct equities**, run a quick health check:  

- Does the original investment thesis still hold?  
- Any red flags on financials or governance?  
- Is your stock list overly bloated? 50 + stocks become a monitoring nightmare and add little diversification beyond a point.  

[Deep dive video on stock due‑diligence →](https://youtu.be/C1j3asSi2tA)  

**Further reading:**  
- *The Investment Due Diligence*  
- *Portfolio Optimization*  

---

## 32.3 – Rebalancing  

Asset allocation is the **plan** (e.g., 60 % equity, 30 % debt, 10 % gold). Markets love to mess with your plan. Suppose equities rally and swell to 70 % of your portfolio; debt falls to 25 % and gold to 5 %. If you leave it alone, your risk profile **inflates** – you’re now more exposed to equity swings than you intended.  

Higher volatility = a shakier path to your goals, especially as you near them. Rebalancing is the *reset button* that brings your mix back in line.  

![Rebalancing illustration](https://zerodha.com/varsity/wp-content/uploads/2023/01/p3kmc-asset-drawdowns-5.png)  

### How to rebalance (without losing your mind)  

1. **Sell the “over‑weight” assets** (the ones that grew beyond target).  
2. **Buy the “under‑weight” assets** (the ones that shrank).  

In our example, you’d sell enough equity to drop it back to 60 % and use part of that cash to boost debt and gold back to 30 % and 10 % respectively.  

> **Tax talk:** Yes, rebalancing may trigger capital gains, but the goal is *risk reduction*, not tax avoidance.  

**Quick reminders:**  

- **Tax bite is usually modest.** LTCG on equities only after ₹1  lakh of gains; debt funds enjoy indexation.  
- **Rebalancing = risk control, not return hunting.** The chart above shows how portfolios that stayed true to their allocation fared better during the 2020 crash.  
- **Don’t rebalance on every tiny drift.** Adopt a tolerance band (e.g., ± 5 %). If equity drifts from 60 % to 63 %, ignore it. At 66 %, rebalance.  
- **Use fresh money** if you have any – you don’t always need to sell existing holdings.  
- **Returns can go up or down** depending on timing and luck. It’s not a guaranteed performance boost.  
- **Tweak sub‑asset classes** when you have a window. If mid‑caps are cheap during a rebalance, overweight them for extra upside.  

**Taxation guide:** [Equity & Debt Fund Tax FAQ]  

---

## 32.4 – Savings rate matters more than the return on investments  

Remember that classic Maruti Suzuki ad, “Kitna Deti Hai?” – most investors are stuck on that question, obsessing over “how much return will my portfolio give?” The truth bomb: **your savings rate is the real game‑changer.** You can’t control market returns, but you *can* decide how much of your paycheck you stash away.  

### What’s a “good” savings rate?  

- **Rule of thumb:** Save **15‑20 %** of your after‑tax income *without* sacrificing sleep, coffee, or toothpaste.  
- **Make it a habit to increase the rate each year** (even a 1 % bump adds up).  

### Can’t save much now?  

That’s okay – we’ll talk about a secret weapon next.  

### Your biggest asset (spoiler: it’s *not* your 401(k)…)  

If you draw up a personal balance sheet, the top line isn’t your house or your brokerage account; it’s **human capital** – the present value of your future earnings potential.  

- Think of it as a *salary‑producing machine* you’re constantly upgrading.  
- Most financial planners skip this, focusing only on stocks and bonds.  

**Bottom line:** Your most valuable asset is **you**.  

![Human capital illustration](https://zerodha.com/varsity/wp-content/uploads/2023/01/Personal-finance-review-6-1024x638.png)  

**Why does this matter?**  

- **Youth = high human capital.** The younger you are, the more “earning power” you have left to compound.  
- **Invest in yourself** (education, upskilling) → higher future earnings → higher possible savings rate.  
- **Treat human capital like a financial asset:**  
  - Stable job → bond‑like (steady, low risk).  
  - Gig or startup → equity‑like (high upside, high volatility).  

Your job’s nature should influence how aggressive (or conservative) your overall portfolio feels.  

---

## 32.5 – Behave!  

Behavioral finance has turned into a buzzword buffet over the past 40 years. The original idea? Humans *aren’t* perfectly rational calculators – we’re more like squirrels hoarding nuts when they sense a storm.  

But somewhere along the way, the field got hijacked: we now have endless lists of biases, and “bias” is sometimes used as an insult. **Biases aren’t bugs; they’re evolutionary features** that helped our ancestors survive. Unfortunately, they’re lousy at picking winning stocks.  

**Common behavioural slip‑ups:**  

- Not saving enough despite having the cash.  
- Over‑indulging today and under‑saving for tomorrow.  
- Parking money in low‑yield bank accounts or pricey funds.  
- Sticking with terrible default options because “it’s the default.”  
- Chasing hype, fads, or “quick‑rich” schemes.  

Once the basics are solid, *behaviour* becomes the single biggest determinant of success. You can craft the perfect portfolio, but if you panic‑sell during a dip, you’ve thrown the cake away.  

### How to get your behaviour in shape  

**Automation = the ultimate self‑control hack.**  

| What to automate | Why it helps |
|------------------|--------------|
| SIPs (systematic investment plans) | Forces regular saving, no excuses. |
| Emergency‑fund SIP | Builds a safety net without you thinking about it. |
| Health & life‑insurance premiums | Guarantees coverage, avoids missed payments. |
| Credit‑card & loan repayments | Prevents costly interest and penalties. |
| Rent & utility bills | Stops late fees and the “I‑forgot‑to‑pay‑my‑rent” panic. |

**Other tricks to dodge the “stupidity trap”:**  

- **Learn the basics.** A solid foundation shows you that wealth is built slowly, not via overnight miracles.  
- **Limit portfolio checks.** The more you stare, the more you’ll be tempted to tweak. Some people even uninstall finance apps until year‑end – try it!  
- **Accept you’ll never beat the market 100 % of the time.** Evidence says the odds of picking the *best* stock or fund are essentially zero. Low‑cost index funds are your friend.  
- **Guard against external noise.** Don’t compare your net worth to the guy on Instagram who shows off yachts you can’t afford. Be comfortable with a slower, steadier climb.  

---

## 32.6 – Money and mental health  

This is the part that’s close to my heart (and probably to yours too). Money isn’t just numbers on a screen; it’s a huge source of stress for most of us.  

The American Psychological Association consistently ranks **money** as a top stressor. In India we lack a massive survey, but it’s safe to assume the picture looks similar.  

**Why does money stress us?**  

1. **External shocks:** pandemics, wars, economic turbulence – all beyond our control.  
2. **Internal relationship with money:** early experiences, parental attitudes, and cultural narratives shape how we think about cash. Someone raised during a recession may be overly cautious, while another from a boom period may overspend.  

Financial anxiety can seep into mental health, which then affects physical health. Understanding this link is the first step to **taming the money‑monster**.  

![Money stress illustration](https://zerodha.com/varsity/wp-content/uploads/2023/01/Personal-finance-review-7-1024x599.png)  

**Things you can actually control (the “do‑ables”):**  

- **Stop splurging on non‑essentials.**  
- **Boost your savings** even if it’s a small amount.  
- **Build an emergency fund** and get adequate insurance.  
- **Upskill continuously** – the job market loves adaptable people.  
- **Be transparent about money** with partners and family.  
- **Avoid the “compare‑and‑despair” trap** (no need to measure yourself against a stranger’s net worth).  
- **Define success on your terms**, not society’s.  

Remember the Serenity Prayer:  

> “God, grant me the serenity to accept the things I cannot change, the courage to change the things I can, and the wisdom to know the difference.”  

---

## 32.7 – Create a “what‑if?” folder  

Did you know the Economic Times estimates **₹80,000 crore** of Indian assets sit idle because of missing nominations or unknown beneficiaries? That’s a *lot* of unclaimed wealth.  

Two common culprits:  

1. **No nomination was filled out.**  
2. **Nomination exists, but the nominee never got told.**  

A friend of mine lost a cousin to COVID‑19; the poor guy had a crore of investments his parents never knew about. The friend stepped in, helped the family claim it, and saved them from a financial nightmare.  

### Your checklist  

- **Nominate** every investment, insurance, and pension plan. Most providers let you fill a form online – a few clicks, and you’re done.  
- **Tell your nominee** that they’ve been nominated. No point keeping it a secret!  

### Build the ultimate “what‑if” folder  

| Folder contents | Why it matters |
|----------------|----------------|
| All investment statements (what, where, how much) | Quick reference for heirs. |
| Bank account details | Easy access for settlement. |
| Insurance policies | Guarantees payout without hassle. |
| Liabilities (home loan, loan against securities) | Shows the full picture. |
| Property documents | Proof of ownership. |
| Identity proofs, education certificates | Needed for KYC during claim. |
| Step‑by‑step claim process notes | Saves time and headaches. |

Create a Google Drive (or any secure cloud) folder, share it with your nominees, and **ensure they use strong passwords + 2FA**.  

---

## 32.8 – Beware of financial fraud  

Scams are everywhere: phishing, identity theft, fake investment platforms. Here’s a quick cheat‑sheet:  

- **Strong, unique passwords** for every financial account.  
- **Enable two‑factor authentication (2FA)** on banks, brokers, and email.  
- **Biometric + 2FA** on your phone – lose it? Hackers can’t get in.  
- **Never share** account numbers, OTPs, or personal documents over a call or WhatsApp.  
- **Double‑check URLs** before you type in credentials – look for the padlock and correct domain.  
- **Stay away from shady platforms**; if it looks too good to be true, it probably is.  

---

## 32.9 – Your information diet  

We live in a *noise* era. Financial news, meme‑stock hype, influencer “get‑rich‑quick” reels – most of it is garbage.  

- **~99 % of daily financial chatter is fluff.**  
- Making decisions based on a headline or your driver’s opinion = guaranteed loss.  
- Core principles are timeless. For example, the Talmud advised: “Divide wealth into three parts – land, commerce, and cash.” That’s diversification 2,000 years old.  

**What to do instead?**  

- **Read good books.** Start with:  
  - *The Behavioral Investor* – Daniel Crosby  
  - *The Psychology of Money* – Morgan Housel  
  - *Common Sense on Mutual Funds* – Jack Bogle  
  - *Triumph of the Optimists* – Dimson, Marsh & Staunton  
  - *The Delusions of Crowds* – William Bernstein  

These will give you a solid, bias‑free foundation, far beyond any 60‑second Instagram tutorial.  

---  

*And there you have it – the full, witty, and (still fact‑checked) rundown of Part 2 of the personal‑finance review. Go forth, diversify, rebalance, and keep your human capital shiny!*