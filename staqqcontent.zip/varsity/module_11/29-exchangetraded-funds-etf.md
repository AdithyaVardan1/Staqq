# 29. Exchange‑traded funds (ETF)

**Source:** <https://zerodha.com/varsity/chapter/exchange-traded-funds-etf/>

---

> **Heads‑up:** This isn’t my brainchild. The original wizardry comes from my colleague Bhuvan. I’ll be hanging around to answer whatever spicy questions you toss my way.  
> Happy learning,  
> — Karthik Rangappa  

---

## 29.1 – Overview  

Remember Chapter 7 when we dissected mutual funds? Quick refresher: a mutual fund is a big pot where many investors dump cash, the fund manager whips up a basket of assets, and you own a slice of that pot. When you place an order **before** the cut‑off, you get units at that day’s NAV (Net Asset Value) which is published at midnight. Miss the cut‑off and you’re stuck with tomorrow’s NAV. In short, everything in a mutual fund happens **after‑hours**.  

Now picture this: what if you could buy those mutual‑fund slices on an exchange **anytime**, just like you do with Reliance or Infosys? Enter the **exchange‑traded fund (ETF)** – a mutual‑fund‑style basket (stocks, bonds, commodities, you name it) that lives on the stock‑exchange playground. You can click “Buy” or “Sell” whenever the market’s open, and you’ll see your order executed in real time.  

There are a few extra quirks that set ETFs apart from plain‑vanilla mutual funds, but before we go full‑on, make sure you’ve got a decent mental picture of what an ETF actually is.  

---

## 29.2 – History of ETFs  

Mutual funds are the grandpas of the investment world. The first open‑ended mutual fund in the U.S. rolled out in **1924** and is still chugging along. India’s debut mutual fund surfaced in **1964**. Over the last century, mutual funds have democratized access to everything from equities to real‑estate, letting the “average Joe” own a slice of the financial pie.  

ETFs, by contrast, are the cool younger cousins. The **SPDR S&P 500 Trust**—often hailed as the world’s first ETF—was launched in **1993** in the U.S. Fast forward to today, and it’s the most‑traded security on the planet (yeah, that’s a lot of trading).  

India caught the ETF bug a few years later. **NiftyBeES**, the first Indian ETF that tracks the Nifty 50, launched in **2002** via Benchmark AMC. Since then the ETF has changed hands more times than a hot potato: Benchmark → Goldman Sachs → Reliance → Nippon India Mutual Fund. 😄  

---

## 29.3 – ETFs in India  

Even though ETFs have been around for a while here, they’re still more of a “HNIs‑and‑institution‑thing” than a retail‑investor staple. Take the **SBI Nifty 50 ETF** – with an AUM (Assets Under Management) of **₹ 89,441.55 cr**, it’s the biggest mutual‑fund‑style vehicle in India. The bulk of that money comes from the **Employees’ Provident Fund Organisation (EPFO)**, which loves to park cash in Nifty‑ and Sensex‑linked ETFs.  

The biggest drivers of ETF AUM growth are:

| Driver | Why it matters |
|--------|----------------|
| **EPFO** investing in Nifty & Sensex ETFs | A massive institutional investor pours in steady cash |
| **Government divestments** (CPSE ETF, Bharat 22 ETF) | The state sells its stakes via ETFs, feeding the pool |
| **Bharat Bond Debt ETFs** (government‑push) | Debt‑focused ETFs with mostly non‑retail money |  

![Growth of ETF AUM in India](https://zerodha.com/varsity/wp-content/uploads/2021/01/ETF-AUM.png)  

Even though ETFs are still a modest slice of the Indian investment pie, retail participation is creeping up, and so is the daily turnover on the exchanges.  

A quick reality check: **NiftyBeES**, now 20‑years‑old, sits at roughly **₹ 2,800 cr** AUM. Why isn’t it bigger?  

| Reason | Explanation (with a dash of sarcasm) |
|--------|----------------------------------------|
| **Tiny market** – only ~**1.7 cr** active demat accounts | You need a demat account to buy an ETF – no “walk‑in” purchase like a candy bar. |
| **Distribution incentives** – mutual funds pay distributors, ETFs don’t | AMCs love to reward salespeople for pushing MF products, but ETFs are commission‑free, so they get less love. |
| **Complexity** – ETFs seem “harder” than MF at first glance | We’ll demystify this later, promise! |
| **Low margins for AMCs** – small AUM → low profit | Most AMCs don’t shout about ETFs because they’re not money‑making machines. |  

![ETF vs MF graphic](https://zerodha.com/varsity/wp-content/uploads/2021/02/M11-C29-MF-ETF-WEB.jpg)  

---

## 29.4 – What is an ETF?  

An **exchange‑traded fund** is, at its core, a basket of securities—just like a mutual fund. The **only** place the similarity stops is the trading mechanic. While a mutual fund’s NAV is calculated once a day, an ETF **trades all day** on the exchange. Think of it as a mutual fund that got a caffeine shot and decided to join the stock market party.  

If you type “Nifty ETF” into Kite, you’ll be greeted with a buffet of ETFs that each try to mimic the Nifty 50 in their own way.  

![Searching ETFs on Kite](https://zerodha.com/varsity/wp-content/uploads/2021/02/ETF-search-Kite-300x262.png)  

---

## 29.5 – How does an ETF work?  

When you buy a mutual fund, the AMC (Asset Management Company) takes your cash, goes shopping for the underlying securities, and publishes a once‑daily NAV. Redeeming is the reverse: AMC sells the securities, hands you cash. Simple, right?  

With an ETF, **you usually don’t even talk to the AMC**. Most buying and selling happen on the exchange, as a pure buyer‑seller swap. It’s like buying a used car from a dealer vs. buying it from a private party—except the “private party” is the entire market.  

---

## 29.6 – Creation and redemption mechanism  

Remember that I said “mostly you don’t talk to the AMC”? Let’s unpack why.  

In Chapter 6 we met the usual suspects in an MF transaction: the **AMC**, the **custodian**, and the **RTA**. ETFs have a secret weapon: the **creation‑and‑redemption mechanism**. Before we dive, we need a quick crash‑course on a few buzzwords:  

1. **NAV, iNAV, and market price**  
2. **Market makers & authorized participants (APs)**  
3. **Creation units**  
4. **Premiums & discounts**  
5. **Tracking error**  

### NAV vs. market price  

When you buy a mutual fund, you look at the NAV. For ETFs, you glance at the **market price** shown on your broker (e.g., Kite). This price is set by supply‑and‑demand on the exchange, just like any stock.  

![ETF prices](https://zerodha.com/varsity/wp-content/uploads/2021/02/Market-price-300x293.png)  

But is that price “fair”? That’s where the **end‑of‑day NAV** (still calculated once a day) comes in:  

\[
\text{NAV} = \frac{\text{Total asset value – expenses}}{\text{Number of ETF units}}
\]

Since ETFs trade in real time, the NAV can feel a bit stale. Enter the **indicative NAV (iNAV)**—a near‑real‑time estimate of the NAV, refreshed every 10–15 seconds by the AMC.  

\[
\text{iNAV} = \frac{\sum (\text{last price of each holding} \times \text{weight}) + \text{cash}}{\text{Total ETF shares}}
\]

Think of iNAV as the “price you should be paying right now” barometer.  

### Creation units  

If you’re a big‑ticket investor, you can buy ETF units **directly from the AMC**—but not one or two units. You must buy a **creation unit**, which is a pre‑defined basket of the underlying securities in the exact index weights.  

Example: **ICICI Nifty 50 ETF** has a creation unit of **50,000 ETF units**, worth roughly **₹ 80 lakhs** at today’s prices. You need that much cash to purchase the whole basket in one go.  

### Market makers & authorized participants  

Because ETFs trade all day, they need **liquidity providers**. These are the **market makers** (or **authorized participants**, APs). Their job is to continuously post **bid** (buy) and **ask** (sell) quotes, earning a tiny spread each time. Think of them as the baristas who keep the coffee flowing—without them, the market would get choppy.  

Most Indian market makers are large brokerage houses that have the infrastructure to handle the creation‑redemption dance.  

### Premiums, discounts, and tracking error  

Since ETF prices are set by market forces, they can **deviate** from the NAV:

| Situation | What it’s called |
|-----------|-------------------|
| Market price **>** NAV | **Premium** |
| Market price **<** NAV | **Discount** |

**Tracking error** measures how closely the ETF’s returns follow its benchmark index. Formally, it’s the annualized standard deviation of the difference between the ETF’s NAV returns and the index returns.  

Simple illustration: if **Nifty 50** returns **10 %**, but the **Nifty ETF** returns **9.8 %**, the tracking error is **0.2 %**. Lower tracking error → tighter tracking.  

### Why creation/redemption matters  

1. **Cost‑efficient large purchases** – If you want to buy a huge amount (multiples of the creation unit), it’s cheaper to go straight to the AMC. You avoid the market impact and spread‑drag that would occur on the exchange.  

2. **Arbitrage (the market‑maker’s playground)** – When an ETF trades at a premium, APs can **create** new ETF units (by delivering the underlying basket to the AMC), sell them on the exchange, and pocket the spread. When it trades at a discount, they **redeem** ETF units (hand over the ETF shares, receive the underlying basket), sell the basket, and capture the profit. This arbitrage pressure forces the ETF price back toward its NAV.  

**Example:** During the March‑April 2020 COVID crash, many Nifty‑linked ETFs showed noticeable premium/discount swings.  

![Premiums during March‑April 2020](https://zerodha.com/varsity/wp-content/uploads/2021/02/Premiums-Nifty-1024x491.png)  

#### A real‑world arbitrage story  

The **Motilal Oswal NASDAQ 100 (N100)** ETF in 2017‑2018 traded at **> 20 % premium** to NAV. Why? Market makers weren’t active enough. Clever traders could have approached Motilal AMC, asked for creation at NAV, sold the fresh ETF shares on the exchange at the inflated market price, and walked away with a tidy profit.  

Later, Motilal appointed new market makers and launched a **Fund‑of‑Fund (FOF)**, which helped tighten that premium.  

![N100 price vs NAV – huge premium](https://zerodha.com/varsity/wp-content/uploads/2021/02/N100.png)  
![N100 price vs NAV – after market‑maker fix](https://zerodha.com/varsity/wp-content/uploads/2021/02/N100-2.png)  

So, the creation‑redemption mechanism is the secret sauce that keeps ETFs liquid, price‑efficient, and arbitrage‑proof.  

---

## 29.7 – ETF liquidity  

Liquidity is the lifeblood of any security that trades intraday. When you eye an ETF, you’ll naturally check two numbers: **AUM** and **average daily volume**. They’re helpful, but they don’t tell the whole story.  

### Layers of ETF liquidity  

| Layer | What you see | Why it matters |
|------|--------------|----------------|
| **Secondary‑market liquidity** | Bid‑ask spread on your screen | A tight spread usually means you can get in/out without huge price impact. |
| **Market‑depth liquidity** | Order‑book depth (how many shares at each price) | Even a tight spread can be deceptive if there’s only a handful of shares on the other side. |
| **Primary‑market liquidity** | Ability to create/redeem units with the AMC | Large institutions often bypass the exchange and deal directly with the AMC, bypassing the on‑screen depth. |
| **Underlying‑asset liquidity** | How liquid the basket’s stocks/bonds are | An ETF can’t be more liquid than the least‑liquid security it holds. |

#### Secondary‑market example  

Look at two Nifty‑50 ETFs: **Mirae** (AUM **₹ 483 cr**) vs **LIC** (AUM **₹ 618 cr**). Both have traded only about **500 units** today.  

![Spread comparison](https://zerodha.com/varsity/wp-content/uploads/2021/02/Mirae-Nifty-50-ETF-vs-LIC-Nifty-50-ETF.png)  

Even though LIC’s AUM is larger, its on‑screen liquidity is almost nonexistent. If you slapped a market order for 100 units, you’d end up paying a lot more than the last traded price because there’s barely anyone willing to sell.  

#### Market‑depth insight  

Mirae’s order book shows **≈ 60,000 shares** on the sell side, meaning a market order (the rookie mistake) would still fill nicely at around **₹ 157.44**. LIC, on the other hand, shows a **dry‑run**—no depth, so any market order would “walk up the ladder” and fill at ever‑higher prices.  

#### Primary‑market liquidity  

Large players (HNIs, pension funds) often **create** new ETF units directly with the AMC, sidestepping the exchange entirely. That’s why the “visible” depth can be misleading—the market maker holds a hidden stash of units ready to be deployed.  

#### Underlying‑asset liquidity  

If you ever wonder why India still lacks a **small‑cap ETF**, the answer lies in the bottom‑tier stocks. After the top 200 companies, trading volume drops dramatically, and many stocks hit circuit limits daily. If a small‑cap ETF were to exist and demand spiked, the market maker might be **unable** to buy enough of those illiquid stocks to create new units, forcing the ETF to trade at a premium (or simply stall).  

**Takeaway:** Big‑cap ETFs (like Nifty 50) enjoy abundant underlying liquidity, while niche ETFs can suffer from “liquidity‑of‑the‑underlying” constraints.  

---

## 29.8 – ETF choices in India  

India currently hosts **≈ 88 ETFs** (as of early‑2026). The majority are **equity ETFs**, but we also have debt and commodity (gold) ETFs. Here’s the quick menu:

| Category | Sub‑type | What it tracks |
|----------|----------|----------------|
| **Equity ETFs** | *Vanilla* (cap‑weighted) | Nifty 50, Nifty 100, Sensex, etc. |
|  | *Smart‑beta* | Factor‑based indices – value, quality, low‑volatility, momentum |
| **Debt ETFs** | G‑Sec ETFs | Government securities |
|  | Bharat Bond ETF | PSU‑issued bonds |
|  | CPSE + SDL ETF (Nippon) | PSU bonds + State Development Loans |
| **Commodity ETFs** | Gold ETFs | Physical gold (held in vaults) |

A handy **full list** of Indian ETFs is available on the Zerodha Varsity site (link omitted for brevity).  

**Passive vs. “smart‑beta”**: Most Indian ETFs today are **passive** (they simply replicate a benchmark). Smart‑beta ETFs, while still tracking an index, tilt toward a factor‑based methodology – a hybrid between active and passive. Globally, **80‑90 %** of ETFs are passive; the rest are “active” or “smart‑beta”. India may eventually see truly active ETFs, but for now, the majority are the quiet, index‑following types.  

---

## 29.9 – ETF vs. index funds  

| Feature | ETF | Index Fund (mutual fund) |
|---------|-----|--------------------------|
| **Trading** | Real‑time on exchange (like a stock) | Once‑daily at NAV |
| **Order type** | Limit, market, stop, etc. | Generally market‑order (NAV‑based) |
| **Costs** | Brokerage + bid‑ask spread (no commission) | Possible entry/exit loads, commissions to distributors |
| **Flexibility** | Can be used for intra‑day tactical moves | Mostly “buy‑and‑hold” style |
| **Minimum investment** | 1 unit (≈ ₹ 10‑20) | Often ₹ 500‑₹ 1,000 (though some have lower) |

If you like **tactical, in‑the‑moment** positioning (think “I want to be long Nifty for the next 3 days”), ETFs win. If you’re a **lazy investor** who’d rather set it and forget it (like me, who prefers a single click once a month), index funds are the painless route.  

---

## 29.10 – Performance of ETFs vs. actively managed funds  

Over the past decade, the pendulum has swung heavily toward **passive** vehicles worldwide. Why? Because the **majority of active managers fail to beat their benchmarks**. In the United States, **≈ 90 %** of active funds under‑perform their peers over any given period.  

India’s market has matured, with institutional money dominating. Information asymmetry has shrunk, making it tougher for a fund manager to consistently spot a “secret” stock. Add in **high expense ratios** (active large‑cap funds ≈ 1.5 % vs. Nifty 50 index fund ≈ 0.10 %) and the math tilts heavily toward passive.  

The **SPIVA India** report (S&P’s performance index) shows that **> 70 %** of large‑cap active funds lag their benchmarks across all time horizons.  

![SPIVA India chart](https://zerodha.com/varsity/wp-content/uploads/2021/02/2023-08-10_16-19.png)  

Mid‑cap and small‑cap spaces, once considered “inefficient”, are also tightening. Since SEBI’s categorisation (2017‑2022), many active mid‑cap funds have struggled to keep pace with broad mid‑cap benchmarks (Nifty Mid‑Cap 150, BSE Mid‑Cap, etc.).  

**Bottom line:** For most investors, a **low‑cost, broad‑market ETF or index fund** outperforms the average active manager, especially after fees. Small‑cap active management may still have a niche, but it’s high‑risk and requires deep conviction.  

---

## Key takeaways from this chapter  

| ✅ | Insight |
|---|----------|
| **Real‑time trading** | ETFs can be bought/sold anytime the market’s open – you can even set up SIPs for them. |
| **Do your homework** | Blindly picking an ETF is a recipe for disappointment. Perform thorough due diligence. |
| **Liquidity matters** | Indian ETFs suffer from limited market depth; always check bid‑ask spreads, depth, and underlying asset liquidity. |
| **Never use market orders** | Always place **limit orders** and compare the limit price to the iNAV. |
| **Check iNAV** | AMC websites publish the intraday NAV; a big gap between iNAV and market price is a red flag. |
| **Track the index, not the NAV** | Compare the ETF price to the underlying index’s total‑return index (TRI) – dividends matter! |
| **Volume consistency** | Favor ETFs with steady daily volume; avoid those that only spike once in a blue moon. |
| **Choose the right style** | Large‑cap & mid‑cap passive ETFs usually beat active counterparts in India today. |

Enjoy the ETF playground, but remember: **smart orders + solid research = happy returns**. Cheers! 🍻  