# 17. Arbitrage Funds  

**Source:** https://zerodha.com/varsity/chapter/arbitrage-funds/

---  

## 17.1 – Arbitrage  

We were all set to march on to the next chapter of mutual‑fund wizardry when I had a sudden “aha!” moment: **we haven’t even talked about Arbitrage Funds!**  They’re the rock‑stars of the market right now, so let’s give them a quick cameo and then get back to the main show.  

### First things first – what *actually* is arbitrage?  

If you’ve been scrolling through Varsity before, you’ll remember us flirting with arbitrage in calendar spreads, pair‑trading, and put‑call parity.  If you’re fresh, think of the last time you bought a souvenir abroad and sold it at home for a tidy profit.  

> **My college‑days tape‑trade story**  
> I used to ask my cousin in Singapore to snag *Rock ‘n’ Roll* audio cassettes for ₹100 each. I’d bring them back to Bangalore and sell them for ₹150 because nobody else had them.  
>  
> In that tiny operation I was an **arbitrageur** – I bought cheap in one market (Singapore) and sold dear in another (Bangalore). The ₹50 per tape was, on paper, a **risk‑free** gain.  

Sounds like a dream, right? Just sit on a mountain of tapes, watch the cash roll in, and retire early.  

#### But life isn’t a sitcom.  

The whole trick hinges on **continuous demand and supply** in both markets. Imagine I’ve spent ₹100,000 on tapes, only to discover Bangaloreers have collectively decided that Boy Zone is the new “It” band. My inventory sits there like a pricey doorstop – the profit evaporates.  

That’s the **supply‑demand risk** baked into every arbitrage play.  

Now, let’s add another twist: **competition**.  

Suppose my buddy catches wind of the tape‑trade and decides to undercut me, selling at ₹140 instead of ₹150. What follows is a classic price war: I drop to ₹135, he slides to ₹125, and so on until the margin disappears faster than the last slice of pizza at a party.  

**Lesson:** The more people chase the same price‑gap, the slimmer the profit.  

### How does this look on a stock‑exchange screen?  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/06/Image-1_arb-300x71.png)  

The snapshot shows **Kirloskar Industries** quoted at **₹562.4** on NSE and **₹546.4** on BSE – a **₹16** spread.  
If you buy on BSE and instantly sell on NSE, you lock in that ₹16 (ignoring transaction costs). That’s a textbook arbitrage opportunity.  

A mutual‑fund scheme that spends most of its time hunting for such gaps is aptly named an **Arbitrage Fund**.  

---  

## 17.2 – The Arbitrage Fund  

The tape‑trade was just one flavor. In reality, markets serve up a whole buffet of arbitrage possibilities. The **most popular** for a fund manager is the **Spot‑Future arbitrage** – a situation where a futures contract is priced noticeably away from the underlying cash price.  

In plain English: the fund is either **long** or **short** the same security in the cash market *and* the futures market at the same time.  

> *“Did that sentence make you’s brain melt?”* – Don’t worry, we’ll break it down with a real‑world example.  

### Spot‑Future example with Maruti  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/06/Image-8_cashfut-300x75.png)  

*Date:* 18 June 2020  
*Cash price (Maruti)*: **₹5,714.4** per share  
*June futures price*: **₹5,735.6**  

**Spread (aka “basis”)** = 5,735.6 – 5,714.4 = **₹21.2**  

**Rule of thumb:** *Buy where it’s cheap, sell where it’s dear.*  

So the fund does two things **simultaneously**:  

1. **Buy** Maruti in the cash market at **₹5,714.4**.  
2. **Sell** the June futures at **₹5,735.6**.  

Because the trades happen at the same moment, the **₹21.2 spread is locked in**, regardless of where the price wanders later.  

#### The magic of convergence  

On the futures’ expiry day, the cash price and futures price *must* converge to a single number (the market can’t tolerate two different prices for the same asset forever). This is called **Cash‑Futures Convergence** and forces the fund to unwind the trade.  

Let’s say on expiry both markets quote **₹5,780**.  

| Position | Entry | Exit | P&L |
|----------|-------|------|-----|
| **Cash (Long)** | Buy @ 5,714.4 | Sell @ 5,780 | **+ ₹65.6** |
| **Future (Short)** | Sell @ 5,735.6 | Buy @ 5,780 | **‑ ₹44.4** |

Net P&L = 65.6 – 44.4 = **₹21.2** – exactly the spread we locked earlier. No matter the direction the price moves, the fund walks away with that ₹21.2 per share (ignoring transaction costs, taxes, and the occasional slip‑up).  

You can play the same numbers with different price levels and you’ll always see the spread survive.  

### The nitty‑gritty you *don’t* need to obsess over  

- **Rollover** – moving from one expiry to the next.  
- **Transaction costs** – brokerage, STT, exchange fees.  
- **Execution risk** – the chance you can’t fill both legs simultaneously.  

All that matters for a high‑level understanding is: **Arbitrage funds lock a spread, and that spread is their profit engine.**  

### What the fund documents actually say  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/06/Image-2_dsparb-300x36.png)  

DSP’s Arbitrage Fund simply promises “income generation through cash and derivatives markets,” without spilling the beans on the exact playbook. Many funds even brag about “low‑volatility returns.”  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/06/Image-3_icici.png)  

Why *low volatility*? A pure spot‑future arbitrage is almost deterministic, so the P&L curve looks relatively flat.  

#### But the devil is in the SEBI definition  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/06/Image-4_arbfund-300x42.png)  

SEBI mandates that **at least 65 %** of an arbitrage fund’s assets must be in bona‑fide arbitrage strategies. The remaining **35 %** can be invested *anywhere* the manager wishes – most commonly in debt securities.  

Because of that freedom, many arbitrage funds end up with a **debt‑tilt** that adds a dose of interest‑rate and credit risk, making the “low‑volatility” label a little optimistic.  

### Real‑world portfolio peek – ICICI Prudential Arbitrage Fund  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/06/Portfolio_Allocation.jpg)  

*Key observations:*  

- Every equity position is **fully hedged** with its futures contract – classic arbitrage.  
- Roughly **65 %** of the exposure is the hedged (arbitrage) part.  
- The remaining **35 %** sits in **debt & cash**.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/06/Image-6_debt-300x217.png)  

The debt slice is where the *real* risk hides.  

#### A cautionary tale – Principal Arbitrage Fund & DHFL  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/06/Image-7_principal-300x237.png)  

Principal Arbitrage Fund had a concentrated holding of **DHFL bonds**. When DHFL defaulted in October 2018, the fund’s NAV slipped from **₹11.5** to **≈₹10.9** – a **5.22 %** plunge.  

Five‑point‑two‑percent loss isn’t earth‑shattering, but the recovery took **about 1.5 years**. That teaches us three things:  

1. **Arbitrage funds are not risk‑free** – the debt side can bite.  
2. **Typical returns hover around 5‑7 %** – a single bad credit event can wipe them out.  
3. **Recovery isn’t instant** – you need a decent time horizon.  

Don’t panic; just keep the lessons in mind when you’re scouting a fund.  

### The *real* arbitrage (the tax one)  

The best part of an arbitrage fund is its **tax treatment**: it behaves like a debt fund (steady, low‑risk returns) but is taxed **as an equity fund**.  

| Asset class | Holding period | Tax treatment (India) |
|-------------|----------------|-----------------------|
| **Equity fund** – sold ≤ 12 months | Short‑term capital gain (STCG) | 15 % (plus cess) |
| **Equity fund** – sold > 12 months | Long‑term capital gain (LTCG) | 10 % on gains above ₹1 lac |
| **Debt fund** – held ≤ 36 months | STCG | Taxed at your personal slab |
| **Debt fund** – held > 36 months | LTCG | 20 % after indexation |

Because an arbitrage fund’s returns *look* like a debt fund but are taxed at the **15 % (or 10 % LTCG)** equity rate, you end up *paying less tax* than a straight‑up debt fund for comparable returns. That’s the **tax arbitrage** most investors (and fund houses) love.  

### How to pick a decent arbitrage fund  

1. **Inspect the debt slice** – avoid funds with a heavy concentration in a single issuer or low‑grade paper.  
2. **Check for un‑hedged equity** – any naked equity exposure defeats the whole arbitrage premise.  
3. **Look at the expense ratio** – arbitrage trades are thin‑margin; high fees can eat your spread.  

If the fund clears those hurdles, you can treat it as a **low‑duration / short‑duration** proxy: similar risk‑return profile, but with a more favourable tax regime.  

---  

### Key take‑aways  

- **Arbitrage funds** lock in price differentials (spreads) between correlated markets (e.g., cash vs. futures).  
- **SEBI** requires ≥ 65 % of assets to be in genuine arbitrage trades; the remaining ≤ 35 % can be placed in debt, adding credit/interest‑rate risk.  
- Because of that debt component, arbitrage funds **can be volatile**—they’re not the “risk‑free” unicorn some ads imply.  
- With the right tax treatment, they act like a **debt fund that gets taxed as equity** – a neat tax arbitrage.  
- When hunting one, scrutinize the **debt holdings** and confirm there’s **no un‑hedged equity**.  

Next stop: **Mutual‑Fund Metrics**. Stay tuned, and keep those spreads tight!