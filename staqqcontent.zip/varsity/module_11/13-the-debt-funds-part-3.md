# 13. The Debt Funds (Part 3)

**Source:** https://zerodha.com/varsity/chapter/the-debt-funds-part-3/

---  

## 13.1 – Debt Jargons  

Welcome back, fellow lockdown‑warrior! It’s day 27 of India’s “stay‑home‑and‑watch‑your‑plants‑grow” experiment. The COVID‑19 tally has crept past 17 000, with Maharashtra leading the pack at 3 500‑plus cases. Until the virus finally decides to take a coffee break, our mantra is still **social distancing**—so keep that six‑foot bubble intact, okay?  

I’ve heard a lot of you are using this forced Netflix‑break to level‑up your finance game. The traffic on Varsity has exploded like popcorn in a microwave. Here’s a quick peek at the Google‑Analytics heat‑map:  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/04/Image-1_stats-300x67.png)  

And the inbox? It’s bursting at the seams. We’re spending hours each day answering the avalanche of questions you’re sending our way.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/04/M11-C13-Illustration-300x200.jpg)  

If the new chapter feels a tad sluggish, blame the sheer volume of curiosity‑fuelled traffic—not a lazy writer. 🙂  

Last time we dipped our toes into **Macaulay Duration**—the number of years it takes a bondholder to get back the cash they paid, courtesy of the bond’s coupon and principal cash‑flows. We didn’t go full‑blown math because that would have turned this into a night‑time horror story, but I promised a deeper dive in the “fixed‑income mini‑series” later on.  

While we’re cruising, let’s lock down a couple of bond basics you **must** have on your mental cheat‑sheet:  

- **Yield ↔ Price:** They’re sworn enemies. When a bond’s price climbs, its yield falls, and vice‑versa.  
- **Interest Rate ↔ Price:** Same love‑hate relationship. Higher market rates push bond prices down; lower rates pull them up.  

Now, meet the next star of the show: **Modified Duration**.  

> **Modified Duration** (in years) measures how much a bond’s price will wiggle when the interest rate shifts.  

Think of it like this: a bond with a modified duration of **3.2 years** will react as follows:  

- **+1 % interest rate** → price drops ~3.2 %  
- **+1.5 % interest rate** → price drops ~4.8 % (3.2 × 1.5)  
- **–1 % interest rate** → price rises ~3.2 %  
- **–1.5 % interest rate** → price rises ~4.8 %  

In plain English: the longer the duration, the more jittery the bond when rates move. A **high‑duration fund** will shake harder than a low‑duration one for the same 1 % rate swing.  

When we talk about a **mutual‑fund NAV**, the modified duration is an **aggregate** figure for the whole portfolio. So if interest rates jump by 1.5 %, a fund with a 4.8 % modified duration would see its NAV dip by roughly that amount. Got it? Good.  

Now that you’re a semi‑pro, let’s add the other two classic villains that stalk any debt‑fund holder:  

- **Credit risk** – the chance that a bond in the fund gets downgraded (think “oops, we’re not as safe as we claimed”).  
- **Default risk** – the scary scenario where the issuer simply *doesn’t* pay the coupon or principal.  

Sure, we know interest‑rate risk is a thing, but for now, let’s assume the fund manager has some fancy hedging tricks up their sleeve.  

Enough chit‑chat – we’re about to plunge back into the world of debt funds. In this chapter we’ll dissect a few more sub‑categories, starting with **low‑duration, money‑market, and short‑duration** funds. Buckle up!  

---

## 13.2 – Low‑Duration and Money‑Market  

Recall the **ultra‑short‑duration** fund we covered earlier? Its defining rule, per SEBI, is a **Macaulay duration between 3 – 6 months** (yes, that’s half a year, not a half‑second).  

Enter the **low‑duration** fund – essentially the ultra‑short’s older sibling. Its portfolio’s Macaulay duration must sit **between 6 – 12 months**. Think of it as the “teenage” version: still young, still flexible, but with a tad more independence.  

Credit‑risk wise, low‑duration funds are on par with ultra‑short ones, so you still want to eyeball the *paper quality* (aka the credit ratings) before you dive in.  

### Spot‑check: IDFC’s Low‑Duration Fund  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/04/Image-2_sebiclass-300x196.png)  

IDFC’s portfolio is a **100 % AAA** extravaganza. But remember the Vodafone saga from the previous chapter? Even AAA isn’t a guarantee of immortality—ratings can slip faster than a cat on a hot tin roof.  

Interest‑rate risk for low‑duration funds is modest. Check out the **modified duration** from IDFC’s factsheet:  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/04/Image-3_modduration-300x45.png)  

It’s **289 days**. Convert that to years (the finance world loves 360‑day years):  

\[
\frac{289}{360} \approx 0.802\ \text{years}
\]  

So a 1 % swing in rates nudges the NAV by about **0.8 %** – hardly enough to make your coffee jittery.  

Not all funds quote modified duration in days; some (like Nippon India) give you the number straight in years:  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/04/Image-4_nippon-293x300.png)  

Nippon’s low‑duration fund shows **0.94 years**. No need to divide by 360 here; just use the figure as‑is.  

**Quiz time:** Which fund is *riskier* in terms of interest‑rate sensitivity?  

- IDFC (0.802 yr)  
- Nippon India (0.94 yr)  

If you guessed **Nippon**, you’re spot‑on. Why does Nippon’s duration sit higher? Peek at their April 2020 portfolio and you’ll see a slightly longer‑maturity mix—maybe a few 10‑month bonds instead of pure 6‑month paper.  

**Who should consider low‑duration funds?**  
If you have a short‑term goal (think “down‑payment for a car in 9 months” or “emergency fund for the next rainy season”), a low‑duration fund can park your cash while you wait, offering a modest yield over a regular savings account.  

### Money‑Market Funds – The Cousin  

Money‑market funds are the **next‑door neighbor** of low‑duration funds. Here’s the SEBI definition:  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/04/Image-5_money-mkt-fund-300x30.png)  

Key take‑away: **Maximum maturity = 1 year**. The difference lies in **what they can hold**.  

- **Low‑duration fund** → can own money‑market instruments *and* bonds, as long as the aggregate duration stays 6‑12 months.  
- **Money‑market fund** → **only** money‑market instruments.  

Typical money‑market holdings:  

- **Commercial Papers (CPs)** – unsecured short‑term notes issued by corporates.  
- **Certificates of Deposit (CDs)** – bank‑issued time‑deposits.  
- **Treasury Bills (T‑Bills)** – sovereign‑guaranteed government paper.  

So a low‑duration manager can sprinkle a 2‑year bond into the mix, while a money‑market manager must stick to the “under‑1‑year” crowd.  

**Two quick brain‑teasers:**  

1. What risk does a money‑market fund face?  
2. What do you think its modified duration will be—**< 1**, **≈ 1**, or **> 1**?  

Take a pause, imagine the answer, then check yourself against the factsheet of **UTI’s Money‑Market Fund**:  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/04/Image-6_UTI-300x237.png)  

- **Risk:** Credit risk is real. About **9.39 %** of the assets sit in a single company’s CP/CD. Even if the rating is stellar today, it can tumble tomorrow.  
- **Modified duration:** As expected, it’s **under 1 year** (around 0.3‑0.5 yr in most cases), meaning interest‑rate exposure is minimal.  

Bottom line: Money‑market funds and low‑duration funds are cousins, both offering low interest‑rate risk but still carrying **credit risk**. Many investors bounce between the two depending on liquidity needs and the subtle taste of risk they prefer.  

---

## 13.3 – Short‑Duration and Medium‑Duration Funds  

Next stop: **short‑duration** funds. SEBI’s official wording (the boring but necessary part) looks like this:  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/04/Image-7_sdf-300x61.png)  

In plain English: the portfolio’s **Macaulay duration must be between 1 – 3 years**. What pops into your mind? Probably the same thing we learned earlier—**longer duration = more interest‑rate sensitivity**.  

That’s right: a short‑duration fund is *more* jittery than low‑duration or money‑market funds when rates move. The same holds for **medium‑duration** funds, which we’ll meet a bit later.  

Credit risk doesn’t disappear either. Let’s glance at the **Mirae Asset Short‑Term Fund** rating breakdown:  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/04/Image-8_rate-246x300.png)  

You’ll see a blend of **AAA, AA, and A‑plus** papers—a decent mix but still exposed to downgrades.  

Now, the **modified duration** for this fund:  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/04/Image-9_mod-300x152.png)  

It clocks in at **2.67 years**. Translation: a 1 % uptick in market rates would shave **2.67 %** off the NAV. That’s a heftier swing than anything we’ve seen so far.  

Notice the **Macaulay duration** is comfortably below 3 years, satisfying SEBI’s rule.  

### When (and why) to consider short‑duration funds  

Because the risk is higher, you should only hop on board if you have **at least a three‑year horizon**. Think of it as a “medium‑term” parking spot for cash that you don’t need right now but plan to use in a few years.  

With added risk comes **higher expected returns**. Historically, short‑duration funds have delivered around **7 % (ish)** per annum—so you’re being compensated for the extra jitter.  

If you’ve made it this far, you’ve basically earned a **debt‑funds 101** badge.  

### Medium‑Duration Funds – The “Just‑Right” Option  

Here’s SEBI’s snapshot for **medium‑duration** funds:  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/04/Medium_Duration_Fund.jpg)  

The mandate? Portfolio Macaulay duration between **3 – 5 years**.  

**Your homework (yes, we love homework):** Grab a fact‑sheet of any medium‑duration fund and answer these questions (feel free to shout if you get stuck):  

1. **Portfolio composition** – What instruments are they holding? How are the papers rated?  
2. **Credit risk** – Given the mix, how risky is the credit side?  
3. **Macaulay duration** – Does it sit inside the 3‑5 year window?  
4. **Modified duration** – What does that tell you about interest‑rate exposure?  
5. **Your investment horizon** – If you were to invest, how long would you stay put?  

I’m confident you’ll ace it. If you stumble, drop a query at the end of this chapter and I’ll swing by with a helping hand.  

In the next installment we’ll tackle **credit‑risk intricacies, dynamic bonds, and the ever‑enigmatic gilts**. But before we close the book on this chapter, there’s one more story that’ll make you respect liquidity risk a lot more.  

---

## 13.4 – The Franklin India Debt‑Fund Saga  

**23 April 2020** – Franklin Templeton (India) AMC dropped a bombshell that sent ripples through the debt‑fund community:  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/04/Image-11_franklin-203x300.png)  

They announced the **closure of six debt schemes**, including their low‑duration and ultra‑short‑duration funds, totaling roughly **₹27,000 crore** in AUM.  

Why the dramatic exit? The AMC blamed **mass redemptions** spurred by the COVID‑19 economic shock, which created a **liquidity crunch**.  

- In March 2020 alone, investors asked for **₹9,000 crore** (about **one‑third** of the total AUM) to be cashed out.  

The problem? India’s **secondary bond market** is about as liquid as a thick milkshake—hard to pour quickly without splashing. Fund managers can’t simply sell a whole lot of bonds overnight without bruising prices, so most of the holdings stay on the books until maturity.  

AMC’s usual toolkit includes **laddering** (spreading maturities across the timeline) to smooth cash‑flow needs. Under normal conditions, this works fine. But when the market turns into a chaotic supermarket on a Black Friday, the ladder collapses.  

No AMC (at least not until now) had prepared for a redemption wave of this magnitude. Consequently, Franklin decided to **lock the funds**—meaning investors can’t submit redemption requests until the fund is formally wound up.  

Important nuance: **This isn’t a credit‑risk or interest‑rate‑risk failure**. Franklin’s debt‑fund team is top‑notch; they’ve survived many cycles. The issue is purely **liquidity risk**—the danger that a fund can’t meet redemption demands promptly.  

So, dear reader, when you evaluate any debt fund, you now have **three risk lenses**:  

1. **Credit risk** – “Will the issuer default or get downgraded?”  
2. **Interest‑rate risk** – “How will a rate move affect NAV?”  
3. **Liquidity risk** – “Can the fund actually sell assets when I need cash?”  

Quantifying liquidity risk is still a budding art (think of it as the “wild west” of risk metrics), but you now know it exists and can ask fund managers about their **redemption buffers, laddering strategies, and cash‑holdings**.  

**Should you shun debt funds altogether?** Absolutely not. They remain a cornerstone of a balanced portfolio, especially when equity markets look like a roller‑coaster after a pandemic. The current crisis merely reinforces the age‑old wisdom of **asset allocation**—don’t put all your eggs in one (liquid) basket.  

We’ll keep unpacking these ideas as we sail through the rest of the module. Until then, stay home, stay safe, and keep those spreadsheets tidy!  

### Key Takeaways  

- **Bond yields ↔ bond prices:** Inverse relationship—when one climbs, the other falls.  
- **Interest rates ↔ bond prices:** Also inverse—higher rates push prices down.  
- **Modified duration:** Tells you how much a fund’s NAV will move (≈ % change) for each 1 % change in interest rates.  
- **Low‑duration funds:** Carry **credit risk** but enjoy **low interest‑rate risk**.  
- **Money‑market funds:** Same credit exposure, still low interest‑rate risk (duration < 1 yr).  
- **Short & medium‑duration funds:** Exposed to both **credit** and **interest‑rate** risks; higher duration means higher sensitivity.  
- **Liquidity risk:** A third, often‑overlooked danger—especially evident in the Franklin saga.  

Keep these pearls in mind, and you’ll navigate the debt‑fund world like a seasoned captain (even if you’re still in your pajamas). Happy investing!  