# 6.                            Introduction to Mutual Funds  

**Source:** <https://zerodha.com/varsity/chapter/introduction-to-mutual-funds/>  

---  

## 6.1 – Flashback  

The *Retirement Problem* chapter gave us a tidy roadmap for personal‑finance mastery. One of the signposts on that road was crystal clear: if you want a comfy nest egg, you *have* to put a chunk of money into long‑term mutual funds. Since mutual funds are the workhorse that can turn today’s rupees into tomorrow’s freedom, it’s only fair we spend a little quality time getting to know them.  

But I’m not talking about the “mutual fund 101” you get from that one‑line definition on a brochure. I want to go a notch deeper—just enough to make you feel comfortable chatting about expense ratios at a party, yet not so deep that you need a PhD in finance to stay awake. Here’s the buffet of topics we’ll chew over:  

- **What exactly is a mutual fund?**  
- **Who runs one and why they get paid for it**  
- **The regulator’s playbook from an investor’s point of view**  
- **The family tree of funds – Equity, Debt, FoF, Hybrid, Liquid**  
- **How to dissect a fund: risk, return, ratios, sector exposure**  
- **Stuff that actually matters – MF ranking, Direct vs Regular, Growth vs Dividend**  
- **Setting realistic long‑term return & risk expectations**  
- **Building goal‑based MF portfolios (because you’re not just investing for fun)**  
- **Logistics 101 – SIP, SWP, STP, CAS statements, DEMAT vs non‑DEMAT**  
- **Keeping tabs on your investments**  
- **Mutual‑fund taxation (the not‑so‑fun‑but‑necessary part)**  

If anything else pops up and you think, “Hey, that would be useful!” – feel free to shout. I’ll happily toss it in.  

Now, before we dive headfirst into “what the heck is a mutual fund?”, let’s set the stage. I’m going to assume you’re a total newbie—like you’ve never heard the term before. If you already know the basics, feel free to skim this chapter and jump to the next.  

### A little personal anecdote (2008‑09 style)

How many of you were watching the markets in 2008, clutching your coffee while the Dow did somersaults? If you were a bystander, it was like watching a disaster movie with popcorn. If you were *in* the market, it felt more like being on a roller‑coaster that forgot its brakes.  

I was in London—the very heart of the financial apocalypse—fresh out of university, armed with a flimsy résumé and an even slimmer network. When the wave of layoffs rolled through the City, I knew the only question was *when* my desk would get a “Thanks for your service” email.  

Instead of twiddling my thumbs, I booked a one‑way ticket back to India. By February 2009 I was back in Bangalore, lucky enough to land a seat at the (now‑legendary) Kamath Associates (pre‑Zerodha). I was suddenly knee‑deep in the Indian exchanges, buying and selling anything that moved. My capital? Mostly my own savings, with a pinch of cash from friends who trusted my enthusiasm.  

Trading was a rush, but the deeper, slower‑burning joy came from *investing*. I devoured annual reports, taught myself a crash course in accounting, and started treating each company like a new person I was trying to date—understanding their strengths, weaknesses, and long‑term potential.  

Soon enough, I shifted from day‑trading to building a disciplined equity portfolio. I left Kamath Associates, the firm dissolved, and Nithin Kamath went on to start Zerodha (the same Zerodha you’re reading about right now).  

I built a modest but thoughtful portfolio, each stock backed by a thesis, each risk factor noted in a notebook that looked more like a detective’s case file than a spreadsheet. My family and a few close friends started asking, “Hey, can you do this for us too?” Before I knew it, I was the unofficial family‑stock‑picker.  

Fast forward to November 2010: I decided to turn this hobby into a *profession*. My mission? To help people build equity portfolios, manage them, review performance, and keep risk in check—all with one simple goal: grow wealth over the long haul. In other words, I wanted to be a *fund manager*—the kind of guy who makes your money work while you’re sleeping (or binge‑watching Netflix).  

By 2012, I’d onboarded a handful of clients—roughly 20‑25 families—managed a decent chunk of money, and sent out a monthly performance report every first Saturday. I was living the fund‑manager dream.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2019/10/M11-C6-Illustration-300x200.jpg)  

**But then the regulator (aka SEBI) knocked on the door.**  

SEBI says anyone who wants to manage other people’s money professionally needs a *Portfolio Management Service* (PMS) licence. That licence comes with a hefty net‑worth requirement and a mountain of paperwork. The cost was more than my startup capital, so I had to shut shop and return the capital to my clients.  

*Why am I sharing this melodramatic flashback?* Because it illustrates the core duties of a fund manager, which you’ll see mirrored in the mutual‑fund world:  

- Research stocks (or bonds, or whatever asset class)  
- Build a thesis for each investment  
- Decide how much money to allocate to each idea  
- Assemble a portfolio (the “basket of goodies”)  
- Track each holding and the overall portfolio performance  
- Measure returns, risk, and other metrics at regular intervals  
- Communicate results to the investors  

That’s the essence of fund management. Keep it in mind as we move on to mutual funds, because they are basically a *scaled‑up* version of what I was doing, but with a legal wrapper that lets you invest with a few clicks.  

> **Quick reminder:** We’re still in the “what’s a mutual fund?” zone, so stick around—there’s a lot more fun ahead! 🙂  

## 6.2 – Large‑Scale Fund Manager  

Picture this: you stroll into your neighborhood bakery for a fresh loaf or a packet of those oddly‑shaped biscuits that only your street’s bakery makes. They taste *unique*—like a secret family recipe—because the baker is a local artisan with a tiny distribution network.  

Now imagine you’re in a supermarket, picking up a Britannia biscuit. Whether you’re in Bangalore or Delhi, that biscuit looks, feels, and tastes *exactly* the same. No surprises, no “oops, this one is a little crunchier.” Britannia is a *large‑scale* baker with a national distribution engine that guarantees uniformity.  

In the world of fund management, I was the neighborhood baker—catering to a handful of friends and family, crafting bespoke portfolios by hand. Large‑scale fund managers, on the other hand, are the Britannia of investing. They serve millions of investors with the *same* product (the mutual fund) and the *same* process, ensuring that every investor gets a slice of the same cake.  

So who are these “big‑baker” fund managers? They usually operate through a **mutual‑fund structure**, which is simply a legal and operational framework that lets them manage huge pools of money while keeping things transparent and regulated.  

Let’s recap the analogies we’ve built so far:  

- **Fund manager** = the baker who decides which ingredients (stocks, bonds, etc.) go into the mix.  
- **Asset Management Company (AMC)** = the bakery building where the baker works, complete with ovens, mixers, and a payroll department.  
- **Mutual‑fund structure** = the *vehicle* (think of it as the delivery truck) that transports the baked goods (your money) from the bakery to your kitchen (your investment account).  

Got it? Great.  

Now, you might be thinking, “Do I really need to know how the bakery is built? I just want a slice of cake!” The answer is a resounding *maybe*. Knowing a little about the AMC’s architecture is like understanding the camera’s manual mode—sure, auto works, but once you get the hang of it, you can capture that perfect shot (or in our case, a better‑optimized portfolio).  

## 6.3 – Deconstructing an AMC  

Launching an **Asset Management Company (AMC)** isn’t as simple as opening a lemonade stand. You can’t just wake up one morning, grab a coffee, and declare, “I’m now an AMC!” The Indian regulator—**Securities and Exchange Board of India (SEBI)**—has a whole checklist that you must clear before you’re allowed to hold public money.  

Why the heavy‑handed scrutiny? Because we’re talking about *other people’s* retirement savings, children’s college funds, and dream‑home deposits. The regulator’s job is to make sure the entity handling this money is trustworthy, transparent, and financially sound.  

### SEBI’s Multi‑Tier AMC Blueprint  

SEBI has mandated a layered structure for every AMC. Below is the anatomy of a typical AMC, complete with the roles each piece plays.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2019/10/Image-2_AMC-Structure-with-watermark-300x212.jpg)  

1. **Fund Sponsor** – Think of the sponsor as the *entrepreneur* who says, “I want to start an AMC.” This is usually a corporate entity with deep pockets and a reputation to protect. The sponsor files a two‑stage application with SEBI:  

   - **Stage 1** – Submit an outline; SEBI either says “Nope” or gives an *in‑principle* nod.  
   - **Stage 2** – After the green light, the sponsor must furnish exhaustive documentation, financial statements, governance policies, etc. SEBI then does a final deep‑dive and either grants the licence or rejects the application.  

2. **Trustees** – Once the sponsor gets the licence, a *trust* is set up, and a board of **trustees** is appointed. The trust acts as a guardian for the investors (the *unit holders*). The trustees must be independent of the sponsor—no cozy family ties—so they can keep the AMC honest.  

3. **AMC (Investment Manager)** – The trust, in consultation with the sponsor, appoints the **AMC** itself. This is the *engine room* where the Chief Investment Officer (CIO), fund managers, analysts, compliance officers, and support staff work. The AMC designs and runs the various mutual‑fund schemes, adhering to SEBI’s rules.  

4. **Custodian** – The custodian is the *safe‑keeper* of the actual securities the fund buys (stocks, bonds, etc.). Think of it as the vault where the fund’s assets are stored, separate from the AMC’s own balance sheet for safety.  

5. **Registrar & Transfer Agent (RTA)** – The RTA handles the *customer‑service* side: issuing folio numbers, processing purchases/redemptions, maintaining unit holder records, and ensuring smooth transfers.  

All these players must *dance in sync* for the mutual‑fund ecosystem to work. As an investor, you only need to keep an eye on two things:  

- **Who’s the sponsor?** (Credibility check)  
- **Who’s the fund manager?** (Skill & track record check)  

### Real‑World Example: Aditya Birla Sun Life  

Let’s ground this in a concrete illustration. Below is a snapshot of the **Aditya Birla Sun Life** AMC’s structure (all data taken from their public filings).  

![Image](https://zerodha.com/varsity/wp-content/uploads/2019/10/Image-3_fundsheet-300x269.png)  

- **Sponsors**: *Aditya Birla Capital Limited* and *Sun Life (India) AMC Investments Inc.* – two heavyweights who teamed up to get the licence. Because there are two sponsors, this is a joint venture, and the shareholding pattern looks like this:  

  ![Image](https://zerodha.com/varsity/wp-content/uploads/2019/10/Image-2_share-300x48.png)  

- **AMC (Investment Manager)**: *Aditya Birla Sun Life AMC Limited* – the entity that actually runs the funds.  

- **Trustee**: *Aditya Birla Sun Life Trustee Private Limited* – the independent guardian of investors’ interests.  

- **Service Providers** (Custodians & RTA):  

  ![Image](https://zerodha.com/varsity/wp-content/uploads/2019/10/Image-4_service-245x300.png)  

  Here you see two custodians—*Citi* and *Deutsche*—and one RTA—*CAMS*. The diagram also lists the AMC’s auditors, bankers, and other compliance partners.  

### Bottom‑Line Takeaways  

- **Fund manager** = the chef who decides the recipe (asset allocation).  
- **Sponsor** = the restaurant owner who provides the kitchen and the licence.  
- **AMC** = the kitchen staff and equipment that actually cook the food.  
- **Custodian** = the pantry that stores the raw ingredients safely.  
- **RTA** = the waitstaff who deliver the meal to your table (your folio).  

If you keep these roles straight, you’ll never feel lost when you read a mutual‑fund prospectus.  

---  

### Key Takeaways from this Chapter  

- A **fund manager** is the person (or team) responsible for picking assets and steering the fund’s performance.  
- The **sponsor** of an AMC is essentially the promoter that holds the licence and brings credibility.  
- The sponsor appoints a **trustee** and the **AMC** (investment manager) to run the show.  
- The **AMC** executes the investment strategy, complies with SEBI rules, and manages day‑to‑day operations.  
- A **custodian** safeguards the fund’s securities, keeping them separate from the AMC’s own balance sheet.  
- The **RTA** handles unit‑holder services—folio numbers, transfers, and redemption processing.  
- As an investor, the two most important names to note are **who the sponsor is** (for credibility) and **who the fund manager is** (for skill).  

Armed with this backstage pass, you’re now ready to walk onto the mutual‑fund stage with confidence—and maybe even drop a witty comment about “custodians” at the next dinner party. Cheers to becoming a smarter investor! 🍻  