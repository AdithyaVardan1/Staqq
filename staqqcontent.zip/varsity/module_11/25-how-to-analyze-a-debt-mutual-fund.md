# 25. How to Analyze a Debt Mutual Fund?  

**Source:** <https://zerodha.com/varsity/chapter/how-to-analyze-a-debt-mutual-fund/>

---  

## 25.1 – The “Confused Portfolio” Dilemma  

In the last chapter we fell head‑first into an equity fund – **Kotak Standard Multi‑Cap Fund** – and walked you through the classic equity‑fund‑analysis checklist. We discovered it was a solid performer, especially when it came to keeping risk in check.  

So, the obvious next question is: *If the fund is good, should I just throw my cash at it and add it to my portfolio?*  

On paper it sounds like a no‑brainer. We’ve already poked it, prodded it, and it ticks all the nice‑boxes. But remember, **the decision to buy a fund shouldn’t be driven by how shiny the fund looks**. It should be driven by **the objective of your whole mutual‑fund portfolio**.  

Your portfolio objective is just a fancy way of saying “what am I really trying to achieve?” – a rainy‑day emergency fund, a child’s education, a future house, or just “I want my money to do something other than sit in a savings account.”  

If my goal is to build a **quick‑access emergency corpus**, an equity fund that can swing 30 % in a week is about as helpful as a fireworks display in a library. It might be great, but it’s the wrong tool for the job.  

This feels counter‑intuitive, I know. It’s like telling someone with a sore knee, “Hey, take a Dolo‑650!” – you’d rather see a orthopaedic specialist first, maybe get an MRI, and only then decide whether a pill, physio, or a good night’s rest is the right fix.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/11/M11-C25-How-to-analyze-a-debt-fund-WEB-300x200.jpg)  

Similarly, you should only add a fund to your basket **when its risk‑return personality matches the personality of your portfolio**. Ignore that, and you’ll end up with a **“confused portfolio”** – a mishmash of funds that don’t speak the same language.  

In the next few chapters we’ll talk about aligning funds with goals, but before we get to that, let’s dive into the nitty‑gritty of analysing a **debt** mutual fund.  

---

## 25.2 – Risk Recap (Quick‑fire Refresher)  

Just like we did for equities, we’ll pick a debt fund and dissect it. But first, a lightning‑round on the **big three risks** that haunt every debt fund.  

### 1. Credit Risk  

Debt MF’s are basically big‑ticket lenders. Imagine **Company A** wants to raise ₹50 cr for expansion and floats a 5‑year bond at a 9 % coupon. AMC X buys that bond. If everything goes smoothly, Company A pays the 9 % coupon each year and returns the ₹50 cr at maturity.  

But what if Company A gets a nasty surprise – a product flop, a regulatory fine, or a sudden drop in demand? It might miss an interest payment, or worse, wave a white flag and say “no cash, no principal.” That’s the dreaded **default** scenario, and the chance of it happening is the **credit risk**.  

A sub‑type of this is **rating‑downgrade risk**. Even if Company A is chugging along today, rating agencies might spot trouble brewing, downgrade its rating from **AAA to AA**, and the market will react instantly. The downgrade itself can depress the bond’s price, hurting the fund.  

### 2. Interest‑Rate Risk  

Bond prices and interest rates are like oil and water – they *don’t* mix. When rates fall, bond prices rise (good for NAV); when rates rise, bond prices fall (bad for NAV).  

The **modified duration** tells you how much the bond’s price will move for a 1 % change in rates. A higher duration = more wiggle‑room, i.e., higher interest‑rate risk. In a debt fund, the reported modified duration is a weighted average across all the bonds it holds.  

### 3. Liquidity Risk (Bonus round)  

If the fund needs to sell a bond quickly to meet redemptions, a thinly‑traded bond can fetch a discount, dragging down NAV. Keep an eye on how many securities the fund holds and its total AUM – extreme ends (tiny or gigantic funds) can both suffer liquidity hiccups.  

Now that the risk‑menu is refreshed, let’s roll up our sleeves and start the **debt‑fund deep‑dive**.  

---

## 25.3 – Portfolio Check (The Real Deal)  

**TL;DR:** *Buy a fund because it matches your goal, not because it’s “good.”*  

Debt funds are often sold as the “safe‑as‑houses” alternative to a bank FD. In reality, **they’re not risk‑free**. A poorly‑managed debt fund can be volatile enough to erode your capital permanently.  

I’m not trying to scare you off; I’m just waving a red flag so you don’t think “low risk = no risk.”  

### The Fund We’ll Dissect  

Enter **Mirae Asset Short‑Term Fund** – a relatively fresh face (NFO in early 2018). Because it’s short‑term, it invests in bonds that mature in **1–3 years**.  

#### 1. Average Maturity  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/11/Image-1_mat-300x116.png)  

The graph shows an **average maturity of ~2.5 years**. That tells us the fund sits in the sweet spot where **credit, rating, and interest‑rate risks** can all bite hard if something goes sideways.  

**Rule of thumb:** *Stay invested at least as long as the fund’s average maturity.*  
- For this fund → **≈ 2.5–3 years** minimum.  
- For a 10‑year gilt fund → **≈ 10 years** minimum.  

Why? If a shock hits, NAV may dip sharply, and you’ll need enough time for the bond ladder to roll over and recover.  

#### 2. Portfolio Allocation  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/11/Image-2_allocation-300x300.png)  

The pie tells us **67.31 % of assets are in corporate bonds**. That’s a big exposure to **credit risk**.  

So, how do we gauge whether the fund manager is handling this risk responsibly? Look for:  

- **Diversification across issuers** – no single corporate should dominate.  
- **Credit‑rating distribution** – most bonds should be high‑grade (AAA/AA).  
- **Concentration limits** – e.g., no more than 5 % in any one issuer.  

#### 3. Digging Into the Holdings  

You can pull the full spreadsheet from Mirae’s download hub: <https://www.miraeassetmf.co.in/mutual-fund-scheme/fixed-income/mirae-asset-short-term-fund>  

Here’s a snapshot:  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/11/Image-3_port-300x182.png)  

- **56 securities** in the book – decent breadth.  
- Top three holdings (each > 3 %) are **sovereign bonds** → no single corporate “credit‑risk monster.”  

Let’s zoom in on a specific issuer:  

| Issuer | Holding % | Bond | Maturity |
|--------|-----------|------|----------|
| RIL    | 2.44 %    | 7 % coupon | Aug 2022 |
| RIL    | 1.64 %    | 8.3 % coupon | Mar 2022 |

Add them up → **~4.08 %** exposure to Reliance.  

The fund’s fact sheet (or the quick‑look table) shows:  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/11/Image-4_corpbond-300x93.png)  

- **Reliance:** 5.56 %  
- **NHB (National Housing Bank):** 5.23 %  
- **PFC (Power Finance Corp):** 5.12 %  

These are **moderately concentrated bets** – not disastrous, but worth noting.  

#### 4. How Does the Fund Stack Up Against Its Peers?  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/11/Image-5_pa-300x184.png)  

- **Number of securities:** Fund = 56, Category average = 64. Slightly tighter, but not alarming.  
- If the gap were huge (e.g., 45 vs. 65) I’d start worrying about concentration risk.  

#### 5. Credit‑Rating Profile  

From the AMC’s website:  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/11/Image-6_paper-300x235.png)  

- **14.41 % sovereign** → essentially free of credit risk.  
- **66.3 % AAA** → top‑grade corporate bonds.  
- **~8.5 % A+ / AA** → still decent, but a hint that the manager is reaching for extra yield.  

A quick glance at Value Research’s rating breakdown:  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/11/Image-7_credit-300x170.png)  

- **AAA exposure:** 66 % (vs. category ~45 %) – higher quality than peers.  
- **Sovereign exposure:** 14.5 % (vs. category ~25 %) – a tad lower than average.  
- **Cash equivalents:** Higher than peers – a buffer, but also a sign of lower yield pursuit.  

**Interpretation:** The fund is **leaning a little into credit risk** to boost returns, even though it’s a short‑duration vehicle. For a fund meant to be a “parking spot” for 2–3 years, I’d prefer a more conservative credit mix.  

---

## 25.4 – Other Checks (The Fine Print)  

Let’s revisit those portfolio aggregates:  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/11/Image-5_pa-300x184.png)  

| Metric | Fund | Category |
|--------|------|----------|
| **Modified Duration** | **1.97** | 2.34 |
| **Average Maturity (years)** | **2.28** | 2.89 |
| **Yield‑to‑Maturity (YTM)** | **4.59 %** | **5.18 %** |
| **AUM** | ~₹650 cr | — |

- **Modified Duration** is a touch lower than the category, reflecting the fund’s shorter average maturity – it’s less exposed to rate swings.  
- **YTM** is lower than peers (4.59 % vs. 5.18 %). A lower YTM can be a **good sign** (less risk‑taking) or a **bad sign** (manager not chasing yield enough). In this case, the lower YTM aligns with the higher AAA share, so it’s not a red flag.  
- **AUM** is modest. In debt funds, *very* large AUM can cause liquidity squeezes during mass redemptions, while *tiny* AUM may never get decent pricing on bonds. A mid‑size fund (~₹500 cr–₹2,000 cr) is usually a sweet spot.  

### Bottom‑Line Decision  

Would I hop on the Mirae Asset Short‑Term bandwagon? I’d hesitate, mainly because:  

1. **Concentrated corporate exposure** (Reliance, NHB, PFC each > 5 %).  
2. **Slightly higher credit risk** than the category (more AAA, but also a fair chunk of A+/AA).  
3. **New fund** (launched 2018) – limited track record.  
4. **Modest AUM** – could become a liquidity issue if the fund grows too fast or shrinks too much.  

I’m not saying the fund is a disaster; it could still be a decent choice for a very risk‑averse investor who loves AAA bonds. But there are probably better‑established short‑term funds out there.  

> **Why I didn’t spend ages on star‑ratings, rolling returns, capture ratios, etc.?**  
> Because for debt funds those flashy numbers are often *noise*. The real story lives in the **credit quality, duration, and liquidity**.  

### Quick Cheat‑Sheet Before You Close This Chapter  

- **Goal‑first:** Debt funds are for capital preservation, not for hunting high returns.  
- **Ignore star‑ratings** – a high‑star fund usually means it’s chasing yield (more risk).  
- **Watch liquidity:** If AUM and the number of holdings are both shrinking, raise a flag.  
- **SEBI now forces fortnightly portfolio disclosures** – keep an eye on those updates.  
- **Diversify across AMCs:** Split your short‑term allocation between two different fund houses.  
- **Steer clear of pure “credit‑risk” funds** (they’re built to chase returns, not preserve capital).  
- **Beware of hidden related‑party exposure:** Some funds lend to two firms with the same promoter – that’s a double‑whammy if the promoter trips.  

> **Your homework:** Pick a debt fund with at least a **5–8‑year** history, download its factsheet, and run through the same checklist we just did.  

In upcoming chapters we’ll talk about **financial goals**, **building a balanced mutual‑fund portfolio**, and how to **match funds to those goals** like a perfect cocktail.  

---

## Key Takeaways from This Chapter  

- **Align fund choice with your financial goal** – don’t buy a great fund just because it looks good.  
- Debt mutual funds carry **credit risk, interest‑rate risk, and rating‑downgrade risk**.  
- **Invest for at least the fund’s average maturity** (e.g., ~2.5 years for a short‑term fund).  
- **Portfolio analysis is crucial** – look at number of securities, concentration, and sector mix.  
- **Higher corporate‑bond exposure → higher credit risk**; sovereign bonds are credit‑risk‑free but still feel interest‑rate moves.  
- **Watch out for large single‑issuer bets** – > 5 % exposure is a red flag.  
- **Yield‑to‑Maturity (YTM) is a proxy for risk**; higher YTM often means higher risk.  
- **Avoid extremes in AUM** – very small or very large debt funds can suffer liquidity problems.  
- **Liquidity risk matters** – shrinking AUM or a shrinking basket of bonds = warning signs.  
- **Diversify across AMCs** and stay alert to related‑party lending.  

Keep these nuggets in mind, run the checklist on any debt fund you eye, and you’ll be well‑armed to build a *sensible*, *goal‑driven* mutual‑fund portfolio without ending up with a confused mess. Cheers to smarter investing!  