# 21. Mutual Benchmarking  

**Source:** <https://zerodha.com/varsity/chapter/mutual-benchmarking/>

---  

## 21.1 – TER savings  

Okay, confession time – I should have dropped this nugget in the previous chapter, but somehow it slipped through the cracks (maybe because I was busy sipping chai and watching the markets). We’ve already chatted about TER, Direct vs. Regular plans, but we never actually showed you the cold, hard cash you *could* be saving by hopping on the Direct‑plan train. Before we dive head‑first into the wonderful world of mutual‑fund benchmarking, let’s take a quick detour and see the numbers. This is also my **final** pleading for you to ditch the regular plan and go Direct.  

### The DIY experiment  

1. **Pick a fund** – I grabbed **IDFC Core Equity Fund – Growth** (any fund will do, just pick your favorite).  
2. **Set the scene** – Assume you started a SIP on **1 Jan 2014** with a **₹10,000** monthly contribution.  
3. **Run it for five years** – So the SIP runs until **1 Jan 2020** (that's 73 months of disciplined investing).  

I fed these numbers into a trusty SIP calculator (the one on Moneycontrol – because why reinvent the wheel?). Here’s what popped out for the **regular** version of the fund:  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/09/Image-1_IDFC-Core.png)

#### What you’ll notice  

- **CAGR / XIRR:** **8.84 %**  
- **Total money put in:** **₹7,30,000** (₹10,000 × 73)  
- **Units accumulated:** **20,772.43**  
- **Current value after 73 months:** **₹9,52,000**  

Nothing spooky – just a nice, “average‑Joe” SIP performance.  

Now, let’s do the same thing **but with the Direct variant** – **IDFC Core Equity Fund – Direct – Growth**.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/09/Image-2_idfcd.png)

And for easy side‑by‑side comparison, I crunched the numbers into a tidy table:  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/09/Image-3_diff.png)

#### The showdown  

- **Units:** Direct gave you **19,982** units (slightly fewer than the regular plan).  
- **Why fewer?** Because the price per unit in the Direct scheme is higher – the fund doesn’t have to share a slice of the pie with a distributor.  
- **Value:** Direct = **₹9,99,527** vs. Regular = **₹9,52,000**.  

That’s a **₹47,527** gap – roughly **6.51 %** of the amount you originally put in.  

> **Where did that extra cash go in the regular plan?**  
> Straight to the distributor’s pocket for convincing you to start that ₹10k SIP five years ago.  

In the Direct world, there’s no middle‑man commission, so your money stays in the fund and compounds a bit faster. Look at the XIRR:  

- **Direct XIRR:** **10.47 %**  
- **Regular XIRR:** **8.84 %**  

That’s a **1.63 %** annual “tax” you’re paying to the distributor just for the privilege of buying through a broker.  

**Moral of the story:** Switch to Direct funds, save a decent chunk, and give your future self a high‑five. 😊  

---  

## 21.2 – Benchmarking and TRI  

Now that you’ve seen the TER magic, let’s talk about another buzzword that makes fund managers’ eyes sparkle: **Benchmarking**.  

### What’s a benchmark, anyway?  

Think of a **runner** named **X** who’s training for a 100‑meter dash. He wants not just to finish, but to **beat** his rival **Y** from the neighboring town.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/09/M11-C21-Mutual-Fund-Benchmarking-300x200.jpg)

During a practice run, X clocks **14.5 seconds**. Is that good? Only if you know Y’s time. Suppose Y runs it in **13 seconds** – well, X is clearly the slower hare.  

Why does this matter? Because we *benchmarked* X against Y. Without a reference point, X’s time is just a number. Benchmarking gives us a **yardstick**.  

### Translating to mutual funds  

Mutual funds do the same thing: they pick a **benchmark index** and promise to **beat it** (or at least not embarrass themselves).  

Take a look at this snapshot of **DSP Equity Opportunity Fund** – it’s pegged to the **Nifty 250 Index (TRI)**.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/09/Image-4_benchmark.png)

A **large‑cap** fund will usually benchmark against **Nifty 50**, while a **mid‑cap** or **multi‑cap** fund may use **Nifty 500** or **Nifty 250**. The idea is simple:  

| Outcome | What we call it |
|--------|-----------------|
| Fund returns > benchmark returns | **Outperforms** |
| Fund returns < benchmark returns | **Under‑performs** |

#### Example: Alpha in action  

- Fund’s 3‑year CAGR: **12 %**  
- Benchmark (Nifty 50) 3‑year CAGR: **10.5 %**  

The fund’s **Alpha** = **12 % – 10.5 % = 1.5 %**. That extra 1.5 % is the manager’s brag‑right.  

### TRI – Total Return Index  

You may have noticed the **TRI** tag on the benchmark. **TRI** = **Total Return Index**, which means it **includes dividends** in addition to price appreciation.  

When you own a stock, you get two possible cash flows:  

1. **Capital gains** (price goes up)  
2. **Dividends** (cash payout)  

Most index charts you glance at (e.g., the classic Nifty 50 line) only show **price appreciation**. They ignore the dividend drizzle that can be a substantial part of total return.  

The **TRI** version adds that dividend rain back into the picture, giving you a more honest view of what an investor actually earns.  

Here’s a visual comparison:  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/09/Image-5_tri.png)

- **Blue line:** Nifty 50 **TRI** (price + dividends)  
- **Red line:** Nifty 50 **price‑only**  

Over the same horizon, **TRI** delivered a whopping **942 %** total return, while the price‑only chart shows **738 %**.  

**Take‑aways**  

1. **TRI > Price‑only** – it always looks better because it counts dividends.  
2. Modern mutual funds now **benchmark against TRI**, not just price‑only.  
3. **Beating a TRI** is tougher than it sounds – you’re essentially trying to out‑run a marathoner who also gets a free energy drink every few miles. 😊  

That’s the groundwork for benchmarking. Let’s dig a little deeper.  

---  

## 21.3 – Weights matter  

Imagine two fund managers:  

- **Manager A** runs a **large‑cap** fund benchmarked to **Nifty 50 TRI**.  
- **Manager B** runs an **equity multi‑opportunity** fund benchmarked to **Nifty 500 TRI**.  

Which one has the harder job? Intuitively you might think **B** because **Nifty 500** covers 500 stocks, is more diversified, and should be less volatile.  

**Spoiler:** It’s actually **A** who has the tougher time. Here’s why.  

### A toy index: “High 5”  

Let’s create a fictional index called **High 5** – it contains the **top 5 stocks** from **five different sectors**.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/09/Image-6_index1.png)

Each stock gets a **weight** (percentage of the index). The index starts at **1000 points**; the “Base Split” column shows how that 1000 is allocated among the stocks.  

Now let’s fast‑forward a few days. Stock prices move, the index value changes, and we end up with this snapshot:  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/09/Image-7_index2.png)

The index has risen from **1000** to **1,081.72**, an **8.17 %** absolute return.  

### Same stocks, different weights  

What if we keep the **exact same stock prices**, but **re‑assign the weights**?  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/09/Image-8_index-3.png)

Notice:  

- **Biocon** jumps from **10 %** to **20 %**.  
- **Bajaj Auto** balloons from **18 %** to **40 %**.  

With the new weights, the index value slides down to **1,056.51**, delivering only **5.65 %** return – a **2.52 %** drop just because we tweaked the weightings.  

#### The lesson  

**Weighting matters more than the sheer number of constituents.**  

Even in a 500‑stock index, a handful of stocks can dominate the performance. In **Nifty 500**, the **top 10** hold **≈ 45 %** of the weight, the **top 25** about **65 %**, and the **top 50** roughly **85‑90 %**. The remaining **450** stocks are there “for the scenery.” 😊  

### Rolling returns – Nifty 50 TRI vs. Nifty 500 TRI  

Let’s look at the **10‑year rolling returns** (starting 2005) for both indices:  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/09/Image-10_rr10.png)

And the **5‑year rolling returns**:  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/09/Image-9_rr5.png)

Both charts are courtesy of my good buddy **Shyam** from **Stockviz**.  

What you see is a **remarkable similarity**. After a brief divergence from 2005‑2007, the two curves practically hug each other. The extra 450 stocks in Nifty 500 contribute **almost nothing** to the overall return profile.  

The same pattern holds for other broad indices like **Nifty 100** or **Nifty 250** – the **big‑ticket stocks** drive the show.  

### So, does the benchmark choice matter?  

**Short answer:** **Practically nothing.**  

**Long answer:**  

- If you’re a large‑cap investor, you’ll be looking at **Nifty 50 TRI** anyway, because that’s where most of the action lives.  
- If a fund is consistently lagging its chosen benchmark, that’s a red flag – not the benchmark itself.  

### What should *you* do?  

- **Set realistic expectations** based on the *type* of fund you own (large‑cap vs. small‑cap, etc.).  
- Use your own **personal return target** as a “private benchmark.” The AMC’s index is just a noisy background.  
- If a fund **persistently under‑performs** its benchmark, consider a **review** or even a **switch**.  

Your ability to **evaluate a fund against your own goals** is the true mark of an MF investor. In the next chapters we’ll shift gears: we’ll talk about **goal‑based investing**, **building a portfolio**, and **setting those realistic return expectations** you need to sleep well at night.  

Stay tuned – the best is yet to come!  

---  

### Key takeaways from this chapter  

- **Benchmarks** give you perspective; they’re the race‑track you compare your runner (fund) against.  
- Most funds now use **TRI (Total Return Index)** as their benchmark, which includes dividends.  
- **Dividends** matter – TRI returns are typically higher than price‑only returns.  
- The **weighting** of stocks in an index drives returns far more than the sheer count of stocks.  
- **Nifty 50 TRI** and **Nifty 500 TRI** produce almost identical return patterns.  
- As an investor, **set your own realistic return expectations** and treat those as your personal benchmark.  

Happy benchmarking, and may your returns always out‑run the market! 🚀