# 22. Mutual‑Fund Beta, Standard Deviation & Sharpe Ratio  

**Source:** <https://zerodha.com/varsity/chapter/mutual-fund-risk-metrics/>

---  

## 22.1 – Beta  

We’ve already chatted about a bunch of mutual‑fund attributes in the previous chapters. Now it’s time to put on our risk‑analyst hat (the one that looks cool on a cocktail napkin) and dive into the first of four classic risk gauges:

- **Beta**  
- **Alpha**  
- **Standard Deviation**  
- **Sharpe Ratio**  

Let’s start with **beta**—the “relative‑risk” number that every fund flyer loves to brag about.

![Beta illustration](https://zerodha.com/varsity/wp-content/uploads/2020/10/M11-C22-Mutual-Fund-Risk-Measures-300x200.jpg)

### What is beta, really?  

Beta is a single‑digit (or sometimes a negative digit) that tells you how *wiggly* a fund is compared with its benchmark.  
- **Beta > 1** → the fund jiggles more than the index.  
- **Beta = 1** → the fund jiggles exactly as much as the index.  
- **Beta < 1** → the fund is a bit of a couch potato compared with the index.  

I won’t re‑derive the regression formula here – that’s already covered in the Futures chapter (Section 11.5). If you’re itching for the math, go check it out: <https://zerodha.com/varsity/chapter/hedging-futures/>. For now, think of beta as a *relative‑risk* dial.

Below is a screenshot I nabbed from Value Research for the **Tata Multicap** fund (benchmark: **S&P BSE 500 TRI**).

![Beta snapshot](https://zerodha.com/varsity/wp-content/uploads/2020/10/Image-1_beta-300x90.png)

The fund’s beta is **0.95**. Here’s how to read that number:

| Beta range | What it means for the fund |
|------------|----------------------------|
| **< 1**    | The fund is *less* risky than its benchmark. In our case, a 1 % dip in the S&P BSE 500 would, on average, drag Tata Multicap down only **0.95 %**. |
| **= 1**    | The fund mirrors the benchmark’s risk. A 1 % move in the index equals a 1 % move in the fund. |
| **> 1**    | The fund is *more* volatile. A beta of **1.2** would mean a 1 % fall in the benchmark translates to a **1.2 %** fall in the fund (20 % extra wiggle). |

Notice the nuance: beta tells you **relative** risk, not the fund’s *absolute* risk. A Ferrari is faster than a BMW, but that doesn’t tell you how fast the Ferrari is in absolute terms. Same with beta – it’s a speed‑compare‑to‑something‑else, not a speedometer reading.

So, is a “high beta” automatically a bad thing? Not necessarily. Whether you love or loathe a high beta depends on the next metric: **Alpha**.  

---

## 22.2 – Alpha  

In the last chapter we tossed around a quick definition of alpha as “the extra return over the benchmark”. That’s a good start, but we need to sprinkle in beta and the **risk‑free rate** to get the full cocktail.

### Risk‑free rate 101  

Think of the risk‑free rate as the return you’d get by doing absolutely nothing risky. In practice we use:

1. **Savings‑account interest** (or a fixed deposit) – technically not 100 % risk‑free, but close enough for a backyard conversation.  
2. **Treasury bills** (T‑bills) issued by the Government of India – the gold standard because the sovereign backs them.

As of today, 10‑year Indian T‑bills are yielding roughly **3.75 %**. Let’s round that to a tidy **4 %** for our calculations.

![Risk‑free illustration](https://zerodha.com/varsity/wp-content/uploads/2020/10/Image-2_mkttrend-261x300.png)

### The alpha formula (with a dash of beta)

\[
\text{Alpha} = \bigl(\text{MF Return} - r_f \bigr) \;-\; \bigl(\text{Benchmark Return} - r_f \bigr) \times \beta
\]

In words:  

1. Subtract the risk‑free rate from the fund’s actual return.  
2. Do the same for the benchmark, then *multiply* by the fund’s beta (to adjust for how much market risk the fund actually took).  
3. The difference between step 1 and step 2 is the alpha.

### Example time – “nice” beta  

Suppose a fund delivered **10 %** over the last year, its benchmark was **7 %**, beta = **0.75**, and the risk‑free rate = **4 %**.

\[
\begin{aligned}
\text{Alpha} &= (10\% - 4\%) - (7\% - 4\%) \times 0.75\\
            &= 6\% - 2.25\%\\
            &= \mathbf{3.75\%}
\end{aligned}
\]

Notice the alpha (3.75 %) is *higher* than the naïve “benchmark‑difference” of 3 % because the fund achieved that out‑performance while being **less volatile** (beta = 0.75). The market rewards you for taking less risk.

### Example time – “wild” beta  

Keep the same returns (10 % fund, 7 % benchmark) but crank beta up to **1.3**.

\[
\begin{aligned}
\text{Alpha} &= (10\% - 4\%) - (7\% - 4\%) \times 1.3\\
            &= 6\% - 3.9\%\\
            &= \mathbf{2.1\%}
\end{aligned}
\]

Even though the raw returns didn’t change, the alpha *shrinks* because the fund was **more exposed** to market swings. The risk‑adjusted reward is lower, and the formula penalises that extra volatility.

#### Bottom line on alpha  

- Alpha measures **excess return after adjusting for market risk (beta) and the risk‑free rate**.  
- A high beta will *drag* alpha down; a low beta can *boost* alpha, all else equal.  
- Hence, volatility (beta) is a key player in performance attribution.

Now that you see why volatility matters, let’s talk about the metric that actually *measures* volatility: **Standard Deviation**.

---

## 22.3 – Standard Deviation (SD)  

I’ve already covered the nitty‑gritty of standard deviation in a dedicated chapter (see <https://zerodha.com/varsity/chapter/understanding-volatility-part-1/>). If you haven’t read that, feel free to skim it later; for now, here’s the cheat‑sheet:

- **Standard Deviation** = the annualised percentage that captures how wildly a fund’s returns bounce around its mean.  
- **Higher SD → Higher volatility → Higher risk** (and also higher upside potential).  

### Real‑world snapshot  

Below is a Value Research snapshot comparing two Axis funds:

![Axis funds snapshot](https://zerodha.com/varsity/wp-content/uploads/2020/10/Image-3_riskstats-300x72.png)

| Fund | SD |
|------|----|
| **Axis Small‑Cap** | **23.95 %** |
| **Axis Long‑Term Equity** | **19.33 %** |

The Small‑Cap fund’s SD is roughly **4.6 % points** higher, meaning its returns swing more dramatically.

#### What does that mean for a ₹10,000 investment?  

If you plunk ₹10,000 into each fund today, the *range* of possible year‑end values (ignoring any drift) looks like:

![Return range illustration](https://zerodha.com/varsity/wp-content/uploads/2020/10/Image-4_range-300x64.png)

- **Loss scenario**: Investment × (1 − SD)  
- **Gain scenario**: Investment × (1 + SD)

So the Small‑Cap fund could finish anywhere from **≈ ₹7,605** (10,000 × (1 − 0.2395)) up to **≈ ₹12,395** (10,000 × (1 + 0.2395)). The Long‑Term Equity fund’s range is tighter: roughly **₹8,067 – ₹11,933**.

### Takeaways on SD  

- **Mid‑ and small‑cap funds** typically sport higher SDs than large‑cap funds.  
- Volatility is **inherent** to equities; it’s not a bug, it’s a feature. If the roller‑coaster makes you queasy, maybe equities aren’t your jam.  
- **Two ways to tame volatility**:  
  1. **Smart diversification** (don’t throw every stock into one basket).  
  2. **Patience** – time smooths out the bumps. Think of it as letting a fine wine breathe.  

While you’re looking at the two Axis funds, notice:

- **Beta** for both is **< 1**, implying each is *less volatile than its benchmark*.  
- **Alpha** is positive for both, with the Small‑Cap fund’s alpha looking especially juicy—thanks to its lower beta and a low‑risk‑free environment.

Now that we’ve got beta, alpha, and SD under our belt, let’s bring in the grand unifier: the **Sharpe Ratio**.

---

## 22.4 – Sharpe Ratio  

The Sharpe Ratio is the **Swiss‑army‑knife** of risk‑adjusted performance. Invented by Nobel‑winning economist **William F. Sharpe** in 1966 (yes, the same Sharpe who gave us the CAPM), it bundles three ingredients into one tidy number:

\[
\text{Sharpe Ratio} = \frac{\text{Fund Return} - \text{Risk‑Free Return}}{\text{Standard Deviation}}
\]

### A quick showdown  

Imagine two large‑cap funds:

| Fund | Return | SD |
|------|--------|----|
| **A** | 14 % | 28 % |
| **B** | 16 % | 34 % |

Risk‑free rate (let’s keep it at **6 %** for illustration). Which fund looks better?

- **Fund A Sharpe**: \((14\%-6\%)/28\% = 0.29\)  
- **Fund B Sharpe**: \((16\%-6\%)/34\% = 0.29\)

Both give **0.29** – they’re equally attractive on a risk‑adjusted basis, even though B has a higher raw return.  

Now, if Fund B were *less* volatile, say **SD = 18 %**, its Sharpe would jump:

\[
\frac{16\%-6\%}{18\%}=0.56
\]

Now Fund B clearly dominates because it delivers more return per unit of risk.

#### Important footnote  

The Sharpe Ratio only looks at **price‑based risk** (i.e., volatility). It ignores **credit** and **interest‑rate** risk, so you shouldn’t use it for debt funds. For those, other metrics (like the **Sortino Ratio** or **capture ratios**) are more appropriate.

In the next chapter we’ll explore those finer‑pointed tools and then wrap up the whole “Mutual‑Fund‑Risk‑Parameters” saga before moving on to portfolio construction. Stay tuned – I’ll have the next post up faster than a high‑frequency trader can place an order! 😊  

---

### Key takeaways from this chapter  

- **Beta** = relative risk versus the benchmark.  
- **Higher beta → higher relative risk**, but **beta ≠ absolute risk**.  
- **Alpha** = excess return *after* adjusting for beta and the risk‑free rate.  
- **Higher beta drags alpha down** (and vice‑versa).  
- **Standard Deviation** measures *absolute* volatility; the larger it is, the bigger the swing in returns.  
- **Sharpe Ratio** tells you how many units of excess return you earn per unit of volatility. Higher is better.  

Keep these metrics in your mental toolbox, and you’ll be able to size up any mutual fund like a seasoned risk‑analyst who’s also great at happy‑hour conversation. Cheers!