# 15. Investing in Bonds  

**Source:** <https://zerodha.com/varsity/chapter/investing-in-bonds/>

---  

## 15.1 – Context  

Okay, so we kinda hinted at “hey, next up: index funds!” at the end of the last chapter. But before we sprint off to the land of low‑cost ETFs, let’s take a quick scenic detour and talk about buying bonds **directly**.  

Why the detour? Because we just finished a crash‑course on debt funds and all the jargon that comes with them. Debt funds are basically a mutual‑fund‑ish way of holding a basket of bonds and bills. If you’re comfortable letting a fund manager do the heavy lifting, great. If you’re the “I‑like‑to‑press‑the‑buttons‑myself” type, you can hop onto a platform and buy the actual bonds the manager would buy for you.  

> **Pro tip:** There are several online brokerages that let you buy bonds the same way you’d buy a share of T‑Series.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/05/M11-C15-Bonds-Web-300x200.jpg)  

Remember: a debt‑mutual‑fund is a **wrapper** around a bunch of bonds. Buying a bond outright means you become the “wrapper” yourself.  

---  

## 15.2 – Studying Bonds Before Investing in Them  

To keep things concrete, I grabbed *all* the publicly listed bonds of REC Limited (a classic PSU) straight from the NSE portal.  

Each bond issue carries its own **ISIN** – that’s the International Securities Identification Number, the bond’s global passport. Think of it as the bond’s unique social security number.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/05/ISIN-bonds.png)  

Click the little “+” next to any symbol and a tidy pop‑up of details appears. Below is a screenshot of one such bond.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/05/Bond-Investing.png)  

Two highlighted flags are the *must‑knows*:  

| Flag | What It Means | Why It Matters |
|------|---------------|----------------|
| **Tax‑free** | Interest earned is 100 % tax‑exempt (only the interest, not capital gains). | If you hold the bond to maturity you keep every rupee of coupon. Sell early at a profit? Capital gains tax applies. |
| **Credit Rating** | REC’s bond is **AAA** (triple‑A) by CRISIL. | AAA is the top‑tier rating – the issuer is considered rock‑solid. No need to lose sleep over default risk. |

Beyond those, you’ll see a smorgasbord of specs. Some are self‑explanatory, others need a little translation.  

### SEC – Secured Debt  
“SEC” tells you the bond is **secured**. Imagine a gold‑loan: you hand over a gold bar, the bank gives you cash, and if you default the bank keeps the gold. Secured debt works the same way – there’s collateral backing the loan, which makes it safer for the lender and helps explain why our REC bond enjoys that sparkling AAA rating.  

### Issue & Maturity Dates  
REC issued this paper in **2012** and it will mature in **2027** – a 15‑year ride.  

### Coupon Rate & Face Value  
- **Coupon rate:** 7.38 %  
- **Face value:** ₹1,000  

Why the face value matters:  

1. **Premium/Discount Check** – The bond’s current VWAP (volume‑weighted average price) is ₹1,083, meaning it’s trading **₹83 above** par.  
2. **Coupon Calculation** – 7.38 % of ₹1,000 = **₹73.80** per year per bond. Some bonds pay semi‑annual, quarterly, or even monthly coupons, but this one is once‑a‑year.  
3. **Redemption** – When the bond hits 2027, you’ll get back the face value (₹1,000) – unless you’re lucky and the issuer does a call.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/05/Screenshot-from-2025-07-16-18-45-22.png)  

Everything on the snapshot now makes sense—except the mysterious **YTM**.  

---  

## 15.3 – Yield to Maturity  

Yield‑to‑Maturity (YTM) is the *real* compass for bond investors. The coupon tells you what you’ll receive **if** you hold the bond forever, but YTM tells you the *effective* return **given the price you paid**.  

Let’s picture YTM with a real‑estate analogy (because everyone loves a good property story).  

### Scenario 1 – “Perfect Deal”  

- Property price: **₹3 crore**  
- You pay cash, rent comes in at **₹5 lakhs per month** (₹500,000).  
- After 12 months you sell the building for **₹3 crore** (price unchanged).  

**Calculations**  

| Item | Amount |
|------|--------|
| Purchase price | ₹3 crore |
| Sale price | ₹3 crore |
| P&L from price | 0 |
| Total rent (12 × ₹5 lakh) | ₹60 lakhs |
| Net profit | ₹60 lakhs |
| Net Yield = Net profit / Purchase price | **20 %** |

So the net yield equals the advertised **rental yield** (20 %).  

### Scenario 2 – “Over‑paid”  

- You over‑pay: **₹3.3 crore**  
- Same rent, same sale price (₹3 crore).  

**Calculations**  

| Item | Amount |
|------|--------|
| Purchase price | ₹3.3 crore |
| Sale price | ₹3 crore |
| P&L from price | **‑30 lakhs** |
| Total rent | ₹60 lakhs |
| Net profit | ₹30 lakhs |
| Net Yield = ₹30 lakhs / ₹3.3 crore | **≈ 9.09 %** |

Paying more upfront slashes your effective yield dramatically.  

### Scenario 3 – “Bargain Buy”  

- You snag it for **₹2.9 crore**  
- Same rent, same exit price (₹3 crore).  

**Calculations**  

| Item | Amount |
|------|--------|
| Purchase price | ₹2.9 crore |
| Sale price | ₹3 crore |
| P&L from price | **+10 lakhs** |
| Total rent | ₹60 lakhs |
| Net profit | ₹70 lakhs |
| Net Yield = ₹70 lakhs / ₹2.9 crore | **≈ 24.14 %** |

Buying cheap boosts your net yield way above the headline rental yield.  

#### TL;DR of the property exercise  

| Situation | Net Yield vs. Rental Yield |
|-----------|---------------------------|
| Same buy & sell price | Equal |
| Buy > sell price | Net < Rental |
| Buy < sell price | Net > Rental |

Now map that back to bonds:  

| Property term | Bond analogue |
|---------------|---------------|
| Purchase price | **Bond price** (what you actually pay) |
| Sale price | **Redemption price** (usually face value) |
| Rental yield | **Coupon rate** |
| Net yield | **Yield‑to‑Maturity (YTM)** |

Most bonds trade **above** face value, so YTM usually sits *below* the coupon. Why? Because you’re paying extra up‑front (₹1,083 vs. ₹1,000) but still only get ₹73.80 each year and ₹1,000 back at maturity. In our REC example that works out to an **effective return of ~5.5 %**.  

---  

## 15.4 – Accrued Interest  

Accrued interest is just the interest that has been earned **but not yet paid** since the last coupon date.  

- Coupon: 7.38 % of ₹1,000 = **₹73.80** per year.  
- Paid once a year on **19 Dec**.  

**Daily accrual**  

\[
\frac{₹73.80}{365} = ₹0.20219\ \text{per day}
\]

Let’s fast‑forward to **16 July 2025**. That’s **209 days** after the last coupon (19 Dec 2024).  

\[
209 \times ₹0.20219 = ₹42.26\ (\text{approx})
\]

So a buyer on 16 July owes the seller **₹42.26** in accrued interest. The quoted “settlement price” of **₹1,083** actually consists of:  

| Component | Amount |
|-----------|--------|
| Clean price (pure bond value) | ₹1,040.74 |
| Accrued interest | ₹42.26 |
| **Dirty price (settlement price)** | **₹1,083** |

Why the buyer pays the seller? Because the seller earned those 209 days of interest while holding the bond. When the next coupon drops on 19 Dec 2025, the new owner will receive the **full ₹73.80**, effectively recouping the interest they just paid the seller.  

**Bond‑speak cheat‑sheet**  

- **Dirty price** = Full price you see on the exchange (includes accrued interest).  
- **Clean price** = Price *minus* accrued interest (what the bond is “worth” on a pure‑principal basis).  

---  

## 15.5 – Should You Invest in Bonds?  

If you’ve been scrolling through Varsity, you know I’m a **100 % equities fanboy** (at least in spirit). I’ve repeatedly warned that putting every rupee into stocks is a recipe for a sleepless night during market tantrums. Diversification is the name of the game, but I kept postponing it—until COVID gave me a very loud *nudge*.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/05/Image-7_covid-300x192.png)  

In March 2020 the Nifty dropped **~40 % in a single month**. My SIPs that had been sailing smoothly for years went **negative** for the first time. Even the 2008 crash didn’t wipe out a 10‑year systematic investment plan so cleanly. (Here’s a chart from Value Research that proves the point.)  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/05/Image-8_sip-300x159.png)  

That shock was enough to finally open my eyes to asset‑allocation. If you haven’t built a diversified portfolio yet, now’s a good time to start.  

### Your new toolbox (post‑COVID, pre‑index‑fund)  

- **Direct equities** (stocks you pick yourself)  
- **Equity mutual funds** (actively or passively managed)  
- **Direct bonds** (the subject of this chapter)  
- **Debt mutual funds** (managed baskets of bonds)  
- **Sovereign Gold Bonds** (gold with a government backing)  
- **Bank Fixed Deposits** (the old‑school, interest‑only safe haven)  

Mix‑and‑match these to hit whatever risk‑return target you have—whether you’re saving for a house, a child’s education, or just trying to retire on a beach in Goa.  

In upcoming chapters I’ll walk you through concrete portfolio constructions and how to align them with your life goals. But first, we’ll swing back to the promised **Index Funds**.  

Stay tuned!  

---  

## Key Takeaways from This Chapter  

- **Tax‑free bonds**: The coupon interest is completely exempt from tax (capital gains are *not*).  
- **PSU debt** carries an implicit sovereign guarantee → **very low credit risk**.  
- **Coupon** = percentage of the **face value** (the amount you’ll get back at maturity).  
- **Yield‑to‑Maturity (YTM)** = the true, all‑in annualised return you’ll earn, considering price paid, coupons, and redemption value.  
- When you buy a bond, you also **pay accrued interest** to the seller (dirty price = clean price + accrued interest).  

Happy bond‑hunting, and may your yields be ever in your favour! 🍻  