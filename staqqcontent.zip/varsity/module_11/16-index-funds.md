# 16. Index Funds  

**Source:** <https://zerodha.com/varsity/chapter/introduction-to-index-funds/>  

---  

## 16.1 Overview  

In Chapters 6 & 7 we already dissected what a mutual fund actually is – basically a giant piggy‑bank where you toss in cash, someone else does the heavy lifting (buying, selling, re‑balancing) and you hope the pile grows. The real drama comes from **how** that someone (the fund manager) decides to play the market. Broadly, we can split the strategies into two camps:  

| Strategy | What they do |
|----------|--------------|
| **Active** | Try to *beat* a benchmark – they hunt for “alpha”, i.e. returns that sit on top of the market’s baseline. |
| **Passive** | Simply *match* the benchmark – they copy it like a karaoke singer hitting every note. |

### Benchmarks: the market’s report card  

Before we can talk about beating or matching anything, we need a reference point. That’s the **benchmark** – a publicly known index (Nifty 100, Nifty Midcap 150, S&P 500, etc.) that tells you how the market performed. Think of it as the “do‑nothing” scenario: “If I’d just bought the index and sat on it, what would I have earned?”  

Active managers try to out‑perform that number by picking stocks they like, deviating from the index, and applying a whole toolbox of strategies. A few classic ones:  

* **Value investing** – hunt for stocks cheaper than their “intrinsic” worth (like finding a discounted avocado at the grocery).  
* **Growth investing** – chase companies that are expanding faster than a teenager’s waistline and plough earnings back into the business.  

There are literally hundreds of nuanced approaches, but the core idea is the same: **beat the benchmark**.  

A **passive** or **index** fund, on the other hand, simply mirrors the chosen benchmark as tightly as possible. No fancy stock‑picking, no “I’ve got a hot tip”. The fund’s return = benchmark return – expenses.  

So, if you put money into a Nifty 50 index fund and Nifty 50 goes up **10 %** this year, you’ll get roughly **10 % – expense‑ratio**. Easy as pie (or, for the finance‑nerd, “as easy as a zero‑coupon bond”).  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/06/M16-Illustration-Jack-Bogle-twitter.png)  

---  

## 16.2 History  

Every good story needs a hero, a setback, and a “what‑if” moment. The hero here is **John C. “Jack” Bogle**, the man who gave us Vanguard and the first index fund in **1976**. He launched the **First Index Investment Fund**, which tracked the **S&P 500** (the 500 biggest U.S. companies, weighted by market cap – i.e., bigger companies get a bigger slice of the pie).  

### The spectacular flop  

Vanguard wanted to raise **$150 million** in the underwriting stage, but investors only forked over **$11.3 million**. That’s like planning a big pizza party for 150 guests and only 11 show up. Not enough cash to buy *every* share in the S&P 500, so Bogle did something clever: he **sampled** the index. He bought a representative basket of stocks that roughly mimicked the whole index, and the fund survived. Had he thrown in the towel, we might still be waiting for index funds to become mainstream.  

The fund was later renamed the **Vanguard 500 Index Fund**. It took **14 years** (1976 → 1990) to cross the **$1 billion** AUM threshold. Fast‑forward to today (the time the original chapter was written) and that same fund boasts **$500 billion** in assets, making it the world’s biggest mutual fund.  

> **Perspective:** The entire Indian mutual‑fund industry sits at roughly **$350 billion** in assets. One U.S. fund alone dwarfs the whole Indian market!  

Vanguard itself is now the **second‑largest asset‑management company** globally, with **$6 trillion** under management, behind only **BlackRock** (≈ $7 trillion).  

### The Indian chapter  

* **IDBI Principal** launched the first Indian index mutual fund, tracking the Nifty. It later morphed into the **Principal Nifty 100 Equal‑Weight Fund**.  
* **Benchmark AMC** introduced **Niftybees**, the first Nifty‑50 **ETF** (exchange‑traded fund). Benchmark later changed hands a few times (Goldman Sachs India → Reliance Mutual Fund → Nippon).  

Fast forward to the present: the **SBI Nifty 50 ETF** is the biggest mutual fund in India with **> ₹60,000 crore** AUM. Most of that money comes from the **Employees’ Provident Fund Organisation (EPFO)**, which started buying equities (via Nifty and Sensex ETFs) in **2015**.  

Even though the Indian market loves ETFs now, the **overall AUM for index mutual funds** was only about **₹8,800 crore** as of **April 2020** – a drop in the ocean compared with the **₹119,861 crore** sitting in active large‑cap funds.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/06/AUM.png)  

---  

## 16.3 Definition of an Index Fund  

The **active vs. passive** debate is the finance world’s version of “Cats vs. Dogs”. Everyone’s got an opinion, and it gets loud.  

When we say “index fund” today, we simply mean **any fund that tracks an index** – even if you invented an index of companies whose names start with “G” and built a fund around it.  

However, the *purists* (the finance‑professors who love footnotes) argue that a “true” index fund should follow a **broad, market‑cap‑weighted index** like the **Nifty 50** or **S&P 500**. Those indexes include a wide swath of the market and weight each company by its market capitalization, which keeps the fund truly representative of the whole market.  

---  

## 16.4 Do Index Funds Work?  

You might be thinking: “If a fund only gives me the market’s return, why not just buy the market directly? Why pay any fee at all?” Great question. Let’s break it down with a dash of humor.  

### The zero‑sum illusion  

Picture the market as a giant **pie‑eating contest**. For every slice someone wins, someone else loses a slice. That’s the **zero‑sum** nature of trading. If you sum up the performance of **all** active managers, they **cannot** collectively beat the market because the market itself is the benchmark.  

The drag on their performance? **Costs**.  

### Cost comparison – active vs. passive  

Active funds need a whole army: research analysts, star portfolio managers, Bloomberg terminals, fancy coffee for late‑night meetings, the works. All that expertise comes at a price, reflected in the **expense ratio**.  

| Category | Average expense ratio (direct plan) |
|----------|--------------------------------------|
| Active large‑cap mutual funds | **1.28 %** |
| Index (passive) funds | **0.31 %** |

*(Numbers from Moneycontrol, as quoted in the original chapter.)*  

That’s **≈ 1 %** difference. It might look tiny, but over long horizons it **compounds** into a massive chasm.  

#### Real‑world illustration  

Assume you invest a **₹10,000 SIP** for **20 years**.  

| Expense ratio | Final corpus (approx.) |
|---------------|------------------------|
| 0.6 % | ₹≈ 12.0 lakh |
| 1.6 % | ₹≈ 12.8 lakh |

That extra **₹0.8 lakh** is simply the cost of being an “active” fan.  

Now, picture an active fund charging **1.5 %** (benchmark = Nifty 50) versus a passive Nifty 50 fund charging **0.10 %**. Right off the bat, the active fund needs to **outperform the index by 1.4 %** just to break even.  

In contrast, the **SBI Nifty ETF** charges a **measly 0.07 %**. The reason? No star manager, no research department, just a robotic algorithm that says “Buy exactly what the index says”.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/06/uti.png)  
![Image](https://zerodha.com/varsity/wp-content/uploads/2020/06/nippon.png)  

---  

## 16.5 Historical Performance  

Numbers don’t lie (unless you’re looking at a shady chart). The **S&P Indices Versus Active (SPIVA®) scorecard** is the finance world’s version of “Who’s the Real MVP?” – it compares active fund returns against a standard benchmark over 1, 3, 5, and 10‑year horizons.  

### Indian active funds at a glance (as of end‑2019)  

* Over a **5‑year** window, **82 %** of active large‑cap funds **underperformed** the **S&P BSE 100** (the 100 biggest Indian companies).  

Mid‑ and small‑cap funds look a bit rosier, but the **SEBI recategorisation** has tightened the definition of what a fund can own, making outperformance **harder**.  

* **Mid‑cap**: previously we only had ETFs (often illiquid); now several AMCs have launched proper mid‑cap index funds.  
* **Small‑cap**: both active and passive versions are wildly volatile – they “shoot up like fireworks and crash like a cheap laptop battery”. Many investors end up **buying high, selling low**.  

---  

## 16.6 Bottomline  

Pick a random active fund and you’re basically playing a **coin toss** – odds are **worse than 50 %** that it will consistently beat the benchmark. In large‑caps the odds are *even* worse, and the gap will only widen as India’s market matures.  

Why?  

1. **Information parity** – All 40‑plus AMCs have essentially the same data.  
2. **Limited stock universe** – Everyone can only invest in the top 100 stocks; beating the index is like trying to run faster than a treadmill set at its max speed.  
3. **Cost disadvantage** – Active funds pay higher fees, so they need to *add* alpha *on top of* that drag.  

Add to that the phenomenon of **“closet indexing”** – many so‑called active funds merely hug the benchmark (they’re “active in name only”). After expenses, they **guarantee** underperformance.  

### The “paradox of skill”  

Michael Mauboussin summed it up nicely:  

> “When everyone has a similar level of skill, the *difference* in skill shrinks, and **luck** becomes the dominant factor.”  

In other words, today’s investors are **better educated, have better tools**, and therefore the *edge* that a star manager might have had back in the ‘80s is now **tiny**.  

---  

## 16.7 Fixed Income (Debt)  

So far we’ve been talking equity index funds. Over the past **5–10 years**, **bond ETFs** have exploded globally, with **$1 trillion** of assets in the U.S. alone.  

In India, however, debt‑indexing is still in its **infancy**. Apart from the newly launched **Bharat Bond ETF** and a few fund‑of‑fund structures, there’s essentially **no** Indian debt index fund.  

Why?  

* The Indian bond market is **tiny and illiquid**. Apart from government securities (G‑Secs) and a handful of AAA‑rated corporate bonds, most bonds trade *over‑the‑counter* (OTC), lacking transparent price discovery.  
* Even in the U.S., despite the bond market being larger than the equity market, **OTC trading dominates**.  

Because of these structural issues, building a **replicable, low‑cost bond index** is tough. Companies like **Tradeweb** are trying to bring electronic trading to the bond arena, so perhaps in a decade or two we’ll see Indian bond index funds on the menu.  

---  

## 16.8 Active or Passive (Conclusion)  

After chewing through all that, you might think you have to choose between **active** *or* **passive**. The reality is more nuanced: think **“active + passive”**. Build a portfolio that blends both, allocating based on your risk tolerance and investment horizon.  

A few golden rules:  

1. **Pick funds with a solid track record** and that **stick to their stated mandate**. After SEBI’s recategorisation, funds can’t wander into unrelated caps just to chase short‑term returns.  
2. **Beware of “cowboy” managers** – they love the spotlight but often leave investors with a mess.  
3. **Don’t forget ETFs** – they’re essentially index funds that trade like stocks. We’ll dive into those in the next chapter.  

Finally, you’ll encounter **smart‑beta** funds. The term sounds high‑tech, but they’re just **rules‑based, index‑like funds** that tilt toward certain factors (value, momentum, low‑volatility, etc.). We’ll give them a quick once‑over later.  

---  

*That’s a wrap on index funds – the lazy investor’s best friend, the market’s mirror, and, thanks to Jack Bogle, the ultimate proof that sometimes doing **less** really does **more**.*  