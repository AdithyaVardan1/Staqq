# 23. Sortino and the Capture Ratios  

**Source:** https://zerodha.com/varsity/chapter/sortino-and-the-capture-ratios/  

---  

## 23.1 – The Sortino’s Ratio  

Alright, grab a drink and settle in, because we’re about to meet two new kids on the mutual‑fund‑performance playground: the **Sortino Ratio** and the **Capture Ratios**. They’re not as scary as they sound—think of them as the Sharpe Ratio’s cooler, more nuanced cousins. We’ll keep this as a quick‑fire note, but we’ll still hit every point you need to walk away feeling like a “risk‑adjusted return” guru.  

### Quick refresher: Sharpe Ratio  

If you still have the Sharpe formula tucked away in your brain, give yourself a pat on the back:  

\[
\text{Sharpe Ratio}=\frac{\text{Fund Return} - \text{Risk‑Free Return}}{\text{Standard Deviation of the fund}}
\]  

The denominator—**standard deviation**—is the classic “how wobbly are the returns?” gauge.  

### What kind of wobble are we measuring?  

Standard deviation looks at **all** the wobble, whether the fund’s daily returns are dancing above the mean or slipping below it. In other words, it treats a big gain and a big loss as the same “risk.”  

Picture this: you have a series of daily NAV numbers for a mutual fund. We compute the daily return for each day, then take the average of those returns. In our example the average daily return is **0.108 %**.  

Now pick a random day—say **4 Aug 2020**—when the fund posted a **1.23 %** return. The **excess return** (actual minus average) is  

\[
1.23\% - 0.108\% = 1.122\% \approx 1.13\%
\]  

If the day had been a loss, the excess return would be negative. When you square those excess returns you get the **variance**, and the square‑root of variance gives you the standard deviation (the denominator of Sharpe).  

The key observation: **excess returns can be positive *or* negative**. The Sharpe Ratio therefore “punishes” the fund for **both** big wins and big losses, because they both inflate the denominator.  

### Enter the Sortino Ratio  

Do we really want to penalize a fund for a *good* day? Most investors would say “nope, only the bad days should hurt the score.” That’s where the **Sortino Ratio** steps in, swapping the generic standard deviation for **downside risk**—the volatility that comes *only* from negative excess returns.  

\[
\text{Sortino Ratio}= \frac{\text{Fund Return} - \text{Risk‑Free Return}}{\text{Downside Risk}}
\]  

*Downside risk* is computed exactly like standard deviation, **except** we ignore any positive excess returns before squaring. In plain English: we only care about how far the fund fell below its average, not how high it jumped above it.  

The rest of the formula stays the same, and the interpretation is identical—**higher is better**. The only difference is that the Sortino Ratio is a **cleaner** measure of reward per unit of *bad* risk.  

> **Bottom line:** The Sortino is Sharpe’s minimalist sibling that refuses to count your lucky streaks as “risk.”  

---

## 23.2 – Capture Ratios  

Capture ratios are my personal favorite because they cut straight to the chase: *how much of the market’s good (or bad) days does a fund actually capture?*  

### A college‑yard analogy  

Let me take you back to my first year of engineering. We were a ragtag squad of 8‑10 lads—cricket addicts, parking‑lot philosophers, and chronic procrastinators. Exams loomed like a dark cloud, but we spent most of our time perfecting the art of “strategic napping.”  

One guy in the crew was a bit of a ninja. He partied with us, hit the boundaries, and still managed to *study* when the exam week arrived. He didn’t ace every paper, but he *always* out‑performed the rest of us.  

Now picture that clever lad as a **mutual fund**, and the rest of the gang as the **benchmark index**.  

| Situation | Benchmark (the gang) | Fund (the clever lad) |
|-----------|----------------------|-----------------------|
| **Good times** (market up) | Gets happy, rallies | Rides the wave, captures most of the upside |
| **Bad times** (market down) | Trips, falls | Pulls the emergency brake, loses less than the gang |

When you distill that story into numbers, you get **capture ratios**. They tell you, over a defined period, how much of the *upside* and *downside* of the benchmark the fund actually “captured.”  

### Upside vs. Downside Capture  

- **Upside Capture Ratio** = (Fund’s return in up‑market periods) ÷ (Benchmark’s return in those same periods) × 100  
- **Downside Capture Ratio** = (Fund’s return in down‑market periods) ÷ (Benchmark’s return in those same periods) × 100  

If the fund makes **99 %** of the benchmark’s gains, its upside capture is **99**. If it suffers **119 %** of the benchmark’s losses, its downside capture is **119** (i.e., it *under‑performs* on the downside).  

### Real‑world example: HDFC Top 100 (Direct, Growth)  

![HDFC Capture Ratios](https://zerodha.com/varsity/wp-content/uploads/2020/10/Image-2_hdfc-300x58.png)  

- **Upside Capture = 99** → The fund grabbed 99 % of the index’s rally over the last three years.  
- **Downside Capture = 119** → When the index fell, the fund fell *more* than the index (119 % of the loss).  

The arithmetic is straightforward, but the insight is gold: the fund is a *near‑perfect follower on the upside* but a *bit too eager* on the downside.  

### What should an “ideal” capture ratio look like?  

| Desired trait | Target number |
|---------------|---------------|
| **Upside Capture** | **≥ 100 %** (the fund should at least match the benchmark’s gains) |
| **Downside Capture** | **≤ 100 %** (the fund should lose *less* than the benchmark) |

In practice, you rarely get both at the same time. Funds tend to be **either** aggressive chasers (high upside, high downside) **or** defensive caretakers (lower upside, low downside).  

#### The trade‑off in action  

**Parag Parikh Long‑Term Equity Fund** (3‑year snapshot)  

![Parag Parikh Capture Ratios](https://zerodha.com/varsity/wp-content/uploads/2020/10/Image-3_ppfas-300x61.png)  

- **Upside Capture**: modest (well below 100) – the fund didn’t ride the market’s highs aggressively.  
- **Downside Capture**: impressive (well under 100) – it protected investors when the market slipped.  

So the fund chose “safety first” over “chasing every bull run.”  

### How to use these ratios  

1. **Decide your style** – Do you want a fund that *goes all‑in* when the market is hot, or one that *holds the fort* when things get chilly?  
2. **Look for consistency** – A single year’s spectacular ratio could be a fluke. Check 3‑, 5‑, and 10‑year capture ratios; see if the fund repeats its behavior.  
3. **Compare peers** – If two funds both have downside capture ≈ 90, pick the one with the higher upside capture (or vice‑versa, depending on your appetite).  

**A personal anecdote:** I once chased a fund with a 130 upside capture but a 150 downside capture. It felt great during the bull market, but when the market turned, I was *down* more than my benchmark. Lesson learned: **consistency beats a one‑off fireworks display.**  

You can find these ratios on the **Morningstar India** portal (they’re not always shown elsewhere).  

---

### Wrapping up  

We’ve just added two more tools to your mutual‑fund‑analysis toolbox:

| Metric | What it tells you | Key nuance |
|--------|------------------|------------|
| **Sharpe Ratio** | Return per unit of *total* risk (both up & down) | Treats upside volatility as “risk.” |
| **Sortino Ratio** | Return per unit of *downside* risk only | Ignores upside volatility—focuses on the bad stuff. |
| **Upside Capture Ratio** | % of benchmark’s gains captured | Higher is better (≥ 100 % ideal). |
| **Downside Capture Ratio** | % of benchmark’s losses captured | Lower is better (≤ 100 % ideal). |

Remember: **higher Sortino → better reward for the bad days**, **high upside capture + low downside capture → the holy grail**, but in reality you’ll pick the combination that matches your risk appetite.  

Next up we’ll dive into a full‑blown **mutual‑fund analysis framework** and learn how to stitch these metrics together into a portfolio that meets your life goals. Stay tuned, and keep those calculators handy!  

---

### Key takeaways from this chapter  

- **Sharpe ratio** measures return per unit of *total* risk (both positive and negative volatility).  
- **Sortino ratio** refines Sharpe by using **downside risk only**, so only bad volatility drags the denominator down.  
- **Upside capture ratio** tells you how much of the benchmark’s *positive* moves the fund captured.  
- **Downside capture ratio** tells you how much of the benchmark’s *negative* moves the fund captured (lower is better).  
- Look for **consistency** across multiple horizons (3, 5, 10 years) rather than a single‑year flash.  

Happy measuring, and may your funds always capture more upside than downside! 🚀📈  