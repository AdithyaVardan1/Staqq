# 10. Equity Scheme (Part 2)

**Source:** <https://zerodha.com/varsity/chapter/equity-scheme-part-2/>

---  

## 10.1 – Multicap Funds  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/02/M11-C10-Illustration-4-300x200.jpg)

In the previous chapter we kicked the tires of the equity scheme and its many cousins. Now we’re moving on to the **multicap** family – the free‑spirited wanderers of the mutual‑fund world.  

As the name suggests, a multicap fund isn’t chained to a single market‑cap bucket. The portfolio manager can wander from towering large‑caps like HDFC Bank to teeny‑weeny small‑caps such as UFO Moviez, picking whatever looks like a tasty bite. The only hard‑and‑fast rule is that **at least 65 % of the assets must be in equity or equity‑like instruments**.  

Take a peek at the **SBI Multicap Fund** portfolio:  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/02/Image-1_port.png)

You’ll see a mix that stretches from the heavyweight champ HDFC Bank to the scrappy underdog UFO Moviez. The exact weight of each name is the fund manager’s call – think of it as a chef sprinkling a pinch of this and a dash of that.  

The **capitalisation mix** (how much is large‑cap, how much is mid‑cap, how much is small‑cap) also varies fund‑to‑fund. For SBI’s multicap, the breakdown looks like this:  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/02/Image-2_port-mix.png)

Because a multicap fund spreads its bets across the whole market, AMCs (Asset‑Management Companies) usually benchmark it against broad indices like the **S&P BSE 500** or **Nifty 500** – essentially the “top‑500‑of‑everything” club.

### Return expectations  

Since the fund can tap into the high‑growth corners of small‑caps *and* the stability of large‑caps, the **expected returns sit on the higher side** – but so does the risk. The ten‑year return chart tells the tale:  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/02/Image-3_multicap.png)

On average these funds churn out **≈10‑11 %** per annum. The worst performer in the sample gave **7.36 %**, while the champion hit **≈16 %**.  

### “What happens when the fund gets big?”  

Think of an AMC as a magnet for money. When a multicap fund gathers a mountain of assets, it has to **deploy** that cash into actual stocks. In India, the small‑cap arena isn’t exactly a liquid pool – you can’t dump a tonne of money there without causing a splash.  

Consequently, a bloated multicap fund ends up **leaning heavily on large‑ and mid‑caps**. That’s why the SBI Multicap Fund (about **₹8,500 crore** AUM) has **≈70 %** of its holdings in large‑cap names.  

### What to watch out for  

The biggest elephant in the room is **fund‑manager risk**. Because the manager can wander anywhere, the fund’s fortunes hinge on his/her stock‑picking acumen and the proportion of each cap segment.  

> **Pro‑tip for newbies:** If you’re staring at the mutual‑fund menu and feel lost, start with a multicap fund. It’s like walking into an all‑you‑can‑eat buffet – you get a taste of everything without having to commit to a single cuisine.

---

## 10.2 – Focused Funds  

We’ve already trekked through a few equity categories, and you’ve probably leafed through a couple of fact‑sheets. One thing that jumps out is the **number of holdings**. A typical equity mutual fund carries **60‑70 stocks** – the “spread‑your‑eggs‑widely” philosophy.  

The textbook says: *more stocks = less risk (and usually, lower returns)*.  

Enter **focused funds** – the minimalist artists of the fund universe. As the moniker hints, they **cap the portfolio at 30 stocks** (sometimes even fewer). The idea is to concentrate on **high‑conviction bets** after a deep‑dive due‑diligence process. Think of it as a chef who only serves his/her signature dishes, rather than a spread of 20‑item appetizers.  

The average focused fund holds **≈25 stocks**. A notable outlier is **JM Financial’s “Core 11” fund**, which holds **exactly 11 stocks**:  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/02/image-5_core.png)

### Risk‑return profile  

With a smaller roster, the **risk‑return curve tilts upward** – you can reap bigger gains, but you also expose yourself to sharper swings. The ten‑year return ladder looks like this:  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/02/Image-4_focused.png)

The bottom line is **7.25 %** on the low‑end, and **≈16.75 %** on the high‑end. Those numbers illustrate the higher‑risk, higher‑reward nature of a focused fund.  

I like to think of a focused fund as a **budget‑friendly Portfolio Management Service (PMS)**. You get the same high‑conviction play‑book without the PMS price tag or the astronomical entry barrier.  

### Who should (or shouldn’t) bite?  

Focused funds aren’t the best starter kit for a green‑horn investor. The volatility can be a **real gut‑punch** if you’re not used to market‑linked roller‑coasters. Jumping straight into a focused fund without a cushion of diversified exposure could make you swear off mutual funds forever.  

Treat a focused fund as a **spice‑rack addition** to an already‑well‑balanced portfolio – bring it in once you’ve built a solid base and can handle a few extra heat notes.

---

## 10.3 – Dividend‑Yield Funds  

If you see “dividend‑yield” on a fund’s banner, you might picture a **monthly dividend check landing in your mailbox**. Spoiler alert: **Most dividend‑yield funds don’t guarantee any payout to investors**.  

So why the name? It’s simply a **descriptor of the fund’s investment strategy**: they buy stocks that historically hand out *high* dividends. The fund itself may retain those cash flows to reinvest, which can still boost your NAV.  

**Dividend yield** is calculated as:  

\[
\text{Dividend Yield} = \frac{\text{Annual Dividend per Share}}{\text{Current Share Price}}
\]

*Example:* Infosys trades at **₹780** and pays **₹22** dividend per share annually.  

\[
\frac{22}{780} \approx 2.8\%
\]

### SEBI’s definition  

SEBI (the Indian securities watchdog) says a dividend‑yield fund must invest **≥65 % of its assets in dividend‑paying stocks**. The remaining **35 %** can go anywhere – possibly non‑dividend stocks, bonds, etc.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/02/Image-6_dy.png)

Two practical take‑aways:

1. **65 % rule** – at least two‑thirds of the corpus must be in dividend‑paying equities.  
2. **What counts as “high dividend” is fuzzy**. One manager may deem anything above **0.75 %** as high, another may benchmark against the index’s average yield. This lack of a universal cut‑off can lead to **inconsistent stock selection**.  

#### Real‑world example  

The **UTI Dividend Yield Fund** benchmarks itself against the **Nifty Dividend Opportunity 50** index. Its holdings are a roster of **well‑established, consistent dividend payers**:  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/02/Image-9_port.png)

### Ten‑year performance  

Here’s a quick snapshot of how dividend‑yield funds have fared over the last decade:  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/02/Image-7_divret.png)

The returns are **fairly tight** across the category, hovering around the same ballpark as other equity funds.  

> **Personal take:** I’m more of a “growth‑stock‑hungry” person, so I tend to sidestep pure dividend‑yield funds. But if you need a modest, steady‑income flavor in your portfolio, they can fit nicely – just remember they’re *not* a guaranteed dividend machine.

---

## 10.4 – ELSS Funds  

*(Yes, the numbering slipped – we’ll keep it as‑is to stay faithful to the original.)*  

**ELSS** = **Equity‑Linked Savings Scheme**. These are the **tax‑saving superheroes** of the mutual‑fund world, giving you a **Section 80C** deduction on your Indian income‑tax return.  

### Section 80C in a nutshell  

- You can claim a deduction of **up to ₹1,50,000** per financial year for certain investments, including ELSS.  
- Example: Gross income = **₹12,00,000**. If you invest the full **₹1,50,000** in an ELSS, your *taxable* income drops to **₹10,50,000**.  

ELSS is just one of the many 80C options – others include **Life Insurance, PPF, 5‑year Fixed Deposits, Sukanya Samriddhi Yojana**, etc. How you split that ₹1.5 Lakh depends on your overall financial‑planning game plan.  

### SEBI’s ELSS definition  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/02/Image-10_elss.png)

Two crucial points:

1. **Lock‑in period:** **3 years** – the government’s gentle nudge to make you think long‑term.  
2. **Equity exposure:** **≥80 %** must be in equities/equity‑related instruments, with **no cap on market‑cap**.  

### Multi‑cap or large‑cap?  

A common myth is that **ELSS = large‑cap fund**. In reality, many ELSS schemes behave more like **multicap funds**. A quick glance at the top‑40 ELSS funds shows:

- **23 funds** have **<70 %** in large‑cap stocks.  
- **17 funds** have **≥70 %** in large‑cap stocks.  

For instance, the **IDFC Tax Advantage Fund** spreads its equity across large, mid and small caps, making it a textbook **multicap** ELSS.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/02/Image-11_elssplit.png)

**Takeaway:** Don’t double‑dip. If you already own a large‑cap fund, adding an ELSS that is 83 % large‑cap (like **HDFC Tax Saver**) may give you redundant exposure.  

### Ten‑year ELSS returns  

Here’s the performance of some of the biggest ELSS players over the last decade:  

![Image](https://zerodha.com/varsity/wp-content/uploads/2020/02/Image-12_ELSS-performance.png)

Average returns sit around **11‑12 %**, pretty much in line with the broader multicap universe.  

---

## Wrapping Up  

We’ve just sprinted through the last two chapters of the equity‑mutual‑fund saga. Up next we’ll dive into **debt funds**, explore their many flavors, and then unpack **how to pick the right mutual fund** and **build a balanced portfolio**. Stay tuned – the adventure continues! 🙂

### The key takeaway from this chapter  

- **Multicap funds**: No cap‑size restrictions; the manager roams across large, mid, and small caps.  
- **Risk alert**: “Fund‑manager risk” is the main thing to monitor for multicap funds.  
- **Focused funds**: ≤30 stocks, high‑conviction bets – think of it as a concentrated espresso shot.  
- **Risk‑return**: Focused funds swing wider (higher upside, higher downside) than broad equity funds.  
- **Dividend‑yield funds**: The name reflects the *investment strategy*, not a promise of regular payouts to you.  
- **Dividend‑yield funds**: They chase stocks with high dividend yields, but “high” is loosely defined.  
- **ELSS funds**: Tax‑saving (Section 80C) mutual funds with a **3‑year lock‑in**.  
- **ELSS limit**: Up to **₹1,50,000** can be claimed as a deduction per FY.  
- **ELSS ≈ multicap**: Most ELSS schemes have a mix of caps, making them more multicap‑ish than pure large‑cap.  

Enjoy the ride, keep asking questions, and remember – the best portfolio is the one that lets you sleep at night (and maybe still have enough cash for that extra slice of pizza). 🍕🚀