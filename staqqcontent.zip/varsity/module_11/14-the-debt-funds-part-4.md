# 14. The Debt Funds (Part 4)

**Source:** https://zerodha.com/varsity/chapter/the-debt-funds-part-4/  

---  

## 14.1 – Liquidity Risk  

In the last chapter we lived through the **Franklin debt‑fund drama** – a real‑life thriller that proved, once and for all, that you can’t pick a debt fund the way you pick a Netflix series (i.e. “based on past returns” or “current ranking”). The market has repeatedly reminded us that those shiny numbers are about as useful as a chocolate teapot when it comes to picking a debt fund.  

The only sensible way to pick a debt fund is to **look at the risk metrics**. If you can’t name the risks that come with a debt fund, you should stay out of the debt‑fund arena altogether – the same rule that applies to equity funds. The disclaimer “mutual funds are subject to market risk” has made most investors associate market risk *only* with equities. That’s why many think debt funds are “risk‑free”. Spoiler alert: they are not.

If you’ve breezed through the earlier chapters, you already know that debt funds carry **default risk, credit risk, and interest‑rate risk**. The Franklin fiasco added a new, lurking menace to the list: **Liquidity Risk**.

![Liquidity Risk](https://zerodha.com/varsity/wp-content/uploads/2020/05/M11-C14-Debt-Funds-Liquidity-Risk-WEB-1-300x200.jpg)

We’ll start with a quick dive into liquidity risk, then move on to the other sub‑categories of debt funds.

### What does liquidity risk mean for a debt fund?  

Two sides of the same coin:

1. **Market‑level illiquidity** – The underlying bond market (Indian bonds) may be thin, so the fund can’t sell its holdings quickly.  
2. **AMC‑level cash crunch** – The Asset Management Company (AMC) may run out of cash to meet redemption requests.  

Both are intertwined. If the bond market is illiquid, the AMC can’t turn its paper into cash at will, so the money is effectively “locked‑in”.  

An AMC’s core job is simple:  
*Collect money → Invest it → Generate returns → Return cash when investors ask for it.*  

To honour redemptions, the AMC must keep a **cash buffer** in each scheme. If a wave of investors decides to pull out at once, the AMC needs enough cash on hand.  

Now picture this: the AMC has a portfolio of bonds it **can’t sell on demand** (market illiquidity) **and** it must hold a cash cushion to meet redemptions. If redemption pressure spikes, the cash buffer can evaporate fast, creating a classic liquidity crunch.

That’s exactly what happened to **Franklin India**. Under normal circumstances, AMCs keep enough cash because redemptions are a daily routine. But when redemptions surge, they need *extra* cash. Where does it come from?  

> **Hint:** They borrow.

SEBI allows an AMC to borrow **up to 20 % of its Net Asset Value (AUM)**. The rule (read the full SEBI direction [here](https://www.sebi.gov.in)) is summarised below:

![Borrowing limit](https://zerodha.com/varsity/wp-content/uploads/2020/05/Image-1_guidelines-300x55.png)

If an AMC is tapping this 20 % lever, it’s a red flag that its usual cash pile is thinning and it needs external money to honour redemptions.

### How to spot borrowing in the wild?  

Every month an AMC files a **portfolio declaration**. Look at the **cash component**:

| Cash component | Interpretation |
|----------------|----------------|
| Positive       | No borrowing (cash surplus) |
| Negative       | Borrowing (cash deficit) |

Take a look at the snapshots from Franklin’s **Ultra‑Short‑Term Fund**:

- **January 2020**  

  ![Jan‑2020 portfolio](https://zerodha.com/varsity/wp-content/uploads/2020/05/Image-2_Jan-300x81.png)

- **February 2020**  

  ![Feb‑2020 portfolio](https://zerodha.com/varsity/wp-content/uploads/2020/05/Image-3_Feb-300x73.png)

- **March 2020**  

  ![Mar‑2020 portfolio](https://zerodha.com/varsity/wp-content/uploads/2020/05/Image-4_Mar-300x42.png)

Notice the **cash line turns negative in March 2020** – that’s the moment Franklin started borrowing, a clear early warning of liquidity stress. The fund (and five sister funds) was eventually shut down on **23 April 2020**.

#### A couple of cautionary notes  

- **Don’t panic at the first negative cash**. A negative cash line alone isn’t a death sentence; you need to connect the dots.  
- **It’s a lagging indicator** – the portfolio data is published with a delay, but it still gives you a useful glimpse of trouble.

If you’re a “DIY” investor, make it a habit to scan these monthly tables. The real skill is *connecting the dots* to anticipate trouble before it erupts.

What would the dot‑connecting look like for Franklin? In hindsight, the warning signs were:

1. **Vodafone‑Franklin episode** – the first crack.  
2. **Heavy exposure to sub‑AA+ papers** – a risky cocktail.  
3. **Cash falling, borrowings rising** – the classic liquidity squeeze.  
4. **COVID‑19 market panic** – a systemic shock.  
5. **Negative street sentiment** – everyone was nervous.  

When you line those up, you see a storm brewing. For a seasoned analyst the “gut feeling” will eventually kick in; for a retail investor, systematic dot‑connecting is the best defence.

We’ll revisit these risk‑checking tools later when we talk about **how to pick mutual funds**. For now, let’s move on to the three main families of debt funds: **Banking & PSU Debt Funds, Credit‑Risk Funds, and Gilts**.

---

## 14.2 – Banking and PSU Debt Fund  

If you asked me to stop after the medium‑duration funds, I’d probably say, “Why bother? The rest are for the brave‑heart retail investor.” But a good friend (or a responsible educator) can’t leave you in the dark, so let’s unpack the **Banking & PSU Debt Fund**.

### What does the name actually mean?  

Most of us instinctively think: “Banking & PSU Debt Fund = a fund that only buys bonds issued by banks and Public‑Sector Undertakings.” That feels safe, right? Banks and PSUs are the *rock‑solid* part of the Indian economy.

Let’s see what the regulator actually wrote:

![SEBI definition](https://zerodha.com/varsity/wp-content/uploads/2020/05/Banking_and_PSU_Fund.png)

Surprise! The rule says **80 %** of the assets **must** be in banking & PSU debt, **and the remaining 20 % can be anything**.  

So you’ve got an **80‑20 cocktail**. The cocktail problem is that a casual investor reading the title will assume 100 % safety, while the fund manager is free to slip in private‑sector bonds (or any other instrument) in that 20 % slice.

If a default happens in that 20 % bucket, the NAV gets hammered. Who’s to blame?  

- The investor for assuming a pure‑play fund?  
- The manager for a sloppy allocation?  
- SEBI for allowing the cocktail?  

Take a peek at **IDFC AMC’s Banking & PSU Debt Fund** portfolio:

![IDFC portfolio](https://zerodha.com/varsity/wp-content/uploads/2020/05/Image-6_port-300x286.png)

You’ll see **Reliance Industries** making up **1.27 %** of the assets. Reliance isn’t a “dangerous” name, but it certainly isn’t a bank or a PSU. Does it belong here? Technically, yes – it lives in that 20 % free‑float bucket.

#### Why the 80 % part still feels relatively safe  

Two reasons keep the credit risk modest for the bulk of the fund:

1. **RBI’s liquidity backstop** for banks and NBFCs.  
2. **Implicit sovereign guarantee** for PSUs – the Government essentially says “We’ll bail you out”.

But remember: **the comfort only covers 80 %**. The remaining 20 % can bring in higher credit risk.

#### Duration – the hidden wildcard  

SEBI does **not** prescribe a **Macaulay duration** for these funds, so the manager can wander into longer‑dated bonds. Consequently, the **modified duration** tends to be on the higher side.

Here’s a snapshot of IDFC’s parameters:

![IDFC parameters](https://zerodha.com/varsity/wp-content/uploads/2020/05/Image-7_parameters-300x22.png)

- **Average (Macaulay) duration ≈ 3.1 years** – similar to a mid‑duration fund.  
- **Modified duration ≈ 2.6 years** – on the higher side for a debt fund.  

What does that mean for you? If interest rates rise, the fund’s NAV will dip and may take a while to recover.  

**Bottom line:** Treat these funds as a **3‑5‑year investment horizon**. Anything shorter, and you might get jolted by rate swings.

> **Side note:** Up to this point we’ve only introduced fund types. We haven’t yet explained **how** or **why** you’d pick any of them. Later in this module we’ll answer two big questions:  
> 1. *How to analyze a mutual fund?*  
> 2. *How to build a well‑balanced MF portfolio?*  

When we get there, all these pieces will click into place.

---

## 14.3 – Credit Risk Funds  

Before **October 2017**, the category was called **“Credit Opportunities Fund”**. The name change to **“Credit Risk Fund”** is subtle but profound – it flips the narrative from “Here’s a juicy opportunity!” to “Here’s a vehicle packed with risk”.  

### SEBI’s definition (the fine print)  

![SEBI definition](https://zerodha.com/varsity/wp-content/uploads/2020/05/Credit_Risk_Fund.png)

And that little **circumflex** you see next to the name?

![Circumflex](https://zerodha.com/varsity/wp-content/uploads/2020/05/Image-9_circumflex-300x36.png)

It simply reminds you that **65 %** of the assets must be in **AA\***‑and‑below corporate bonds** (i.e., below investment grade). The remaining 35 % is a free‑for‑all.

#### What does “AA\* and below” mean in plain English?  

- **High credit risk** – the issuers have a sizable chance of default or a rating downgrade.  
- **No caps** on the other 35 % – the manager can go wild.

Think of a credit‑risk fund as a **buffet‑line kid** who piles everything on his plate, ignoring the “no‑pork” sign. The fund manager loads the portfolio with the *spiciest* bonds to chase the *juiciest* yields.

### Why would anyone lend to a shaky borrower?  

Because **shaky borrowers throw higher coupons**. If a corporation is on the edge, it has to **pay more** to attract lenders. The fund manager hopes:

1. The company **pays interest on time** (so you get the coupon).  
2. The company **improves its creditworthiness**, leading to a rating upgrade.  
3. The bond **price rises** after a rating upgrade, boosting the fund’s NAV.

If all three happen, the manager enjoys **high interest income + capital appreciation**.  

### A real‑world example – DSP’s Credit Risk Fund  

![DSP Credit Risk portfolio](https://zerodha.com/varsity/wp-content/uploads/2020/05/Image-10_dsp-300x184.png)

Look at that **~30 % concentration in a single issuer**. If that company defaults, the fund’s NAV would take a massive hit. Combine that concentration with **sub‑par credit ratings**, and you have a recipe for volatility.

#### Bottom line for the retail investor  

- Credit‑risk funds are **hard to understand** and **hard to tolerate**.  
- **You don’t need them** to meet typical retail goals (emergency fund, retirement, short‑term targets).  
- **Avoid** them unless you have a strong appetite for high‑yield, high‑risk play.

---

## 14.4 – GILT Funds  

Picture the early 1800s: governments needed cash, so they printed **physical bonds** with **gold‑lined edges**. Those were called **“gilt‑edged bonds”** because of the golden trim.  

Fast forward to today – there’s no gold on the edges, but the **sovereign guarantee** remains. Government bonds (aka **Gilts**) are still considered virtually **default‑free** because a sovereign simply *can’t* (or at least, won’t) walk away from its debt.

### SEBI’s definition of a Gilt Fund  

![SEBI Gilt definition](https://zerodha.com/varsity/wp-content/uploads/2020/05/Image-11_Gilt-300x69.png)

Two flavors exist:

| Type | Minimum Govt‑bond allocation | Other rules |
|------|------------------------------|-------------|
| **Gilt Fund** | ≥ 80 % in government securities | The remaining 20 % can be anything (hello, cocktail again). |
| **Gilt with 10‑yr constant duration** | Same 80 % rule **plus** a **Macaulay duration ≥ 10 years** | Locks the fund into a long‑duration profile. |

#### Credit risk vs. interest‑rate risk  

- **Credit risk ≈ 0** (the Government is assumed not to default).  
- **Interest‑rate risk** can be *massive*, especially for the 10‑year‑duration version. When rates climb, the NAV can tumble sharply and take years to bounce back.

**Tip:** Always peek at the **duration** and **modified duration** on the fact sheet. The higher they are, the more rate‑sensitive the fund.

#### Who should sip a Gilt fund?  

Only investors with a **long‑term horizon** (think **8‑10 years**) should consider them. For most retail portfolios, a Gilt fund adds little value and can be safely omitted.

---

## Key takeaways from this chapter  

- **Liquidity risk** is a hidden danger in debt funds; monitor it closely.  
- **Negative cash** in an AMC’s monthly portfolio hints at **borrowings** and possible liquidity stress.  
- **Banking & PSU Debt Funds** allocate **80 %** to “safe” bank/PSU bonds, but the remaining **20 %** can be anything, so treat the fund with a bit of caution.  
- The **credit‑risk comfort** only applies to that 80 % slice; the rest can inject higher credit risk.  
- **Credit‑Risk Funds** are packed with sub‑investment‑grade bonds, high concentration, and are generally unsuitable for the average retail investor.  
- **Gilt Funds** have virtually no credit risk but can be very sensitive to interest‑rate movements; they demand a **long‑term** (8‑10 yr) outlook.  

Stay vigilant, keep an eye on the cash line, and remember: **risk isn’t a one‑size‑fits‑all label**—it’s a collection of quirks you need to understand before you pour your money in. Cheers to smarter (and slightly more entertaining) debt‑fund investing!