# 31. Personal finance review (Part 1)

**Source:** https://zerodha.com/varsity/chapter/personal-finance-review-part-1/

---  

## 31.1 – Overview  

It’s a brand‑new calendar year, which in finance‑land means it’s officially **“time to stare at your bank statements and pretend you’re a grown‑up.”**  
Most of the advice you’ll find online is all about “how to invest like a guru,” and that really grinds my gears. People keep shouting “invest!” while forgetting there’s a **personal** before the **finance**—and the personal part is the one that decides whether you’ll be sipping margaritas on a beach or eating instant noodles on a couch.

A one‑size‑fits‑all plan is about as useful as a size‑8 shoe for a giant. If you don’t factor in your own life‑situation (job, family, Netflix subscription, pet hamster) you’ll end up with a blueprint that looks great on paper but collapses the moment reality shows up.  

In this post I’ll walk you through the **must‑do** pieces of a personal‑finance health‑check. I can’t promise to cover every weird corner case (like the time you invested in a pet‑rock startup), but I’ll make sure you have a solid foundation.  

Who’s this for?  
- Anyone who’s still earning a paycheck (or a freelance gig) and wants to get their money‑life in order, whether you’ve just opened your first demat account or you’re still figuring out how to write a cheque.  
- Retirees have a different set of questions – think of that as **Part 2** (coming soon, stay tuned!).  

---

## 31.2 – Don’t be scared  

Money is the ultimate “choose‑your‑own‑adventure” where the map is scribbled in invisible ink. Our brains are wired to **hate uncertainty**.  

A classic psychology study found that *not knowing what will happen* makes people sweat more than being told, “Hey, you’ll definitely lose $1,000.”  It’s called **ambiguity aversion**. And then there’s **loss aversion**—the fact that a $100 loss feels about twice as painful as a $100 gain feels good.  

Why does this matter? Because losing cash lights up the same brain regions that process physical pain. In other words, **watching your portfolio dip is basically a punch to the gut** (or the funny‑bone, depending on how dramatic you are).  

When you sit down to review your finances you’ll be making choices whose results you won’t fully see for years—maybe even decades. Your brain will try to protect you by whispering, “Just leave it alone, buddy.” That’s **not** a sign you should throw in the towel; it’s just your inner neuro‑pessimist trying to keep you comfy.  

### For new investors  

A lot of newbies never even open a spreadsheet because the inner monologue goes:  

- “What if I mess up?”  
- “Will I lose money?”  
- “This looks like a PhD in rocket science.”  

Mistakes are **the tuition fee** for financial literacy. The real crime is having the time, the income, and the brainpower to manage your money **and not using it at all**.  

The first step is always the hardest (just like the first push‑up). Once you start moving money around, the process stops feeling like you’re defusing a bomb and more like you’re learning a new dance move—awkward at first, but soon you’ll be moonwalking through your budget.  

Being a little scared is normal; you’re not a robot. The danger is **letting that fear freeze you**—that’s the difference between a cushy retirement and a “why‑did‑I‑spend‑that‑on‑the‑latest‑gadget” regret. The rest of this post will give you a cheat‑sheet to keep the fear in check.  

---

## 31.3 – A time for reflection  

> “The map is not the territory.” – Alfred Korzybski  

In finance‑speak that means **your mental model of your money isn’t the actual money**. You may think you have $20k in savings, but the bank might be charging a $15 fee you forgot about.  

The personal‑finance world has turned into a **product‑shopping mall** (“Buy the shiny new mutual fund!”) while ignoring the fact that **products are tools, not goals**. So before you start clicking “Invest” on the next hot tip, take a breath and look at the **real life** happening around you.

### What does this look like in practice?  

A year is long enough for a lot of plot twists:

- **Pandemic** – you learned you can work in pajamas.  
- **Inflation spike** – your grocery bill now feels like a Netflix subscription.  
- **Economic slowdown** – some friends got layoffs, others got promotions.  

On the personal side you may have gotten **married**, welcomed a **baby**, faced a **family emergency**, or even tried (and failed) at a **side hustle**. All of these shift the shape of your cash‑flow landscape.

Money is also a **taboo** in many families. You’ll be surprised how many “financial shocks” happen because nobody ever asked, “Hey, Mom, how’s your retirement fund?” That’s why personal finance isn’t a solo sport; it’s a **team sport** that includes partners, kids, and aging parents.

#### The senior‑citizen angle  

Your parents (or grandparents) are often the **most vulnerable** to scams and mis‑selling. Because they rarely discuss money with you, a shady insurance policy can stay hidden for years—until it’s too late. A quick check‑in can prevent a tragedy where a retirement nest‑egg disappears faster than a pizza at a party.  

Having a **holistic view**—your own finances **plus** those of anyone who depends on you—keeps you from getting blindsided.

### For new investors  

Before you even ask, “Which mutual fund has the best 5‑year return?” ask yourself, “**Where am I now?**” Opening that conversation can feel like opening Pandora’s box, but hey, at least you’ll know what’s inside.  

---

## 31.4 – Know where your finances are  

### The financial inventory (aka “your net‑worth check‑up”)  

Think of your net‑worth as a **body‑scan** for your money. It tells you whether you’re in the “fit” zone or the “needs‑more‑exercise” zone.  

**Net worth = Assets – Liabilities**  

But you can’t get there without first understanding your **cash‑flow** (money in vs. money out). You don’t need to log every latte, but you do need a monthly **big‑picture** view:

- **Total inflows** (salary, freelance cash, side‑gig income, etc.)  
- **Total outflows** (rent, groceries, subscriptions, that monthly “just‑because‑I‑feel‑like‑buying‑it” purchase).  

Most banks now bundle a simple **spending‑analysis** dashboard in their apps. If you’re a spreadsheet junkie, there are free templates (Morningstar’s template is a good starter).  

Why bother? Because tracking cash‑flow lets you spot **lifestyle creep**—the sneaky habit of letting expenses grow in lockstep with income. It’s the financial equivalent of “I’ll just have one more slice of cake” that eventually becomes a whole bakery.  

### Building your personal balance sheet  

Once you’ve got your cash‑flow picture, list every **asset** and **liability**. Here’s a quick cheat‑sheet:

#### Assets  

- **Cash** – every checking, savings, and digital wallet balance.  
- **Investments** – FD’s, stocks, mutual funds, bonds, pension pots, ULIPs, chit funds, government schemes, etc.  
- **Real‑world valuables** – your house (use a conservative market estimate), jewellery, art, vintage bike, etc.  
- **Other** – any cash‑equivalent (e.g., a prepaid travel card).  

#### Liabilities  

- **Housing loan** balance.  
- **Other loans** – car loan, personal loan, BNPL balances, loan‑against‑securities, loan‑against‑insurance, jewellery‑loan, etc.  
- **Other obligations** – credit‑card dues, unpaid taxes, etc.  

Plug the numbers into a spreadsheet and you’ll have your **net‑worth statement**. If it’s negative, don’t panic—just a sign you need a plan. If it’s positive, celebrate with a modest treat (but not a yacht).  

> **Pro tip:** *If you can’t find a particular number, use a conservative estimate.* It’s better to under‑estimate assets than over‑estimate them and get a nasty surprise later.  

### Consolidate whatever you can  

While you’re inventorying, you’ll likely discover your money is scattered like confetti across a dozen platforms:

- Multiple broker accounts (Zerodha, Groww, etc.)  
- Several banks (ICICI, SBI, a neobank you opened after a promo)  
- A few “investment‑app” wallets you never use  

**Consolidation** = fewer passwords, easier tracking, and lower chances of paying hidden fees. If you already have a **direct mutual‑fund** account with your broker, close the duplicate ones.  

**Toxic products** – endowment policies, traditional whole‑life insurance, ULIPs that look like a “mutual fund in disguise” – are usually money‑sinks. Dump them if you can; they’re the financial equivalent of that couch you never sit on.

#### Quick checklist  

- Involve your **partner/spouse** when you do the review. Money arguments are cheaper than divorce lawyers.  
- Talk to **parents** (or the people who finance you) and help them tidy up their accounts.  
- Close **redundant accounts** unless you have a clear purpose (e.g., a foreign‑exchange account for travel).  
- Ditch **opaque, high‑fee products**.  

A thorough sweep gives you a **clear picture** and often uncovers hidden cash you can immediately put to work.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2023/01/Personal-finance-review-1-1024x609.png)

---

## 31.5 – Review your goals  

Now that you know **what** you have, let’s talk about **why** you have it.  

Goal‑setting in finance is a hot‑button topic: some swear it’s the only way to stay disciplined, others claim it’s a recipe for tunnel‑vision and risk‑taking. The reality sits somewhere in the middle—like a perfectly balanced cocktail of ambition and flexibility.

### Why goals matter (and why they can bite you)  

Humans love **mental accounting** (thanks, Nobel‑winner Richard Thaler). When you get paid, you automatically allocate money to “rent,” “food,” “fun,” etc. Goal‑based investing just formalizes that instinct.  

But if you lock yourself into a rigid target (e.g., “buy a $2 million house in 3 years”), life might change the rules of the game. Your definition of *house* could shift from “villa with pool” to “cozy apartment with a balcony for plants.”  

A Morningstar study showed that after seeing a **master list of common financial goals**, **73 %** of participants altered at least one of their original top‑3 goals. Goals evolve—so should your plan.

### Flexible, “possibilities” planning  

Instead of saying *“I will own a Ferrari by 2027,”* start with *“I want to be financially free enough to choose my lifestyle.”* Then map out **what’s possible** given your current net worth, cash‑flow, and risk tolerance. This approach stays adaptable, which is essential because—**as the old saying goes—*“Man plans, and God laughs.”*  

There is **no one‑right way** to manage your money. Some people just **save everything** (the “squirrel” approach), others have **broad, generic goals** (like “retire early”), and a few set **laser‑sharp targets** (like “have $500k in a taxable brokerage by 2030”). Pick a style that feels **sustainable**, then focus on building **systems** (automatic transfers, regular reviews) rather than obsessing over the exact outcome. You can’t control the market; you can control the process.

### How to review your goals  

1. **Make them concrete** – e.g., “Retire in 2065 with ₹10 crore and withdraw 4 % per year.”  
2. **Estimate the cost** – use inflation‑adjusted calculators (SEBI’s tools are handy).  
3. **Calculate required savings** – factor in expected returns and inflation.  
4. **Pick an asset allocation** that matches the time‑horizon and risk profile.  

Here’s a quick visual example (feel free to replace with your own numbers):

![Image](https://zerodha.com/varsity/wp-content/uploads/2023/01/Personal-finance-review-2-1024x735.png)

#### A few practical tips  

- **Don’t assume historic returns will repeat.** Nifty’s 12 % long‑run average is nice to quote, but assuming you’ll earn that every year is a *recipe for disappointment*. Use **realistic** assumptions (e.g., 8‑10 % for a 60/40 equity‑debt mix).  
- **Gradually de‑risk** as you near a goal. A 70 % equity portfolio is fine for a 30‑year horizon, but not for a 5‑year house‑down‑payment.  
- **Short‑term goals (<5 years)** should sit in low‑risk, liquid vehicles: savings account, FD, or liquid mutual fund.  
- **Distinguish risk tolerance (how much volatility you can stomach)** from **risk capacity (how much risk a particular goal can bear)**.  

> **Example:** You’re 30, want to retire at 60 → 30 years of compounding → you can afford high equity exposure.  
> But you also want to buy a house in 7 years → even if you’re a “risk‑taker,” the **capacity** for that goal is low; a 60 % equity allocation would expose you to **sequence risk** (what if the market tanks in year 6?).  

### Aligning goals with your values  

Goals that don’t reflect your deeper values feel like chores. Ask yourself:  

- *What truly matters to me?*  
- *What kind of life would make me feel fulfilled?*  

George Kinder, the “father of financial life planning,” coined three provocative questions:

1. **Design Your Life** – Imagine you’re financially secure. What does your perfect day look like?  
2. **You Have Less Time** – Suppose a doctor tells you you have 5‑10 years left. How would you rearrange priorities?  
3. **Today’s the Day** – The doctor says you have ONE day left. What regrets surface?  

These questions can be uncomfortable, but they force you to **anchor your financial targets in meaning**, not just numbers.  

---

## 31.6 – Debt  

Even if you could *out‑invest* Warren Buffett (spoiler: you can’t), **bad debt** will chew away at your returns faster than a rabbit on a carrot.  

### Gather the dirty laundry  

Collect every loan statement, credit‑card bill, and app‑based micro‑loan balance. Not all debt is created equal:

| Debt type | Typical interest range | “Good” vs “Bad” |
|-----------|-----------------------|----------------|
| Credit‑card | 12 %–42 % | **Bad** (unless you’re a master of paying in full every month) |
| Lending‑app loans | 20 %–30 %+ | Generally **bad** |
| Housing loan (mortgage) | 6 %–9 % (varies) | **Potentially good** (low‑cost borrowing for an appreciating asset) |
| Personal loan | 10 %–22 % | Mixed – depends on purpose & rate |
| Reverse mortgage | 8 %–12 % | May be useful for seniors, but read fine print |

If you can **pay extra** on any loan, do it. Early payments mostly chip away at **interest**, because in the early years of a typical EMI schedule, most of the payment goes toward interest, not principal.  

### Repayment strategies  

#### Snowball method  

1. List all debts **smallest to largest** (by outstanding balance).  
2. Pay **minimum** on every loan **except** the smallest.  
3. Funnel any extra cash toward that smallest loan.  
4. Once it’s gone, move to the next smallest.  

Psychologically rewarding because you *see* debts disappear quickly.  

#### Avalanche method  

1. List debts **by interest rate** (highest to lowest).  
2. Pay **minimum** on all except the highest‑rate loan.  
3. Throw any surplus at that loan.  
4. Move down the list as each loan is cleared.  

Mathematically optimal because you minimize total interest paid.  

If you have a high salary *and* high debt, ignoring the avalanche is practically **financial suicide**—paying off debt is a **guaranteed return** (think 15‑20 % after‑tax, depending on the loan).  

### Credit score – your financial street‑cred  

India’s credit bureaus (Experian, Equifax, TransUnion CIBIL, CRIF Highmark) score you **300–900**. Aim for **750+** to keep borrowing costs low.  

- **Free credit report**: Each bureau lets you download one report per year (or more if you opt in).  
- **Dispute errors**: Mistakes happen (maybe a loan you never took shows up). Raise a dispute on the bureau’s portal.  

Basic habits for a healthy score:  

- Keep **credit utilisation** below 30 % (don’t max out cards).  
- Pay all dues **on time**.  
- Avoid opening *too many* new accounts in a short window.  

---

## 31.7 – Insurance  

You’re probably wondering, “Why are we still not talking about stocks?” Because before you **grow** your wealth, you must first **protect** it. Think of it as wearing a helmet before you ride a bike.  

### Why insurance matters  

Imagine you have a tidy emergency fund and a solid portfolio, but a serious health issue hits you tomorrow. Without a **health policy**, you’d have to **sell investments at a loss** or take high‑interest loans—both of which erode the very cushion you built.  

In India, a single major hospitalisation can **wipe out years of savings**. That’s why insurance is the *defensive* layer of any personal‑finance strategy.  

The two **must‑have** policies are:

1. **Term life insurance** (if you have dependents).  
2. **Health insurance** (for everyone).  

### Term insurance – the pure‑death‑benefit  

Term plans provide a **lump‑sum payout** if you pass away during the cover period. They are cheap because there’s **no investment component**.  

How much cover? A common rule of thumb: **10–12 × your annual income**. Example:  

- Income = ₹12 lakhs/year  
- Desired cover ≈ ₹1.2–₹1.5 crore  

If you placed ₹1 crore in a 7 % FD, it would generate roughly **₹57,000** per month—potentially enough for a modest family’s living expenses, assuming inflation is accounted for. The higher the cover, the more safety net you have.  

### Health insurance – your medical shield  

Hospital bills are rising faster than a pizza price in a college town. A **base policy** of **₹10–20 lakhs** is a good starting point; add a **top‑up** for extra protection if your family’s risk profile is high (e.g., senior members, chronic conditions).  

Shrehith from Ditto has a great deep‑dive on picking a health plan—worth a read if you’re serious.  

### Quick insurance checklist  

- Verify you have **adequate term cover** (use the linked guide).  
- Ensure your **health policy** meets your family’s needs (check co‑pay, network hospitals, exclusions).  
- **Avoid “investment‑linked” insurance** (ULIPs, endowment policies). They’re usually expensive, opaque, and underperform traditional investments.  

Insurance is **personal**; a good advisor can tailor it, but the baseline rule is: *protect before you project.*  

#### For newbies  

If you’re just starting out, **lock in term and health coverage first**—the rest can come later. It’s cheaper to buy a solid term plan in your 20s/30s than to wait until you’re older and premiums skyrocket.  

---

## 31.8 – Emergency fund  

Your **emergency fund** is the financial equivalent of a **fire extinguisher**—hopefully you never need it, but you’ll be glad it’s there when the kitchen catches fire (or the job market does).  

### How much is enough?  

Common wisdom suggests **3–12 months** of living expenses. The exact number depends on:

| Situation | Suggested reserve |
|-----------|-------------------|
| Stable salaried job, low expense volatility | 3–6 months |
| Contract / gig work, higher income variability | 9–12 months |
| High‑income professional or sole‑proprietor | 9–12 months (or more) |

If you’re a **young starter** with a predictable salary, you can begin with a **3‑month** buffer and grow it over time.  

### Where to park it?  

Liquidity trumps returns here. You need **instant access** without market‑timing risk. Good options:

- **Liquid mutual funds** (low‑risk, daily liquidity).  
- **Savings account** (if interest rates are decent).  
- **Short‑term FD** (with a 7‑day premature withdrawal clause).  

Avoid locking emergency cash in **stocks, bonds, or long‑term FDs**—you might need the money when the market is down, turning a “safety net” into a “safety trap.”  

### Practical pointers  

- **Scale to your cash‑flow**: the more unpredictable your income, the larger the reserve.  
- **Don’t over‑stock**: 5 years of salary in a liquid fund is overkill and ties up money that could be invested for growth.  
- **Build gradually**: start a SIP into a liquid fund, or allocate a chunk of each bonus/raise to the fund.  
- **Never chase yield** on this pile. The goal is **peace of mind**, not a 7 % return.  

---

### TL;DR (in case you skim while sipping coffee)  

1. **Take stock** of everything you own and owe.  
2. **Consolidate** accounts, ditch toxic products.  
3. **Set flexible goals** that match your values, not just market hype.  
4. **Tackle high‑interest debt** with snowball/avalanche methods.  
5. **Buy the basics**: term life + health insurance.  
6. **Build a liquid emergency fund** sized to your life‑style risk.  
7. **Review, repeat, and keep the fear in check**—your future self will thank you (and maybe buy you a drink).  

Now go forth, pull up that spreadsheet, and give your finances the **annual check‑up** they desperately need. 🍻  