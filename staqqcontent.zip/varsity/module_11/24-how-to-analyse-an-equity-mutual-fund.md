# 24. How to Analyse an Equity Mutual Fund?  

**Source:** <https://zerodha.com/varsity/chapter/how-to-analyse-an-equity-mutual-fund/>

---  

## 24.1 – Recap  

Alright, grab a coffee (or a cocktail, I don’t judge) and give yourself a quick mental rewind of the past 23 chapters. What have we learned?  

- **Investment = essential** – it’s the bread and butter of personal finance.  
- **Assets galore** – from gold to bonds, we’ve catalogued the tools that can ferry you toward retirement or any other money‑goal you fancy.  
- **Mutual funds = the Swiss‑army‑knife** of the investing world; they’re the workhorse that helps you hit those goals.  
- **Mutual‑fund basics** – we defined what a fund actually is, why the fact sheet is your new best friend, and the most common fund categories.  
- **Equity vs. debt** – we toured the whole zoo, from blue‑chip giants to high‑yield bonds.  
- **Index funds** – the passive, low‑cost cousins that let you “track” the market.  
- **Performance & risk lingo** – volatility, Sharpe, alpha… you know the drill.  

Now we’re standing at the start of the final sprint: **building a mutual‑fund portfolio** that actually works for your life‑plan. Think of it as a three‑step recipe:  

1. **Define the goal** – e.g., “₹40 lakhs for my 10‑year‑old’s U.S. master’s in 15 years (inflation‑adjusted, of course).”  
2. **Pick the right funds** – the meat of the exercise.  
3. **Monitor & rebalance** – keep the salad fresh.  

Step 1 and 3 are a walk in the park; Step 2 is where the weeds grow. It breaks down further into three bite‑sized tasks:  

- **Fund screening** – weed out the duds, keep the studs.  
- **Portfolio construction** – 100 % equity? 70 % equity + 30 % debt? You decide.  
- **Allocation** – decide how many rupees go into each chosen fund.  

Getting the **fund analysis** right is the secret sauce. Pair up with a fund house you trust, and you’ll be well on your way to smashing that financial target.  

In this chapter we’ll walk through a **simple, repeatable template** for analysing any equity mutual fund. It’s not the only way—just the way that’s worked for me. Feel free to tweak it as you gain experience. Let’s dive in!  

---  

## 24.2 – Hygiene Check  

![Fund hygiene](https://zerodha.com/varsity/wp-content/uploads/2020/11/M11-C24-mutualfund-hygiene-WEB-300x200.jpg)

I’ll pick an equity fund and show you how I give it a quick “doctor’s check‑up.” Different investors have different obsessions: some stalk the fund manager’s résumé, others only stare at the past‑year return chart.  

My mantra? **Risk‑adjusted returns** – can the fund give me decent gains without taking a heart‑attack‑inducing amount of volatility?  

*Disclaimer: I’m looking at **Kotak Standard Multi‑Cap Fund (Growth, Regular)** purely as a case study. Not a recommendation, okay?* 😊  

> **Why regular, not direct?** Direct plans are newer and may not have ten years of data yet, so the regular version gives us a richer history.  

### Step 1 – Grab the fact sheet  

The fact sheet is the fund’s résumé. The first block tells you who the fund *is*:  

![Fund snapshot](https://zerodha.com/varsity/wp-content/uploads/2020/11/Image-1_abt-300x129.png)

**What I read:**  

- **Multi‑cap** – the fund can swing between large‑cap, mid‑cap, even small‑cap stocks. That means the benchmark isn’t the plain‑vanilla Nifty 50 TRI; expect something broader.  
- **Inception:** 11 Sept 2009. Not a newborn, but old enough to have survived a few market cycles (≈ 14 years of data).  
- **Fund manager:** Same person since day one. If you’re a “manager‑cultist,” you could dig into his background; I usually skip that part.  

### Step 2 – Dig deeper into the sheet  

![More info](https://zerodha.com/varsity/wp-content/uploads/2020/11/Image-2_info-300x183.png)

- **Investment objective:** No cap‑size restriction, so the fund can roam freely.  
- **Style grid:** A blend of **growth** and **value** – the fund’s like a hybrid car, good for both city traffic and highway cruising.  
- **Portfolio tilt:** Heavy on large‑ and mid‑cap stocks, which is why the benchmark is the **Nifty 200 Total Return Index**.  

> **Quick sanity check:** If you start obsessing over why the manager owns 5 % of Stock A vs. 2 % of Stock B, you’re doing “stock‑picking research,” not fund research. If you can pick winning stocks better than the manager, you’d be better off buying those stocks directly. It’s like critiquing a chef’s garnish while the main dish is already perfect.  

### Step 3 – Look at AUM (Assets Under Management)  

![AUM snapshot](https://zerodha.com/varsity/wp-content/uploads/2020/11/Image-3_aum-300x129.png)

- **Fund AUM:** ₹29,500 crore → a **large** fund.  
- **Kotak AMC total AUM:** ₹1.5 Lakh crore.  
- **Equity‑category AUM:** ~₹40,000 crore.  

So the Standard Multi‑Cap fund makes up **≈ 18 %** of Kotak’s total AUM and **≈ 72 %** of its equity AUM. In other words, it’s one of Kotak’s flagships.  

> **Why care?** Flagship funds usually get the AMC’s extra attention (and budget). But big AUM can be a double‑edged sword: the manager may find it harder to deploy fresh capital efficiently. If the fund’s inflow is smooth and gradual, it’s fine. Sudden, massive inflows (often from aggressive marketing) can cause a **“size‑drag”** and slightly lag performance.  

### Step 4 – Expense Ratio  

- **Direct plan:** 0.73 %  
- **Regular plan:** 1.69 %  

That’s a *lot* cheaper than many actively managed funds. If you’re still eyeing the regular plan after reading this, you might need a new hobby. 😜  

### Step 5 – Quick risk‑return numbers (Morningstar snapshot)  

![Morningstar snapshot](https://zerodha.com/varsity/wp-content/uploads/2020/11/Image-4_msone-300x94.png)

- **Standard deviation (3 yr):** 20.58 % vs. category 21.38 % → a touch less volatile than peers.  
- **5 yr SD:** 18.39 % (category 19.12 %)  
- **10 yr SD:** 17.42 % (category 18.40 %)  

Lower volatility → better risk‑management, at least on paper.  

- **Sharpe ratio:** Negative. Either the risk‑free rate is higher than the fund’s excess return, or the fund’s returns are negative. Not useful here, so we’ll ignore it.  

- **Alpha & Beta:** (Check 3 yr, 5 yr, 10 yr) – they’ll tell us if the fund is truly “adding value” beyond the benchmark.  

That’s essentially the **hygiene checklist** – a handful of “good‑to‑know” data points that set the stage for deeper analysis.  

---  

## 24.3 – Rolling‑Returns Check  

You’ve heard the mantra: *“Past performance is not a guarantee of future results.”* True, but it’s still the best crystal ball we have. The trick is to look at **rolling returns** over longer horizons (≥ 3 years). Anything shorter is basically noise for equity funds.  

> **Pro tip:** If you don’t know what a rolling return is, skim the earlier Varsity chapter on “Rolling Returns” before proceeding.  

Below are snapshots from **RupeeVest** (soon we’ll have them on Coin).  

### 3‑Year Rolling Returns  

![3‑yr rolling](https://zerodha.com/varsity/wp-content/uploads/2020/11/Image-5_3rr-300x154.png)

- **Blue line:** Fund’s 3‑yr rolling CAGR.  
- **Grey line:** Benchmark’s 3‑yr rolling CAGR.  

**Key observations:**  

- The fund’s line stays **above** the benchmark for most of the period → outperformance.  
- **Average 3‑yr return:** 15.2 % vs. benchmark 9.87 % (a healthy gap).  
- **Dispersion:** Fund’s min –5.19 % / max +31.2 % vs. benchmark min –6.97 % / max +23.53 %.  

*Pause and ask:* “Is this extra return coming from extra risk?” We’ll answer that shortly.  

The gap narrows after mid‑2018, possibly because the fund’s AUM ballooned (size‑drag) or the market environment changed.  

### 5‑Year Rolling Returns  

![5‑yr rolling](https://zerodha.com/varsity/wp-content/uploads/2020/11/Image-6_rr5-300x155.png)

- **Fund average:** 16.51 %  
- **Benchmark average:** 10.46 %  

Minimum returns: **+1.18 %** (fund) vs. **–2.28 %** (benchmark). Even on the downside, the fund out‑performed.  

### 10‑Year Rolling Returns  

![10‑yr rolling](https://zerodha.com/varsity/wp-content/uploads/2020/11/Image-7_rr10-300x155.png)

- **Fund average:** 12.07 % vs. benchmark 7.48 %  
- **Min:** 8.59 % (fund) vs. 3.79 % (benchmark)  
- **Max:** 14.56 % (fund) vs. 9.67 % (benchmark)  

**Take‑aways from rolling returns:**  

1. **Spread shrinking?** Could be AUM‑related, or just market regime change.  
2. **Risk‑adjusted?** We’ll verify with risk metrics next.  

### Trailing Returns (as‑of‑today snapshot)  

![Trailing returns](https://zerodha.com/varsity/wp-content/uploads/2020/11/Image-8_ttr-300x100.png)

- **3‑yr:** Fund underperforms benchmark.  
- **5‑yr:** Roughly on par.  
- **10‑yr:** Slight edge still.  

Overall, the fund has historically beat its peers in the **Equity Multi‑Cap** bucket, but the recent 3‑yr dip reminds us that outperformance isn’t forever.  

---  

## 24.4 – Risk‑Return Matrix Check  

Morningstar’s **risk‑return matrix** is a visual cheat‑sheet that plots **risk (X‑axis)** vs. **return (Y‑axis)** for the fund, its category, and its benchmark.  

![Risk‑return matrix](https://zerodha.com/varsity/wp-content/uploads/2020/11/Image-9_matrix-258x300.png)

I’m looking at the **5‑year** view.  

- **Red square:** Benchmark – about **10 % return** for **19 % risk**.  
- **Yellow square:** Category – sits on the same vertical line (same risk) but a tad lower return than the benchmark.  
- **Fund point:** Lies **north‑west** of the benchmark – **similar or slightly higher return** with **lower risk**.  

> **Interpretation:** If you had to pick between the benchmark and the whole category, the benchmark wins: same risk, better return. The fund, however, improves the trade‑off – it gives you benchmark‑level returns while taking on *less* volatility. That’s the sweet spot for an active manager.  

### 10‑Year Matrix  

![10‑yr matrix](https://zerodha.com/varsity/wp-content/uploads/2020/11/Image-10_10matrix-253x300.png)

Even more impressive over ten years: the fund nudges a bit left (lower risk) and a bit up (higher return) relative to both benchmark and category.  

**Bottom line:** The fund’s risk‑adjusted performance is solid.  

---  

## 24.5 – Capture Ratios  

Capture ratios tell you how well a fund **captures upside** and **limits downside** relative to its benchmark.  

### 5‑Year Capture  

![5‑yr capture](https://zerodha.com/varsity/wp-content/uploads/2020/11/Image-11_5yrs-capture-300x54.png)

- **Upside capture:** ~ 100 % (the fund rides almost the entire upside of the benchmark).  
- **Downside capture:** ~ 90 % (it only suffers 90 % of the benchmark’s losses).  

That’s a respectable risk‑management score.  

### 10‑Year Capture  

![10‑yr capture](https://zerodha.com/varsity/wp-content/uploads/2020/11/Image-12_10yrs-capture-300x59.png)

- **Upside:** ~ 100 %  
- **Downside:** ~ 87 %  

Compared with the category, the fund does a better job of **keeping the bad stuff out** while still riding the good.  

### Verdict  

Our quick‑and‑dirty analysis suggests Kotak Standard Multi‑Cap is a **well‑run, reasonably sized, low‑cost fund** that has delivered consistent outperformance with modest volatility. Does that mean you should drop everything and pour your savings into it? Not quite – we’ll explore the “should‑I‑buy‑it?” decision in the next chapter.  

> **One more nugget:** Fund rankings published by rating agencies are fun to glance at, but they’re not a substitute for your own homework. Think of them as movie reviews – they can guide you, but you still have to watch the film yourself.  

---  

## Key Takeaways  

- **Start with a hygiene check** – AUM size, inception date, fund manager tenure, expense ratio, benchmark, and basic risk stats.  
- **Know the fund’s purpose** – investment objective, style grid, and where it sits in the AMC’s portfolio.  
- **Roll with rolling returns** – look at 3‑, 5‑, and 10‑year rolling CAGR, and note the average, min, and max values.  
- **Compare against the benchmark** – is the fund consistently above the benchmark, and is the spread widening or narrowing?  
- **Assess risk** – standard deviation vs. category, beta, alpha, and the risk‑return matrix (5‑yr & 10‑yr).  
- **Check capture ratios** – upside capture near 100 % and downside capture well below 100 % signals good risk management.  
- **Expense matters** – direct plans can shave off a full percent point in annual costs.  
- **AUM dynamics** – huge inflows can create a “size drag”; gradual growth is healthier.  
- **Don’t chase rankings** – they’re a nice garnish, not the main course.  

Armed with this checklist, you can now give any equity mutual fund a proper once‑over, just like a bartender assessing a new cocktail before adding it to the menu. Cheers to smarter fund picking! 🍹