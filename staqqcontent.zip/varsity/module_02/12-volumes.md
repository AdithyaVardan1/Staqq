# 12. Volumes  

**Source:** https://zerodha.com/varsity/chapter/volumes/  

---  

Volume is the unsung hero of technical analysis – it’s the “cheerleader” that shouts whether the crowd really believes the price moves or if it’s just a lone guy dancing in the middle of the floor. Think of volume as the market’s gossip column: it tells you how many people are actually talking (or trading) about a stock at any given moment.  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M2-Ch12-title.jpg)  

---

### What *is* volume, really?  

Volume simply counts how many shares change hands over a specific time slice. The louder the market, the higher the volume.  

**Example:** You snap up 100 shares of **Amara Raja Batteries** at ₹485. At the exact same instant, I’m offloading 100 shares at ₹485. The trade executes, and together we have *generated* a volume of **100** shares—not 200. The “buy side” and the “sell side” are two sides of the same coin; they don’t double‑count.  

---

### A day in the life of a fictional market  

| Time | Shares traded | Price | Cumulative volume |
|------|---------------|-------|-------------------|
| 9:30 AM | 400 | ₹62.20 | 400 |
| 10:30 AM | 500 | ₹62.75 | 900 (400 + 500) |
| 11:30 AM | 350 | ₹63.10 | 1,250 (400 + 500 + 350) |
| … | … | … | … |

Just keep adding the numbers and you’ll see how the “total volume” builds up throughout the session.  

---

### Real‑world snapshot (2:55 PM, 5 Aug 2014)  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M2-Ch12-chart1.jpg)  

- **Cummins India Limited:** 12,72,737 shares traded so far.  
- **Naukri (Info Edge India Limited):** 85,427 shares traded so far.  

These are **cumulative** figures – they represent everything that has happened from the opening bell up to the timestamp on the chart.  

Fast forward to 3:30 PM (same day, same stocks) and you’ll see the numbers swell because the market is still buzzing.  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M2-Ch12-chart2.jpg)  

- Cummins India jumps to **13,49,736** shares.  
- Naukri climbs to **86,712** shares.  

Notice the steady climb? That’s the market’s way of saying “I’m still awake, keep the orders coming!”  

---

## 12.1 – The volume‑trend table  

Volume by itself is like a solo‑singer with no band – it sounds interesting, but you can’t tell if the song is a hit. Pair it with price action and you get a full‑blown concert.  

Below is the classic **volume‑price matrix** (re‑created in words because we’re not embedding a table image here).  

| Price movement | Volume movement | What it *usually* means |
|----------------|----------------|-------------------------|
| **↑** (price up) | **↑** (volume up) | Bullish – “smart money” is buying |
| **↑** | **↓** | Potential bull trap – price rising on weak participation |
| **↓** | **↑** | Bearish – “smart money” is exiting |
| **↓** | **↓** | Possible bear trap – price falling on thin interest |

### What counts as “increase” in volume?  

Traders love a good reference point. The most common yardstick is the **10‑day moving average** of volume.  

- **High Volume:** Today’s volume > 10‑day average  
- **Low Volume:** Today’s volume < 10‑day average  
- **Average Volume:** Today’s volume ≈ 10‑day average  

To get the average, simply plot a moving‑average line over the volume bars – we’ll dive deeper into moving averages in the next chapter.  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M2-Ch12-chart3.jpg)  

In the chart above, the blue bars are raw volume; the red line is the 10‑day average. Whenever a blue bar towers above the red line, you have a **volume spike** – a possible sign that institutional players (the “big kids”) are stepping onto the playground.  

---

## 12.2 – The thinking behind the table  

### Big‑money, big‑volume  

When a giant institutional investor like **LIC** decides to buy Cummins, they won’t settle for a modest 500‑share snack. They’re more likely to gobble up **500,000 + shares** in one go. Such a massive order instantly inflates the volume bar and, because demand is huge, nudges the price upward. This is why volume is often called **“smart‑money meter.”**  

- **Price ↑ + Volume ↑** → Big players are buying → Bullish → Consider going long.  
- **Price ↑ + Volume ↓** → Small‑time retail fans are lifting the price → Beware of a bull trap.  
- **Price ↓ + Volume ↑** → Big players are dumping → Bearish → Consider going short.  
- **Price ↓ + Volume ↓** → Weak retail sellers are pulling the price down → Possible bear trap.  

#### Quick mental cheat‑sheet  

| Situation | Why it matters | Takeaway |
|-----------|----------------|----------|
| Price up, volume up | Institutional buying | **Bullish** – join the party |
| Price up, volume down | Retail‑only hype | **Caution** – could be a fake rally |
| Price down, volume up | Institutional selling | **Bearish** – start looking for exits |
| Price down, volume down | Retail panic | **Caution** – may be a false alarm |

The underlying assumption is that **smart money usually makes smarter moves** than the average retail trader. It’s not a guarantee, but it’s a useful heuristic.  

---

## 12.3 – Revisiting the checklist (with a volume twist)  

Let’s see how volume fits into a classic technical‑analysis checklist. Imagine the following scenario:  

1. **Bullish Engulfing pattern** appears on the chart – a classic “long‑trade” signal.  
2. **Support level** sits right at the low of that engulfing candle – giving the price a solid “floor” to bounce off.  

Now, **add high volume on the second day of the engulfing (the blue candle, P2).**  

What does that tell you?  

- **High volume + price rise** = big players are backing the move → **Triple confirmation** (candlestick, support/resistance, volume).  
- If volume were low, you’d suspect a “solo act” – the price may look good but nobody else is cheering it on.  

### Updated “Trade‑Ready” checklist  

- **Candlestick pattern:** Must be a clear, recognizable formation (e.g., bullish engulfing, hammer, etc.).  
- **Support & Resistance:**  
  - *Long trade*: pattern low ≈ support level.  
  - *Short trade*: pattern high ≈ resistance level.  
- **Volume confirmation:**  
  - **Above‑average volume** on the day(s) of interest (use the 10‑day MA as the benchmark).  
  - **Low volume** = red flag; consider staying on the sidelines.  

If all three boxes are ticked, you’ve got a **triple‑confirmation setup** – the market’s saying “go ahead, the odds are in your favor.”  

---

### Key takeaways from the chapter  

- **Volume = the market’s applause meter.** It tells you whether the price move is backed by a crowd or just a lone wolf.  
- **100‑share buy + 100‑share sell = 100‑share volume**, not 200.  
- **End‑of‑day volume** is cumulative – it aggregates every trade from open to close.  
- **High volume** usually signals “smart money” (institutional) activity.  
- **Low volume** often means the move is driven by retail traders – tread carefully.  
- **Always cross‑check volume** before committing to a long or short position.  
- **Avoid low‑volume days** unless you love playing musical chairs with a half‑empty floor.  

Happy chart‑watching, and may your volume bars always be tall enough to keep the smart money cheering you on!  