# 7. Single Candlestick patterns (Part 3)

**Source:** <https://zerodha.com/varsity/chapter/single-candlestick-patterns-part-3/>

---  

##  

##  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/09/M2-Ch7-title.jpg)

## 7.1 – Paper Umbrella  

The *paper umbrella* is a one‑candle show‑stopper that tells you whether the market might swing one way or the other. Its meaning flips depending on **where** it pops up on the chart.  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/09/M2-Ch7-D1a.jpg)

A paper umbrella actually bundles **two** classic reversal shapes:  

| Pattern | Bias | Look |
|--------|------|------|
| **Hanging Man** | Bearish | Long lower wick, tiny body at the *top* of a rally |
| **Hammer** | Bullish | Same shape, but hanging out at the *bottom* of a rally |

Both share the same visual DNA – a **long lower shadow** that’s at least **twice** the length of the real body. The tiny body sits near the top of the candle, the shadow dangles down like a sad umbrella in a storm.

### How to prove it with numbers  

Take an example candle:  

| OHLC | Value |
|------|-------|
| Open | 100 |
| High | 103 |
| Low  | 94 |
| Close| 102 |

*Real body* = Close – Open = **2** points.  
*Lower shadow* = Open – Low = **6** points.  

Because **6 > 2 × 2**, the shadow‑to‑body ratio is satisfied, so we have a legit paper umbrella. The colour (green/blue or red) is irrelevant – the candle’s “mood” is neutral, it’s the shape that matters.

---

## 7.2 – The Hammer formation  

A **bullish hammer** is the market’s way of saying, “Hey, I might have stumbled, but I’m getting back up!” It shows up at the **bottom** of a downtrend, looking like a tiny body perched on a long, droopy lower wick. The longer the wick, the louder the bull’s comeback chant.

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/09/M2-Ch7-Chart1.jpg)

Notice the blue hammer’s almost‑non‑existent upper shadow – perfectly fine under the “be flexible, quantify and verify” rule. Colour doesn’t matter, but a blue (or green) body feels nicer because it already hints at a modest gain.

### What the market is whispering  

1. **Downtrend dominance** – bears have been running the show.  
2. Each day the market opens lower and makes a fresh low.  
3. On hammer day, the market **does** open lower, carving a new low (the long wick).  
4. Then, like a surprise cameo, buyers swoop in, pushing the price back up, and the candle closes near its high.  
5. This bullish push can flip sentiment, signalling a possible **long** entry.

### Trade‑setup cheat sheet  

| Trader type | Entry timing | How to confirm at ~3:20 PM (or end‑of‑day) |
|-------------|--------------|--------------------------------------------|
| **Risk‑taker** | Same day (right on the hammer) | • Open and close within 1‑2 % of each other (tiny real body)<br>• Lower shadow ≥ 2 × real body |
| **Risk‑averse** | Next trading day (after a blue candle) | • Check that the next day’s candle is blue (close > open) |

**Stop‑loss** = the low of the hammer (the bottom of that shaggy wick).  

### Real‑world example (Cipla Ltd., 15‑min intraday)

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/09/M2-Ch7-Chart2.jpg)

| Person | Entry price | Reason |
|--------|-------------|--------|
| Risk‑taker | **₹ 444** (on the hammer) | Meets hammer criteria instantly |
| Risk‑averse | **₹ 445.4** (next blue candle) | Waited for confirmation |
| **Both** | Stop‑loss **₹ 441.5** (hammer low) | Hard‑stop on the wick |

The trade blossomed into a tidy intraday profit.

### More hammer fun  

1. **Risk‑averse win** – see the chart below where the “Buy strength & Sell weakness” rule shines.  

   ![Image](http://zerodha.com/varsity/wp-content/uploads/2014/09/M2-Ch7-Chart3.jpg)

2. **Two‑hammer combo** – both satisfy the hammer pre‑conditions (downtrend + shadow‑to‑body ratio).  

   ![Image](http://zerodha.com/varsity/wp-content/uploads/2014/09/M2-Ch7-Chart4.jpg)

   *First hammer*: Risk‑averse stayed out thanks to Rule 1, avoiding a flat‑lined loss.  
   *Second hammer*: Both types jumped in, but the price lingered and finally slipped – a reminder that **once you’re in, stay put until SL or target hits**.  

3. **False alarm** – a perfect‑looking hammer that appears **without** a prior downtrend.  

   ![Image](http://zerodha.com/varsity/wp-content/uploads/2014/09/M2-Ch7-Chart5.jpg)

   It looks nice, but it isn’t a *real* pattern because the trend prerequisite is missing.

---

## 7.3 – The Hanging Man  

Flip the paper umbrella upside‑down, and you get a **hanging man** – a bearish top‑reversal candle that shows up **after** an uptrend. Think of it as the market’s “I’m getting tired of these highs, let’s cool off.”

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/09/M2-Ch7-Chart6.jpg)

The colour again doesn’t matter; what matters is the **shadow‑to‑body ratio** (lower shadow ≥ 2 × body). The prior **uptrend** is the essential backdrop (highlighted by the curved line).

### What the market is muttering  

1. Bulls have been partying, pushing the price higher every day.  
2. On hanging‑man day, bears sneak in, dragging the price down to form a long lower wick.  
3. The long wick signals **bearish pressure** trying to wrest control from the bulls.

### Trade‑setup cheat sheet  

| Trader type | Entry timing | Confirmation (same as hammer) |
|-------------|--------------|--------------------------------|
| **Risk‑taker** | Same day, near the close | Candle meets shadow‑to‑body ratio; colour irrelevant |
| **Risk‑averse** | Next day, only if a red candle forms | Wait for a confirming red (close < open) candle |

**Stop‑loss** = the **high** of the hanging man (the top of the wick).  

### Real‑world example (BPCL Ltd.)

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/09/M2-Ch7-Chart7.jpg)

| OHLC | Value |
|------|-------|
| Open | 592 |
| High | 593.75 |
| Low  | 587 |
| Close| 593 |

*Trade plan*  

- **Risk‑taker** shorts at **₹ 593** (same‑day).  
- **Risk‑averse** waits for the next day’s close, ensuring it’s a red candle, then shorts.  
- **Stop‑loss** sits just above the high → **≈ ₹ 593.75**.  

Both would have walked away with a profit, assuming the price respected the stop‑loss.

---

## 7.4 – My experience with a paper umbrella  

I’m a bit of a **hammer fan**. If the market hands me a hammer and a hanging man at the same time, I’ll usually bet on the hammer. Why? In my back‑testing, the **bullish** hammer tends to materialise into a stronger move than the bearish hanging man.

My nagging doubt about the hanging man is simple: *If bears pushed the price down enough to carve that long wick, why does the candle still close near the top?* It feels like the bulls got a second wind, which weakens the bearish signal.

**Bottom line:** Build your own thesis. Observe how these candles behave in real markets, and let that shape your personal rule‑book. A little self‑research turns “just another candle” into a **structured market mindset**.

---

## 7.5 – The Shooting Star  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/09/shooting-star.png)

The **shooting star** is the final solo‑candle act before we graduate to multi‑candle combos. Visually, it’s an **upside‑down paper umbrella** – a tiny body with a **long upper shadow** that’s at least **twice** the body’s length.  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/09/M2-Ch7-Chart8.jpg)

*Key traits*  

| Feature | Requirement |
|---------|-------------|
| Upper shadow | ≥ 2 × real body |
| Lower shadow | Ideally none (tiny is okay) |
| Body colour | Doesn’t matter, but red gives a tiny confidence boost |
| Prior trend | Must be **uptrend** (bulls in charge) |

### Market’s inner monologue  

1. Bulls have been cruising, making higher highs and higher lows.  
2. On shooting‑star day, the market **shoots** up to a fresh high (the long wick).  
3. At that lofty point, bears jump in, slashing the price back down, leaving the close near the low of the day.  
4. The long upper wick screams **bearish pressure** – the bears have entered the arena with a shotgun.  
5. Expectation: More selling in the days ahead → **short‑trade** opportunity.

### Trade‑setup cheat sheet  

| Trader type | Entry timing | Confirmation checklist |
|-------------|--------------|------------------------|
| **Risk‑taker** | Same day, at/near the low of the star | • Current price ≈ low<br>• Upper shadow ≥ 2 × body |
| **Risk‑averse** | Next day, after a confirming red candle | • Wait for a red candle (close < open) on day 2 |

**Stop‑loss** = the **high** of the shooting star (the tip of that flashy wick).

### Real‑world example (stock at 1,417)

| OHLC | Value |
|------|-------|
| Open | 1,426 |
| High | 1,453 |
| Low  | 1,410 |
| Close| 1,417 |

*Trade plan*  

- **Risk‑taker** shorts around **₹ 1,417** (the low) on the day the star appears.  
- **Risk‑averse** waits for the next day’s red candle, then shorts near the low.  
- **Stop‑loss** placed at the star’s high → **₹ 1,453**.

### Profit‑and‑pain snapshots  

1. **Nice profit** – both trader types rode the star down and booked gains.  

   ![Image](http://zerodha.com/varsity/wp-content/uploads/2014/09/M2-Ch7-Chart10.jpg)

2. **Stop‑loss hit** – the price rebounded, hitting the high‑wick stop. Remember: when your SL fires, **exit**. It’s the market’s way of saying “better luck next time.”  

   ![Image](http://zerodha.com/varsity/wp-content/uploads/2014/09/M2-Ch7-Chart11.jpg)

> *Pro tip:* Once you’re in a trade, **don’t fiddle**. Let the stop‑loss or target do the work. (We’ll chat about trailing stops later.)

---

### Key take‑aways from this chapter  

- **Paper umbrella** = long lower shadow + tiny body; shadow must be **≥ 2×** the body.  
- Colour is irrelevant because open and close are almost equal.  
- **Hammer** = paper umbrella at the **bottom** of a downtrend → **bullish** signal.  
- **Hanging Man** = paper umbrella at the **top** of an uptrend → **bearish** signal.  
- For a **hammer**, the **low of the candle** is the stop‑loss.  
- For a **hanging man**, the **high of the candle** is the stop‑loss.  
- **Shooting star** = inverted paper umbrella (long upper shadow, tiny body) in an uptrend → **bearish** signal.  
- For a **shooting star**, the **high of the candle** is the stop‑loss.  
- Risk‑takers can jump in **same‑day** after confirming the shape; risk‑averse traders wait for the next day’s confirming colour (blue/green for longs, red for shorts).  
- Always respect your stop‑loss; it’s the safety net that keeps you from turning a small loss into a big regret.  

Now go out there, spot those umbrellas, hammers, hanging‑men, and shooting stars, and trade like you’re juggling flaming torches at a circus—stylish, confident, and with a safety net (your stop‑loss) ready just in case! 🎪📈