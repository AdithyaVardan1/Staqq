# 3. The Chart Types  

**Source:** https://zerodha.com/varsity/chapter/chart-types/  

---  

##  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/09/M2-Ch3-title.jpg)  

## 3.1 – Overview  

So you’ve already figured out that the Open (O), High (H), Low (L) and Close (C) are the four musketeers that summarise everything that happened to a security in a given period. The next logical question is: *how on Earth do we show those four numbers in a way that doesn’t make our brain melt?*  

If you tried to jam every OHLC into a plain‑old spreadsheet, a 10‑day chart would need you to stare at **40** separate numbers (4 per day). Imagine stretching that to six months or a full year – you’d be looking at **roughly 720** data points. That’s a lot of eye‑balling!  

Enter charting techniques that were invented to keep our sanity intact. Traditional business charts—think column, pie, area—just don’t cut it for technical analysis. The only old‑school survivor is the line chart, but even that is a bit of a one‑track mind.  

Why? Because most of those “regular” charts only display **one** data point for each moment in time. Technical analysis, however, wants to see **four** points at once. It’s like trying to watch a movie while only being shown one frame per scene – you’ll miss the plot.  

Below is the short list of chart families we’ll be chewing over:

- Line chart  
- Bar chart  
- Japanese Candlestick  

Our love‑affair in this chapter is with the Japanese Candlesticks, but before we go full‑blown “candle‑lit romance,” we’ll briefly see why line and bar charts get the short end of the stick.  

---  

## 3.2 – The Line and Bar Chart  

### The Line Chart – the “minimalist” of the bunch  

The line chart is the graphic equivalent of a stick‑figure drawing: simple, quick, and barely any detail. In practice we plot **closing prices** (or closing values of an index) as dots, then join the dots with a line.  

If you’ve got 60 days of data, you’ll end up with 60 dots connected by a single, smooth line that tells you the overall direction of the market.  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/09/M2-Ch3-Chart1.jpg)  

You can do this on any time‑frame—monthly, weekly, hourly, you name it. Want a weekly line chart? Pull the weekly closing prices and you’re good to go.  

**Pros:**  
- So simple a kindergartner could read it.  
- One glance tells you whether the market is generally up, down, or doing the “shrug” (sideways).  

**Cons:**  
- That very simplicity is also its kryptonite. By only caring about the **close**, you ignore the open, the high and the low.  
- No clue about intraday drama, gaps, or volatility.  

Because of those blind spots, many traders treat the line chart like a polite “nice to meet you” handshake—acceptable but not enough for serious conversation.  

### The Bar Chart – the “Swiss‑army‑knife” that looks a bit clunky  

Bar charts crank up the detail factor by showing **all four** price variables (OHLC) in a single vertical bar. Each bar has three parts:

1. **The central line** – the top marks the **high** of the period, the bottom marks the **low**.  
2. **Left tick** – tells you where the **open** was.  
3. **Right tick** – tells you where the **close** landed.  

Let’s walk through an example:  

- Open = **65**  
- High = **70**  
- Low = **60**  
- Close = **68**  

If you plot those numbers, the bar would look like this:  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/09/M2-ch3-diagrams-1.jpg)  

Now imagine a 5‑day chart – you’d get five of those vertical bars lined up, each whispering its own OHLC story.  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/09/M2-Ch3-Chart2.jpg)  

Notice how the left and right ticks move around depending on the day’s price action:

* **Bullish day** – open < close. The left tick (open) sits lower than the right tick (close). Traders usually colour these bars **blue** (or green) to signal “price went up.”  

  Example: O = 46, H = 51, L = 45, C = 49  

  ![Image](http://zerodha.com/varsity/wp-content/uploads/2014/09/M2-ch3-diagrams-2.jpg)  

* **Bearish day** – open > close. The left tick is higher than the right tick, and we paint the bar **red** (or black) to scream “price fell.”  

  Example: O = 74, H = 76, L = 70, C = 71  

  ![Image](http://zerodha.com/varsity/wp-content/uploads/2014/09/M2-ch3-diagrams-3.jpg)  

The length of that central line is the **range** (high – low). A long line = a big swing, a short line = a tame day.  

Even though bar charts hand you all four numbers, they’re not exactly eye‑candy. The lack of colour‑coding and the plain vertical sticks can make pattern‑spotting feel like looking for a needle in a haystack—especially when you’re juggling several charts at once.  

That’s why most modern traders skip the bar chart in favour of something a tad prettier: the Japanese Candlestick. (A few die‑hard purists still love bars, but if you’re a newcomer, start with candlesticks.)  

---  

## 3.3 – History of the Japanese Candlestick  

Before we get too cozy with those colourful candles, let’s take a quick trip to the past. The candlestick technique was **born in Japan** in the 1700s, courtesy of a rice‑trading wizard named **Homma Munehisa**. He noticed that the price of rice moved in patterns that could be visualised with a simple “body” and “wicks.”  

Fast forward a couple of centuries, and the Western world was still stuck with bar charts and line charts, blissfully unaware of this Japanese gem. Enter **Steve Nison** in the 1980s. While digging through Japanese market literature, he stumbled upon these candlestick charts, fell in love, and decided to introduce them to the West.  

Nison’s book, *Japanese Candlestick Charting Techniques*, became the bible for anyone who wanted to read market “candles” like a seasoned sommelier reads wine. The names of many patterns (e.g., “Doji,” “Hammer,” “Engulfing”) remain in Japanese, giving the whole discipline a subtle oriental flair.  

---  

## 3.4 – Candlestick Anatomy  

If the bar chart shows open and close as tiny ticks, the candlestick swaps those ticks for a **rectangular body**. The body’s colour tells you whether the market closed higher or lower than it opened:  

- **Bullish candle** – close > open → usually coloured **blue**, **green**, or **white**.  
- **Bearish candle** – close < open → usually coloured **red** or **black**.  

(You can set your own colour scheme; the software will oblige.)  

Let’s break down the three parts of any candle:  

1. **Real body** – the thick rectangle that connects the open and the close.  
2. **Upper shadow (wick)** – a thin line extending from the top of the body up to the day’s high.  
3. **Lower shadow (wick)** – a thin line dropping from the bottom of the body down to the day’s low.  

### Bullish candle example  

Suppose we have:  

- Open = **62**  
- High = **70**  
- Low = **58**  
- Close = **67**  

Plotting those numbers gives us a blue‑ish candle with a long upper wick (70 → 67) and a shorter lower wick (58 → 62).  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/09/M2-ch3-diagrams-41.jpg)  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/09/M2-ch3-diagrams-5.jpg)  

### Bearish candle example  

Now flip the script:  

- Open = **456**  
- High = **470**  
- Low = **420**  
- Close = **435**  

Because the close is below the open, the rectangle sits **above** the close and **below** the open, and we colour it red/black. The upper shadow runs from the high (470) down to the open (456), while the lower shadow stretches from the low (420) up to the close (435).  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/09/M2-ch3-diagrams-61.jpg)  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/09/M2-ch3-diagrams-7.jpg)  

#### Quick exercise  
Grab the data set below and try drawing the candles on a piece of paper (or a spreadsheet). If you get stuck, shout in the comments at the end of the chapter—no shame in asking for help!  

Once you internalise how each candle is built, spotting patterns (like “Morning Star” or “Shooting Star”) becomes as easy as spotting a red traffic light.  

Here’s a mini‑chart that strings a few candles together:  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/09/M2-Ch3-Chart3.jpg)  

The blue candles scream “buyers are in charge,” the red ones whisper “sellers are calling the shots.”  

A **long‑bodied** candle means strong buying (bullish) or selling (bearish) pressure, while a **short‑bodied** candle indicates a day of indecision or low activity.  

**Bottom line:** Candlesticks give you a quick visual shortcut to see the relationship between open/close and high/low—something bar charts do, but with a lot more flair.  

---  

## 3.5 – A Note on Time Frames  

A *time frame* is simply the slice of time you decide to inspect. Popular choices among technical analysts include:  

- **Monthly charts** – one candle = one month  
- **Weekly charts** – one candle = one week  
- **Daily (or End‑of‑Day) charts** – one candle = one trading day  
- **Intraday charts** – 30‑minute, 15‑minute, 5‑minute, even 1‑minute candles for the speed demons  

You can tailor the frame to your own style. A high‑frequency trader might obsess over 1‑minute candles, while a long‑term investor will barely glance at a weekly or monthly chart.  

| Time Frame | Candles per Day (approx.) |
|------------|--------------------------|
| 1‑minute  | 390 (typical Indian market hours) |
| 5‑minute  | 78 |
| 15‑minute | 26 |
| 30‑minute | 13 |
| 1‑hour    | 6‑7 |
| Daily     | 1 |
| Weekly    | 0.2 (≈ 1 per 5 days) |
| Monthly   | 0.04 (≈ 1 per 20‑22 trading days) |

As you shrink the time frame, the number of candles **increases**—more detail, more noise. The trick is to separate the wheat (information) from the chaff (noise).  

- **Long‑term investors**: look at weekly or monthly charts. The “noise” of daily swings is filtered out, leaving the underlying trend.  
- **Day traders** (1‑2 trades per day): end‑of‑day or 15‑minute charts give enough granularity without drowning you in data.  
- **High‑frequency traders**: 1‑minute (or even sub‑minute) charts are their playground; they thrive on the tiniest price moves.  

Choosing the right frame is **crucial** because a mis‑matched time frame can make you chase phantom patterns or miss real opportunities. In short, successful traders know when to tune out the static and focus on the signal.  

---  

### Key Takeaways from This Chapter  

- Conventional chart types (column, pie, area) can’t handle technical analysis because we need to plot **four** data points simultaneously.  
- Line charts are great for spotting the **overall trend**, but they give you **zero** insight into the day’s high, low, or opening price.  
- Bar charts show all OHLC numbers but lack visual punch, making pattern‑recognition cumbersome.  
- Candlesticks come in two flavours—**bullish** (close > open) and **bearish** (close < open)—but both share the same three‑part anatomy (body, upper shadow, lower shadow).  
- The colour of a candle is just a visual cue: bullish = blue/green/white, bearish = red/black (customisable).  
- Time‑frame selection is a make‑or‑break decision: shorter frames → more candles → more detail **and** more noise; longer frames → less noise, clearer trend.  
- As you move from monthly → weekly → daily → intraday, the **number of candles climbs** dramatically.  
- The hallmark of a good trader is the ability to **filter out noise** and focus on the information that truly matters.  

Now go forth, light up those candlesticks, and may your charts be ever in your favour!  