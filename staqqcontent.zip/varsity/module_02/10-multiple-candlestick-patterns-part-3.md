# 10. Multiple Candlestick Patterns (Part 3)

**Source:** <https://zerodha.com/varsity/chapter/multiple-candlestick-patterns-part-3/>

---

The **Morning Star** and the **Evening Star** are the final two “celestial” candlesticks we’ll explore.  
Before we can spot a Morning Star, we have to get cozy with two very common price behaviours: **gap‑up opening** and **gap‑down opening**. In chart‑speak, a *gap* (whether up or down) is what happens when a stock closes at one price one day and then opens the next day at a completely different price—no “in‑between” trades, just a jump, like a coffee‑powered rabbit.

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M2Ch10-title.jpg)

---

## 10.1 – The Gaps

### Gap‑up opening  
A gap‑up opening is the market’s way of shouting, “Buy‑me‑now, I’m excited!” Buyers are willing to pay more than yesterday’s close, so the next day the stock **opens above** the previous close.  

**Example:**  
- ABC Ltd closed Monday at **₹100**.  
- Overnight the company announced results that made analysts drool.  
- On Tuesday the market opens at **₹104** – a clean jump with **no trades** between ₹100 and ₹104.  

That’s a classic gap‑up, a bullish wink from the market. In the chart below the green arrows point to the gap‑up openings.

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M2-Ch10-chart1.jpg)

### Gap‑down opening  
Flip the script and you get a gap‑down opening: the bears are so eager to unload they’ll sell at a price **lower** than yesterday’s close.  

**Example:**  
- Same ABC Ltd, but now the quarterly report is a disaster.  
- Instead of a nice brunch, the market opens at **₹95** on Tuesday – a straight‑down jump, no trades between ₹100 and ₹95.  

That’s a gap‑down, a bearish “Get‑out‑while‑you‑can” signal. The green arrows in the next picture highlight the gap‑down openings.

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M2-Ch10-chart2.jpg)

---

## 10.2 – The Morning Star  

The **Morning Star** is a three‑day bullish reversal pattern that shows up right at the *bottom* of a downtrend. Think of it as the market’s “Good morning! I’m feeling optimistic again” after a few gloomy nights.

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M2-Ch10-chart3.jpg)

### How the three candles play out  

| Day (P) | What Happens | Why It Matters |
|--------|--------------|----------------|
| **P1** (Day 1) | A long **red** candle makes a fresh low – the bears are hammering the price. | Shows acceleration of selling; the downtrend is in full swing. |
| **P2** (Day 2) | Opens **gap‑down** (bears still confident) but then wanders around, ending as a **doji** or **spinning top**. | The indecision (doji/spin) tells us the bears are getting a little twitchy; they expected another slam‑down but got a snooze instead. |
| **P3** (Day 3) | Opens **gap‑up** and creates a solid **blue (bullish)** candle that *closes above the opening of P1*. | The bulls have taken the stage, swallowing the loss from Day 1 and often swallowing the doji’s “I‑don’t‑know‑what‑to‑do” vibe. |

If you strip away the doji on P2, P1 and P3 would look like a **bullish engulfing**—but the star gets its charm from that middle‑day hesitation.

### Trading the Morning Star  

Both the **risk‑taker** (who loves the adrenaline rush) and the **risk‑averse** (who likes a safety net) can jump in on **P3** itself—no need to wait for a fourth day confirmation. Here’s a step‑by‑step “how‑to‑order‑a‑latte‑and‑go‑long” recipe:

1. **Enter** a long position **at the close of P3** (around 3:20 PM, when the market is still fresh).  
2. **Validate** the three‑candle story:  
   - **P1** must be a **red** candle.  
   - **P2** must open **gap‑down** and end as a **doji** or **spinning top**.  
   - **P3** must open **gap‑up** and its **closing price** must be **higher than P1’s opening price**.  
3. **Set your stop‑loss** at the **lowest low** of the three‑candle pattern (the deepest trough the bears dug).  

That’s it! The market’s psychology says, “Bears got nervous, bulls are back on the dance floor—let’s ride this wave.”  

*(Side note: The bullet list repeats a bit in the original; we keep the same redundancy for fidelity.)*

- P1 should be a red candle  
- With a gap‑down opening, P2 should be either a doji or a spinning top  
- P3 opening should be a gap‑up, plus the current market price at 3:20 PM should be higher than the opening of P1  
- The lowest low in the pattern would act as a stop loss for the trade  

---

## 10.3 – The Evening Star  

The **Evening Star** is the bearish twin of the Morning Star. It appears at the **top** of an uptrend—think of it as the market sighing, “Okay, that party’s over, time to go home.”

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M2-Ch10-chart4.jpg)

### The three‑candle drama (but in reverse)

| Day (P) | What Happens | Why It Matters |
|--------|--------------|----------------|
| **P1** (Day 1) | A long **blue** candle pushes to a fresh high – the bulls are on a buying binge. | Shows buying acceleration; the uptrend is roaring. |
| **P2** (Day 2) | Opens **gap‑up** (bulls still confident) but then stalls, ending as a **doji** or **spinning top**. | The doji/spin signals that the bulls are starting to get nervous; the party is losing steam. |
| **P3** (Day 3) | Opens **gap‑down** and whips up a **red** candle that closes below P1’s opening price. | Sellers have taken over, driving the price down and making the bulls panic. |

### Trading the Evening Star  

Again, both the risk‑taker and the risk‑averse can hop on **P3** right at the close (no extra waiting required). Here’s the “short‑sell‑and‑cheer‑with‑a‑beer” checklist:

1. **Short** the stock at the **close of P3** (≈ 3:20 PM).  
2. **Confirm** the pattern:  
   - **P1** is a **blue** candle.  
   - **P2** opens **gap‑up** and finishes as a **doji** or **spinning top**.  
   - **P3** opens **gap‑down**, forms a **red** candle, and its **closing price** is **below P1’s opening price**.  
3. **Stop‑loss** goes to the **highest high** among P1‑P3 (the peak the bulls were defending).  

- P1 should be a blue candle  
- P2 should be a doji or a spinning top with a gap‑up opening  
- P3 should be a red candle with a gap‑down opening. The current market price at 3:20 PM on P3 should be lower than the opening price of P1  
- Both risk‑taker and risk‑averse can initiate the trade on P3  
- The stop loss for the trade will be the highest high of P1, P2, and P3.  

---

## 10.4 – Summarizing the entry and exit for candlestick patterns  

Before we close the chapter, let’s recap **entry** and **stop‑loss** rules for both long and short trades. (We’ll tackle **targets**—the “when‑to‑take‑profits” part—in the next chapter.)

| Trader type | When to enter | What to look for | Stop‑loss |
|-------------|---------------|------------------|-----------|
| **Risk‑taker** | **Same day** the pattern finishes (P3), around the 3:20 PM close. | All pattern rules satisfied (colour, gaps, doji/spin, price relation). | Long: **lowest low** of the pattern. <br> Short: **highest high** of the pattern. |
| **Risk‑averse** | **Next day** after the pattern, once the confirming candle appears (blue for longs, red for shorts). | Same colour‑check as above, but you wait for an extra candle to give you a safety cushion. | Same stop‑loss rule as risk‑taker. |

*Rule of thumb:* The more days a pattern spans, the more sensible it is to jump in **the same day** the pattern completes.  

- **Long trade stop‑loss** = lowest low of the three‑candle pattern.  
- **Short trade stop‑loss** = highest high of the three‑candle pattern.

---

## 10.5 – What next?  

We’ve already dissected **16** candlestick patterns. “Is that everything?” you ask.  

**Nope.** The world of candlesticks is practically infinite, but you don’t need to memorize every obscure formation. The **ultimate goal** is to internalize the *thought process* behind a candle—not just the picture on the screen.

Think of it like learning to drive. Once you know how to operate a steering wheel, clutch, and pedals, it doesn’t matter whether you’re behind a Honda, a Hyundai, or a Ford. The act of driving is the same; the car brand is just a garnish. Likewise, once you train your brain to read the market’s mood (bulls vs. bears) through candlesticks, you’ll instinctively know how to react—no matter which pattern shows up.

So, **your homework**: master the patterns we covered here (they’re the most frequent and profitable in Indian markets). As you gain experience, start building trades based on the *psychology* behind the candles rather than rote memorization. Over time, that mental model becomes your best trading ally.

### Key takeaways from this chapter  

- Star formations (Morning/Evening) always span **three trading sessions**; the middle candle (P2) is usually a **doji or spinning top**.  
- When P2 is a doji, you get a **Doji Star** (Morning Doji Star, Evening Doji Star); otherwise it’s just a **Star**.  
- **Morning Star** = bullish, appears at the **bottom** of a downtrend. Go **long on P3**; stop‑loss = pattern’s **lowest low**.  
- **Evening Star** = bearish, appears at the **top** of an uptrend. Go **short on P3**; stop‑loss = pattern’s **highest high**.  
- Both risk‑takers and risk‑averse traders are encouraged to **enter on P3** (the third candle).  
- Candlesticks are a window into the market’s collective mind. Nurture that mindset as you dive deeper into candle‑studies.  

Happy chart‑watching, and may your stars always guide you to profitable trades! 🚀📈