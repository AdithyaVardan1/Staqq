# 21. Interesting Features on TradingView  

**Source:** https://zerodha.com/varsity/chapter/interesting-features-on-tradingview/  

---  

If you haven’t heard the gossip yet, TradingView has finally slipped into Kite’s wardrobe. The beta launch was announced in a TradingQ&A post (think of it as the tech‑world’s version of “We’re getting married!”).  

Because of that, I’m going to spill the beans on a handful of my favorite TradingView (TV) tricks. If you’re fresh‑off the boat, these should help you avoid the usual “Where‑is‑the‑button?” panic. I’m **not** going to re‑hash the obvious chart‑drawing tools – those are as intuitive as a coffee‑order at a café. Instead, I’ll focus on the quirky, off‑the‑beaten‑path features that make TV feel like a Swiss‑army knife for chart junkies.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2014/09/M2-Ch4-title.jpg)  

## 21.1 Multi‑timeframe Settings  

This isn’t a TV‑exclusive superpower, but the platform definitely makes it smoother than most. You’ve probably already fiddled with layout options, so let’s jump straight into a scenario.  

Imagine you’re eyeing **IndiGo** for a quick intraday swing. Before you smash that “Buy” button, you’d love to see how the stock looks on a 1‑day chart, a 30‑minute chart, and a 15‑minute chart – all at once. The usual method is to keep swapping the timeframe dropdown, which feels like playing “musical chairs” with your mouse.  

Enter TV’s multi‑chart layout: you get a simultaneous, side‑by‑side view of the same ticker on three different clocks. Here’s the “how‑to” –  

1. Click **Select Layout** in the top‑right corner (it looks like a tiny grid).  
2. Choose a layout that fits your brain‑space. I like three charts, so I hit the three‑panel option.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2019/03/Image-1_TV.png)  

Boom! You now have three identical charts, all showing IndiGo’s 1‑day candle.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2019/03/Image-2_layout.png)  

Notice the left‑most chart is framed in blue – that’s the *active* pane.  

Now, let’s give each pane its own personality:  

- **Left pane:** 15‑minute – the one you’ll actually trade on.  
- **Top‑right pane:** 30‑minute – a nice “medium‑range” perspective.  
- **Bottom‑right pane:** 1‑day – the big‑picture trend.  

To change a pane’s timeframe, click inside it (the blue border re‑appears) and hit the timeframe dropdown. The red arrow in the screenshot below points to that little menu.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2019/03/Image-3_load.png)  

Now you’ve got a three‑panel “price‑action movie” playing at once.  

### Why it’s cool  

* **Cross‑hair sync** – move the cross‑hair over any price level and it jumps across all panes simultaneously.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2019/03/image-4_ch.png)  

That visual cue lets you instantly see whether a 15‑minute spike is just noise or part of a larger daily swing.  

* **Toggle‑full‑screen** – need to zoom into the 15‑minute chart for a deep‑dive? Hit the little toggle button in the bottom‑right corner and that pane balloons to fill the screen, while the other two take a coffee break.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2019/03/image-5_toggle.png)  

* **Pane‑specific annotations** – suppose your daily chart is whispering “double‑top” in your ear. You can drop a text note *only* on that pane, keeping the intraday charts clean.  

  1. Click the **Text** tool (looks like a “T”).  
     
     ![Image](https://zerodha.com/varsity/wp-content/uploads/2019/03/Image-6_text.png)  

  2. Click anywhere on the daily pane, type something like “⚠️ Double‑top? Prepare shorts.”  

     ![Image](https://zerodha.com/varsity/wp-content/uploads/2019/03/image-7_annotate.png)  

That’s the multi‑timeframe magic, and it’s a lifesaver for anyone who trades intra‑day but still wants to keep an eye on the longer trends.  

## 21.2 Undo‑Redo  

Ever drawn a trend line that looks more like a toddler’s scribble than a technical analysis tool? (Picture a line that says, “I’m just here for the free pizza.”)  

On most platforms you’d have to hunt down that line, right‑click → Delete, or even go into a “drawing manager.” TV keeps it simple: **Ctrl + Z** (or click the Undo button) erases your most recent mistake in a flash.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2019/03/Image-8_undo.png)  

Just remember: Undo only rolls back the *last* action, so if you accidentally erased a whole bunch of work, you’ll have to redo them manually. Still, it’s a huge time‑saver compared to the “select‑and‑delete‑forever” dance on other charting tools.  

## 21.3 Visibility  

Visibility settings are the unsung heroes of clean‑charting. Imagine you’ve plotted a Fibonacci retracement on a daily chart to spot a potential 61.8 % bounce. You then flip to an hourly view, and that same retracement clutters the screen, looking about as useful as a snow‑shovel in the Sahara.  

TV lets you lock a drawing to a specific timeframe. Here’s a quick demo:  

1. Draw a Fibonacci on the daily chart.  

   ![Image](https://zerodha.com/varsity/wp-content/uploads/2019/03/image-9_fib-retracement.png)  

2. Switch to the hourly chart – the retracement stubbornly follows you.  

   ![Image](https://zerodha.com/varsity/wp-content/uploads/2019/03/Image-10_hr.png)  

3. Double‑click the Fibonacci line → **Settings** → **Visibility** tab.  

   ![Image](https://zerodha.com/varsity/wp-content/uploads/2019/03/Image-11_vis.png)  

4. Tick only the timeframe(s) where you want it to appear (e.g., “D” for daily).  

Now when you hop to a 15‑minute or hourly view, the Fibonacci disappears like a magician’s rabbit, leaving your chart tidy and relevant.  

## 21.4 Go‑to Date  

Ever needed to answer the classic interview question: “What was the price of Infosys at 12:30 PM on 2 Jan 2019?” (Spoiler: It wasn’t “I don’t know”). Scrolling back manually is like looking for a needle in a haystack while the haystack is on a treadmill.  

TV’s **Go‑to** box solves that. It lives at the bottom of the chart and lets you type a date, time, or even a bar number, and *bam* you’re there. No more endless dragging.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2019/03/Image-12_goto.png)  

For example, I typed “Mar 5 2020 12:15” and instantly landed on that exact candle:  

![Image](https://zerodha.com/varsity/wp-content/uploads/2019/03/Image-13_gototime-1024x759.png)  

You can even paste a timestamp from an external source and TV will zip you right there. Handy for back‑testing, audit trails, or just impressing your friends with “I know exactly when the stock dipped.”  

## 21.5 HD Images  

You’ve spent an hour crafting a masterpiece chart: multiple indicators, a couple of trendlines, and a witty annotation (“Buy the dip, not the dip‑stick”). Now you want to share it on WhatsApp, Slack, or tweet it, but the screenshot looks pixelated, like it was taken through a frosted glass.  

TV’s **Alt + S** shortcut snaps a high‑resolution PNG that’s crisp enough to make your grandma think you’re a professional analyst.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2019/03/Image-14_image.png)  

After pressing the hotkey, a dialog pops up offering to **Save** the image locally or **Tweet** it straight from the platform. No more “blurry‑chart‑of‑the‑day” memes.  

---  

I’ll keep this chapter open for future discoveries – the TV universe is constantly adding new tricks. If you stumble upon a hidden gem, drop a comment below and share the love.  

**Happy trading, and may your charts always be in your favor!**  