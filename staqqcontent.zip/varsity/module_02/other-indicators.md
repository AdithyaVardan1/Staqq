# 20. Other indicators  

**Source:** https://zerodha.com/varsity/chapter/supplementary-notes-1/  

---  

##  

![Image](http://zerodha.com/varsity/wp-content/uploads/2016/02/SN-Cartoon2.png)  

## Average Directional Index (ADX)  

**About:**  
The Average Directional Index (ADX) together with the Minus Directional Indicator (‑DI) and the Plus Directional Indicator (+DI) are a trio of “directional movement” tools cooked up by the legendary Welles Wilder. Think of ADX as the bouncer at the club – it tells you how **strong** the crowd (trend) is, but it doesn’t care whether they’re dancing to “buy‑buy‑buy” or “sell‑sell‑sell”. The +DI and –DI are the bouncer’s side‑kicks that actually point out which side of the floor the crowd is moving toward. Use them together and you’ll know both **how loud** the party is *and* which way the DJ is spinning.  

**What should you know?**  

- The ADX system has three buddies – **ADX**, **+DI**, and **‑DI**.  
- **ADX** only measures *strength* of a trend. It’s a “how‑hard‑is‑it‑shaking” meter, not a “which‑way‑is‑it‑going” compass.  
- **Thresholds:**  
  - **ADX > 25** → The trend is flexing its muscles (strong).  
  - **ADX < 20** → The trend is a sleepy kitten (weak).  
  - **20 ≤ ADX ≤ 25** → The market is in a “meh” zone – you’re better off sipping your drink.  
- **Buy signal:** ADX ≥ 25 **and** **+DI** crosses **‑DI** from below (the plus line steals the show).  
- **Sell signal:** ADX ≥ 25 **and** **‑DI** crosses **+DI** from below (the minus line takes the floor).  
- **Once the crossover happens**, lock in the trade with a stop‑loss:  
  - **Longs:** Use the *low* of the signal candle.  
  - **Shorts:** Use the *high* of the signal candle.  
- The trade lives on until the stop‑loss is hit – even if the DI lines do a quick tango later on.  
- **Default look‑back:** 14 periods (days, bars, whatever you’re charting).  

**On Kite:**  
1. Pop open the *Studies* menu and pull in **ADX**.  
2. Kite lets you tweak the look‑back; the default is 14, but feel free to experiment.  

![Image](http://zerodha.com/varsity/wp-content/uploads/2016/02/Image-1_ADX1.png)  

You can also paint the three lines any colour you like – why not match your favorite cocktail? Click **Create** to summon the indicator.  

![Image](http://zerodha.com/varsity/wp-content/uploads/2016/02/Image-2_ADX_loaded.png)  

By default ADX sits underneath the price chart. The black line is the ADX itself – keep an eye on it staying above 25 while you watch the +DI / –DI dance.  

---  

## Alligator Indicator  

**About:**  
Bill Williams invented the Alligator to illustrate how markets behave like a sleepy reptile. When the Alligator snoozes, the market is flat‑lined. When it wakes up, the jaws, teeth and lips snap open and the price starts chomping. The longer the beast nap‑s, the hungrier (and more ferocious) the next move.  

**What should you know?**  

- The Alligator lives **on top of the price chart** (no need for a separate pane).  
- It’s made of **three simple moving averages (SMAs)**:  
  - **13‑period SMA** = **Jaw** (the big, lazy mouth) – default blue.  
  **-** **8‑period SMA** = **Teeth** (the sharp part) – default red.  
  **-** **5‑period SMA** = **Lips** (the cute front) – default green.  
- **Buy signal:** All three SMAs are nicely **separated** and the hierarchy is:  
  `Price > 5‑MA > 8‑MA > 13‑MA`  
  This tells you the Alligator is *awake* and **chewing upward**. Your job is to jump in somewhere on that up‑trend.  
- **Sell signal:** Same separation but reversed:  
  `Price < 5‑MA < 8‑MA < 13‑MA`  
  Now the beast is chewing **downward** – look for shorting opportunities.  
- When the three lines **bunch together** (or move flat), that’s the **“no‑trader zone.”** The Alligator is either half‑asleep or just taking a nap – better stay out of the market.  

> **TL;DR:** “If the jaws, teeth and lips are all over the place, the market’s asleep. If they’re nicely spaced, the market’s chewing. Eat accordingly!”  

**On Kite:**  
Select **Alligator** from *Studies*. The default SMA periods (13, 8, 5) and their “offsets” (a little shift to smooth whipsaws) load automatically. You can tinker with the periods, offsets, or colour scheme – make it look as snazzy as you want.  

![Image](http://zerodha.com/varsity/wp-content/uploads/2016/02/Image-3_Aligator_load.png)  

Below is a screenshot of the Alligator overlaid on a chart. Red boxes flag the *sell* conditions, the blue box flags a *buy* condition.  

![Image](http://zerodha.com/varsity/wp-content/uploads/2016/02/Image-4_aligator-overlay.png)  

---  

## Aroon  

**About:**  
Created by Tushar Chande in 1995, the Aroon family (Aroon‑Up & Aroon‑Down) is named after the Sanskrit word for “dawn’s early light.” Why? Because it tries to catch the *first glimpse* of a new trend. Unlike most oscillators that look at *price momentum*, Aroon looks at **time** – how many bars have passed since the last high or low.  

- **Aroon‑Up (25)** = days since the most recent 25‑day high.  
- **Aroon‑Down (25)** = days since the most recent 25‑day low.  

If the market just made a new high, the Up line shoots toward 100 while the Down line plummets toward 0 – a classic sunrise.  

**What should you know?**  

- The indicator tells you **how many periods** have elapsed since the last high/low – it’s a *time‑relative* gauge.  
- Two components: **Aroon‑Up** and **Aroon‑Down** (plotted side‑by‑side).  
- **Default length:** 25 periods (you can change it).  
- **Scale:** 0 → 100 (0 = “it’s been forever,” 100 = “just happened”).  
- **Buy cue:** Aroon‑Up > 50 **and** Aroon‑Down < 30 → the market is fresh‑out‑of‑a‑high, bullish vibes.  
- **Sell cue:** Aroon‑Down > 50 **and** Aroon‑Up < 30 → fresh‑out‑of‑a‑low, bearish vibes.  

**On Kite:**  

![Image](http://zerodha.com/varsity/wp-content/uploads/2016/02/Image-5_aroon-load.png)  

The default period shown is **14** (just a different taste of “days”). Feel free to crank it up or down – remember the number reflects “how many bars back you’re looking for that high/low.”  

![Image](http://zerodha.com/varsity/wp-content/uploads/2016/02/Image-6_Aroon-applied.png)  

Both lines appear together, making it easy to spot those sunrise‑like crossovers.  

---  

## Aroon Oscillator  

The Aroon Oscillator is the **difference** between Aroon‑Up and Aroon‑Down, plotted as a classic oscillator that swings between **‑100** and **+100** with a zero line in the middle.  

- **Positive** values → Up‑trend dominance (new highs are fresher than new lows).  
- **Negative** values → Down‑trend dominance (new lows are fresher).  

Because it’s simply *Up minus Down*, the chart is usually either above zero or below zero – you rarely get a “flat‑line” situation.  

> **Quick tip:** Anything above **+50** is a *strong* up‑trend, below **‑50** is a *strong* down‑trend.  

![Image](http://zerodha.com/varsity/wp-content/uploads/2016/02/Image-7_Aroon-Osc.png)  

---  

## Average True Range (ATR)  

**About:**  
J. Welles Wilder (the same wizard behind ADX) introduced **Average True Range (ATR)** to capture **volatility**. He built it for commodities, which love gaps and limit moves. A plain high‑low range would miss those dramatic jumps, so Wilder added the “True Range” concept and then averaged it.  

**What should you know?**  

- **ATR =** smoothed version of **True Range** (the biggest of today’s high‑low, yesterday’s close‑to‑today’s high, or yesterday’s close‑to‑today’s low).  
- **No fixed bounds:** One stock might have ATR ≈ 1.2, another might sit at ATR ≈ 150.  
- **It tells you *how much* a price likes to wiggle, not *which way* it wiggles.**  
- **Stop‑loss utility:**  
  - Suppose **ATR = 48** for a stock priced at **₹1,320**. Expect the price to wander roughly **₹48** up or down on an average day. So the expected daily band is **₹1,272 – ₹1,368**.  
  - If tomorrow ATR drops to **40**, the expected range contracts accordingly.  
- **Practical stop‑loss rule:**  
  - Long entry at **₹1,325** → place SL ≤ **₹1,272** (current price – ATR).  
  - Short entry at **₹1,320** → place SL ≥ **₹1,368** (current price + ATR).  
  - If those SL levels are too far for your risk‑/‑reward appetite, skip the trade.  

**On Kite:**  
Default ATR period is **14** (last 14 bars). Change it if you fancy a shorter or longer volatility window.  

![Image](http://zerodha.com/varsity/wp-content/uploads/2016/02/Image-8_ATR_load.png)  

Once added, ATR appears below the price pane:  

![Image](http://zerodha.com/varsity/wp-content/uploads/2016/02/Image-9_ATR_create.png)  

Next time you set a stop‑loss, glance at the ATR – it’s your volatility‑aware safety net.  

---  

## Average True Range Band  

ATR Bands are essentially **ATR + a moving average envelope** – think of them as Bollinger‑style bands but powered by volatility rather than standard deviation.  

**What should you know?**  

1. **Compute a moving average (MA)** of the price (usually the close).  
2. **Upper band = MA + ATR**  
3. **Lower band = MA – ATR**  
4. If price **breaks above the upper band**, the market often *keeps* moving up (the trend has momentum).  
5. If price **breaks below the lower band**, the market often *keeps* moving down.  
6. You can treat ATR Bands as a **volatility‑adjusted alternative** to Bollinger Bands.  

**On Kite:**  

![Image](http://zerodha.com/varsity/wp-content/uploads/2016/02/Image-10_ATRB_load.png)  

- **Period** = MA length (default **5**). Feel free to use 20, 30, whatever feels right.  
- **Shift** = usually left at 0 (ignore it unless you’re a masochist).  
- **Field** = choose *Close* to base the MA on closing prices.  
- The rest are just cosmetic knobs. Hit **Create** and watch the bands appear.  

![Image](http://zerodha.com/varsity/wp-content/uploads/2016/02/Image-11_ATRbands_created.png)  

---  

## Super Trend  

The **Super Trend** is a trend‑following overlay that leans on ATR for its calculations. It paints a **green/red line** over the price chart, switching colour whenever the price flips relative to the line.  

**What should you know?**  

- **Look:** a continuously changing green‑and‑red line that hugs the price.  
- **Buy trigger:** price crosses **above** the Super Trend line → line turns **green**. Think “price just jumped the fence, let’s chase it.”  
- **Hold the long** until price **closes below** the green line (the line now acts as a trailing stop).  
- **Sell/short trigger:** price drops **below** the line → line turns **red**.  
- **Hold the short** until price **closes above** the red line (again, a trailing stop).  
- Works best in **trending markets** – it’s not a crystal ball for sideways choppy action.  
- Compared with a plain Moving‑Average system, Super Trend generally gives **fewer false signals** – fewer “oops‑I‑was‑wrong” moments.  

**On Kite:**  

![Image](http://zerodha.com/varsity/wp-content/uploads/2016/02/Image-12_supertrend-load.png)  

- **Period** = ATR look‑back (default **7**).  
- **Multiplier** = how many ATR units to pad the line (default **3**).  
  - **Higher multiplier** → fewer signals (safer, but you might miss some moves).  
  - **Lower multiplier** → more signals (spicier, but more whipsaws).  
  - Most traders stick with **3‑4**.  

When plotted, the line flips colour as price dances around it, and **green/red arrows** pop up at each crossover to remind you “Hey, time to go long!” or “Hey, time to go short!”  

![Image](http://zerodha.com/varsity/wp-content/uploads/2016/02/Image-13_supertrend_create.png)  

---  

## Volume‑Weighted Average Price (VWAP)  

VWAP is the **simplest yet surprisingly powerful** intraday gauge. It answers the question: *If I weighed every trade by its size, what would the average price be?*  

**How it’s built (quick math):**  

1. **Typical price** for each bar = (High + Low + Close) ÷ 3.  
2. **Volume × Typical price** = **Volume Price (VP)** for that bar.  
3. **Cumulative VP** = sum of all VPs up to the current bar.  
4. **Cumulative Volume** = sum of all volumes up to the current bar.  
5. **VWAP** = Cumulative VP ÷ Cumulative Volume.  

**Example (Infosys, 14:30‑14:35 Nov 2 2016):**  

![Image](http://zerodha.com/varsity/wp-content/uploads/2016/11/Image-14_VWAP.png)  

At 14:32, 2,475 shares changed hands at a high of ₹983.95, low of ₹983.00, closing at ₹983.10. Plug the numbers into the steps above and you get the VWAP shown in the next screenshot.  

![Image](http://zerodha.com/varsity/wp-content/uploads/2016/11/Image-15_VWAP.png)  

VWAP is **dynamic** – it moves as volume flows in.  

**How to use VWAP:**  

- **Intraday only** – apply it on minute‑level charts.  
- Expect a **jump at 9:15 AM** (the first minute of the session). It’s just the market waking up, ignore it.  
- Like any average, VWAP **lags** a bit behind the latest price.  
- **Two primary uses:**  
  1. **Direction gauge:**  
     - **Price < VWAP** → market is generally **below** the average – bearish bias.  
     - **Price > VWAP** → market is generally **above** the average – bullish bias.  
  2. **Execution efficiency:**  
     - If you **short** above VWAP, you’re selling at a “good” price (above the average).  
     - If you **long** below VWAP, you’re buying at a “good” price (below the average).  
- If price sits **inside** the day’s high‑low range with VWAP smack‑in‑the‑middle, expect **choppy** action.  

**On Kite:**  

1. Open any intraday chart (1‑min, 5‑min, 10‑min, …).  
2. Choose **VWAP** from the *Studies* dropdown.  

![Image](http://zerodha.com/varsity/wp-content/uploads/2016/11/Image-16_VWAP.png)  

VWAP only works on intraday data – you can’t apply it to daily‑close charts. Once you select a time‑frame, Kite does the heavy lifting and draws VWAP as an overlay.  

![Image](http://zerodha.com/varsity/wp-content/uploads/2016/11/Image-17_VWAP.png)  

Now you can see where the price sits relative to the volume‑weighted average and make your trade‑decision with a dash of statistical flair.  

---  

*And there you have it – a full‑blown, witty tour of the “Other Indicators” chapter. Feel free to experiment, tweak the colours, and maybe name your own Alligator or Super Trend after your favorite pet. Happy charting!*