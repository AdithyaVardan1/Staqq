# 13. Moving Averages  

**Source:** https://zerodha.com/varsity/chapter/moving-averages/

---  

We all survived the “average” lesson in school—remember that boring moment when the teacher asked you to add up a bunch of numbers and then divide by how many you had?  Well, a **moving average** is just that same old trick, but with a little extra cardio.  It drags the window of data forward, “moves,” and gives you a smoothed‑out trend line that many traders love because it’s simple, intuitive, and (most importantly) it makes you look smart in the office break‑room.  Before we dive into the moving‑average party, let’s quickly refresher‑course the basic average formula.  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M2-Ch13-title.jpg)  

### The “Beach‑Bottles” Analogy  

Picture five friends lounging on a sun‑kissed beach, each clutching a frosty bottled drink.  By the end of the day the total number of empty bottles scattered on the sand is **29**.  A curious passer‑by (let’s call him the 6th person) wants a quick guess of how many each buddy gulped, so he does the classic average:

\[
\text{Average bottles per person}= \frac{29\text{ bottles}}{5\text{ friends}} = 5.8\text{ bottles}
\]

That 5.8 tells us “roughly” how much each person drank, but we all know the reality:  
- **Person E** polished off **8** bottles – a clear above‑average guzzler.  
- **Person D** managed only **3** – a below‑average sipper.  

The average is just a *ballpark* figure; it can’t capture the outliers.  

### From Beach Drinks to Stock Prices  

Swap the beach for the stock exchange and the bottles for closing prices.  Here are the last five closing prices of **ITC Limited**:

| Day | Close (₹) |
|-----|-----------|
| ‑  | 1700 |
| ‑  | 1730 |
| ‑  | 1760 |
| ‑  | 1680 |
| ‑  | 1730 |
| **Total** | **1719.75** |

The 5‑day simple average is:

\[
\frac{1719.75}{5}= 343.95
\]

So the average closing price for ITC over the past five sessions is **₹ 343.95**.  Simple, right?  

---  

## 13.1 – The “Moving” Average (a.k.a. Simple Moving Average, SMA)

Now imagine you want the average closing price of **Marico Ltd.** for the most recent five sessions.  The data looks like this:

| Date | Close (₹) |
|------|-----------|
| 21 Jul | 1200 |
| 22 Jul | 1220 |
| 23 Jul | 1215 |
| 24 Jul | 1225 |
| 25 Jul | 1215 |
| **Total** | **1212.3** |

The 5‑day SMA is:

\[
\frac{1212.3}{5}= 242.46\;(\text{≈ 242.5})
\]

**Fast‑forward one day** to **28 July** (the weekend of 26‑27 July is ignored because the market is closed).  Our new five‑day window is now **22‑23‑24‑25‑28 Jul**; we drop the 21 Jul point:

\[
\frac{1223.3}{5}= 244.66
\]

That’s the updated SMA.  Notice the pattern? Each day we **add** the newest price and **subtract** the oldest one, keeping the window size constant.  That’s why it’s called a **moving** average!  

A couple of quick footnotes:  

- **What we average:** Typically the *closing* price because that’s the price the market finally settles on for the day.  You *can* use high, low, or open, but close is the crowd‑favorite.  
- **Time‑frames:** Anything from a 1‑minute SMA for high‑frequency traders to a 200‑day SMA for long‑term investors.  Your charting platform will let you pick what you need.  

If you love Excel (or just love pretending you’re a data scientist), you’ll see the formula’s cell references slide over as the window moves, automatically dropping the oldest value and pulling in the newest.  The result is a **smooth curving line**—the **SMA line**—that trails the price chart.

Below is a 5‑day SMA over **ACC’s** candlestick chart (just for visual flair).  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M2-Ch13-chart1.jpg)

So, what can you actually *do* with this line?  Plenty!  But before we go full‑blown “trader‑guru,” let’s meet its cooler cousin: the **Exponential Moving Average (EMA).**  

---  

## 13.2 – The Exponential Moving Average (EMA)

Take the same set of price points we used earlier.  When we compute a plain SMA we **implicitly give every data point the same weight**—the price on **22 Jul** is treated as important as the price on **28 Jul**.  In the chaotic world of markets, that assumption is a bit naïve.  

Remember the golden rule of technical analysis: **“Markets discount everything.”**  In other words, the most recent price already incorporates all known and unknown information up to that moment.  So the price on **28 Jul** should be considered *more* important than the price on **25 Jul**, which in turn is more important than the price on **22 Jul**, and so on.  

Enter the EMA, which **assigns higher weight to newer data** and progressively lower weight to older data.  The newest price gets the biggest slice of the pie, the oldest gets the crumbs.  The math behind the weighting factor (the “smoothing constant”) is a little fiddly, but most charting packages let you drop an EMA onto a chart with a single click—so you can mostly ignore the algebra and focus on the *application*.  

Here’s a visual comparison of a **50‑day SMA** (black) versus a **50‑day EMA** (red) on **Cipla Ltd.**  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M2-Ch13-chart2.jpg)

Notice how the EMA hugs the price action more tightly.  Because it reacts faster to recent moves, the EMA can give you a *head‑start* on a trade, which is why many traders give it the VIP seat over the SMA.  

---  

## 13.3 – A Simple (and Slightly Silly) Application of Moving Averages  

The core idea is straightforward:  

- **Price > MA** → the market is **bullish** (people are willing to pay more than the average).  
- **Price < MA** → the market is **bearish** (people are willing to sell for less than the average).  

From those two statements you can craft a **basic trading system**—a set of mechanical rules that tell you when to jump in and when to hop out.  

### The 50‑Day EMA System  

1. **Buy (go long)** when the current price **crosses above** the 50‑day EMA.  Once you’re in, stay put until the opposite signal appears.  
2. **Exit (square off)** when the price **falls back below** the 50‑day EMA.  

Let’s see it in action on **Ambuja Cement** (black line = 50‑day EMA).  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M2-Ch13-chart3.jpg)

**Trade walk‑through:**  

| Trade | Entry (₹) | Exit (₹) | P/L (₹) |
|-------|-----------|----------|---------|
| B1 → S1 | 165 | 187 | **+22** |
| B2 → S2 | 178 | 182 | **+4** |
| B3 → S3 | 165 | 215 | **+50** |

- **B1@165 → S1@187:** The price jumps above the EMA, we go long, and later exit at 187 for a tidy **₹ 22** profit.  
- **B2@178 → S2@182:** A modest **₹ 4** gain—still positive, but the market was wobbling sideways.  
- **B3@165 → S3@215:** The *big winner*—a **₹ 50** windfall because the stock rode a solid up‑trend.  

**What does this tell us?**  

- Moving‑average systems **shine in trending markets** (first and third trades).  
- In a **range‑bound (sideways) market**, they churn out a lot of small, sometimes loss‑making signals (second trade).  

### Lessons from the Trenches  

- **Signal overload:** In a choppy market you’ll get many buy/sell cues, most of which are pennies.  
- **One big winner can cover the rest:** A single strong trend can wipe out the numerous tiny losses.  
- **Don’t cherry‑pick:** The system works best when you **take every signal** it gives you.  
- **Trend‑following:** Because the MA sticks to the trend, it can also act as a *proxy* for finding long‑term investment ideas.  

Take **BPCL** as another example.  The plain‑vanilla MA gave a handful of signals during a flat market—most were losers, but the final trade delivered a **67 %** gain over five months.  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M2-Ch13-chart4.jpg)

---  

## 13.4 – Moving‑Average Crossover System (The “Less‑Noisy” Upgrade)

The plain‑vanilla system is great, *until* you realize it’s spitting out **too many** signals during sideways markets.  The cure? **Crossover**—use **two** moving averages of different lengths, and only trade when they cross.  This “smoothing” reduces noise and cuts down on whipsaws.  

### Fast vs. Slow  

- **Fast MA** (e.g., 50‑day EMA) – reacts quickly because it averages fewer data points.  
- **Slow MA** (e.g., 100‑day EMA) – reacts slower because it looks at a longer history.  

When the fast line **crosses above** the slow line, the market is turning bullish; when it **crosses below**, the trend is turning bearish.  

### Visual Example – Bank of Baroda  

| Line | Period | Color |
|------|--------|-------|
| Fast EMA | 50 days | Black |
| Slow EMA | 100 days | Pink |

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M2-Ch13-chart5.jpg)

You can see the black line hugging the price more tightly, while the pink line lags behind.  

### Crossover Rules  

1. **Buy** when the **fast MA** moves **above** the **slow MA**. Stay in the trade as long as the fast stays on top.  
2. **Exit** when the **fast MA** drops **below** the **slow MA**.  

Applying this to the earlier **BPCL** chart (single 50‑day MA on the left), you’ll notice that the crossover system **ignores** the three little losers and only catches the big winner.  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M2-Ch13-chart6.jpg)

Now overlay the **50‑day** (black) and **100‑day** (pink) EMAs on the same chart:  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M2-Ch13-chart7.jpg)

The arrow marks the exact moment the fast EMA **crosses** the slow EMA.  From that point onward, the system stays out of the three unprofitable trades we saw earlier.  **That’s the power of the crossover:** fewer signals, higher probability of each being a winner.  

### Popular Fast/Slow Combos  

| Fast | Slow | Typical Use‑Case |
|------|------|------------------|
| 9‑day EMA | 21‑day EMA | Ultra‑short swing (a few sessions) |
| 25‑day EMA | 50‑day EMA | Short‑to‑mid swing (weeks) |
| 50‑day EMA | 100‑day EMA | Medium‑term (months) |
| 100‑day EMA | 200‑day EMA | Long‑term (years, even “buy‑and‑hold”) |

**Rule of thumb:** The *longer* the pair, the *fewer* the signals—perfect for investors who hate constant alerts.  

### A Quick 25‑×‑50 EMA Crossover Example  

Three clean crossovers appear on the chart below, each generating a trade signal.  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M2-Ch13-chart8.jpg)

### Intraday Twist  

Crossover isn’t just for daily charts.  You can shrink the periods to minutes:  

- **15‑minute vs. 30‑minute EMA** → intraday scalping.  
- **5‑minute vs. 10‑minute EMA** → aggressive day‑trading.  

Just remember: the shorter the timeframe, the more *noise* you’ll encounter, so you may need tighter risk controls.  

> “The trend is your friend.”  
> — Every market veteran ever  

Moving averages are essentially a **friend‑locator** that points you toward that trend.  As long as a trend exists, the MA family (SMA, EMA, crossovers) will serve you well.  Pick the timeframe and combination that matches your personality, and you’ll have a solid, rule‑based companion for the markets.  

---  

### Key Takeaways (aka “What to Remember After the Drink”)  

- **Average** = quick, rough estimate of a set of numbers.  
- **Moving average** = average where you **add the newest** data point and **drop the oldest** as the window slides.  
- **Simple Moving Average (SMA)** treats every data point equally.  
- **Exponential Moving Average (EMA)** gives *more weight* to recent data, less to older data.  
- **Practical tip:** Use EMA over SMA for most trading because it reacts faster.  
- **Bullish signal:** Price > EMA. **Bearish signal:** Price < EMA.  
- **Sideways markets** → MA lines can cause “whipsaws” (many tiny losses).  Mitigate with an **EMA crossover** system.  
- **Crossover system:** Two EMAs (fast & slow).  Fast crossing above slow = **buy**, fast crossing below slow = **sell**.  
- **Longer timeframes** → **fewer** signals, **more** “set‑and‑forget” vibe.  

Now go forth, plot those lines, and may your trends be ever in your favor! 🍻  