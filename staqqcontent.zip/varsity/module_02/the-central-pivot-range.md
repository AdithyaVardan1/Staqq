# 22. The Central Pivot Range  

**Source:** <https://zerodha.com/varsity/chapter/the-central-pivot-range/>  

---  

## 22.1 Trade from charts  

If you’ve ever spent a night scrolling through Zerodha’s trading terminal, **Kite**, you already know you can flip between two heavyweight charting engines: **TradingView** and **ChartIQ**. Think of them as the “Ferrari” and the “Lamborghini” of chart‑tech—both insanely fast, both free (thanks to your Zerodha subscription).  

### Why ChartIQ just got a makeover  

The latest ChartIQ update dropped a whole toolbox of new studies that would make a quant’s eyes sparkle. Here are a few of the goodies:  

- Candlestick Patterns  
- Stochastic RSI  
- RSI Divergence  
- MACD Divergence  
- Stochastic Divergence  
- **Central Pivot Range (CPR)**  
- **Trade from Chart**  

My personal favourites are the candle‑pattern detector, the CPR, **and** the “Trade from Chart” button—so let’s dive into why they’re worth a few extra sips of coffee.  

### Getting the “Trade from Chart” button on  

1. Open Kite and click your avatar (the little profile pic in the top‑right).  
2. Choose **ChartIQ** as the chart provider.  

![ChartIQ profile selection](https://zerodha.com/varsity/wp-content/uploads/2020/07/Image0_ciq.png)  

Now pull up any instrument from your Market Watch.  

![Open a chart from market watch](https://zerodha.com/varsity/wp-content/uploads/2020/07/Image-1_tfc.png)  

On the chart’s top‑right you’ll spot a **Trade** button—looks like a tiny lightning bolt. Click it and—*voilà*—a floating order window appears.  

![Floating order window](https://zerodha.com/varsity/wp-content/uploads/2020/07/Image-2_tfc.png)  

This floating window is the trader’s Swiss‑army knife. Drag it to any price level you like, drop it, and you can instantly fire a **Buy**, **Sell**, **CNC** (delivery) or **MIS** (intraday) order—right from the chart. No need to hop back to Market Watch, no more “where did that price go?” moments.  

#### Real‑life demo: Ashok Leyland  

Take a look at the Ashok Leyland 15‑minute chart below. The stock has been meandering sideways for the past couple of sessions—think of a lazy river with a few eddies. If it breaks out above the range (around ₹45), that’s a classic “buy‑the‑breakout” signal.  

![Ashok Leyland chart](https://zerodha.com/varsity/wp-content/uploads/2020/07/Image-3_buy.png)  

I’m eyeing a buy around **₹45.40**—the price where I think momentum will kick in. I simply drag the floating order box up to that level, click “Buy,” and the trade is placed. The current market price (CMP) is shown in a red background (₹42.45 at the time of the screenshot), so you instantly see the distance you’re covering.  

**Why this matters:**  

- **Focus** – No more bouncing between windows; you stay glued to the price action.  
- **Speed** – In a volatile breakout, seconds count; dragging and clicking is faster than typing a price.  
- **Clarity** – The floating box visually marks the exact level you intend to trade, reducing “I thought I clicked at 45.4 but I actually hit 45.2” errors.  

Give it a spin—you’ll feel like you’ve got a cheat code for chart‑centric trading.  

---  

## 22.2 Candlestick Pattern  

ChartIQ’s newest update also bundles a **Candlestick Pattern** detector. Think of it as a robotic Sherlock Holmes that scans the chart and shouts, “Elementary, my dear trader—this is a bullish engulfing!”  

### Turning the detector on  

1. Click the **Studies** button (the beaker‑icon).  
2. Choose **Candlestick Pattern** from the list.  

![Enable candlestick pattern study](https://zerodha.com/varsity/wp-content/uploads/2020/07/Image-4_csp.png)  

Once activated, ChartIQ automatically tags recognized patterns on the chart.  

![Pattern identification on chart](https://zerodha.com/varsity/wp-content/uploads/2020/07/Image-5_iden.png)  

You can see the markers on an end‑of‑day (EOD) chart, but they work just as well on intraday timeframes.  

### The cautionary tale  

The AI is great at spotting shapes, but it’s a bit **trend‑blind**. Candlestick analysis is like reading a novel—knowing the previous chapter (the prior trend) is crucial. For example, an engulfing pattern that appears in a **downtrend** might be a false alarm, whereas the same pattern in an **uptrend** could be a genuine reversal signal.  

#### Example: Hanging‑Man vs. Engulfing  

- **Hanging‑Man**: Usually appears at the top of an uptrend and signals potential weakness—ChartIQ will flag it correctly, and you can trust it.  
- **Three‑Bar Engulfing**: The engine will label it, but if the prior trend is missing, you could end up chasing a phantom.  

**Bottom line:** Use the detector as a **confirmation tool**, not as the sole decision‑maker.  

### A practical workflow  

1. **Do your own analysis**—look at trend, volume, support/resistance, etc.  
2. **Identify a candlestick pattern** you think is forming (e.g., a morning star).  
3. **Flip on the Candlestick Pattern study** and see if ChartIQ agrees.  

If both you **and** the software point to the same pattern, you’ve just earned a confidence boost.  

#### Walk‑through: DCB Bank  

Here’s a DCB Bank daily chart with a potential **Morning Star** formation circled.  

![DCB Bank chart – raw view](https://zerodha.com/varsity/wp-content/uploads/2020/07/Image-6_dcb1.png)  

What’s happening?  

- The stock is in a **downtrend**.  
- **P1**: A long bearish candle (the “big sad” candle).  
- **P2**: After a gap down, a spinning‑top (the “confused” candle).  
- **P3**: After a gap up, a long bullish candle (the “hopeful” candle).  

Taken together, they look like a **Morning Star**, a classic bullish reversal.  

Now turn on the Candlestick Pattern study:  

![DCB Bank chart – pattern highlighted](https://zerodha.com/varsity/wp-content/uploads/2020/07/Image-7_dcb2.png)  

Boom—ChartIQ labels the Morning Star. With both the manual eye‑test and the algorithm agreeing, I’d feel a lot more comfortable placing a long trade.  

---  

## 22.3 Central Pivot Range  

The **Central Pivot Range (CPR)** is the workhorse for many intraday traders. It gives you three “sweet spots” that act like invisible price fences:  

| Component | Formula | What it Represents |
|-----------|---------|--------------------|
| **Pivot (P)** | \((High + Low + Close) / 3\) | The average price of the previous period—think of it as the “center of gravity.” |
| **Bottom Central Pivot (BC)** | \((High + Low) / 2\) | The midpoint of the prior day’s range—often acts as a **support** level. |
| **Top Central Pivot (TC)** | \((Pivot - BC) + Pivot\) | A mirrored point above the Pivot—frequently behaves as a **resistance** level. |

> **Quick sanity check:** All three numbers are just weighted averages of the prior session’s high, low, and close. No wizardry, just good old arithmetic.  

### Where do you find CPR on Kite?  

1. Open a chart (any timeframe).  
2. Hit **Studies** → search for “Pivot”.  
3. Choose the **Central Pivot Range** option.  

![CPR selector](https://zerodha.com/varsity/wp-content/uploads/2020/07/Image-8_cpr1.png)  

On a 15‑minute chart of **M&M**, the CPR appears as three horizontal lines:  

- **BC** (bottom line)  
- **Pivot** (middle line)  
- **TC** (top line)  

![CPR on M&M chart](https://zerodha.com/varsity/wp-content/uploads/2020/07/Image-9_cpr2.png)  

### Reading the CPR’s “width”  

Notice how the distance between BC and TC changes from day to day. That “width” tells you something about the previous day’s market behavior:  

- **Narrow CPR** → Prior day was **range‑bound** (low volatility).  
- **Wide CPR** → Prior day was **trending** (high volatility).  

In the screenshot above I’ve marked three points:  

1. **Day 1** – a tiny green candle, little price movement → CPR for **Day 2** is *narrow*.  
2. **Day 2** – a clear uptrend → CPR for **Day 3** widens dramatically.  

**Rule of thumb:**  

- **If today’s price action is tight**, expect tomorrow’s CPR to be tight.  
- **If today’s price action is a full‑blown swing**, expect tomorrow’s CPR to be wide.  

The wider the CPR, the more “room” the market has to roam, which often translates into bigger intraday moves.  

### How to trade the CPR  

#### 1. Bullish bias – play the pull‑back to **TC**  

- **Setup:** Current Market Price (CMP) is **above** the TC line.  
- **Interpretation:** Buyers are willing to pay *more* than the average price, indicating bullish sentiment.  
- **Play:** Wait for the price to retrace down to the **TC** (now acting as support). Once it bounces, go **long**.  

Here’s a live‑looking example:  

![Pull‑back to TC (bullish)](https://zerodha.com/varsity/wp-content/uploads/2020/07/Image-10_pull-back.png)  

The price surged above TC, then slipped back and found a foothold right at the TC line. That’s a classic “buy the dip” within a bullish context.  

#### 2. Bearish bias – play the pull‑back to **BC**  

- **Setup:** CMP is **below** the BC line.  
- **Interpretation:** Sellers are dominating, pushing the price under the average.  
- **Play:** Watch for a bounce *up* to BC (now acting as resistance). When it fails, go **short**.  

Example:  

![Pull‑back to BC (bearish)](https://zerodha.com/varsity/wp-content/uploads/2020/07/Image-11_pullbackbear.png)  

The price touched BC, attempted a rally, but got smacked back down—perfect short‑entry material.  

#### 3. Trading **inside** the CPR (range‑bound play)  

When the price oscillates between BC and TC, you can treat the CPR as a **range**:  

- **Buy at BC**, target **TC**.  
- **Sell (or short) at TC**, target **BC**.  

Many traders, myself included, prefer to stay out of the “inside‑range” noise and only chase the pull‑backs to the outer bands (TC for longs, BC for shorts). It reduces the whiplash that sometimes comes with a tight range.  

### A few practical quirks you should know  

| Timeframe | OHLC reference for CPR calculation |
|-----------|------------------------------------|
| **EOD (daily)** | **Previous month’s** High, Low, Close |
| **30 min / 1 hr** | **Previous week’s** High, Low, Close |
| **1 min – 15 min** | **Previous day’s** High, Low, Close |

So, if you’re looking at a 5‑minute chart, the CPR you see is built on **yesterday’s** price action. That’s why the CPR can sometimes feel “one step behind”—it’s literally using the most recent completed period as its foundation.  

Happy trading, and may your CPR always be in your favour!  

---  

### Key Takeaways  

- **Trade from chart** – The floating order window lets you place orders directly on the price map; no more “hunt‑and‑peck” across screens.  
- **Candlestick pattern study** – Use it to *confirm* a pattern you already spotted; don’t let the software replace your own trend analysis.  
- **Central Pivot Range** – Provides three pivotal levels (BC, Pivot, TC) that act as dynamic support & resistance.  
- **Bullish signal** – CMP > TC → look for a pull‑back to TC for a long entry.  
- **Bearish signal** – CMP < BC → look for a pull‑back to BC for a short entry.  
- **Range‑trade** – Buy at BC, sell at TC (or vice‑versa) if the price stays trapped inside the CPR.  
- **Time‑frame nuance** – CPR’s underlying OHLC changes with the chart interval (daily, weekly, monthly references).  

Now go forth, click that Trade button, watch the CPR dance, and may your charts be ever in your favour!  