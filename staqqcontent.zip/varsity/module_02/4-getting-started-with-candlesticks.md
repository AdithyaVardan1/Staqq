# 4. Getting Started with Candlesticks  

**Source:** <https://zerodha.com/varsity/chapter/getting-started-candlesticks/>

---  

##  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/09/M2-Ch4-title.jpg)

## 4.1 – “History tends to repeat itself” – The big assumption (with a side of drama)

Alright, picture this: you’re at a bar, the bartender is a chart, and the cocktail of the night is “Technical Analysis”. One of the main ingredients in that mix is the belief that **history likes to replay the same old sitcom episodes**. In other words, price action tends to behave like that one friend who always repeats the same story at every party. This isn’t just a cute anecdote—it’s *the* cornerstone of any serious technical‑analysis conversation.

Because candlestick patterns are essentially the punchlines to those recurring stories, we need to chew on this assumption a bit longer.

### The “July 7, 2014” Thought‑Experiment (yes, we love dates)

Imagine it’s **July 7, 2014** and a particular stock is throwing a tantrum. Three things are happening simultaneously:

1. **Factor 1** – The stock has been **falling for four straight trading sessions**. Think of it as a downhill roller‑coaster that just won’t stop.
2. **Factor 2** – Today (the 5th session) the decline continues, but **the volume is low**—the market’s yawning instead of cheering.
3. **Factor 3** – The day’s price **range is tiny** compared to the previous four days—so the candle looks like a skinny pencil rather than a bold marker.

Now, fast‑forward one day to **July 8, 2014**. Suddenly the market says “Enough!” and the price **snaps back up, closing positive**. In other words, after those three gloomy factors, the stock *bounces* on the 6th day.

Fast forward a few months (or a few episodes of your favorite sitcom) and the same three factors line up again for **five consecutive sessions**. What does the plot suggest for the 6th day?  

If you’re still with us, the answer is: **the stock is likely to rise again**.  

Why? Because we’re banking on the same assumption that *when a set of factors has produced a certain result in the past, it will likely do the same in the future—as long as the factors stay the same*. It’s the “history‑repeats‑itself‑with‑the‑same‑ingredients” clause.

So, in our bar‑side analogy, if the bartender keeps using the same three spirits, you can expect the same cocktail flavor—unless he sneaks in a surprise ingredient, of course.

---

## 4.2 – Candlestick patterns and what to expect (a.k.a. the party tricks)

Candlesticks are the **visual gossip** of the market. By grouping two or more candles in a particular order, they form *patterns* that whisper (or sometimes shout) what the market might do next. A savvy technical analyst reads these whispers, decides whether to buy a round or call it a night, and sets up a trade accordingly.

Sometimes a **single candle** is enough to make you sit up straight; other times you need a whole *dance routine* of candles to feel confident. Below is the menu of patterns you’ll be tasting—broken down into “single‑candle appetizers” and “multiple‑candle entrees”.

### Single‑candle patterns (the one‑liner jokes)

| Category | Patterns you’ll meet (and maybe love/hate) |
|----------|--------------------------------------------|
| **Marubozu** | • **Bullish Marubozu** – a solid green (or blue) bar that says “I’m strong, I’m bullish, and I have no wimps in me.” <br>• **Bearish Marubozu** – the opposite, a red bar that looks like a stubborn donkey refusing to move up. |
| **Doji** | The market’s version of a “meh” face—open and close are almost identical, indicating indecision. |
| **Spinning Tops** | Like a Doji’s slightly more excited cousin; the body is small, shadows are longer, showing a tug‑of‑war. |
| **Paper Umbrella / Hammer / Hanging Man** | <ul><li>**Hammer** – a short body with a long lower shadow, looks like a hammer ready to whack the price back up (bullish). </li><li>**Hanging Man** – same shape but appears at the top of an uptrend, hinting “maybe we’re about to drop” (bearish). </li><li>**Paper Umbrella** – just a fancy name for a Doji‑ish candle with long shadows, a little umbrella for market rain. </li></ul> |
| **Shooting Star** | The opposite of a hammer; a tiny body with a long upper shadow that screams “I’m about to crash down!” (bearish). |

> **Quick recap:** Marubozus are the “no‑nonsense” candles, Dojis and Spinning Tops are the “I‑don’t‑know‑what‑to‑do” candles, and the hammer family are the “I‑think‑this‑might‑turn‑around” candles.

### Multiple‑candle patterns (the full‑blown choreography)

| Category | Patterns you’ll learn (and maybe brag about) |
|----------|---------------------------------------------|
| **Engulfing** | • **Bullish Engulfing** – a small red candle gets swallowed by a big green one, like a tiny dog being devoured by a Great Dane (bullish). <br>• **Bearish Engulfing** – the reverse, a big red candle engulfs a tiny green one (bearish). |
| **Harami** | • **Bullish Harami** – a big red candle “holds” a tiny green candle inside (like a pregnant bear, bullish). <br>• **Bearish Harami** – a big green candle cradles a tiny red one (bearish). |
| **Piercing Pattern** | After a downtrend, a long red candle is followed by a green candle that closes **above the midpoint** of the red candle – a market “piercing” through the gloom. |
| **Dark Cloud Cover** | The evil twin of Piercing: a green candle is followed by a red candle that closes below the midpoint of the prior green candle. |
| **Morning Star** | A three‑candle sunrise: long red → short (doji or spinning top) → long green that closes well into the red’s body. Think “good morning, profits!” |
| **Evening Star** | The night‑time counterpart: long green → short → long red that closes deep into the green. “Good night, losses.” |

> **Side note:** Many of these names are straight out of a Japanese manga about traders—so you can imagine a samurai sword (engulfing) or a sleepy ninja (harami).  

Candlestick patterns give you **both an entry point and a built‑in risk guard** (i.e., where to place your stop‑loss). They’re like a GPS that says “Turn left now, but also watch out for that pothole”.

---

## 4.3 – Few assumptions specific to candlesticks (the fine print you can’t ignore)

Before you start bragging about “I saw a Hammer and bought the dip”, there are a handful of **candlestick‑specific assumptions** you need to keep in mind. We’ll revisit them constantly, so treat them like the bar’s house rules.

1. **Buy strength, sell weakness** – In chart‑speak, a **bullish (blue/green) candle means buying power**, while a **bearish (red) candle signals selling pressure**. In practice: *only buy on a blue day, only sell on a red day.* It’s the market’s version of “Dress for the occasion.”  
2. **Be flexible (but quantify the flexibility)** – Textbooks love perfect shapes, but the real market throws in a few extra wiggles. You can accept minor deviations **as long as you can measure them** (e.g., “the upper shadow may be up to 10 % longer than the textbook definition”). Think of it like allowing a little extra cheese on a pizza—just don’t drown the crust.  
3. **Look for a prior trend** – A bullish pattern is most convincing when **the previous trend was bearish** (and vice‑versa). It’s the classic “after the storm comes the rainbow” narrative. If you see a Bullish Engulfing during a strong uptrend, it’s probably just a “continue‑up” candle, not a reversal signal.

These three pillars will keep you from misreading the market’s jokes. We’ll keep circling back to them, so keep them handy—like the bar tab you never want to lose.

> **Pro tip:** Write these three on a sticky note, slap it on your monitor, and pretend it’s a coaster.

In the next chapter we’ll dive into **single‑candle patterns**—the quick‑fire one‑liners that can make or break a trade.

---

### Key takeaways from this chapter

- **History repeats itself** – but only when the same *set of factors* line up. Think of it as a sequel that follows the same script.
- **Candlestick patterns split into two families**: single‑candle “one‑liners” and multiple‑candle “full‑stage performances.”
- **Three candlestick‑specific assumptions** you must never forget:  
  1. **Buy strength, sell weakness.**  
  2. **Be flexible, but quantify the flexibility.**  
  3. **Look for a prior trend** (bullish patterns need a bearish backdrop, and vice‑versa).  
- These assumptions act like the bar’s house rules—ignore them, and you might end up with a nasty hangover (aka a bad trade).

*Bottom line:* Candlesticks are the market’s storytelling medium. Learn the characters, respect the plot twists, and you’ll be able to read the market’s next chapter before anyone else flips the page. Cheers! 🍻