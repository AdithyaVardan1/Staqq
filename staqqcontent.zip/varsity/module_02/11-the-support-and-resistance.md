# 11. The Support and Resistance  

**Source:** https://zerodha.com/varsity/chapter/support-resistance/  

---  

When we were chatting about candlestick patterns, we talked about where to jump in (entry) and where to put the “don’t‑let‑me‑lose‑more‑than‑this” stop‑loss. But we left the finish line—aka the target price—hanging in the air like a confused bartender. 🍸 In this chapter we’ll finally give that target a proper address.  

The fastest way to guess a sensible target is to locate the **support and resistance** (S & R) zones. Think of them as invisible walls on the chart that either attract a crowd of eager buyers or a swarm of frantic sellers. A **support** level is where the buying party gets so loud that the price stops falling (or even bounces). A **resistance** level is where sellers start chanting “sell, sell, sell!” and push the price down.  

Even if you’re only after an entry point, you can still use S & R as your personal GPS for the trade.  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M2-Ch11-title1.jpg)  

---  

## 11.1 – The Resistance  

As the name hints, **resistance** is the market’s way of saying “Whoa, slow down!”—it stops the price from climbing any higher (at least for a while). The resistance line sits **above** the current market price and marks a zone where sellers are likely to pile in, flooding the market with supply.  

In a bullish run, the price often rockets up to this line, pauses to “catch its breath,” and then usually slides back down. Because of this, resistance is a favorite tool for technical analysts who love to spot potential exit points in a rising market.  

Take a look at the Ambuja Cements Limited chart below. The horizontal line sitting at **₹215** is our resistance marker.  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M2-Ch11-chart1.jpg)  

I crunched the chart to squeeze in more data points—don’t worry, I’ll explain why in a sec. But first, two things you should spot right away:  

- The resistance line (₹215) sits **higher** than today’s market price.  
- The most recent candle is chilling at **₹206.75**; I’ve circled it for you.  

Now, imagine Ambuja’s price at ₹206 forming a bullish marubozu with a low of ₹202. That pattern screams “go long!” and tells us the stop‑loss should be right at the low, ₹202. With the fresh knowledge of resistance, we can now aim for **₹215** as our profit target.  

**Why ₹215?** Simple, yet elegant:  

1. The ₹215 wall signals **excess supply**—more sellers than buyers.  
2. Excess supply creates **selling pressure**.  
3. Selling pressure usually drags the price **downward** once the wall is hit.  

So a trader who’s long can set the resistance as a logical exit point.  

Putting it all together, a clean trade plan looks like this:  

- **Entry:** ₹206  
- **Stop‑loss:** ₹202  
- **Target:** ₹215  

### How do we spot that resistance line?  

Identifying a price level as support or resistance is almost as easy as spotting a celebrity on the street—once you know what you’re looking for. The rule is straightforward:  

- **If the current price is **below** the line → it’s **resistance**.**  
- **If the current price is **above** the line → it’s **support**.**  

Since the method is identical for both, let’s move on to the other half of the duo—**support**—and then wrap up with the full S & R identification routine.  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M2-Ch11-title2.jpg)  

---  

## 11.2 – The Support  

If resistance is the market’s “stop‑the‑press” sign, **support** is the “bounce‑back” trampoline. As the name suggests, it prevents the price from sliding any further down. The support line lives **below** the current market price and marks a zone where buyers gather like a crowd at a free pizza party.  

When price hits the support line, it usually **consolidates**, **absorbs** all that buying interest, and then **reverses upward**. In a falling market, traders keep a keen eye on support because it often triggers buying.  

Check out Cipla Limited’s chart. The horizontal line at **₹435** marks the support level.  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M2-Ch11-chart2.jpg)  

A couple of things to notice:  

- The support line (₹435) is **below** today’s market price.  
- The latest candle sits around **₹442.5**—again, I’ve circled it for clarity.  

Now, let’s flip the script and imagine a bearish pattern—a shooting star at ₹442 with a high of ₹446. That pattern tells us to **short** Cipla at ₹442, with a stop‑loss at the high, ₹446. Since we know the **nearest support** sits at ₹435, that becomes our profit target.  

**Why target ₹435?** Same logic as before, just inverted:  

1. The ₹435 floor hints at **excess demand**—more buyers than sellers.  
2. Excess demand creates **buying pressure**.  
3. Buying pressure tends to push the price **higher** once the floor is reached.  

Thus, a short trader can use the support as a logical exit point.  

Our short‑trade blueprint:  

- **Entry:** ₹442  
- **Stop‑loss:** ₹446  
- **Target:** ₹435  

---  

## 11.3 – Construction / Drawing of the Support and Resistance Level  

Ready for a **4‑step recipe** to draw those magical horizontal lines? Grab your charting software, a cup of coffee, and let’s get nerdy.  

### Step 1 – Load Data Points  

- **Short‑term S & R:** Load **3–6 months** of candles. This gives you a zoomed‑in view for intraday or BTST (Buy‑The‑Same‑Day‑Trade) setups.  
- **Long‑term S & R:** Load **12–18 months** of data. This stretched view is perfect for swing‑trading where you hold positions for weeks.  

Loading many candles squeezes the chart, which is why the earlier Ambuja and Cipla pictures look a bit “squished.”  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M2-Ch11-chart3.jpg)  

### Step 2 – Spot at Least 3 “Sticky” Price‑Action Zones  

A **price‑action zone** is a point where the market gets a little nervous and does one of the following:  

- **Hesitates** after a brief rise (like a cat pausing before a leap).  
- **Hesitates** after a brief fall (like a driver hitting the brakes on a downhill).  
- **Reverses sharply** (the market does a 180‑degree turn, aka “the plot twist”).  

Below are three mini‑charts illustrating each behavior.  

**1️⃣ Hesitation after an up‑move**  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M2-Ch11-chart4.jpg)  

**2️⃣ Hesitation after a down‑move**  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M2-Ch11-chart5.jpg)  

**3️⃣ Sharp reversal**  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M2-Ch11-chart6.jpg)  

### Step 3 – Align the Zones  

On a 12‑month chart you’ll see *lots* of sticky spots. The trick is to find **at least three** that cluster around the **same price level**.  

Here’s a chart where two zones are present—but they’re at different prices, so they don’t help us much.  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M2-Ch11-chart7.jpg)  

Now, feast your eyes on a chart where **three** zones hover around the same price.  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M2-Ch11-chart8.jpg)  

A crucial nuance: the zones should be **well‑spaced in time**. If the first zone appears in week 2 of May, the next should be at least a few weeks later—think “separated by a Netflix‑binge‑length interval.” The greater the time gap, the stronger the S & R line.  

### Step 4 – Fit a Horizontal Line  

Draw a straight, horizontal line through the aligned zones. Its relationship to the current price decides its role:  

- **Above** the price → **Resistance**  
- **Below** the price → **Support**  

Here’s a full‑blown example:  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M2-Ch11-chart9.jpg)  

From left to right:  

1. Sharp reversal zone (circle 1)  
2. Sticky zone (circle 2)  
3. Sharp reversal zone (circle 3)  
4. Sticky zone (circle 4)  
5. Current market price of Cipla – **₹442.5** (circle 5)  

All four zones hover near **₹429**, so we draw a line there. Since ₹429 sits **below** the market price, it acts as **support** for Cipla.  

> **Pro tip:** Technical analysis is a visual art, so expect a little “approximation error.” The line isn’t a laser‑precise point; it’s more of a **zone**. Think of it as a hallway rather than a single door.  

For Cipla, I’d give myself a **support corridor** from **₹426 to ₹432** (±3 points around the ₹429 line). No hard‑and‑fast rule—just a quick mental math trick.  

Finally, here’s a chart where we’ve plotted **both** S & R for Ambuja Cements:  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M2-Ch11-chart10.jpg)  

- **Current price:** ₹204.1  
- **Support:** ₹201 (below)  
- **Resistance:** ₹214 (above)  

If you’re short at ₹204, aim for the **₹201** support as your target—nice intraday swing. If you’re long at ₹204, the **₹214** resistance becomes a realistic profit goal.  

Notice how each line is backed by at least **three well‑spaced zones**—that’s the secret sauce.  

---  

## 11.4 – Reliability of S & R  

Support and resistance are **indicators**, not guarantees. They’re like weather forecasts: “There’s a good chance of rain (price reversal) if the clouds (historical zones) line up, but you might still end up with a sunny day.”  

Take Ambuja again:  

- **Current price:** ₹204  
- **Resistance:** ₹214  

If the price climbs, it’s likely to hit the ₹214 wall, where sellers may surface and push it down. But **do we have a 100 % guarantee?** Nope—your guess is as good as mine.  

What gives us confidence is **history**. Every time Ambuja has approached ₹214, a price‑action zone formed, and the price behaved as expected. That repeated behavior (spaced out over time) makes the level **time‑tested**. Remember the old TA mantra:  

> **“History tends to repeat itself.”**  

From my own trading chronicles, **well‑constructed S & R zones are usually respected**—they’re not ironclad, but they’re reliable enough to be a cornerstone of any trade plan.  

---  

## 11.5 – Optimization and Checklist  

We’ve reached the **sweet spot** of the chapter: turning theory into a disciplined, repeatable process. Think of this as the “cheat code” for hunting high‑quality trades. Quality over quantity, baby—because a single good trade beats a dozen “meh” trades any day.  

**Optimization** = fine‑tuning a process for the *best* outcome. Here, the process is **trade identification**.  

### Let’s revisit the bullish marubozu  

- **Open:** 432  
- **High:** 449  
- **Low:** 430  
- **Close:** 448  

A bullish marubozu tells us:  

- **Enter long** near the close (≈ ₹448)  
- **Stop‑loss** at the low (₹430)  

Now, what if that low (₹430) **coincides with a robust, time‑tested support**? Boom—double confirmation!  

#### The “Two‑for‑One” Confluence  

1. **Candlestick pattern** (bullish marubozu) → signals a long trade.  
2. **Support near stop‑loss** → shows genuine buying interest around that low.  

When markets feel as random as a dice roll, we need **well‑crafted setups**. The overlap of a pattern and a support zone gives us a **high‑probability** cue to go long.  

### The Checklist (or Framework)  

A **checklist** is your personal trade‑gatekeeper. If a potential trade satisfies every bullet, you go ahead; if not, you walk away and wait for a better candidate. Discipline is the secret sauce that allegedly accounts for **≈ 80 %** of a trader’s success.  

Here are the **first two** pillars of our eventual 6‑point checklist (we’ll flesh out the rest as we learn more TA tricks):  

1. **Candlestick pattern must be recognizable**  
   - Use any of the classic patterns we covered (marubozu, hammer, shooting star, etc.).  
2. **S & R must corroborate the trade**  
   - For a **long** trade: the pattern’s low should sit near a **support** level.  
   - For a **short** trade: the pattern’s high should sit near a **resistance** level.  

(Yes, we repeated the wording a bit—just to make sure the point sticks, like glue on a wall.)  

When we add more concepts (trend lines, moving averages, volume spikes, etc.), each will become another checklist item. In the final version we’ll have **six** points, each weighted by importance (point 1 being the heavyweight champion, point 4 maybe a lightweight, but still better than ignoring it altogether).  

---  

### Key takeaways from this chapter  

- **S & R are specific price points (or zones) on a chart** that attract buying or selling pressure.  
- **Support** = price level **below** the market price where buying interest is strong enough to halt a decline.  
- **Resistance** = price level **above** the market price where selling interest is strong enough to cap a rise.  
- **How to draw them:** Connect **at least three** well‑spaced price‑action zones with a horizontal line. The more zones you have, the sturdier the line.  
- **Trade targets:**  
  - **Long trade:** Aim for the nearest **resistance** as your profit target.  
  - **Short trade:** Aim for the nearest **support** as your profit target.  
- **Checklist matters:** Follow a disciplined, multi‑point checklist to filter out low‑quality setups and boost your odds of success.  

Now go forth, draw those lines, and let the market’s invisible walls guide you—just remember to keep the jokes coming and the risk low! 🍻