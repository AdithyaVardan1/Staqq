# 5.  Single Candlestick patterns (Part 1)

**Source:** https://zerodha.com/varsity/chapter/single-candlestick-patterns-part-1/

---  

##  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/09/M2-Ch5-title.jpg)

## 5.1 – Overview  

As the name *suggests*, a single‑candlestick pattern is built from just one candle—no entourage, no entourage‑sized chart‑formation drama. In plain English, the whole trade signal is squeezed into one day’s worth of buying‑and‑selling action. If you can spot the pattern and execute it cleanly, the payoff can be as sweet as finding an extra fry at the bottom of the bag.

When you start flirting with candlesticks, the **length of the candle** becomes your best friend (or worst enemy). Think of the candle’s body as the distance between the day’s low and high. A long candle says, “We’ve been partying hard—lots of buying or selling!” A short candle whispers, “Eh, today was a snoozefest; nobody cared enough to move the price much.”  

The picture below illustrates the contrast between a long/short bullish candle and a long/short bearish candle.

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/09/M2-ch5-D1a.jpg)

**Takeaway:** Don’t go chasing a trade on a limp, tiny candle. We’ll see why when we dissect the actual patterns later.

---

## 5.2 – The Marubozu  

Enter the **Marubozu**—the “bald” candlestick from Japan (yes, literally “bald”). There are two flavors: bullish Marubozu (the shiny, bullish hair‑less hero) and bearish Marubozu (the gloomy, bald‑headed villain).

Before we dive in, let’s recap the three golden candlestick commandments we brushed up on in the previous chapter. I’m copying them here for your convenience (and to make sure you don’t forget them while sipping your coffee):

1. **Buy strength, sell weakness.**  
2. **Be flexible with patterns – verify and quantify.**  
3. **Look for the prior trend.**

Now, here’s the cheeky part: the Marubozu is basically the rule‑breaker of the candlestick world. It **doesn’t care** about the prior trend (so rule #3 gets tossed out the window). Whether the market was in an up‑trend, down‑trend, or just flat‑lining like a bored cat, a Marubozu shows up and says, “I’m doing my own thing, deal with it.”

**Textbook definition:** A Marubozu has **no upper or lower shadow**, which makes it look completely bald—just a solid body. In reality, you might see a teeny‑tiny wick that’s practically invisible; we’ll call that “acceptable baldness” later.

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/09/M2-ch5-D2a.jpg)

The red candle is the bearish Marubozu, the blue one is the bullish Marubozu.  

---

## 5.3 – Bullish Marubozu  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/09/bullish-marubuzo.png)

A **bullish Marubozu** is the candlestick equivalent of a marathon runner who never slowed down: the **low equals the open**, and the **high equals the close**. In other words, the day opened at the bottom, kept buying all the way up, and slammed the close near the top.  

What does this tell us? Buyers were so enthusiastic they were willing to pay every price the market tossed at them. The market sentiment has flipped to bullish, regardless of what happened yesterday, last week, or last year.

**Trading implication:** Expect a short‑term bullish streak. Your entry point should be around the closing price of that shining Marubozu.

### Real‑world example – ACC Limited  

Here’s a chart where the bullish Marubozu is circled for emphasis.

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/09/M2-Ch5-Chart1.jpg)

- **OHLC:** Open = 971.8, High = 1030.2, Low = 970.1, Close = 1028.4  
- **Ideal textbook rule:** Open = Low and High = Close.  

Notice the tiny deviation: the high‑to‑close gap is only **1.8 points**, which is **0.17 %** of the high. That’s barely enough to be visible on a ruler, so we treat it as a “practically perfect” Marubozu. This is where rule #2 (be flexible, quantify, verify) saves the day.

**Trade setup:**  

- **Buy price:** ~ 1028.4 (the close)  
- **Stop‑loss:** 970.0 (the low)  

Candlestick patterns don’t hand you a profit target—don’t worry, we’ll discuss targets later in the course.

### When should you actually hit the “Buy” button?  

It depends on your **risk appetite**. Let’s picture two archetypal traders:

| Trader type | When to enter | How they validate |
|-------------|----------------|-------------------|
| **Risk‑taker** | Same day, as the candle forms | Around 3:20 PM, check that the **current market price ≈ high** and **opening price ≈ low**. If yes, jump in around the close. |
| **Risk‑averse** | Next trading day (after the candle closes) | Wait for the next day’s candle to be **blue** (bullish). Then buy near that day’s close. |

The risk‑taker is basically shouting, “Buy the dip—no, the rise—right now!” while the risk‑averse is more like, “Let’s make sure the party’s still going before I RSVP.”

Both approaches would have been profitable on the ACC chart, as you can see.

### Another happy example – Asian Paints Ltd  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/09/M2-Ch5-Chart2.jpg)

Again, both the adrenaline‑junkie and the cautious cat would have walked away with a grin.

### When the risk‑taker gets the short end of the stick  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/09/M2-Ch5-Chart3.jpg)

In this chart a bullish Marubozu is circled. The risk‑taker buys on the same day, but the **next day turns red** (a losing day). The risk‑averse trader, who waited for a confirming blue candle, simply stays out and avoids the loss. Moral of the story: **Rule #1 (Buy strength, sell weakness)** is not just a slogan—it’s a lifesaver.

---

## 5.4 – The Stop‑loss on Bullish Marubozu  

What if the market decides to pull a prank and goes the opposite direction after you’ve bought? Candlestick patterns are generous: they come with an **in‑built risk‑management guardrail**. For a bullish Marubozu, **the low of the candle is your stop‑loss**.

#### Example of a busted bullish Marubozu  

- **OHLC:** O = 960.2, H = 988.6, L = 959.85, C = 988.5  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/09/M2-Ch5-Chart4.jpg)

The pattern looked perfect, but the price eventually fell, triggering the stop‑loss at **959.85**. You’d have taken a loss, and that’s okay—every trader’s résumé includes a few “oops” moments.

Why is this a good thing? Because **the loss can’t run away**. You know exactly where you’ll get out if the market flips. Even seasoned pros get bruised, but at least the bruises are bounded.

Sure, sometimes you’ll get stopped out *just* before the market reverses and runs up again. It’s the cruel irony of trading, but the rule‑book is clear: **don’t make excuses, stick to the stop‑loss**.

---

## 5.5 – Bearish Marubozu  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/09/bearish-marubuzo.png)

A **bearish Marubozu** is the mirror image of its bullish sibling: **Open = High** and **Close = Low**. Sellers dominated the day, hammering the price down at every tick, and the candle closed near the day’s low.

**Trading implication:** Expect a short‑term bearish drift. Short (sell) around the close of the Marubozu.

### Real‑world example – BPCL Limited  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/09/M2-Ch5-Chart5.jpg)

- **OHLC:** Open = 355.4, High = 356.0, Low = 341.0, Close = 341.7  

Again, a tiny shadow is permissible; the deviation is minuscule and well within the “acceptable baldness” range.

**Trade setup:**  

- **Short entry:** ~ 341.7 (the close)  
- **Stop‑loss:** 356.0 (the high)  

Targets will be discussed later; for now, remember the rule: **stay in the trade until either the target hits or the stop‑loss is breached**. Jumping out early is like leaving a party before the cake is served—most likely you’ll miss the good part.

### Risk‑taker vs. Risk‑averse on the short side  

- **Risk‑taker:** Short the same day, after confirming at ~3:20 PM that **Open ≈ High** and **current price ≈ Low**.  
- **Risk‑averse:** Wait for the next day’s candle to be **red**, then short near that day’s close.

Both approaches would have been profitable on the BPCL chart.

### Another success story – Cipla Limited  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/09/M2-Ch5-Chart6.jpg)

Both trader personalities could have ridden the down‑trend and booked quick profits.

### When the risk‑taker gets burned  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/09/M2-Ch5-Chart7.jpg)

Here the bearish Marubozu looks tempting, but the next day flips green. The risk‑taker, who entered on the same day, would have taken a loss. The cautious trader, waiting for confirmation, simply stays out—again proving the wisdom of **Rule #1**.

---

## 5.6 – The Trade Trap  

Earlier we talked about candle **length**. The rule of thumb: **avoid candles that are too short (< 1 % range) or too long (> 10 % range).**

- **Short candle** → “Subdued trading activity.” It’s like a whisper in a noisy bar; you can’t tell if the market’s about to roar or fade away.  
- **Long candle** → “Extreme activity.” While excitement is great, the stop‑loss ends up being *deep* (think of a cliff‑side exit). If the trade goes south, you’ll feel the pain in your wallet.

Thus, the sweet spot lies somewhere in the middle, where the candle is long enough to show conviction but not so long that your stop‑loss becomes a mountain you can’t climb.

### Key takeaways from this chapter  

- Keep the three candlestick commandments in mind.  
- **Marubozu** is the only pattern that politely ignores rule #3 (look for prior trend).  
- **Bullish Marubozu** → bullishness.  
  - Buy near the **close** of the candle.  
  - Set the **stop‑loss** at the candle’s **low**.  
- **Bearish Marubozu** → bearishness.  
  - Short near the **close** of the candle.  
  - Set the **stop‑loss** at the candle’s **high**.  
- **Aggressive (risk‑taker) traders** can jump in on the same day the pattern appears.  
- **Risk‑averse traders** wait for the next day’s confirming candle (blue for longs, red for shorts) before entering.  
- Stay away from **abnormally short** (< 1 %) or **abnormally long** (> 10 %) candles; they either lack conviction or make stop‑loss placement a nightmare.  
- Remember: **Buy strength, sell weakness**—the simplest yet most powerful rule in the candlestick playbook.  

Happy candle hunting, and may your Marubozus be ever‑bald and profitable!