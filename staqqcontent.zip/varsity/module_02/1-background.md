# 1. Background  

**Source:** https://zerodha.com/varsity/chapter/background/  

---  

## 1.1 – Overview  

The previous module—*Basics of the Stock Market*—gave us a solid launch pad, like a cheap airline that actually gets you off the ground. From that launch pad we learned that a razor‑sharp, well‑researched point‑of‑view (POV) is the secret sauce for surviving (and thriving) in the market jungle.  

A good POV isn’t just “I think this stock will go up.”  It’s a full‑blown trading recipe that spells out:  

- **Entry price** – the exact level where you’ll slam the “Buy” button (or “Sell” if you’re short).  
- **Expected risk** – how much of your capital you’re willing to watch melt away if the market decides to throw a tantrum.  
- **Expected reward** – the profit target that makes the risk worth the sleepless nights.  
- **Expected holding period** – the horizon over which you expect the trade to play out, from minutes to a few weeks.  

*(Yep, we said it three times in the original, because repetition is the mother of retention—and also because the original was a bit of a copy‑paste glitch. We’ll keep the spirit, not the typo.)*  

Enter **Technical Analysis (TA)**, the chart‑loving cousin who helps you turn that abstract wish‑list into concrete numbers. TA lets you stare at price action, spot patterns, and then assign an entry, an exit, and a risk level to a particular stock or index.  

Just like any other research technique, TA rides on a handful of assumptions—some as simple as “prices move in trends,” others as tangled as a spaghetti‑code algorithm. Fortunately, modern software makes the heavy lifting painless, so we can focus on the *why* instead of the *how*. We’ll uncover those assumptions as we trek through the rest of this module.  

---

## 1.2 – Technical Analysis, what is it?  

### The “Food‑Street” analogy (served with a side of humor)  

Picture this: you’ve landed in a foreign land where the language sounds like a cat choir, the weather flips from sauna to snowstorm in a heartbeat, and the street food scene looks like a carnival of aromas. After a day of sightseeing, you’re famished and you need dinner—fast.  

You ask a local (who replies in a language you can’t decipher) and get pointed toward a bustling food street. You arrive and see **hundreds** of stalls, each flashing neon signs and promising “world‑changing” delicacies. Your stomach is growling, your brain is melting, and you have **no clue** what to order.  

How do you pick?  

#### Option 1 – The “Taste‑Tester” Approach  

You wander from stall to stall, sniff the spices, peek at the cooking process, maybe even sample a nibble (if the vendor is nice). After a few minutes at each of, say, 4–5 stalls, you decide which one looks the most promising and order.  

**Pros:** You know exactly what you’re eating because you did the leg‑work yourself.  

**Cons:** With ~100 stalls, you’ve only sampled 5 % of the options. You might miss the stall that serves the *best* biryani because you ran out of time (or stomach space). In other words, this method isn’t *scalable*.  

#### Option 2 – The “Crowd‑Wisdom” Approach  

You plant yourself in the middle of the street, sip a cold drink, and watch where the longest lines form. You reason: “If a ton of people are queuing, the food must be good—otherwise, they’d be complaining on social media.” You then join the biggest line and hope for the best.  

**Pros:** You can evaluate the whole street in seconds. The crowd’s collective decision‑making does a lot of the heavy lifting for you.  

**Cons:** The crowd can be wrong—maybe the line is long because the stall gives out free Wi‑Fi, not because the noodles are Michelin‑starred.  

In the stock‑market world, **Option 1** mirrors **Fundamental Analysis (FA)**: you dig into a handful of companies, read balance sheets, talk to management, and decide based on intrinsic value. We’ll deep‑dive into FA in the next module.  

**Option 2** is the essence of **Technical Analysis**. You scan the market for where the *most* participants are piling money (or exiting). The idea is that the crowd’s action creates patterns on the chart, and those patterns give you clues about future moves.  

### TL;DR of Technical Analysis  

- **What it is:** A research method that reads the *collective behavior* of market participants through price charts.  
- **How it works:** Over time, price action paints recognizable shapes (head‑and‑shoulders, double tops, flags, etc.). Each shape carries a probabilistic message about future direction.  
- **Your job:** Spot the pattern, interpret the message, and craft a trade (entry, exit, risk).  

Like any scientific method, TA rests on a set of **assumptions** (e.g., “history repeats itself,” “all known information is already priced in”). We’ll dissect those assumptions later, because a trader who ignores them is like a chef who forgets to check if the oven is on.  

#### TA vs. FA – The “Never‑Ending Debate”  

Every trader loves a good argument, especially the one about “which analysis is superior?” The truth is: **both are useful, both have pros and cons, and both can coexist peacefully**—kind of like pineapple on pizza. Some people swear by it; others call it a culinary crime.  

- **Fundamental Analysis** tells you **what** to buy (a company with solid earnings, good moat, etc.).  
- **Technical Analysis** tells you **when** to buy (the moment the price breaks a resistance level, for example).  

A savvy trader learns both, then uses each where it shines brightest. No one method is the *ultimate* answer.  

---

## 1.3 – Setting expectations  

Let’s get real: many newbies think TA is a “get‑rich‑quick” cheat code, like a secret level in a video game. Spoiler alert: it isn’t. If you treat TA as a shortcut, you’ll end up with a *trading catastrophe*—think of it as a kitchen fire caused by trying to flambé with a gas stove you don’t know how to turn off.  

When a trade goes south, people love to blame “the chart” rather than their own execution. That’s why we need crystal‑clear expectations before you dive head‑first into the sea of candlesticks.  

### What TA can (and cannot) do  

| Aspect | What TA is good at | What TA isn’t meant for |
|--------|-------------------|------------------------|
| **Trade type** | Spotting **short‑term** trades (minutes to weeks). | Identifying **long‑term** investment ideas (months to years). |
| **Return per trade** | Small, repeatable profits that add up over time. | Expecting a **home‑run** on every single trade. |
| **Holding period** | From a few minutes (intraday scalps) to a few weeks (swing trades). | Holding a position for years expecting TA to guide you. |
| **Risk management** | Quick‑stop‑losses and disciplined exits are essential. | Holding on to losers hoping “the market will turn around.” |

#### 1️⃣ Trades – Short‑term focus  

Technical Analysis shines when you’re hunting for *quick‑turn* opportunities. Think of it as a fast‑food restaurant: you get something tasty fast, but you’re not there for a multi‑course dinner. For long‑term investments—think “buy and hold for retirement”—FA is your go‑to. If you *are* a fundamental analyst, you can still sprinkle some TA on top to fine‑tune entry and exit points (like adding hot sauce to a well‑cooked steak).  

#### 2️⃣ Return per trade – Small but steady  

Because TA trades are usually brief, you shouldn’t expect a 200 % gain in a single day. Instead, aim for modest targets (say 1‑2 % per trade) that compound over months. It’s the “snowball” effect: a bunch of tiny snowflakes eventually become a mountain—if you don’t melt them on the way down.  

#### 3️⃣ Holding period – Minutes to weeks  

We’ll unpack timeframes later, but remember: a typical TA trade lives somewhere between a coffee break and a Netflix binge. Anything longer and you’re drifting into the realm of fundamentals.  

#### 4️⃣ Risk – Cut losses fast  

Imagine you buy a stock at ₹150 expecting it to climb to ₹170. If it drops to ₹140, the *right* move (according to TA) is to **exit**—not to cling on hoping it’ll bounce back like a rubber ball. Short‑term traders must respect the “stop‑loss” rule: if the market moves against you, cut the loss and move on to the next setup. Holding onto a losing trade is the fastest way to turn a promising account into a cautionary tale.  

> **Pro tip:** Treat every trade like a speed‑date. If the chemistry fizzles in the first 5 minutes, thank them politely and move on.  

### TL;DR of expectations  

- **TA = short‑term, pattern‑driven, risk‑controlled**.  
- **Don’t expect massive, overnight windfalls.**  
- **Keep your holding periods short, your stop‑losses tighter, and your profit targets realistic.**  

---

### Key takeaways from this chapter  

- Technical Analysis is a widely‑used method for shaping a market POV and pinpointing entry/exit levels.  
- It visualizes the **collective actions** of traders on price charts, turning raw data into readable patterns.  
- Recognizable **patterns** (heads‑and‑shoulders, triangles, etc.) act as signposts for potential trades.  
- TA works best when you keep its core **assumptions** (trend persistence, price reflects all known info, etc.) in mind.  
- Its sweet spot is **short‑term trading**—think intraday or swing—not long‑haul investing.  

Now that you’ve got the lay of the land, grab a chart, a cup of coffee, and let’s start hunting those patterns—just remember to bring a sturdy pair of “stop‑loss” shoes. Happy chart‑reading!