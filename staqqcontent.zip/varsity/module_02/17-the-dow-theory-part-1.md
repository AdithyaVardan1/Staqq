# 17. The Dow Theory (Part 1)

**Source:** <https://zerodha.com/varsity/chapter/dow-theory-part-1/>

---

The Dow Theory is like the grand‑dad of technical analysis – the wise old‑timer who was schooling traders **way** before anyone even heard the word “candlestick.”  Even today, the kids on the floor mix the best of both worlds: the candlestick’s flashy hair‑dos and Dow’s no‑nonsense, suit‑and‑tie wisdom.  

Charles H. Dow – the man who gave us the **Dow‑Jones** and the **Wall Street Journal** – started spitting out a series of market‑musings in the early 1900s.  Those ramblings later got bundled, annotated, and polished by his faithful side‑kick William P. Hamilton, who spent **27 years** turning newspaper columns into the textbook you’re reading now.  Since then the world has changed (hello, crypto), so you’ll hear both die‑hard supporters chanting “Dow forever!” and skeptics muttering “Old news, bro.”  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M2-Ch17-title.jpg)

---

## 17.1 – The Dow Theory Principles  

Dow didn’t just throw a few random ideas at the wall and hope something stuck.  He distilled his market‑watching into **nine** core tenets – think of them as the “rules of the road” for anyone who wants to navigate Wall Street without crashing into a billboard.  These tenets are the backbone of the whole theory and the compass you’ll use to decide whether the market is humming a lullaby or screaming a death metal solo.

*(We won’t list all nine here – the original chapter does that – but remember: they cover things like “the market has three trends,” “averages must confirm each other,” and “volume must confirm the trend.”  If you ever feel lost, just ask yourself: “Does the Dow say ‘yes’ or ‘no’ to this move?”)*

---

## 17.2 – The Different Phases of the Market  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/phases.jpg)

According to Dow, the market is a drama with **three acts** that repeat like a bad sitcom you can’t stop watching:

| Phase | What’s happening? | Who’s in the audience? |
|-------|-------------------|------------------------|
| **Accumulation** | The market has just taken a nosedive, prices are at rock‑bottom, and the mood is “maybe we should all go home.” | **Smart money** – the institutional investors who have the patience of a monk and the cash of a small nation. |
| **Markup** | The “smart money” has scooped up bargains, sentiment improves, and the price starts sprinting up the stairs. | Early‑birds, momentum traders, and anyone who smells a quick profit. |
| **Distribution** | Prices have hit the roof (52‑week highs, all‑time highs), the news is all rainbows, and the *public* rushes in like it’s Black Friday. | The masses, retail investors, and the “I‑just‑heard‑it‑on‑Twitter” crowd. |

### Accumulation – The “We’re Not Sure If This Is a Party Yet” Phase  

Picture a market that just took a **steep sell‑off** – think of it as a rollercoaster that decided to drop straight down instead of looping.  Retail investors panic, headlines scream “Ruin!” and many swear they’ll never touch stocks again.  At the bottom, prices sit in the “too cheap to ignore” zone, but most people are still hiding under the bench.

Enter the **smart money** (aka institutional investors).  These are the big‑ticket players with deep pockets and a **long‑term horizon**.  They sniff out value like a bloodhound on a steak and start buying **steady, sizable chunks** over weeks or months.  Because they’re buying *as* the sellers are trying to unload, the price stops its free‑fall and starts forming a **support level**.  That support is essentially the market’s “floor” – the point where the price says, “I’m not going any lower unless someone really wants to.”

The accumulation phase can linger **months** (or even a year) – think of it as a slow‑cooked stew, letting all the flavors meld together.

### Markup – The “All‑Aboard the Rocket” Phase  

Once the smart money has hoarded enough bargains, the **business sentiment** improves (maybe earnings beat expectations, or a new policy is announced).  Suddenly, the price **races upward** – fast, sharp, and often with a lot of hype.  

The hallmark of the markup phase is **speed**.  The rally is so quick that most retail traders are still licking their wounds from the previous crash.  By the time they realize the market is soaring, the price is already at a new high, and everyone’s shouting “Buy! Buy! Buy!”  

### Distribution – The “Everyone’s at the Party, But It’s Time to Leave” Phase  

When the price hits those **new highs** (52‑week, all‑time, or “my grandma’s retirement fund” levels), the news turns sunny, analysts start writing glowing reports, and the public rushes in like it’s a free‑food buffet.  

Meanwhile, the **smart money** that got in during accumulation begins **off‑loading** – not all at once, but **gradually**, to avoid shocking the market.  The public’s buying provides the **price support** that lets the smart money unload without causing a crash.  

This phase looks a lot like accumulation, but in reverse: every time the price tries to push higher, the smart money sells a little more, carving out a **resistance level**.  When the institutional players have fully exited, there’s no more buying power to hold the price up, and the market slides into a **markdown** – a steep sell‑off that leaves the new investors feeling like they just bought a ticket to a sinking ship.

### The Cycle – From Bottom to Top to Bottom Again  

After the markdown, the market eventually finds a new **bottom**, and the whole three‑phase dance starts over.  The entire cycle – from the first accumulation to the final markdown – can span **several years**, but the timing varies wildly.  

For example, India’s **2006‑07 bull market** looked nothing like the **2013‑14** rally: one was a leisurely jog, the other a sprint.  Sometimes the swing from accumulation to distribution drags on for **multiple years**; other times it whizzes by in **a few months**.  The key is to **identify which phase you’re in** – that’s the secret sauce for building a solid market view.

---

## 17.3 – The Dow Patterns  

Just like candlesticks have their own family reunion, Dow Theory brings a few classic **price‑pattern relatives** to the party.  Knowing these patterns lets you spot potential trade setups before the crowd catches on.

| Pattern | What it looks like | Why you care |
|---------|-------------------|--------------|
| **Double Bottom / Double Top** | Two valleys (or peaks) at roughly the same level, separated by a bounce. | Signals a **reversal** – bottom for a bullish turn, top for a bearish turn. |
| **Triple Bottom / Triple Top** | Same idea, but the price tests the level **three times**. | Even stronger reversal signal – the market really “likes” that price. |
| **Range Formation** | Price bounces between a clear support and resistance, forming a rectangle. | Good for range‑trading strategies; you buy low, sell high. |
| **Flag Formation** | A short, tight consolidation after a strong move, resembling a flag on a pole. | Typically a **continuation** pattern – the trend likely resumes after the flag. |

Of course, **support and resistance** are the backbone of Dow Theory, and you already met them earlier in a dedicated chapter.  They’re the invisible “walls” that keep prices from moving too far without a good reason.

---

## 17.4 – The Double Bottom and Top Formation  

A **double top** or **double bottom** is the Dow‑theory version of a “two‑strike warning.”  

### Double Bottom – The Bullish “We’re Back!”  

Imagine a stock that drops to a **shallow low**, bounces, then, after at least **two weeks** (the “well‑spaced” rule), drops back to that same low.  If it **holds** the low the second time and then **shoots upward**, you’ve got a **double bottom** – a classic **reversal** signal that the market may be turning **bullish**.  

*Example:* Look at the chart of **Cipla Limited** (below).  Notice the two troughs are nicely spaced in time, and after the second trough the price climbs like it’s trying to reach the moon.

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M2-Ch17-Chart1.jpg)

### Double Top – The Bearish “Enough Already!”  

Flip the script: the stock rallies to a high, falls back, and after at least two weeks attempts the same high again.  If the second attempt **fails** and the price slides lower, that’s a **double top**, a bearish reversal cue.  

*Example:* In **Cairn India Ltd**, the price tried to breach the **₹336** level twice (the second peak was a hair lower at **₹332**, which is fine – a small deviation is acceptable).  After the second attempt fizzled, the price dropped.

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M2-Ch17-Chart2.jpg)

### My Personal Twist  

In my own trading life, I love **combining** Dow patterns with candlestick signals.  For instance, if a **double top** coincides with a **shooting star** candle on the second peak, you have **two independent confirmations** that the market is about to turn bearish – a strong conviction to go short.

---

## 17.5 – The Triple Top and Bottom  

If two tries felt like a polite request, **three** feels like a firm demand.  A **triple top** or **triple bottom** works exactly like its double‑counterpart, except the price tests the same level **three times** before finally breaking away.

The rule of thumb: the **more times** a price level is respected, the **more sacred** it becomes.  Hence, a triple formation is generally **more powerful** than a double.  

*Example:* Check out **DLF Limited** – the price hit the same resistance **three times** before crashing hard, completing a classic **triple top** pattern.

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M2-Ch17-Chart3.jpg)

---

### Key takeaways from this chapter  

- **Dow Theory predates candlesticks** – it’s the OG of technical analysis.  
- It rests on **nine basic tenets** that act like the market’s constitution.  
- Markets move through **three recurring phases**: accumulation, markup, and distribution.  
- **Accumulation** = smart money (institutional investors) quietly buying; **Markup** = price rockets up as sentiment improves; **Distribution** = the public rushes in while the smart money slowly exits.  
- After distribution comes the **markdown** (a sharp sell‑off), which then paves the way for a fresh **accumulation** phase – the cycle repeats.  
- Dow offers a handful of **classic patterns** (double/triple tops & bottoms, ranges, flags) that shine brightest when you **pair them with candlestick signals**.  
- **Double and triple formations** are **reversal patterns**; the more times a level is tested, the stronger the signal.  
- The **interpretation** of double and triple formations is identical – they simply differ in the *strength* of the conviction they provide.

Now go forth, spot those phases, draw those patterns, and remember: the market may be a wild party, but the Dow Theory is the sober friend who tells you when it’s time to leave. 🍻📈