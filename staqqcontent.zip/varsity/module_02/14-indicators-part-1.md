# 14. Indicators (Part 1)

**Source:** <https://zerodha.com/varsity/chapter/indicators-part-1/>

---  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M2-Ch14-title.jpg)

Picture yourself staring at a stock chart on a trading terminal. What you’ll see is a jungle of squiggly lines, each one trying to whisper “buy!” or “sell!” in your ear. Those are **technical indicators** – the gizmos that turn raw price action into something a mortal can actually interpret.

Think of an indicator as a side‑kick that a successful trader has trained for years. It follows a pre‑written script (the “preset logic”) and helps you supplement the classic technical toolbox – candlesticks, volume, support & resistance – to reach a trading decision. Indicators can tell you when to hop on a trade, when to hop off, when a trend is solid, and sometimes (if you’re lucky) they’ll even give you a sneak peek at the next trend.

There are two big families of indicators:

| Type | What it does | Mood |
|------|--------------|------|
| **Leading** | Tries to *lead* the price, i.e., shout “trend change incoming!” before it actually happens. | The over‑enthusiastic friend who always thinks they know the punchline. |
| **Lagging** | Waits for the price to *lag* behind, confirming a reversal **after** it’s already happened. | The cautious buddy who only speaks up once the drama has settled. |

> **Heads‑up:** Leading indicators love drama but also love false alarms. They’re the “false‑positive” masters, so you need a seasoned palate to separate the real signal from the noise. The more you trade, the better you’ll get at not over‑reacting to their occasional melodrama.

Most leading indicators are called **oscillators** because they swing back and forth inside a bounded range (think a swing set that can only go from 0 to 100). Their reading – 55, 70, 22 – is the cue you use to decide what the market might be feeling.

Lagging indicators, on the other hand, are the “after‑the‑fact” reporters. The classic example? **Moving averages**. They’re like that friend who shows up fashionably late, but when they do, they bring the whole story.

> **Why did we talk about moving averages before the “real” indicators?**  
> Because moving averages are the bread‑and‑butter of many other indicators (RSI, MACD, Stochastic, …). They’re the secret sauce, so we gave them a cameo appearance up front.

Before we dive into the nitty‑gritty of each indicator, let’s quickly brush up on **momentum** – the speedometer of price change. Suppose a stock trades at ₹100 today, jumps to ₹105 tomorrow, and then to ₹115 the day after. That’s a 15 % surge in just three days → high momentum. Same 15 % spread over three months? That’s a lazy‑caterpillar momentum. The faster the price moves, the higher the momentum gauge.

---

## 14.1 – Relative Strength Index

Enter the **Relative Strength Index** (RSI), the most popular leading‑momentum oscillator, invented by the legendary J. Welles Wilder (the same guy who gave us the ATR and the ADX). Despite its intimidating name, RSI isn’t comparing two securities; it’s simply measuring the *internal* strength of a single security. Think of it as a “how pumped is this stock right now?” meter that swings between 0 and 100.

- **0 – 30** → “We’re super‑squashed, maybe time to buy.”
- **70 – 100** → “We’re on a hype train, maybe time to sell.”
- **Middle ground** → “Just chilling, keep watching.”

### The math (don’t panic, it’s easier than assembling IKEA furniture)

The RSI formula is:

\[
RSI = 100 - \frac{100}{1 + RS}
\]

where  

\[
RS = \frac{\text{Average Gains}}{\text{Average Losses}}
\]

Let’s walk through a concrete example (the numbers are the same as the original so you can verify later).

> **Assumptions:**  
> - Day 0 price = 99  
> - Look‑back period = 14 days (the default “look‑back” in most charting packages – 14 hours for an hourly chart, 14 days for a daily chart).

| Day | Close | Points Gained | Points Lost |
|-----|-------|---------------|-------------|
| 1   | 104   | 5             | 0           |
| 2   | 101   | 0             | 3           |
| …   | …     | …             | …           |
| 14  | …     | …             | …           |

*(The table in the original article lists the actual 14 rows; we’ll keep the spirit here.)*

**Step 1 – Compute averages**

- **Average Gains** = 29 ÷ 14 = **2.07**  
- **Average Losses** = 10 ÷ 14 = **0.714**

**Step 2 – Compute RS**

\[
RS = \frac{2.07}{0.714} = 2.8991
\]

**Step 3 – Plug into RSI formula**

\[
\begin{aligned}
RSI &= 100 - \frac{100}{1 + 2.8991}\\
    &= 100 - \frac{100}{3.8991}\\
    &= 100 - 25.6469\\
    &= \mathbf{74.3531}
\end{aligned}
\]

Boom! The RSI comes out at **74.35**, a clear sign we’re in the “maybe‑overbought” zone.

### How to read the RSI on a real chart

Take a look at the Cipla Ltd chart (original image below). The red line below the price candles is the 14‑period RSI.

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M2-Ch14-Chart2.jpg)

- **0 – 100** is the full vertical scale, but you’ll rarely see the line touching the extremes because markets rarely sprint from 0 to 100 in a single day.

- **30 – 0** → “Oversold”. Think of it as the market saying, “I’m tired, let’s take a break – maybe a bounce is coming.”

- **70 – 100** → “Overbought”. The market is shouting, “I’m on fire! Might cool off soon.”

#### Spot the drama on the chart

1. **First vertical line** – RSI dips to **26.8** (below 30). The stock is oversold, and—boom!—a **bullish engulfing** candlestick appears right there. Two confirmations in one glance: RSI says “buy”, candle says “buy”. (Of course, you’d also want volume and support/resistance to nod along.)

2. **Second vertical line** – RSI spikes to **81** (above 70). The market looks overheated, and the candles form a **bearish engulfing** pattern. RSI + bearish candle = a solid “short‑sell” signal. The price then makes a quick correction, just as the indicator warned.

#### When the classic story doesn’t fit

Sometimes RSI and candlesticks disagree, and that’s where the fun begins. Imagine two scenarios:

| Scenario | What the RSI does | What the price does | Takeaway |
|----------|-------------------|---------------------|----------|
| **1. Persistent Uptrend** (e.g., *Eicher Motors*) | RSI stays **stuck** in the overbought region for months because it can’t go above 100. | Price keeps climbing, delivering ~100 % YoY returns. | Don’t auto‑short just because RSI is high; the momentum may be *still* bullish. |
| **2. Persistent Downtrend** (e.g., *Suzlon Energy*) | RSI remains glued to the oversold region (near 0). | Price keeps sliding, delivering –34 % YoY returns. | Don’t auto‑buy just because RSI is low; the down‑momentum may still dominate. |

**Key tricks to tame a “stuck” RSI**

- **Overbought for a long stretch?** Consider *buying* instead of shorting. The price is riding an excess of positive momentum.
- **Oversold for a long stretch?** Consider *selling* (or shorting) instead of buying. The negative momentum is entrenched.
- **RSI climbing out of oversold territory after a long dip?** That could be a **bottom‑sign** → look for longs.
- **RSI falling out of overbought territory after a long run?** That could be a **top‑sign** → look for shorts.

---

## 14.2 – One last note

Treat RSI parameters like your favorite cocktail recipe – you can start with the classic mix and then tweak to suit your palate.

- **Look‑back period**: Wilder chose **14** days because it worked well in the late‑1970s market environment. Feel free to experiment with **5, 10, 20, or even 100** days. Shorter periods = spikier, more reactive RSI; longer periods = smoother, slower‑moving RSI. Your edge is born from finding the sweet spot that matches your trading style and the asset’s volatility.

- **Oversold/Overbought thresholds**: Wilder’s 0‑30 / 70‑100 split is a convention, not a law. Some traders (including yours truly) like to tighten the bands to **0‑20** and **80‑100** for a more aggressive signal, still using the 14‑day look‑back.

Bottom line: **Play around**. Back‑test different combos, see what gels with your risk tolerance, and lock in the settings that give you a consistent edge.

> **Pro tip:** RSI is rarely used in isolation. Pair it with candlestick patterns, volume spikes, or other indicators (MACD, Bollinger Bands, etc.) for a well‑rounded view. Think of RSI as the witty sidekick that adds flavor, not the sole hero of the story.

### Key takeaways from this chapter

- Indicators are **independent trading systems** crafted by seasoned pros.
- They come in two flavors: **leading** (try to predict) and **lagging** (confirm after the fact).
- **RSI** is a momentum **oscillator** that wiggles between **0 and 100**.
- **0 – 30** → *Oversold* → watch for **buying** chances.
- **70 – 100** → *Overbought* → watch for **selling** chances.
- If RSI lingers **high** or **low** for a long stretch, it signals **excess momentum**. Instead of flipping the script, you may actually **trade in the same direction** the RSI is stuck.
- Customise the look‑back period and threshold bands to fit your style; the “one‑size‑fits‑all” settings are just a starting point.
- Use RSI **with** other tools (candlesticks, volume, support/resistance) – never let it fly solo.  

Happy chart‑watching, and may your indicators be ever in your favor!