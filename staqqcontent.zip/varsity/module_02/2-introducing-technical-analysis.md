# 2. Introducing Technical Analysis  

**Source:** <https://zerodha.com/varsity/chapter/introducing-technical-analysis/>

---  

##  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/09/M2-Ch2-title.jpg)

## 2.1 – Overview  

In the last chapter we gave you a quick sniff of what technical analysis (TA) is and how it differs from the number‑crunching world of fundamental analysis. Think of it as the difference between judging a movie by its trailer (TA) versus reading the entire script, budget sheets, and cast contracts (fundamentals).  

In this chapter we’ll roll up our sleeves, sip a (virtual) coffee, and dig a little deeper into the **assumptions** that keep TA from being just “pretty charts”. By the end you’ll know why traders whisper about “the market discounts everything” while still arguing over whether a candle looks bullish or just hungover.

---

## 2.2 – Application on Asset Types  

One of the coolest super‑powers of technical analysis is its **universality**. As long as an instrument spits out a time‑series—open, high, low, close, volume—you can slap a chart on it and start hunting patterns.  

### The “Learn to Drive Once, Ride Anything” Analogy  

Imagine you learned to drive a Mahindra XUV. After a few weeks of clutch‑and‑gear gymnastics you can hop into a Maruti Swift, a Harley, or even a spaceship (okay, maybe not the last one) and still get where you’re going. TA works the same way: learn the language of price bars once, then you can talk to **equities**, **commodities**, **FX**, **bonds**, you name it.  

#### Why This Beats Other Research Techniques  

- **Fundamentals are fussy** – If you want to value an Indian IT stock, you pore over P&L statements, balance sheets, cash‑flow forecasts, and management commentary. Switch to a coffee bean future and you’re suddenly hunting rainfall data, crop yields, and export‑import logistics. Switch again to copper and you’re obsessing over mine production, refinery capacity, and geopolitical tension. It’s a full‑time job just to learn the *different* fundamental playbooks.  

- **TA stays the same** – Whether you’re looking at the price of a Tata Steel share, a barrel of Brent crude, or the EUR/INR pair, the chart still shows candles, moving averages, MACD, RSI, and the rest of the toolbox. The **how** stays constant; the **what** changes.

So, the next time a friend says “I can’t do TA on gold because it’s a commodity,” you can smirk and reply, “Buddy, I’m about to MACD that bullion like it’s a blue‑chip stock.”

---

## 2.3 – Assumptions in Technical Analysis  

Fundamental analysts spend their nights dreaming about EPS, EBITDA multiples, and discount‑rate gymnastics. Technical analysts, on the other hand, are more like party‑goers who care only about the **DJ’s playlist**—the price and volume history—and what that tells us about tomorrow’s dance floor.

Below are the four cornerstones (or four “rules of the road”) that keep TA from drifting into fantasy land. Memorize them, and you’ll avoid the classic rookie mistake of treating a chart like a horoscope.

| # | Assumption | What It Means (with a dash of bar‑room colour) |
|---|------------|----------------------------------------------|
| **1** | **Markets discount everything** | Every shred of public (and sometimes not‑so‑public) info is already baked into the last‑traded price. Imagine an insider buying a ton of shares before a stellar earnings beat. Even if the deal is whispered in the hallway, the price will *wiggle*—and a sharp‑eyed TA‑guy will spot the wiggle before anyone else hears the gossip. |
| **2** | **The “how” beats the “why”** | We don’t care *why* the insider bought; we care *how* the market reacted. The price jump, the volume spike—those are the clues. It’s like watching a magician’s hand‑movement; you don’t need to know the secret, just that the rabbit *appeared*. |
| **3** | **Price moves in trends** | Markets love to march in one direction for a while before deciding to change direction. Think of the NIFTY 50’s climb from ~14,750 to ~18,500 – it didn’t happen in a single “boom” flash, but over roughly 11 months of steady, step‑by‑step upward steps. Once a trend is set, price tends to keep marching in that direction—until it doesn’t. |
| **4** | **History tends to repeat itself** | Humans are predictably predictable. When prices rise, greed surfaces; when they fall, fear (and a little bit of masochism) shows up. Because market participants react in similar ways each time a price moves, patterns tend to re‑emerge. That’s why a “head‑and‑shoulders” formation in 1999 still looks like a head‑and‑shoulders in 2024. |

If you keep these four ideas in your mental back pocket, you’ll be less likely to chase every random spike and more likely to read the market’s *story* like a seasoned bartender reads a regular’s order.

---

## 2.4 – The Trade Summary  

India’s equity market runs a tight 6‑hour‑15‑minute shift, from **09:15 AM** to **03:30 PM**. In that window, the exchange processes **millions** of trades—think of it as a bustling highway where cars (trades) zip past every second.  

### Why We Don’t Plot Every Single Trade  

Picture this: you decide to plot **every** trade that happens in a day on a single chart, marking each price point at the exact second it occurred. The result? A dense, indecipherable spaghetti monster that would make even a seasoned chartist cry.  

Below is a stylised illustration of that chaos (imagine a star‑filled night sky where each star is a trade):

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/09/M2-Ch1-Chart1.jpg)

Clearly, trying to eyeball that mess is like trying to find a particular grain of rice in a sack of rice—possible, but not very useful.

### The Elegant Four‑Letter Summariser: OHLC  

Enter the **OHLC** (Open, High, Low, Close) framework, the “four‑point summary” that every trader uses to compress a day’s chaos into something you can actually read while sipping your chai.

| Price | What It Is | Why It Matters (with a pinch of bar‑talk) |
|-------|------------|------------------------------------------|
| **Open** | The first price at which a trade is executed when the market swings its doors open at 09:15. | Think of it as the first sip of a freshly poured beer—sets the tone for the session. |
| **High** | The highest price that any trade reached during the day. | That’s the “peak of excitement”—the moment everyone shouted “Buy!” (or “Sell!” if you’re a contrarian). |
| **Low** | The lowest price touched in the session. | The “bottom of the barrel” moment—when the brave (or reckless) decide to dip their toes in. |
| **Close** | The final price at which the market shuts down at 03:30. | The grand finale, the “closing act” that tells you how the day ended. If the close is above the open, the market had a happy hour; if it’s below, someone probably spilled the drinks. |

The **Close** carries a bit of extra swagger: it’s the reference point for the next day’s opening price, a proxy for intraday sentiment, and the most widely‑watched number by news anchors and meme‑stock enthusiasts alike.

All four of these numbers get plotted on a candlestick or bar chart, giving you a tidy visual of the day’s drama without drowning in minutiae.

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/09/M2-Ch1-Chart2.jpg)

---

### Key Takeaways (the “cheat‑sheet” you can actually keep on a sticky note)

- **TA works on any asset** that spits out time‑series data—stocks, commodities, currencies, bonds—so you only need to learn the language once.  
- **Four core assumptions** keep TA grounded:  

  1. *Markets discount everything* – the price already knows the news.  
  2. *The “how” beats the “why”* – focus on price reaction, not motive.  
  3. *Price moves in trends* – markets like to keep marching in one direction.  
  4. *History repeats itself* – human psychology makes patterns re‑appear.  

- **OHLC** (Open, High, Low, Close) is the daily summary that turns a chaotic sea of trades into a readable story. The **Close** is especially important—it’s the day’s final word and tomorrow’s starting point.  

- Remember: you’re not trying to memorize every tick; you’re looking for the *shape* of the market’s dance.  

---

That’s it for Chapter 2! Grab a drink, glance at a candlestick chart, and think about how the market is already whispering its secrets through those four numbers. Next up we’ll start putting those assumptions to work with actual indicators—so keep the jokes coming and the charts loading. 🚀📈