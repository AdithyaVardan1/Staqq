# 9. Multiple Candlestick Patterns (Part 2)

**Source:** https://zerodha.com/varsity/chapter/multiple-candlestick-patterns-part-2/

---  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M2-Ch9-title.jpg)

## 9.1 – The Harami Pattern  

First off, no, “Harami” isn’t a secret Indian dish (though it would be tasty). It’s actually a Japanese word that means *pregnant*. Yep—​the chart is “expecting” a reversal, and the name is surprisingly spot‑on when you picture the tiny candle snuggled inside a much larger one, just like a baby in a womb.

A Harami is a **two‑candle** formation:

| Candle | What it looks like | Typical colour |
|--------|-------------------|----------------|
| **P1** | Long body (big range) | Same colour as the prevailing trend (red in a downtrend, blue in an uptrend) |
| **P2** | Small body, tucked inside P1’s range | Usually the *opposite* colour of P1 |

When this little “pregnant” pattern shows up, traders start eyeing a possible trend flip. There are **two flavors**:

* **Bullish Harami** – appears at the *bottom* of a downtrend.  
* **Bearish Harami** – shows up at the *top* of an uptrend.

---

## 9.2 – The Bullish Harami  

As the name says, a **bullish** Harami is the market’s way of saying “Hey, maybe it’s time to stop being a grumpy bear.” It unfolds over **two days**, much like the classic engulfing pattern, but with the second candle *shrinking* instead of swallowing the first.

Below is a chart with the bullish Harami circled for your viewing pleasure.

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M2-Ch9-chart1.jpg)

### How the drama unfolds

1. **Downtrend dominance** – Bears have the market on a leash, pushing prices lower.  
2. **Day 1 (P1)** – A *red* candle makes a fresh low, screaming “Bears rule!”  
3. **Day 2 (P2)** – The market opens **higher** than P1’s close. Bears get a sudden case of the jitters because they expected a gloomier open.  
4. The price fights back, closing **blue**, but the close stays **below P1’s open**.  
5. The tiny blue candle is *nestled* inside the long red one—hence the “pregnant” vibe.  
6. Even though the P2 candle looks modest, its **unexpected bullishness** rattles the bears and cheers the bulls.  
7. The panic among bears often spreads faster than a meme, giving bulls the room to push the price upward.  

**Bottom line:** The market may be about to reverse, so a long (buy) position becomes attractive.

### Trade‑setup cheat sheet (bullish Harami)

| Who? | When to enter | How to confirm |
|------|----------------|----------------|
| **Risk‑taker** (aggressive) | Near the **close of P2** | 1️⃣ P2 opens **above** P1’s close.<br>2️⃣ By ~3:20 PM on P2, price is **still below** P1’s open. |
| **Risk‑averse** (cautious) | Close of the **next day after P2** (but only if that day forms a **blue** candle) | Same two conditions above, plus a confirming blue candle on the following day. |
| **Stop‑loss** | The **lowest low** of the two candles (i.e., the lower of P1‑low and P2‑low) | Keeps your downside risk bounded. |

> **Note:** The two bullet points above are repeated in the original text – we keep them for clarity.

### Real‑world example: Axis Bank

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M2-Ch9-chart2.jpg)

| Candle | Open | High | Low | Close |
|--------|------|------|-----|-------|
| **P1** | 868 | 874 | **810** | 815 |
| **P2** | 824 | 847 | 818 | **835** |

* **Risk‑taker** would jump in at the **close of P2** (≈ ₹835) and set the stop‑loss at the **lowest low** of the pattern, i.e., **₹810**.  
* **Risk‑averse** would wait for the next day’s candle to turn blue and then consider entering.  

After entering, you simply sit tight and let the market decide whether it hits your target or busts your stop.

### When it *looks* like a bullish Harami but isn’t

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M2-Ch9-chart3.jpg)

Here the two candles are nicely nested, but the **preceding trend is flat**, not bearish. Without a downtrend backdrop, the pattern loses its reversal mojo.

### When a bullish Harami **fails**

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M2-Ch9-chart4.jpg)

Even a textbook Harami can get whacked by a sudden stop‑loss hit. Remember, no pattern is a guarantee—just a probability boost.

---

## 9.3 – The Bearish Harami  

Flip the script and you get the **bearish** Harami, which shows up at the *top* of an uptrend, whispering “Time to take profits, folks.” The anatomy is the mirror image of the bullish version.

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M2-Ch9-chart5.jpg)

### How the short‑side story plays out

1. **Uptrend dominance** – Bulls are the party animals, driving prices higher.  
2. **Day 1 (P1)** – A *blue* candle makes a fresh high, reinforcing bullish confidence.  
3. **Day 2 (P2)** – The market **opens lower** than P1’s close, catching bulls off‑guard.  
4. The price drifts down, closing **red**, but the close stays **above** P1’s open, making the red candle sit snugly inside the blue one.  
5. This unexpected bearishness spooks the bulls, who may start unwinding.  
6. The panic can snowball, so the odds tilt toward further downside.

### Trade‑setup cheat sheet (bearish Harami)

| Who? | When to enter | How to confirm |
|------|----------------|----------------|
| **Risk‑taker** (aggressive) | Near the **close of P2** | 1️⃣ P2 opens **below** P1’s close.<br>2️⃣ P2 closes **above** P1’s open. |
| **Risk‑averse** (cautious) | Close of the **next day after P2** (provided that day is a **red** candle) | Same two conditions plus the confirming red candle. |
| **Stop‑loss** | The **highest high** of the two candles (i.e., the higher of P1‑high and P2‑high) | Caps your upside risk. |

### Real‑world example: IDFC Limited

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M2-Ch9-chart6.jpg)

| Candle | Open | High | Low | Close |
|--------|------|------|-----|-------|
| **P1** | 124.0 | 129.0 | 122.0 | **127.0** |
| **P2** | **126.9** | **129.7** | 125.0 | **124.8** |

* **Risk‑taker** would short near the close of P2 (≈ ₹125).  
* **Risk‑averse** would wait for the next day to confirm a red candle—if it doesn’t, they’d stay out (as happened in this case).  

The **stop‑loss** sits at the **highest high** of the pair: **₹129.70**.

---

### Key takeaways from this chapter

- The Harami lives across **two trading sessions** – P1 (the long “parent” candle) and P2 (the tiny “baby” candle).  
- Visually, P2’s body is **fully contained** within P1’s range, which is why the “pregnant” metaphor works.  
- **Bullish Harami**  
  * Pops up at the **bottom of a downtrend**.  
  * P1 = long red, P2 = small blue (opposite colour).  
  * **Risk‑taker** enters near P2’s close; **risk‑averse** waits for the next day’s blue candle.  
  * **Stop‑loss** = the **lowest low** of the two candles.  
- **Bearish Harami**  
  * Shows up at the **top of an uptrend**.  
  * P1 = long blue, P2 = small red.  
  * **Risk‑taker** shorts near P2’s close; **risk‑averse** waits for the next day’s red candle.  
  * **Stop‑loss** = the **highest high** of the two candles.  
- Always double‑check the **preceding trend**: a Harami without the right background is just a cute picture, not a trade signal.  

Happy chart‑watching! May your Haramis be pregnant with profit and not with pain. 🍻📈