# 6. Single Candlestick Patterns (Part 2)

**Source:** <https://zerodha.com/varsity/chapter/single-candlestick-patterns-part-2/>

---  

##  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/09/M2-Ch6-title.jpg)

## 6.1 – The Spinning Top  

Picture a little candle that looks more like a bored teenager than a market‑moving beast. That’s the **spinning top**. Unlike its macho cousin the Marubozu, it doesn’t shout “Buy now!” or “Sell now!” with a neon sign. Instead, it whispers a cryptic story about what the market was *really* doing during the session. If you listen closely, you can use that gossip to decide whether to hop on the train, hop off, or just stare at the platform and sip your coffee.

Take a good look at the picture below. What do you notice about the shape of this candle?

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/09/M2-Ch6-D1a.jpg)

Two things jump out like a rabbit out of a magician’s hat:

1. **A tiny real body** – the “meat” of the candle is so slim it could be a diet soda.
2. **Almost equal upper and lower shadows** – the wicks stretch up and down like a seesaw that’s perfectly balanced.

### What happened during the day to create this modest marvel?

Let’s walk through the drama, scene by scene.

| Feature | What it tells us | Why it matters |
|---------|----------------|----------------|
| **Small real body** | The open and close were practically neighbours. Example: open = ₹210, close = ₹213 (or the other way around, ₹210 → ₹207). A 3‑point swing on a ₹200‑stock is about as exciting as watching paint dry. | Because the body is tiny, the candle’s colour (green/blue for up, red for down) is irrelevant. The market can’t decide whether to cheer for the bulls or the bears. |
| **Upper shadow** | Connects the body to the high of the session. If the candle is red, it links the high to the open; if it’s blue, to the close. | The bulls tried to push the price higher, but they ran out of steam. If they’d succeeded, we’d see a long blue body, not a dainty top. |
| **Lower shadow** | Connects the body to the low of the session. Red candle: low to close; blue candle: low to open. | The bears made a valiant attempt to drag the price down, but they too fell short. A successful bear attack would have produced a long red body, not a meek top. |

Put all three together and you get a market that looked both ways, waved at the bulls, then the bears, and finally said, “Eh, I’m not sure.” In other words: **indecision**. Neither side could dominate, so the candle’s body stayed small while the wicks showed the failed attempts on both ends.

If you see a spinning top **alone**, it’s just a polite “I’m not sure yet.” The magic happens when you place it on a **trend**. Then the candle whispers a *compelling* message that you can turn into a trading stance.

---

## 6.2 – Spinning Tops in a Downtrend  

*What if the little indecisive candle shows up while the market is already doing the “down‑hill tumble” dance?*

In a downtrend, the bears have the steering wheel and are happily grinding the price lower. When a spinning top pops up, it usually means the bears are **taking a breather**—maybe they’re refilling their coffee, maybe they’re waiting for the next wave of sellers. At the same time, the bulls have tried to slap a “stop‑the‑slide” sign on the chart, but they’ve only managed a faint tap that didn’t change the body.

So, what should you, the ever‑curious trader, do?

Two equally likely scenarios loom:

| Scenario | What it means |
|----------|----------------|
| **Another round of selling** | Bears tighten their grip and the downtrend continues. |
| **A reversal** | Bulls finally catch a break, the market flips, and prices start climbing. |

Because the crystal ball is foggy, you have to **prepare for both**. Here’s a cheeky way to do it:

*If you’ve been waiting for a long‑run “buy” opportunity, this could be the moment.*  
- **Play it safe:** Instead of throwing all 500 shares into the pot, buy **only half** (250).  
- **Watch the dance:** If the price decides to climb, you can add more (average‑up).  
- **If the price keeps falling:** Exit the half‑position and limit your loss to 50 % of the original size.

### Real‑world examples  

**Reversal after a spinning top**  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/09/M2-Ch6-Chart1.jpg)

**Continuation of the downtrend**  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/09/M2-Ch6-Chart2.jpg)

Think of the spinning top in a downtrend as **“the calm before the storm.”** The storm could be a *new down‑trend* or a *sudden up‑trend*. What’s certain is that **the market will move**—just not sure which direction yet. Keep your position size modest and your stop‑loss tight, and you’ll be ready for whatever the market decides to do next.

---

## 6.3 – Spinning Tops in an Uptrend  

Now flip the script: the market has been marching upward, the bulls are the party hosts, and—*bam*—a spinning top shows up. The story is almost the same, but the perspective changes a bit, like watching the same movie from a different seat in the theater.

Look at this chart and tell me what you see:

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/09/M2-Ch6-Chart3.jpg)

**Observation:** The market has been in a solid uptrend, meaning the bulls have been the undisputed headliners. The sudden appearance of a spinning top tells us:

1. **Bulls lost the steering wheel for a moment.** If they were still in full control, we’d see a long blue candle, not a wobbly top.
2. **Bears made a cameo.** They tried to push the price down, but just like before, their attempt fizzled out.

### What does this indecision mean for you?

| Possibility | Interpretation |
|-------------|----------------|
| **Bulls are consolidating** | They’re catching their breath before the next big push upward. |
| **Bulls are fatigued** | They’re losing steam, and the bears may soon take over, leading to a correction. |

The odds are essentially a coin toss—**50 % each**. So, just like with the downtrend, you need a **dual‑ready stance**.

**Practical approach:**  
- Suppose you own **500 shares** that have been soaring. Instead of selling everything when the spinning top appears, **take profit on 50 % (250 shares)** and keep the rest in the market.  
- **Two outcomes:**  

  1. **Bears take over** – the price slides. You already locked in half the profit, and you can sell the remaining 250 at a still‑reasonable level.  
  2. **Bulls regroup** – the uptrend resumes, and you still have 250 shares riding the wave, ready for further upside.

### Example of a successful “half‑out, half‑in” play  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/09/M2-Ch6-Chart4.jpg)

**Bottom line:** The spinning top in an uptrend signals **confusion**. Until the market gives a clear sign (a long blue candle for continuation or a decisive red candle for reversal), keep your exposure modest and stay ready for either scenario.

---

## 6.4 – The Dojis  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/09/doji.png)

Dojis are essentially the **spinning top’s minimalist sibling**—they’re the candle version of a *mic drop*: the open and close are *exactly* the same, so the real body is virtually non‑existent. The wicks (upper and lower shadows) can be as long as a giraffe’s neck; the point is that the price opened and closed at the same level, indicating a stalemate.

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/09/M2-Ch6-D2a.jpg)

### The textbook definition  

- **Open = Close** (or within a hair’s breadth, say < 0.1 % of price).  
- Upper and lower wicks can be any length.  

But remember the **2nd rule** of candlestick analysis: *“Be flexible, verify, and quantify.”* Even if the body is a razor‑thin line, you can still call it a Doji if the open‑close gap is negligible.

**Colour doesn’t matter** – a Doji can be green, red, or even a neutral gray; what matters is the *equality* of open and close.

### Dojis = Spinning Tops, just with a slimmer waist  

All the psychology we learned for spinning tops applies here: **indecision, tug‑of‑war, and a pending breakout**. In practice, you’ll often see Dojis clustering together, amplifying the market’s “I‑don’t‑know‑what‑to‑do‑yet” vibe.

### Dojis in action  

**Doji in a downtrend (sign of possible reversal)**  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/09/M2-Ch6-Chart5.jpg)

**Doji after a strong uptrend (often preceding a correction)**  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/09/M2-Ch6-Chart6.jpg)

So the next time you spot a **Spinning Top** or a **Doji**—whether standing alone or hanging out in a crowd—remember: the market is stuck in a **“choose‑your‑own‑adventure”** moment. Your job is to adopt a flexible stance that can ride either the reversal or the continuation.

---

### Key Takeaways from This Chapter  

- **Shape matters:** A spinning top has a *tiny* real body with *almost equal* upper and lower shadows.  
- **Colour is irrelevant** for both spinning tops and Dojis; the crucial fact is that the open and close are *very close* (or identical for Dojis).  
- **Indecision is the core message**—neither bulls nor bears have the upper hand.  
- **Location on the chart decides the narrative:**  

  *At the top of a rally* – could be a **pause before the next leg up** *or* the **first sign of a bearish reversal**.  
  *At the bottom of a rally* – could be a **pause before the next leg down** *or* the **first sign of bullish resurgence**.  

- **Trading advice:** When a spinning top or Doji shows up, **scale back**. If you’re long, consider selling **about half** the position and wait for a clearer direction. If you’re short, do the opposite. This way, you limit risk while staying in the game.  
- **Dojis are the same beast in a tighter outfit:** they also signal indecision, and the same cautious, half‑size‑position approach applies.  

In short, treat spinning tops and Dojis as **market mood‑lights**—they tell you the room is dim, not whether it will turn bright or stay dark. Stay flexible, keep your position size modest, and let the next candle give you the final word. Happy trading!