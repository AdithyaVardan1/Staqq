# 15. Indicators (Part 2)

**Source:** https://zerodha.com/varsity/chapter/indicators-part-2/

---  

##  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M2-Ch15-title1.jpg)

## 15.1 Moving Average Convergence and Divergence (MACD)

Picture the 1970s: bell‑bottoms, disco, and a guy named Gerald Appel tinkering with spreadsheets in his basement. He birthed the **Moving Average Convergence and Divergence**, or MACD for short—a mouthful that sounds like a sci‑fi weapon, but it’s really just a clever way of watching two EMAs argue over who’s the cooler one.

> **Bottom line:** MACD is the grand‑daddy of momentum indicators. Even after 50 years it still gets invited to the party because it usually tells the truth.

### How MACD is cooked up

1. **Pick two EMAs** – the classic recipe uses a 12‑day EMA (the sprinter) and a 26‑day EMA (the marathoner). Both are based on *closing* prices, because who cares about the intraday drama when you’re looking at trends?
2. **Subtract** the long‑term EMA from the short‑term EMA  

   \[
   \text{MACD value} = \text{EMA}_{12} - \text{EMA}_{26}
   \]

   The result is a single line that wiggles around zero – we call it the **MACD line**.

Let’s walk through a tiny spreadsheet (imagine a table of Nifty close prices starting 1 Jan 2014).  

* The first 12 rows are needed to seed the 12‑day EMA.  
* The first 26 rows are needed to seed the 26‑day EMA.  
* Once both EMAs are alive on **6 Feb 2014**, we can compute MACD:  

  *EMA₁₂ = 6 153, EMA₂₆ = 6 198 → MACD = 6 153 − 6 198 = **‑45**.*

Plot those MACD values day‑by‑day and you’ll see a line that drifts above and below the zero **centerline**.

### The three “obvious” questions

| Question | What it means |
|----------|---------------|
| **Negative MACD?** | The 12‑day EMA is lagging the 26‑day EMA → momentum is *downhill*. The farther below zero, the steeper the decline. |
| **Positive MACD?** | The short‑term EMA is leading the long‑term EMA → momentum is *uphill*. Bigger positive numbers = stronger up‑trend. |
| **Magnitude matters** | A –90 is a *stronger* bearish signal than a –30. Same rule for the positive side. Remember, high‑priced assets (e.g., Bank Nifty) naturally produce larger MACD numbers because the EMAs themselves are larger. |

The gap between the two EMAs is called the **MACD spread**. When the spread narrows, the momentum is calming; when it widens, the momentum is heating up.

### MACD line vs. centerline

Below is the MACD line for Nifty from 1 Jan 2014 to 18 Aug 2014.

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M2-Ch15-Chart1.jpg)

*The line bounces over the zero line (aka the **centerline**).*

**Key rules**

* **Cross‑up** (negative → positive) → the two EMAs are diverging → bullish momentum → consider buying.  
  *Example: around 27 Feb the line jumps above zero.*
* **Cross‑down** (positive → negative) → the two EMAs are converging → bearish momentum → consider selling.  
  *Example: near 8 May and 24 Jul the line flirted with zero but bounced back.*

> **Pro tip:** Waiting for the zero‑cross can be like waiting for the barista to finish your latte—by the time it’s ready the crowd may have moved on.  

### Enter the **Signal Line** (the sidekick)

To get earlier hints we add a **9‑day EMA of the MACD line**. Now we have two lines:

1. **MACD line** (black)
2. **Signal line** (red) – a 9‑day EMA of that black line.

Now we can trade *line‑crossovers* instead of waiting for the zero line.

| Situation | What it says |
|-----------|--------------|
| **MACD line > Signal line** (crosses upward) | Bullish → look for a long entry. |
| **MACD line < Signal line** (crosses downward) | Bearish → look for a short entry. |

#### Example on Asian Paints

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M2-Ch15-Chart2.jpg)

* Black = MACD line (12 – 26 EMA)  
* Red = 9‑day EMA of that line (the signal line)  

Vertical bars mark the moments the two lines cross:

* **First bar** – MACD below signal → short signal.  
* **Second bar** – MACD above signal → long signal.  

Just like a moving‑average system, MACD shines in *trendy* markets and gets confused when the price is meandering sideways. Notice the first two‑line pair on the chart: they whine a lot in a flat market.

> **Feel free to tweak the numbers** – you can try 10‑day/20‑day EMAs, 5‑day signal, etc. My personal favourite? The original Gerald‑Appel recipe (12‑26‑9). It’s the “original flavor” that never goes out of style.

---

## 15.2 The Bollinger Bands

Fast forward to the 1980s: neon leg warmers, shoulder pads, and a guy named **John Bollinger** who decided that volatility needed a visual hug. He invented **Bollinger Bands (BB)** – three lines that act like a stretchy rubber band around price.

### The three‑part sandwich

| Component | How it’s built |
|-----------|----------------|
| **Middle line** | 20‑day **Simple Moving Average** (SMA) of closes. |
| **Upper band** | Middle line **+ 2 × standard deviation** (SD). |
| **Lower band** | Middle line **‑ 2 × SD**. |

**Standard deviation** is the statistical cousin of “how much does this stock swing around its average?”. A 12 % SD means the price typically wanders ±12 % from its mean.

### Quick arithmetic

* Suppose 20‑day SMA = **7 800**.  
* SD = **75** points (≈ 0.96 %).  

Upper band = 7 800 + 2 × 75 = **7 950**  
Lower band = 7 800 ‑ 2 × 75 = **7 650**

So we have:

* 20‑day SMA = 7 800  
* Upper band = 7 950  
* Lower band = 7 650  

### What the bands whisper

* **Price near the upper band** → “Hey, I’m pricey compared to my 20‑day average. Maybe it’ll slip back.” → **Sell** near the upper band, aim for the SMA (≈ 7 800).  
* **Price near the lower band** → “I’m cheap, might bounce up.” → **Buy** near the lower band, target the SMA.

In other words, the bands are *trigger zones*: touch the top → think “short”; touch the bottom → think “long”.

#### BB in action – BPCL

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M2-Ch15-Chart3.jpg)

* Black = 20‑day SMA.  
* Red = Upper (+2 SD) and lower (‑2 SD) bands.  

The red arrows point at places where price hit the upper band – we’d have sold there, hoping for a pull‑back. Most of those signals worked, **except** for a stretch where price clung to the upper band and kept marching higher. That’s called an **envelope expansion**.

### Envelope expansion – why BB can choke

When price trends strongly, the bands *stretch* to accommodate the move, forming a wide envelope. In that scenario the bands lose their “mean‑reversion” magic and generate **false signals**. Bottom line:

* **Sideways market** → BB shines (prices bounce between the bands).  
* **Trending market** → BB’s envelope expands → many whiffs.

When I use BB, I expect the trade to turn favorable **quickly**. If it stalls, I start checking for an envelope expansion.

---

## 15.3 Other Indicators

There are **zillions** of technical gadgets out there—awesome, but also overwhelming. Do you need to memorize every single one to be a profitable trader? **Nope.** Think of indicators as a toolbox: you only need the hammer and the screwdriver for most jobs. A solid grasp of the few we covered (MACD, Bollinger Bands, plus the usual candlesticks, support/resistance, volume) is more than enough.

---

## 15.4 The Checklist (with a twist)

We’ve been building a **trade‑entry checklist** throughout the course. Time to sprinkle indicators onto it, but not let them run the show.

### Updated checklist (bullet‑proof)

1. **Candlestick pattern** – recognizable and reliable (e.g., hammer, engulfing).  
2. **Support & Resistance** – the low of a bullish pattern should sit near support; the high of a bearish pattern should sit near resistance.  
3. **Volume** – above‑average on the entry day (and preferably on the exit day). Low volume = “meh, let’s wait”.  
4. **Indicators** – confirm the trade **or** adjust position size.

> **The twist:** If the first three items tick all the boxes, you *still* trade even if the indicator is silent. You just **scale down** the size.

### Walk‑through example

*Stock:* Karnataka Bank Ltd.  
*Signal:* Bullish hammer, support line matches the hammer low, volume is chugging along, **and** MACD line just crossed above the signal line.

All four boxes are checked → I’m comfortable buying **500 shares**.

Now imagine the MACD **doesn’t** cross (the first three boxes are still green). What do I do?

I’ll still buy, but only **300 shares**. The indicator isn’t a deal‑breaker; it just tells me to be a bit more cautious.

**Bottom line:**  

* **If indicators confirm** → **upsize** your bet.  
* **If they don’t** → **downsize**, but don’t abandon a solid setup.

I *never* compromise on the first three items. If the hammer’s low isn’t near support, I’ll walk away. Indicators are nice companions, not the boss.

---

### Key takeaways from this chapter

- **MACD** is a trend‑following system built on a 12‑day EMA, a 26‑day EMA, and a 9‑day EMA (the signal line).  
- The **MACD line** = 12‑day EMA − 26‑day EMA; the **signal line** = 9‑day EMA of the MACD line.  
- Trade the **crossover** of MACD line ↔ signal line for earlier entries than waiting for the zero‑line cross.  
- **Bollinger Bands** capture volatility with a 20‑day SMA flanked by ± 2 × standard‑deviation bands.  
- **Short** when price touches the upper band, targeting the SMA; **long** when price touches the lower band, targeting the SMA.  
- BB excels in **sideways** markets; during strong trends the bands stretch (envelope expansion) and generate many false signals.  
- Indicators are **useful**, but they’re **not the sole decision‑maker**. Use them to **size** your position, not to *make* the trade.

Happy chart‑watching, and may your lines cross in the right direction! 🍻