# 16. The Fibonacci Retracements  

**Source:** https://zerodha.com/varsity/chapter/fibonacci-retracements/  

---  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M2-Ch16-title.jpg)  

So, you’ve heard the word *Fibonacci* tossed around on trading forums and thought it was the name of a new crypto‑coin. Spoiler alert: it’s not. It’s actually a centuries‑old number‑play that somehow sneaks its way into stock charts, pinecones, and even the way you arrange your pizza toppings. To appreciate why traders love Fibonacci retracements, we first need to get cozy with the **Fibonacci series** itself.  

## The origin story (minus the drama)

Long before Leonardo da Vinci was doodling the Vitruvian Man, ancient Indian scholars were scribbling numbers that looked suspiciously like our beloved sequence. Some historians even claim a 200 BC manuscript contains a proto‑Fibonacci list. Fast forward to the 12th century, when an Italian math whiz from Pisa named **Leonardo Pisano – aka Fibonacci** (because “Fibonacci” sounds cooler than “Leonardo”) decided to formalise the pattern.  

The Fibonacci series is just a simple list of numbers that starts at zero and each new term is the sum of the two that came before it. Like a financial‑advisor version of “the more the merrier”:  

```
0, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610 …
```

See the magic?  

* 233 = 144 + 89  
* 144 = 89 + 55  
* 55 = 34 + 21  

…and it just keeps marching on forever—kind of like my inbox after a market‑wide rally.  

### A couple of “wow” properties (because we love nerd‑y tricks)

1. **The Golden Ratio (Φ ≈ 1.618)** – Divide any term by the one right before it and you’ll hover around 1.618.  

   ```
   610 / 377 ≈ 1.618
   377 / 233 ≈ 1.618
   233 / 144 ≈ 1.618
   ```  

   This number is called **Phi** or the **Golden Ratio**. It shows up in everything from the spiral of a nautilus shell to the proportions of the Parthenon (and apparently in the way your favourite meme spreads).  

2. **The “reverse” ratio (≈ 0.618 or 61.8 %)** – Flip the division (larger number ÷ smaller number) and you get roughly 0.618.  

   ```
   89 / 144 ≈ 0.618
   144 / 233 ≈ 0.618
   233 / 377 ≈ 0.618
   ```  

   In plain English: 61.8 % is the “sweet spot” many traders watch for retracements.  

3. **Two‑step‑away ratio (≈ 0.382 or 38.2 %)** – Divide a term by the one **two places** ahead.  

   ```
   13 / 34 ≈ 0.382
   21 / 55 ≈ 0.382
   34 / 89 ≈ 0.382
   ```  

4. **Three‑step‑away ratio (≈ 0.236 or 23.6 %)** – Same idea, three places apart.  

   ```
   13 / 55 ≈ 0.236
   21 / 89 ≈ 0.236
   34 / 144 ≈ 0.236
   ```  

All of these percentages—61.8 %, 38.2 %, 23.6 %—are the numbers that will start popping up in the next sections when we talk about stock charts.  

---

## 16.1 – Why traders care about Fibonacci in the market

The theory goes like this: whenever a stock makes a **big, bold move**—either soaring like a rocket or diving like a submarine—it rarely just keeps going in that direction forever. It usually pulls back a bit, takes a breather, and then decides whether to keep the original trend alive.  

Imagine a stock marching from **₹50 to ₹100**. Many traders believe it will *retrace* somewhere around the 61.8 % level (≈₹70) before it possibly rallies to, say, ₹120. Those retracement levels (61.8 %, 38.2 %, 23.6 %) become a sort of “where‑might‑it‑pause‑party” for the price.  

### A live chart example (because pictures speak louder than words)

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M2Ch16-chart1.jpg)  

In the picture above I’ve highlighted two crucial points:  

* **Start of the rally:** ₹380  
* **Peak of the rally:** ₹489  

The **total up‑move** = 489 – 380 = **₹109**.  

Now, using the Fibonacci theory, we ask: *How far could the price pull back?*  

* **23.6 % retracement** → 0.236 × 109 ≈ ₹25.8  
* **38.2 % retracement** → 0.382 × 109 ≈ ₹41.6  
* **61.8 % retracement** → 0.618 × 109 ≈ **₹67.4**  

If the market respects the 61.8 % level, the price should dip to around **₹489 – ₹67.4 ≈ ₹421.6** before resuming its climb.  

And guess what? That’s exactly what happened (see the next chart).  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M2Ch16-chart2.jpg)  

You can verify the math yourself:  

```
Total up‑move = 109
61.8% of 109 = 67.36
Retracement price = 489 – 67.36 = 421.64 ≈ 421.6
```  

Most charting platforms will draw those levels automatically, so you don’t have to be a spreadsheet wizard.  

### A shorter rally example

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M2Ch16-chart3.jpg)  

Here the stock went from **₹288 → ₹338** (a tidy ₹50 swing). It pulled back about **38.2 %**, landing near **₹319**, and then kept marching upward.  

### Down‑trend retracements (because markets aren’t all sunshine)

Fibonacci isn’t just for bull runs. It works just as well when prices are in a free‑fall.  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M2Ch16-chart4.jpg)  

Take DLF Limited: it fell from **₹187** to **₹120.6**, a **₹66.4** drop. The price then bounced up to **₹162**, which is roughly the 61.8 % retracement level of that decline.  

---

## 16.2 – How to actually draw a Fibonacci retracement

Alright, now that you’ve seen the magic, let’s get hands‑on. The first thing you need is the **100 % move**—the full swing you want to measure. That could be a rally or a slump. You locate the most recent **peak** and **trough** on your chart, then hook the built‑in Fibonacci tool between them.  

Most charting software (including Zerodha’s **Pi**) has a ready‑made “Fibonacci retracement” button. Here’s a quick‑and‑dirty walkthrough:  

### Step‑by‑step (with screenshots, because we’re visual learners)

1. **Identify the recent trough and peak.**  
   In this toy example the trough sits at **150**, the peak at **240**. The move is **90 points**, which we treat as 100 %.  

   ![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M2Ch16-chart5.jpg)  

2. **Select the Fibonacci retracement tool** from the toolbar.  

   ![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M2Ch16-chart6.jpg)  

3. **Click the trough first**, then **drag the line up to the peak** *without releasing* the mouse button. As you stretch the line, the software automatically plots the 23.6 %, 38.2 %, 50 %, 61.8 % (and sometimes 78.6 %) levels.  

   ![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M2Ch16-chart7.jpg)  

4. **Release the mouse** once you hit the peak. The full set of retracement levels now sticks to your chart like a cling‑film on leftovers.  

   ![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M2Ch16-chart8.jpg)  

Now you have a visual “ladder” of possible pull‑back zones. Use them to plan entries, exits, or just to impress your friends with fancy chart‑reading lingo.  

---

## 16.3 – Putting the retracement levels to work (without turning into a fortune‑teller)

Picture this: you’ve spotted a stock you *really* want to own, but it’s already spiking like a caffeine‑fueled kangaroo. Jumping in now would be like buying a concert ticket at the last minute—expensive and risky.  

**Enter the Fibonacci retracement** as your “price‑pause detector.” The 61.8 %, 38.2 %, and 23.6 % levels give you probable zones where the price might stall before it either continues its march or flips direction.  

### How to combine Fibonacci with your usual “trade‑checklist”

Don’t treat Fibonacci as a crystal ball; treat it as a **confirmation** tool. Here’s a quick recipe I use before shouting “BUY!” at the market:  

| Checklist Item | Why it matters |
|----------------|----------------|
| **Candlestick pattern** (e.g., bullish engulfing) | Shows real‑time buyer aggression. |
| **Stop‑loss aligns with a strong S&R level** | Gives you a safety net if the market decides to be a drama queen. |
| **Volume > average** | High volume means the move is backed by actual money, not just wishful thinking. |
| **Fibonacci level (61.8 % / 38.2 % / 23.6 %) coincides with S&R** | Adds an extra layer of confidence—multiple signals converging. |

If all the above line up, I’ll call it a **“strong buy.”** The word *strong* isn’t just for bragging rights; it tells my brain (and my broker) that I have a high conviction, and I’m willing to allocate a decent chunk of capital.  

The same logic works in reverse for **short trades**: look for a bearish candlestick, a stop‑loss near a resistance level, low volume on the upside, and a retracement bounce off a Fibonacci level.  

---

### Key takeaways from this chapter (the cheat‑sheet you can actually use)

- **Fibonacci series** is the mathematical backbone of Fibonacci retracements.  
- The series has *crazy* internal ratios (1.618, 0.618, 0.382, 0.236) that appear in nature, art, and—yes—stock charts.  
- Traders believe those ratios highlight **potential pull‑back zones** after a strong price move.  
- The three most‑watched retracement levels are **61.8 %, 38.2 %, and 23.6 %**.  
- When price hits one of these zones, it can be a good moment to **enter a trade in the direction of the original trend**, **provided** other checklist items (candlestick patterns, stop‑loss placement, volume, etc.) also give you a thumbs‑up.  

Now go forth, draw those Fibonacci ladders, and may your retracements be ever in your favour! 🍀📈  