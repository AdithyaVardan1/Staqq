# 18. The Dow Theory (Part 2)

**Source:** https://zerodha.com/varsity/chapter/dow-theory-part-2/

---  

## 18.1 – Trading Range  

Think of a trading range as the “meh‑zone” of the market – the place where price just can’t make up its mind. It’s the financial equivalent of that friend who keeps flipping between pizza and burgers for weeks. The stock keeps bouncing between the same ceiling and floor over and over, giving the whole scene the nickname *sideways market* (or *sideways drift* if you fancy a little alliteration).  

Why does it happen? Because buyers and sellers are both sitting on the fence, sipping their coffee, and waiting for a sign. No one is bold enough to push the price beyond the established support (the floor) or resistance (the ceiling). Long‑term investors often get a migraine watching this indecision, but short‑term traders love it – it’s a buffet of “buy low, sell high” (or “sell high, buy low” if you’re feeling rebellious).  

In the chart below you can see a textbook example of a range‑bound beast:  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M2-Ch18-Chart1.jpg)  

The price keeps hitting the **upper bound at ₹165** and the **lower bound at ₹₹128** like a ping‑pong ball. The distance between those two levels is the *width* of the range. A simple way to profit is to **buy near the bottom** (₹128‑ish) and **sell near the top** (₹165‑ish). Of course, you can also do the opposite – short at the ceiling and cover near the floor – if you enjoy living on the edge.  

Notice the little candlestick story hidden in the picture (the encircled candles on the left):  

| Candle | What it whispers |
|--------|-------------------|
| **Bullish engulfing** | “Hey, the bulls are getting cozy.” |
| **Morning‑doji‑star** | “A calm sunrise after a night of chaos.” |
| **Bearish engulfing** | “Time to bring the umbrellas, folks.” |
| **Bearish harami** | “Small baby candle, big bad trend ahead.” |

These patterns are like traffic lights for the short‑term trader – green means go, red means stop, and yellow means “maybe grab a coffee first”.  

A range can last **a few weeks** or **a couple of years**. The longer it lingers, the fatter the width usually gets, giving you a bigger playground (and a bigger potential profit – if you can survive the boredom).  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M2-Ch18-title1.jpg)  

---  

## 18.2 – The Range Breakout  

All good things (and all bad things) must eventually end, and so does a range. But before we talk about the breakout, let’s ask the obvious: **Why does a stock sit in a range in the first place?**  

1. **No meaningful fundamentals** – No quarterly earnings surprise, no shiny new product, no CEO‑level drama. The company is just… existing. In such a “nothing‑to‑see‑here” environment, the price gets comfy in a box and refuses to leave.  
2. **Waiting for a big announcement** – The market senses a bomb (good or bad) is about to drop, so everyone holds their horses. Buyers and sellers both whisper, “What if it’s bad? What if it’s great?” and the price hovers in a narrow tunnel until the news finally lands.  

When the trigger finally arrives, the price *breaks out* – either upward through resistance or downward through support. Think of the range as a **pressurized soda can**: every day the pressure builds a little more, and when the tab finally pops, the fizz shoots out with a bang.  

### True breakout vs. false breakout  

*False breakout* = the tab pops, but the fizz fizzles out because the “trigger” wasn’t strong enough. Usually you’ll see **low volume** and **weak momentum**; the market‑smart money isn’t even there. The price often snaps back into the range, leaving the impatient retail trader with a bruised ego (and possibly a bruised wallet).  

*True breakout* has two tell‑tale signs:  

- **High volume** – the crowd is actually showing up.  
- **Strong momentum** – the price is moving faster than a caffeinated squirrel.  

Take a look at the next chart:  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M2-Ch18-Chart2.jpg)  

The stock tried to escape three times. The first two attempts were *false* – low volume, sluggish momentum. The third attempt had the full party: big volume and a rapid price surge. That’s the breakout you want to ride.  

---  

## 18.3 – Trading the Range Breakout  

The golden rule: **Enter as soon as the price breaks the wall with healthy volume, and always protect yourself with a stop‑loss**. You can never be 100 % sure the momentum will keep marching, so a safety net is a must.  

### Example 1 – Long breakout  

- **Range:** ₹128 – ₹165  
- **Breakout:** Price punches above ₹165 and lands at ₹170.  

**Action:** Go long at ₹170, set stop‑loss right at the old resistance (₹165). If the breakout is genuine, the price should keep climbing.  

### Example 2 – Short breakdown  

- **Range:** Same as above.  
- **Breakdown:** Price slides below ₹128 and settles at ₹123.  

**Action:** Short at ₹123, stop‑loss at the old support (₹128).  

### Targeting the move  

If the breakout is legit, the price often travels at least the *width* of the previous range.  

- **Width** = Upper – Lower = ₹165 – ₹128 = **₹37**  
- **Breakout price** (say) = ₹168  
- **Minimum target** = ₹168 + ₹37 = **₹205** (rounded a bit for illustration)  

In practice you might aim a little higher if the momentum stays hot, but never forget the stop‑loss – it’s the only thing that keeps your night’s sleep intact.  

---  

## 18.4 – The Flag Formation  

Picture a race‑horse that bursts out of the gate, hits top speed, then eases off for a short lap while the crowd cheers. In chart‑land that’s a **flag**: a steep, almost vertical rally (the “pole”) followed by a modest, parallel‑sided correction (the “flag”).  

The correction usually lasts **5‑15 trading sessions** and stays between two roughly parallel trendlines, creating a rectangular or parallelogram shape that looks like a nautical flag on a mast.  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M2-Ch18-Chart3.jpg)  

When the flag finishes its little nap, the price **springs back up** and often continues the original rally with gusto.  

### Why does this happen?  

- The initial rally forces profit‑taking. Retail traders who rode the wave start selling to lock in gains.  
- This selling pressure creates the modest pull‑back (the flag).  
- Meanwhile, the “smart money” (institutional players, insiders, etc.) is still fully invested, keeping the overall sentiment bullish.  

So the flag is basically **the market’s way of saying “I need a breather, but I’m still excited”**. For a trader who missed the first surge, the flag is a second‑chance invitation – but you’ve got to be quick because the price usually rockets out of the flag faster than a cat on a laser pointer.  

---  

## 18.5 – The Reward‑to‑Risk Ratio (RRR)  

RRR isn’t exclusive to Dow Theory; it’s the **universal law of “don’t gamble with your lunch money”**. Whether you’re a technical trader or a fundamental investor, you should always ask: *“What am I risking, and what could I possibly win?”*  

### A quick‑math example  

| Detail | Value |
|--------|-------|
| **Entry** | 55.75 |
| **Stop‑loss** | 53.55 |
| **Target** | 57.20 |

- **Risk** = Entry – Stop‑loss = **55.75 – 53.55 = 2.20** points  
- **Reward** = Target – Entry = **57.20 – 55.75 = 1.45** points  
- **RRR** = Reward / Risk = **1.45 / 2.20 ≈ 0.66**  

A ratio below 1 means you’re *risking more than you could possibly earn* – not a great trade unless you have some magical reason to believe the odds are stacked in your favour.  

### A healthier trade  

| Detail | Value |
|--------|-------|
| **Entry** | 107 |
| **Stop‑loss** | 102 |
| **Target** | 114 |

- **Risk** = 107 – 102 = **5** points  
- **Reward** = 114 – 107 = **7** points  
- **RRR** = **7 / 5 = 1.4**  

Now you’re earning **₹1.40 for every ₹1.00 you risk** – a much nicer deal.  

#### Personal RRR preferences  

- **Ultra‑conservative**: RRR ≥ 2.0 (risk ₹1, expect at least ₹2).  
- **Moderately aggressive**: RRR ≥ 1.5 (my sweet spot).  
- **Very aggressive**: RRR ≈ 1.0 (risk‑reward break‑even).  

If a trade fails to meet your personal threshold, **throw it away**. Even a perfect‑looking pattern isn’t worth the gamble if the math says otherwise.  

### Real‑world illustration  

Suppose a **bearish engulfing** candle shows up at the top of a double‑top, volume is 30 % above the 10‑day average, and there’s medium‑term support nearby. Looks like a textbook short, right?  

| Parameter | Value |
|-----------|-------|
| **Entry** | 765.67 |
| **Stop‑loss** | 772.85 |
| **Target** | 758.50 |
| **Risk** | 772.85 – 765.67 = **7.18** |
| **Reward** | 765.67 – 758.50 = **7.17** |
| **RRR** | 7.17 / 7.18 ≈ **1.0** |

Because my personal rule is **RRR ≥ 1.5**, I would **skip** this trade despite the perfect technical setup. I’d rather wait for a setup that gives me a healthier payoff.  

---  

## 18.6 – The Grand Checklist  

Now that we’ve covered candles, support‑resistance, volumes, breakouts, flags, and RRR, let’s bundle everything into a **cheat‑sheet** you can glance at before you click “Buy” or “Sell”.  

| ✅ Checklist Item | 🎯 What to Look For |
|-------------------|---------------------|
| **Candlestick pattern** | Recognisable bullish or bearish formation (engulfing, harami, etc.). |
| **Support/Resistance** | For longs, entry near support; for shorts, entry near resistance. Stop‑loss should sit just beyond the opposite side. |
| **Volume confirmation** | Above‑average volume on entry day (and preferably on exit day). Low volume = “meh, maybe skip”. |
| **Dow Theory lens** | Identify primary trend (long‑term) and secondary trend (short‑term). Make sure your trade aligns with the primary direction, or be extra cautious if it opposes it. |
| **Pattern type** | Is it a double, triple, range, or flag formation? Verify it matches a classic Dow shape. |
| **Indicator check** | If your favourite technical indicators (RSI, MACD, etc.) agree, you can consider scaling up position size. If they disagree, stick to a modest size. |
| **Reward‑to‑Risk (RRR)** | Calculate risk = entry – stop‑loss; reward = target – entry. Ensure RRR ≥ your personal threshold (≥ 1.5 for most active traders). |
| **Stop‑loss placement** | Set it at the logical level (just beyond support/resistance, or below the low of the candle pattern). |
| **Target** | At least the width of the range or flag, or based on a measured move (e.g., 1×, 2× the range). |

**How to use it:**  

1. Spot a potential trade.  
2. Run through each line of the checklist.  
3. If you tick **all** (or most) boxes, you have a *high‑probability* setup.  
4. If you miss a crucial box (e.g., low volume, bad RRR), either adjust the trade (smaller size) or skip it altogether.  

Following this disciplined routine will **reduce emotional decision‑making** and give you a solid audit trail for every trade you take.  

---  

## 18.7 – What Next?  

We’ve just unpacked a *lot* of technical‑analysis goodness: ranges, breakouts, flags, RRR, and a full‑blown checklist that even a sleep‑deprived night‑owl can follow. If you feel like you still have a gap in your knowledge (maybe you’ve never seen a **Gann fan** or a **Ichimoku cloud**), remember that **Varsity only covers what you need to start trading responsibly**.  

If you truly want to become a *TA ninja*, devote time to **master each concept**, practice on paper, then on a small live account. The next natural step is to learn how to **back‑test your strategies**, tighten your **risk‑management** framework, and polish the all‑important **trading psychology**. All of those will be covered in upcoming modules.  

### Quick recap – takeaways from this chapter  

- A **range** is formed when price oscillates between two horizontal levels (support & resistance).  
- You can **buy low and sell high** (or short high and cover low) within that corridor.  
- Ranges appear because **nothing fundamental is moving the stock** or because the market is **waiting for an event**.  
- A **breakout** signals a possible new trend; look for **high volume** and **strong momentum** to confirm it.  
- The **flag pattern** is a short‑term correction after a steep rally – a second chance to jump on the upward move.  
- **RRR** is the cornerstone of trade evaluation; set a personal minimum (1.5 is a good rule‑of‑thumb).  
- Always view any trade through the **Dow Theory lens** (primary & secondary trends, formation type).  

Keep the checklist handy, stay disciplined, and remember: **the market rewards patience, preparation, and a good sense of humor**. Cheers to profitable (and fun) trading!  