# 19. The Finale – Helping You Get Started  

**Source:** https://zerodha.com/varsity/chapter/finale-helping-get-started/  

---  

##  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/11/M2-Ch19-illustration1.jpg)  

## 19.1 – The Charting Software  

After slogging through the previous 18 chapters you’ve now swallowed enough technical‑analysis jargon to sound like a walking Bloomberg ticker. If you’ve actually understood most of it (or at least pretended convincingly), you’re ready to dip your toes into live‑trading waters. This last chapter is the “how‑do‑I‑actually‑trade‑today?” guide – my personal cheat‑sheet based on years of buying, selling, and occasionally screaming at my screen.  

### Why you *need* a charting platform  

Think of a charting platform as the TV for your stock‑watching habit. You can have the biggest screen in the world, but if you don’t have a signal, you’ll just stare at a black rectangle. The platform is that signal‑receiver: it pulls price data, draws candles, lets you add indicators, and generally makes you look like a professional when you brag to friends.  

There are a handful of heavy‑weight paid options out there; the two most popular are **MetaStock** and **AmiBroker**. Most full‑time technical analysts swear by one of them – they’re like the “iPhone” of charting: sleek, powerful, and pricey.  

Free alternatives exist on Yahoo Finance, Google Finance, and basically any news site that wants to look smart. They’re fine for a casual glance, but if you’re serious about becoming a technical analyst, treat a good charting package as a non‑negotiable investment.  

> **Analogy alert:** A charting program is like a DVD player. You buy the player (the software) and then you still need DVDs (the data). Without the DVDs you can’t watch *any* movies.  

### Data feeds – the “DVDs” you must rent  

In India you’ll need a data vendor to supply the price stream that your charting software will chew on. Look up reliable vendors, tell them which platform you’ve bought, and they’ll give you a feed in the right format (usually .txt or .csv). The feed isn’t free – you pay a one‑time “setup” fee for historic data, then a recurring annual charge for live updates.  

From my own wallet‑draining experience:  

| Item | Approximate Cost (₹) |
|------|----------------------|
| MetaStock / AmiBroker (latest version) | 25,000 – 30,000 (one‑time) |
| Data‑feed subscription (annual) | 15,000 – 25,000 |

Older versions can be a lot cheaper, but they may lack the newest indicators or faster rendering.  

### The “budget‑friendly” alternative: Zerodha Pi  

If you’re thinking “I’ll just keep buying coffee and hope it pays for the software”, meet **Zerodha’s Pi** – a free, all‑in‑one trading terminal that bundles charting and data feed together. Here’s why Pi might just become your new best friend:  

- **Bundled** – No separate data‑feed bill; it’s all included.  
- **Great Visualisations** – Multi‑time‑frame charts, from tick‑by‑tick to monthly, all in one window.  
- **80+ built‑in indicators + 30+ drawing tools** – Enough to make a Quant cry with joy.  
- **Strategy Scripting & Back‑testing** – Write Pine‑like scripts, test on historic candles (yes, Varsity will cover this soon).  
- **Pattern‑Recognition Engine** – Spot a “cup‑and‑handle” across the market with a single click.  
- **Trade‑direct‑from‑chart** – Click a candle, trade a share. No more toggling between windows.  
- **Massive Historical Dump** – Over 50,000 candles per instrument, perfect for robust back‑testing.  
- **Expert Advisor** – Real‑time alerts when your favourite patterns start forming.  
- **AI & Genetic Algorithms** – Fancy optimisation tools that try to “evolve” a better strategy (don’t worry, you won’t need a PhD).  
- **Zero Cost** – Free for all active Zerodha traders.  

The feature list runs the gamut from “basic” to “NASA‑level”. My advice: fire up Pi, play with it for a week, and only then consider shelling out cash for a pricey desktop package.  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/11/M2-Ch19-illustration6.jpg)  

---  

## 19.2 – Which Timeframe to Choose?  

We covered timeframes back in Chapter 3 – give that a quick skim if the terms “1‑minute”, “EOD”, “weekly” sound like a foreign language.  

Choosing a timeframe is the single biggest source of head‑ache for a rookie analyst. You have everything from 1‑minute candles (the “espresso shot” of charting) to yearly candles (the “slow‑cooked stew”).  

**Rule of thumb:** *The higher the timeframe, the more reliable the signal.* A bullish engulfing on a 15‑minute chart is far more trustworthy than the same pattern on a 5‑minute chart, because the longer chart has filtered out a lot of noise.  

### How long do you plan to hold?  

- **Positional / Swing Trading** – Hold a few days to a few weeks. Ideal for beginners. Look back 6 months – 1 year to get the right context.  
- **Scalping** – Hold minutes (or even seconds). Use 1‑minute or 5‑minute charts; you’ll need a lookback of just a few days.  

If you’re fresh out of the gate, avoid day‑trading madness. Start with swing‑trades, let the market do most of the work, and only later graduate to the high‑octane world of intraday. The transition varies per person, but disciplined traders usually make the jump faster than a caffeinated rabbit.  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/11/M2-Ch19-illustration3.jpg)  

---  

## 19.3 – Lookback Period  

The lookback period is simply “how many candles back do I peek at before I decide?”.  

- **Swing trader:** 6 months – 1 year of daily candles. Gives you a clear sense of the medium‑term trend and where support/resistance sits.  
- **Scalper:** 5 days of 1‑minute candles – enough to gauge recent volatility and volume spikes.  

When you’re drawing **Support & Resistance (S&R)** levels, stretch the lookback to **2 years**. Longer history smooths out outliers and gives you more confidence that the levels you draw aren’t just a fluke.  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/11/M2-Ch19-illustration4.jpg)  

---  

## 19.4 – The Opportunity Universe  

There are roughly **6,000** stocks on the BSE and **2,000** on the NSE. Scanning all of them daily is like trying to read every book in a library in one night – exhausting and ineffective.  

Instead, carve out a **personal “Opportunity Universe”** – a manageable bucket of stocks you’ll watch every day. Here’s how to build one:  

- **Liquidity matters.** Look at the bid‑ask spread: the tighter, the better. A rule‑of‑thumb is a *minimum daily volume of 500,000 shares*.  
- **Stay in the EQ segment.** Only equities (EQ) can be day‑traded on Indian exchanges. (You can still swing‑trade an EQ stock even if you exit intraday.)  
- **Avoid “operator‑driven” stocks.** These are the ones that move because a big fund or a promoter is pulling strings. No clean metric for this; experience will teach you to spot the weird price‑volume combos.  
- **If you can’t meet the above**, fall back to the **Nifty 50** (or Sensex 30). Index constituents are pre‑screened for liquidity, corporate governance, and market relevance. They make an excellent starter universe for both swing‑traders and scalpers.  

Keeping your universe tight (say 30‑50 stocks) lets you scan quickly and stay disciplined.  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/11/M2-Ch19-illustration5.jpg)  

---  

## 19.5 – The Scout  

Now that you have a platform, timeframe, lookback, and a curated universe, let’s talk **how** to actually hunt for trades. I’ll walk you through my two‑step scouting process – the same routine I use every morning before my first cup of chai.  

### The Four Pillars I’ve Already Set  

| Pillar | My Choice |
|--------|-----------|
| **Charting software** | Zerodha Pi (free & powerful) |
| **Timeframe** | End‑of‑Day (EOD) candles for swing trades |
| **Opportunity Universe** | Nifty 50 stocks |
| **Trade type** | Positional (hold a few days) with optional intraday exit if target hits early |
| **Lookback** | 6 months – 1 year (2 years for S&R) |

### Part 1 – Shortlisting  

1. **Open every chart** in your universe (yes, all 50 if you’re using the Nifty 50).  
2. **Zoom in on the most recent 3‑4 candles** – this is the “quick‑scan zone”.  
3. **Spot a candlestick pattern** (e.g., bullish engulfing, hammer, shooting star). If something catches your eye, **bookmark** that ticker and move on.  
4. **Repeat** until you’ve examined all charts.  

By the end of this sprint you’ll usually have **4‑5** candidates that showed a recognizable pattern.  

### Part 2 – Deep Evaluation  

For each shortlisted stock, I spend **15‑20 minutes** doing a forensic analysis. Here’s the checklist (feel free to print and tattoo it on your monitor):  

1. **Pattern Strength** – Is the candle clean or does it have long wicks? A Marubozu with a tiny shadow is stronger than one with a huge tail.  
2. **Prior Trend** – Bullish patterns need a preceding downtrend, bearish patterns need an uptrend. Trend confirmation is your first sanity‑check.  
3. **Volume Confirmation** – Current volume should be ≥ the 10‑day average. High volume adds muscle to the pattern.  
4. **Support/Resistance Alignment** – Plot the nearest S&R level. Ideally this should be *within 4 %* of the stop‑loss implied by the pattern. If it’s farther, toss the stock.  
5. **Higher‑order Patterns** – Look for double‑top/bottom, flags, or breakouts that could reinforce (or contradict) the candle. Also note the primary and secondary market trends.  
6. **Risk‑Reward Ratio (RRR)** – Compute target (next major S&R) and stop‑loss (pattern‑derived). Minimum RRR = **1.5** (i.e., you risk ₹1 to potentially make ₹1.5).  
7. **Oscillators** – Quick glance at MACD and RSI. Do they echo the direction of your trade? If you have spare cash, you might upsize the position (but stay within your risk budget).  

Usually, out of the 4‑5 shortlisted stocks, **only 1 or 2 survive** this gauntlet. Some days you’ll end up with *no* trades – that’s perfectly fine. Remember, **not trading is a trade**; the checklist is deliberately strict to keep your win‑rate healthy.  

> **Pro tip:** Once you place a trade, *don’t stare* at the screen. Let it run to your target or stop‑loss (you may trail the stop if you’re comfortable). The market will move; you just need to stay calm and trust your analysis.  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/11/M2-Ch19-illustration21.jpg)  

---  

## 19.5 – The Scalper  

If you’ve mastered swing‑trading and crave the adrenaline rush of making dozens of tiny profits in a single day, **scalping** is the sport for you. Think of it as the “speed‑run” mode of trading.  

A typical scalper trade looks like this (using Zerodha’s ultra‑low‑cost brokerage):  

- **Gross profit** after all charges ≈ **₹2,644** on a single 100‑share scalping burst.  
- If you were using an expensive broker, that profit could evaporate faster than a puddle in the sun. **Low‑cost brokerage = scalper’s lifeblood.**  

### Scalper’s Checklist (short and sweet)  

| Item | Why it matters |
|------|----------------|
| **Candlestick pattern + volume** | They’re the fastest signal combo; you don’t have time for a full checklist. |
| **RRR 0.5 – 0.75** | You’re aiming for *tiny* moves, so even a 1:0.5 ratio can be profitable when repeated. |
| **Liquidity** | Tight spreads and high volume keep slippage minimal. |
| **Rapid risk‑management** | Cut losses instantly; a 2‑tick move against you can wipe out a day’s profit. |
| **Bid‑Ask spread watch** | If the spread widens, your trade may become unprofitable before you even enter. |
| **Global market cues** | A sudden tumble in Hang Seng or Nikkei often triggers a ripple in Indian indices. |
| **Low‑cost broker** | Every rupee saved on commission adds to the scalper’s bottom line. |
| **Margin discipline** | Use only a fraction of your buying power; over‑leveraging is a fast track to disaster. |
| **Reliable intraday charting** | You need a snappy, real‑time chart (Pi works fine). |
| **Know when to quit** | If the market’s acting weird, step away – no point fighting a losing battle. |

Scalping is a mental marathon. You must be laser‑focused, emotionally detached, and comfortable watching your P&L flicker like a neon sign. Embrace the volatility; it’s the scalper’s playground.  

---  

### Key Takeaways from This Chapter  

- **Good charting software is non‑negotiable.** My personal favorite? Zerodha’s free Pi.  
- **EOD charts** work for both swing‑trading and day‑trading; switch to intraday only if you’re scalping.  
- **Lookback:** 6 months – 1 year for swing trades; extend to 2 years for solid S&R levels.  
- **Start with the Nifty 50** as your opportunity universe – it’s liquid, well‑covered, and easy to monitor.  
- **Scanning process:**  
  1. **Shortlist** – skim every chart, flag recognizable candlesticks.  
  2. **Evaluate** – run the full checklist (trend, volume, S&R proximity, RRR, MACD/RSI, etc.).  
- **Scalping** is best left to seasoned swing traders who already understand market mechanics and have the right tools.  
- **Discipline beats excitement** – once you’re in a trade, sit tight (or trail) and let your plan run its course.  

Now go forth, fire up Pi, and start hunting those charts. Remember, the market is a *lot* like a bar: you’ll meet many characters, some will be noisy, some will be quiet, but if you know the menu, you’ll always know what you’re ordering. Cheers to profitable chart‑watching! 🍻  