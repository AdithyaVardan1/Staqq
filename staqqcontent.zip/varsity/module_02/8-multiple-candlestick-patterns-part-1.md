# 8. Multiple Candlestick Patterns (Part 1)

**Source:** <https://zerodha.com/varsity/chapter/multiple-candlestick-patterns-part-1/>

---  

##  

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M2-Ch8-title.jpg)

## 8.1 – The Engulf‑Everything‑But‑Your‑Dinner Pattern  

When you were a kid, you needed *one* cookie to feel happy. In candlesticks, a **single‑candle** pattern needs just one bar to shout “Hey, there’s money here!”.  
But the **multiple‑candle** family is more like a sitcom: you need at least **two** (sometimes three) episodes before the joke lands. In other words, the trading signal unfolds over a minimum of two trading sessions.

The **engulfing pattern** is the grand‑daddy of these multi‑day setups. It needs exactly two sessions to finish its little drama. Picture day 1 showing a modest candle, and day 2 unfurling a giant candle that *literally swallows* the first one—think of a hungry shark gobbling a minnow.

* Bottom of a downtrend → **Bullish Engulfing** (the market says “I’m back, baby!”).  
* Top of an uptrend → **Bearish Engulfing** (the market whispers “Time to nap, bears.”).

---

## 8.2 – The Bullish Engulfing Pattern (aka “The Come‑Back Kid”)

The bullish engulfing pattern is a two‑candle love story that appears **at the bottom of a downtrend**. As the name suggests, it’s a *bullish* signal that tells you to go long—think of it as the market’s version of “I’m not mad, just disappointed”.

The chart below (green‑boxed) highlights the two candles. Here’s what you must see before you start popping champagne:

| Requirement | What it means |
|------------|---------------|
| **Prior trend** | Must be a genuine downtrend (prices falling like my motivation on a Monday). |
| **Day 1 (P1)** | A **red** candle confirming the bears are still in charge. |
| **Day 2 (P2)** | A **blue/green** candle long enough to *fully* engulf P1’s body (shadows optional, we’ll talk about that later). |

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M2Ch8-chart1.jpg)

### The mental movie behind a bullish engulfing

1. **Downtrend in full swing** – Prices are sliding down the slope like a kid on a slide.
2. **P1 opens low, makes a new low, closes lower** – The market is still wearing its bearish hoodie.
3. **P2 opens near P1’s close** – The bulls peek out from behind the curtain.
4. **Sudden buying frenzy** – Buyers jump in, push the price up, and *close* above P1’s open. The blue candle now looks like a proud superhero cape.
5. **Bears get the shock** – The sudden bull charge rattles the bears, making them nervous (just like you when the Wi‑Fi drops).
6. **Expectation of higher prices** – The market is now likely to climb for the next few sessions, giving you a nice entry point.

### How to trade the bullish engulfing

| Role | Entry point | Rules |
|------|-------------|-------|
| **Risk‑taker** | **Right on P2’s close** (or a few minutes before the market shuts). Must verify that P2 *engulfs* P1. | No waiting – you’re the early‑bird who likes fresh eggs. |
| **Risk‑averse** | **Next day (P3) close**, but only if P3 is a **blue** candle. If P3 turns red, you bail out (Rule 1 of candlesticks: *Buy strength, sell weakness*). | You prefer the “let‑it‑settle” approach. |
| **Stop‑loss** | The **lowest low** of the two candles (the bottom of the shark’s mouth). | Keeps the loss bounded if the market decides to swim away. |

> **Pro tip:** In two‑day patterns, the *risk‑taker* usually gets a better price because the move often continues on the same day. But if you’re a nervous‑nelly, waiting a day isn’t a crime.

### Real‑world example: DLF

| Candle | Open | High | Low | Close |
|--------|------|------|-----|-------|
| **P1** | 163 | 168 | **158.5** | 160 |
| **P2** | **159.5** | **170.2** | 159 | **169** |

The blue candle on P2 completely swallows the red candle of P1.

**Trade plan**

* **Risk‑taker:** Go long at around **169** (or a little lower if you’re sneaky) once you’ve confirmed that:  
  1. The market price at ~3:20 PM on P2 is **higher** than P1’s open (163).  
  2. P2’s open (159.5) is **≤** P1’s close (160).  
* **Risk‑averse:** Wait for **P3** to be a blue candle, then enter near the close (usually around 169‑170).  
* **Stop‑loss:** Set it at the **lowest low** of the pattern – **158.5**.

Both styles would have been profitable in this case.

#### A “missed‑the‑bus” illustration – Cipla Ltd

The chart below shows a textbook bullish engulfing. A risk‑averse trader who waited for the next day would have missed the party entirely.

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M2Ch8-chart3.jpg)

### Real‑world debate: “Do we need to swallow the shadows?”

Some purists argue the whole candle—including upper and lower shadows—must be engulfed. In practice, **most traders (including yours truly) accept engulfing of just the **real bodies**. The shadows are like the extra frosting on a cupcake—nice, but not essential.

Hence, even a pattern that looks like this (shadows not fully covered) still qualifies:

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M2Ch8-chart4.jpg)

---

## 8.3 – The Bearish Engulfing Pattern (aka “The Bear’s Night‑Out”)

The bearish engulfing is the *mirror image* of its bullish sibling. It shows up **at the top of an uptrend** and signals a short‑side entry. Think of it as the market’s way of saying “I’m done partying, let’s go home”.

The chart below circles the two candles that make up the bearish engulfing.

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M2Ch8-chart5.jpg)

### The bearish story in bullet points

1. **Bulls dominate** – Prices have been marching upward.
2. **P1 (blue)** – Opens, makes a new high, confirming bullish vigor.
3. **P2 (red) opens higher** – Bulls expect another high, but sellers ambush them at the top.
4. **Sellers drive the price down** – The red candle closes **below P1’s open**, shaking the bulls.
5. **Bearish momentum** – The market is now likely to keep falling for a few sessions.
6. **Trading idea** – Short the instrument to capture the downside.

### Trade set‑up

| Role | Entry | Conditions | Stop‑loss |
|------|-------|------------|-----------|
| **Risk‑taker** | Same day (P2) close, after confirming: <br>1️⃣ P2 open > P1 close <br>2️⃣ Current price (≈3:20 PM) < P1 open | Immediate – you like living on the edge. |
| **Risk‑averse** | Next day (P3) close, **but only if P3 is a red candle**. | Wait‑and‑see – you prefer the “let‑the‑dust‑settle” vibe. |
| **Stop‑loss** | The **highest high** of the two candles (the roof of the bear’s cave). | Keeps the trade from turning into a bull‑run. |

> **Quick note:** Because this is a 2‑day pattern, many traders adopt the risk‑taker stance. Still, always respect your own risk appetite.

### Real‑world example: Ambuja Cements

Two bearish engulfing patterns appear on the chart (left‑most is a dud for risk‑takers; the right‑most is a winner for everyone).

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M2Ch8-chart6.jpg)

| Candle | Open | High | Low | Close |
|--------|------|------|-----|-------|
| **P1** | 214 | **220** | 213.3 | 218.75 |
| **P2** | **220** | **221** | **207.3** | 209.4 |

**Trade plan**

* **Risk‑taker:** Short around **209** by 3:20 PM on P2 after confirming the engulfing conditions.  
* **Risk‑averse:** Wait for P3 to be a red candle, then enter near the close.  
* **Stop‑loss:** The **highest high** of P1 & P2 → **221**.

Both approaches would have been profitable here.

---

## 8.4 – The Doji Cameo (aka “The Indecision Interlude”)

Here’s a chart that looks like a Hollywood thriller—lots of drama, a twist, and a cliff‑hanger.

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M2Ch8-chart7.jpg)

### What catches the eye?

1. **A clear uptrend** (green arrow).  
2. **A bearish engulfing** perched on the rally’s summit.  
3. **A Doji** the day after the engulfing.

### Event‑by‑event breakdown

| Day | What happens | Why it matters |
|-----|--------------|----------------|
| **P1** | Blue candle – bulls still in charge. | Confirmation of the uptrend. |
| **P2** | Opens higher, makes a fresh high, then sells hard → closes **below P1’s open** (bearish engulf). | Bulls get a panic attack. |
| **P3 (Doji)** | Opens weakly, tries to push higher (upper shadow), but also dips low (lower shadow). Closes flat → Doji. | Doji = market “I don’t know, you tell me”. |
| **P4** | Long red candle follows the Doji. | Panic + uncertainty = perfect recipe for a crash. |

**Takeaway:** Whenever a Doji follows a recognizable pattern (engulfing, piercing, etc.), it **amplifies** the signal. You’re essentially seeing two layers of market psychology stacked together.

---

## 8.5 – The Piercing Pattern (aka “Half‑Engulf, Full‑Hope”)

The **piercing pattern** is the cousin of the bullish engulfing, except it’s a *partial* engulf. P2’s blue candle must swallow **more than 50 %** but **less than 100 %** of P1’s red body.

> **Rule of thumb:**  
> If P1’s real‑body length = 12 points, P2’s body must be **≥ 6 points** and **< 12 points**.

Visually you can eyeball it, or you can do a quick calculation.

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M2Ch8-chart8.jpg)

If the 50‑%‑plus condition is met, everything else mirrors the bullish engulfing:

* **Risk‑taker** enters near the close of P2.  
* **Risk‑averse** waits for the next blue candle (P3).  
* **Stop‑loss** = the low of the two‑candle pattern.

### A borderline case

The chart below shows P2 engulfing **just under** 50 % of P1. Hence, it **fails** the piercing test.

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M2Ch8-chart9.jpg)

And here’s a clean example where the engulf is well within the 50‑100 % band (good to go).

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M2Ch8-chart10.jpg)

---

## 8.6 – The Dark Cloud Cover (aka “Night‑time Bear‑Sighting”)

The **dark cloud cover** is the bearish twin of the piercing pattern. It’s basically a **bearish engulfing** where the red candle on P2 covers **50 %‑100 %** of the previous blue candle’s body.

Think of it as the market’s evening forecast: “Expect cloudy, with a chance of showers (i.e., falling prices).”

The trade mechanics are identical to the bearish engulfing:

* **Risk‑taker:** Enter on P2’s close after confirming the 50‑%‑plus engulf.  
* **Risk‑averse:** Wait for a confirming red candle on P3.  
* **Stop‑loss:** Highest high of P1 & P2.

![Image](http://zerodha.com/varsity/wp-content/uploads/2014/10/M2Ch8-chart11.jpg)

---

## 8.7 – A Quick Thought on Picking the Right Trade

Stocks that belong to the same sector often move in *similar* rhythm—think **TCS vs. Infosys** or **ICICI Bank vs. HDFC Bank**. They’re like siblings who copy each other’s fashion, but they don’t wear the exact same shoes.

If a sector‑wide bad‑news shock hits banks, both ICICI and HDFC will dip, but not necessarily by the same percentage. ICICI might slide **2 %**, while HDFC could drift **1.5 %** or **2.5 %**. Consequently, you could see **different candlestick patterns** on the two charts at the same time—say, a bearish engulfing on ICICI and a dark‑cloud cover on HDFC.

### Which pattern gets my money?

* I’d favour the **bearish engulfing** over the dark‑cloud cover because the former swallows the whole previous candle—more aggressive bearishness.  
* Same logic applies on the bullish side: **bullish engulfing** beats a **piercing** pattern.

#### The exception: the 6‑point checklist

Later in the course we’ll talk about a **six‑point trade‑checklist**. A trade must tick **at least 3‑4** points to be deemed “qualified”. Imagine this scenario:

* **ICICI Bank** shows a **piercing** pattern but nails **4** checklist points.  
* **HDFC Bank** shows a **bullish engulfing** but only satisfies **3** points.

Even though the bullish engulfing looks “stronger” visually, I’d probably trade **ICICI** because its overall setup is more robust.

Conversely, if both stocks hit **4** checklist points, I’d go with the pattern that looks more decisive (i.e., the bullish engulfing).

---

### Key take‑aways (the cheat‑sheet you’ll actually read)

- **Multiple candlestick patterns** need **≥ 2** days to form.  
- **Bullish engulfing** = two‑day reversal at the *bottom* of a downtrend. P1 = red, P2 = blue **fully** engulfs P1.  
- **Entry**:  
  * **Risk‑taker** – at P2’s close (or a few minutes before market close).  
  * **Risk‑averse** – next‑day close *only if* the candle stays blue.  
- **Stop‑loss** = **lowest low** of the two candles.  
- **Bearish engulfing** = two‑day reversal at the *top* of an uptrend. P1 = blue, P2 = red fully engulfs P1.  
- **Entry**: same risk‑taker / risk‑averse logic, but for shorts.  
- **Stop‑loss** = **highest high** of the two candles.  
- **Doji** after an engulfing (or any strong pattern) **boosts** the signal – it’s the market’s “I’m not sure” whisper that often precedes a big move.  
- **Piercing pattern** = bullish *partial* engulf (50 % – < 100 % of prior red body). Same trade rules as bullish engulfing.  
- **Dark cloud cover** = bearish *partial* engulf (50 % – < 100 % of prior blue body). Same trade rules as bearish engulfing.  
- **Sector‑wise similarity** → expect similar but not identical patterns across peers. Pick the pattern that satisfies **more checklist points**, not just the one that looks flashier.  

Now go forth, spot those two‑day dramas, and remember: the market loves a good story—just make sure you’re on the right side of the script!