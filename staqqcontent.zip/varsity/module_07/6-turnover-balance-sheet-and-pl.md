# 6. Turnover, Balance Sheet, and P&L  

**Source:** https://zerodha.com/varsity/chapter/turnover-balance-sheet-and-pl/  

---  

##  

![Image](https://zerodha.com/varsity/wp-content/uploads/2015/07/M7-Chapter6-new-illustration2.png)  

## 6.1 – Turnover & Tax Audit  

Remember that little chat we had in the previous chapter about tax audit?  If you’re treating your trading gains as **business income** (instead of the “I‑just‑sold‑some‑shares‑and‑it‑happened” capital‑gains route), the taxman will want to know your **turnover** before he decides whether to send an auditor to your doorstep.  

**Quick reminder:** Turnover is **only** a trigger for a tax audit. It does **not** affect the amount of tax you owe. In other words, the bigger your turnover, the bigger the chance you’ll have to host a CA for coffee – but your tax bill is still calculated on profit, not on how much you bought and sold.  

### When does the audit police knock?  

| Condition | What it means (in plain English) |
|-----------|-----------------------------------|
| **Rs 10 crore** turnover | If the total business turnover for the FY **2023‑24 / 2024‑25** (the digital‑only years) crosses the Rs 10 crore line, the auditor comes in.  Think of it as the “VIP club” – once you spend enough, you get a special invite. |
| **Section 44AD** opt‑out + FNO < 6 % of turnover + total income > exemption limit | If you decide NOT to use the presumptive‑tax scheme (44AD), your Futures‑and‑Options (FNO) earnings are less than 6 % of your turnover **and** your overall income (salary + business + capital gains) is above the basic exemption, you’re also on the audit radar. |

> **Pro tip:** If all you have are capital‑gains (you’re a “buy‑and‑hold” kind of person), the audit rule **doesn’t apply** no matter how many rupees you swing around.

---

### “Is that my contract turnover?”  

Your brain probably went, “Hey, I bought 100 Nifty contracts at 8 000, sold at 8 100 – that’s a turnover of 1.61 million, right?”  

```
Buy side  = 8 000 × 100 = 800 000  
Sell side = 8 100 × 100 = 810 000  
Turnover  = 800 000 + 810 000 = 1 610 000
```  

Nice arithmetic, but the **Income Tax Department** isn’t interested in this “contract turnover”. They want **business turnover** – the total value of *business* transactions that you have declared as income from a trade‑or‑business activity.

---

### How the tax‑man suggests you calculate business turnover  

There is no iron‑clad law that says “turnover = X”. The only quasi‑official guidance comes from the ICAI’s “Guidance Note on Tax Audit under Section 44AB” (see page 15, Section 5.10). Below is the distilled version, with a dash of humor to keep you awake.

#### 1. Delivery‑based transactions (you hold shares > 1 day)  

> **Rule:** **Total sales value** = turnover.  
> **Example:** Bought 100 RIL shares at ₹800, sold at ₹820 → **Turnover = ₹82 000** (the sale price).  

*But* this only matters if you are **declaring those delivery trades as business income**. If you treat them as pure capital gains, ignore the turnover calculation – the audit rule never fires for pure cap‑gains.

#### 2. Speculative (intraday) equity trades  

> **Rule:** Add up the **absolute** profit or loss of every intraday round‑trip. In other words, treat each trade’s P&L (whether + or –) as a positive number and sum them.  
> **Example:** Buy 100 RIL at ₹800, sell at ₹820 → profit = ₹2 000 → **Turnover = ₹2 000** for that trade.

#### 3. Non‑speculative (Futures & Options)  

The ICAI note gets a little more wordy here, but the gist is:

| What to include | How to treat it |
|-----------------|-----------------|
| **Favourable + unfavourable differences** | Sum their absolute values – that’s your turnover. |
| **Premium received on option sales** | Include it, **unless** you already counted that premium in the net profit calculation (don’t double‑count). |
| **Reverse trades** (e.g., you close a position by taking the opposite side) | Their difference also joins the turnover pool. |
| **Open positions at FY‑end** | Wait until they are squared‑off; the turnover belongs to the FY when you finally close them. |
| **Delivery‑based settlement in derivatives** | The gap between trade price and settlement price becomes turnover. |

**Concrete examples**

*Futures:* Bought 1 lot (25 units) of Nifty futures at 24 000, sold at 23 900 → loss = 25 × 100 = **₹2 500** → turnover = **₹2 500** (the loss is taken as a positive number for turnover).  

*Options:* Bought 4 lots (100 contracts) of Nifty 26 000 calls at ₹1 000, sold at ₹1 010 → profit = 10 × 100 = **₹1 000** → turnover = **₹1 000**.

---

### Scrip‑wise vs. Trade‑wise turnover  

You have two ways to aggregate the numbers:

| Approach | How it works | When it’s handy |
|----------|--------------|-----------------|
| **Scrip‑wise** | Group all trades of the same contract (or scrip), compute an average buy price and average sell price for the FY, then apply the rules on the *overall* profit/loss of that average. | Useful if your broker already gives you a P&L with average prices (most do). |
| **Trade‑wise** | Treat every single trade separately, take the absolute P&L of each, and sum them up. | The most **compliant** method (the tax department loves it). The downside: you’ll need to export every trade into Excel because most brokers (except Zerodha) don’t give you a ready‑made “trade‑wise turnover” report. |

#### Example 1 – Nifty Oct Futures  

| Trade | Buy @ | Sell @ | P&L |
|------|-------|--------|-----|
| 1 | 26 000 | 26 100 | +₹10 000 |
| 2 | 26 100 | 26 050 | –₹5 000 |

* **Scrip‑wise**  
  - Total quantity = 200 contracts.  
  - Avg. buy = (26 000 + 26 100)/2 = **26 050**  
  - Avg. sell = (26 100 + 26 050)/2 = **26 075**  
  - Net P&L = 200 × (26 075 – 26 050) = **+₹5 000** → Turnover = **₹5 000**.

* **Trade‑wise**  
  - |+₹10 000| + |–₹5 000| = **₹15 000** turnover.

#### Example 2 – Nifty Dec 26 000 Puts  

| Trade | Premium bought | Premium sold | P&L |
|------|----------------|--------------|-----|
| 1 | 1 000 | 950 | –₹5 000 |
| 2 | 500 | 480 | –₹2 000 |

* **Scrip‑wise**  
  - Avg. buy = (1 000 + 500)/2 = **₹750**  
  - Avg. sell = (950 + 480)/2 = **₹715**  
  - Net P&L = 200 × (715 – 750) = **–₹7 000** → Turnover = **₹7 000**.

* **Trade‑wise**  
  - |–₹5 000| + |–₹2 000| = **₹7 000** turnover.

> **Bottom line:** Trade‑wise is bullet‑proof, but you might need to roll up your sleeves and crunch the numbers yourself (or stick with Zerodha, which conveniently serves the trade‑wise report on Console).

---

### Screenshots – How Zerodha shows you the numbers  

| Scrip‑wise turnover report | Trade‑wise turnover report |
|----------------------------|----------------------------|
| ![Image](http://zerodha.com/varsity/wp-content/uploads/2015/06/M7C5-image1.jpg) | ![Image](http://zerodha.com/varsity/wp-content/uploads/2015/06/M7C5-image2.jpg) |

Once you have the turnover figure, just check the two audit thresholds (Rs 10 crore or 44AD condition) and you’ll know whether a CA‑visit is **mandatory** or just a nice‑to‑have “second‑opinion” kind of thing.

---

## 6.2 – Section 44AD  

Section 44AD is the “presumptive taxation” scheme that lets small businesses (turnover ≤ Rs 2 crore) claim **8 %** (or 6 % for digital receipts) of gross receipts as profit, without maintaining detailed books.  

**But** if you **opt out** of 44AD, the audit rule we discussed earlier kicks in:

* **Turnover < Rs 10 crore** **AND** **profit < 6 % of turnover** → No audit **unless** your **total tax liability > 0**.  

In plain speak:  

* If you’re making a *tiny* profit (less than 6 % of your business turnover) **and** you owe **zero** tax because your total income (salary + business + cap‑gains) is under the basic exemption (₹2.5 lakh old regime, ₹3 lakh new regime), the auditor can stay home.  

* However, if you have a **loss** or a **very low profit** but still cross the exemption threshold, the tax department will still want the books audited.  

### Why traders grumble about 44AD  

A normal shop sells a widget, makes a 20 % margin, and the profit is predictable. In the market, your “margin” swings wildly – sometimes you win big, sometimes you lose the whole lot. The 6 % profit rule doesn’t really capture the reality of a trading business, and many retail traders end up **forced** to maintain full‑blown books just to satisfy a rule that feels like it was written for a bakery, not a derivatives desk.  

Zerodha has even started a **Change.org petition** asking the government to relax this provision for traders. If you’re feeling the pain, give it a click and convince your fellow traders to sign.

---

### Filing as a business – ITR‑3  

If you declare your trades as **business income**, you must file **ITR‑3** (the form for individuals with a “profitable business or profession”). That brings along a small paperwork party:

1. **Balance Sheet**  
2. **Profit & Loss (P&L) statement**  
3. **Books of Accounts** (at least a bank book and a trading book)

All of these have to be **audited** if either:

* Turnover > Rs 10 crore, **or**  
* Turnover ≤ Rs 10 crore **and** profit < 6 % of turnover **and** you owe tax.

Below we break down the three statements in a friendly, “let’s‑do‑it‑together” style.

---

## 6.3 – Balance sheet, P&L, Book of accounts  

### Balance sheet – Your financial selfie  

A balance sheet is a snapshot of **what you own** vs **what you owe** at a point in time. Think of it as the “before‑and‑after” picture of your net worth.

#### How to build one (no PhD required)

1. **Gather the paperwork** – latest bank statements, loan statements (home, car, personal), demat holdings, any other debt statements.  
2. **List Assets** (the good stuff you own) – cash, bank balances, investments (MFs, stocks, bonds), property (purchase price + stamp duty + renovation), vehicles, jewelry, gadgets, loans you’ve given to friends, even that plot of land you inherited.  
3. **Add them up** → **Total Assets**.  

4. **List Liabilities** (the not‑so‑good stuff you owe) – mortgage balance, car loan, student loan, credit‑card debt, any personal loan.  
5. **Add them up** → **Total Liabilities**.  

6. **Net Worth** = **Total Assets – Total Liabilities**.  

> **Tip:** Update this every quarter, not just at the end of the year. That way you’ll spot a leaky faucet (or a leaky portfolio) before it drenches your finances.

### Profit & Loss statement – The story of how you got richer (or poorer)  

A P&L statement tells you **where the money came from** (Revenue) and **where it went** (Expenses) over a financial year.

| Revenue (don’t mix with salary) | Examples |
|--------------------------------|----------|
| Realised capital gains from stock sales | ₹ X |
| Income from F&O, intraday, commodity trades (treated as business) | ₹ Y |

| Expenses (the things that eat your profit) | Examples |
|-------------------------------------------|----------|
| Salaries for assistants or analysts | ₹ Z |
| Office rent / co‑working space | ₹ A |
| Brokerage, exchange fees, STT, GST, etc. | ₹ B |
| Advisory fees, depreciation of your trading rig, internet, etc. | ₹ C |

**Profit** = **Revenue – Expenses**.  

*Important:* **Salary** from your day‑job does **not** belong on the business P&L. Keep it in a separate “personal” income column; mixing them will make the tax department raise an eyebrow.

### Book of accounts – The humble ledger you never knew you needed  

Don’t be scared by the term “book‑keeping”. For a solo trader it’s basically two Excel sheets (or two CSV downloads) that you keep tidy.

| Book | What you record | Where to get it |
|------|----------------|-----------------|
| **Bank Book** | Every debit/credit in your personal/current account – annotate “trading expense”, “margin call”, “interest received”, etc. | Export from your net‑banking portal (or use the bank’s CSV). |
| **Trading Book** | All broker‑provided statements – daily P&L, ledger, contract notes. | Most brokers give you a downloadable P&L/ledger; Zerodha also shows every charge (other than brokerage) under *Other Credits/Debits* on the Console tax‑P&L. |

If you’re using a broker other than Zerodha, you’ll likely need to **download all trades** for the year and mash them together in Excel to produce a trade‑wise turnover (as explained earlier).  

**Why bother?** Because a clean book makes the auditor’s job easy, and more importantly, it keeps you honest with yourself. You’ll instantly see if a “mysterious” expense is actually a hidden brokerage charge or a data‑feed subscription you forgot you paid for.

---

### Zerodha’s transparency bonus  

Zerodha loves transparency like a bartender loves a clean glass. Every charge (exchange fees, GST, STT, DP fees, etc.) shows up in the “Other Credits/Debits” column of the tax‑P&L on Console. You also get a neat **Open Position Summary** (April 1 – March 31) which you can cross‑check with your own ledger.

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/06/M7C5-image3.jpg)

---

## Final Words (and a quick cheat‑sheet)  

### Key take‑aways from this chapter  

- **Audit triggers**: turnover > Rs 10 crore **or** 44AD opt‑out with FNO < 6 % of turnover **and** total income > basic exemption.  
- **Turnover** for audit purposes is **business turnover**, *not* the contract‑turnover you calculate for each trade.  
- You can compute business turnover **scrip‑wise** (average‑price method) **or** **trade‑wise** (absolute sum of each trade’s P&L). Trade‑wise is the safest bet.  
- Filing **ITR‑3** obliges you to have a **Balance Sheet**, **P&L statement**, and **Books of Accounts**.  
- **Balance‑sheet equation**: **Net Worth = Assets – Liabilities**.  
- **P&L** lists **Revenue** (trading profits, capital‑gains treated as business) minus **Expenses** (brokerage, rent, salaries, etc.).  
- **Book‑keeping** for a solo trader = **Bank Book** + **Trading Book**.  
- Update your Balance Sheet, P&L, and books **at least once per quarter** – think of it as a quarterly “financial health check‑up”.  

> **Disclaimer:** This is a friendly guide, not legal advice. Before you file any returns, have a Chartered Accountant (CA) glance over your numbers. The content is tailored for *retail individual investors/traders* in India.  

---  

*Now go forth, calculate those turn‑over numbers, keep your books cleaner than your kitchen countertop, and may the audit gods smile upon you!*