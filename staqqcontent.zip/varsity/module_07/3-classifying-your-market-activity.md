# 3. Classifying Your Market Activity  

**Source:** https://zerodha.com/varsity/chapter/classifying-your-market-activity/  

---  

## 3.1 – Are you a trader or investor, or both?  

First things first: before you hand over that glossy IT‑R to the taxman, you have to decide whether you’re wearing the *trader* hat, the *investor* cap, or a weird combination of both.  
Why does this matter? Because the Income‑Tax Act lets you label your share‑related earnings as **capital gains** *or* **business income** (trading) **regardless of how long you held the shares**. Once you pick a label, you’re expected to stick with it for the years that follow – you can’t play “I‑just‑changed‑my‑mind‑today” on the tax form.  

So, before you even think about punching numbers into Form I‑TR, you must first classify yourself as an **investor**, a **trader**, or a **mix‑and‑match** of the two. In this chapter we’ll walk you through the logic that most Assessing Officers (AOs) use when they stare at your PAN. (By “income” we mean **both** profits **and** losses.)

When you trade or invest, the income you generate must be parked under one of the following heads:  

- **Long‑term capital gain (LTCG)**  
- **Short‑term capital gain (STCG)**  
- **Speculative business income**  
- **Non‑speculative business income**  
- **Dividend income**  

Let’s break down each of these, with a side of humor.  

### Long‑term capital gain (LTCG)  

Picture this: you buy stocks or an equity‑mutual‑fund today for **₹50,000** and, after **365 days**, you sell them for **₹55,000**. That **₹5,000** profit is a **long‑term capital gain** because you held the asset for at least a year.  

> **Rule of thumb:** Any profit from listed equity or equity‑MF sold **≥ 1 year** after purchase = LTCG.  

**Tax story (pre‑July 2024):**  
* Up to **₹1 lakh** of LTCG on equity was **tax‑free**.  
* Anything above that was hit with a **10 %** LTCG tax, provided the trade went through a recognized exchange (i.e. you paid **Securities Transaction Tax – STT**).  

**Budget 2024 update:**  
* The exemption rose from **₹1 lakh** to **₹1.25 lakh**.  
* Gains **beyond ₹1.25 lakh** are taxed as follows:  

| Sale date | Tax rate |
|-----------|----------|
| Before 23 July 2024 | 10 % |
| On/after 23 July 2024 | 12.5 % |

The **₹1.25 lakh** threshold is **cumulative** – it covers all LTCG you make both before and after 23 July 2024.  

**Caveat:** The above rates **only** apply if the purchase & sale happened on a **recognised exchange** (i.e. STT was paid). Off‑market deals are taxed differently.  

#### Unlisted‑stock LTCG  

Unlisted shares (those not quoted on any Indian exchange) have historically been taxed at **20 % with indexation** up to FY 2023‑24.  

From FY 2024‑25 onward the regime shifts:  

| Sale date | Tax rate | Indexation? |
|-----------|----------|-------------|
| Before 23 July 2024 | 20 % | Yes |
| On/after 23 July 2024 | 12.5 % | No |

The same treatment applies to foreign‑listed shares (e.g., ADRs).  

#### Grandfather clause (2018) – the “you‑bought‑it‑in‑2015‑so‑you‑get‑a‑break” rule  

If you owned shares **before 1 Jan 2018**, the **cost of acquisition** for LTCG calculation becomes the **higher** of:  

1. Your actual purchase price, **or**  
2. The **maximum closing price** on **31 Jan 2018**.  

*Example:* You bought Infosys for **₹1 lakh** in 2015. On **31 Jan 2018** the market price was **₹5 lakh**. You sell today for **₹20 lakh**.  
Your taxable gain = **₹20 lakh – ₹5 lakh = ₹15 lakh**, not **₹19 lakh**.  

If the Jan‑2018 price was *lower* than your actual cost, you simply use your real purchase price.  

### Short‑term capital gain (STCG)  

Buy listed equity or an equity‑MF for **₹50,000**, flip it **within 12 months** (say you sell at **₹55,000**). That **₹5,000** profit is **STCG**.  

> **Rule of thumb:** Any profit from listed equity held **> 1 day** (delivery‑based) but **< 12 months** = STCG.  

**Tax story (pre‑FY 2024):** flat **15 %** on the gain.  

**Budget 2024 update (FY 2024‑25 onward):**  

| Sale date | Tax rate |
|-----------|----------|
| Before 23 July 2024 | 15 % |
| On/after 23 July 2024 | 20 % |

*Illustration:* Buy Infosys for **₹100,000**, sell **10 days** later for **₹120,000**.  
* If sold **before** 23 July 2024 → tax = **15 % × ₹20,000 = ₹3,000**.  
* If sold **on/after** 23 July 2024 → tax = **20 % × ₹20,000 = ₹4,000**.  

### Speculative business income  

Section 43(5) of the Income‑Tax Act says: profits from **intraday** or **non‑delivery** equity trades are **speculative business income**. The same label applies to **currency‑trading** (unless you’re using currency derivatives purely for hedging, which would then be non‑speculative).  

There is **no fixed “speculative‑rate”**. Instead, you **add** this profit (or loss) to **all other income** and tax it at your **personal slab rate**.  

*Example:*  
* Intraday profit = **₹100,000**.  
* Salary = **₹800,000**.  
* Total income = **₹900,000**.  

Assuming you’re on the **new‑regime** slab that levies **₹40,000** tax on ₹900,000, that **₹40,000** is the tax you pay on the speculative profit as well.  

The key takeaway: **speculative income is just another line item in your total taxable income**; you don’t get a special 15 % or 10 % rate.  

### Non‑speculative business income  

Trading **Futures & Options (F&O)** on a recognised exchange (equity, commodity, or currency) falls under **non‑speculative business income** (again, per § 43(5)).  

The tax mechanics are identical to speculative income: **add it to all other heads** and apply the slab rates.  

*Example:*  

| Income source | Amount |
|---------------|--------|
| F&O profit | ₹500,000 |
| Hotel business | ₹2,000,000 |
| **Total** | **₹2,500,000** |

If the applicable slab is **30 %**, you’ll effectively pay **30 % of the ₹500,000 F&O profit** as tax (i.e., **₹150,000**).  

**Why the split?**  
*Intraday equity* is “speculative” because you never intend to take delivery.  
*F&O* is “non‑speculative” because the contracts can be **settled by delivery** or used for **hedging**, and the government decided to give them a slightly friendlier label.  

### Dividend income  

From FY 2020‑21 onward, **Section 115BBDA** (the “dividend‑distribution tax” that used to make dividends tax‑free in the hands of shareholders) was **scrapped**. Now **dividends are taxed in your hands** at the **applicable slab rate**.  

A new twist (effective **1 Oct 2024**): any **share‑buyback** payment by a company is treated as a **dividend**. No expense deductions (including the cost of acquisition) are allowed against it. When you later sell other shares, you can still claim the *original* cost of acquisition for **all** shares (including the bought‑back ones).  

---  

## 3.2 – Pros and cons of declaring trading as a business income  

Let’s weigh the **good** and the **bad** of telling the tax authorities “Hey, my trading is a business.”  

### The bright side (pros)  

| Advantage | What it means for you (with a splash of wit) |
|-----------|----------------------------------------------|
| **Low‑tax threshold** | If **total income** (trading + other) is **< ₹300,000** you pay **zero tax** under the new regime. Even if you’re a little richer (up to **₹700,000**) you can still claim the **₹70,000 rebate** and walk away tax‑free. |
| **Expense‑claim bonanza** | You can deduct **everything** that helped you make (or lose) money: brokerage, STT, internet, phone, newspapers, depreciation of your laptop, research reports, books, advisory fees, you name it. Capital‑gains, by contrast, let you claim only the **contract‑note charges** (excluding STT). |
| **Loss‑set‑off power** | A **non‑speculative F&O loss** can be offset against *any* other income **except salary**. Example: lose **₹5 lakh** in F&O, other non‑salary income is **₹10 lakh** → you’re taxed only on **₹5 lakh**. |
| **Carry‑forward F&O loss** | If you end a year with a **net loss** (non‑speculative F&O + other non‑salary income) and you file ITR on time, you can **carry the loss forward for 8 years**. In any of those years, you can offset it against future **business gains**. Example: loss **₹5 lakh** this year, profit **₹20 lakh** next year → tax only on **₹15 lakh**. |
| **Carry‑forward intraday loss** | Intraday (speculative) losses can be set off **only** against other **speculative gains** and can be carried forward for **4 years**. Example: loss **₹1 lakh** this year, profit **₹50,000** next year → you wipe out the ₹50,000 profit and still have **₹50,000** loss to carry forward. |

### The dark side (cons)  

| Drawback | Why it might bite you |
|----------|-----------------------|
| **Higher slab risk** | If you sit in the **30 % slab**, you’ll pay **30 % of every rupee of profit** (just like any other salaried income). |
| **More complex ITR forms** | Business income forces you onto **ITR‑3 or ITR‑4**. Those aren’t the cute‑and‑easy **ITR‑1/2** forms most salaried folks love. You may need a CA’s help, which means extra cash and extra paperwork. |
| **Audit nightmare** | If your **turnover** exceeds **₹10 crore** (it used to be **₹1 crore** until FY 19/20) *or* if profit is **< 6 % of turnover**, you’ll need a **statutory audit**. That’s a whole other beast (we’ll dive deeper in the “Turnover” chapter). |

> **Quick recap table** – (Feel free to imagine a colourful cartoon here)  

| Feature | Business income (trading) | Capital gains (investing) |
|---------|---------------------------|---------------------------|
| Tax rate | Your slab (0‑30 %) | Fixed LTCG/STCG rates |
| Expense claim | Broad (brokerage, internet, etc.) | Only contract‑note charges |
| Loss set‑off | Against other income (except salary for spec.) | Only against same head |
| Carry‑forward | 8 yr (F&O) / 4 yr (intraday) | No carry‑forward for LTCG/STCG |
| ITR form | ITR‑3/ITR‑4 | ITR‑1/ITR‑2 |

### Bottom line  

If you’re a **small‑ish** trader with total income under **₹300 k**, the business route can be *tax‑free*. If you’re in the **30 % slab** and have a lot of expenses to claim, business income might still be cheaper than the flat LTCG/STCG rates. But the paperwork and audit risk go up. Choose wisely, and keep a CA on speed‑dial.  

---  

## 3.3 – What are you? Trader, Investor, or Both?  

Let’s bring the **CBDT’s** official definitions into the party:  

| Role | Definition (CBDT) |
|------|-------------------|
| **Investor** | Someone who buys with the **intention of earning dividends** (and/or long‑term appreciation). |
| **Trader** | Someone who buys and sells with the **intention of profiting from price movements** (short‑term or otherwise). |

### Investor vs. Trader in practice  

* **Investor** → All **delivery‑based** equity gains are treated as **capital gains** (LTCG or STCG).  
* **Trader** → Those same gains become **business income** (speculative or non‑speculative).  

The law draws a **hard line** for **F&O** and **intraday equity**:  

* **F&O** = **Non‑speculative business** → you *must* file **ITR‑3**.  
* **Intraday equity** = **Speculative business** → you *must* file **ITR‑3**.  

Even if you’re a salaried employee, once you dip your toes into these instruments, you’re **forced** to declare the income as **business income**.  

### Why you should *still* declare losses  

Hiding trading activity is like trying to sneak a pizza into a “no‑food‑allowed” cinema – the staff (the AO) will eventually spot the smell. If the tax department’s algorithms notice **trading volume** on your PAN that you didn’t declare, you’ll get a **scrutiny notice** (the AO wants a coffee‑shop‑style interview). Better to be transparent and claim your losses; they can only **reduce** your tax bill.  

### How to decide when to wear which hat  

1. **Pure delivery‑based, > 1 year** → Treat as **Investor** (LTCG).  
2. **Delivery‑based, < 1 year, low turnover** → Usually **STCG** (still an investor).  
3. **Frequent short‑term trades** → Consider **Non‑speculative business income** (especially if you’re in F&O).  
4. **Only market‑activity as livelihood** → Lean towards **Business income** for *all* equity trades (makes bookkeeping cleaner).  
5. **Salaried or have another main business** → You can comfortably keep most equity trades under **capital‑gains** (unless you’re doing heavy intraday/F&O).  

### “Can I be both?”  

Absolutely! Think of yourself as a **dual‑citizen** of **Investoria** and **Traderland**.  

* Keep a **long‑term portfolio** (LTCG‑eligible) for wealth‑building.  
* Maintain a **short‑term trading book** (STCG or business income) for the thrill.  

Just **segregate the two** when you file returns:  

* **LTCG/STCG** → Fill the **capital‑gains** schedule.  
* **Intraday/Speculative** → Fill the **speculative business** schedule.  
* **F&O** → Fill the **non‑speculative business** schedule.  

If you trade **F&O** or **intraday equity**, you *must* file **ITR‑3** (or ITR‑4 if you qualify for presumptive taxation). But you can still claim LTCG on your long‑haul holdings in the same return.  

### Bottom line checklist  

- **Identify** each instrument’s nature (delivery vs. intraday vs. F&O).  
- **Tag** each transaction to the proper head (LTCG, STCG, spec., non‑spec., dividend).  
- **Stay consistent** – don’t flip between “investor” and “trader” from year to year just to chase a lower tax rate.  
- **Consult a CA** before filing; they’ll keep you from accidentally inventing a new tax category.  

> “Rules are made for the 1 % who try to break them.” – *Anonymous tax‑guru*  

As long as your intent is clear, you understand the tax department’s red‑flags, and you stay consistent, the whole process is **pretty painless**.  

---  

### Key takeaways from this chapter  

- **F&O (Equity, currency, commodity)** = **Non‑speculative business**  
- **Intraday equity** = **Speculative business**  
- **Equity held > 1 year** = **Long‑term capital gain (LTCG)**  
- **Equity held 1 day‑to < 1 year with low turnover** = **Short‑term capital gain (STCG)**; high‑frequency trades → **Non‑speculative business income**  

**Disclaimer:** *Always run your final numbers past a qualified Chartered Accountant (CA). The material here is meant for retail individual investors/traders and reflects the tax rules as of FY 2024‑25.*  