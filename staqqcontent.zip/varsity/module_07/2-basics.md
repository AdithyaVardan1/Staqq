# 2. Basics  

**Source:** <https://zerodha.com/varsity/chapter/basics/>  

---  

## 2.1 – Overview  

India’s tax culture needs a little TLC – think of it as a collective group‑therapy session where we all learn to love the Income‑Tax Department (ITD) instead of treating it like that creepy guy in the corner at a party. The only cure for that “ITD‑phobia” is plain‑old knowledge: know the rules, know the forms, and you’ll stop trembling every time a notice pops up in your inbox.  

Back in the early‑70s the top marginal rate was a jaw‑dropping **> 90 %** (yes, you read that right). Fast‑forward to FY 2020‑21 and the government says, “Hey, you can earn up to **₹ 3 Lakh** (or **₹ 2.5 Lakh** under the new‑regime) and pay zero tax.” Yet, millions still treat filing returns like going to the dentist – you know you should, but you keep putting it off.  

The tax‑tech train is gaining speed. Every year the department rolls out sleeker software, which means the odds of getting a *“Hey, you missed a box”* notice or a penalty for a slip‑up are climbing faster than a Nifty‑50 rally.  

Just as the ITD can peek into every bank account you own, it can also snoop on your market moves because every trade is tagged with your PAN (Permanent Account Number). With Aadhaar being stitched into everything, the day isn’t far when the department will mail you a **consolidated activity statement** – essentially a “your‑money‑in‑and‑out” report, much like the NSDL/CDSL holdings summary you already get for your Demat accounts.  

What we once called “the future” is now reality, courtesy of two superheroes:  

* **TIS – Taxpayer Information Summary** – a category‑wise snapshot of everything you earn.  
* **AIS – Annual Information Summary** – the nitty‑gritty line‑by‑line breakdown (bank interest, post‑office savings, dividends, rent, securities trades, crypto swaps, foreign remittances, GST turnover, you name it).  

Below is a sample TIS for your viewing pleasure.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2023/07/TIS.png)  

Take a look at the notice sent to a client who *forgot* to declare his commodity‑exchange trades in FY 2012‑13. The tax man only knocked on his door in 2015 – three years later! (Pro tip: the ITD never forgets, it just likes to be fashionably late.)  

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/07/whytax1-911x1024.jpg)  

There’s also a whole e‑campaign ecosystem where the department shoots out emails asking you to “confirm” transactions you already did.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2023/07/Tax-clarifications.png)  

Even when the intention to comply is there, many – including a good number of Chartered Accountants – get tangled up in the jargon jungle of taxation for investors and traders. A few years back we published a “Taxation Simplified” blog on Z‑Connect, and the flood of questions was so massive we needed a lifeboat. The takeaway? We had to go deeper, clearer, and a lot more entertaining. Hence, this whole module.  

If you’re just a buy‑and‑hold stock or mutual‑fund fan, filing is a breeze. But once you start dancing with intraday stocks or futures‑and‑options, the tax maze becomes a bit more *labyrinthine*.  

In the chapters that follow we’ll strip tax concepts down to bite‑size pieces, with **zero** CA‑speak. Here’s a teaser of what’s coming:  

- Introduction (Setting the Context)  
- Basics  
- Classify your Market Activity  
- Taxation for Investors  
- Taxation for Traders  
- Turnover, Balance Sheet, and P&L  
- ITR Forms (The Finale)  
- Foreign Taxation (freshly added)  

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/06/M7-C1-cartoon1.png)  

---  

## 2.2 – What is income tax?  

In plain English: **Income tax** is the slice of your earnings that you hand over to the Government of India. The legal backbone is the **Income‑Tax Act, 1961**. Think of it as the nation’s way of saying, “Hey, thanks for working hard – now help us build roads, hospitals, schools, and that fancy defense equipment you see on TV.”  

### Why should I pay tax?  

Because India doesn’t hand out free universal health‑care or a “pay‑nothing‑ever‑again” pension plan (unlike a few Western friends). The cash we collect funds:  

- Government hospitals (so you don’t have to sell a kidney for a check‑up)  
- Public education (so your kids can learn something other than TikTok trends)  
- National defence (because aliens might be real, we’re prepared)  
- Infrastructure (roads, bridges, Wi‑Fi on trains – you name it)  

### Who is supposed to pay income tax?  

Anyone whose earnings cross the **minimum taxable slab** set by the budget. “Person” under the Act is a broad term – it covers natural humans **and** artificial entities (yes, even your startup’s corporate shell).  

A quick reality check:  

| Statistic | Figure |
|-----------|--------|
| % of India’s 130 crore population that files an ITR | **≈ 5 %** |
| % that actually pays any tax (i.e., owes something) | **≈ 1.5 crore (~1 %)** |
| % of U.S. citizens who file/pay taxes | **≈ 45 %** |

So, we’re a bit behind the curve. Some of that is because many Indians earn below the threshold, but the bigger culprit is a weak **tax culture**.  

### FY vs. AY – what’s the difference?  

- **Financial Year (FY)** – the 12‑month window when you *earned* the money. In India it runs **1 April – 31 March**.  
- **Assessment Year (AY)** – the year you *file* the return for the income earned in the preceding FY.  

For example:  

- **FY 2024/25** = 1 Apr 2024 → 31 Mar 2025 (the period you earned the cash).  
- **AY 2025/26** = the calendar year you file the return for that FY.  

In practice you’ll download an ITR form stamped **AY 2025/26** and use it to declare everything you earned between April 2024 and March 2025.  

---  

## 2.3 – Income tax slabs in India for financial year 2024/25  

Every Indian with taxable income must pay according to the slab they fall into. You have **two choices**: the **old regime** (with a bouquet of deductions) or the **new regime** (lower rates, fewer deductions).  

### The old regime – the “bring‑your‑own‑deductions” plan  

If you’re a salaried employee, your employer already deducts TDS (Tax‑Deducted‑at‑Source) and hands you a **Form 16** – the official “We’ve paid X rupees on your behalf” receipt. But Form 16 only covers salary; it doesn’t see your bank‑interest, capital‑gains, rental income, or side‑hustle earnings. You’ll have to add those, claim the appropriate deductions, and settle any remaining tax before the due date.  

Here are the **FY 2024/25** slabs (old regime) – remember the **standard deduction** of **₹ 50,000** is automatically subtracted from your gross income.  

| Age group | Income up to | Tax Rate |
|-----------|--------------|----------|
| **Individual** (≤ 60 yr) | ₹ 0 – ₹ 2.5 L | **Nil** (plus rebate) |
| | ₹ 2.5 L – ₹ 5 L | **5 %** |
| | ₹ 5 L – ₹ 10 L | **20 %** |
| | Above ₹ 10 L | **30 %** |
| **Senior citizen** (60‑80 yr) | ₹ 0 – ₹ 3 L | **Nil** |
| | ₹ 3 L – ₹ 5 L | **5 %** |
| | ₹ 5 L – ₹ 10 L | **20 %** |
| | Above ₹ 10 L | **30 %** |
| **Super senior** (≥ 80 yr) | ₹ 0 – ₹ 5 L | **Nil** |
| | Above ₹ 5 L | **30 %** |

**Rebate:** If your taxable income (after the standard deduction) lies between **₹ 2.5 L – ₹ 5 L**, you can claim a **5 % rebate up to ₹ 12,500**, effectively wiping out tax for many.  

**Surcharge:** Once you cross certain income thresholds, an extra charge kicks in:  

| Income Bracket | Surcharge |
|----------------|-----------|
| ₹ 50 L – ₹ 1 Cr | **10 %** of income tax |
| ₹ 1 Cr – ₹ 2 Cr | **15 %** |
| ₹ 2 Cr – ₹ 5 Cr | **25 %** |
| Above ₹ 5 Cr | **37 %** |

*Note:* The 25 % and 37 % surcharges **do not apply** to capital‑gains and dividend income; those are capped at **15 %**.  

### The new regime – “let’s keep it simple”  

Budget 2020 introduced an **optional new‑regime** with lower slabs but **no** (or very few) deductions (except for 80CCD(2) – the NPS employer contribution). The highest surcharge (37 %) was trimmed to **25 %**.  

Budget 2023 and **Budget 2024** have since tweaked the numbers again. The latest (FY 2024/25) looks like this:  

| Income (₹) | Tax Rate (New Regime) |
|------------|-----------------------|
| 0 – ₹ 2.5 L | **Nil** |
| ₹ 2.5 L – ₹ 5 L | **5 %** |
| ₹ 5 L – ₹ 7.5 L | **10 %** |
| ₹ 7.5 L – ₹ 10 L | **15 %** |
| ₹ 10 L – ₹ 12.5 L | **20 %** |
| ₹ 12.5 L – ₹ 15 L | **25 %** |
| Above ₹ 15 L | **30 %** |

**Standard deduction** in the new regime is now **₹ 75,000** (instead of ₹ 50,000).  

**Rebate:** A flat **₹ 25,000** rebate if taxable income is **≤ ₹ 7 L** (resident individuals only). Non‑residents cannot claim it.  

**Surcharge & Cess:** Same surcharge structure as the old regime, plus a **4 % Health & Education Cess** on tax + surcharge.  

### Marginal relief – the tax system’s “nice‑guy” clause  

When you cross a surcharge threshold, the tax jump can feel like a **bouncer at a club** (think Bumrah’s intimidating look). To soften the blow, the law offers **marginal relief**: you won’t pay *more* tax than the amount that exceeds the threshold.  

**Illustration:**  
- Cricketer **Dravid** earns **₹ 51 L** in FY 2023‑24.  
- Without relief, his tax (including 10 % surcharge) would be **₹ 14,76,750**.  
- If he earned just **₹ 50 L**, tax would be **₹ 13,12,500**.  
- The *extra* ₹ 1 L of income would otherwise cost him **₹ 1,64,250** in tax – a steep jump.  

**Marginal relief** caps the extra tax at the amount of extra income, i.e.,  

\[
\text{Relief} = (\text{Tax with surcharge}) - (\text{Tax just below threshold}) - (\text{Income excess})
\]

So, relief = (₹ 14,76,750 − ₹ 13,12,500) − (₹ 51 L − ₹ 50 L) = **₹ 64,250**. Dravid ends up paying **₹ 64,250** less than the raw calculation, making the tax system a tad less cruel.  

---  

## Key takeaways from this chapter  

- Filing a correct Income‑Tax Return (ITR) is *your civic duty* – think of it as voting, but with money.  
- The IT Department can see every trade you make; your PAN is the universal key.  
- Only **≈ 5 %** of Indians file returns, and **≈ 1 %** actually pay tax – we have a lot of work ahead!  
- **FY** = the year you earned; **AY** = the year you file. FY runs 1 Apr – 31 Mar.  
- Your tax bill depends on the slab you fall into, which varies by **age** and **regime** you pick.  
- The **new regime** offers lower rates but fewer deductions; the **old regime** lets you claim a garden of exemptions.  

> **Disclaimer:** This is *general* education material. Before you click “Submit” on any ITR, have a qualified Chartered Accountant (CA) give it a once‑over. The content is meant for individual retail investors and traders in India only.  

---  