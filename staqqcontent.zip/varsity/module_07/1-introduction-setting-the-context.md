# 1.    Introduction (Setting the Context)

**Source:** https://zerodha.com/varsity/chapter/introduction-setting-the-context/

---

I can still hear the thump of the bass at that birthday bash ten‑ish years ago, when I was introduced to a rare breed of Chartered Accountant – the kind who can quote both the Income‑Tax Act and the latest market chart without breaking a sweat. He asked, “What do you do for a living?” and I, with the swagger of a self‑proclaimed day‑trader, blurted out, “I trade for a living.” Instantly we hit it off like two traders who just discovered a common “stop‑loss” – the conversation flowed, the drinks kept coming, and then the CA pulled out his “tax‑guy” checklist:

- **How do I declare the profits or losses from my market activity?**  
- **Do I need to split speculative business income from non‑speculative business income?**  
- **Which books of accounts am I required to keep?**

My brain went blank faster than a 0.5‑second candle after a market crash. I was a market‑obsessed, strategy‑devouring squirrel who had never even glanced at a tax form. My ignorance was the only thing I could proudly display at that moment.

### The “I‑Only‑Learn‑Charts‑Stuff” Phase

I’d spent countless nights glued to candle‑charts, back‑testing strategies, and memorising the names of every candlestick pattern. Taxation? That was the dark side I deliberately avoided, convinced it was a swamp of jargon, endless references to “Section 115A, Sub‑section (2)”, and a mountain of circulars that would make even a seasoned auditor weep.

In my defence, I *did* try once. I marched into my broker’s office, found the dealer (the guy who hands you the “execution confirmation” and also knows the best coffee in town), and asked him about taxes. He leaned back, smiled, and said, “Arre, why worry? Long‑term capital gains tax is 0 % and short‑term capital gains tax is 15 %; that’s it – simple as a 5‑minute call option.”

I knew that was *too* simple. So I asked for someone “more knowledgeable”. Luck (or perhaps the universe’s sense of humor) handed me the Regional Head of the brokerage. I peppered him with the same questions, expecting a deep dive. Instead, he repeated the dealer’s two‑sentence gospel, but this time with a puffed‑up chest and a hint of “I‑know‑my‑stuff” pride.

### The CA Who Spoke in Latin

Defeated but not demoralised, I marched on to a Chartered Accountant. He opened his mouth and unleashed a torrent of fancy terminology: “Section 44AD, presumptive taxation, audit‑trials, and the applicability of the “deemed dividend” rule…” By the time he finished, I felt I’d just survived a tax‑law boot‑camp, but the core answer was still the same 0 %/15 % split. The only difference? He wrapped it in a cloak of incomprehensible jargon that would make a law student’s head spin.

Back then, the internet was a barren desert when it came to Indian market‑tax content. No blogs, no YouTube explain‑ers, no Reddit threads. My quest for clarity was squashed like a bug under a heavy‑handed audit.

---

### Fast‑Forward: What I Learned (and What You’ll Learn)

If I’d had a solid, plain‑English guide back then, I could have saved myself countless hours of head‑scratching, avoided the embarrassment of sounding clueless at parties, and perhaps even saved a few rupees on tax filing. I’m pretty sure a lot of you fellow traders and investors have been in the exact same boat – staring at a Form 16, wondering if your intraday profits belong under “speculative business” or “capital gains”.

The proof? Our own **Taxation Blog** (the one we finally launched a few years ago) has been bombarded with **over 10,000 questions** – a number that only grows when you add the flood of emails and Trading Q&A queries we receive daily. That’s a lot of curious heads trying to untangle the tax maze.

Enter the brand‑new module on **Zerodha Varsity**, proudly titled **“Markets & Taxation”**. This isn’t just another PDF with dense legalese; it’s a one‑stop, bite‑sized, trader‑friendly manual that covers everything you need to know:

- Short‑term vs. long‑term capital gains (yes, that 0 %/15 % split still holds for Indian equities).  
- When to treat your intraday frenzy as **speculative business income** versus a regular business.  
- The mysterious **Section 44AD & 44ADA** – the presumptive tax schemes that can save small‑business traders a lot of paperwork.  
- How to maintain **books of accounts** without turning your spreadsheet into a horror story.  
- And a bunch of other tax‑related quirks that usually hide in footnotes of the Income‑Tax Act.

#### The Secret Sauce: Written by a Trader, Not Just a CA

Here’s the kicker – the whole module is authored by **Nithin** (yes, the same Nithin who’s been trading, learning, and losing money in the market long before he ever wrote a line about tax). That means you get a *trader’s perspective*: straight‑to‑the‑point, no unnecessary detours into “tax wilderness”. You’ll hear explanations like, “If you’re day‑trading more than 5 % of your portfolio, treat it as speculative business – the tax slab will be the same as your personal income, but you’ll get to claim expenses.” It’s the difference between reading a legal brief and listening to a buddy who’s been there, done that, and filed the return.

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/07/M7-Ch1-Intro-Cartoon1.png)

### From “Info‑Hoarders” to “Info‑Sharers”

If you asked any broker a decade ago for tax‑friendly reports, you’d probably get a blank stare and a “That’s not our job” shrug. Brokers used to be the gatekeepers of knowledge – think secret societies where only the elite got the “inside scoop”. They were snobby, pricey, and had an attitude that could rival a hedge fund manager on a bad day.

But the industry is waking up. Customers, no matter how small, now demand transparency, tools, and education. This shift is sparking a **revolution** in Indian broking, and **Zerodha** is right at the epicentre, shaking the foundations with:

- **High‑quality trading platforms** that don’t feel like a 1990s Excel nightmare.  
- **Comprehensive trader education** (hello, Varsity! 🙌).  
- **Ready‑to‑use, tax‑friendly reports** that you can export, upload, and impress the tax officer with.

### Bottom Line: Don’t Fear the Taxman, Befriend Him

Take the plunge, explore the **Markets & Taxonomy** (sorry, *Taxation*) module. The content is crisp, concise, and written in a way that will make you feel confident when you file your returns. You’ll walk away with the kind of peace of mind that only comes from knowing the taxman won’t chase you down with a magnifying glass and a courtroom summons.

Stay connected, stay profitable, and remember – the only thing scarier than a market crash is a tax bill you don’t understand. Let’s make sure it’s the former, not the latter.

— Karthik Rangappa