# 4. Taxation for Investors  

**Source:** <https://zerodha.com/varsity/chapter/taxation-for-investors/>

---  

## 4.1 – Quick Recap  

Remember the “Classify Your Market Activity” chapter? The tax man gives you a neat little choice: **treat your share dealings as capital gains** *or* **as business income (trading)** – and you can pick whichever vibe you like, **no matter how long you kept the shares**. Once you pick a lane, you’ve got to stay on it for the rest of the ride. (See the official circular for the boring legalese.)

In plain English:  

- **Hold‑over‑a‑year stocks** → you’re probably getting dividends and have a “long‑term investor” story, so you can call it *capital gains*.  
- **Quick‑flip delivery trades** (buy‑sell a few times a year) → still fine to label as *investments* **as long as you’re not doing it daily**.  
- **If you’re a day‑trader** you *could* declare every delivery trade as *business income*, but once you go that route you must keep doing it year after year.  

This chapter sticks to the **investment** side (points 1 & 2). In the next chapter we’ll dive into the **trading / business‑income** tax jungle.  

---  

## 4.2 – Long‑Term Capital Gains (LTCG)  

First, a quick glossary:  

| Term | What it means |
|------|---------------|
| **Intraday trade** | Buy **and** sell the same stock *within* one trading session. |
| **Equity‑delivery trade** | Buy, let the shares settle in your DEMAT, then sell later – the “real” investor move. |

All profit from **equity‑delivery** trades or equity‑oriented mutual funds lands in the **Capital Gains** bucket, which splits into:  

- **Long‑Term Capital Gain (LTCG)** – you held the asset **> 1 year**.  
- **Short‑Term Capital Gain (STCG)** – you held it **≤ 1 year**.  

### How the taxman treats LTCG on stocks & equity funds  

| Asset | Tax up to ₹1.25 L | Tax **beyond** ₹1.25 L (before 23 Jul 2024) | Tax **beyond** ₹1.25 L (on/after 23 Jul 2024) |
|-------|-------------------|--------------------------------------------|---------------------------------------------|
| **Equity shares** | **0 %** | **10 %** | **12.5 %** |
| **Equity‑oriented MF** | **0 %** | **10 %** | **12.5 %** |

*The ₹1.25 L exemption is **cumulative** for the whole financial year – it doesn’t reset when you sell a different stock.*  

**Important caveat:** This sweet 0 %/10 %/12.5 % regime ONLY applies when the trade is **on a recognised exchange** *and* you’ve paid **STT (Securities Transaction Tax)**.  

If you move shares **off‑market** (via a Delivery Instruction Slip, not through the exchange), the tax jumps to a flat **20 %** on the gain – for both listed and unlisted securities. You dodge STT, but you get a bigger tax bite.  

#### Gifts are not “sales”  

Receiving shares as a **gift** (via a DIS slip) from a close relative (spouse, siblings, parents, in‑law equivalents, or lineal ancestors/descendants) is *not* a taxable transaction. It’s a gift, not a sale, so no capital‑gain tax.  

#### Debt (non‑equity) mutual funds  

- **Before FY 2024‑25:** LTCG on debt funds required a **3‑year** holding period (instead of 1 year for equity funds).  
- **Finance Bill 2023** changed the game for funds that invest **≤ 35 %** in equity: they **lose indexation benefit** and are taxed at your **regular slab rates** for any gains made **on or after 1 Apr 2023**.  

#### Cryptocurrencies / Virtual Digital Assets (VDA)  

Flat **30 %** on **any** gain – long or short term. No deductions allowed except the cost of acquisition.  

---  

## 4.3 – Indexation (the “inflation‑adjuster”)  

**Inflation** is the sneaky thief that makes today’s ₹100 candy bar cost ₹110 next year. Indexation tries to give you a fair “real” profit by inflating your purchase price to today’s rupee value.  

### Before the 2024 budget  
You could claim indexation on:  

- Non‑equity mutual funds  
- Property, gold, and other assets taxed under LTCG  

### After the 2024 budget  
**All** assets *lose* the indexation benefit **except**:  

- **Real‑estate bought *before* 23 July 2024** – you can still pick the **old regime (20 % with indexation)** *or* the **new regime (12.5 % without indexation)**.  

> **How to compute the indexed cost?**  
> Use the **Cost Inflation Index (CII)** from the Income‑Tax portal.  

### Example – Apartment flip  

| Item | Amount |
|------|--------|
| **Purchase price (2015)** | ₹10,00,000 |
| **Sale price (2025)** | ₹30,00,000 |
| **Holding period** | 10 years |

#### New regime (no indexation)  
- LTCG = Sale – Purchase = ₹30,00,000 – ₹10,00,000 = **₹20,00,000**  
- Tax = 12.5 % × ₹20,00,000 = **₹2,50,000**  

#### Old regime (20 % with indexation)  

1. **CII**: 2015 = 240, 2025 = 363  
2. **Indexed purchase price** = ₹10,00,000 × (363 / 240) = **₹15,12,500**  
3. **LTCG** = ₹30,00,000 – ₹15,12,500 = **₹14,87,500**  
4. **Tax** = 20 % × ₹14,87,500 = **₹2,97,500**  

*Result:* New‑regime tax (₹2.5 L) < Old‑regime tax (₹2.975 L), so you’d likely stick with the 12.5 % slab. (Sometimes the old regime wins – keep both calculators handy.)

You don’t have to do the math by hand; the IT department’s **CII utility** does it for you.  

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/07/M7-Ch3-cartoon.png)  

---  

## 4.4 – Short‑Term Capital Gains (STCG)  

| Asset | Tax if sold **before** 23 Jul 2024 | Tax if sold **on/after** 23 Jul 2024 |
|-------|-----------------------------------|--------------------------------------|
| **Equity shares** | **15 %** (on recognised exchange, STT paid) | **20 %** |
| **Equity‑oriented MF** | **15 %** | **20 %** |
| **Off‑market shares** | **Your personal slab rate** (e.g., 30 % if you’re in the top slab) | Same – slab rate |
| **Debt MF** | **Your slab rate** (no special STCG rate) | Same – slab rate |

### The “off‑market” twist  

If you swap shares via a Delivery Instruction Slip (no STT), the gain is **taxed at your ordinary income‑tax slab**. So a high‑earning professional in the 30 % slab would pay 30 % on those short‑term gains.  

**Note:** STCG only kicks in if the **total taxable income** crosses the basic exemption threshold:  

- **Old regime:** ₹2.5 L  
- **New regime:** ₹3 L  

If you earned **only** ₹1 L of STCG and nothing else, the 20 % flat tax **does not apply** – you’re under the exemption limit.  

### Debt mutual funds (short‑term)  

- **Holding < 2 years** → treated as STCG and added to your other income, taxed at your slab.  
- Example: Salary ₹8 L + STCG ₹1 L → total ₹9 L → falls in the **20 %** slab, so you’d pay 20 % on that ₹1 L STCG.  

### Crypto again  

Flat **30 %** on any gain, irrespective of holding period.  

---  

## 4.5 – Days of Holding (Why the Calendar Matters)  

The tax difference between LTCG (0 %/10 %/12.5 %) and STCG (15 %/20 %/slab) can be **huge**. Sell a stock after **360 days** → you get hit with 15 % on the whole profit. Hold it **5 days longer** (365 days) → the profit becomes LTCG and you may pay **zero** tax (up to the exemption).  

### FIFO – First‑In‑First‑Out  

If you bought a stock multiple times, the **FIFO** rule decides which batch you’re selling.  

**Example:**  

| Date | Qty | Price (₹) |
|------|-----|----------|
| 10 Apr 2014 | 100 | 800 |
| 01 Jun 2014 | 100 | 820 |
| 01 May 2015 (sell) | 150 | 920 |

*FIFO says:*  

- The first 100 shares sold are the **10 Apr 2014** lot → Gain = (920‑800) × 100 = **₹12,000** (LTCG, 0 % tax).  
- The next 50 shares come from the **01 Jun 2014** lot → Gain = (920‑820) × 50 = **₹5,000** (STCG, 15 % tax = **₹750**).  

> **Zerodha tip:** The **Console** holdings page automatically tracks the age of each lot and shows the FIFO split, complete with a green arrow for holdings > 365 days (tax‑free under the new regime).  

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/06/M7Ch3-image.png)  

### Bonus: Equity‑Tax P&L report  

Zerodha’s **Equity Tax P&L** is one of the few Indian broker reports that separates **Speculative Income, STCG, and LTCG** for you.  

---  

## 4.6 – Quick Note on STT, Advance Tax, and More  

| Item | What it is | Key numbers |
|------|------------|-------------|
| **STT (Securities Transaction Tax)** | Tax on exchange‑traded deals (not off‑market). | **0.1 %** of the transaction value for equity‑delivery trades. |
| **STT treatment** | **Cannot** be added to the cost of acquisition/sale for CG calculation. | Brokerage, exchange, SEBI, stamp duties *can* be added (they reduce your taxable gain). |
| **Advance tax** | Pay‑as‑you‑earn tax on expected profit/short‑term gains. | 15 % by 15 Jun, 45 % by 15 Sep, 75 % by 15 Dec, 100 % by 15 Mar. Penalty ≈ **12 %** per annum on delayed amount. |
| **ITR forms** | Where to report your gains. | **ITR‑2** = Salary + capital gains. <br> **ITR‑3** (formerly ITR‑4) = Business income + capital gains. |

**Practical tip:** If you’ve booked a short‑term profit mid‑year, you can *just* pay advance tax on the profit you have so far. If the year ends up less profitable, you can claim a refund – the IT department now processes those fairly quickly.  

Pay your advance tax via **Challan No./ITNS 280** at <https://incometaxindiaefiling.gov.in/>.  

---  

## 4.7 – Short‑ and Long‑Term Capital Losses  

- **Short‑Term Capital Loss (STCL)** – can be **carried forward for 8 years** and set off against **any** future capital gains (short or long).  
- **Long‑Term Capital Loss (LTCL)** – can **only** be set off against **future LTCG** (not against STCG).  

**Example:**  

- This FY you lose **₹100,000** STCL.  
- Next FY you earn **₹50,000** STCG.  
- You can offset the ₹50,000 gain, so no tax on that slice. The remaining **₹50,000 loss** carries forward to the next year.  

- **Crypto losses** are a special case – they **cannot** be set off against any income, nor carried forward.  

---  

### Key Takeaways  

- **LTCG** – Equity & equity‑MF: **0 % up to ₹1.25 L**, then **10 % (pre‑23 Jul 2024) / 12.5 % (post‑23 Jul 2024)**. Debt MF: **20 % with indexation** (if bought before 23 Jul 2024) or taxed at slab (post‑2023 rules).  
- **STCG** – Equity & equity‑MF: **15 % (pre‑23 Jul 2024) / 20 % (post‑23 Jul 2024)** on exchange trades; **slab rate** on off‑market trades. Debt MF: **your slab**. Crypto: **30 % flat**.  
- **Indexation** = Purchase × (CII<sub>sale</sub>/CII<sub>purchase</sub>). Use the IT‑Dept CII utility – no manual spreadsheet gymnastics needed.  
- **FIFO** decides which lot you’re selling when you have multiple purchases. Zerodha’s Console does this automatically.  
- **STT** (0.1 % on delivery trades) is *not* an allowable expense for CG calculation, but brokerage/other charges *are*.  
- **Advance tax** – pay quarterly, avoid a 12 % interest penalty, and claim refunds if you over‑pay.  

### Further Reading (for the curious nerd)  

- *Livemint*: “If you pay STT, STCG is 15 %; otherwise it follows your slab.”  
- **Income Tax India** – Cost Inflation Index utility.  
- **TaxGuru** – Capital gains tax for mutual funds.  
- **HDFC** – Debt‑MF tax scenario after Finance Bill 2023.  

> **Disclaimer:** This is educational material for **retail individual investors/traders** only. Always consult a Chartered Accountant (CA) before filing your returns.  

---  