# 8. Foreign Stocks and Taxation  

**Source:** <https://zerodha.com/varsity/chapter/foreign-stocks-and-taxation/>

---  

In the earlier chapters we dissected how the Indian Income‑Tax Act treats your home‑grown shares, futures, options, the bookkeeping you need to keep, and when a tax audit can knock on your door. Those pages were penned by Nithin Kamath himself, looking at the market from the trader’s side of the fence.  

Now it’s my turn – I’m Satya Sontanam – and I’ll walk you through the slightly more exotic (and sometimes hair‑raising) world of **taxes on foreign equities**.  

![Foreign‑stock‑tax](https://zerodha.com/varsity/wp-content/uploads/2023/08/foreign-stocks-and-tax.png)

If you thought Indian tax rules were a maze, imagine a maze that’s been glued to a different country’s rule‑book and then spun around three times. The biggest snag shows up when the same income gets taxed *both* abroad **and** back home. Every nation has its own playbook, so we’ll try to cut through the jargon and give you a “cheat‑sheet” view of what matters for stock‑market investments overseas. (We won’t dive into foreign real‑estate, crypto, or gold – just the good‑old equity market.)

---

## 8.1 First Things First: Rules for Global Investing  

You scroll past a headline about Meta, Microsoft, Tesla, or Alphabet and think, “Hey, I want a slice of that pie!” Lately, Indian investors have been sprinkling a little global flavor into their portfolios.  

**How do you actually buy those foreign shares?**  

A handful of Indian fintech platforms now let you buy overseas stocks and ETFs with a few clicks – a massive upgrade from the “write a cheque to a foreign broker” days. But the process isn’t a carbon copy of buying a Nifty‑50 stock. A few extra hoops are in play:

| What it is | What it means for you |
|------------|----------------------|
| **Liberalised Remittance Scheme (LRS)** | The RBI allows you to send **up to USD 2.5 lakh (≈ ₹ 2 crore at ₹ 82/USD)** abroad each financial year. This bucket covers stock purchases, overseas education fees, vacations, etc. Anything beyond that? You’re out of luck (or you’ll need a special RBI approval). |
| **Tax Collection at Source (TCS)** | If your total overseas spend **exceeds ₹ 7 lakh** in a year, the bank collects **20 % TCS** on the amount above the threshold (it used to be 5 % before Oct 2023). FY25 will raise that threshold to **₹ 10 lakh**. In plain English: you invest ₹ 100, the bank withholds ₹ 20, and the remaining ₹ 80 goes into the market. |
| **TCS offset** | Budget 2024 made life a little easier for salaried folks: you can ask your HR to set off the TCS against the TDS deducted from your salary. So if you have a ₹ 1 lac TCS credit and ₹ 3 lac salary TDS, you’ll only see ₹ 2 lac net deduction. |
| **Remittance rule** | When you sell your foreign holding, the proceeds must be **repatriated within 180 days** (unless you reinvest immediately). Leaving the cash idle in a foreign bank account is a no‑no. |
| **Disclosure** | Your Indian ITR must have a separate schedule for foreign assets. The tax department likes to know where your money is sleeping. |
| **Alternative route** | If the LRS, TCS, and repatriation paperwork sound like a horror‑movie plot, you can invest through Indian mutual funds that hold overseas stocks/ETFs. No LRS hassle, just a domestic mutual‑fund wrapper. |

---

## 8.2 Residency Status  

**Resident = taxed on worldwide income.**  
If you’re a resident under Indian law, the taxman says, “Everything you earn, wherever you earn it, belongs to my ledger.” That includes salaries, rental income, and the dividends you collect from a US‑based Apple share.

**Non‑resident = only Indian‑source income matters.**  
If you’ve moved abroad and meet the “non‑resident” tests, India doesn’t care about your foreign earnings. (Your foreign‑based cousin’s stock profits won’t show up on your Indian return.)

**How does the law decide?**  
It’s all about the days you spend on Indian soil. The formal definition sits in the annexure at the end of this chapter, but the quick‑and‑dirty version is:

* If you live and work in India most of the year and only take occasional trips abroad, you’re a **resident**.  
* If you’re away for a long stretch (≥ 182 days in a FY) or meet the “60‑day/365‑day” test, you could be a **non‑resident** or **resident but not ordinarily resident (RNOR)**.

---

## 8.3 Tax in India  

When you own foreign equity, the Indian tax code looks at two streams of money:

1. **Capital gains** – the profit (or loss) when you sell the shares.  
2. **Dividends** – the cash the company decides to share with you.

### Capital Gains  

| Holding period | Tax treatment (as of FY 2024‑25) |
|----------------|---------------------------------|
| **Long‑term** ( > 24 months ) | **12.5 %** + applicable surcharge & cess (this rate kicked in from **23 July 2024**). |
| **Short‑term** ( ≤ 24 months ) | Added to your total income and taxed at your **personal slab rate**. |

#### Example (long‑term)

| Item | Details |
|------|----------|
| Purchase date | 1 Apr 2018 – ₹ 1,00,000 (≈ USD 1,500 at that time) |
| Sale date | 31 Aug 2024 – USD 2,500 received |
| Holding period | 6 years + 4 months → **Long‑term** |
| Exchange rate for conversion | **Telegraphic Transfer Buying Rate** of RBI on **31 July 2024** = **₹ 83.7** per USD |
| Sale value in INR | 2,500 × 83.7 = ₹ 2,09,250 |
| Capital gain | ₹ 2,09,250 − ₹ 1,00,000 = ₹ 1,09,250 |
| Tax due | 12.5 % × ₹ 1,09,250 ≈ ₹ 13,656 |

> **Note:** For shares sold **between 1 Apr 2024 and 22 Jul 2024**, LTCG was taxed at **20 % with indexation** and STCG at slab rates. The holding‑period rule (24 months) stayed the same.

### Dividends  

Dividends are treated as “Income from Other Sources.” You must:

1. Convert the dividend from foreign currency to INR using the **last‑day‑of‑the‑previous‑month** TT‑Buy rate.  
2. Add the INR amount to your total income and tax it at your slab rate.

> **Pro tip:** Many foreign companies withhold tax at source (e.g., US 25 % on dividends). You’ll still declare the gross amount in India and can claim a credit (see DTAA below).

![Foreign‑stock‑tax‑chart](https://zerodha.com/varsity/wp-content/uploads/2024/10/foreign-stocks-taxation.png)

### ETFs – The Slightly Different Beast  

| Scenario | Tax rule (FY 2024‑25) | Change starting FY 2025‑26 |
|----------|----------------------|----------------------------|
| **Foreign‑listed ETFs bought ≥ 1 Apr 2023** | All capital gains in FY 25 (1 Apr 2024‑31 Mar 2025) taxed at **your slab rate**, irrespective of holding period. | From 1 Apr 2025: <br>• LTCG (≥ 24 months) = **12.5 %** (no indexation) <br>• STCG (< 24 months) = **slab rate** |
| **Indian‑listed ETFs that hold foreign securities** | Same as above, but the holding‑period threshold to differentiate LTCG vs STCG is **12 months** (instead of 24). | Same 12‑month rule continues, with LTCG at 12.5 % and STCG at slab rate. |

Quicko (a tax‑tech portal) helped us double‑check that these are the post‑Budget 2024 rates.

---

## 8.4 Foreign Tax  

Don’t get too comfortable yet – the **double‑taxation** monster is still lurking.

### Why might you be taxed twice?  

*You earn a dividend in the US, the US withholds 25 % at source, and India also wants its share.*  
Most countries, including India, have **Double Taxation Avoidance Agreements (DTAA)** to make sure you don’t end up paying the same rupee twice.

### How does India usually avoid double tax?  

The **credit method** is the most common. You get a **tax credit** for the foreign tax you’ve already paid, which you can claim against your Indian tax liability on the same income. The paperwork? **Form 67** filed with your ITR.

### DTAA in action – United States  

| Income type | US rule for non‑residents | Indian rule (DTAA) | What you actually pay |
|------------|--------------------------|--------------------|----------------------|
| **Capital gains** | No US tax on non‑resident shareholders (except on US real‑estate) | Taxed in India (12.5 % LT or slab ST) | **Only Indian tax** – no double tax. |
| **Dividends** | 25 % withholding at source | Taxed in India (slab) but you can claim credit for the 25 % US tax. | You pay your Indian slab rate **minus** the credit for the 25 % already deducted. |

> **Bottom line:** You still declare the **gross dividend** (the amount before the US withheld tax) in INR, then use Form 67 to ask the Indian tax office to give you credit for the 25 % already taken abroad.

If you invest in other jurisdictions (UK, Singapore, Australia, etc.), the DTAA terms differ. Some countries may tax capital gains, some may not. Your broker’s tax‑statement is a good starting point, but **consult a tax professional** for the nitty‑gritty.

---

## 8.5 Reporting of Foreign Assets in ITR  

If you love paperwork, you’ll feel right at home. If not… well, you’ll still have to fill it out. The Income‑Tax Department wants a **full inventory** of every foreign bank account, depository, and stock you hold.

### The forms and schedules  

| Schedule / Form | What you put in |
|-----------------|-----------------|
| **FSI** (Foreign Source Income) | Details of foreign income (dividends, interest, etc.) |
| **FA** (Foreign Assets) | List of foreign bank/depository accounts, stocks, etc. |
| **TR** (Tax Relief) | Claim of tax credit under DTAA (Form 67 is attached here). |
| **Form 67** | Specific claim for foreign tax paid (must be filed with ITR). |

> **Tip:** Choose the right ITR form (ITR‑2, ITR‑3, etc.) based on your source of income. The schedules are only relevant if you are a **resident** for tax purposes.

### Calendar year vs. Financial year  

- **Calendar year** determines *when* you must disclose an asset.  
- **Financial year** (April 1 – March 31) determines *when* the income is taxed.

#### Example walkthrough (FY 2023)

| Asset | Purchase / Dividend date | Calendar‑year relevance | Tax‑year relevance |
|------|--------------------------|------------------------|--------------------|
| **Microsoft stock** | Bought Sep 2022, dividend Nov 2022 | **2022** (so you must disclose it in the FY 2022‑23 return) | Dividend falls in FY 2022‑23, so it’s taxable then. |
| **Alphabet stock** | Bought Jan 2023, dividend Mar 2023 | Not in calendar 2022 → **no disclosure** needed for FY 23. | Dividend is still in FY 23, so you pay tax on it, but you don’t have to list the asset in the foreign‑asset schedule (because you didn’t own it in 2022). |

Even if you don’t have to list an asset in the schedule (because you didn’t own it in the calendar year), any **income** it generated is still taxable.

### Other practical pointers  

* Keep records of **opening, closing, peak, and transaction balances** for every foreign account.  
* Note the **foreign‑tax paid** and the **exchange‑rate** used for conversion (the RBI TT‑Buy rate on the specified dates).  
* If your **total income > ₹ 50 lakh**, you’ll also have to fill **Schedule AL** with a snapshot of all assets (Indian + foreign) as on **31 Mar 2023**.  

---

## Annexure – Definition of “Resident” (Income‑Tax Act)

A person is deemed a **resident of India** if **either** of the following conditions is satisfied:

1. **Physical presence test** – Stayed in India for **≥ 182 days** in the relevant financial year, **or**  
2. **Combined test** – Stayed **≥ 60 days** in the FY **and** **≥ 365 days** in the four preceding FYs.

> **Special case:** Indian citizens or persons of Indian origin who are in India for employment or a visit, and whose total Indian income **exceeds ₹ 15 lakh** in that FY, are automatically treated as residents (even if they spent less than 60 days in India).  

*Example:* An Indian citizen working in the UAE (where there’s no personal income tax) earns **₹ 16 lakh** from Indian sources in FY 2024. Even if he never set foot in India that year, the tax law deems him a **resident** for FY 2024.

---

### Key Takeaways  

- **Foreign‑stock investing isn’t a copy‑paste of the Indian market.** You must juggle LRS limits, TCS, repatriation timelines, and mandatory disclosures.  
- **Residents are taxed on worldwide income.** So any capital gains or dividends from overseas equities end up in your Indian tax bill.  
- **If the foreign country also taxes the same income,** you can usually claim **exemption** or a **tax credit** under the relevant **DTAA** (usually via Form 67).  
- **DTAA details differ country‑by‑country.** For the US, capital gains on shares are only taxed in India, while dividends attract a 25 % US withholding that you can credit. Other nations may have different rules – get a tax pro to decode them.  
- **Never forget to disclose foreign assets** in the proper ITR schedules (FSI, FA, TR, Schedule AL). The tax department loves to know where your money sleeps.  

> **Disclaimer:** This write‑up is for general information only. It does **not** constitute tax, financial, or legal advice. Always consult a qualified tax adviser before making any decisions that affect your wallet.  