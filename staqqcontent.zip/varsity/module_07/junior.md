# Junior  

**Source:** https://zerodha.com/varsity/chapter/episode-1-ideas-by-the-lake/  

*(Yep, that’s the place where Zerodha’s brainy folks went to sip tea and spit out trading ideas—by a lake, because apparently good ideas need good scenery.)*  

---  

📹 **Watch the video:** https://www.youtube.com/watch?v=9155SZc96kk  

*(Grab your popcorn (or chai) and enjoy the episode where the “Lake‑side Brainstorm” meets the world of trading. Spoiler: there are no actual fish, just a lot of charts.)*  