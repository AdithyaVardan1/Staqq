# 7.     ITR Forms (The Grand Finale)

**Source:** https://zerodha.com/varsity/chapter/itr-forms/

---  

## 7.1 – Income‑Tax‑Return (ITR) Forms  

Alright, you’ve survived the maze of capital gains, TDS, and the occasional “why‑did‑my‑broker‑charge‑me‑so‑much?” – now comes the last act: filing your Income‑Tax Return (ITR). Think of it as the *final boss* of the tax‑year video‑game. Below is a quick‑and‑dirty (but still 100 % correct) cheat‑sheet for every trader‑investor who wants to keep the tax‑man happy without losing sleep.

### Paying tax ≠ filing tax – don’t get them mixed up!  

Many of us hear the phrase “pay your taxes” and assume that once the money’s out of our bank account, the job is done. Spoiler alert: it’s not.  

* **Paying Income Tax** – If you’re a salaried employee, your boss (a.k.a. your employer) automatically slices off a chunk of your paycheck and sends it to the government. That’s the classic **Tax‑Deducted‑at‑Source (TDS)**. It’s like your employer is a silent, dutiful bar‑tab payer for you.  

* **What if you have other cash‑cows?** Say you also earn money from active delivery‑based equity trading. The tax department doesn’t know you’re a secret superhero, so the TDS on your salary won’t cover those extra earnings. It’s **your** responsibility to tell the tax office about that side‑hustle and pay the right amount of tax on it.  

### Filing Income‑Tax Returns – the official “Hey, here’s what I earned”  

Filing an ITR is the *formal* way of saying “I’m not hiding anything, here’s the full menu of my income.” Even if the only thing you earn is a salary, filing tells the government, “Yep, I’m clean; I have no hidden pizza‑delivery earnings.”  

In technical terms, an **Income‑Tax Return (ITR)** is a prescribed form that communicates *all* your income sources for the financial year and the taxes already paid on them. The government has a whole family of ITR forms, each tailored to a specific mix of income streams. You can download them from the official portal here: https://incometaxindiaefiling.gov.in/.  

---  

## 7.2 – Different ITR Forms  

Since we’re talking about people who invest, trade, or run a little‑sized business out of their home office, the following forms are the ones you’ll actually meet in the wild.

| Form | When to use it | Income ceiling | Why you *can’t* use it for certain incomes |
|------|----------------|----------------|-------------------------------------------|
| **ITR‑1 (SAHAJ)** | Salary + interest + *one* house‑property | Up to **₹50 lakhs** total income | No capital gains, no business income – it’s the “basic” form. |
| **ITR‑2** | Salary + interest + house‑property + **capital gains** (but **no** business) | No upper limit (still within normal filing limits) | If you run a trading business, you must step up. |
| **ITR‑3** (formerly ITR‑4 renamed 2017) | Salary + interest + house‑property + capital gains **+** business/profession | No upper limit | This is the “jack‑of‑all‑trades” form. Use it when you declare trading as a business. |
| **ITR‑4 (formerly ITR‑4S)** | Business income **under presumptive scheme** (sections 44AD/44AE) – *no* capital gains | Turnover ≤ **₹10 crore** (₹2 crore till FY 2022‑23, ₹3 crore from FY 2023‑24 if 95 % digital) | You can’t report capital gains or carry forward losses here. It’s a shortcut for small‑business owners who don’t keep full books. |

### Quick TL;DR  

* **Salary‑only folks:** ITR‑1.  
* **Investor‑only (capital gains, no business):** ITR‑2.  
* **Trader‑business + investor:** ITR‑3.  
* **Small business using the presumptive 6 % rule:** ITR‑4.  

---  

## 7.3 – Digging Into ITR‑4 (the “4S” Era until 2017)

### Why ITR‑4 can be a lifesaver  

If you’re the kind of person who thinks “books of accounts” are a medieval torture device, ITR‑4 is your best friend. It lets you **skip formal bookkeeping** (provided your turnover stays under the thresholds) and simply declare **6 % of turnover** as your presumptive profit.  

* **Section 44AD** – The magic clause that says “if your turnover is below the limit, you may assume 6 % profit and pay tax on that.”  
* **Turnover caps:**  

  * Up to FY 2022‑23 → **₹2 crore** (the old limit).  
  * From FY 2023‑24 onward → **₹3 crore** *if* 95 % of receipts are digital (otherwise you’re stuck at ₹2 crore).  

If you exceed the turnover limit, you’re forced out of the presumptive world and must keep proper books.  

### How the numbers play out  

Let’s walk through a realistic example (the numbers are real, the jokes are optional).

| Item | Amount (₹) |
|------|-----------|
| Salary (FY) | 500,000 |
| Business turnover (F&O) | 400,000 |
| Actual F&O loss | 25,000 |

Because the loss **(25,000 / 400,000 = 6.25 %)** is *slightly above* the 6 % threshold, you **cannot** claim a loss under the presumptive scheme. Instead, you *pretend* you earned **6 % of turnover** = **₹24,000** as business income and file ITR‑4 (or the newer ITR‑4S).  

Now compute total taxable income:

```
Salary                = 500,000
Presumptive profit    =   24,000
-------------------------------
Total income          = 524,000
```

Tax calculation (FY 2023‑24 slab for individuals below 60 years):

| Slab | Tax Rate | Tax on that slab |
|------|----------|------------------|
| Up to ₹250,000 | 0 % | 0 |
| ₹250,001 – ₹500,000 | 5 % | (₹500,000‑₹250,000) × 5 % = ₹12,500 |
| ₹500,001 – ₹524,000 | 20 % | (₹524,000‑₹500,000) × 20 % = ₹4,800 |
| **Total tax** | — | **₹17,300** |

So by *pretending* you made a ₹24,000 profit, you pay **₹4,800 extra tax**. Compare that with the cost of a professional audit (often **₹15,000+**). For low‑turnover traders, the presumptive route can be a cheaper way to stay compliant.  

> **Note:** The 6 % rate replaced the older 8 % rule starting AY 2017‑18 (FY 2016‑17).  

---  

## 7.4 – Unpacking ITR‑3  

### The “Swiss‑army‑knife” of returns  

ITR‑3 is the most versatile form. It can handle **salary, house‑property, capital gains, business income, and other sources** (like interest). In short, if you have *any* mix of the above, ITR‑3 is the form that says, “I’ve got it all covered.”  

### Presumptive scheme inside ITR‑3 (post‑FY 2018‑19)  

Since FY 2018‑19, the tax portal added a tick‑box in **Schedule PL** that lets you claim **presumptive income (44AD)** *even when you file ITR‑3*. That means a trader who wants to keep books *and* enjoys the 6 % shortcut can still use ITR‑3 – handy for those who want the flexibility of both worlds.  

#### Example of a mixed‑income scenario  

| Head of income | Amount (₹) |
|----------------|------------|
| Business (presumptive 6 % of ₹1 cr) | 600,000 |
| Loss from house property (interest) | (150,000) |
| Brought‑forward business loss | (50,000) |
| 80C deduction (PF, ELSS, etc.) | (50,000) |
| **Taxable income** | **350,000** |

What happened?  

1. **Presumptive profit** of ₹6 lakhs was declared.  
2. It got *offset* by a ₹1.5 lakhs loss from house‑property and a ₹50 k carry‑forward loss.  
3. The ₹50 k 80C deduction further shaved the taxable base.  

Result: **₹3.5 lakhs** taxable – a much lighter tax bill than if you had reported the full ₹6 lakhs without offsets.  

### The “once you leave, you stay out for five years” rule  

If you **opt out** of the presumptive scheme in any FY (say you had a loss and decided to file normally), you **cannot re‑enter** that scheme for the next **five assessment years**. Example timeline:

| FY | Action |
|----|--------|
| 2022‑23 | Used 44AD (presumptive) |
| 2023‑24 | Opted out, declared loss normally |
| 2024‑25 – 2028‑29 | **You must keep books and cannot use 44AD** |
| 2029‑30 | You’re free to jump back in (if turnover limits still apply). |

During those five years you’ll also need to **pay advance tax in one lump sum (by 15 March)** and, if your total income exceeds the basic exemption limit, a **tax audit** becomes mandatory.  

### Non‑resident caveat  

Section 44AD **does not apply** to non‑residents. If you’re an NRI, you must keep proper books and cannot rely on the 6 % shortcut.  

### Normal provisions (books of accounts)  

When you abandon the presumptive route, you fall back to “normal provisions”:  

* Maintain **Balance Sheet** and **Profit‑and‑Loss** statements.  
* Record every buy/sell of futures and options.  
* Carry forward losses, claim deductions, etc.  

#### Sample F&O entry (illustrative)

| Point in ITR‑3 | What you put |
|----------------|--------------|
| **4** (Sale details) | Total sell value of futures + premium received from options |
| **9** (Purchase details) | Total purchase value of futures + premium paid for options |
| **Result** | Net loss = **₹83,329** (as per the screenshots in the original). |

**Expenses you can claim** (still under “normal provisions”):  

* Salaries for staff who help you trade.  
* Office rent (if you have a dedicated space).  
* Brokerage, exchange fees, STT, etc.  
* Advisory fees, depreciation on laptops, internet bills, etc.  

All of these are deducted *before* you apply your slab rates.  

### Speculative vs. Non‑speculative income  

* **Speculative income** – Intraday trades (no delivery, high leverage). Declared in **Schedule PL**. Taxed at normal slab rates.  
* **Non‑speculative (business) income** – Delivery‑based equity trades, F&O, commodities. Also goes in **Schedule PL** but may be eligible for the presumptive scheme.  

### Capital Gains – the two cousins  

| Type | Where you put it | Typical schedule |
|------|------------------|------------------|
| **Short‑Term Capital Gains (STCG)** | **Schedule CG** (and Form 112A for certain securities) | Taxed at your slab rate |
| **Long‑Term Capital Gains (LTCG)** | **Schedule 112A** | 10 % (or 12.5 % after the 1 Jan 2023 amendment) on gains above **₹1.25 lakhs** |

#### Sample STCG calculation  

* Sale consideration: **₹100,000**  
* Purchase cost: **₹90,000**  
* Transaction charges: **₹1,000**  

**STCG = 100,000 – 90,000 – 1,000 = ₹9,000**  

#### Sample LTCG (post‑23 July 2024)  

Assume you sold shares after holding them for more than a year and the gain exceeds ₹1.25 lakhs. The tax is **10 %** (or **12.5 %** if the law changes again).  

**Grandfathering clause** (shares bought before 31 Jan 2018):  

* The fair‑market value (FMV) as of 31 Jan 2018 is treated as your *cost of acquisition* for any later sale.  
* If FMV (₹611.94) > your sale price, no LTCG liability arises for those pre‑2018 shares.  

The same logic appears in the original screenshots: column 14 shows zero tax for the grandfathered batch.  

---  

## 7.5 – Quick FAQ and Handy Notes  

| Question | Answer (with a splash of humour) |
|----------|-----------------------------------|
| **How do I file electronically?** | Hop on to the e‑filing portal: <https://www.incometaxindiaefiling.gov.in/>. There’s even a snazzy video from the tax department (it’s not a TikTok, promise). |
| **Do I need to attach supporting docs?** | No. ITRs are *attachment‑less*. Keep your TDS certificates, investment proofs, etc., in a safe drawer (or cloud) – you’ll need them only if the tax officer knocks on your door. If you’re under audit, you’ll have to attach a soft copy of your Balance Sheet, P&L, and audit report. |
| **What’s the diff between e‑payment & e‑filing?** | *E‑payment* = you’re actually paying tax (net‑banking, SBI card, etc.). *E‑filing* = you’re sending the return to the tax department. Think of e‑payment as paying the bar tab, e‑filing as sending the receipt to the landlord. |
| **Do I still file if I made a loss?** | Absolutely! If you want to carry that loss forward to offset future profits, you must file a return before the due date. |
| **When are the due dates?** | *No audit*: **31 July**. <br>*Audit required*: **30 September**. (Mark them on your calendar, not just on your phone’s “reminder” app.) |
| **What do I write under “Nature of Business” on ITR‑3 (or ITR‑4 pre‑2017)?** | Use the code **0204 – Trading‑Others** for the older version. From FY 2017‑18 onward, the code is **13010 – Financial intermediation/Investment activities**. |
| **What if I’m late?** | You’ll pay interest on any tax due **plus** a penalty under Section 234F: **₹1,000** if your income ≤ ₹5 lakhs, **₹5,000** if > ₹5 lakhs. |
| **How to show profit & loss on the balance sheet?** | Gross receipts = positive turnover; gross sales = negative turnover. Keep it simple, keep it honest. |
| **Can I file after the deadline?** | Yes – it’s called a **belated return**. You have **1 year** from the end of the FY (or until the assessment is completed, whichever is earlier). Expect interest + penalties as per the table above. |
| **What about “updated returns” under Section 139(8A)?** | If you discover an error after filing a belated return, you can file an updated return. Penalty = **25 %** of the *additional tax + interest* if done within 12 months of the assessment year, **50 %** if within 24 months. |
| **Sample forms** | Below are the screenshots of ITR‑3, ITR‑4, and a sample computation (same as in the original). |  

---  

### Key Takeaways (the “cheat‑sheet” you can tattoo on your forehead)

1. **Tax payment** = the cash you actually hand over (via e‑payment).  
2. **Tax filing** = the formal communication of *all* your income sources and taxes already paid.  
3. Filing is **mandatory** even if you’ve already paid tax via TDS.  
4. Pick the **right ITR** for your income mix – don’t force a square peg into a round hole.  
5. **ITR‑4S** (presumptive) can dramatically lower cash outflow when you have low turnover business income, but you lose the ability to claim capital‑gains or carry forward losses.  
6. **Stay compliant** – procrastination only invites interest, penalties, and sleepless nights.  

Phew! That wraps up the taxation chapter. Tax law is a jungle of jargon, but with the right map (this chapter) you can swing through without getting tangled.  

**Financial discipline = long‑term wealth.** It starts with filing your returns on time, accurately, and with a dash of humor.  

Spread the knowledge, keep the jokes flowing, and happy (tax‑compliant) trading!  

— Nithin Kamath, Zerodha  

*Special thanks to TaxIQ for the priceless inputs throughout this module.*  

> **Disclaimer:** This write‑up is for **retail individual investors/traders** only. Always consult a qualified Chartered Accountant (CA) before filing your returns.  

---  

### Bonus: Sample ITR Screenshots (FY 2022‑23)

| ITR‑3 Sample | ITR‑4 Sample | Computation Sample |
|--------------|--------------|-------------------|
| ![ITR‑3](http://zerodha.com/varsity/wp-content/uploads/2015/06/xls.jpg) | ![ITR‑4](http://zerodha.com/varsity/wp-content/uploads/2015/06/xls.jpg) | ![Computation](http://zerodha.com/varsity/wp-content/uploads/2015/06/xls.jpg) |

*(Images are placeholders – replace with the actual screenshots from the portal when you file.)*  