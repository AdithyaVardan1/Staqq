# 5. Taxation for Traders  

**Source:** <https://zerodha.com/varsity/chapter/taxation-for-traders/>  

---  

## 5.1 – Quick Recap  

Alright, let’s rewind the tape from the previous chapter (yes, the one where we talked about “investor vs. trader” while sipping chai).  

- **Investor** – You hang on to equities **more than 1 year** and report the profit as **Long‑Term Capital Gains (LTCG)**.  
- **Short‑Term Capital Gains (STCG)** – You keep the stock **longer than a day but shorter than a year**; the tax treatment is different, but you’re still in the “investor” camp.  

Now, if you’re flicking the switch on trades every other day, or if the market is your main paycheck, it’s usually smarter to treat those gains as **business income** rather than capital gains.  

From here on we’ll focus on the scenario where *trading is declared as a business*. That business can be split into two flavors:

| Business type | What it covers | Why it’s called that |
|---------------|----------------|---------------------|
| **Speculative business income** | Intraday equity trading (you never intend to take delivery) | “Speculative” because you’re basically gambling on price moves within the same day. |
| **Non‑speculative business income** | Futures & Options (F&O) – both intraday **and** carry‑over positions, plus delivery‑based equity trades that you do a lot of | It’s “non‑speculative” because the contracts are defined as deliverable (or hedge‑able) instruments, even if they settle in cash today. |

A few nuggets to chew on:  

* Until FY 24, all of this income was shoved into a vague “Other” bucket. Starting FY 25 the taxman gave us dedicated business codes, so you can finally brag that you’re not “Other”.  

| Business code | Description |
|---------------|-------------|
| **21009** | Income from Intraday Trading – Speculative Business Income |
| **21010** | Income from F&O – Non‑speculative Business Income |

The surge of traders made the tax authorities realize that “Other” was getting too crowded, so they carved out these codes. **You’ll still file ITR‑3** (the same form you used before), but now you’ll tick the proper box for 21009 or 21010.  

---

## 5.2 – Taxation of Trading / Business Income  

Unlike the neat‑and‑tidy slab for capital gains, **business income** simply gets added to **all** your other earnings (salary, rental, interest, other businesses) and the whole pile is taxed at the slab rates that apply to you.  

Let’s walk through a *real‑world‑ish* example (imagine I’m the guy at the bar who’s also a tax‑savvy accountant).  

| Source of Income | Amount (₹) |
|------------------|-----------|
| Salary | 1,000,000 |
| Short‑term capital gains (delivery‑based equity) | 100,000 |
| Profits from F&O trading | 150,000 |
| Intraday equity trading | 125,000 |

**Step 1 – Build the “business” total** (salary + both types of trading income). Capital gains are **not** added because they have their own fixed rate.  

```
Total business income = 1,000,000 (salary)
                     +   150,000 (F&O)
                     +   125,000 (intraday)
                     = 1,275,000
```

**Step 2 – Apply the standard deduction (new tax regime)** – you can shave off ₹75,000 before the slab calculation, leaving a **taxable base of ₹1,200,000**.  

**Step 3 – Run the slab calculator** (FY 2024‑25, new regime):  

| Slab (₹) | Rate | Tax on this slab |
|----------|------|-----------------|
| 0 – 300,000 | 0 % | 0 |
| 300,001 – 700,000 | 5 % | (400,000 × 5 %) = 20,000 |
| 700,001 – 1,000,000 | 10 % | (300,000 × 10 %) = 30,000 |
| 1,000,001 – 1,200,000 | 15 % | (200,000 × 15 %) = 30,000 |

**Tax from business & salary = ₹80,000**  

**Step 4 – Add the STCG tax** – short‑term capital gains are taxed at a flat **20 %**.  

```
STCG tax = 100,000 × 20% = 20,000
```

**Grand total tax = 80,000 + 20,000 = ₹100,000**  

That’s the bottom‑line: combine business income, apply the standard deduction, run the slab, then tack on any capital‑gain tax.  

---

## 5.3 – Carry‑Forward Business Loss  

Timing is everything—especially when it comes to filing.  

| Deadline | Non‑audit case | Audit case |
|----------|----------------|-----------|
| **July 31** | Return must be filed (no excuse) | — |
| **September 30** | — | Return must be filed (audit‑related) |

If you miss the deadline, you **lose** the right to carry forward any loss, so set those alarms!  

### How the loss‑carry works  

| Loss type | Carry‑forward period | What it can offset |
|-----------|---------------------|--------------------|
| **Speculative loss** (intraday) | 4 years | Only against **speculative gains** (same or future years) |
| **Non‑speculative loss** (F&O, delivery‑based, etc.) | 8 years | Against **any other business income** (but **not** salary) in the same year; later years only against **non‑speculative gains** |

### Example – Using a non‑speculative loss  

Suppose you wear many hats: a hotelier, a bond‑interest earner, and a futures trader.  

| Income | Amount (₹) |
|--------|------------|
| Hotel business | 1,500,000 |
| Interest income |   200,000 |
| Non‑speculative loss (F&O) | –700,000 |

**Taxable income = (1,500,000 + 200,000) – 700,000 = 1,000,000**  

Now apply the slab (same as before):  

- 0‑300k → 0  
- 300k‑700k → 20,000  
- 700k‑1,000k → 30,000  

**Tax = ₹50,000**  

So a ₹700k loss saved you a nice chunk of tax.  

---

## 5.4 – Offsetting Speculative and Non‑Speculative Business Income  

**Rule of thumb:** *Speculative losses only talk to speculative gains.* They refuse to shake hands with non‑speculative profits.  

### Scenario 1 – Speculative loss vs. non‑speculative profit  

- Salary = ₹1,000,000  
- Non‑speculative profit = ₹100,000  
- Speculative loss = –₹100,000  

You **cannot** net the ₹100k profit against the ₹100k loss. The loss is stuck in the speculative lane, so you pay tax on the ₹100k non‑speculative profit.  

**Tax calculation**  

```
Total taxable = Salary + Non‑speculative profit
               = 1,000,000 + 100,000
               = 1,100,000
```

Apply slabs:  

- 0‑300k → 0  
- 300k‑700k → 20,000  
- 700k‑1,000k → 30,000  
- 1,000k‑1,100k → (100,000 × 15 %) = 15,000  

**Tax = ₹65,000**  

You still have a **speculative loss of ₹100,000** to carry forward for up to four years, but it won’t reduce today’s tax.  

### Scenario 2 – Speculative gain vs. non‑speculative loss  

If you flip the script (speculative gain ₹100k, non‑speculative loss ₹100k), they *can* offset each other, because a speculative **gain** can be reduced by a non‑speculative **loss**. In that case you’d only owe tax on the ₹1,000,000 salary.  

---

![Cartoon: Two traders arguing over loss offsets](http://zerodha.com/varsity/wp-content/uploads/2015/06/M7-Ch4-Cartoon2.png)  

---

## 5.5 – What Is Tax‑Loss Harvesting?  

Picture this: it’s the last day of the financial year, you have a **paper profit** of ₹200k and a **paper loss** of ₹150k sitting in different stocks. If you do nothing, you’ll get taxed on the ₹200k profit **and** carry the ₹150k loss forward to the next year (where it may or may not be useful).  

**Tax‑loss harvesting** is the art of *realising* that loss **right now** (sell the losing position) and, if you still believe in the stock, **buy it back** immediately (or within a short window). The loss becomes a **realised** loss for the current year, shaving off your tax bill, while you stay in the market.  

In the U.S., the IRS calls a quick‑turn‑around “wash sale” and disallows the loss. India has **no explicit rule** against the practice, but the tax authorities could raise eyebrows if you sell and repurchase the same security *just* to dodge tax. Bottom line: **talk to a CA** before you start playing “tax‑loss hopscotch”.  

---

## 5.6 – BTST (ATST) – Is It Speculative, Non‑Speculative, or STCG?  

**BTST** (Buy‑Today‑Sell‑Tomorrow) and **ATST** (Acquire‑Today‑Sell‑Tomorrow) are the night‑owl’s version of “overnight holding”. You buy a share today, sell it the next day **without taking delivery**.  

Two camps argue over its classification:  

1. **Speculative camp** – “No delivery, so it’s intraday‑style, hence speculative.”  
2. **Non‑speculative / STCG camp** – “The exchange levies STT exactly like a normal delivery trade, so treat it as a short‑term capital gain.”  

**Practical advice:**  
- If you only dabble in BTST a handful of times a year, label it **STCG**.  
- If BTST is your daily bread (i.e., you’re doing it *a lot*), file it under **speculative business income** (code 21009).  

---

## 5.7 – Advance Tax – Business Income  

When you have **business income**, the taxman expects you to pay **advance tax** in four installments, just like a disciplined gym‑goer pays his fees on time.  

| Due date | Percentage of **estimated total tax** |
|----------|--------------------------------------|
| 15 Jun | 15 % |
| 15 Sep | 45 % (cumulative) |
| 15 Dec | 75 % (cumulative) |
| 15 Mar | 100 % (cumulative) |

**How do you know the “percentage of what”?**  
You estimate your **annual tax liability** based on the income you’ve earned *so far* and pay the corresponding slice. The tricky part: trading can be a roller‑coaster. You might be roaring in September and then flat‑lining in December. That’s why the safest route is to **pay based on actual earnings up to each checkpoint**.  

If you under‑pay, the penalty is **12 % per annum** (prorated for the period of default). Over‑pay? No worries—you can claim a **refund** later, and the IT department usually processes refunds fairly quickly.  

**Paying online** is a breeze: hit the “Challan No./ITNS 280” link on the e‑filing portal <https://incometaxindiaefiling.gov.in/>.  

Need a calculator? The Income Tax website hosts a handy **Advance Tax Calculator** and a **Penalty/Interest** estimator – both worth bookmarking.  

---

## 5.8 – Balance Sheet and P&L Statements  

If you’ve declared your trades as a business, you now have the **same paperwork** as a shop‑owner selling mangoes. That means:  

- **Balance Sheet** – a snapshot of what you own (assets) and owe (liabilities) on March 31.  
- **Profit & Loss (P&L) Statement** – a movie of how much you earned and spent over the financial year.  

Depending on your **turnover** and **profitability**, you might have to get these statements **audited** (more on that in the next section).  

---

## 5.9 – Turnover and Tax Audit  

### When does the tax man knock on your door?  

| Condition | Audit required? |
|-----------|-----------------|
| Business turnover **> ₹10 crore** (FY 24‑25) | **Yes** |
| Equity trader who **opts out of presumptive tax (Section 44AD)**, profits **< 6 % of turnover**, and **total income > basic exemption limit** | **Yes** |

*Presumptive taxation* is the “I’ll tell you a flat % of turnover as profit” scheme. If you ditch it, the tax authorities want to make sure you’re not hiding anything, so they demand an audit.  

### What’s an audit, really?  

In plain English, an **audit** is a *check‑up* of your books. The Income Tax Act mandates a **tax audit** when you cross the thresholds above. It’s not a forensic investigation (unless you’re doing something shady), just a professional verification that your **balance sheet** and **P&L** are prepared correctly.  

Because the IT department can’t possibly review every single trader’s statements, they delegate the job to a **Chartered Accountant (CA)** – a qualified, government‑authorized number‑cruncher.  

#### The CA’s role (in a nutshell)  

1. **Prepare** the balance sheet and P&L (most traders hand over the raw data and let the CA do the formatting).  
2. **Audit** – verify the numbers, sign the statements, and attach the audit report (Form 3CA).  

The audit does more than keep the taxman happy:  

- Shows you the health of your trading “business”.  
- Guarantees that deductions you claim are legit.  
- Helps lenders (banks, NBFCs) assess your creditworthiness.  

### Which ITR form?  

- **ITR‑3** for business income (the old ITR‑4 was for presumptive tax).  
- **Don’t cheat** by masquerading speculative income as capital gains just to stay on ITR‑4 – the tax department can sniff that out and you could end up in a *“why‑did‑you‑do‑that?”* audit.  

### Business expenses you can claim  

When you treat trading as a business, **every cost that helped you earn can be deducted**. Here’s the cheat‑sheet:  

| Expense | Can you deduct it? |
|---------|--------------------|
| Trading charges (STT, brokerage, exchange fees, other taxes) | **Yes** (STT is *not* deductible for capital gains, but it is for business). |
| Internet/phone bills (portion used for trading) | **Yes** |
| Depreciation of computers, monitors, routers, etc. | **Yes** |
| Rent for a home‑office or a dedicated room (pro‑rata) | **Yes** |
| Salary paid to a helper/assistant who actually trades for you | **Yes** |
| Advisory fees, books, newspapers, subscriptions (trading‑related) | **Yes** |

These deductions lower your **taxable business income**, possibly turning a profit into a loss that can be carried forward (see Section 5.3).  

---

## Key Takeaways from This Chapter  

- **Speculative business income** = intraday equity trades (code 21009).  
- **Non‑speculative business income** = F&O, and heavily‑traded delivery‑based equity (code 21010).  
- **Speculative losses** can **only** be set‑off against **speculative gains** (same year or carried forward up to 4 years).  
- **Non‑speculative losses** can offset **any other business income** (except salary) in the same year and be carried forward up to 8 years, but only against non‑speculative gains thereafter.  
- **Advance tax** is mandatory: 15 % by 15 Jun, 45 % by 15 Sep, 75 % by 15 Dec, 100 % by 15 Mar. Penalty for missing it = 12 % p.a.  
- **All trading‑related expenses** (brokerage, STT, internet, depreciation, rent, salaries, advisory fees) are deductible when you report income as business.  

> **Disclaimer:** This is a *friendly* guide, not legal advice. Always **consult a Chartered Accountant** before filing your returns. The material here applies only to **retail individual investors/traders** in India.  