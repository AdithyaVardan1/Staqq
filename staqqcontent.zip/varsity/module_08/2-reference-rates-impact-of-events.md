# 2.  Reference Rates & Impact of Events  

**Source:** https://zerodha.com/varsity/chapter/reference-rates-impact-of-events/  

---  

## 2.1 – Dual View  

Picture this: you’re at the bar, sipping a cold one, and you decide to buy a share of **Infosys**. Your brain does the usual “bullish or bearish” dance—if you think the stock will go up, you buy; if you think it will tumble, you sell. Simple, right?  

Now imagine you’re playing with a **currency pair**—say **USD/INR**. When you buy or sell that pair you’re actually pulling a double‑act on the audience. Buying USD/INR means you’re **bullish on the US dollar** *and* **bearish on the Indian rupee** at the same time.  

Why the split personality?  

Because a currency never stands alone; it’s always quoted **against another**. Remember the little formula from the previous chapter:  

```
Base Currency / Quotation Currency = Value
```  

In plain English: “How many units of the quote currency can I snag with one unit of the base?”  

If you decide to **buy** the pair, you’re betting that the **value** (the number you see on the screen) will rise.  
Example: USD/INR = 65. You buy, hoping the quote climbs to 68.  

When the number goes up, it means **1 USD will fetch more INR**. So the **base (USD) gets stronger**, while the **quote (INR) gets weaker**.  

![Cartoon](http://zerodha.com/varsity/wp-content/uploads/2016/06/M8C2-Cartoon.png)  

In other words, a rising pair is a win‑win for the base and a loss‑loss for the quote.  

The flip side? **Selling** USD/INR means you expect the opposite: the base will buy fewer quotes. You’re **bearish on USD** and **bullish on INR**.  

So, “strengthening/weakening” really means:

- **Base currency strengthens** when it can buy **more** of the quote.  
  *Example*: USD/INR jumps from 67 → 68 → **USD** is the heavyweight, **INR** is wobbling.  
- **Quote currency strengthens** when the base can buy **less** of it.  
  *Example*: USD/INR slides from 66 → 65 → **INR** gets the upper hand, **USD** is feeling a bit shy.  

“Appreciation” and “depreciation” are just fancy synonyms for the same thing.  

### Two‑Way Quote (Bid / Ask)  

Just like stocks, currencies have a **two‑way quote**—the price you can **buy** (Ask) and the price you can **sell** (Bid). No need to over‑think it; think “Bid = what someone’s willing to pay me, Ask = what I have to pay them.”  

Check out this snapshot from a forex site (I’ve highlighted EUR/USD and GBP/USD for you):  

![Two‑Way Quote](http://zerodha.com/varsity/wp-content/uploads/2016/06/Image-1_spot-2-way-quote.png)  

If you want to **go long EUR/USD**, you pay the **Ask** price, say **1.1270**. You’re effectively **long EUR** and **short USD**.  

If you want to **sell** EUR/USD, you do it at the **Bid** price, say **1.1269**. Now you’re **short EUR** and **long USD**—the dual‑view in action again.  

Sometimes the quote is shown in a short form, e.g.  

```
EUR/USD – 1.1269/70
```  

Notice the Bid (1.1269) is written out fully, while the Ask (1.1270) drops the leading digits and only shows the last two “pips”.  

**Pips** are the smallest price movement unit in forex. So, if EUR/USD moves from **1.1270 → 1.1272**, that’s a **2‑pip** shift.  

---  

## 2.2 – Rate Fixing and Conversion Path  

Fast‑forward to today: the RBI’s **Reference Rate** for USD/INR is **67.0737**. This number is the daily “official” spot rate that underpins all Indian currency‑futures settlements.  

![RBI Reference Rate](http://zerodha.com/varsity/wp-content/uploads/2016/06/Image-2_rbi-ref-rate.png)  

That screenshot is straight from the RBI website, showing the **spot** rate for **14 June 2016** (not a futures contract). Futures rates live on the NSE portal.  

### How does the RBI conjure this magic number?  

Spoiler: it’s not a secret AI algorithm, it’s good old‑fashioned polling. Here’s the quick‑and‑dirty version (feel free to skim the official circular if you love paperwork):

1. **Pick the “contributing banks.”** These are the heavy‑hitters in India’s FX market, chosen by market‑share.  
2. **Randomly call a handful** of those banks **between 11:30 AM and 12:30 PM** each business day.  
3. Ask each bank for its **two‑way quote** on USD/INR.  
4. **Average** all the bids and asks separately.  
5. Publish the averaged **mid‑price** as the day’s **Reference Rate**.  
6. Repeat daily—except weekends and bank holidays, of course.  

That’s it! Easy peasy, lemon‑squeezy.  

### The Cross‑Rate Trick  

The RBI only polls **USD/INR** directly. For other pairs like **EUR/INR**, **GBP/INR**, **JPY/INR**, it uses a **cross‑rate** (also called the “crossing” technique).  

Think of it as a currency relay race: you don’t have a direct hand‑off between Euro and Rupee, so you pass the baton through the US Dollar.  

#### Example: Deriving EUR/INR  

1. **Start with the known spot:**  

   ```
   USD/INR = 67.0737
   ```  

   Two‑way view: **67.0730 / 67.0740** (Bid / Ask).  

2. **Grab the EUR/USD quote** from a global source (Bloomberg, Reuters, etc.). Suppose it’s:  

   ```
   EUR/USD = 1.1134 / 1.1140
   ```  

   So you need **1.1140 USD** to buy **1 EUR** (the Ask).  

3. **Convert that USD amount into INR** using the USD/INR Ask:  

   ```
   1 USD = ₹67.0740
   1.1140 USD = 1.1140 × 67.0740 = ₹74.72044
   ```  

   Rounded, **EUR/INR ≈ 74.7240** (Ask).  

Boom—USD acted as the pivot.  

**Your homework:** Using the same method, calculate the **Bid** for EUR/INR (hint: use the USD/INR Bid of 67.0730 and the EUR/USD Bid of 1.1134). Drop your answer in the comments, and we’ll give you a virtual high‑five.  

### What moves those banks’ sentiments?  

Simple: **domestic and international events**. Anything that makes the banks think “hey, the dollar’s about to go up” or “the rupee’s looking shaky” will nudge their quotes, and thus the RBI’s Reference Rate.  

---  

## 2.3 – Events That Matter  

When you read a company’s quarterly earnings, the impact on the stock price is pretty linear: good numbers → happy investors → price up; bad numbers → sad investors → price down.  

Currencies, however, are the **Schrödinger’s cats** of the financial world. Because they’re always quoted in pairs, a single event can **strengthen one side and weaken the other** at the same time. That’s why assessing “fundamentals” for FX feels like trying to solve a Rubik’s cube blindfolded.  

### A Two‑Event Showdown  

- **Event 1:** India gets a flood of **Foreign Direct Investment (FDI)**—great news for the rupee, right?  
- **Event 2:** The US economy spikes (or there’s a commodity‑crash scare) causing the **dollar to rally**.  

Which way does **USD/INR** go?  

There’s no crystal ball answer. The pair will ultimately follow the **dominant** factor, but until that dominance is clear, the market will swing like a drunk on a merry‑go‑round.  

Hence, a successful FX trader becomes a **news‑junkie**, constantly scanning the globe for data that could tip the balance. Below is the starter pack of must‑watch headlines and numbers.  

### 1. Import / Export Data  

India is a net importer of oil, gold, and a handful of other goodies, while it exports software, textiles, and spices.  

- **More exports** → **INR strengthens** (you’re selling foreign currency for rupees).  
- **More imports** → **INR weakens** (you need to buy foreign currency, usually USD, to pay for those imports).  

Why? Imagine you need to buy a barrel of crude oil priced in dollars. You sell rupees, buy dollars → demand for USD rises, USD appreciates, INR depreciates. The reverse happens when you earn dollars from an export and convert them back to rupees.  

### 2. Trade Deficit (Current Account Deficit)  

The **trade deficit** is simply **imports − exports**. A shrinking deficit is a **good‑vibes signal** for the domestic currency because it implies fewer dollars are needed to pay for foreign goods.  

### 3. Interest Rates & the Carry Trade  

Higher interest rates act like a **magnet for foreign capital**. Investors borrow cheap money from low‑rate countries, convert it, and park it in high‑rate havens to earn the spread—this is the classic **carry trade**.  

- **Higher rates** → **Capital inflows** → **Currency appreciates**.  
- **Lower rates** → **Capital outflows** → **Currency depreciates**.  

Central banks (RBI, Fed, ECB) release **policy statements** and **rate decisions** that can move markets faster than a cat on a hot tin roof.  

#### Dovish vs. Hawkish  

- **Dovish** = “We might cut rates soon.” Lower rates = weaker currency.  
- **Hawkish** = “We’re likely to hike rates.” Higher rates = stronger currency.  

A quick visual example:  

![Dovish headline](http://zerodha.com/varsity/wp-content/uploads/2016/06/Image-3_dovish.png)  

*Click* [here](#) *for the full article.*  

![Hawkish headline](http://zerodha.com/varsity/wp-content/uploads/2016/06/Image-4_hawkish.png)  

### 4. Inflation (CPI)  

Inflation is the rate at which everyday prices climb. Central banks fight high inflation by **raising rates** (making money more expensive, cooling demand).  

- **Rising CPI** → **Hawkish stance** → **Higher rates** → **Currency strengthens**.  
- **Falling CPI** → **Dovish stance** → **Lower rates** → **Currency weakens**.  

So, when you see a headline about “inflation ticking up,” start thinking “the central bank might go hawkish, and that could boost the domestic currency.”  

#### Consumer Price Index (CPI)  

The **CPI** tracks a basket of goods and services. A **higher CPI** means inflation is heating up; a **lower CPI** signals cooling. For India’s latest CPI numbers, visit the official stats portal.  

### 5. Gross Domestic Product (GDP)  

GDP is the **total market value** of everything a country produces. We usually quote it as a **growth rate** (e.g., “GDP grew 7.1% YoY”).  

- **Higher growth** → **More investor confidence** → **Currency appreciates**.  
- **Lower growth** → **Less confidence** → **Currency depreciates**.  

### Bottom Line on Events  

There’s an **almost infinite** list of data points that can sway a currency. The key is to understand the **cause‑and‑effect chain** rather than memorizing every single number. The more you grasp how one piece of news ripples through the economy, the better you’ll be at predicting the direction of a pair.  

---  

### Key Takeaways from This Chapter  

- The **base currency** “strengthens” (or **appreciates**) when it can buy **more** of the quote currency.  
- The **base currency** “weakens” (or **depreciates**) when it can buy **fewer** of the quote currency.  
- Going **long** a pair = **long the base**, **short the quote**.  
- Going **short** a pair = **short the base**, **long the quote**.  
- The RBI **polls contributing banks** each day to set the **USD/INR reference rate**.  
- All other Indian FX rates are derived via the **cross‑rate** method (using USD as the bridge).  
- Currency‑pair movements are messy because **events affect both sides** of the pair, sometimes in opposite directions.  
- The **dominant** event eventually steers the pair, but until then expect **volatility**.  
- Countries with **higher interest rates** tend to have **stronger currencies**, and vice‑versa.  
- A **lower trade deficit** (or a narrowing current‑account gap) usually **boosts** the domestic currency.  
- **Higher inflation** generally triggers a **hawkish** stance → **higher rates** → **stronger currency** (the opposite holds for low inflation).  
- Knowing the **cause‑and‑effect** of macro events gives you a huge edge when trading currencies.  

Now go forth, keep an eye on the news, and may your pips be plentiful! 🍻  