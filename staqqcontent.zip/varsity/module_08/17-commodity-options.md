# 17. Commodity Options  

**Source:** <https://zerodha.com/varsity/chapter/commodity-options/>

---  

##  

![Image](https://zerodha.com/varsity/wp-content/uploads/2017/08/M8-C17-Cartoon.png)

## 17.1 – Commodity options, finally!  

My maiden voyage into the world of commodities was a pepper‑futures trade sometime in the twilight of 2005 or the early days of 2006. Since then I’ve been glued to the ticker, watching MCX grow from a scrappy little market into the heavyweight champion of Indian commodities. They’ve kept adding fresh contracts, deepening the order‑book, and the liquidity has ballooned faster than my ego after a winning trade.  

Around 2009 there was a whisper that options would finally make their debut on the commodity floor. I was so thrilled I imagined “buy‑low‑sell‑high” strategies for gold, crude, and even my grandma’s favorite masala blend. Spoiler alert: the idea never materialised, and every time the rumour resurfaced it vanished like a bad trade after the market close.  

Fast forward to June 2017 – SEBI gave the green light, signing off on a file that officially allowed **commodity options**.  

![Image](https://zerodha.com/varsity/wp-content/uploads/2017/08/Commodity-Options-Clear.png)  

*(Read the official announcement [here](#).)*  

Since the clearance, the exchanges have been burning the midnight oil, sketching out a framework that will let us actually trade these beasts. I figured it’d be useful to jot down a quick‑fire primer so you know what to expect when the “options” button finally lights up on your screen.  

If you’re still fuzzy on the basics of options, hit the **Options** module first – you’ll thank me later.  

Bottom line: the theory behind commodity options mirrors equity options; the only extra ingredient is a dash of logistics. That’s what this chapter will chew over.

---

## 17.2 – Black 76  

First, a crucial point: **commodity options are options on futures**, not on the spot market.  

- In equity land, a call on Biocon has the *spot* price of Biocon as its underlying.  
- A Nifty option sits on the *spot* Nifty‑50 index.  

But look at crude oil. India has no physical spot market for barrels of black gold, so the underlying can’t be “spot oil”. Instead, the option’s base is the **Crude Oil Futures contract**. And those futures, in turn, reference the NYMEX price of crude.  

So you’re essentially dealing with a *derivative of a derivative* – like a matryoshka doll of financial contracts. In practice you won’t feel the extra layer; the only thing that changes is **how the premium is computed**.  

- Spot‑based options → Black‑Scholes model.  
- Futures‑based options → **Black 76** model.  

The distinction lies in the treatment of the continuously‑compounded risk‑free rate. I won’t dive into the calculus here, but remember this golden rule: **don’t throw commodity numbers into a regular Black‑Scholes calculator**. It will give you nonsense faster than a meme stock pump. Use a Black 76 calculator (plenty are free online) to get the correct premium and Greeks. 😊  

---

## 17.3 – Contract Specifications  

The exact rule‑book is still under construction, but the mock framework that MCX has shown us is pretty telling. Expect the rollout to start with **Gold options** and then creep out to other commodities, much like a shy kid testing the water before diving in. Here’s the sketch‑pad version of what we think will land on the exchange:

| Feature | Likely Specification |
|---|---|
| **Option Types** | Both **Calls** and **Puts** |
| **Lot Size** | Same as the corresponding futures lot (e.g., 1 kg gold = 1 lot) |
| **Order Types** | All the usual suspects – IOC, SL, SLM, GTC, Limit, Regular |
| **Exercise Style** | **European** – only exercisable on the expiry date |
| **Margins** | SPAN + Exposure margin for writers; full premium upfront for buyers. A “devilment margin” will also appear (see later). |
| **Last Trading Day (Gold)** | 3 days before the first tender day of the underlying futures |
| **Strikes** | One ATM strike, plus 15 strikes above and 15 below → **31 strikes total** |

### A quick refresher on “moneyness”

Equity traders are used to:

| Term | Meaning (Equity) |
|---|---|
| **ATM** (At‑the‑Money) | Spot ≈ Strike (only one strike qualifies) |
| **ITM** (In‑the‑Money) | Calls with strike **below** ATM; Puts with strike **above** ATM |
| **OTM** (Out‑of‑the‑Money) | Calls with strike **above** ATM; Puts with strike **below** ATM |

Commodity options will introduce a new cousin: **CTM (Close‑to‑Money)**.

- **ATM** – The strike *closest* to the settlement price on expiry.  
- **CTM** – The two strikes **above** and **two strikes below** the ATM strike (so five strikes total).  
- **ITM / OTM** – Same definitions as equity; CTM just sits in the middle of the spectrum.

### Settlement mechanics

For futures, the exchange uses the **Daily Settlement Price (DSP)** as the reference. The DSP on the expiry day becomes the reference for the option series as well.

**Example** – Suppose the DSP of a commodity is 100 and the strike grid moves in steps of 10:

| Category | Strikes |
|---|---|
| **ATM** | 100 |
| **CTM** | 80, 90, 100, 110, 120 |
| **OTM** | Calls > 100, Puts < 100 (worthless) |
| **ITM** | Calls < 100 (including 80, 90) & Puts > 100 (including 110, 120) |

#### What happens to CTM holders?

If you own a CTM option (say a **80 call**), you must submit an **explicit instruction** before expiry. That instruction “devolves” the option into a futures contract at the strike price – in this case, a long futures at 80. The instruction will likely be sent through your trading terminal, just like a normal order.

**If you fail to give the explicit instruction, the CTM option simply vanishes** – treated as worthless. So set a reminder; you don’t want your money to disappear faster than a pizza slice at a party.

#### ITM (non‑CTM) options settle automatically

Non‑CTM ITM options are automatically **devolved** into the equivalent futures position on expiry. However, you have a **contrary instruction** option: if you *don’t* want the automatic conversion (perhaps because taxes or transaction costs would make the trade unprofitable), you can tell the exchange “no thanks, I’ll pass”. If you don’t send a contrary instruction, the system will go ahead and convert the option for you.

Why would anyone skip a profitable‑looking ITM option?  
- **Tax inefficiency** – short‑term capital gains could be higher than the net payoff.  
- **Hidden charges** – stamp duty, brokerage, and the dreaded exchange fees can eat the margin.  

In those scenarios, the contrary instruction saves you from a loss‑making settlement.

---

## 17.4 – Devolvement into a Futures contract  

Alright, let’s talk cash. When an option turns ITM (including CTM) and the expiry clock hits zero, the option **devolves** into a futures position. Futures demand **margin** – the security deposit that keeps you from defaulting. But when you bought the option, you only paid the premium; you didn’t earmark margin for a future futures contract that might never materialise.  

Enter the **Devolvement Margin** – a pre‑emptive buffer that the exchange will ask you to fund *before* the option actually converts. Here’s the gist:

1. **Gap between expiries** – Commodity options expire a few days *before* the first tender day of the underlying futures. Example: Gold option expiry = 28 Nov 2017, first futures tender = 5 Dec 2017.  
2. **Sensitivity Report** – A few days prior, the exchange runs a “what‑if” engine to flag which strikes are likely to be ITM/CTM.  
3. **Margin Allocation** – For each flagged strike, the exchange posts a **devolvement margin** requirement:  
   - **50 %** of the required margin must be in your account **one day before option expiry**.  
   - The remaining **50 %** is due **on the expiry day** itself, just before the option morphs into a futures contract.  
4. **Profit offsets** – If your ITM option is already deep‑in‑the‑money, the unrealised profit can be used to offset part of the required margin. In other words, the deeper the option, the less cash you need to bring in. Conversely, CTM options (which are only marginally ITM/OTM) will attract a *higher* margin because the profit cushion is smaller.  

**Bottom line for traders:**  
- If you expect your commodity option to finish ITM, start shuffling cash into your account a few days before expiry.  
- The exact margin amount, expiry dates, and tender dates will vary commodity‑by‑commodity, so keep an eye on the exchange’s circulars.  

That’s the high‑level picture of how an option becomes a futures contract. As soon as the official contract specifications land, we’ll flesh out the nitty‑gritty (tick size, settlement formulas, etc.) and update this chapter. Stay tuned – the market is about to get a whole lot spicier!  

---

### Key takeaways from this chapter  

- Commodity options are **options on futures**, not on spot prices.  
- **Black 76** (not Black‑Scholes) is the correct pricing model; regular calculators will give you garbage.  
- Upon expiry, an ITM option **devolves** into an equivalent futures position.  
- **CTM** = the two strikes **above** and **below** the ATM strike (five strikes total).  
- Forgetting to send an **explicit instruction** for a CTM option = the option is treated as worthless.  
- An ITM holder can file a **contrary instruction** to avoid automatic conversion if taxes/fees make the trade unattractive.  

Happy trading, and may your margins be thin and your profits fat! 🎉