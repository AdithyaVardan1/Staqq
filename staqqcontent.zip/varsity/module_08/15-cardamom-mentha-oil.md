# 15. Cardamom & Mentha Oil  

**Source:** <https://zerodha.com/varsity/chapter/cardamom-mentha-oil/>

---  

##  

![Image](http://zerodha.com/varsity/wp-content/uploads/2017/01/M8-C15-Cartoon.png)

## 15.1 – Monsoon blues  

Picture this: a fresh‑out‑of‑college trader (that’s me) doing a love‑affair with ICICI Direct’s equity platform. One day, MCX—still a baby exchange—starts shouting “Come trade us, we have *spice*!” and rolls out workshops that smell more like a farmer’s market than a Wall Street conference.  

I was a curious cat, so I sat in one of those sessions, grabbed a free pen, and walked away convinced that I’d be a commodities wizard. “Why trade stocks when you can trade pepper?” I thought. Spoiler: I didn’t know *which* pepper.  

Fast forward to the day I marched into my broker’s office with a stack of documents that would make a visa officer weep. I was one of the first Bangalore‑based folks to open an MCX account—so fresh that the system took a *whole* 12 days to process it. Twelve days felt like an eternity; I kept refreshing my email like it was a stock ticker.

When the broker finally rang, “You’re good to go live tomorrow!” I actually called in sick at work. “I’m trading commodities,” I told my boss, as if I were about to cure the nation’s cholesterol problem.  

My heart was set on **pepper futures**—the reasoning is lost to the sands of time, but I’m pretty sure I was trying to emulate a Bollywood hero who always picks the *spiciest* thing. I went **long pepper, 10 lots** (that’s a 1‑metric‑tonne contract, in case you’re counting). I can’t remember the exact entry price, but it hovered around **₹7,500 per quintal**. In other words, I had just **bet the farm** (read: my entire trading account) on a spice that smelled like my mom’s kitchen.  

Predictably, the market turned into a **monsoon‑driven roller‑coaster**. Within two days pepper hit its 52‑week low, I poured in more cash (because panic is an excellent financial strategy), and the price kept diving like I’d slipped on a banana peel. My account went from “let’s make a fortune” to “let’s make a *fewer* fortunes” until it was **zero**.  

Post‑mortem time: I discovered that a **stellar monsoon in Kochi** was forecast, meaning a bumper pepper harvest. In other words, I’d been trading *without* knowing the most basic rule of agriculture—**rain matters**. I learned the hard way that you can’t ignore the clouds when you’re trading crops.  

The silver lining? As soon as I wiped out my account, pepper **bottomed out and sprinted to ₹12,500 per quintal**. If only my ego had the same elasticity!  

Lesson learned, and now we’ll dig into the *real* rain‑related stuff so you don’t end up with a pepper‑flavoured bank statement.

---

## 15.2 – Understanding Rainfall  

India’s economy has been on a diet: decades ago agriculture was **30 %** of GDP, now it’s a lean **≈ 10 %**. Still, agriculture is the **biggest employer**, so every new policy looks a bit like a populist love letter to the farmer.  

Below is a quick snapshot (RBI data, publicly available back to the 1950s) showing sector contributions over time:

![Image](http://zerodha.com/varsity/wp-content/uploads/2017/01/Image-1_economy.png)

The chart tells a familiar story: **services** (think software, consulting, Netflix binges) have been marching up, while **agriculture** has been sliding down. Yet, with **two‑thirds of India’s arable land being rain‑fed**, the sector is still at the mercy of the sky.

India has **two primary monsoon spells**:

| Monsoon | When? | What part of the country? |
|--------|-------|---------------------------|
| **South‑West Monsoon** (the *main* rain) | June – September (sometimes spilling into Oct) | Starts in the south‑west, spreads to central India |
| **North‑East Monsoon** | December – March | Hits the north‑east, the Himalayas, western states, and most of Tamil Nadu |

I’m no meteorologist, so I won’t go into the physics of why the wind changes direction; just remember that the **calendar decides the planting calendar**.

### Kharif vs. Rabi – the two crop families  

* **Kharif (Monsoon) crops** – sown **just before** the south‑west monsoon (late May/early June) and harvested **after** the rains (around Oct). Think **pulses, millets, rice, urad, moong, cotton**.  
* **Rabi (Winter) crops** – sown at the *onset of winter* (around Oct‑Nov) and harvested **by end‑April**. Think **wheat, gram, coriander, mustard, oats**.  

Rice and wheat together make up **≈ 40 %** of India’s food‑grain production, so their sow‑harvest cycles are practically national holidays.  

Progress of sowing/harvest is reported daily by agencies and shown in newspapers. A couple of classic examples:

*Rabi progress chart*  

![Image](http://zerodha.com/varsity/wp-content/uploads/2017/01/Image-2_Rabi.png)

*Kharif progress chart*  

![Image](http://zerodha.com/varsity/wp-content/uploads/2017/01/Image-3_karif.png)

If you’re serious about agri‑trading, you’ll start treating these charts like a Netflix binge‑watch schedule—*always* know what’s being harvested and when.  

### The MCX agri menu  

MCX currently offers futures on the following agricultural commodities:

- Cardamom  
- Castor Seed  
- Cotton  
- Crude Palm Oil  
- Kapas  
- Mentha Oil  

Out of these, **Cardamom** and **Mentha Oil** win the “most liquid” award—so they’re the low‑friction playground for beginners. Also, remember: **Indian agri futures stop trading at 5:00 PM** (no after‑hours drama).

---

## 15.3 – Cardamom  

Cardamom is the *queen of spices* grown mainly in **Karnataka & Kerala**. The Indian variety is called **“Small Cardamom.”** India is the **second‑largest producer** but the **largest consumer**; Guatemala tops production charts (mostly for export).  

Why do we love it? It flavors everything from **sweet dishes** to **mouth‑freshening gums**, and it even moonlights as a **skin‑care & dental‑care** ingredient—because why not make your toothpaste smell like biryani?  

### What drives Cardamom prices?  

| Driver | Why it matters |
|--------|----------------|
| **South‑west monsoon** | A good monsoon → better yields → lower prices (supply up). |
| **Quality** (flavour, colour, size, aroma) | Premium quality fetches a premium price—think “farm‑to‑fork” but “farm‑to‑futures.” |
| **Pest attacks** (inset) | Insects love cardamom; a bad pest season can shrink supply dramatically. |
| **Stock levels** (India vs. Guatemala) | Global inventories can buffer a weak Indian harvest. |
| **Domestic consumption** | Generally stable, but festival spikes (e.g., Diwali sweets) can add a seasonal bump. |

A recent news bite (I saw it this morning while sipping chai) summed it up nicely:

![Image](https://zerodha.com/varsity/wp-content/uploads/2017/01/Image-7_cardamom-news.png)

### Contract specifications  

| Parameter | Detail |
|-----------|--------|
| **Price Quote** | Per kilogram |
| **Lot size** | 100 kg |
| **Tick size** | ₹0.10 |
| **P&L per tick** | ₹10 |
| **Expiry** | 15th of every month |
| **Delivery unit** | 100 kg |

Notice there is **no “mini” cardamom contract**—you get the full‑flavour lot or nothing.

#### Example: Feb 2017 contract  

Snap quote (Feb 2017):

![Image](https://zerodha.com/varsity/wp-content/uploads/2017/01/Image-4_Cardamom-feb.png)

*Price*: **₹1,564 / kg**  
*Contract value*: 100 kg × ₹1,564 = **₹156,400**  

**NRML margin** (overnight) looks like this:

![Image](https://zerodha.com/varsity/wp-content/uploads/2017/01/Image-5_Cardamom.png)

*Margin*: **₹16,237** → roughly **10.5 %** of the contract value.  

**MIS margin?** Not available. Agri futures are **highly volatile** and hit circuit limits often, making same‑day unwind risky. So you’ll trade **NRML** even for intraday moves—think of it as a “day‑trade with an overnight safety net.”

#### Contract roll‑over  

Every month MCX lists a **six‑month forward series** (e.g., Jan 2017 launches June 2017 contracts). The contract lives until the **15th of its month**; after that, liquidity shifts to the next month.  

**Rule of thumb:** *Trade the current‑month contract for best liquidity.*  

When I wrote this (17 Jan 2017), the **Feb 2017** contract was the live one; the Jan contract had just expired on the 15th.

---

## 15.4 – Mentha Oil  

Mentha (the fresh‑smelling herb you find in every Indian kitchen) is distilled and filtered to produce **Mentha Oil**. MCX lists a futures contract on this oil, which is a key ingredient for **food, pharma, perfumery, and flavouring** industries.  

Mentha oil isn’t just an Indian story—it’s shipped to the **U.S., China, Singapore**, so its price **reacts to the USD‑INR exchange rate** in addition to the usual suspects: rainfall, pest pressure, and acreage.

### Contract specifications  

| Parameter | Detail |
|-----------|--------|
| **Price Quote** | Per kilogram |
| **Lot size** | 360 kg |
| **Tick size** | ₹0.10 |
| **P&L per tick** | **₹36** (the only Indian futures where a single tick feels like a mini‑lot) |
| **Expiry** | Last business day of the month |
| **Delivery unit** | 360 kg |

### Example: 2017 contract  

Snap quote:

![Image](http://zerodha.com/varsity/wp-content/uploads/2017/01/Image-8_Mentha-oil.png)

*Price*: **₹1,023.2 / kg**  
*Contract value*: 360 kg × ₹1,023.2 = **₹368,352**  

**NRML margin** (overnight) appears as:

![Image](http://zerodha.com/varsity/wp-content/uploads/2017/01/Image-9_margin.png)

*Margin*: **₹29,893** → about **8.5 %** of the contract value.  

Again, **no MIS margin** for the same volatility‑circuit‑limit reasons we saw with cardamom.

### Rolling strategy  

Mentha contracts are also listed **five months ahead**. The same advice applies: **stick to the current‑month contract** for the deepest order‑book and tightest spreads.

---

### Key takeaways from this chapter  

- **Agriculture contributes ~10 % of India’s GDP** but still employs the largest share of the workforce.  
- **Rainfall is the lifeblood** of Indian farming; two monsoons dominate the calendar.  
- **South‑west (principal) monsoon** drives **Kharif** crops (e.g., rice).  
- **North‑east monsoon** drives **Rabi** crops (e.g., wheat).  
- MCX agri futures **trade only until 5:00 PM**—no midnight oil for you.  
- **India** is the **largest consumer** and the **second‑largest producer** of **cardamom** (behind Guatemala).  
- Cardamom’s **supply‑demand** dynamics are relatively **stable**, but watch monsoon and pest news.  
- **MIS margin isn’t offered** on Indian agri futures because of **high volatility & circuit‑breaker hits**.  
- **Mentha oil** is a distilled product of **mint leaves**, used globally and sensitive to **USD‑INR moves**.  

Now you’ve got the rain‑check on cardamom and mint—go ahead, trade smart, and keep an eye on the clouds. 🌦️📈