# 6.   EUR, GBP, and JPY  

**Source:** <https://zerodha.com/varsity/chapter/eur-gbp-and-jpy/>

---  

## 6.1 – The other currency pairs  

We’ve been chewing over the good old **USD‑INR** pair for a while now, so it’s time to invite the other three cousins to the party: **EUR‑INR, GBP‑INR, and JPY‑INR**.  The mechanics are basically the same – think of it like knowing how the Nifty‑50 futures work; once you’ve cracked that, the Bank Nifty is just a slightly different flavor of the same ice‑cream.

So, in this first half we’ll sprint through the contract specs of these three “crosses”.  In the second half we’ll dip our toes into some classic technical‑analysis tricks (because who doesn’t love a good chart pattern with a side of popcorn?).  After that, we’ll close the currency chapter and roll right into commodities.  

Ready? Let’s roll the dice.

![Cartoon](http://zerodha.com/varsity/wp-content/uploads/2016/08/M8-Cartoon1.png)

### EUR‑INR  

Globally the **EUR‑USD** is the second‑most‑traded FX pair, but India still hasn’t got a futures contract for that exact duo.  The RBI has given the green light for the “crosses”, so sooner or later we’ll see **EUR‑USD** and **GBP‑USD** join the party.  In the meantime, we have **EUR‑INR** to keep our forex cravings satisfied.

The Euro, as you probably know, is the money of the **European Union** – a single currency backed by a whole bunch of economies instead of just one.  That makes it a little more diversified than a one‑man band.

The **EUR‑INR** futures contract mirrors the **USD‑INR** contract almost lock‑step.  The only thing that changes is the lot size: instead of $1,000 we trade €1,000.

| Parameter | EUR‑INR |
|-----------|----------|
| **Lot size** | €1,000 |
| **Underlying** | Spot rate of 1 Euro in INR |
| **Tick size** | 0.0001 |
| **Contract months** | Mar, Jun, Sep, Dec |
| **Price multiplier** | 1 |

Because the lot size is larger in euro‑terms, the margin looks a tad higher.  Here’s a snapshot of the live futures board (as of the day of writing):

![EUR‑INR Futures board](http://zerodha.com/varsity/wp-content/uploads/2016/08/Image-1_eur-inr.png)

The last‑traded price is **74.8950**.  So the contract value is simply:

```
Contract Value = Lot size × Price
                = 1,000 × 74.8950
                = 74,895.0 INR
```

If the margin requirement is roughly **2.5 %**, you’d need about **₹1,870** in your account (you can always double‑check with Zerodha’s margin calculator for the exact figure).

![Margin calculator view](http://zerodha.com/varsity/wp-content/uploads/2016/08/Image-2_margin.png)

That margin is a shade higher than for **USD‑INR**, but still peanuts when you compare it to what you need for equity derivatives.

![Cartoon 2](http://zerodha.com/varsity/wp-content/uploads/2016/08/M8-Cartoon2.png)

### GBP‑INR  

If **USD‑INR** is the rock‑star, **GBP‑INR** is the reliable side‑kick – the second‑most‑traded currency contract on Indian exchanges.  Everything looks familiar, except for two things: the underlying is now the **spot rate of 1 British Pound in INR**, and the lot size is **£1,000**.

When the futures were trading at **89.3450** (5 Aug 2016), the contract value works out to roughly **₹89,345**.

The required margin is a bit higher than for the Euro pair, reflecting the higher lot‑size value:

![GBP‑INR Margin](http://zerodha.com/varsity/wp-content/uploads/2016/08/Image-3_gbp-inr.png)

Fun fact: in the global FX arena the **GBP‑USD** pair is nicknamed the **“Cable”** (back when the trans‑Atlantic cable first carried exchange rates).  So if a trader says “I’m short Cable”, he’s short **GBP‑USD**.

![Cartoon 3](http://zerodha.com/varsity/wp-content/uploads/2016/08/M8-Cartoon3.png)

### JPY‑INR  

The **JPY‑INR** contract is the quirky cousin of the bunch.  First off, the lot size jumps from 1,000 to **100,000** (yes, you read that right).  Second, the underlying isn’t “1 Yen in INR”, it’s **100 Yen in INR**.  In other words, the quoted price is the rupee cost for a hundred yen.

Here’s the board snapshot:

![JPY‑INR Futures board](http://zerodha.com/varsity/wp-content/uploads/2016/08/Image-4_JPYINR.png)

If the price reads **66.2750**, that means **₹66.2750** buys you **100 Yen**.  Because the lot size is 100,000 (i.e. 1,000 × 100 Yen), the contract value is:

```
Contract Value = (Lot size × Price) / 100
                = (100,000 × 66.2750) / 100
                = 66,275 INR
```

One pip (or tick) move in this contract is worth **₹2.5** – the same tick‑value you see for the other INR‑crosses.

The margin sits at about **₹2,808**, which is roughly **4.2 %** of the contract value – the highest margin among the four pairs, likely because the yen contract can be a bit more jittery (lower liquidity, higher volatility).

![JPY‑INR Margin](http://zerodha.com/varsity/wp-content/uploads/2016/08/Image-5_jpyinr.png)

#### Spread contracts

All four currency pairs have spread contracts across all expiry months.  NSE’s website shows the spread board, but apart from **USD‑INR** the spreads are pretty thin‑liquidity, meaning you might get stuck with a wide bid‑ask.

![Spread board](http://zerodha.com/varsity/wp-content/uploads/2016/08/Image-6_spreads.png)

#### Liquidity ranking – where to park your capital?

If you were to line up the contracts purely by how easy it is to get in and out, the hierarchy would look something like this:

1. **USD‑INR Futures**  
2. **USD‑INR ATM Options**  
3. **GBP‑INR Futures**  
4. **EUR‑INR Futures**  
5. **JPY‑INR Futures**

Assuming you now have the basics of currency trading under your belt, we can move on to the next piece of the puzzle: **building a simple trading approach**.

---

## 6.2 – The test for seasonality  

Everyone loves a good “seasonal story”.  “USD‑INR always drops in December”, “INR spikes the week before the RBI meeting”, etc.  Many traders actually **base positions on these myths** without ever checking the data.  So we did a reality‑check on the **USD‑INR spot series**.

> **⚠️ Warning**  
> This part gets a little nerdy.  If you just want the TL;DR, the answer is **no, there’s no reliable seasonality** in the pair.  Jump to the next section if you’re impatient.  If you love stats, stick around – I’ll keep the math light and the jokes heavy.

*(Contributed by our friend Prakash – any questions, ping him at [email protected].)*

### What’s the test?

We used the **Holt‑Winters** methodology – a time‑series forecasting technique that splits a series into three parts:

| Component | What it captures |
|-----------|------------------|
| **Level** | The overall average (think “where are we now?”) |
| **Trend** | The direction over time (up, down, flat) |
| **Seasonality** | Repeating patterns (monthly, weekly, etc.) |

Each component can be modelled **additively** (you just add them) or **multiplicatively** (you multiply them).  The details aren’t crucial; just know we built two models:

* **Model 1** – **No seasonality** (only level & possibly trend).  
* **Model 2** – **Seasonality included**.

We then compared the prediction errors of the two models using a **Chi‑Square test**.  If Model 2 is statistically better, we declare a seasonal pattern; otherwise, we chalk it up to random noise.

### Weekly seasonality check  

| Model | Best configuration | Coefficients |
|-------|-------------------|--------------|
| **Model 1** (no seasonality) | (M, N, N) | 0.9999 (level) |
| **Model 2** (with seasonality) | (M, N, M) | 0.7 (level) & 0.0786 (seasonal) |

Interpretation: Model 1 says the next week’s price is basically the same as this week’s – a classic **random‑walk**.  Model 2 tries to force a seasonal swing, but the Chi‑Square test tells us the two models are **identical in accuracy** (100 % probability they’re the same).  In plain English: **no weekly seasonality**.

### Monthly seasonality check  

| Model | Best configuration | Coefficients |
|-------|-------------------|--------------|
| **Model 1** | (A, N, N) | 0.9999 (level) |
| **Model 2** | (A, N, A) | 0.9999 (level) & 0.0001 (seasonal) |

Here Model 2 gets a *tiny* edge – about **20 %** chance it’s better.  In statistics we usually demand **≥95 % confidence** before we shout “Seasonality!”.  So, again, the verdict is **no meaningful monthly seasonality**.

The data set spans the last **8 years** of spot USD‑INR rates, sourced from the RBI’s website.

> So the next time someone says “USD‑INR always slides before Christmas”, you can smile, sip your drink, and say, “That’s a nice story, but the numbers say otherwise.” ☺

---

## 6.3 – Classic TA  

Imagine you’re doing a fundamental deep‑dive on **Hindustan Unilever**: you read the annual report, check margins, compare peers, maybe even build a DCF model.  That’s fairly straightforward for a stock.  For a currency pair like **USD‑INR**, the fundamentals are **macro‑economics** on both sides of the globe – US Fed policy, Indian RBI moves, trade balances, geopolitical events, you name it.  You’d need a PhD in economics *and* a trader’s gut to synthesize all that into a price view.

Because that’s a tall order, most forex (and commodity) traders gravitate toward **Technical Analysis (TA)**.  The core premise? **“Price discounts everything.”**  All the macro‑news, central‑bank whispers, and market sentiment are already baked into the chart, so you just read the patterns.

If you’re new to TA, give the **TA module** a quick read – it’s the cheat‑sheet for all chart‑lovers.

Below are a couple of classic candlestick setups we’ve spotted on the Indian currency futures board.

### Piercing pattern on USD‑INR  

![Piercing pattern](http://zerodha.com/varsity/wp-content/uploads/2016/08/Image-7_TA1.png)

The two circled candles form a **Piercing Pattern** – a bullish reversal signal.  In our example, a long position was entered and the trade rode the wave without ever hitting the stop‑loss.  Classic “buy the dip” with a smile.

### Bearish Marubozu on GBP‑INR  

![Bearish Marubozu](http://zerodha.com/varsity/wp-content/uploads/2016/08/Image-8_TA2.png)

A **Bearish Marubozu** (big body, no wicks) screams “sell‑off”.  Shorting the pair after this candle would have been a logical move, expecting the price to keep falling.

The universe of setups is endless – from double tops to hammer‑in‑the‑middle.  A common misconception is that you need a *different* TA toolkit for currencies or commodities.  **False!**  The same chart‑reading principles apply whether you’re looking at a stock, a gold future, or a yen contract.

That wraps up our currency chapter.  Up next: **Commodity trading** – where we’ll talk about oil, gold, and why you might want to own a piece of a coffee bean.

---

### Key takeaways from the chapter  

- **EUR‑INR** underlying = spot rate of **1 Euro** in INR; lot size = **€1,000**.  
- **GBP‑INR** underlying = spot rate of **1 Pound** in INR; lot size = **£1,000**; it’s the **2nd‑most‑traded** currency contract in India.  
- Internationally, **GBP‑USD** is nicknamed the **“Cable”**.  
- **JPY‑INR** has the **highest margin requirement** among the four pairs (≈4.2 %), likely due to its higher volatility and lower liquidity.  
- JPY‑INR lot size = **100,000** (i.e., 1,000 × 100 Yen); underlying = rate of **100 Yen** in INR.  
- **No reliable seasonality** (weekly or monthly) in the **USD‑INR** pair – those Christmas‑time myths are just folklore.  
- **Technical Analysis** works just as well on currencies as it does on stocks; you don’t need a secret “FX‑only” playbook.  

Happy trading, and may your spreads be tight and your pips be plentiful! 🚀