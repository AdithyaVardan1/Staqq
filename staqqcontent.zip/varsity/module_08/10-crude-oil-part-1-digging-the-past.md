# 10. Crude Oil (Part 1), Digging the Past  

**Source:** <https://zerodha.com/varsity/chapter/crude-oil-part-1-digging-the-past/>

---  

##  

![Cartoon](http://zerodha.com/varsity/wp-content/uploads/2016/10/M8-C10-cartoon.png)

## 10.1 – The Commodities Superstar  

If I had to nominate a single international commodity that can give you the same roller‑coaster drama you see in Hollywood‑style stock‑market movies, it would be **crude oil**. Why? Just stare at the chart below and let the oil‑price plot twist sweep you off your seat.  

![10‑year Crude Oil chart](http://zerodha.com/varsity/wp-content/uploads/2016/10/Image-1_10-year-crude-oil.png)

See that meteoric climb to **$140 a barrel**, followed by an abrupt nosedive, a brief comeback to the $110‑ish “almost‑there” zone, and then a merciless plunge below **$30**? It’s a full‑blown emotional thriller—fear, greed, euphoria, despair—all in one tidy line graph.  

And because oil is an *international* commodity, the cast includes hundreds of thousands of traders from every continent, each adding a sprinkle of chaos to the mix.  

So, what’s the backstage story? Why did oil tumble from a lofty **$115** to a pitiful **$28**? What triggered the panic‑selling? Where does the barrel stand today, and where might it be heading tomorrow? To answer those questions we need a time‑machine set to **mid‑2015** and a quick flash‑back to the events that shaped 2014‑15.

That’s exactly what we’ll do in this chapter: rewind, dust off the old spreadsheets, and see how the oil world looked when everyone thought “the worst is behind us”.  

---

## 10.2 – The Crisis Revisited  

From a lofty **$110+** per barrel in **January 2014** to a gut‑wrenching **$28** in **January 2016**, Brent crude experienced perhaps the most dramatic five‑year price slide on record.  

The crash made a few oil‑rich corporates and even a couple of sovereign wallets grin (think “hey, our subsidies just got cheaper!”), but it *devastated* economies that live off oil exports. Nobody saw it coming; even the most pessimistic analysts thought the dip would be *moderate*, not a **75 %** plunge that would make even a seasoned day‑trader choke on his coffee.  

Is that the bottom? Your guess is as good as mine. The crash was so ferocious that the idea of “bottom‑out” feels like looking for a needle in a haystack that’s already on fire.  

### What Went Wrong?  

To diagnose the ailment we must first learn a bit of **oil 101**—the basics of who makes the oil, who drinks it, and why they sometimes argue over the bill.  

**Supply side:** Oil‑rich nations pump several **million** barrels every day and ship them to the biggest consumers: the United States, China, India, and the EU. The producers fall into two camps:

| Camp | Who’s in it? |
|------|--------------|
| **OPEC** (Organization of the Petroleum Exporting Countries) | Saudi Arabia, Qatar, Kuwait, UAE, etc. |
| **Non‑OPEC** (the “I‑don’t‑join‑the‑club” crowd) | Brazil, Canada, Russia, Mexico, Norway, … |

Together, OPEC and non‑OPEC churn out roughly **90 million barrels per day**. The graph below shows the split.  

![Production split OPEC vs Non‑OPEC](http://zerodha.com/varsity/wp-content/uploads/2016/10/Image-2_Production-data.png)

#### The Trigger  

Every country has its own **breakeven price**—the barrel price needed to cover the cost of extraction. If the market price drops below that, the country starts losing money on each barrel, and the national budget begins to look like a sandcastle at high tide.  

Below is a *representative* breakeven table for OPEC members (the exact numbers vary by source, but the story stays the same).  

| Country | Approx. Breakeven ($/bbl) |
|---------|--------------------------|
| Saudi Arabia | 20‑25 |
| Iran | 30‑35 |
| Iraq | 15‑20 |
| Venezuela | 25‑30 |
| Nigeria | 30‑35 |

When oil was hovering above **$100**, everyone was sipping oil‑price cocktails. Then three seismic events knocked the bar off the table:  

1. **American Shale Boom** – Thanks to hydraulic fracturing (fracking) and horizontal drilling, the U.S. unlocked cheap “shale oil” from sedimentary rock. By 2014, U.S. shale production was enough to *replace* a sizable chunk of OPEC’s traditional exports to the U.S. market. Think of it as an unexpected understudy stealing the spotlight.  

2. **Lack of Coordinated Cuts** – With shale flooding the market, OPEC tried to *cap* output to prop up prices, but convincing non‑OPEC producers to voluntarily *shut in* wells proved harder than getting a cat to take a bath. Production cuts are expensive (you still pay staff, maintain rigs, etc.), so many countries kept pumping.  

3. **China’s Slow‑down** – China, the world’s biggest oil importer, hit the brakes on its growth engine. Less steel, less construction, less demand for crude. In 2013 China actually overtook the U.S. in oil imports, but by 2015 the growth curve had flattened, pulling the global demand gauge downwards.  

Add a fourth ingredient: **massive short positions** on oil futures. Traders betting on a price fall piled in, turning a price dip into a *price avalanche*.  

#### The Dollar‑Oil Tango  

When oil prices tumble, the **U.S. dollar usually strengthens**—especially against emerging‑market currencies. Why? A cheaper barrel means the U.S. imports *less* oil, which helps its current‑account deficit. Conversely, when oil spikes, the dollar weakens because the U.S. has to spend more on imports.  

Remember 2008? When Brent hit **$148**, the dollar was trading around **1.6 EUR/USD**. The inverse relationship is a classic textbook example, and it still holds water today.  

### The Russian Episode  

Russia is the heavyweight *non‑OPEC* champ, contributing almost **40 %** of its total export basket from oil. When oil prices nosedived, the Russian economy felt the squeeze hard. Three intertwined problems emerged:  

| Problem | Why it hurts Russia |
|---------|--------------------|
| **Oil‑price dependence** | Russia needs roughly **$105‑$107** per barrel to balance its federal budget. At **$50**, the budget gap widens like a bad haircut. |
| **Ruble weakness** | Falling oil revenues weakened the ruble, prompting the Central Bank to hike rates by **7.5 %** overnight in 2015—an emergency “cough‑up” to defend the currency. |
| **Sanctions (Crimea curse)** | Western sanctions limited Russia’s access to foreign capital just when it needed cash the most. Combine that with the Syrian quagmire, and you’ve got a perfect storm. |

The result? A looming recession risk that felt more like a *financial coma* than a mild nap.  

### The India Macro Angle  

On the surface, low oil prices look like a **gift** for India, a net oil importer that spends about **two‑thirds** of its total import bill on crude. Cheaper barrels mean:  

* **Lower fiscal deficit** (less subsidy money out the door)  
* **Easing of inflation** (fuel‑price driven CPI falls)  
* **Potential interest‑rate cuts** (central bank gets breathing room)  

All very welcome in a country juggling slowing growth and fiscal pressures.  

But there’s a *flip side*. India’s export markets—UAE, Saudi Arabia, Kuwait, the U.S., China—are themselves oil‑import dependent. When their oil bills shrink, they spend less on everything else, including Indian goods.  

A quick look at RBI data for **Oct 2014** shows the dual effect:  

* **Oil import bill** fell **19 % YoY** (thanks, cheap oil)  
* **Exports** dropped **5 % YoY** (because our customers are pinching pennies)  

And the market felt it. On **6 Jan 2015**, the NSE Nifty slipped **≈255 points (≈3 %)**, causing traders to scramble for the nearest chai stall.  

### Impact on Indian Companies  

State‑run oil marketing firms—**HPCL, BPCL, IOC**—are the immediate beneficiaries of a cheap‑crude environment. Lower input costs ease working‑capital pressures, letting them pay down debt.  

* BPCL and HPCL have already retired **>50 %** and **≈30 %** of their short‑term borrowings respectively over the past two years.  

If crude stabilises around **$50 per barrel**, those balance‑sheet clean‑ups will keep going, and profitability should improve.  

### Is This the End?  

Bottom‑line (pun intended): the future hinges on **supply vs. demand**. As Saudi Prince Al‑Waleed Bin Talal quipped, “If supply stays where it is and demand stays where it is, there’s little hope for prices to bottom out.”  

Two recent twists add extra drama:  

* The **U.S. lifted its 40‑year ban on oil exports** (yes, the ban existed), flooding the market with even more supply.  
* **OPEC** finally agreed in **September 2016** to *cut* production—a historic first since the 2014 crash. (Read the Bloomberg article for the juicy details.)  

American shale is still a wild card. The key questions are:  

* Are shale producers over‑leveraged?  
* Are their reserve estimates overly optimistic?  

The market will eventually sort those out, and the answers will reverberate through oil prices.  

So, is this the bottom of the crash? Your guess is as good as mine—just like trying to guess the ending of a thriller you haven’t watched yet.  

> **Note:** Unlike previous Varsity chapters, this one deliberately **omits a tidy “Key Takeaways” box**. I wanted to give you the raw, unfiltered story of what happened to crude oil. It may feel like a slice of history that will fade, but understanding it equips you to spot the next plot twist.  

*P.S.* All the data and narratives above were compiled from the special report **“Oil Crisis”** published by the *Dalal Street Investment Journal*, authored by yours truly.  

---  