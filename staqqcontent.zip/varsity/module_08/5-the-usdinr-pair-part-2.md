# 5. The USD‑INR Pair (Part 2)

**Source:** <https://zerodha.com/varsity/chapter/the-usd-inr-pair-part-2/>

---  

## 5.1 – Futures Calendar Spread  

Let’s start with a little reminder from the futures‑101 class: **all else equal a futures contract should sit a bit above the spot price**. Why? Because you have to pay the cost of carry – basically the interest you’d earn if you locked the money today and waited until delivery. We covered the exact formula in the Futures module, so I’ll spare you the calculus and jump straight to the juicy part: arbitrage.  

### Quick‑and‑dirty arbitrage sketch  

Imagine the spot price of a currency is **100** and the “fair” futures price (what the pricing model tells you) is **105**. The *no‑arbitrage spread* is just the difference:  

```
105 – 100 = 5
```  

Now suppose the market is being a little sloppy and the futures is quoted at **98** instead of its fair 105. The actual spread you see is **7** (105‑98). That extra 2 points is a free‑lunch waiting to be snatched.  

![Cartoon illustration of arbitrage](http://zerodha.com/varsity/wp-content/uploads/2016/07/M8-C5-cartoon-1.png)  

**How to cash in?**  
1. **Buy** the under‑priced future at 98.  
2. **Sell** the spot (or a spot‑linked instrument) at 100.  

When the contract expires, the future and spot must converge to the same settlement price, so you pocket the 2‑point spread.  

If the future is *over‑priced* (say it trades at 112 while the fair value is 105), you do the opposite: sell the future, buy the spot, and wait for convergence. The mechanics are identical – just the direction flips.  

### Why can’t we do this with USD‑INR spot?  

In theory, the same spot‑future arbitrage should work for the USD‑INR pair. In practice, retail traders can’t actually get into the *spot* market for Indian rupees – it’s a bank‑only playground. So the classic “buy spot, sell future” trick is off‑limits for most of us.

### Enter the **calendar spread**  

Instead of chasing a spot‑future mismatch, we look at the mismatch **between two futures contracts that expire on different dates**. This is called a *calendar spread* (or *time‑spread*).  

All else equal, the longer‑dated future should sit at a premium over the nearer‑dated one because you’re paying carry for a longer period. For example, an August USD‑INR future is normally higher than a July contract. That “normal” gap is what the market expects.  

But sometimes the gap widens or narrows beyond expectations – that’s our opportunity.

#### Real‑world numbers (as of the writing)

| Contract | Quote |
|----------|-------|
| July 2023 USD‑INR Future | **67.3075** |
| August 2023 USD‑INR Future | **67.6900** |

**Spread** = 67.6900 − 67.3075 = **0.3825**  

Suppose your analysis tells you that the “fair” spread should be **0.2000**, not 0.3825. The *mis‑pricing* is therefore  

```
0.3825 – 0.2000 = 0.1825
```  

That 0.1825 is the profit you could capture per unit of spread.

#### How to lock it in  

- **Buy** the July future at 67.3075 (the “long” leg).  
- **Sell** the August future at 67.6900 (the “short” leg).  

That’s a **Future Bull Spread** (long near‑month, short far‑month).  
The opposite – short July, long August – is a **Future Bear Spread**.

Once you have the spread set up, you watch it like a toddler waiting for a candy drop. You’ll close the position when the spread contracts back toward your target (0.2000 or lower). You make money when any of the following plays happen:

| Situation | Why it works |
|-----------|--------------|
| July price **rises** while August price **falls** | The spread shrinks from both sides. |
| July rises, August stays flat | The numerator of the spread (July) grows. |
| Both rise, but July rises **faster** | The differential narrows. |
| August falls **faster** than July | The denominator drops quicker, narrowing the spread. |
| July stays flat, August falls | The spread shrinks from the short side. |

Will it converge? Will it converge *when* you think it will? That’s the million‑dollar (or rather, million‑rupee) question. The answer lies in how well you understand the historical behavior of that particular spread. That’s where **back‑testing** comes in – a whole rabbit‑hole we’ll save for another night (or another chapter).  

For now, let’s just appreciate that you can **trade the spread directly from your terminal**. No need to place two separate orders and pray the market doesn’t move in the meantime.

---

## 5.2 – Executing the Spread  

Imagine you could click a single button and *buy the spread* instead of fiddling with two orders. That would be nice, right? Because placing two separate orders carries **execution risk** – the market could move between your buy and sell, erasing the spread advantage you thought you had.

### The “one‑click” solution for Zerodha fans  

If you’re on Zerodha, you have the **NEST Trader** platform (and eventually Pi and Kite) that lets you treat a calendar spread as a single tradable instrument. Below is a step‑by‑step, screenshot‑rich tour of how to do it.

#### 1️⃣ Setting up the market watch  

![Market watch screenshot – selecting spread](http://zerodha.com/varsity/wp-content/uploads/2016/07/Image-1_load.png)  

- **Drop‑down #1 – “Spread”**: tells the system you want a spread instrument, not a plain future.  
- **Drop‑down #2 – “CDS”**: selects the *Currency Derivatives* segment.  
- **Drop‑down #3 – “FUTCUR”**: narrows it down to *future* spreads (as opposed to option spreads).  
- **Drop‑down #4 – “USDINR”**: picks the USD‑INR pair.  

You’ll see a long list of available spreads (e.g., Sep‑Oct, Oct‑Nov, etc.). Pick the **July‑August** spread – that’s the one we’re talking about.

#### 2️⃣ Loading the spread  

Hit *Enter* (or click *Load*) and the screen swaps to a single line showing the spread’s live price.

![Spread price view](http://zerodha.com/varsity/wp-content/uploads/2016/07/Image-2_Spread.png)  

The **last traded price** you see is the market’s current valuation of the July‑August spread.

> **Side note:** You might wonder why the quoted spread isn’t exactly 0.3825 (our manual calculation). Good catch! The discrepancy can be chalked up to a few things:
> * The market data you’re looking at is a *snapshot*; the bid/ask can be a hair different from the mid‑price used in textbook examples.  
> * Liquidity on the spread instrument can be thin, causing a small “price‑impact” premium.  
> * Or simply: the market thinks the spread is a tad mis‑priced (hey, we’re not perfect!).  

#### 3️⃣ Understanding the two‑leg pricing  

Take a look at the full market watch that has both individual futures and the spread together.

![Market watch with futures and spread](http://zerodha.com/varsity/wp-content/uploads/2016/07/Image-3_spread.png)  

Now, if you wanted to **manually** create a **Future Bull Spread** (long July, short August), you’d do:

- **Buy July** at the *Ask* price = **67.3100**  
- **Sell August** at the *Bid* price = **67.6775**  

Resulting spread: **67.6775 − 67.3100 = 0.3675**  

Conversely, a **Future Bear Spread** (short July, long August) would be:

- **Buy August** at *Ask* = **67.6850**  
- **Sell July** at *Bid* = **67.3075**  

Resulting spread: **67.6850 − 67.3075 = 0.3775**  

So you have **two** possible spread values depending on which leg you’re the aggressor on. The market’s quoted spread (≈ 0.3700) is roughly the **average** of those two numbers:

```
(0.3675 + 0.3775) / 2 = 0.3725  ≈ 0.3700
```  

Minor differences arise from the same bid/ask‑lag we mentioned earlier.

#### 4️⃣ Placing the order  

With the spread instrument loaded, you can now treat it like any other security:

- Click the row to highlight it.  
- Press **F1** to buy, **F2** to sell (or use the on‑screen buttons).  

A pop‑up order window appears, pre‑filled with the spread symbol, price, and lot size.

![Buy window for spread](http://zerodha.com/varsity/wp-content/uploads/2016/07/Image-4_Buy.png)  

Just adjust the quantity if you need more (or fewer) contracts, hit **Submit**, and voilà – you’re long or short the spread with a single order. No more juggling two tickets, no more worrying about the market moving between them.  

That’s it. Simpler than ordering a pizza, right? 🍕

---

## 5.3 – USD‑INR Stats  

Numbers are boring… *unless* you dress them up with a story. Let’s dig into some hard‑core stats on the USD‑INR pair, because a trader who can’t read a chart is like a bartender who can’t pour a drink.

### 8‑year price trajectory (July 2008 – July 2016)

![USD‑INR 8‑year chart](http://zerodha.com/varsity/wp-content/uploads/2016/07/Image-5_USD-INR.png)  

The dollar’s been on a steady climb against the rupee. Not a surprise – our economy has been more “couch‑potato” than “marathon runner” in those years. 😅

### Daily returns – what’s the roller‑coaster look like?

![Daily returns plot](http://zerodha.com/varsity/wp-content/uploads/2016/07/Image-6_daily-rt.png)  

A few take‑aways:

| Metric | Value |
|--------|-------|
| **Average daily return** | **+0.025 %** |
| **Maximum daily return** | **+4.01 %** |
| **Minimum daily return** | **‑2.962 %** |
| **Daily SD (2008‑2016)** | **0.567 %** |
| **Daily SD (2015 only)** | **0.311 %** |
| **Annualised SD (2015)** | **4.94 %** |

Compare that to the Nifty 50 (daily SD ≈ 0.82 %, annualised ≈ 15.71 %). The USD‑INR is a *quiet* partner – less volatile, more predictable, kind of like that friend who always shows up on time.

### Correlation with Nifty 50  

Before we drop the number, let’s talk correlation in plain English. Correlation tells you **how two series move together** on a scale from –1 (perfect opposite) to +1 (perfect together).  

- **+0.75** means “they usually go in the same direction, and they’re pretty tight on each other.”  
- **‑0.75** means “when one goes up, the other tends to go down, but the magnitude can differ.”  
- **0** means “no relationship whatsoever – like you and your cousin’s hamster.”

**Important nuance:** Correlation only makes sense on *stationary* data, i.e., data that bounces around a mean rather than drifting endlessly. Returns are stationary; prices are not (they trend). So always run correlation on daily returns, not on raw price series.

#### Quick correlation cheat‑sheet  

1. Compute daily returns for each series.  
2. In Excel (or Google Sheets) type `=CORREL(range1, range2)` and press **Enter**.  

That’s it – you get a number between –1 and +1.

#### Guess the sign!  

Think about the macro story: when the Indian equity market is hot, foreign investors pour money in, converting dollars to rupees. That **strengthens the rupee** (USD‑INR goes down) while the Nifty goes up. The opposite happens in a market slump. So you’d expect an **inverse** relationship.

Indeed, the 2015 data shows a correlation of **‑0.1227** – a mild negative link. Not a perfect mirror, but enough to say “they tend to move opposite each other a bit.”

You can download the Excel sheet used for these calculations if you’re curious.

---

### What’s next?  

In the following chapter we’ll glance at other currency contracts (think EUR‑INR, JPY‑INR) and peek at how **technical analysis** can be applied to FX trading. Then we’ll close the currency section and jump head‑first into the wild world of **commodities**.  

---

## Key Takeaways  

| ✅ | Insight |
|---|----------|
| 1️⃣ | Classic spot‑future arbitrage isn’t available to most retail traders in India. |
| 2️⃣ | **Calendar spreads** (buy one future, sell another) are the workhorse for currency traders. |
| 3️⃣ | **Future Bull Spread** = long near‑month, short far‑month. |
| 4️⃣ | **Future Bear Spread** = short near‑month, long far‑month. |
| 5️⃣ | Zerodha’s NEST (and soon Pi/Kite) let you trade the spread as a single instrument – no double‑order headache. |
| 6️⃣ | USD‑INR is *less volatile* than the Nifty 50 (annualised SD ~5 % vs ~16 %). |
| 7️⃣ | USD‑INR and Nifty 50 are **weakly inversely correlated** (≈ ‑0.12 in 2015). |

That’s a lot of info, but now you’ve got the toolbox to spot and trade calendar spreads in USD‑INR, and you also know why the rupee‑dollar dance is a bit calmer than the Indian equity circus. Cheers to smarter, smoother trades! 🎉