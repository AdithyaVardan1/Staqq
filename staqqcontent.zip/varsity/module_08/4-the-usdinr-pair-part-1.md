# 4. The USD‑INR Pair (Part 1)

**Source:** https://zerodha.com/varsity/chapter/the-usd-inr-pair/  

---  

## 4.1 – The contract  

First things first: I’m going to **assume** you already know what Futures and Options are. If you’re still wondering whether a “future” is something that will happen next week or a “call option” is a free phone call, hit pause and read the Futures‑and‑Options modules first.  
Why? Because the whole currency‑and‑commodity arena runs on derivatives, not on “buy‑low‑sell‑high”‑and‑pray.

Assuming you’re not a total rookie, let’s start cutting the USD‑INR futures contract into bite‑size pieces. The spec sheet tells us everything we need to know about how the trade actually works.

### Quick‑look at the USD‑INR futures specs  

| Feature | What it means for you |
|---------|----------------------|
| **Expiry** | Every weekly contract expires on **Friday** of that week. |
| **Lot size** | 1 lot = **$1,000** worth of USD. |
| **Price quote** | Up to **four decimal places** (e.g., 67.9025). |
| **Tick / pip** | One tick = **0.0025** (the smallest move you can get). |
| **Margin** | Typically only about **2 %** of the contract value (much lower than equities). |

#### Example chart (15‑minute candles)

![Image](http://zerodha.com/varsity/wp-content/uploads/2016/07/Image-1_USDINR.png)  

You see the orange‑circled candle? It’s a **bearish Marubozu** – a long‑bodied candle that tells us sellers were in charge for the entire bar. If you were a trader with a short‑term appetite, you could flip a short position using the candle’s high (67.7500) as your stop‑loss.

> **Note:** I’m *not* trying to sell you a trade idea here. I’m just using this chart to show you how the contract math works.

### Trade details (the numbers you’ll actually type)

| Item | Value |
|------|-------|
| **Date** | 1 July 2016 |
| **Position** | Short |
| **Entry price** | 67.6900 |
| **Stop‑loss** | 67.7500 |
| **Lots to short** | 10 |
| **Lot size** | $1,000 |
| **Contract value of 1 lot** | 1 000 × 67.6900 = **₹67,690** |
| **Margin per lot** (from Zerodha calculator) | ~₹1,525 |
| **Margin %** | 1,525 ÷ 67,690 ≈ **2.25 %** |
| **Total margin for 10 lots** | 10 × 1,525 = **₹15,250** |

A quick reality check: equity futures usually ask for **15 %–65 %** of the contract value as margin, depending on the stock. Currency futures are a *lot* cheaper – that’s why you can crank up the leverage, but remember the market is also *tighter* (less swing room).  

---

## 4.2 – The contract logistics  

### Why four decimal places?  

Currency futures love precision. The RBI (Reserve Bank of India) publishes its reference rate to the **fourth decimal**, because a move of **0.0025** (one pip) can shift the nation’s foreign‑exchange reserves by a noticeable amount. Globally, everyone quotes FX to four decimals – it’s the lingua‑franca of forex.

So when the pair goes from **67.9000** to **67.9025**, we say it “moved up one pip.”  

### How much cash does a pip give you?  

```
Cash per pip = Lot size × Tick size
             = 1,000 × 0.0025
             = ₹2.5 per lot per pip
```

If you trade 10 lots, every pip is worth **₹25**.  

### Follow‑through on the short trade  

![Image](http://zerodha.com/varsity/wp-content/uploads/2016/07/Image-3_Short-exit.png)  

Our short entry was at **67.6900**. The price fell to **67.6000** before we exited.

1. **Total points moved** = 67.6900 − 67.6000 = **0.0900**  
2. **Number of pips** = 0.0900 ÷ 0.0025 = **36 pips**  
3. **Profit** = Lot size × Lots × Points moved  
   = 1,000 × 10 × 0.0900 = **₹900**

That’s an intraday profit of **₹900** on a margin of **₹15,250** – a *nice* 5.9 % return in a few hours.

### Holding the contract to expiry  

Currency futures can be carried forward **as long as you maintain the required margin**. The July series expires **2 business days before the month’s last working day**.  

Calendar snapshot:

![Image](http://zerodha.com/varsity/wp-content/uploads/2016/07/Image-4_expiry.png)  

- **Last working day** of July 2016 = 29th July (Friday).  
- **Expiry** = 27th July (Wednesday).  
- You can stay in the trade **until 12:30 PM** on the expiry day.

#### Settlement mechanics  

Settlement is based on the **RBI reference rate** of the expiry date, and the P&L is settled in **INR**.  

Suppose you held the short until 12:30 PM on 27 July and the settlement price turned out to be **67.4000**. Your profit would be:

```
Profit = Lot size × Lots × (Entry – Settlement)
       = 1,000 × 10 × (67.6900 – 67.4000)
       = 1,000 × 10 × 0.29
       = ₹2,900
```

That cash lands in your trading account the next day (28 July). While you’re holding the position, it’s **marked‑to‑market** every minute, just like equity futures.

---

## 4.3 – USD‑INR options contract  

Now, let’s peek at the **option** side of the same pair. As of now, the exchange only offers options on USD‑INR, but who knows? Maybe someday you’ll see Euro‑Yen options on the menu.

| Feature | Details |
|---------|---------|
| **Expiry style** | European (exercisable only on the expiry day). |
| **Premium quote** | In **INR** (not in USD). |
| **Contract cycle** | Only **3 months** ahead (July, August, September) – same cadence as equity options. |
| **Strikes available** | 12 ITM, 12 OTM, 1 Near‑the‑Money → roughly **25 strikes**. New strikes appear as the market moves. |
| **Strike spacing** | Every **0.25 INR** (i.e., 0.2500). |
| **Settlement** | INR, based on the RBI reference rate on expiry. |

### Example option quote  

![Image](http://zerodha.com/varsity/wp-content/uploads/2016/07/Image-5_options.png)  

From the screen we can read:

| Parameter | Value |
|-----------|-------|
| **Option type** | Call |
| **Strike** | 67.0000 |
| **Spot (RBI rate)** | 67.1848 |
| **Expiry** | 27 July 2016 |
| **Position** | Long |
| **Premium** | 0.7400 INR (per USD) |

Remember: **Lot size = $1,000** even though the UI doesn’t repeat it.  

#### Premium outlay  

```
Premium paid = Lot size × Premium per USD
             = 1,000 × 0.7400
             = ₹740
```

### Closing the option  

Later the same day the premium rose to **0.7750**:

![Image](http://zerodha.com/varsity/wp-content/uploads/2016/07/Image-6_option-exit.png)  

If you sell (close) at that price:

```
Proceeds = 1,000 × 0.7750 = ₹775
Profit   = 775 – 740 = ₹35 per lot
```

Not a fortune, but it illustrates the mechanics.

### Writing (selling) the option  

Selling an option means you have to post **margin**. Using Zerodha’s F&O margin calculator:

![Image](http://zerodha.com/varsity/wp-content/uploads/2016/07/Image-7_option-margins.png)  

The required **SPAN + exposure** margin for this short call is **₹2,390**.  

---

### Key take‑aways (the cheat‑sheet you’ll actually keep)

- The **spec sheet** is your contract bible – it spells out lot size, tick size, expiry, etc.  
- **Lot size** is fixed at **$1,000**, but the exchange can change it, so keep an eye on announcements.  
- **Expiry** occurs **2 business days before the month‑end**; you can trade up to **12:30 PM** on that day.  
- **Margins** are roughly **2.25 %–2.5 %** of the contract value (SPAN + exposure).  
- FX quotes go to the **fourth decimal**; a move of **0.0025** is one **pip** (or tick).  
- **Pip value** for USD‑INR = **₹2.5 per lot** (₹25 for 10 lots).  
- Currency options are **European‑style**; you can’t exercise before expiry.  
- **Premiums** are quoted in **INR**, not USD.  
- **Strike spacing** = **0.25 INR** (i.e., 25 paisa).  
- When you **write** an option, the required margin is **blocked** until you close or the contract expires.  

That’s the gist of how the USD‑INR futures and options tick along. Next up we’ll dive into the numbers that make the pair behave the way it does, and maybe peek at a couple of other currency contracts. Grab a drink, because the next chapter gets a little nerdier! 🍻