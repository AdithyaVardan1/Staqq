# 11. Crude Oil (Part 2) – The Oil‑and‑Gas Jungle  

**Source:** https://zerodha.com/varsity/chapter/crude-oil-part-2-the-crude-oil-eco-system/  

---  

## 11.1 – Mapping Companies  

If you survived the first chapter without nodding off, you now have a rough idea of what’s cooking in the world of crude‑oil fundamentals. Some of you are probably wondering *how the black gold actually gets out of the earth and ends up in the gas station on your way to the office.* Good news: the YouTube channel **Oil and Gas Videos** has a whole playlist of bite‑size animated explainers that make the whole “oil‑rig‑on‑the‑sea‑with‑flames‑shooting‑out‑of‑the‑exhaust” thing look almost fun.  

If you can’t binge‑watch the entire playlist, at least watch **this** one (link in the original). It shows, in cartoon form, how we drill into on‑shore and off‑shore beds, what an “oil rig” really looks like, and which companies actually build and run those floating metal dinosaurs. Names you’ll hear a lot: **Aban Offshore, Selan Exploration, Cairn India** – the folks who put the steel and the fire‑balls together.  

I meet a lot of traders who throw money at asset‑heavy oil stocks without ever opening the back‑of‑the‑envelopes that explain *what the company actually does.* That’s like buying a Ferrari because it looks cool, without knowing whether it runs on gasoline or electricity. So, let’s pull back the curtain and see how the whole oil ecosystem is stitched together.  

---  

## 11.2 – Upstream, Downstream, and Midstream  

*Quick disclaimer:* I’m not a petroleum engineer; I know just enough to keep my trading hat on straight. But as a crude‑oil trader, you *have* to know the lay‑of‑the‑land, because the next big trade might not be a barrel of oil itself—it could be a refinery, a pipeline, or a storage tank.  

### The three big buckets  

| Segment | What they do | Typical players |
|---------|--------------|-----------------|
| **Upstream** | Hunt for oil, drill, extract, store in barrels | ONGC, Cairn India, Reliance, Oil India; globally: Shell, BP, Chevron |
| **Midstream** | Move the crude from the well to the refinery (pipelines, trucks, ships) | TransCanada, Spectra Energy, Williams |
| **Downstream** | Turn crude into gasoline, diesel, jet‑fuel, lubricants; then sell to B2B or B2C (think fuel stations) | BPCL, HPCL, IOC; “Super Majors” that do both upstream + downstream: Exxon Mobil, Royal Dutch Shell |

Below is a quick cartoon that shows the three sections as a simple “see‑saw”.  

![Image](http://zerodha.com/varsity/wp-content/uploads/2016/11/M8-C11-cartoon1.png)  

### Upstream – the dirt‑diggers  

Upstream firms are the **oil prospectors and drillers**. They spend months (sometimes years) on geological surveys, then sink boreholes, and finally, if they hit the jackpot, they set up a full‑blown extraction operation. Think of them as the **gold miners of the 21st century**—they pour money into capital‑intensive equipment, R&D, and drilling rigs, hoping to turn rock into barrels.  

Every barrel they produce has a *breakeven* cost (also called the **full‑cycle cost**). If the market price of oil is **above** that breakeven, the company is smiling; if it’s **below**, the shareholders start sweating. The market price isn’t in their hands—it’s set by the global oil market, where you, me, and the OPEC cartel are all shouting our opinions.  

Bottom line: **low oil prices hurt upstream firms** (especially those with high breakevens), while **high prices boost their margins**.  

### Downstream – the refineries and the pumps  

Once the crude leaves the well, it’s still a *messy, black, unrefined slurry.* Downstream firms buy that crude, run it through massive refineries, and splice it into useful products: petrol, diesel, jet fuel, kerosene, LPG, asphalt, you name it. They also own the **petrol bunks** where you fill up your car—so a downstream company is literally the one that tells you “pump 1 litre for ₹100”.  

Because they buy crude **cheaper** when oil prices dip, downstream margins improve in a falling‑price environment. In places like the US or UK, that price relief often trickles down to the consumer quickly. Conversely, when oil prices **spike**, downstream firms pay more for raw material, squeezing their profit‑pipes.  

### Midstream – the middle‑man logistics crew  

Midstream firms are the **oil‑delivery service**. They own pipelines, tanker fleets, and railcars that shuttle crude from the wellhead to the refinery. Some of them dabble in light‑refining, blurring the line between mid‑ and downstream, but their core business is *transport*.  

Because they earn money **regardless** of the crude price (they charge per barrel‑kilometre, not per barrel‑price), they prefer a **stable oil price**. If the price crashes, upstream customers are hurting, and if it soars, downstream buyers are hurting—both scenarios can reduce the volume of oil flowing through the midstream network.  

Here’s a quick diagram that sums up all three segments.  

![Image](http://zerodha.com/varsity/wp-content/uploads/2016/11/M8-C11-cartoon2.png)  

---  

## 11.2 – Difference Between WTI Crude and Brent  

Most people treat “crude oil” like it’s a single commodity—kind of like gold. In reality, **there are dozens of crude grades**, each with its own colour, thickness, sulfur level, and smell (yes, some are practically “smoky”). The two that matter most to traders are **West Texas Intermediate (WTI)** and **Brent Blend**.  

### Two key quality knobs  

| Characteristic | What it means | Typical numbers |
|----------------|---------------|-----------------|
| **API Gravity** (American Petroleum Institute) | A measure of *lightness* vs. water. > 10 = lighter than water (floats). < 10 = heavier (sinks). | WTI: **39.6** (very light). Brent: **38.1** (still light). |
| **Sweetness** (sulfur content) | Lower sulfur → “sweet” crude (easier to refine). Higher sulfur → “sour”. | WTI: **0.26 %** S (sweet). Brent: **0.37 %** S (still sweet, just a tad sourer). |

So, **WTI** is the *premium light‑sweet* crude that comes out of Texas. **Brent** is a *blend* of oil from over 15 North‑Sea fields, giving it a slightly heavier, slightly more sour profile. Because of those subtle quality differences, the two trade at different prices.  

Check out this Bloomberg snapshot (source in original).  

![Image](http://zerodha.com/varsity/wp-content/uploads/2016/11/Image-2_Brent-and-WTI.png)  

**Important for Indian traders:** the MCX (Multi Commodity Exchange) crude contract tracks **WTI**, not Brent.  

A fun footnote: Brent contracts let you choose **physical delivery or cash settlement** when they expire, while WTI contracts are **physically settled** only. That flexibility is one reason Brent’s benchmark price often sits a smidge above WTI.  

---  

## 11.3 – Crude‑Oil Inventory Levels  

Supply‑and‑demand is the mother of all oil price moves, and **inventories** are the pulse‑check. When inventories rise, it usually means demand is weak or supply is plentiful → price pressure **down**. When inventories fall, the market is either gobbling up oil or producers have cut output → price pressure **up**.  

Two main sources publish inventory data:  

1. **U.S. Energy Information Administration (EIA)** – weekly reports, easy to track.  
2. **OECD Crude Oil Inventory** – less frequent (not weekly) but still useful for a global view.  

Both are worth bookmarking if you want to anticipate moves in MCX crude, or in stocks like **BPCL, HPCL, IOC, ONGC**.  

---  

## 11.4 – The Relationship Between the U.S. Dollar and Crude Oil  

Oil is priced in **U.S. dollars** everywhere, so the value of the greenback matters a lot. In general, a **stronger dollar** makes oil *cheaper* for holders of other currencies, which tends to **push oil prices down**. Conversely, a **weaker dollar** makes oil relatively expensive abroad, nudging prices **up**.  

That’s why you’ll see a lot of charts titled “Oil vs. Dollar Index” – the index measures the dollar against a basket of major currencies, not just the spot USD.  

A quick mental experiment: imagine the dollar jumps 10 % in strength. A country that earns in euros now needs *fewer* dollars to buy the same barrel of oil, so its demand falls, inventories build, and price slides.  

A few caveats:  

* The inverse link is **not a 1‑to‑1 ratio**. A 10 % drop in the dollar does **not** guarantee a 10 % rise in oil.  
* Both assets have **their own supply‑demand drivers** (e.g., OPEC cuts, U.S. shale output, U.S. monetary policy), so they can temporarily move together.  

In short, keep an eye on the **Dollar Index** as a *supporting* factor, but never treat it as the sole oracle.  

---  

### Key Takeaways  

- **Map the ecosystem:** Upstream = explorers/drillers, Midstream = transporters, Downstream = refiners & retailers.  
- **Upstream firms** are capital‑heavy; they love **high oil prices** and hate low ones.  
- **Downstream firms** benefit from **low oil prices** (cheaper feedstock) but suffer when oil spikes.  
- **Midstream firms** want **price stability** because they earn on moving barrels, not on the barrel price itself.  
- **WTI vs. Brent:** differ mainly in **API gravity** (WTI 39.6, Brent 38.1) and **sulfur sweetness** (WTI 0.26 %, Brent 0.37 %).  
- **Brent** is the global benchmark; **WTI** is what you trade on MCX.  
- **Inventories** matter: rising stocks → price pressure down; falling stocks → price pressure up. Follow EIA (weekly) and OECD (periodic).  
- **Dollar‑Oil inverse correlation** holds over longer horizons, but magnitude varies and short‑term breaks are possible.  

Now you’ve got the whole oil‑and‑gas circus in your back pocket—feel free to pop a few jokes at your trading desk while you decide whether to go long on a refinery or short a drilling outfit. Cheers!