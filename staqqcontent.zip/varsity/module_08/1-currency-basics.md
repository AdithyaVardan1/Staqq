# 1. Currency Basics  

**Source:** <https://zerodha.com/varsity/chapter/currency-basics/>

---  

## 1.1 – Module Orientation  

Alright, buckle up, future Forex‑wizard. Before we dive head‑first into the world of money‑talk, let’s set the GPS so you know where we’re headed. This mini‑course will focus on three heavyweight topics that normally deserve their own Netflix series:  

| 🎯 What we’ll cover | 📚 Why it matters |
|----------------------|-------------------|
| **Currencies & currency trading** | Because swapping rupees for dollars is way more fun than swapping socks. |
| **Commodities** | Gold, oil, turmeric – the stuff that makes the world go round (and your portfolio wobble). |
| **Interest‑Rate Futures** | The “Bond‑Ninja” arena where central banks and traders dance. |

I hear you: “Each of these is a whole universe!” – and you’re right. They’re not as liquid as equities (you can’t pour a barrel of wheat on a stock chart), and in India they’re still in the “new‑kid‑on‑the‑block” phase. Think of this module as the **starter pack** – a friendly nudge that says “Hey, these assets exist, they move, and you might want to keep an eye on them before you go all‑in.”  

We’ll **dig deep enough** that you finish with more than a surface‑level “what’s a currency pair?” but we won’t drown you in PhD‑level econometrics (unless you secretly have a doctorate in “making charts look pretty”).  

### The roadmap  

1. **Currencies** – We’ll meet the regulars: USD‑INR, GBP‑INR, INR‑JPY, plus the globe‑trotting couples like EUR‑USD, GBP‑USD, and USD‑JPY. Expect contract specs, a dash of fundamentals, and a few anecdotes about why the euro sometimes acts like a drama‑queen.  
2. **Commodities** – Same template, different spice rack. From shiny Gold & Silver to earthy Turmeric and pungent Cardamom, we’ll talk contracts, price drivers, and the little math that turns a world‑wide gold price into an Indian rupee quote.  
3. **Interest‑Rate Futures (IRF)** – The “borrowing‑dance” of the RBI, sovereign bonds, NSE listings, and (if we have time) a quick tour of bond‑trading strategies.  

Sounds like a lot? That’s because it is, and that’s exactly why it’ll be a **great learning experience** for both of us.  

#### Prerequisites (read the fine print)  

- Futures Trading  
- Options Theory  
- Technical Analysis  

If any of these sound like foreign languages, give them a quick refresh before you plunge into currency land.  

Ready? Let’s roll the intro tape and talk *basics* of money‑talk.  

---  

## 1.2 – Currency (in)equality  

Before we start crunching numbers, let me share a *real* story that made me realize just how weird money can be. Picture this: I’m on vacation in Austria with my six‑year‑old daughter, who’s instantly turned into a tiny, demanding art critic. She drags me into a cute little toy shop and spots a **colorful wooden caterpillar**.  

The price tag? **25 €**.  

I’m about to whisper, “How about a plastic dinosaur for 5 €?” when she shouts, “It’s only 25 €!” She’s treating 25 € like it’s 25 ₹ – completely oblivious to the fact that 1 € ≈ ₹78 (as of 2026).  

That moment made me ask: **Why isn’t 1 € equal to 1 ₹?** Why do currencies have different “weights”? The answer isn’t just “because someone said so”; it’s a whole saga of economics, politics, and human ingenuity. Understanding this “inequality” is the secret sauce that lets us trade *pairs* instead of single, lonely currencies.  

Below is a lightning‑fast tour of how money went from “barter” to “Forex” – think of it as a quick history cheat sheet, not a bedtime story.  

### Stage 1 – The Barter Era  

Before coins, people swapped *stuff* directly: cotton for wheat, oranges for a cow‑shearing service. The **Barter System** was the original “bring‑your‑own‑lunch” economy.  

*Problems*:  

- **Divisibility** – You can’t cut a cow into half‑cows to pay for a sack of cotton.  
- **Scalability** – Our farmer would have to lug a mountain of cotton across the country just to find someone who needed cotton *and* owned a cow.  

Enter **Metal** as the universal medium.  

### Stage 2 – Goods for Metal  

Metals (especially gold & silver) solved the divisor problem: they’re melt‑able, portable, and don’t rot. People started **minting coins** and eventually **depositing gold/silver in vaults** and issuing paper receipts that promised you could redeem the metal on demand. Those receipts are the ancestors of today’s banknotes.  

Think of it as the first version of a **book‑entry system**: you have a claim on something shiny without physically holding it.  

### Stage 3 – The Gold Standard Era  

International trade exploded, and merchants needed a *single* unit of value that everyone trusted. The world said, “Let’s peg every currency to gold.” Countries fixed their money’s value to a certain amount of gold, making the **Gold Standard** the global accounting system.  

Then came the **Bretton Woods System (BWS)** after World War II. In simple terms:  

- All currencies *peg* to the **U.S. Dollar** (USD).  
- The USD itself is pegged to **gold at $35 per ounce**.  

Countries could deviate by up to **±1 %**. This made the dollar the de‑facto global reserve currency – the “world’s Wi‑Fi” for trade.  

Fast forward: the U.S. abandoned the gold peg in 1971, and the BWS crumbled. Since then, **floating exchange rates** dominate: market forces (politics, economics, even Twitter memes) decide how much one rupee is worth in dollars.  

And that, my friends, lands us in **today’s 24/7 Forex frenzy**.  

---  

## 1.3 – International Currency Market (Forex)  

If you thought the Indian stock market’s daily turnover was huge, think again. The **Bank for International Settlements (BIS)** reported that in April 2013 the **global FX market** churned **$5.4 trillion** a day. My crystal ball (aka recent BIS updates) suggests we’re hovering around **$5.8–$6 trillion** daily in 2026.  

**Perspective:** That’s roughly **20 % more** than the entire **annual Indian GDP**—and that’s *every single day*.  

Why is it so massive? Because **currency markets chase the sun**. While you’re sipping chai at 9 am, traders in Sydney are already shouting “Buy the yen!”; by the time you hit lunch, London, Frankfurt, and Paris are in full swing; when you finish dinner, the New York session is roaring.  

### The 24‑hour dance floor  

| Time‑zone | Market(s) open | What’s happening? |
|-----------|----------------|-------------------|
| **Asia** (Tokyo, Singapore, Hong Kong, Sydney) | Pre‑Indian market | First wave of liquidity, Asian macro data. |
| **Middle East** (Dubai, Riyadh) | Overlap with Asia | Oil‑related flows dominate. |
| **Europe** (London, Frankfurt, Paris) | Overlap with Indian market | Most volume, central bank speeches. |
| **North America** (New York) | After Indian close | USD‑driven moves, US macro releases. |

The **peak liquidity** occurs when **US, UK, Japan, and Australia** are all awake – basically when the world is collectively caffeinated.  

### Who’s actually trading?  

- **Central Banks** – They tweak rates, intervene to stabilize their currency.  
- **Corporates** – Hedging foreign‑currency exposure for imports/exports.  
- **Banks & Financial Institutions** – Provide liquidity, earn spreads.  
- **Travelers** – The “I need 200 USD for my vacation” crowd.  
- **Speculators/Traders** – The adrenaline‑junkies who live for pips.  

Because **everyone** participates, the *notional* (face‑value) size balloons. Add **high leverage** (often 1:20 or more) and you get the eye‑popping numbers you see in reports.  

There’s **no single exchange** like NSE for Forex. Trades happen over a web of banks, brokers, and electronic networks (think of it as a giant, borderless flea market).  

---  

## 1.4 – Currency Pairs and Quotes  

When you hear “Forex”, think **pairs**, not lone wolves. A currency pair is written as **BASE / QUOTE = price**. Let’s dissect it with a cocktail analogy.  

| Component | What it means | Analogy |
|-----------|---------------|---------|
| **Base Currency** | Always **1 unit** (e.g., 1 USD) | The “drink” you’re ordering. |
| **Quote Currency** | What you pay for that 1 unit (e.g., INR) | The “price tag” on the drink. |
| **Value** | The numeric price (e.g., 67) | The actual cash you hand over. |

**Example:** `USD/INR = 67`  

- **Base** = 1 USD (the drink).  
- **Quote** = Indian Rupee (the cash).  
- **Value** = 67 – meaning you need **₹67** to get **$1**.  

So, “USD/INR = 67” is simply **“$1 = ₹67”**.  

### Most‑traded pairs (as of 3 June 2016 – numbers have shifted a bit but the hierarchy remains)  

| Pair | Approx. price (June 2016) |
|------|--------------------------|
| EUR/USD | 1.11 |
| USD/JPY | 106 |
| GBP/USD | 1.45 |
| USD/CHF | 0.96 |
| AUD/USD | 0.73 |
| USD/CAD | 1.26 |
| NZD/USD | 0.66 |

*(We’ll update the exact numbers later; the concept stays the same.)*  

### What moves the pairs?  

Liquidity, news, central‑bank policy, geopolitical events, commodity price swings (think “oil price = CAD strength”), and even **Twitter storms** can cause a pair to jiggle. We’ll unpack the “why” in the next chapter.  

---  

### Key Takeaways  

- The **Gold Standard** once anchored currencies to a shiny metal, but it’s now museum‑piece material.  
- **Currency inequality** (why € ≠ ₹) stems from political and economic differences—think “different gym memberships for each country”.  
- By sheer volume, **Forex** is one of the world’s biggest markets – trillions of dollars daily.  
- The market runs **24 hours a day, 6 days a week**, chasing the sun across time zones.  
- **Currencies are always traded in pairs**; you never buy a dollar alone, you buy a *dollar‑rupee* combo.  
- Each pair follows the **Base / Quote = Value** format.  
- The **Base Currency** is always **1 unit**; the Quote shows how many of that currency you need to buy the base.  

Now that we’ve set the stage, grab a coffee (or a chai, your call) and let’s plunge into the nitty‑gritty of how those numbers actually move. 🚀  