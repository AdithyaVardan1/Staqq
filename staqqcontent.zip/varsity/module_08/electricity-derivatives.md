# 20. Electricity Derivatives  

**Source:** https://zerodha.com/varsity/chapter/electricity-derivatives/  

---  

## 20.1 – Background  

Picture this: MCX just rolled out a brand‑new commodity—electricity. Yep, the same exchange where you’ve been buying gold, silver, copper, oil, and gas now lets you trade the juice that powers your toaster. Because it’s fresh off the press, we figured it deserved a spot in Varsity.  

### How does electricity even get to the market?  

Power plants (think NTPC, Reliance Power, etc.) crank out megawatts and then sign **Power Purchase Agreements (PPAs)** with distribution companies (discoms) like Tata Power‑DDL. A PPA is basically a “I’ll sell you X MWh at a fixed price” contract. The price is almost set in stone; any variable component is so tiny it’s like the garnish on a cocktail.  

Discoms, on the other hand, are the middle‑men who deliver that electricity to your home, office, or the factory down the road. Because many states subsidise residential tariffs, discoms often have to sell power to households **below** what they paid for it. They make up the shortfall by charging commercial and industrial users a little more, which makes their profit margins look like a roller‑coaster.  

For decades these discoms were stuck with the PPAs’ “rigid‑price” clause. If demand spiked one summer afternoon, the market price might shoot up, but the discom’s cost stayed the same—leaving them either with a windfall or a hole in the books, depending on the direction of the swing. They didn’t have a way to buy electricity elsewhere at a better price—until **2008**.  

![Electricity derivatives illustration](https://zerodha.com/varsity/wp-content/uploads/2025/07/Electricity-derivatives-scaled.jpg)  

#### Enter the power exchange (IEX, PXIL…)  

Think of a power exchange like a stock exchange, but instead of Apple shares you’re buying megawatts. Discoms and generators can now go “Hey, I need 100 MWh tomorrow, what’s the market saying?” and execute a trade on the spot. This short‑term buying and selling lets both sides chase the best price and, ideally, improve their bottom line.  

India now drinks over **1,700 TWh** of electricity a year—making it the world’s third‑largest power market. Yet only about **7 %** of that volume passes through power exchanges. Europe, by contrast, trades roughly **50 %** of its electricity on energy exchanges, so there’s plenty of room for India to grow.  

All trades on the power exchange are **delivery** trades. If you buy 10 MWh you must take delivery; if you sell, you must deliver. Forward contracts give you a little wiggle room to square‑off before expiry, but you still end up cash‑settled at the end.  

So far, so good—except for one big snag: **what if the price goes berserk and you want to protect yourself?** Before the recent launch, there were **no derivative contracts** to hedge that volatility. Now there are. That, dear reader, is the juicy meat of this chapter.  

---

## 20.2 – What are Electricity Derivatives?  

Electricity derivatives are simply **futures or options whose underlying asset is electricity**. Think of them as the same financial toys you use for gold, natural gas, or crude oil, just with a different “under‑the‑hood” asset.  

- **Where do you trade them?**  
  - On **MCX** (and soon NSE) from **9:00 AM to 11:30 PM** on weekdays.  
  - During U.S. daylight‑saving time the close is pushed out to **11:55 PM** (because global markets love to keep you on your toes).  

- **What’s the underlying?**  
  - Even though the derivative trades on MCX, the *real* electricity contracts live on **IEX**, India’s biggest energy exchange. MCX could have used contracts from PXIL or any other exchange, but the first batch launched on **10 July** was pegged to IEX’s **Day‑Ahead Market (DAM)** contracts.  

- **What’s the DAM?**  
  - The Day‑Ahead Market is the physical‑electricity‑trading arena where participants buy and sell power for delivery the very next day. It’s the “tomorrow‑you‑get‑it” market that keeps the grid balanced.  

- **Why didn’t IEX just launch futures itself?**  
  - Electricity is a **regulated commodity** overseen by the **Central Electricity Regulatory Commission (CERC)**. SEBI, the securities regulator, can’t touch commodities.  
  - Derivatives, however, are **securities**, and SEBI does regulate those. Hence, the securities exchanges (MCX, NSE) are the ones that can legally list electricity futures and options, while the energy exchanges continue to host the *physical* contracts that back them.  

- **What’s on the menu today?**  
  - So far, MCX and NSE have rolled out **electricity futures** only. Options are on the horizon, and when they appear, the underlying will be those very futures.  

---

## 20.3 – Who can participate in electricity derivatives?  

In theory, **anyone** with a broker that offers MCX can dip a toe in. In practice, the main players fall into a few neat buckets, each with a clear motive:  

| Participant | Why they care |
|-------------|---------------|
| **Power generators** | Hedge against a price plunge that would turn a profitable generation run into a loss. |
| **Discoms (distribution companies)** | Shield themselves from having to sell power to end‑users at a loss when retail tariffs are kept low by subsidies. |
| **Proprietary trading desks / large‑scale electricity users** | Companies that burn a lot of power (think steel mills, data‑centres, aluminium plants) use futures to smooth out cost volatility and protect EBITDA. |
| **Institutional investors** | Add a low‑correlation, high‑volatility asset class to their playbook. |
| **HNIs & professional investors** | Diversify portfolios, chase alpha, or simply enjoy the novelty of “trading kilowatts”. |

> **Fun fact:** Discoms often lose money on the agricultural and domestic segments because of subsidised tariffs. To make up for those losses, they jack up rates for industrial and commercial consumers. With electricity futures, those industrial users now have a direct way to hedge the extra cost they’re being passed.  

---

## 20.4 – Contract Specifications of Electricity Futures  

Just like equity and commodity F&O, electricity futures come with a **contract calendar** (near‑month, next‑month, far‑month). At launch MCX offered a handful of these expiries.  

| Specification | Detail |
|----------------|--------|
| **Lot size** | **50 MWh** per lot (think of it as 50 × 1 MWh “bars”). |
| **Minimum lot** | 1 lot (50 MWh). |
| **Maximum lot** | 50 lots (2,500 MWh) – enough for a medium‑sized plant. |
| **Tick size** | **₹1 per MWh**. Since a lot is 50 MWh, each tick moves the contract by **₹50**. |
| **Initial margin** | **10 % of contract value** *or* the SPAN‑calculated margin, whichever is higher. |
| **Settlement** | **Cash‑settled** only. No physical megawatts change hands; you receive (or pay) the price difference at expiry. |
| **Charges** | Brokerage, stamp duty, transaction charges, securities transaction tax (STT), and income‑tax treatment are the same as for any other MCX derivative. |

Because settlement is cash‑based, you never have to worry about actually delivering electricity to a grid operator—just your bank account.  

---

## 20.5 – Illustration of a sample electricity futures contract  

Let’s walk through a *real‑world‑style* example (with a dash of bar‑room math).  

1. **You decide to go long** 1 lot of the near‑month contract at **₹3,000 / MWh**.  
2. **Lot size = 50 MWh**, so the notional value is:  

   \[
   3{,}000\;₹ \times 50\; \text{MWh} = 1{,}50{,}000\;₹
   \]  

3. **Margin:** 10 % of ₹1,50,000 = **₹15,000** (or the SPAN amount, whichever is higher). Your broker blocks this as collateral.  
4. **Tick impact:** Each ₹1 move in the price = ₹50 P&L (because 1 MWh × ₹1 = ₹1, and you have 50 MWh).  

   - If the price climbs to **₹3,010 / MWh**, that’s **10 ticks** → 10 × ₹50 = **₹500 profit**.  
   - If it falls to **₹2,990 / MWh**, you lose **₹500**.  

5. **Expiration:** Suppose at expiry the spot (or reference) price is ₹3,020/MWh. Since you’re long at ₹3,000, you pocket the difference:  

   \[
   (3{,}020 - 3{,}000) \times 50 = 20 \times 50 = ₹1{,}000
   \]  

   (Minus any brokerage, taxes, and the return of your margin.)  

6. **Remember:** This example ignores brokerage and other transaction costs. If you’re on Zerodha, you can peek at the exact charge table **[here](https://zerodha.com/varsity/fees)**.  

---

## 20.6 – Are there any risks in electricity derivatives?  

Every financial instrument comes with a **risk cocktail**. Here’s the menu for electricity futures:  

1. **Cost of hedging** – The margin, brokerage, and taxes you pay must be less than the price risk you’re shielding against; otherwise you’re just paying to lose money.  
2. **Cash‑settlement detachment** – Because there’s no physical delivery, speculative frenzy can push futures away from the underlying spot price, especially for contracts far from expiry.  
3. **Basis risk at expiry** – Even on the last day, the cash‑settlement price may not perfectly match the physical spot price (the two are linked but not identical).  
4. **Time‑basis risk** – Your electricity bill may be calculated on a monthly or quarterly cycle, while the futures expiry is a single day. The mismatch can leave you exposed on the “off‑days”.  
5. **Location‑basis risk** – Grid congestion or regional transmission constraints can cause the spot price in, say, Delhi to diverge dramatically from the price used on the exchange (which is typically a *national* reference).  
6. **Quantity‑basis risk** – Hedging the wrong amount is a classic mistake. Too little, and you’re still vulnerable; too much, and you’ve locked in unnecessary cost.  

**Bottom line:** Electricity futures are a brand‑new playground. The novelty may tempt you to jump in headfirst, but it pays to understand the underlying power‑market fundamentals (fuel costs, weather patterns, grid outages, regulatory shifts) before you start trading.  

---  

### Key Takeaways  

- **Spot & short‑term power exchanges** (IEX, PXIL, etc.) let generators and discoms lock in prices for the next day, reducing day‑to‑day volatility.  
- **Electricity derivatives** add another layer of risk‑mitigation by bringing a broader set of market participants (speculators, investors, large‑scale consumers) into the pricing equation.  
- **Derivatives live on securities exchanges** (MCX, NSE) and are **cash‑settled** because the underlying electricity contracts are regulated by CERC, while the derivatives themselves fall under SEBI’s jurisdiction.  
- **Who can play?** Generators, distributors, big‑ticket electricity users, institutional investors, HNIs, and even retail traders with a broker that offers MCX.  
- **Current product:** Electricity **futures** (options are on the way).  
- **Specs:** Lot = 50 MWh, min 1 lot, max 50 lots, tick = ₹1/MWh (₹50 per lot), margin = 10 % (or SPAN).  
- **Risks:** Hedging costs, cash‑settlement basis, time/ location/ quantity mismatches, and the usual market‑volatility‑plus‑speculation cocktail.  

> *“Electricity futures may be new, but the principles of hedging are as old as the first trader who said ‘I’ll take that risk off your shoulders for a fee.’”* – Vineet Rajani, Zerodha Varsity  

Happy (and safe) trading! ⚡️🚀  