# 9. Silver  

**Source:** https://zerodha.com/varsity/chapter/silver/  

---  

##  

![Image](http://zerodha.com/varsity/wp-content/uploads/2016/10/M8-C9-Cartoon.png)  

## 9.1 – The Bullion Twins  

First things first – sorry for the radio‑silence. I took the longest “coffee break” a Varsity writer has ever taken (seriously, I think I broke a world record). A high‑octane project stole my brain‑cells, so the Silver chapter got stuck in the kitchen while the pizza baked. Anyway, let’s get back on track and talk about the shiny stuff.  

Gold, Silver and Platinum are the three musketeers of the metal world and we call them **bullion**. A lot of people think the price of gold and silver move together like synchronized swimmers. If that’s true, we can cook up a whole buffet of “pair‑trading” ideas. (We’ll dissect that later in a dedicated module – don’t go anywhere.) First, though, let’s see if the two actually dance in step.  

I ran a correlation check on 30‑minute intraday bars for the last three months (that’s more than **1,000** data points, so the statistics are pretty solid). The result?  

![Image](http://zerodha.com/varsity/wp-content/uploads/2016/10/Image-1_Correl.png)  

A correlation of **0.7** on an intraday basis. That’s pretty tight for a market that’s usually as jittery as a caffeinated squirrel. I’d bet the end‑of‑day (EOD) correlation is even higher – maybe 0.8‑ish.  

**What does 0.7 actually mean?**  
It tells us that when gold hops up or down, silver tends to follow suit about 70 % of the time. Remember the correlation deep‑dive we did in the USD‑INR chapter? If you missed it, skim section 5.3 of chapter 5 – it’s worth the read.  

With a 0.7 intraday link, you could imagine a “long‑gold / short‑silver” (or the opposite) hedged play. In other words, you’d be simultaneously bullish on one metal and bearish on its twin. **But** don’t go ripping out your credit card just yet. Building a robust pair‑trade requires a lot more than a single number – you need to think about spread volatility, transaction costs, risk limits, and the dreaded “basis risk”. We’ll get to that later.  

Take a look at the normalized intraday chart (both series start at 100 so you can compare apples‑to‑apples):  

![Image](http://zerodha.com/varsity/wp-content/uploads/2016/10/Image-2_intraday-graph.png)  

If you squint at the picture you might think “meh, they look different”, but the math says otherwise. Numbers never lie; eyes can be fooled by scale tricks.  

Now, intraday data is great for short‑term traders, but the long‑run picture is often more telling. Thomson Reuters did a quarterly survey of gold‑silver correlation over a few years. Check it out:  

![Image](http://zerodha.com/varsity/wp-content/uploads/2016/10/Image-3_correl2.png)  

Across quarters the average correlation hovers around **0.8** – that’s why the pair is nicknamed the **“Bullion Twins.”**  

A strong EOD correlation tells us that, in the eyes of investors, both metals are safe‑haven assets. Geopolitical jitters, a sudden oil price shock, or a Fed “oops‑ie” will usually push both gold and silver up together.  

One more nugget: silver’s correlation with crude oil is all over the place – it’s like that friend who never shows up on time. In other words, oil isn’t a reliable guide for silver’s moves.  

## 9.2 – The Silver Basics  

Silver isn’t just a pretty face; it’s the workhorse of many industries. From industrial fabrication and photography (yes, the old‑school dark‑room still loves it) to fashion, electrical wiring, and high‑tech electronics, there’s always a demand for the stuff.  

The **Silver Institute** (U.S.) recently tallied global demand at **1,170.5 million ounces**. Historically demand grows at roughly **2.5 % per year** – a modest but steady climb. Most of that appetite comes from the industrial and manufacturing sectors, meaning the health of big factories (think China, and a bit of India) can tug silver’s price up or down.  

On the supply side, total mined production plus scrap and sovereign sales clocks in at **1,040.6 million ounces**. That’s a small deficit of about **130 million ounces**, which translates to a tight market. Supply growth is sluggish too – only **~1.4 %** per year, far slower than demand.  

Here’s a quick snapshot of the demand‑supply balance:  

![Image](http://zerodha.com/varsity/wp-content/uploads/2016/10/Image-4_Supply-demand.png)  

(You can dig into the full report if you love spreadsheets.)  

Because demand outpaces supply, silver is a fertile playground for traders. But who actually sets the price?  
Just like gold, silver’s benchmark price is fixed in **London** by a consortium of participating banks (the “London Bullion Market Association” in plain English). The mechanics are the same as gold – the banks gather, quote, and lock in a price each day. Want the nitty‑gritty? Read the “How are gold and silver rates fixed?” article linked in the original Varsity chapter.  

## 9.3 – The Silver Contracts  

On the MCX (Multi Commodity Exchange of India) you can trade four flavors of silver futures. The main differences are the **lot size** (how much metal each contract represents) and consequently the **margin** you need to put up. The four contracts are:  

| Contract | Lot Size | Typical Margin % |
|----------|----------|------------------|
| Silver (30 kg) | 30 kg | ~5 % |
| Silver Mini | 1 kg | ~5–6 % |
| Silver Micro | 0.1 kg | ~5–6 % |
| (A fourth variant exists, but the three above are the most popular) |

The **30 kg “Silver” contract** and the **Silver Mini** are the most liquid, so we’ll unpack them in detail.  

### How the price is quoted  

The quote you see on Kite, Bloomberg, or any MCX screen is **per kilogram**. That means when you see “₹42,266”, that’s the price for **1 kg** of silver, inclusive of import duties, taxes, and all other levies.  

![Image](http://zerodha.com/varsity/wp-content/uploads/2016/10/Image-5_Silverbig.png)  

**Contract value** = Lot size × Price per kg  

= 30 kg × ₹42,266  

= **₹12,67,980**  

### Margin requirement  

Margins on silver sit around **5 %** of the contract value. Here’s a snapshot from the MCX portal:  

![Image](http://zerodha.com/varsity/wp-content/uploads/2016/10/Image-6_silver-margin.png)  

Doing the math:  

Margin = ₹68,619 (required) ÷ ₹12,67,980 (contract) ≈ **5.41 %**  

### P&L per tick  

A “tick” is the smallest price movement the exchange allows (₹1 for silver). The profit or loss per tick is:  

\[
\text{P\&L per tick}= \frac{\text{Lot Size}}{\text{Quotation Unit}} \times \text{Tick Size}
\]  

= (30 kg / 1 kg) × ₹1  

= **₹30** per tick  

So every time the price moves up one rupee, you earn ₹30; every down‑tick costs you ₹30.  

### Expiry calendar (as of Oct 2016)  

All contracts expire on the **5th** of the contract month. The rolling series available then were:  

- Dec 2016  
- Mar 2017  
- May 2017  
- Jul 2017  
- Sep 2017  

When the Dec 2016 contract rolls off, the Dec 2017 contract steps onto the stage. The rule of thumb for liquidity: **trade the nearest‑expiry contract** (the “front‑month”). In Oct 2016, that would be the Dec 2016 contract.  

### Settlement – cash vs. physical  

Equity futures settle in cash; commodity futures settle **physically**. That means if you hold 10 lots of the 30 kg silver contract and you opt for delivery, you’re slated to receive **300 kg** of silver (10 × 30 kg).  

You must signal your intention to take delivery **four business days before expiry** (i.e., on or before the 4th).  

**Zerodha’s policy**: we don’t let you walk away with a metal chest in your backyard, so you have to square off (close) your position before the 1st of the expiry month. Personally, I close early too – dealing with a truckload of silver is a logistical nightmare.  

### Mini and Micro contracts – cash‑settlement optional  

The larger 30 kg contract **must** be physically delivered; you cannot cash‑settle it. The **Silver Mini (1 kg)** and **Silver Micro (0.1 kg)** give you the freedom to either take delivery or settle in cash. This flexibility makes them popular with retail traders who just want the price exposure without the freight charges.  

### Spot‑Futures convergence & the “location map”  

Check out this table that links each MCX commodity to a physical spot market:  

![Image](http://zerodha.com/varsity/wp-content/uploads/2016/10/Image-7_spot-convergence.png)  

Ever wondered why a contract is tagged to “Ahmedabad” or “Kochi”?  

When a futures contract expires, its price must **converge** to the price of the underlying spot market. For equities it’s easy – the spot and futures trade on the same exchange (NSE/BSE). Commodities are messier: pepper lives in Kochi, rubber also in Kochi, gold is quoted in both Mumbai and Ahmedabad, etc. MCX solves the identity crisis by pre‑assigning each contract to a single spot hub. So, the **Silver Micro** contract will converge with the **Ahmedabad silver spot price** on expiry.  

## 9.4 – The Other Silver Contracts  

If you’ve wrapped your head around the 30 kg contract, the Mini and Micro are just scaled‑down cousins. The math is identical; the only differences are **lot size**, **margin**, and **delivery option**.  

Below is a quick reference (exact numbers may shift slightly with market conditions):  

| Contract | Lot Size | Approx. Margin (₹) | Delivery? |
|----------|----------|-------------------|-----------|
| Silver Mini | 1 kg | ~₹75,000 (≈5 % of ₹1 kg × price) | Optional (cash or physical) |
| Silver Micro | 0.1 kg | ~₹7,500 (≈5 % of ₹0.1 kg × price) | Optional (cash or physical) |
| Silver (30 kg) | 30 kg | ~₹680,000 (≈5 % of contract) | Mandatory physical |

Because the lot is smaller, the required cash outlay is dramatically lower – perfect for traders who want exposure without tying up a six‑figure bankroll.  

### How to trade them  

Fundamentally, silver is a **complex beast**. Its price is tugged by industrial demand, macro‑economic risk sentiment, and even fashion trends (yes, that silver necklace you’re wearing could be influencing the market). Trying to track every driver daily is a full‑time job – and most of us are busy enough just remembering to water the plants.  

The practical approach most traders take is **technical analysis**: chart patterns, moving averages, RSI, etc. It works surprisingly well on silver because the market is liquid enough for price action to be meaningful, yet not so hyper‑fast that noise drowns the signal.  

If you’re a numbers nerd, you can also explore **quantitative strategies** like **pair trading** (gold vs. silver) or **statistical arbitrage** across the different contract months. As promised, we’ll dedicate a whole module to those tricks later.  

## Key Take‑aways  

- **Gold & Silver move together** – both intraday (≈0.7 correlation) and end‑of‑day (≈0.8).  
- This tight link makes them a classic **pair‑trading** candidate.  
- Silver’s correlation with **crude oil is erratic**, so oil isn’t a reliable signal for silver.  
- MCX offers **four silver futures** – the 30 kg “Silver”, the Mini (1 kg), the Micro (0.1 kg), and a fourth variant.  
- The flagship 30 kg contract trades at ~₹42,000 per kg, giving a **contract value of ~₹12.68 lakh**.  
- **Margins hover around 5‑6 %** of the contract value, meaning you need roughly **₹70‑80 k** to trade a single lot of the main contract (or just ~₹7‑8 k for a Mini).  
- **P&L per tick = ₹30** for the 30 kg contract (₹3 for Mini, ₹0.30 for Micro).  
- **Physical delivery is mandatory** for the 30 kg contract; Mini and Micro let you cash‑settle.  
- Spot‑futures convergence is tied to a specific **spot hub** (e.g., Ahmedabad for Silver Micro).  

Now that you’re armed with the silver scoop, you can decide whether to stare at the charts, set up a pair‑trade, or simply enjoy the sparkle of those “Bullion Twins” from your couch. Happy trading!  