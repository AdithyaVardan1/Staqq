# 16. Natural Gas  

**Source:** https://zerodha.com/varsity/chapter/natural-gas/  

---  

##  

![Image](http://zerodha.com/varsity/wp-content/uploads/2017/02/M8-C16-Cartoon.png)  

## 16.1 – History and background  

Alright, confession time: I dropped this Natural Gas chapter on the back‑burner. We probably should have tackled it right after the oil lesson—like a proper “oil‑and‑gas combo meal.” But hey, as they say, better late than never (and we all love a good dramatic entrance).  

In this final act of the **Currencies & Commodities** saga, we’ll give you the low‑down on natural gas: what it is, where it comes from, and why it’s the quiet hero behind your hot‑cooked noodles, your electric lights, and even the fertilizer that feeds the rice in your grandma’s backyard.  

### What *is* natural gas?  

- **Nature’s own cocktail:** a non‑renewable mixture of hydrocarbons, dominated by methane (CH₄).  
- **Fossil fuel status:** born from ancient dead plants and critters that got squished, heated, and turned into a gas‑filled vault deep underground.  
- **Everyday heroics:** fuels electricity generation, space heating, cooking, and fuels the fertilizer and plastics industries.  

#### The ancient “fire‑god” moment  

Legend has it that around **1000 B.C.**, a natural gas seep on Mount Parnassus in Greece ignited, giving locals a free‑standing flame. The Greeks, being the dramatic folk they were, thought it was the Oracle at Delphi and promptly erected a temple. *First ever natural‑gas‑powered worship?* You bet.  

![Image](http://zerodha.com/varsity/wp-content/uploads/2017/02/Image-1_NG.png)  
*Source: Daily Mail (UK).*

#### The Chinese bamboo‑pipeline hack  

Fast forward to **500 B.C.**—the Chinese spotted the same sneaky gas and thought, “Why not pipe it?” They fashioned bamboo “pipelines” to channel the seepage and used the flame to **boil seawater** into drinkable water. Talk about an early “green” solution—except it wasn’t really green yet.  

#### The British light‑up  

The first **commercial** use pops up in Great Britain circa **1785**. They captured gas generated from coal (yes, “town gas”) and lit lighthouses and street lamps. Imagine strolling down a foggy London lane lit by a flickering flame that’s actually *natural gas*—romantic, right?  

### How did it get *under* the Earth?  

Millions of years ago, dead plants and animals got buried in sand and silt, then *went on a pressure‑cooking marathon*. Over eons, heat and pressure turned that organic mush into coal, oil, **and natural gas**.  

- **Where does it hide?** In porous rock layers, cracks, or “pockets” between strata.  
- **What does it smell like?** Nothing—it's totally invisible, odorless, and tasteless. That’s why the industry adds **mercaptan**, a sulfur‑y stink that makes a leak smell like a rotten egg. (Because nothing says “danger” like a kitchen‑sink stench.)  

### Finding the hidden treasure  

Geologists play a real‑life “Where’s Waldo?” with natural gas:  

1. **Reconnaissance:** Identify promising basins on land or offshore using geological maps.  
2. **Seismic surveys:** Send shock waves underground, listen for echoes, and sketch a 3‑D picture of the subsurface.  
3. **Exploratory well:** Drill a test hole. If the readings are tasty, they go ahead with production wells.  

### India’s place in the gas club  

- **7th‑largest producer globally**, contributing roughly **2.5 %** of world natural‑gas output.  
- **Domestic usage:** power plants, industrial fuel, LPG for homes, and a big slice for fertilizer feedstock.  

That’s enough for a quick tour—enough to whet your appetite before we dive into the **contract specs**.  

> *Spoiler alert:* No gas‑talk is complete without the infamous **Amaranth Natural Gas gamble**. (Cue dramatic music.)  

---

## 16.2 – Amaranth Natural Gas gamble  

Enter **Amaranth Advisors**, a New‑York‑area hedge fund that sprouted in **2000** out of Greenwich, Connecticut. By 2006 it was a **$9 billion** beast, thanks to a mixed bag of strategies: convertible bonds, merger arbitrage, leveraged assets, and—yes—energy trading.  

### The star of the show: Brian Hunter  

- **Background:** Former Deutsche Bank prodigy who made a fortune (and a few million dollars in bonuses) trading natural‑gas derivatives.  
- **New gig:** Hired to run Amaranth’s energy desk; his early success helped the fund rake in **≈ $2 billion** by April 2006.  

### The market context  

Natural‑gas futures are **thin‑traded** relative to oil. That means a mid‑size hedge fund can **corner** the market with a few thousand contracts—like buying all the popcorn at a movie theater and raising the price.  

### The grand plan (and the grand flop)  

| Step | What Happened |
|------|----------------|
| **1** | Hunter spotted a **US gas inventory surplus**, predicting that a glut would push prices **down**. |
| **2** | He also bet on a **harsh winter or a hurricane** that would *tighten* supplies, sending prices **up**. (He’d made a killing during Hurricanes Katrina & Rita in 2005.) |
| **3** | He built **highly‑leveraged, speculative futures positions** across many contract months. |
| **4** | **Nature** said, “Nope.” The expected hurricane never materialized, inventories kept flowing, and prices fell **below the $5.5 / mmBtu** psychological support. |
| **5** | The market panicked; a **single‑day 20 % drop** sent natural‑gas futures into a free‑fall. |
| **6** | Amaranth, still convinced they were right, **borrowed more money** and **doubled down**. Their leverage ratio was **1 : 8** (for every $1 of their own cash they borrowed $8). |
| **7** | Prices kept sinking, the fund’s balance sheet cracked, and Amaranth was forced to **liquidate**, swallowing a **$6 billion** loss. One of the biggest hedge‑fund busts ever. |

#### The moral of the story  

> **Risk management** isn’t just a nice‑to‑have; it’s the *gatekeeper* that decides whether you walk out with champagne or a busted credit card.  

Respect risk, and risk will respect you back. Ignore it, and you’ll find yourself in the *corner*—the one you’re hoping to avoid while trading.  

Because of that, the next module is *all* about **Risk & Trading Psychology**. But for now, let’s get back to the nitty‑gritty of the **Natural‑Gas futures contract** on MCX.  

---

## 16.3 – Contract specifications  

Here’s the cheat‑sheet for the MCX **Natural‑Gas** contract (as of the writing of this chapter).  

| Parameter | Value |
|-----------|-------|
| **Price Quote** | Rupee per **Million British Thermal Unit** (MMBtu) |
| **Lot Size** | **1 250 MMBtu** |
| **Tick Size** | **₹ 0.10** per MMBtu (i.e., a price move of 0.10 ₹) |
| **P&L per Tick** | **₹ 125** (because 0.10 ₹ × 1 250 MMBtu) |
| **Expiry** | **25th of every month** |
| **Delivery Units** | **10 000 MMBtu** (the amount that would be physically delivered if you held to expiry) |

### Live quote example (Feb 2017 contract)  

![Image](http://zerodha.com/varsity/wp-content/uploads/2017/02/Image-2_quote.png)  

- **Price:** **₹ 217.3 / MMBtu**  
- **Contract Value:** 1 250 × 217.3 = **₹ 271 625**  

### Margin requirements (as shown on the platform)  

![Image](http://zerodha.com/varsity/wp-content/uploads/2017/02/Image-3_margins.png)  

- **NRML (overnight) margin:** **₹ 40 644** → roughly **15 %** of contract value (one of the highest margin requirements you’ll see).  
- **MIS (intraday) margin:** **₹ 20 322** → about **7 %** of contract value.  

### Contract roll‑over schedule  

![Image](http://zerodha.com/varsity/wp-content/uploads/2017/02/Image-4_delivery.png)  

- A **new contract** appears **every four months**.  
- Example: The **Jan 2017** contract was **listed in Oct 2016** and **expires on 25 Jan 2017**.  

### How does the Indian price relate to the global market?  

Even though natural gas is a *global* commodity, the **MCX spot price** still reflects domestic demand‑supply fundamentals. Nevertheless, the **MCX futures** track the **NYMEX** contract almost lock‑step.  

![Image](http://zerodha.com/varsity/wp-content/uploads/2017/02/Image-5_distro.png)  

The overlay graph shows a near‑perfect correlation between MCX and NYMEX. Because of that, the following drivers move Indian gas futures just as they move the US market:  

1. **Inventory data:** Higher US storage → lower futures price; lower storage → higher price.  
2. **US weather:** A brutal winter spikes heating demand, drains inventories, and pushes prices up.  
3. **Hurricanes:** Storms disrupt production and pipelines, creating a “supply‑shock” that usually makes you **long** (or at least stay away from shorting).  
4. **Crude‑oil price:** Historically, gas and oil prices have moved together (gas is cheaper and cleaner, but the two are still linked). The correlation has been wobblier lately, but still worth watching.  

> **Pro tip:** When you’re eyeing a natural‑gas trade, glance at the **US weather map**. If the sun’s shining bright, expect calm markets; if a polar vortex or a hurricane is brewing, brace for volatility.  

That’s a wrap on the natural‑gas chapter—time to move on to **Risk & Trading Psychology**.  

---

### Key takeaways from this chapter  

- Natural gas is a **colourless, odourless** hydrocarbon mixture that lives deep underground.  
- Humans have been **tapping** it since ancient Greece (the original “flaming oracle”).  
- Its **main uses** are power generation, heating, cooking, and as a feedstock for fertilizers and plastics.  
- **India** ranks **7th** globally, supplying about **2.5 %** of world production.  
- **Lot size** = **1 250 MMBtu**; price is quoted per **1 MMBtu**.  
- **P&L per tick** = **₹ 125** (0.10 ₹ × 1 250).  
- MCX **natural‑gas futures** mimic NYMEX price movements, so US inventory, weather, and hurricanes drive the Indian market.  
- The **Amaranth disaster** teaches the timeless lesson: **never ignore risk management**.  

Enjoy the ride, keep an eye on the weather, and may your trades be as smooth as a well‑burned flame! 🚀