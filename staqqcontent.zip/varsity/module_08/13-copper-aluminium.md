# 13. Copper & Aluminium  

**Source:** https://zerodha.com/varsity/chapter/copper-aluminium/  

---  

## 13.1 – The Sumitomo Copper Scandal  

If you’ve ever pretended to be a Bond villain while scrolling through commodity news, you’ve probably bumped into the infamous *Sumitomo Copper Scandal*. This Japan‑based drama kicked off around 1995, and its after‑effects still give traders the heebie‑jeebies whenever someone mentions “rogue trading”.  

**Who’s who?**  
- **Sumitomo Corporation** – a gigantic, publicly‑listed Japanese conglomerate that trades everything from steel pipes to sushi‑grade fish. Back in the day it ran a mammoth copper‑trading desk.  
- **Yasuo Hamanaka** – the man the Japanese called “Mr. Copper”. He was Sumitomo’s chief copper trader and, unofficially, the world’s most well‑stocked copper hoarder.  

![Cartoon of Hamanaka’s copper empire](http://zerodha.com/varsity/wp-content/uploads/2016/12/M8-C13-cartoon-1.png)  

### The (almost) Hollywood‑style plot  

| Step | What happened (in plain English) | Why it mattered |
|------|-----------------------------------|-----------------|
| 1️⃣ | Hamanaka bought **physical copper** on the spot market and tucked the shiny bars into warehouses across the globe. | He was literally *long* copper in the real‑world market. |
| 2️⃣ | His spot‑market stash amounted to **≈ 5 % of the world’s above‑ground copper reserves** – roughly the amount you could fit in a small country’s vaults. | With that kind of inventory, you can whisper “price up” and the market tends to listen. |
| 3️⃣ | Simultaneously, he went **all‑in on LME copper futures** (the London Metals Exchange contract that decides the global price). | Nobody knew the size of his futures exposure because LME didn’t publish open‑interest data back then. |
| 4️⃣ | Every time a rival trader tried to *short* copper, Hamanaka swooped in and bought the futures, driving the price higher. | Sumitomo was cash‑rich, so it could keep buying without breaking a sweat. |
| 5️⃣ | Higher LME prices squeezed the shorts, who eventually **defaulted** and had to **take delivery** of copper. | The defaulting short had to buy copper from Sumitomo at a premium – a double‑dip profit for the Japanese giant (spot profit + futures profit). |
| 6️⃣ | The profit snowball turned Hamanaka into the **undisputed copper king** for more than a decade. | Everybody cheered… until the plot twist. |

### The plot twist – China’s copper boom  

In the early ’90s, China cranked up its copper output like a teenager on a caffeine binge, flooding the market with extra supply. Prices started to cool, and Hamanaka’s empire felt the chill. His massive long positions meant he couldn’t off‑load quickly, so he **borrowed money** to keep the boat afloat. Remember: leveraged positions are like a house of cards on a windy day—one gust and *boom*, everything collapses.

When copper prices **crashed**, Sumitomo’s copper kingdom went *kaboom*. The losses piled up to an eye‑watering **≈ $5 billion** (1995 dollars). The firm flirted with bankruptcy, lawsuits flew around like confetti, and the whole industry took notes: **risk management is not optional**.  

That’s the moral of the story – we’ll revisit it in a dedicated risk‑management module later.  

Now that we’ve had our drama fix, let’s get down to the *boring* but essential copper basics.  

---

## 13.2 – Copper Basics  

Copper is a **base metal** (i.e., not a shiny, “precious” metal like gold or silver) and it trades like a rockstar on the MCX.  

- **Daily turnover**: roughly **₹ 2,050 crore** across about **55,000 lots**. That’s liquidity that rivals crude oil and gold – you can get in and out faster than you can finish a cup of instant ramen.  

- **Rank**: 3rd‑most‑consumed metal after **steel** and **aluminium**.  

- **Why it’s valuable**: Copper is an excellent conductor of electricity, so it’s the go‑to metal for wiring. Fun fact: the motor in a Tesla hybrid is **copper‑based**, not the usual iron‑or‑magnet combo. (Check the article for the nerdy details.)  

### Major uses (you’ll see copper everywhere)  

- Building & construction  
- Copper‑alloy moulds (think fancy cookware)  
- Electrical & electronics (yes, your phone’s tiny traces)  
- Plumbing solutions (water‑proof and rust‑proof)  
- Industrial applications (machinery, turbines)  
- Telecom infrastructure (the copper cables that still whisper data)  
- Railways (track signaling, power)  

#### My personal favourite  

![Copper statue – guess what it is!](http://zerodha.com/varsity/wp-content/uploads/2016/12/Image-1_Copper-Still.png)  

Can you guess what this is? If you’re thinking “a giant copper statue of a superhero”, you’re close. It’s a reminder that copper isn’t just for wires – it’s also for **art** and **heritage**.  

### Demand vs. Supply Snapshot  

Source: Hindalco Annual Report (FY 2015‑16)  

![Copper demand‑supply chart](http://zerodha.com/varsity/wp-content/uploads/2016/12/Image-2_Copper.png)  

- **2015 global refined copper demand**: **24 million tons** (≈ 50 % came from China & Japan).  
- **Supply** slightly outpaced demand (the two right‑most bars).  
- Because of a **global commodity glut**, copper prices have been on a long‑term cooling trend.  

#### Bottom line  

Fundamentals matter, but copper is a *liquid* commodity – charts are your best friend. Let’s now dive into the nitty‑gritty of the MCX contracts.  

### Copper contract specifications (big & mini)  

| Feature | Big Copper Contract | Mini Copper Contract |
|---------|-------------------|---------------------|
| **Price quote** | Per kilogram | Per kilogram |
| **Lot size** | **1 metric ton** (1,000 kg) | **250 kg** |
| **Tick size** | ₹0.05 | ₹0.05 |
| **P&L per tick** | ₹0.05 × 1,000 = **₹50** | ₹0.05 × 250 = **₹12.5** |
| **Expiry** | Last day of the month | Last day of the month |
| **Delivery units** | 10 MT | 10 MT |

#### Example: Copper Feb 2017 contract  

![Copper quote snapshot (Feb 2017)](http://zerodha.com/varsity/wp-content/uploads/2016/12/Image-3_Copper-quote.png)  

- **Quote**: **₹ 389.1 / kg**  
- **Contract value**: 1,000 kg × ₹ 389.1 = **₹ 389,100**  

**Margins**  

![Copper margin snapshot](http://zerodha.com/varsity/wp-content/uploads/2016/12/Image-4_Copper-margin.png)  

- **NRML (normal) margin**: **₹ 30,544** → **7.8 %** of contract value  
- **MIS (intraday) margin**: roughly **½** of NRML  

Mini‑contract numbers are simply scaled down by a factor of four.  

> **Pro tip:** Use technical analysis on these liquid contracts – the price moves fast enough that a well‑timed chart pattern can make you feel like a rock‑star (without the need for a cape).  

Onwards to aluminium!  

---

## 13.3 – Aluminium Basics  

We’re not writing a PhD thesis here; most traders hold aluminium for **2‑3 days** max, so you’ll want to focus on price action rather than deep‑dive fundamentals. Below are the bite‑size nuggets you need to know – think of them as the “cheat sheet” you’d keep on the back of a coaster.  

### Quick‑fire facts  

- **Abundance** – Aluminium makes up **≈ 8 % of the Earth’s crust**, making it the **3rd‑most abundant element** after oxygen and silicon.  
- **Corrosion‑resistant** – That’s why you see it in cans, airplane fuselages, and the *“forever‑fresh”* foil that keeps your leftovers from going stale.  
- **Power‑hungry** – Producing **1 tonne** of primary aluminium devours **≈ 17.4 MWh** of electricity (that’s roughly the annual consumption of a small town).  

![Hindalco power & fuel cost chart](http://zerodha.com/varsity/wp-content/uploads/2016/12/Image-5_PL.png)  

Hindalco, the Indian aluminium behemoth, spends **≈ 10 %** of its total cost on power & fuel, even though it runs its own captive power plants.  

- **Recycling** – A green bonus: recycling aluminium needs only **≈ 5 %** of the energy required for primary production. So a soda can can be turned into an aircraft part without breaking the planet’s bank.  
- **Applications** – From the smartphone in your hand to the **≈ 70,000 kg** of aluminium in a single Boeing 747. Other sectors: automotive, construction, defence, electronics, pharma, white goods, etc.  
- **Supply‑demand balance** – The metal enjoys a healthy equilibrium globally; no massive shortages are looming.  
- **Pricing** – MCX aluminium prices **track** the LME (London Metal Exchange) aluminium price.  

### Production, supply & price trends (2015‑16 snapshot)  

Source: Hindalco Annual Report (FY 2015‑16)  

![Aluminium production‑supply‑price chart](http://zerodha.com/varsity/wp-content/uploads/2016/12/Image-6_Al-trend.png)  

**Key takeaways from the chart**  

1. **Global production** (blue bar) = **56 million tons** in 2015 → **+ 4 %** YoY.  
2. **CAGR** over the last 8 years ≈ **6 %** – a modest but steady climb.  
3. **Demand** (yellow bar) matches production, indicating a **tight market** with little excess.  
4. **Price trajectory** – average price fell from a **peak of $2,500/ton** to **≈ $1,500/ton** (a classic commodity‑glut scenario).  
5. **India’s slice** – Hindalco reports **≈ 2 million tons** of domestic demand, most of which is satisfied via imports.  

That’s enough fundamentals to get you comfortable. For day‑trading, however, **charts** are your playground.  

---  

## 13.4 – Aluminium Contract Specifications  

Just like copper, aluminium has **two contract sizes** on MCX: the **big** contract and the **mini** contract. The big one is massive, so let’s break it down first.  

### Big aluminium contract  

| Parameter | Value |
|-----------|-------|
| **Price quote** | Per kilogram |
| **Lot size** | **5 metric tons** (= 5,000 kg) |
| **Tick size** | ₹0.05 (the smallest possible to keep the P&L manageable) |
| **P&L per tick** | ₹0.05 × 5,000 = **₹250** |
| **Expiry** | Last day of the month |
| **Delivery unit** | 10 MT (standard for MCX metals) |

#### What does that look like on a screen?  

![Aluminium market depth (Dec 2016)](http://zerodha.com/varsity/wp-content/uploads/2016/12/Image-7_Al-quote.png)  

- **Current quote** (Dec 2016 expiry) = **₹ 118.4 / kg**.  
- **Contract value** = 5,000 kg × ₹ 118.4 = **₹ 592,000**.  

If the price nudges **₹ 0.05** higher (118.45 → 118.50), you pocket **₹ 250** per contract.  

**Margins**  

![Aluminium NRML margin snapshot](http://zerodha.com/varsity/wp-content/uploads/2016/12/Image-8_margin.png)  

- **NRML margin** = **₹ 33,719** → **≈ 5.6 %** of contract value.  
- **MIS margin** ≈ **½** of NRML (perfect for intraday traders).  

### Aluminium mini contract  

| Parameter | Value |
|-----------|-------|
| **Price quote** | Per kilogram |
| **Lot size** | **1 metric ton** (= 1,000 kg) |
| **Tick size** | ₹0.05 |
| **P&L per tick** | ₹0.05 × 1,000 = **₹50** |
| **Expiry** | Last day of the month |
| **Delivery unit** | 10 MT |

- **Contract value** = 1,000 kg × ₹ 118.4 = **₹ 118,400**.  
- **NRML margin** = **₹ 6,779** → **≈ 5.7 %**.  
- **MIS margin** ≈ **₹ 3,389** (≈ 2.8 % of contract value).  

The mini contract is the “starter‑kit” for retail traders – the P&L per tick (₹ 50) is bite‑sized, and the margin requirement is modest.  

> **Quick tip:** Pick the contract that matches your bankroll and your preferred trade‑frequency. If you’re a swing trader, the big contract gives you more “bang per tick”. If you’re day‑trading with a tighter capital pool, the mini is the way to go.  

For deeper dives, check out the industry portals **[world‑aluminium.org](http://world-aluminium.org)** and **[aluminium.org](http://aluminium.org)**.  

---  

### Key take‑aways from this chapter  

- **Both copper and aluminium are *base* metals** – they’re essential industrial commodities, not shiny stores of wealth.  
- **Aluminium is incredibly abundant** (≈ 8 % of the crust) – only oxygen and silicon are more plentiful.  
- **Demand‑consumption patterns** for both metals are relatively balanced; no massive supply shocks in sight (so far).  
- **Prices have trended downwards** over the past decade, mainly because of global glut and slowing demand in China.  
- **LME prices** serve as the global benchmark; MCX contracts simply track those numbers.  
- **Two contract sizes** per metal (big & mini) let traders choose exposure and margin that suit their risk appetite.  
- **Contract specs matter** – tick size, lot size, and margin percentages dictate how much cash you need and how much you stand to win (or lose) on each price move.  

Now you’ve got the copper‑and‑aluminium toolbox. Go forth, plot those charts, manage your risk, and maybe treat yourself to a copper‑coated cocktail glass when you nail a trade! 🍹🧊  