# 19.						Government Securities  

**Source:** https://zerodha.com/varsity/chapter/government-securities/  

---  

##  


![Image](https://zerodha.com/varsity/wp-content/uploads/2018/05/M8-C19-cartoon.png)  

## 19.1 – The new beginning  

Picture this: the NSE and the RBI walk into a bar, order a round of “retail‑friendly” drinks, and *voilà* – retail investors can now sip on Government Securities (the long‑dated bonds and the snappy Treasury Bills, aka T‑bills).  

Until a few months ago, these goodies were the secret club of banks and big‑ticket institutions. Now the door is ajar, and you can hop in, grab a seat, and enjoy the sweet, guaranteed returns the government promises.  

But—as with any new cocktail—you should know what’s in the shaker before you gulp. That’s why we’ve put together a breezy FAQ‑style conversation. Read on, ask questions in the comments, and you’ll be the life of the (financial) party.  

## 19.2 – FAQs on G‑Sec  

### What am I investing in?  

You’re buying **bonds or T‑bills that the Government of India has issued**. Because the sovereign itself backs them, they’re practically risk‑free – the fancy term is *Sovereign Guarantee*.  

### What are bonds/T‑bills?? Tell me more.  

Think of a loan you’d take from a bank: you get cash now, promise to pay interest every now and then, and return the principal at the end. The government does the same thing, just on a massive scale (roads, bridges, hospitals, you name it).  

When the government runs short of cash, it asks the RBI (its “bank of banks”) for a loan. The RBI then **auctions** that loan to you and other investors in the form of bonds (long‑term) and T‑bills (short‑term). In return, the government promises periodic interest **and** the return of the principal when the instrument matures.  

- **T‑bills** = loans the government will repay *within a year*.  
- **Bonds** = loans stretched over many years.  

### What should I choose? T‑Bills or Bonds?  

Both are solid choices if you care about capital safety. The decision boils down to a few simple variables that we’ll walk through.  

### Variables like what? Start with T‑bills, please.  

T‑bills come in three flavors, distinguished by maturity: **91 days, 182 days, and 364 days**. The biggest twist? **No coupon (interest) payment**. Instead, they’re sold at a discount to their *par* (face) value, and you get the full par back at maturity.  

### Woah! That sounds complex. Give me an example, please!  

Alright, imagine a 91‑day T‑bill with a face value of **₹100**. The auction price is **₹97** (that’s the discount). Hold it for 91 days, and you’ll receive ₹100. Your profit? **₹3**.  

It’s like buying a stock at ₹97, selling it three months later at ₹100—except the market can’t make you lose that ₹3 because the government guarantees it.  

### This sounds quite straightforward, is there anything else I need to know about T‑bills?  

That’s the core idea: *discounted issue price → par at maturity*. If you’re feeling nerdy, you can also compute the **annualised yield**.  

### I’m all ears, let’s get technical!  

Yield tells you the **annualised return** on your money. Even though you only held the bill for 91 days, we express the return as if you could repeat the trade for a full year.  

The formula is  

\[
\text{Yield}= \frac{\text{Discount}}{\text{Purchase Price}} \times \frac{365}{\text{Days to Maturity}}
\]

Plugging the numbers:  

\[
\frac{3}{97} \times \frac{365}{91}=0.0309 \times 4.010989 \approx 12.4052\%
\]

So the *annualised* return looks like **12.41 %**. In practice, 91‑day yields float around **6 %–7.5 %** (the higher, the merrier).  

### What happens upon maturity of a T‑bill?  

When the 91‑day countdown ends, the government automatically **extinguishes** the security from your DEMAT account and deposits the ₹100 face value into the bank account linked to that DEMAT.  

### Is that all about T‑bills? Anything else I should know?  

That’s the whole shebang. You now know the discount‑to‑par mechanics, the yield formula, and the settlement process. Go forth and buy!  

### Alright, tell me how the bonds work.  

Bonds differ in two major ways:  

1. **Longer maturities** (often 5‑30 years).  
2. **Semi‑annual coupon payments** (you get interest twice a year).  

### Sounds interesting. Can you give me an example?  

Every bond carries a **symbol** that packs all the vital stats. Take **740GS2035A**:  

| Symbol part | Meaning |
|-------------|---------|
| **7.40**    | Annual coupon = 7.40 % |
| **GS**      | Government Securities |
| **2035**    | Maturity year (2035) |
| **A**       | Issue series (A = fresh issue, internal NSE code) |

So this bond will pay **7.40 % per year** until 2035, but the cash arrives **twice a year**: **3.70 %** every six months. At the end of 2035 you also get back the principal (the *par* value).  

Below are a few more GS symbols (the original chart omitted the actual list, but you get the idea).  

### Can you give me an illustration to help me understand how much I earn if I were to invest in a bond?  

Sure thing—first, a quick reminder about **price vs. par**.  

- **Par** is the face value, usually **₹100**.  
- You can buy a bond **at a discount** (₹98, ₹97, …), **at par** (₹100), or **at a premium** (₹101, ₹102, …).  
- The price you actually pay is set by an **auction** (we’ll cover that later).  

**Example:**  

- Bond: **700GS2020** (7 % coupon, matures in 2020 – two years from the 2018 baseline).  
- Purchase price: **₹98.4** (discount).  
- Quantity: **150** bonds.  

Cash outlay:  

\[
150 \times 98.4 = ₹14,760
\]

**Interest cash‑flows:** Interest is calculated on *par* (₹100), not on the purchase price.  

- Annual coupon: 7 % of ₹100 = ₹7 per bond.  
- Semi‑annual payment: ₹3.5 per bond.  

Over two years you receive **four** coupons:  

\[
150 \times 3.5 = ₹525 \text{ (per half‑year)}
\]

Total interest earned:  

\[
4 \times ₹525 = ₹2,100
\]

Add the **par repayment** at maturity:  

\[
150 \times 100 = ₹15,000
\]

**Grand total cash received:**  

\[
₹2,100 + ₹15,000 = ₹17,100
\]

**Yield** (approx):  

\[
\frac{₹17,100 - ₹14,760}{₹14,760} \approx 15.86\% \text{ over 2 years} \Rightarrow \text{annualised} \approx 7.88\%
\]

(The RBI’s official yield‑calculation guide lines up with this.)  

### I’ve heard the term ‘Yield to Maturity’, is this the same?  

Not exactly. **Yield to Maturity (YTM)** assumes you **re‑invest every coupon** you receive into an identical bond, letting you earn “interest on interest”. Institutional traders love YTM because it gives a *single* comparable number across bonds of different coupons and maturities. It’s the bond‑world equivalent of a stock’s **total return** (price appreciation + re‑invested dividends).  

### Alright, tell me about the interest payment? How does it get paid?  

The semi‑annual coupon lands directly into the **bank account linked to your DEMAT**—just like a dividend credit. No need to chase a cheque; the money appears automatically.  

### Can you give me some insights into the auction process?  

Historically, **only banks and big institutions** could buy G‑Sec bonds/T‑bills, with a **minimum ticket size of ₹5 crore**. The game changed when NSE & RBI opened the door to **retail investors** with a **₹10,000 minimum** (and multiples thereof).  

**How the price is set:**  

1. Banks and large players submit **bids** on the RBI’s auction platform, stating how much they’re willing to pay.  
2. RBI aggregates these bids and computes a **weighted average price (WAP)**.  
3. That WAP becomes the **official issue price** for the security.  

So the auction is simply a **price‑discovery mechanism**.  

### So it is the weighted average price of the bond, the price I need to pay to purchase the bonds?  

*Kind of.* When you place your order, you initially pay an **“amount payable”** that’s a tiny bit higher than the eventual WAP. Once the auction clears, any **excess** you paid (the difference between amount payable and the final WAP) is **refunded the next business day**.  

### Wait for a second, what do you mean by ‘option to sell in secondary market’?  

Exactly like stocks. After you’ve been allotted a bond (say **740GS2035A**), you can hold it for the full 17 years **or** you can sell it on the **secondary market** whenever you fancy cashing out. The process mirrors equity trading on the NSE.  

If you ever want a deeper dive, check out the **Trading Q&A** post on selling G‑Secs.  

### Great! It looks like I’ve got my basics right. Is there anything else that I need to know?  

Think of the whole lifecycle as an **IPO → listing → trading** sequence:  

- **Auction** = the IPO (price discovery).  
- **Listing** = the bond (or T‑bill) appears on the exchange after the auction.  
- **Secondary market** = you can trade it any time, just like a listed stock.  

**Key numbers:**  

- **Minimum ticket size:** ₹10,000 (and any multiple).  
- **Maximum ticket size:** ₹2 crore.  
- **Auction calendar:** RBI publishes dates well in advance, so you can plan.  

Here are the upcoming **T‑bill auction dates** (copy‑paste into your calendar):  

*Insert calendar table from original source*  

And the upcoming **bond auction dates**:  

*Insert calendar table from original source*  

For a full list of all bonds ever issued by the RBI (including coupon, maturity, and symbol), see the **RBI bond list** link. Pay special attention to the **coupon rate** and **maturity year**—they’re the two numbers that determine your cash flow.  

### What are SDLs?  

State governments also need money, and they raise it via **State Development Loans (SDLs)**. Think of SDLs as the **state‑level cousins** of central‑government bonds:  

- Same **semi‑annual coupon** structure.  
- Principal repaid at maturity.  
- Count toward **Statutory Liquidity Ratio (SLR)** for banks.  
- Accepted as **collateral** in repo transactions and under the RBI’s **Liquidity Adjustment Facility (LAF)**.  

For the official RBI FAQ on SDLs, click the link in the original article.  

### Here is the calendar for the upcoming SDL auctions.  

*Insert SDL auction calendar image*  

### How does the Floatation and Yield of SDLs work?  

RBI conducts SDL auctions **fortnightly** on its **Negotiated Dealing System‑Order Matching (NDS‑OM)** platform. Below is a snapshot (as of Oct 12 2020) of some SDLs up for auction:  

![Image](https://zerodha.com/varsity/wp-content/uploads/2018/05/SDLs-1024x441.png)  

Each SDL carries a unique **symbol**. Example: **05.75APSDL2024**  

| Symbol part | Meaning |
|-------------|---------|
| **05.75**   | Annual coupon = 5.75 % |
| **AP**      | State code = Andhra Pradesh |
| **SDL**     | State Development Loan |
| **2024**    | Maturity year = 2024 |

So a buyer of this security gets **5.75 % per year**, paid **2.875 % every six months**, and the face value back in 2024.  

### What about the Risk Assessment?  

Central‑government G‑Secs enjoy an **implicit sovereign guarantee** (the government’s “I’ve got your back” promise).  

SDLs, on the other hand, have an **explicit sovereign guarantee** under RBI’s CRAR (Capital to Risk‑Weighted Assets Ratio) norms: **risk‑weight = 0 %**. Banks need **no capital** against SDL holdings, making them *effectively* risk‑free for institutional investors.  

### What about taxes?  

| Instrument | Tax treatment |
|------------|----------------|
| **Bonds** (interest) | Taxed as **“Income from Other Sources”** at your marginal slab. Capital appreciation = **Capital Gains** – LTCG (held > 3 years) taxed at **10 % flat** (or 20 % with indexation). STCG taxed at slab. |
| **T‑bills** (discount) | The *discount* (par – purchase price) is treated as **short‑term capital gain** → taxed at your slab. |
| **G‑Sec overall** | Holding period ≤ 3 years → **STCG**; > 3 years → **LTCG** (same rates as above). |

*(Always double‑check with a tax advisor; laws change faster than a stock price on earnings day.)*  

### Will I get assured allotment if I place my order?  

Nope. These securities are issued in **limited quantities**. If demand outstrips supply, you might get **partial or no allotment**. The good news: RBI runs **multiple issues each month**, so you can try again next round.  

### This sounds good. How do I start?  

1. **Open a DEMAT account** (if you don’t have one already).  
2. **Link a bank account** to that DEMAT.  
3. **Log into NSE’s G‑Sec portal** (or use your broker’s platform).  
4. **Pick an auction date**, decide the amount (₹10,000‑₹2 crore), and submit your bid.  
5. **Wait for the auction result** – any excess amount you paid gets refunded the next day.  
6. **Enjoy the coupons or discount‑gain**, and trade later if you wish.  

Happy investing! 🎉  

---

*Got questions, jokes, or a funny meme about bonds? Drop them in the comments below. We’ll keep the conversation rolling!*