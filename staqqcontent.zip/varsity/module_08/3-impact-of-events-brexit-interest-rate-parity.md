# 3. Impact of events (Brexit) & Interest Rate Parity  

**Source:** https://zerodha.com/varsity/chapter/impact-of-events-brexit-interest-rate-parity/

---  

##  

![Image](http://zerodha.com/varsity/wp-content/uploads/2016/06/M8C3-cartoon-1.png)  

## 3.1 – Brexit, the event extravaganza!  

I had every intention of turning this whole chapter into a love‑letter to the USD‑INR pair – after all, it’s the heavyweight champion of Indian FX trading. Then, out of the blue, the Brexit bomb dropped, and I couldn’t ignore it. Why? Because it’s the perfect, real‑world case study for the “events and their impact on currency pairs” theme we just covered.  

**Quick snapshot:** The British pound (GBP) nosedived **8.64 %** after the vote. In FX terms, that’s the equivalent of a marathon runner tripping on the starting line and landing flat on his face.  

![Image](http://zerodha.com/varsity/wp-content/uploads/2016/06/Image-1_GBP_Brexit.png)  

The Guardian’s front‑page reaction looked something like this:  

![Image](http://zerodha.com/varsity/wp-content/uploads/2016/06/Image-2_Press-note.png)  

(You can read the full article if you fancy a bedtime story.)  

My mission here is to break down Brexit in plain English, sprinkle in a dash of humor, and—most importantly—show you how a headline‑making political event can send currencies into a tailspin. By the end, you’ll be able to look at any global news flash, ask the right questions, and gauge its potential FX fallout.  

### Brexit in a nutshell (bullet‑point style, because who has time for long prose?)

- **Post‑WWII origins:** After the Second World War, the great powers of Europe (think Germany and France) started flirting with the idea of a “union” to make war between neighbours as unlikely as a British summer. The logic: trade and cooperation = peace.  
- **Birth of the EU:** That flirtation grew into the European Union, a club where goods, services, and even people could zip across borders like they were at a family reunion.  
- **The Euro’s debut:** The EU eventually rolled out a common currency, the Euro, to make cross‑border payments smoother than a fresh jar of Nutella.  
- **Britain’s stubbornness:** The United Kingdom, while a member of the EU, kept the Pound sterling as its own money. (It’s not the only outlier—Switzerland, the Czech Republic, Denmark, and a few others also stick with national currencies.)  
- **The “Leave” rumblings:** In the years leading up to 2016, a sizable chunk of the British electorate started grumbling that EU rules were more of a tax on their wallets than a benefit. The slogan “Take Back Control” became the political equivalent of a meme that just wouldn’t die.  
- **Enter “Brexit”:** The term “Brexit” (Brit‑ain + exit) became the shorthand for the UK’s potential departure from the EU.  
- **The referendum:** On **23 June 2016**, the British government asked citizens to vote “Remain” or “Leave” in a nationwide referendum.  
- **The shocker:** Against most pundits’ expectations, the “Leave” camp won with about 52 % of the vote. The markets collectively gulped.  

The result? The pound plunged to a **31‑year low**, while major European equity indices slumped **8‑10 %** in a single day—think of it as the market’s version of a collective “oh‑no” facepalm.  

### Why did the markets freak out?  

Remember our previous chapter where we said a strong economy (low inflation, sensible interest rates, modest trade deficits) tends to prop up a strong currency? The UK ticks many of those boxes: it’s a heavyweight economy, a major contributor to the EU, and historically a safe‑haven for investors.  

However, the vote introduced two massive unknowns:

1. **Economic decoupling:** The UK enjoys a **trade surplus with the EU** (i.e., it sells more to the EU than it buys) while running a **trade deficit with the rest of the world**. Pulling the plug on EU ties means that surplus could evaporate, denting growth.  
2. **Policy fog:** What will the Bank of England do? Slash rates to zero? Keep them steady? The lack of a clear policy roadmap makes traders nervous—remember, uncertainty is the market’s kryptonite.  

When traders see a big‑ticket event that could swing an economy’s fundamentals in any direction, they usually hit the panic button, sell the currency, and the price slides down.  

**Pro tip for a budding FX trader:** If you’ve studied the event, weighed the pros and cons, and concluded “I’ll stay out of this trade,” you’ve actually made a winning move. The age‑old mantra “When in doubt, do nothing” still holds true—especially when the news feels like a political thriller you didn’t sign up for.  

Bottom line: Ignoring a seismic event and blindly trading is like playing roulette with a blindfold on. Know the story first, or you’ll end up betting on a horse that never left the starting gate.  

That’s the Brexit saga in a nutshell, and a reminder that geopolitical fireworks can light up currency charts faster than you can say “exchange‑rate volatility.”  

Let’s now glide over to a more theoretical playground: the world of “fair trades” and why they’re only fair in fairy tales.  

## 3.2 – Fairy Trade  

Picture a utopia where you could **borrow cheap money in one country, invest it in another at a higher rate, and pocket the spread—risk‑free.** Sounds like a dream, right? Let’s walk through a concrete (yet slightly magical) example.  

1. **Borrow in the U.S.:** The Federal Reserve is playing nice, offering a **0.5 %** policy rate—the lowest you’ll find on the planet. You snag a **$10,000** loan at that rate.  
2. **Convert to rupees:** At today’s spot of **₹67 per $1**, your loan becomes **₹670,000**.  
3. **Invest in India:** Indian banks are handing out **7 %** interest (let’s take the high end for drama). You park the ₹670,000 there for a year.  

**End‑of‑year balance in India:**  

\[
₹670{,}000 + 0.07 \times ₹670{,}000 = ₹670{,}000 + ₹46{,}900 = ₹716{,}900
\]

4. **Convert back to dollars:** Assuming the exchange rate is still **₹67/$**, you now have  

\[
\frac{₹716{,}900}{67} \approx \$10{,}700
\]

5. **Repay the U.S. loan:** You owe the original **$10,000** plus **0.5 %** interest = **$10,050**.  

**Profit:**  

\[
\$10{,}700 - \$10{,}050 = \$650
\]

That **$650** is precisely the interest‑rate differential (7 % – 0.5 % = 6.5 %) applied to the $10,000 principal:  

\[
\$10{,}000 \times 6.5\% = \$650
\]

Boom—risk‑free arbitrage! In a perfect world, you could repeat this ad infinitum, growing your nest‑egg faster than a rabbit on a treadmill.  

**Reality check:** This is the kind of trade that lives only in storybooks, Disney movies, and the occasional “how‑to‑get‑rich‑quick” forum post. In the real world, a host of frictions (capital controls, taxes, transaction costs, and, most importantly, exchange‑rate movements) swoop in like the Wicked Witch of the West and wipe out the profit.  

So why can’t we pull off this “fair trade” in practice? The answer lies in the next section.  

## 3.3 – Forward Premia & Interest Rate Parity  

Our fairy‑trade scenario made **four** (actually five) unrealistic assumptions:  

- Unlimited borrowing in the U.S.  
- Unlimited lending in India  
- Zero transaction costs, taxes, or regulatory hurdles  
- Seamless, frictionless currency conversion  
- **Most crucial:** The exchange rate stays at **₹67/$** after one year  

If any of those assumptions break (and they all do), the arbitrage evaporates. In a well‑behaved market, the forward exchange rate will adjust precisely to **nullify** the profit opportunity. In other words, the amount you receive in rupees after a year must be worth exactly what you owe in dollars, once you convert at the forward rate.  

Let’s use our numbers to find the **break‑even forward rate**.  

We borrowed **$10,000**, invested it, and ended up with **₹716,900**. To avoid arbitrage, that rupee amount must be equivalent to the **$10,050** we have to repay.  

\[
\text{Forward rate } F = \frac{₹716{,}900}{\$10{,}050} \approx 71.33\;₹/\$ 
\]

That 71.33 figure is called the **forward premium**—the rate at which the market expects the rupee to **depreciate** relative to the dollar over the one‑year horizon.  

### The textbook formula  

\[
F = S \times \frac{1 + r_{\text{quote}} \times N}{1 + r_{\text{base}} \times N}
\]

where  

- \(F\) = forward (future) rate  
- \(S\) = spot (today’s) rate (₹67/$)  
- \(N\) = time in years (1)  
- \(r_{\text{quote}}\) = interest rate of the **quote** currency (the currency on the right side of the pair, i.e., INR = 7 %)  
- \(r_{\text{base}}\) = interest rate of the **base** currency (the left‑side currency, i.e., USD = 0.5 %)  

Plugging in the numbers:  

\[
F = 67 \times \frac{1 + 0.07}{1 + 0.005} = 67 \times \frac{1.07}{1.005} \approx 71.33
\]

That matches our back‑of‑the‑envelope calculation.  

A handy shortcut that many traders use (especially when the rates are small) is:  

\[
F \approx S \times \bigl[1 + (r_{\text{quote}} - r_{\text{base}})\bigr]
\]

\[
F \approx 67 \times \bigl[1 + (7\% - 0.5\%)\bigr] = 67 \times 1.065 \approx 71.35
\]

Both methods give you virtually the same answer.  

### Interest Rate Parity (IRP) in plain English  

**Interest Rate Parity** tells us that the **forward premium** (or discount) of a currency is driven by the **interest‑rate differential** between the two economies. If a country offers a higher interest rate than its counterpart, its currency will **sell at a forward discount** (it’s expected to be worth less in the future). Conversely, a low‑rate currency trades at a forward premium.  

In our example, the rupee’s higher rate (7 % vs. 0.5 %) forces the forward rate to be **higher** (₹71.33/$) than the spot (₹67/$). That means the rupee is priced at a **discount** in the forward market.  

Why does this matter to a trader? Because forward contracts, futures, and many derivative products use the forward rate as a baseline. Understanding IRP helps you anticipate where those prices should logically sit, and spot mispricings (if any) that could be exploited—always remembering that true arbitrage is quickly erased by savvy market participants.  

We’ll dig deeper into futures pricing later, but for now, keep this mental picture: **Higher‑interest‑rate currency → forward discount; lower‑interest‑rate currency → forward premium.**  

### Key takeaways  

- **Big‑ticket events** (Brexit, elections, wars) can wrench currency values dramatically.  
- A country expected to **suffer economically** typically sees its currency **weaken**.  
- **Forward premium** = the market’s expectation of the future spot rate, adjusted for the interest‑rate gap.  
- The **formula** is  
  \[
  F = S \times \frac{1 + r_{\text{quote}}N}{1 + r_{\text{base}}N}
  \]  
- **Interest‑Rate Parity** (IRP) tells us the forward premium ≈ spot × (1 + interest‑rate‑difference).  
- **Higher‑interest‑rate** currencies trade at a **forward discount** relative to lower‑interest‑rate currencies.  

Armed with this knowledge, you’ll be better equipped to read headlines, sniff out potential currency moves, and understand why the forward market behaves the way it does. Cheers to turning geopolitics and math into your trading side‑kick!  