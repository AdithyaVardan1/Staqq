# 14. Lead & Nickel  

**Source:** https://zerodha.com/varsity/chapter/lead-nickel/  

---  

## 14.1 – Lead – some history, some basics  

![Image](http://zerodha.com/varsity/wp-content/uploads/2017/01/M8-C14-Cartoon1.png)  

Picture this: you’re watching a Hollywood epic about the fall of Rome, and the hero‑villain isn’t a barbarian or a corrupt senator, but a *metal* that looks like a dull, heavy pencil. Yep, that’s **lead**. It didn’t conquer the empire with swords, it did it by *quietly* contaminating the water supply of the very people who decided where the legions would march.  

I’m not trying to turn this into a lecture on ancient history (my toga is at the dry cleaners), but the story is worth a quick pint‑level retelling because it shows how a seemingly “boring” commodity can have world‑shaking consequences.  

### Why Lead is a *special* metal  

- **Lustrous and heavy** – it shines like a greased pig, and you’ll feel your forearm burn if you try to lift a big chunk.  
- **Super‑malleable & ductile** – you can flatten it like play‑dough, which is why the Romans liked it for pipes.  
- **Poor conductor of electricity** – it won’t light up your Christmas tree, but that’s not why we love it.  
- **Corrosion‑resistant** – it won’t rust away in a century‑old aqueduct.  
- **Very dense** – 11.34 g/cc, so a handful feels like a small dumbbell.  
- **Reasonably abundant** – you can find it in the Earth’s crust at about 14 ppm, which is “enough for industry, not enough for gold‑fishing.”  

Lead is actually the **earliest metal** humans learned to work with. Archaeologists have unearthed lead figurines from Egypt dated to **~4,000 BC**—talk about a “first‑metal” badge of honor.  

The **Roman Empire** was the lead‑using champion of antiquity. They poured it into:

- Water pipes and aqueducts (the original “plumb‑line” pride)  
- Tank linings and cooking pots (because who needs stainless steel?)  
- Cosmetics (lead‑based face paint, because “pale as death” was the fashion).  

Check out this classic Roman‑era pipe:  

![Image](http://zerodha.com/varsity/wp-content/uploads/2017/01/Image-1_Lead-pipe-1.jpg)  

*Source: Welcome Images, UK*  

Back then, having a **lead pipe** in your villa was a status symbol. The owner’s name was even **etched onto the pipe**—the ancient version of a personalized vanity plate. Imagine bragging, “My water comes straight from *Marcus Aurelius*’s lead line!”  

### The toxic twist  

Unlike iron (which our bodies can at least tolerate in small amounts), **lead is a poison**. It accumulates in the brain, kidneys, and blood, causing everything from anemia to “I can’t remember where I left my empire.” The Roman aristocracy—who drank the most water straight from these pipes—suffered heavy lead exposure. Some historians even argue that chronic lead poisoning contributed to *decision‑making fatigue* at the top, nudging the empire toward its eventual collapse.  

I’m no Caesar‑era doctor, but the correlation is *interesting enough* to keep a footnote in any discussion about why the Romans fell.  

### Modern uses (minus the poison)  

Fast‑forward a couple of millennia and we’ve learned to **respect** lead’s strengths while **avoiding** its weaknesses. Today you’ll find it in:

| Application | Why Lead? |
|---|---|
| **Solders** | Low melting point = easy joins |
| **Industrial linings** (sinks, tanks, reactors) | Corrosion resistance |
| **Radiation shielding** | Heavy atoms stop gamma rays |
| **Lead‑acid batteries** | Largest single use; cheap and recyclable |
| **Cable sheathing** | Flexible, cheap, blocks electromagnetic interference |
| **Pigments & compounds** | Gives vivid reds, yellows, and blues |
| **Shipbuilding** | Ballast and anti‑corrosion coatings |

*Fun fact:* The “lead” in a **pencil** isn’t lead at all—it’s **graphite** (pure carbon). The misnomer stuck because people thought the dark, metallic‑looking core looked like lead.  

### Supply‑demand snapshot  

The **lead market** has been relatively calm over the past few years. Take a look at the supply‑demand curve (source: ILZSG):  

![Image](http://zerodha.com/varsity/wp-content/uploads/2017/01/Image-2_Lead-supply-demand-1.png)  

*Source: www.ilzsg.org*  

### Price action  

Lead’s price has **huddled in a tight range** for a long time. Here’s a long‑term chart that shows the lull (pay special attention to the last few years, when the price hovered around ₹130‑₹150 per kg):  

![Image](http://zerodha.com/varsity/wp-content/uploads/2017/01/Image-3_Lead-long-term-1.png)  

If you’re thinking of **trading Lead futures on MCX**, treat it like a **technical‑only** game. The fundamentals (supply, demand, battery demand, etc.) move so slowly they’re practically a backdrop. I’d **avoid** news‑driven entries and focus on price patterns, support‑resistance, and volume spikes.  

> *Pro tip:* If you *must* dive into fundamentals, click **[here]** for a comprehensive data dump. (Spoiler: it’s a PDF thicker than a Roman column.)  

---  

## 14.2 – Contract Specifications  

Let’s break down the **Lead contracts** that MCX offers. As with most commodities, you get a **big** and a **mini** version.  

### Lead (Big)  

| Spec | Value |
|---|---|
| **Price Quote** | Per kilogram |
| **Lot Size** | **5 metric tonnes** = 5,000 kg |
| **Tick Size** | ₹0.05 |
| **P&L per Tick** | ₹0.05 × 5,000 = ₹250 |
| **Expiry** | Last trading day of the month |
| **Delivery Unit** | 10 MT (the physical delivery quantity) |

A snapshot of the **Jan 2017** Lead contract:  

![Image](http://zerodha.com/varsity/wp-content/uploads/2017/01/Image-4_Lead-big.png)  

*Price = ₹137.05 / kg*  

**Contract value** = 5,000 kg × ₹137.05 = **₹685,250**  

**Margins** (as shown on the MCX portal):  

![Image](http://zerodha.com/varsity/wp-content/uploads/2017/01/Image-5_Lead-big-margin.png)  

- **NRML** (overnight) = ₹80,482 → **≈ 11.7 %** of contract value  
- **MIS** (intraday) = ₹40,241 → **≈ 5.9 %**  

That’s one of the **highest margin percentages** you’ll see in commodities—good to know your cash sits tighter than a Roman senator’s purse.  

### Lead Mini  

| Spec | Value |
|---|---|
| **Price Quote** | Per kilogram |
| **Lot Size** | **1 metric tonne** = 1,000 kg |
| **Tick Size** | ₹0.05 |
| **P&L per Tick** | ₹0.05 × 1,000 = ₹50 |
| **Expiry** | Last trading day of the month |
| **Delivery Unit** | 10 MT (same physical delivery as the big contract) |

Snapshot for **Jan 2017** Lead Mini:  

![Image](http://zerodha.com/varsity/wp-content/uploads/2017/01/Image-6_Lead-mini.png)  

*Price = ₹137.50 / kg*  

**Contract value** = 1,000 kg × ₹137.50 = **₹137,500**  

**Margins:**  

![Image](http://zerodha.com/varsity/wp-content/uploads/2017/01/Image-7_Lead-mini-margin.png)  

- **NRML** = ₹16,442 → **≈ 11.7 %**  
- **MIS** = ₹8,221 → **≈ 5.9 %**  

Because the **lot size is five‑times smaller**, the **cash outlay** is also five‑times lower, but the **margin percentage stays the same**. Perfect for traders who want exposure without selling a kidney.  

---  

## 14.3 – Lead contract logic  

MCX rolls out a **new contract every month**, and each contract expires **on the last business day of the fifth month** after its introduction. Example:  

- **January 2017** sees the launch of the **May 2017** contract.  
- That May 2017 contract will **expire on the last working day of May 2017**.  

Meanwhile, the **January 2017** contract itself expires **at the end of January**.  

The **timeline** looks like this (illustrated below):  

![Image](http://zerodha.com/varsity/wp-content/uploads/2017/01/Image-8_Lead-delivery-logic.png)  

Why the five‑month lead‑time? It guarantees that **there is always a “current‑month” contract** actively trading. However, liquidity **peaks in the contract’s final month**, because that’s when traders roll over positions.  

**Takeaway:** Trade the **current‑month contract** for the best bid‑ask spreads. Tighter spreads mean **lower impact cost**, which translates to *less money slipping through your fingers when you hit the market order button*.  

---  

## 14.4 – Nickel basics  

Nickel is the **Swiss‑army‑knife metal** of the modern world. From **stainless steel** (the backbone of cutlery, appliances, and skyscraper exteriors) to **batteries**, **electronics**, **medical implants**, and **automotive parts**, you’ll find nickel in almost everything that doesn’t want to rust.  

- **~65 %** of global nickel production ends up in **stainless steel**.  

### Nickel demand‑supply picture  

![Image](http://zerodha.com/varsity/wp-content/uploads/2017/01/Image-9_Nickle_demand-supply.png)  

The chart shows **production > demand**, a classic **oversupply** scenario.  

### Price trend  

Because supply outpaces demand, **Nickel prices have been on a down‑trend** over the past year:  

![Image](http://zerodha.com/varsity/wp-content/uploads/2017/01/Image-10_Nickel-long-term.png)  

My trading mantra for Nickel mirrors Lead’s: **focus on price action, not macro fundamentals** (unless you enjoy watching long‑term supply‑demand dramas).  

---  

## 14.5 – Contract Specifications of Nickel  

Just like Lead, Nickel comes in a **big** and a **mini** contract.  

### Nickel (Big)  

| Spec | Value |
|---|---|
| **Price Quote** | Per kilogram |
| **Lot Size** | **250 kg** |
| **Tick Size** | ₹0.10 |
| **P&L per Tick** | ₹0.10 × 250 = ₹25 |
| **Expiry** | Last business day of the month |
| **Delivery Unit** | 3 MT (the physical amount delivered) |

Snapshot of the **Jan 2017** Nickel contract:  

![Image](http://zerodha.com/varsity/wp-content/uploads/2017/01/Image-11_Nickel-big-quote.png)  

*Price = ₹685.50 / kg*  

**Contract value** = 250 kg × ₹685.50 ≈ **₹1,71,375** (the original sheet used ₹686.5, so we’ll keep the official number **₹1,71,625**).  

**Margins:**  

![Image](http://zerodha.com/varsity/wp-content/uploads/2017/01/Image-12_Nickel-margin.png)  

- **NRML** = ₹16,924 → **≈ 10 %** of contract value  
- **MIS** = ₹8,462 → **≈ 5 %**  

### Nickel Mini  

| Spec | Value |
|---|---|
| **Price Quote** | Per kilogram |
| **Lot Size** | **100 kg** |
| **Tick Size** | ₹0.10 |
| **P&L per Tick** | ₹0.10 × 100 = ₹10 |
| **Expiry** | Last business day of the month |
| **Delivery Unit** | 3 MT |

Snapshot of **Jan 2017** Nickel Mini:  

![Image](http://zerodha.com/varsity/wp-content/uploads/2017/01/Image-13_Nickel-mini-quote.png)  

*Price = ₹686.00 / kg*  

**Contract value** = 100 kg × ₹686 = **₹68,600**  

**Margins:**  

![Image](http://zerodha.com/varsity/wp-content/uploads/2017/01/Image-14_Nickel-mini-margin.png)  

- **NRML** = ₹6,694 → **≈ 10 %**  
- **MIS** = ₹3,347 → **≈ 5 %**  

The **margin percentages** line up perfectly with the big contract, but the **cash requirement** is much lower—ideal for traders who want to dip a toe without drowning.  

### Contract rollout  

Nickel contracts follow the **same monthly rollout** as Lead: a new contract is launched each month, and the **current‑month contract** carries the deepest liquidity. Stick to it for tighter spreads and smoother fills.  

---  

### Key takeaways from this chapter  

- **Two Lead futures:** *Lead* (5 MT) and *Lead Mini* (1 MT).  
- **P&L per tick:** ₹250 for Lead, ₹50 for Lead Mini.  
- Lead’s **supply‑demand** curve has been **stable** in recent years.  
- **Two Nickel futures:** *Nickel* (250 kg) and *Nickel Mini* (100 kg).  
- **P&L per tick:** ₹25 for Nickel, ₹10 for Nickel Mini.  
- Nickel **production > demand**, which explains the recent price dip.  
- For both metals, **trade the current‑month contract** to enjoy the best liquidity and narrow spreads.  
- **Price‑action dominates** short‑term trades; fundamentals move too slowly to be useful intraday.  

Now you’ve got the low‑down on Lead and Nickel—no more “heavy” reading, just the heavy metal you need for your next trade! Cheers! 🍻  