# 7. Gold (Part 1)

**Source:** https://zerodha.com/varsity/chapter/gold-part-1/

---  

## 7.1 – Orientation  

Alright, let’s set the stage. India has two big‑kid commodity exchanges: the **Multi Commodity Exchange (MCX)**, which is basically the heavyweight champion for Metals & Energy, and the **National Commodity and Derivative Exchange (NCDEX)**, the go‑to for everything that grows out of the ground (think wheat, soybeans, etc.).  

Lately, MCX is getting a little *agri‑couch‑potato* vibe, with some farmers‑friendly contracts creeping onto its floor. Over the next few chapters I’ll walk you through the contracts you can actually trade, point out the quirks in the fine print, and show you what makes the price wiggle.  

I’m skipping the “once‑upon‑a‑time” lecture about the Chicago Mercantile Exchange, forward markets, and the farmer who sold his corn for a song and a dance. You can find that stuff in any dusty textbook. Instead, we’ll slice straight into the juicy bits: contract specs, which contract is the right one for you, and the forces that push the price around.

Below is the roster of metal‑and‑energy goodies you can pick on MCX (yup, straight from the MCX website – no typo‑hunting here).

![Image](http://zerodha.com/varsity/wp-content/uploads/2016/08/Image-1_A-list.png)

We’ll eventually cover **all** the major tradable commodities, but first you need to be comfortable with *derivative futures* – otherwise you’ll feel like you’re trying to ride a bike with the training wheels off. If futures are still a mystery, hit the “module on futures trading” before you keep scrolling.

Assuming you’ve already taken the futures crash‑course, let’s get our hands dirty with the most glittery of them all: **Gold**.

![Image](http://zerodha.com/varsity/wp-content/uploads/2016/08/M8C7-cartoon.png)

---

## 7.2 – The Gold Contract  

Gold isn’t just the “shiny thing on the king’s crown”; on MCX it’s a beast of a contract with **≈ 15,000 contracts a day**, which translates to **> ₹4,500 crore** of turnover. That’s the “Big Gold” – the heavyweight champion of MCX.

But hold up. Newbies (and even some seasoned traders) often get tangled in the alphabet soup of gold contracts, not knowing which one to pick. Let’s list them first, then we’ll break down why they exist.

| Variant | Nickname |
|---------|----------|
| **Gold (The Big Gold)** | “Big Boy” |
| **Gold Mini** | “Mini‑Gold” |
| **Gold Guinea** | “Guinea‑Gold” |
| **Gold Petal** | “Petal‑Gold” |

All four sit on the same **underlying** – pure gold – but their *contract specifications* differ like a 10‑kg barbell vs. a set of dumbbells. We’ll start with the biggest, because who doesn’t love a good “big‑boy” story?

### Contract Specification (Big Gold)

Below is the MCX spec sheet. I’ll pull out the headline numbers first, then explain each line in plain English (with a sprinkle of sarcasm).

| Parameter | Value | What it means |
|-----------|-------|----------------|
| **Price Quotation** | **10 g** | The price you see on the screen is for 10 grams, not a whole kilogram. |
| **Lot Size** | **1 kg (1,000 g)** | One contract = 1 kg of gold. |
| **Tick Size** | **₹1** | The smallest price movement. |
| **Tick Value** | **₹100** | How much cash you win/lose per tick (see calculation later). |
| **Contract Month** | Every 2 months, expiry on the **5th** | New contracts appear bimonthly; they die on the 5th of the month. |
| **Margin (Initial)** | **≈ ₹1,25,868** | Cash you must stash to open a position (≈ 4 % of contract value). |

#### Price Quote – the 10‑gram trap  

If the live MCX screen shows **₹31,331**, that’s the price for **10 g** of gold *including* all import duties, GST, etc. (MCX is an “all‑inclusive” price). To get the value of one **1 kg** contract:

\[
\frac{1,000\text{ g} \times 31,331}{10\text{ g}} = ₹31,33,100
\]

So a single Big Gold contract is worth a **little over ₹31 lakh**.

#### Margin – why you need a small loan from your mom  

Zerodha’s margin calculator says you need **₹1,25,868** as the initial margin. That’s **4.02 %** of the contract value:

\[
\frac{1,25,868}{31,33,100} \times 100 \approx 4.02\%
\]

Four percent sounds cute, right? But the absolute number is a **quarter of a lakh**, which scares off many retail traders. That’s why Mini, Guinea, and Petal contracts exist – they lower the *cash* barrier, not the *percentage* barrier.

#### P&L per tick – the “₹100 per smile” rule  

Every time the price moves by **₹1** (the tick size), your profit or loss changes by:

\[
\text{P&L per tick} = \frac{\text{Lot Size}}{\text{Price Quotation}} \times \text{Tick Size}
\]

Plug in the numbers:

\[
\frac{1,000}{10} \times 1 = 100 \;\text{₹ per tick}
\]

So a 5‑point swing = **₹500** in your pocket (or the other way around). Same formula works for any futures/option contract. Quick sanity check: for the JPY/INR contract (lot = 100,000 JPY, quotation = 100 JPY, tick = 0.0025 ₹):

\[
\frac{100,000}{100} \times 0.0025 = 2.5\;\text{₹ per tick}
\]

#### Expiry calendar – “the 5th day drama”  

Gold contracts expire on the **5th day of the contract month**. A new series rolls out **every two months**, and at any moment you’ll see six overlapping contracts (think of them as six siblings constantly arguing over who gets the TV).  

Since we’re in **August 2016** in the original example, the active series look like this:

| Contract | Expiry |
|----------|--------|
| **June 2016** | 5 Jun 2016 |
| **August 2016** | 5 Aug 2016 |
| **October 2016** | **5 Oct 2016** (most liquid) |
| **December 2016** | 5 Dec 2016 |
| **February 2017** | 5 Feb 2017 |
| **April 2017** | 5 Apr 2017 |

When the October contract dies on 5 Oct, the **September 2017** series pops up, and the **December 2016** contract becomes the front‑runner.

#### Physical settlement – “bring your own gold”  

Equity futures settle in cash, but **commodity futures settle physically**. That means if you hold **10 lots of Gold** and you *choose* delivery, you’ll walk away with **10 kg of actual gold**. You have to raise your hand (formally, submit a delivery notice) **four days before expiry** – i.e., by the **4th** of the month.

Zerodha doesn’t let you actually take delivery, so you’re forced to **square off before the 1st of the expiry month**. Even I personally like to exit early; I’m not planning a home‑grown jewelry line anytime soon.

Bottom line: once you know the price quote, lot size, margin, tick value, expiry, and delivery rules, you’ve got the “gold contract cheat sheet” you need to start trading the Big Gold.

---

## 7.3 – The other contracts (Gold Mini, Gold Guinea, Gold Petal)  

Big Gold’s big‑boy margin (≈ ₹1.26 lakh) is a **wall** for many traders. The exchanges introduced smaller‑sized contracts to bring that wall down to a **speed‑bump**.

| Contract | Lot Size | Approx. Margin* | Approx. % Margin |
|----------|----------|----------------|-----------------|
| **Gold Mini (GoldM)** | 100 g | ₹15,682 | ~5 % |
| **Gold Guinea** | 10 g | ₹1,251 | ~5 % (tiny value) |
| **Gold Petal** | 8 g | ₹154 | ~5 % (tiny value) |

\*Numbers are based on a **₹31,365** price point (the same day the screenshot was taken).

### Gold Mini – the “Gold‑size‑down”

Contract value (using the same price as before):

\[
\frac{31,365 \times 100}{10} = ₹313,650
\]

Margin % =  

\[
\frac{15,682}{313,650} \times 100 \approx 5\%
\]

Same percentage as Big Gold, just a lot less cash outlay. P&L per tick:

\[
\frac{100}{10} \times 1 = ₹10 \text{ per tick}
\]

### Gold Guinea & Gold Petal – “Gold for the tiny‑handed”

These are **micro‑contracts** (10 g and 8 g respectively). The margin is pocket‑change, but so is the contract value. Liquidity can be thin, and the tick value is minuscule (₹1 per tick for Guinea, even less for Petal). They’re great for a **demo account** or for kids learning to trade, but not ideal for serious players.

### Liquidity check – numbers that matter  

On a typical MCX day you’ll see:

| Contract | Avg. Daily Lots Traded |
|----------|------------------------|
| **Big Gold** | 12‑13 K |
| **Gold Mini** | 14‑15 K |
| **Gold Guinea** | 1‑1.5 K |
| **Gold Petal** | 8‑9 K |

Looks like Petal trades the most lots, right? Not really. Remember, a Petal lot = **8 g**. So 9 K lots ≈ **720 g**, which is only **₹2‑2.5 crore** of turnover – a drop in the gold‑lake compared to the **₹12‑13 crore** (actually *₹31 crore*) from Big Gold.

**Rule of thumb:** **Liquidity is highest in the nearest‑month contract**, and it tapers off as you go further out. Always pick the front‑month unless you have a solid reason to stare into the crystal ball.

### My two‑cents  

If you’re serious about gold, stick to **Big Gold** or **Gold Mini**. They have deep order books, tighter spreads, and you won’t get stuck trying to exit a micro‑contract that nobody else wants to trade.

---

### Key takeaways from this chapter  

- **Gold** is the star bullion contract on MCX, with massive daily turnover.  
- It comes in **four flavors**: **Big Gold**, **Gold Mini**, **Gold Guinea**, **Gold Petal** – all backed by the same metal.  
- **Big Gold** needs a **≈ ₹1.26 lakh** margin (≈ 4 % of contract value) and moves **₹100 per tick**.  
- **P&L per tick** formula:  

  \[
  \text{P&L per tick} = \frac{\text{Lot Size}}{\text{Price Quotation}} \times \text{Tick Size}
  \]

- **Gold Mini** is the second‑most popular, with a **≈ ₹15.7 k** margin (≈ 5 %); it gives **₹10 per tick**.  
- **Gold Guinea** and **Gold Petal** have tiny margins (₹1,251 & ₹154) but also tiny liquidity; they’re mostly for hobbyists.  
- **Liquidity peaks in the nearest‑month contract**; the farther out you go, the thinner the market.  
- All contracts **settle physically**, so you must close or give delivery notice **by the 4th** of the expiry month. Zerodha forces you to close early, so you won’t end up with a safe‑deposit box of gold.  

Next up: we’ll dive into the *parity* between domestic and international gold contracts, the macro‑forces that rock gold’s price, and the love‑hate triangle between gold, equities, and the US dollar. Stay tuned – the glitter is just getting started!