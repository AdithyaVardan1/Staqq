# 18. Cross‑Currency Pairs  

**Source:** <https://zerodha.com/varsity/chapter/cross-currency-pairs/>  

---  

## 18.1 – All hail the king of Forex  

If you wander outside the Indian sub‑continent, you’ll quickly discover that the **forex futures market** is the rock‑star of all tradable arenas. From the kid who just opened a demat account to the hedge‑fund wizard with a beard longer than his spreadsheet, everyone’s got a foot in the forex‑futures pond.  
Take a look at the three heavyweight champions that dominate the ring:  

| Pair | Ticker | Nick‑name |
|------|--------|-----------|
| Euro vs. US Dollar | **EUR/USD** | – |
| British Pound vs. US Dollar | **GBP/USD** | “The Cable” |
| US Dollar vs. Japanese Yen | **USD/JPY** | – |

![Cartoon of the three big players](https://zerodha.com/varsity/wp-content/uploads/2018/03/M8-C18-cartoon.png)

**Back in the day…**  
If you wanted a slice of any of these global duos, you had to hunt down a little‑known broker on an island that most of us can’t even locate on a map (think Cyprus, Isle of Man, or some other “exotic” jurisdiction). You’d wire money across borders, pray the broker didn’t disappear, and trade on a quote that was shouted over a bad phone line. No Indian regulator was watching, so the whole thing felt a bit like buying a mystery box from a street magician.  

**Fast‑forward to 2024:**  
The National Stock Exchange (NSE) has finally gotten its act together and, under a full‑blown regulatory umbrella, now lists cross‑currency **futures and options**. The same three titans listed above can be bought and sold *directly* on NSE, with the usual investor protections you expect from a regulated Indian exchange.  

> **Trivia bite:** A BIS (Bank for International Settlements) survey tells us that **≈ 88 %** of all global forex turnover has the US Dollar on one side of the trade. Half of that action is split among EUR/USD, GBP/USD and USD/JPY. In other words, these three pairs are the *Musketeers* of the FX world—*all for one, and one for all.*  

### The anatomy of a currency pair  

When you see something like **EUR/USD**, the first ticker (EUR) is the **base currency**; the second (USD) is the **quote currency**. The pair is always expressed **in units of the quote currency**. So, a quote of **1.23421** simply means **1 Euro = 1.23421 US Dollars**.  

| Pair | Base | Quote |
|------|------|-------|
| EUR/USD | Euro | US Dollar |
| GBP/USD | British Pound | US Dollar |
| USD/JPY | US Dollar | Japanese Yen |

Imagine an order‑book for EUR/USD (just picture a ladder of bids and asks). If you place a **buy** order at **1.2431**, you’re saying “I’ll hand over 1.2431 USD for each Euro I get.” Conversely, a **sell** at **1.2429** means “I’ll give you one Euro and you’ll pay me 1.2429 USD.” Simple as that—just a fancy version of “I’ll trade you my soda for your chips.”  

---

## 18.2 – The Futures Contracts  

NSE didn’t stop at futures; it also rolled out **options** on the same three cross‑currency pairs. Realistically, options will take a little longer to catch fire (they’re the slow‑cooking stew of the derivatives kitchen), but the **near‑month futures** are already getting a lot of love from day‑traders.  

### Lot size – the magic number  

All three contracts share a **lot size of 1,000 units of the base currency**. In plain English:  

| Pair | Lot size (base) |
|------|-----------------|
| EUR/USD | 1,000 EUR |
| GBP/USD | 1,000 GBP |
| USD/JPY | 1,000 USD |

Why does this matter? Because the lot size tells you how many “units” you’re actually buying or selling, and it determines the tick value (the cash amount you earn or lose when the price moves by the minimum price increment).  

- **Tick size (aka “pip”)**  
  - EUR/USD & GBP/USD: **0.0001** (one pip = 0.0001 USD)  
  - USD/JPY: **0.01** (one pip = 0.01 JPY)  

There are **12 monthly contracts** rolling each calendar month. The *near‑month* contract expires **2 trading days before the last business day of the month**, giving you a tidy window to roll over or close out.  

---

## 18.3 – A Future Trade  

When you hold a cross‑currency future, your **profit & loss (P&L)** is reported in the **quote currency**—not in Indian rupees (INR). That’s a departure from the way equity or commodity futures are settled in India, where everything is INR‑denominated.  

Let’s walk through an example (the original chart is reproduced below for reference).  

![P&L example table](https://zerodha.com/varsity/wp-content/uploads/2018/03/Table-18-3.png)

### Converting to INR  

At the end of each trading day, the **RBI’s reference rate** (released at **12:30 PM**) is used to translate your quote‑currency P&L into INR.  

- **EUR/USD & GBP/USD**: P&L (in USD) → converted with **USD/INR**  
- **USD/JPY**: P&L (in JPY) → first to USD (using JPY/USD), then to INR (using USD/INR) **or** directly with the published **JPY/INR** rate  

### Carry‑forward positions  

If you keep the contract open overnight, the exchange does a **daily “mark‑to‑market” (M2M)** settlement. The settlement price is the **weighted‑average price of the last half‑hour of trading** for that day. Your account gets credited or debited accordingly, keeping the cash flow tidy.  

---

## 18.4 – The Options Contract  

Cross‑currency options on NSE mimic the structure of the already‑familiar **USD/INR options**. Here’s the cheat sheet:  

| Feature | Detail |
|---------|--------|
| **Expiry style** | **European** – can be exercised *only* at expiry, not before |
| **Premium quotation** | In the **quote currency** (USD for EUR/USD & GBP/USD; JPY for USD/JPY) |
| **Contract cycle** | 3 monthly + 3 quarterly contracts each year. The pattern is: three consecutive monthly contracts, then a quarterly contract, repeat. |
| **Strikes available** | 12 In‑the‑Money (ITM) + 12 Out‑of‑the‑Money (OTM) + 1 Near‑the‑Money (NTM) ≈ **25 strikes** per expiry. |

Think of it as a buffet: you get a good spread of deep‑in‑the‑money, slightly out‑of‑the‑money, and a “just‑right” option to choose from.  

---

## 18.5 – Expiry  

All **near‑month contracts** bow out **2 days before the last trading day of the month at 12:30 PM** (the same time the RBI spits out its reference rate). The final settlement price is derived from the **cross‑currency rate** computed using the **individual INR‑quoted reference rates** of each currency in the pair.  

| Pair | How the final settlement is built |
|------|------------------------------------|
| EUR/USD | (USD/INR) ÷ (EUR/INR) |
| GBP/USD | (USD/INR) ÷ (GBP/INR) |
| USD/JPY | (USD/INR) ÷ (JPY/INR) |

![Final settlement calculation table](https://zerodha.com/varsity/wp-content/uploads/2018/03/Table-18-5.png)

### Cash‑settlement  

The futures are **cash‑settled** on **T+2** (two business days after expiry). The **intrinsic value** of any *in‑the‑money* option is calculated using the same final settlement price.  

**Example (quick sketch):**  
Suppose the final EUR/USD settlement comes out at **1.2500** and you hold a **call option** with a strike of **1.2400**. The intrinsic value = **(1.2500 – 1.2400) × 1,000 EUR = 10 USD** per contract, which is then converted to INR at the RBI rate on expiry.  

---

## 18.6 – Margins  

Every contract requires an **initial margin** of **2 % of the contract’s notional value** and an **extreme‑loss margin (ELM)** of **1 %**.  

- **Margin currency:** Although you trade in USD or JPY, the **blocked margin sits in INR**. The exchange automatically converts the INR amount into the quote currency at the appropriate rate.  
- **Timing rule:**  
  - **Trades before 02:00 PM:** Use the **previous day’s RBI reference rate** for margin conversion.  
  - **Trades after 02:00 PM:** Use the **current day’s RBI reference rate**.  

This two‑tier system prevents you from getting a surprise “margin call” due to a sudden rate swing right before the market closes.  

---

## 18.7 – Calendar Spreads  

A **calendar spread** (aka “time‑spread”) is when you hold a **long position** in one expiry month and a **short position** in another expiry month of the same underlying pair. It’s essentially a bet on the *shape of the forward curve* rather than the spot direction.  

The exchange sets **spread‑specific margins** (usually lower than the sum of the two individual margins) because the two legs offset each other’s risk to some degree. The exact numbers are published in the contract specifications, but the key takeaway is: **you lock in a cheaper margin while playing the term‑structure game.**  

---

### Key takeaways from this chapter  

- **Cross‑currency futures & options are now on NSE** – a first for Indian traders.  
- **Lot size = 1,000 units of the base currency** for EUR/USD, GBP/USD, and USD/JPY.  
- **Trading & P&L are quoted in the foreign (quote) currency**, but **settlement occurs in INR** using RBI reference rates.  
- **Daily M2M and final settlement** both rely on the RBI’s 12:30 PM reference rates.  
- **Near‑month contracts expire 2 days before the month’s last trading day at 12:30 PM**, with cash‑settlement on T+2.  

Now you’ve got the toolbox, the jokes, and the numbers—go forth and trade those cross‑currency pairs like a seasoned bar‑room economist! 🍻  