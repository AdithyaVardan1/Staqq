# 12. Crude Oil (Part 3) – The Crude‑Oil‑Contract Show‑Down  

**Source:** <https://zerodha.com/varsity/chapter/crude-oil-part-3-the-crude-oil-contract/>  

---  

## 12.1 – The contract  

If you thought the MCX (Multi‑Commodity Exchange) was just a fancy marketplace for gold and wheat, think again. Crude oil is the *rock‑star* of the exchange – the most‑traded commodity, and the one that makes the floor buzz louder than a teenage boy’s first mixtape.  

On an average day the **combined value** of all crude‑oil contracts that change hands on MCX tops **₹3,000 crore**.  That’s the equivalent of **≈ 8,500 barrels** of black gold being bought and sold every 24 hours.  

Who’s playing in this arena? Both the “big‑boys” and the “little‑guys”:  

| Player type | Example(s) | Why they’re there |
|-------------|------------|-------------------|
| **Up‑stream** (the oil‑finders) | ONGC, Cairn, Reliance | Mostly hedging the physical oil they’ll produce |
| **Down‑stream** (the oil‑drinkers) | IOC, BPCL, HPCL | Hedging their refining & retail exposure |
| **Retail speculators** | You, me, that cousin who thinks “oil‑futures” sounds like a cool Instagram handle | Pure speculation – hoping the price moves like a roller‑coaster they can ride |

If you want a bird’s‑eye view of how liquid a particular contract is, pull up the MCX **Bhav‑Copy** (the daily market‑snapshot file). It’s like the “scoreboard” for each contract: volume, open‑interest, price‑movement, all in one tidy spreadsheet.  

There are **two** crude‑oil contracts you’ll meet on MCX:  

1. **Crude Oil** – the “big‑guy” (sometimes called the *main contract*)  
2. **Crude Oil Mini** – the “baby‑guy” (the *mini‑contract*)  

In this chapter we’ll dissect these two babies from **expiry** to **margin** to **P&L per tick**, so you’ll know exactly what you’re signing up for before you put your hard‑earned rupees on the line.  

![Cartoon – “Crude Oil: Big vs Mini”](http://zerodha.com/varsity/wp-content/uploads/2016/11/M8-C12-cartoon.png)  

---  

## 12.2 – Crude Oil, the big contract  

The *big* crude contract is the heavyweight champion of MCX. With an average **daily turnover of about ₹2,500 crore**, it easily makes the other contracts look like pocket‑money. Let’s cut the fluff and jump straight to the specs.  

| Feature | Value |
|---------|-------|
| **Price Quote** | **Per barrel** (1 barrel = 42 US gal ≈ 159 L) |
| **Lot size** | **100 barrels** |
| **Tick size** | **₹1** |
| **P&L per tick** | **₹100** (because 100 × ₹1) |
| **Expiry** | **19th / 20th of every month** |
| **Delivery unit** | **50,000 barrels** (the physical lot that would be shipped) |
| **Physical delivery point** | **Mumbai / JNPT Port** |

### What does all that mean in plain English?  

* **Price quote per barrel** – When you see a price of “₹3,197”, that’s the price for **one** barrel, not the whole contract.  
* **Lot size = 100 barrels** – To actually buy the contract you have to take the *full* lot of 100 barrels.  
* **Tick = ₹1** – The market can move in steps of a single rupee.  
* **₹100 per tick** – Because you own 100 barrels, a ₹1 move in price gives you a **₹100** profit or loss.  

Take a look at the market‑depth snapshot for the **Dec 2016** contract (the picture below is from the original source, but the numbers still illustrate the idea).  

![Market depth – Dec 2016 contract](http://zerodha.com/varsity/wp-content/uploads/2016/11/image001.png)  

You’ll notice the **offer price** (the price you’d pay to go long) is **₹3,198** per barrel. So the **contract value** is:  

```
Lot size × Offer price = 100 × ₹3,198 = ₹319,800
```  

That’s the *notional* amount you’re controlling.  

### Margin – the “deposit” you actually need  

Unlike some other commodities where the margin can be as low as 3‑4 %, crude oil asks for a little more skin in the game: roughly **9 %** for an overnight (NRML) position.  

```
Margin = 9 % × ₹319,800 ≈ ₹28,782
```  

Zerodha even provides a handy **Margin Calculator** that spits out the exact figure based on the current price. Here’s a screenshot from their site (prices have moved since then, but the logic stays the same).  

![Zerodha margin calculator screenshot](http://zerodha.com/varsity/wp-content/uploads/2016/11/image002.png)  

* **NRML (overnight)** – With a price of **₹3,253** the calculator shows a margin of **₹29,114**.  
* **MIS (intraday)** – If you’re just day‑trading, the required margin drops to roughly **4.5 %**, i.e. **₹14,557**.  

So, if you’re the kind of trader who likes to keep positions open past the market close, be ready to put around **₹30 k** on the table for a single lot. If you’re a day‑trader, you can get away with half that.  

---  

## 12.3 – Selecting the right contract to trade (expiry logic)  

New crude‑oil futures are **launched every month**, but they don’t expire the next day – they live for **six months**. Think of it as a “six‑month lease” that starts the moment the contract appears in the system.  

Example: The **November 2016** contract was actually **introduced in May 2016**. MCX announces these roll‑overs in a circular, but the tables can look a bit cryptic. Below is a typical excerpt (again, from the original source).  

![MCX expiry table example](http://zerodha.com/varsity/wp-content/uploads/2016/11/image003.png)  

**Key take‑aways:**  

1. **Every month** a *new* contract appears, *six months* ahead of its expiry.  
2. The contract **expires on the 19th / 20th** of its designated month (the same day each month).  
3. Each contract therefore has a **six‑month lifespan** on the exchange.  

### Which contract should you actually trade?  

**Liquidity** is the lifeblood of any futures market. The *current‑month* contract (the one whose expiry is coming up next) is always the most liquid. As you get closer to its expiry (say, around the 15th‑16th of the month), the *next* month’s contract starts to pick up steam.  

So, if today is **5 Nov 2016**, you’d likely start with the **Nov 2016** contract (expiring on 19 Nov). Around the 15th‑16th, you’d roll over to the **Dec 2016** contract, because the Nov contract’s order‑book will start to thin out.  

All the other “future‑dated” contracts (Jan 2017, Feb 2017, …) sit on the sidelines, barely moving, until they become the “current month” contract. In other words, they’re the *benchwarmers* of the crude‑oil league.  

---  

## 12.3 – The Crude Oil Mini contract  

Enter the **Crude Oil Mini** – the *compact* version that’s loved by traders who don’t want to tie up a fortune (or who simply prefer a smaller, “cutesier” tick‑size). Its appeal is straightforward:  

* **Lower margin** – you need less cash up front.  
* **Smaller P&L per tick** – a ₹1 move only gives you **₹10** (instead of ₹100).  

That’s not a typo – many traders actually enjoy seeing a *smaller* loss number because it feels less scary, even though the risk‑reward profile is the same if you size the position appropriately.  

### Mini contract specs  

| Feature | Value |
|---------|-------|
| **Price Quote** | Per barrel |
| **Lot size** | **10 barrels** |
| **Tick size** | ₹1 |
| **P&L per tick** | ₹10 |
| **Expiry** | 19th / 20th of each month |
| **Delivery unit** | 50,000 barrels |
| **Physical delivery point** | Mumbai / JNPT Port |

Here’s a snapshot of the **Dec 2016 Mini** market depth:  

![Mini contract market depth](http://zerodha.com/varsity/wp-content/uploads/2016/11/image004.png)  

The price is **₹3,210** per barrel, so the **contract value** is:  

```
Lot size × Price = 10 × ₹3,210 = ₹32,100
```  

### Margin for the Mini  

Because the notional amount is smaller, the **percentage margin** is a shade higher:  

* **NRML (overnight)** – about **9.5 %** → **₹3,049**  
* **MIS (intraday)** – about **4.8 %** → **₹1,540**  

Compare that with the **big** contract’s **₹28‑30 k** (NRML) and **₹14‑15 k** (MIS). The Mini is clearly the *budget‑friendly* sibling.  

Aside from the lot‑size and the resulting margin, everything else – tick size, expiry, delivery point – is identical between the two contracts.  

---  

## 12.4 – Crude Oil Arbitrage  

Now for the part that makes you feel like a secret‑agent on a trading floor. **Arbitrage** is the practice of exploiting a price mismatch between two essentially identical assets.  

Below is a split‑screen view of the **big** Dec 2016 contract and the **Mini** Dec 2016 contract (same source as before).  

![Big vs Mini market depth side‑by‑side](http://zerodha.com/varsity/wp-content/uploads/2016/11/image005.png)  

In a perfect world, both contracts should quote the **same price** (they share the same underlying barrel‑price). In the screenshot they both show **₹3,221** – a happy, arbitrage‑free state.  

### What if they diverge?  

Suppose the big contract is at **₹3,221** while the Mini sits at **₹3,217**. That’s a **4‑point spread** you can potentially lock in risk‑free.  

**Rule of thumb:** *Buy the cheap one, sell the expensive one.*  

| Action | Contract | Price | Lots needed (to equalize notional) |
|--------|----------|-------|-----------------------------------|
| **Buy** | Mini | ₹3,217 | 10 lots (10 × 10 = 100 barrels) |
| **Sell**| Big  | ₹3,221 | 1 lot (1 × 100 = 100 barrels) |

Why 10 Mini lots? Because each Mini lot is 10 barrels, so 10 × 10 = 100 barrels – the same notional as 1 Big lot. Now the two positions are perfectly sized against each other.  

**Profit calculation:**  

If the market later converges to, say, **₹3,230** (a plausible move), you get:  

* Mini: +13 points → **13 × ₹10 = ₹130**  
* Big: ‑9 points → **‑9 × ₹100 = ‑₹900** (but you’re short, so it’s a gain of +₹900)  

Net = **₹130 + ₹900 = ₹1,030** → which is **4 points × ₹100** (the original spread).  

No matter which way the price drifts, as long as the spread narrows to a single price, you’ll pocket the **4‑point difference** (₹400 per ₹1 tick).  

In reality, such clean‑cut spreads don’t stick around for long. High‑frequency algorithms usually pounce within milliseconds. Still, on a slower‑moving market (or during a momentary glitch) you might catch a few minutes of “sweet” arbitrage. Keep your eyes peeled!  

---  

### Key takeaways from this chapter  

* MCX offers **two** crude‑oil futures: the **Big** (100‑barrel lot) and the **Mini** (10‑barrel lot).  
* Both contracts quote price **per barrel**; the difference lies only in lot size and resulting margin/P&L per tick.  
* A **new contract** is launched each month, with an expiry **six months** later (19th / 20th of the month).  
* The **current‑month** contract is the most liquid; as you near its expiry, the next month’s contract takes over the spotlight.  
* **Arbitrage** between the two contracts is possible, but you must match **notional values** (e.g., 10 Mini lots = 1 Big lot).  

That’s it for crude oil – the black gold that fuels not just engines, but also a bustling futures market. Up next we’ll shift gears and dive into the shiny world of **Metals**. Grab your safety goggles; it’s going to be metallic!  