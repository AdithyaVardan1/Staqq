# 8. Gold (Part 2)

**Source:** https://zerodha.com/varsity/chapter/gold-part-2/

---  

##  

![Image](http://zerodha.com/varsity/wp-content/uploads/2016/09/M8-C8-cartoon.png)

## 8.1 – The London fix  

In the last chapter we took a quick tour of the MCX gold contracts. Now we’re going to peek behind the curtain and see **how** the “official” gold price is cooked up in the world’s most posh city—London. (Spoiler: It’s mostly ceremony, not sorcery.)  

The London price is “fixed” **twice** every trading day. The early‑bird session at **10:30 AM** is called the **AM Fix**, and the night‑owl session at **3:00 PM** is the **PM Fix**. The magic is performed by a handful of elite bullion desks, with the whole shindig coordinated by the venerable Nathan Mayer Rothschild & Sons.  

Only about 10‑11 heavyweight banks get an invite to the secret conference call—think JP Morgan, Standard Chartered, ScotiaMocatta (Scotiabank), Société Générale, and a few others. The general public and the rest of the banking crowd are politely shown the door.  

At the appointed minute each dealer dials into a dedicated line and shouts out his **bid** (how much he wants to buy) and his **ask** (how much he wants to sell). The system then averages all the numbers and spits out a single price that becomes the benchmark for the day. The whole thing lasts roughly **10‑15 minutes**, then the process repeats in the evening.  

Because the fix is based on the *actual* trades happening in London, the resulting number is usually a hair’s breadth away from the real‑time market price. Some participants even joke that the fix exists mainly to keep British tradition alive—much like tea time, but with more glitter.  

India runs a miniature version of this ritual. Being one of the world’s biggest gold‑guzzling nations, we import the metal through a set of **designated banks**. Those banks add their own charges (we’ll get to those in a second), then hand the metal to bullion dealers. The **Indian Bullion Association (IBA)** collects the dealers’ bids, averages them, and declares a “floor” price for the day.  

There’s a little feedback loop, because many Indian dealers peek at the MCX gold futures before they submit their numbers to the IBA. In short, the price that ends up on the jeweller’s price board is a blend of import costs, dealer expectations, and a dash of MCX futures magic.

---

## 8.2 – Gold price disparity  

It’s tempting to stare at the CME gold futures quote and the MCX gold futures quote and think, *“Aha! Arbitrage galore!”* After all, gold is a global commodity, so shouldn’t the price be the same everywhere? In theory, yes—​but in practice the two markets often dance to different tunes.  

**Why?** First, let’s see how the Indian spot price is built. India is a **net importer** of gold. Internationally, gold is priced per **troy ounce** (≈ 31.1035 g). Suppose the U.S. spot price is **$1 320 / oz** and the exchange rate is **₹65 / $**.  

- 31.1035 g = $1 320 → 10 g = $1 320 × 10 / 31.1035 ≈ **$424.43**  
- Convert to rupees: $424.43 × 65 ≈ **₹27 588**  

That would be the naïve “raw” Indian price. However, the moment the metal crosses an ocean’s border, a stack of extra costs lands on it:  

| Cost component | What it means |
|----------------|----------------|
| **CIF (Cost, Insurance, Freight)** | The price the bank actually pays for the metal, shipped and insured. |
| **Custom duty** | The government’s bite. |
| **Cess** | A supplemental tax (often for specific schemes). |
| **Bank cost** | The bank’s handling and financing charge. |

All these add up, pushing the **landed price** higher than the simple conversion. For illustration, let’s say after all duties and fees the Indian spot price works out to **$435 / 10 g**—about **$15** higher than the U.S. spot.  

Now, futures aren’t conjured out of thin air; they’re derived from the spot price via the classic cost‑of‑carry formula:  

\[
F = S \times e^{r t}
\]

where **S** is spot, **r** is the risk‑free rate, and **t** is time to expiry.  

Because the **Indian spot** (₹435) is higher than the **U.S. spot** ($420), the MCX futures will naturally sit above CME futures, all else equal. That spread is **not** a free‑lunch arbitrage; it’s simply the result of different underlying spot prices.

---

## 8.3 – What drives the gold price?  

Investors have a habit that would make a meteorologist blush: **Whenever the world looks shaky, they rush to gold**. The metal is the classic “safe‑haven”—the financial equivalent of a warm blanket during a thunderstorm.  

Take the **Brexit referendum (June 2016)**. Look at the chart below:  

![Image](http://zerodha.com/varsity/wp-content/uploads/2016/09/Image-1_Gold-brexit.png)

You’ll see a tidy **run‑up** before the vote, and a big bullish candle right after the “Leave” result (June 24). The market basically said, *“If Europe is about to wobble, we’ll hoard the shiny stuff.”*  

And Brexit is just one of many headlines that have sent gold on a roller‑coaster: oil crises, Middle‑East upheavals, the Greek debt saga, the Lehman collapse—​the list goes on. Whenever geopolitics or macro‑economics get jittery, gold usually **gains**.  

Why? Two forces at play:

1. **Risk‑off sentiment** – investors dump risky assets (like equities) and park cash in “store‑of‑value” assets.
2. **Inflation hedge** – many folks treat gold as a guard against rising prices, believing its long‑term trend is upward.

Speaking of long‑term, check out this historic chart:  

![Image](http://zerodha.com/varsity/wp-content/uploads/2016/09/Image-2_long-term-gold.png)

*Source: LBMA*  

From **1970 ($35/oz)** to **2016 ($1 360/oz)** gold delivered a **37×** return. That sounds like a party, but the **compound annual growth rate (CAGR)** is roughly **8 %** per year. Global inflation hovers around **5‑6 %**, so the *real* (inflation‑adjusted) return is a modest **2 %** per annum. In high‑inflation economies like India, that real edge can even evaporate.  

Bottom line: Gold tends to **shine brighter during uncertainty**, but its long‑run performance is modest once you strip out inflation.

---

## 8.4 – Gold, Dollar, Rupee, and Interest rates  

Gold doesn’t live in a vacuum; it’s tethered to **currencies** and **interest rates**. If you’re a gold trader, you need to keep tabs on the macro‑economy, not just the shiny metal.  

Take a look at this classic chart of **USD vs. Gold**:  

![Image](http://zerodha.com/varsity/wp-content/uploads/2016/09/Image-3_Gold-vs-.png)

*Source: FRED*  

Notice the **inverse relationship**—when the dollar weakens, gold usually climbs, and vice‑versa. Two main reasons:

1. **Currency‑value effect** – A weaker dollar means foreign buyers need fewer of their own currency to buy the same amount of gold, boosting demand.
2. **Asset‑allocation effect** – When the dollar looks sad, investors flee to safe‑haven assets, gold being the prime candidate.

But the world loves exceptions. Imagine a **Saudi oil shock**: investors might dump Saudi‑linked assets and **run to both gold and dollars**, pushing both up together.  

Similarly, **U.S. Federal Reserve rate hikes** typically strengthen the dollar, which *should* dampen gold. In practice, the correlation between gold and Fed rates is rather weak (about **0.3**), so you can’t rely on a single macro variable to predict gold’s next move.  

**Confused?** Absolutely—​that’s why most traders blend **fundamentals** (supply‑demand, macro data) with **technical analysis** (price charts) to get a clearer picture.

**Trading tip:**  
- **Supply‑demand fundamentals** drive the *long‑term* direction.  
- **Charts** translate those fundamentals into *actionable* entry/exit points.

I’m a die‑hard fundamentalist when it comes to stocks, but for commodities (and currencies) I let the charts do most of the talking.

---

## 8.5 – Technical Analysis of Gold  

If “Technical Analysis (TA)” sounds like a fancy term for “reading squiggles on a screen,” you’re not alone. Give the TA module a quick skim first, then come back here for the gold‑specific cheat sheet.  

**Key TA premise:** The method works on *any* tradable asset—equities, forex, commodities, you name it. Below is my personal playbook for gold, keeping the time horizon short (a few days max).  

### 1️⃣ Start with the long‑term view  

I pull up at least a **2‑year daily chart** of the **Gold Bees (ETF)** to gauge the primary trend. Here’s the snapshot:  

![Image](http://zerodha.com/varsity/wp-content/uploads/2016/09/Image-4_Gold-ETF.png)

**What I see:**  

- **Late 2013 → Late 2015:** A steady decline.  
- **End 2015:** Bottoming out, forming a **double bottom** (Sept‑Dec 2015).  
- **Early 2016 onward:** An uptrend, with buyers stepping in at each dip.  
- **Current level:** Around **₹30 900**, comfortably above the 2013 trough.

Conclusion? The bearish phase is mostly over, so **long positions** feel more natural than short ones. That said, I’d still consider a short if the risk‑reward looked *juicy*—but I’d be ready to cover quickly because many traders love to pounce on any dip.

### 2️⃣ Zoom into the short‑term chart  

Next, I flip to the **near‑term daily chart** of the **Oct 2016 MCX contract** (the contract that will expire in October 2016).  

![Image](http://zerodha.com/varsity/wp-content/uploads/2016/09/Image-5_Gold-illiquid.png)

The left half (late 2015 → June 2016) is **quiet**: low volume, big gaps, almost no trading. Why? MCX futures are listed **a year before expiry**, but they stay illiquid until they get close to the delivery month. If the market were a bustling bazaar, you’d see more action earlier.

### 3️⃣ Add some moving averages  

I overlay **9‑day and 21‑day EMAs** on the recent candles to spot short‑term momentum:  

![Image](http://zerodha.com/varsity/wp-content/uploads/2016/09/Image-6_Goldlong-term.png)

Key observations:  

- **Price** is **below** both EMAs, indicating a short‑term bearish bias.  
- A **resistance zone** around **₹30 956** (highlighted in blue). If price breaks above it, we might be looking at a fresh rally.  
- A **bearish Marubozu** (big black candle) just a few sessions back, suggesting some profit‑taking.

### 4️⃣ Build the trade  

Given the setup, my **long** idea is:

| Parameter | Value |
|-----------|-------|
| **Position** | Long |
| **Entry** | Above **₹30 956** (breakout of resistance) |
| **Target** | **₹31 418** (the short blue line on the chart) |
| **Stop‑loss** | **₹30 700** (just below current price) |
| **RRR** | ~**1.8 : 1** |
| **Expected move** | ~**1.5 %** (often achievable in a single session) |

Not a bad risk‑reward, right? If the price snaps above the resistance and rides the EMAs, we could see a tidy intraday profit.

---

## TL;DR – Takeaways  

- **London “fix”**: Gold price is *officially* set **twice a day** (AM 10:30, PM 3:00) by a select club of banks.  
- **Only elite banks** (e.g., JP Morgan, Standard Chartered) can join the fix; the rest watch from the sidelines.  
- **India’s own fix** mirrors London’s but is smaller and a bit circular because dealers peek at MCX futures before bidding.  
- **Spot price gaps** between the U.S. and India arise from **import duties, cess, customs, and bank fees**—not a glitch in the matrix.  
- Because futures are derived from spot, **MCX futures ≠ CME futures**; the disparity is normal, not arbitrage.  
- **Dollar vs. Gold**: Generally **inverse**—when the dollar dips, gold climbs, and vice‑versa (with occasional exceptions).  
- **Fundamentals** (supply‑demand, macro events) are messy; most traders let those pressures **show up on charts**.  
- **Technical analysis** works on gold just as well as on stocks; start with a 2‑year trend, zoom into the recent chart, add EMAs, and watch key price zones.  

Now you’ve got the whole shebang—gold’s quirky pricing rituals, why prices differ across oceans, what moves the metal, and a ready‑to‑use trading blueprint.  

Onward to the silver lining!  

---  

*All numbers are correct as of the 2016 data used in the original source. For live trading, always double‑check the latest rates, fees, and market conditions.*