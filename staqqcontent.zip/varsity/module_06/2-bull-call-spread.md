# 2. Bull Call Spread  

**Source:** https://zerodha.com/varsity/chapter/bull-call-spread/  

---  

## 2.1 – Background  

If you’ve ever tried to juggle two balls while walking a tightrope, you know the thrill (and terror) of a **multi‑leg** option play.  
A “spread” is just a fancy way of saying *we’re buying one option and selling another* –‑ two (or more) legs, two (or more) transactions, and hopefully two (or more) reasons to smile at expiry.

The **Bull Call Spread** is the go‑to when you’re **moderately bullish** – you think the stock will climb, but you’re not ready to bet the farm on a rocket‑ship rally. In other words, you’re somewhere between “it might go up a little” and “I’ll buy the moon”.

Below are three common lenses that can leave you in that “meh‑bullish” zone:  

### Fundamental perspective  
*Imagine Reliance Industries is about to drop its Q3 numbers.* Management hinted in Q2 that Q3 should beat both Q2 and the same quarter last year. The exact point‑spread (how many basis points) is still a mystery – the classic “missing piece of the puzzle”.  
You expect a nice little pop when the results hit, but the market may have already baked some of that optimism into the price. So you think: **Up, but not a fireworks show**.

### Technical perspective  
A stock has been sliding like a greased penguin for weeks, now perched at a 52‑week low, flirting with the 200‑day moving average and a multi‑year support line. The odds of a *relief rally* are decent, yet the overall trend is still bearish. Hence, **maybe up a tad, maybe not**.

### Quantitative perspective  
The ticker is bouncing between ±1 standard deviation (SD) like a disciplined pendulum, showing mean‑reversion. Suddenly it dips to –2 SD for no apparent reason. You suspect a bounce back to the mean, but you also suspect it might linger near –2 SD for a while. So you’re **bullish, but with a safety net**.

The moral of the story: regardless of whether you wear a fundamental, technical, or quant hat, you can land in a *moderately bullish* (or bearish) stance. In that sweet spot you can deploy a spread that gives you three handy perks:

- **Down‑side protection** – if the market says “nope”, you’re not wiped out.  
- **Pre‑defined profit** – you know the ceiling before you even open the trade.  
- **Cheaper entry** – you pay less cash up‑front than you would buying a naked call.  

That third bullet sounds a bit cryptic now, but stick with me; the lightbulb will flick on later.  

![Bull Call Spread cartoon](https://zerodha.com/varsity/wp-content/uploads/2015/11/M6-C2-cartoon.png)  

---

## 2.2 – Strategy notes  

Among the spread family, the Bull Call Spread is the **popular kid**—the one everyone invites to the party because it’s easy to understand and works for a modestly bullish view.

**How it’s built (the classic recipe):**  

| Leg | What you do | Typical strike |
|-----|------------|----------------|
| 1️⃣ | **Buy** an *ATM* (at‑the‑money) call | 7800 in our example |
| 2️⃣ | **Sell** an *OTM* (out‑of‑the‑money) call | 7900 in our example |

A few housekeeping rules before you hit “send” on the order:  

- Both options must be on the **same underlying** (same stock or index).  
- They must share the **same expiry** date.  
- The **quantity** on each leg must match (1:1, 2:2, etc.).  

### A walk‑through example  

| Item | Value |
|------|-------|
| **Date** | 23 Nov 2015 |
| **Outlook** | Moderately bullish (expiry is close, so upside is limited) |
| **Nifty spot** | 7,846 |
| **ATM call** | 7,800 CE, premium = ₹79 |
| **OTM call** | 7,900 CE, premium = ₹25 |

**Trade construction**  

1. **Buy** the 7,800 CE, paying ₹79 → *debit*  
2. **Sell** the 7,900 CE, receiving ₹25 → *credit*  

**Net cash flow** = 79 – 25 = **₹54 debit**  

Because you pay more than you receive, the spread is a **net‑debit** (aka *debit bull spread*).

Now let’s fast‑forward to expiry and see how the payoff behaves under a few price scenarios.

### Scenario 1 – Expiry spot = 7,700 (below the lower strike)

Intrinsic value of a call = **max(0, Spot – Strike)**  

- 7,800 CE: max(0, 7,700 – 7,800) = 0 → you lose the full ₹79 you paid.  
- 7,900 CE: max(0, 7,700 – 7,900) = 0 → you keep the ₹25 you collected.  

**Net P/L** = –79 + 25 = **–₹54** (exactly the net debit).  

### Scenario 2 – Expiry spot = 7,800 (right on the lower strike)

Both options sit exactly at‑the‑money, so each has zero intrinsic value. You lose the whole net debit again: **–₹54**.

### Scenario 3 – Expiry spot = 7,900 (right on the higher strike)

- 7,800 CE intrinsic = max(0, 7,900 – 7,800) = **₹100**  
  Profit on long leg = 100 – 79 = **₹21**  

- 7,900 CE intrinsic = 0 (you’re short, but it expires worthless) → you keep the ₹25 credit.  

**Net profit** = 21 + 25 = **₹46**.

### Scenario 4 – Expiry spot = 8,000 (above the higher strike)

- 7,800 CE intrinsic = 8,000 – 7,800 = **₹200** → profit = 200 – 79 = **₹121**  
- 7,900 CE intrinsic = 8,000 – 7,900 = **₹100** → loss = 100 – 25 = **₹75**  

**Net profit** = 121 – 75 = **₹46** (again the capped maximum).

#### TL;DR of the four cases  

| Spot @ Expiry | Net P/L |
|---------------|---------|
| ≤ 7,700 | –₹54 (max loss) |
| 7,800 | –₹54 |
| 7,900 | +₹46 (max profit) |
| ≥ 8,000 | +₹46 (max profit) |

Two take‑aways pop out:  

1. **Loss is limited** to the net debit (₹54).  
2. **Profit is capped** at the spread width minus the net debit.  

### Defining the numbers  

- **Spread** = Higher strike – Lower strike = 7,900 – 7,800 = **₹100**  
- **Net Debit** = Premium paid (₹79) – Premium received (₹25) = **₹54**  
- **Maximum Profit** = Spread – Net Debit = 100 – 54 = **₹46**  

Here’s a quick‑look payoff table (the original screenshot is reproduced for completeness):

![Payoff table](http://zerodha.com/varsity/wp-content/uploads/2015/11/Image-1_Payoff.png)  

- **LS‑IV** – Lower‑strike intrinsic value  
- **PP** – Premium Paid (₹79)  
- **LS Payoff** – Result from the long leg  
- **HS‑IV** – Higher‑strike intrinsic value  
- **PR** – Premium Received (₹25)  
- **HS Payoff** – Result from the short leg  

The payoff diagram (again, straight from Zerodha) makes the story crystal clear:

![Payoff diagram](http://zerodha.com/varsity/wp-content/uploads/2015/11/Image-2_Payoff.png)  

**Key observations from the graph**

- **Loss zone**: any expiry below 7,800 costs you the full net debit (₹54).  
- **Break‑even**: occurs when Spot = Lower strike + Net debit = 7,800 + 54 = **7,854**.  
- **Profit zone**: any spot above 7,854 earns you money, but the ceiling is **₹46** (100 – 54).  

> **Why not just buy a plain‑vanilla call?**  
> Because the plain call would have cost you the full ₹79 premium, and if the market turned against you you’d lose the entire ₹79. With the spread you’ve shaved the entry cost down to **₹54**, sacrificing a little upside for a fatter wallet now. If you’re only mildly bullish, that trade‑off is usually worth it.

---

## 2.3 – Strike Selection  

What *exactly* qualifies as “moderately bullish”? Is a 5 % jump in Infosys “moderate”, or do we need a 10 % swing? How about a choppy index like Nifty, or a volatile mid‑cap like Yes Bank?  

There’s no universal answer, but a **volatility‑driven rule‑of‑thumb** works for many traders:

| Asset volatility | What I call “moderate” move |
|------------------|-----------------------------|
| **High** (e.g., small‑caps) | 5 %–8 % |
| **Low to medium** (e.g., large caps) | < 5 % |
| **Indices** (Nifty, Bank Nifty) | < 5 % |

### Example: you’re mildly bullish on Nifty (expect < 5 % rise).  
Which strikes should you pick? Is the classic **ATM + OTM** combo still the best?

The answer lives in the land of **Theta**—the time‑decay gremlin that loves to eat option premiums the longer you sit on them.

Below are a set of graphs (originally from Zerodha) that map the *most profitable* strike pair for a given **time‑to‑expiry (TTE)** and a **target move of 3.75 %** (i.e., 8,000 → 8,300). The spread width is fixed at 300 points.

![First‑half‑of‑series graphs](http://zerodha.com/varsity/wp-content/uploads/2015/11/Image-3_first-half-of-series2-1024x576.png)  

**How to read them**  

- **Spot assumed**: 8,000  
- **“Start of series”** = first 15 days of the month‑long expiry cycle.  
- **“End of series”** = last 15 days.  
- **Spread width** = 300 points (e.g., 8,000 → 8,300).  

#### Top‑left (Graph 1) – Early in the series, expect the move in ~5 days  
*Far OTM* wins: **Long 8,600**, **Short 8,900**.  

#### Top‑right (Graph 2) – Early in the series, expect the move in ~15 days  
* Slightly OTM* is optimal: **Long 8,200**, **Short 8,500**.  

#### Bottom‑left (Graph 3) – Early in the series, expect the move in ~25 days  
*ATM* pair shines: **Long 8,000**, **Short 8,300**. Anything above 8,200 (OTM) actually turns negative.  

#### Bottom‑right (Graph 4) – Early in the series, expect the move right at expiry  
Again, **ATM** is best (8,000 / 8,300). OTM strikes start bleeding more because Theta has had its feast.  

Now flip to the **second half** of the series (when you’re closer to expiry and Theta is eating faster):

![Second‑half‑of‑series graphs](http://zerodha.com/varsity/wp-content/uploads/2015/11/Image-4_2nd-half-of-series2-1024x576.png)  

- **Graph 1 (top left)** – Move expected in 1‑2 days → far OTM (8,600 / 8,900).  
- **Graph 2 (top right)** – Move in ~5 days → same far OTM strikes, but profit is smaller (Theta’s bite).  
- **Graph 3 (bottom right)** – Move in ~10 days → slightly OTM (one strike away from ATM).  
- **Graph 4 (bottom left)** – Move only on expiry day → back to **ATM** (8,000 / 8,300). Far OTM options actually lose money even if the market moves up because their time value has evaporated.  

**Bottom line:** The *further* you are from expiry, the more you can afford to go deep OTM (because you have time for the move to happen). The *closer* you get, the more you should hug the ATM or just a hair OTM to avoid Theta eating your potential profit.

---

### 2.3 – Creating Spreads  

A wider spread (larger distance between the two strikes) means **more money at stake**, but it also **pushes the breakeven higher**.  

**Illustrative example (28 Nov, first day of Dec series):** Nifty at 7,883. We’ll look at three different bull‑call spreads:

| Set | Lower strike (long) | Upper strike (short) | Width | Approx. net debit* |
|-----|--------------------|----------------------|-------|-------------------|
| **1** | ITM (7,700) | ATM (7,800) | 100 | ~₹70 |
| **2** | ATM (7,800) | OTM (7,900) | 100 | ~₹54 *(our classic combo)* |
| **3** | OTM (7,900) | Far‑OTM (8,200) | 300 | ~₹30 (cheaper, but higher breakeven) |

\*Numbers are illustrative; exact premiums vary.  

The **risk‑reward profile** flips as you move the strikes:

- **Narrow spread (Set 1)** → smaller max profit, lower breakeven.  
- **Classic spread (Set 2)** → balanced risk/reward, moderate breakeven.  
- **Wide spread (Set 3)** → larger potential profit (if the market rockets), but you need a bigger move to get there (higher breakeven).  

You can also **scale** the legs: buy 2 ATM calls and sell 2 OTM calls, keeping the ratio 1:1 but doubling the notional exposure.  

As always, keep an eye on the **Greeks**, especially **Theta**, because it will determine whether a far‑OTM leg is a cheap ticket or a money‑draining time‑bomb.

---

## Key takeaways from this chapter  

- **Moderate outlook** = you expect a move, but you’re not shouting “to the moon!”.  
- **Quantify “moderate”** by looking at the asset’s volatility; high‑vol stocks need a bigger % move to be “moderate”.  
- **Bull Call Spread** is the go‑to spread for a mildly bullish view.  
- The **classic construction**: buy an ATM call, sell an OTM call (same expiry, same underlying, same quantity).  
- **Theta** is the silent partner that tells you whether to pick far‑OTM, slightly‑OTM, or ATM strikes depending on time‑to‑expiry.  
- **Wider spreads** increase both potential profit and breakeven; narrower spreads tighten both.  
- Adjust the strikes to fit your risk appetite, time horizon, and the Greek‑profile you’re comfortable with.  

> **Bottom line:** If you’re only a little optimistic, a Bull Call Spread lets you **play the upside for cheap** while **capping your downside**. It’s the financial equivalent of ordering a small pizza when you’re not sure you’re hungry—satisfying enough, without the regret of an empty wallet.  

---  

**Download Bull Call Spread Excel Sheet**  

*(Link as provided in the original material – you can grab it from Zerodha’s Varsity page.)*  