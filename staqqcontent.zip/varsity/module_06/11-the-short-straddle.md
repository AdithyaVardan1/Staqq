# 11. The Short Straddle  

**Source:** <https://zerodha.com/varsity/chapter/the-short-straddle/>  

---  

## 11.1 – Context  

In the last chapter we dissected the long straddle and listed the *five* conditions that have to line‑up like a perfect taco for it to make money:

| # | What has to happen | Why it matters |
|---|-------------------|----------------|
| 1️⃣ | **Low** implied volatility when you open the trade | Cheap premiums = you don’t over‑pay for the “insurance” you’re buying |
| 2️⃣ | **Higher** volatility during the life of the trade | The premiums you sold (in a short straddle) or bought (in a long straddle) should **grow**, not shrink |
| 3️⃣ | A **big** market move (direction doesn’t matter) | You need the price to swing far enough to out‑run the premium you paid |
| 4️⃣ | The move must happen **quickly**, well before expiry | Time‑decay (theta) works against you the longer you sit |
| 5️⃣ | The trade is usually placed **around a big event** whose outcome is expected to be *surprisingly* different from the market’s consensus | Events crank up volatility, giving you the “boom” you’re after |

If you’ve ever tried to get all five of those to cooperate, you’ll know it feels a bit like herding cats while juggling flaming swords. In the long‑straddle world we were looking for at least a **3 %** swing on the index (2 % breakeven + 1 % target profit). That’s a lot of wiggle‑room, and in practice it’s rarer than a unicorn sighting on Wall Street.

I’ve seen too many “reckless” traders launch long straddles thinking they’re *immune* to direction, only to watch the trade bleed away because the market stayed boringly flat or moved too slowly. I’m not trying to scold you – the long straddle is beautiful when those five stars align. My gripe is that the odds of that perfect alignment are, well… **meh**.

Now flip the script. The same forces that crush a long straddle (low vol, no big move, slow time decay) **should** be a trader’s best friend when you’re **short** the straddle. In other words, what kills the long version *should* help the short version *make* money.  

![Cartoon of a trader’s brain doing a 180‑degree flip](http://zerodha.com/varsity/wp-content/uploads/2016/04/M6-Ch11-cartoon.png)

---

## 11.2 – The Short Straddle  

Many people get cold sweats at the word *short* because the loss side is “uncapped”. I get it – it sounds scarier than watching a horror movie alone at night. Yet, when the market is expected to *stay* in a tight range, I actually *prefer* the short straddle over its long‑handed cousin. Let’s walk through the set‑up and see how the P&L behaves in different worlds.

### How to set it up (the “sell‑both‑ATM” recipe)

1. Pick an underlying (say, Nifty).  
2. Find the **at‑the‑money (ATM)** strike – the one closest to the spot price.  
3. **Sell** the ATM Call **and** the ATM Put **with the same expiry**.  

Because you’re selling, you receive the premium up front – that’s your *net credit*.  

#### Example with numbers (because numbers are the real party)

*Spot* Nifty = **7,589** → the nearest 100‑point strike is **7,600**.  

| Option | Premium (₹) |
|--------|------------|
| 7,600 CE | 77 |
| 7,600 PE | 88 |

Sell both → **net credit = 77 + 88 = ₹165** per lot.

*Reminder*: Both legs must belong to the same underlying, same expiry, same strike. If you mix‑match, you’ve just invented a new exotic strategy and probably need a PhD.

Now, let’s fast‑forward to expiry and see what the profit‑and‑loss (P&L) looks like under five different market endpoints.

### Scenario 1 – Market crashes to **7,200** (deep ITM Put)

| Leg | Intrinsic value @7,200 | Premium received | P&L |
|-----|------------------------|------------------|-----|
| 7,600 CE | 0 (out‑of‑the‑money) | +77 | **+77** |
| 7,600 PE | 400 (7,600‑7,200) | +88 | **‑(400‑88) = –312** |
| **Net** | — | — | **‑235** |

The put’s loss (₹312) dwarfs the call’s gain (₹77), so you’re **down ₹235**. The “break‑even” point is somewhere between 7,200 and the strike, as we’ll see later.

### Scenario 2 – Market ends at **7,435** (lower break‑even)

| Leg | Intrinsic value @7,435 | Premium received | P&L |
|-----|------------------------|------------------|-----|
| 7,600 CE | 0 | +77 | **+77** |
| 7,600 PE | 165 (7,600‑7,435) | +88 | **‑(165‑88) = –77** |
| **Net** | — | — | **0** |

The loss on the put exactly cancels the call’s credit. You break even – you’ve walked away with exactly what you put in.

### Scenario 3 – Market finishes **right on the strike (7,600)** – **Maximum profit**

Both options expire worthless. You keep the entire credit:

**Profit = ₹165** (the whole net premium).  

*Lesson*: In a short straddle you **love** a lazy market that just sits on the strike. It’s the exact opposite of a long straddle, which needs the market to *move* a lot.

### Scenario 4 – Market ends at **7,765** (upper break‑even)

| Leg | Intrinsic value @7,765 | Premium received | P&L |
|-----|------------------------|------------------|-----|
| 7,600 CE | 165 (7,765‑7,600) | +77 | **‑(165‑77) = –88** |
| 7,600 PE | 0 | +88 | **+88** |
| **Net** | — | — | **0** |

Again, the loss on the call is wiped out by the put’s credit. That’s the *upper* break‑even point.

### Scenario 5 – Market rockets to **8,000** (deep ITM Call)

| Leg | Intrinsic value @8,000 | Premium received | P&L |
|-----|------------------------|------------------|-----|
| 7,600 CE | 400 | +77 | **‑(400‑77) = –323** |
| 7,600 PE | 0 | +88 | **+88** |
| **Net** | — | — | **‑235** |

The call’s loss (₹323) swallows the put’s credit, leaving you **₹235** in the red – the mirror image of Scenario 1.

---

### Pay‑off snapshot  

| Spot at expiry | P&L (₹) |
|----------------|---------|
| 7,200 | –235 |
| 7,435 | 0 |
| 7,600 | **+165** |
| 7,765 | 0 |
| 8,000 | –235 |

![Pay‑off diagram (inverted V)](http://zerodha.com/varsity/wp-content/uploads/2016/04/Image-1_payoff.png)

**What you can read off that picture:**

* **Maximum profit** = total credit (₹165) at the ATM strike.  
* **Profitable zone** = between the lower and upper break‑even levels (strike ± net premium).  
* **Losses are unlimited** – the further the underlying drifts away from those break‑even points, the deeper the hole gets.

And the *inverted‑V* shape tells us a lot more:

* **Peak profit** sits exactly on the strike where you sold the options.  
* **Profit shrinks** as the market wanders away from the strike.  
* **Two break‑even points** are equidistant from the ATM:  

  *Upper Break‑Even* = **Strike + Net Premium** → 7,600 + 165 = 7,765  
  *Lower Break‑Even* = **Strike – Net Premium** → 7,600 – 165 = 7,435  

* **Maximum loss** = *unlimited* (theoretically infinite) because a move beyond the break‑even can be as large as you like.

---

### Bottom line  

The short straddle is the *mirror image* of the long straddle: it thrives when the market is **quiet**, stays within a tight range, and *fails* spectacularly when the market goes on a roller‑coaster ride.  

Yes, the loss side is uncapped, and that can make your heart race. But if you pick the right setup (high IV, upcoming event, expectation of a quick “calm‑after‑the‑storm”), the short straddle can be a tidy money‑maker. In the next section I’ll revisit a classic real‑world example that illustrates exactly that.

---

## 11.3 – Case Study (Re‑posted from Module 5, Chapter 23)

*TL;DR – A short straddle on Infosys before its earnings made a tidy ₹20 per lot because volatility collapsed after the results.*

### The set‑up  

* **Underlying:** Infosys Ltd. (INFY)  
* **Event:** Q2 earnings on **12 Oct** – a classic volatility‑spike catalyst.  
* **Trade date:** **8 Oct** (four days before the announcement).  
* **Spot price:** ~₹1,142 → choose the **1,140** ATM strike.  

| Option | Premium (₹) | Implied Volatility |
|--------|------------|--------------------|
| 1,140 CE | 48 | 40.26 % |
| 1,140 PE | 47 | 48 % |
| **Net credit** | **95** | — |

So we’re pocketing ₹95 per lot, hoping that the **IV** will tumble after the earnings release, letting us buy back the short legs cheaper.

### The earnings surprise  

Infosys delivered numbers *better* than analysts expected:

* **Net profit:** $519 M vs $511 M YoY  
* **Revenue:** $2.39 B (+8.7 %) – comfortably beating the 4‑4.5 % consensus  
* **In rupee terms:** Profit ₹3,398 Cr (+9.8 %); Revenue ₹15,635 Cr (+17.2 % YoY)

The market cheered, but the *volatility* **collapsed** – exactly what the short‑straddle trader wanted.

### Closing the trade  

Right after the results (≈9:18 AM, three minutes after the open), the trader bought back the legs:

| Option | Premium (₹) at close | Implied Volatility |
|--------|----------------------|--------------------|
| 1,140 CE | 55 | 28 % |
| 1,140 PE | 20 | 40 % |
| **Net credit at exit** | **75** | — |

**Profit:** 95 – 75 = **₹20** per lot.  

Notice how the call price *rose* a little (48 → 55) because the stock ticked up, but the put *plummeted* (47 → 20) as the market’s fear evaporated. The net effect was a tidy gain.

**Takeaway:** When you sell a short straddle **before** a volatility‑pumping event, you’re essentially betting that the IV will **spike** (you collect a fat premium) and then **crash** after the event (you buy back cheaper). If the event’s outcome is *not* a surprise, the IV usually drops like a hot potato, and you walk away with profit.

---

## 11.4 – The Greeks  

Because we’re dealing with ATM options, each leg starts with a **delta** of roughly **±0.5**. Since we’re *short* both legs, the signs flip:

| Leg | Delta (≈) | Position | Effective delta |
|-----|-----------|----------|-----------------|
| 7,600 CE | +0.5 | Short | –0.5 |
| 7,600 PE | –0.5 | Short | +0.5 |
| **Combined** | — | — | **0** |

A **zero net delta** means the position is *directionally neutral* at inception – the market moving up or down won’t immediately tilt your P&L. That’s true for both long **and** short straddles.  

**But…** as the underlying drifts away from the strike, each option’s delta changes (the call’s delta climbs toward +1, the put’s toward –1). The net delta will **no longer be zero**; the position will become *directionally biased* (short calls → negative delta, short puts → positive delta).  

*How do you keep it neutral?*  

* **Dynamic hedging** – buy or sell shares (or futures) to offset the drift.  
* **Rolling the strikes** – adjust the ATM strike as the market moves.  

These are more advanced maneuvers, but the key insight is: **delta neutrality is a snapshot, not a permanent guarantee**.

---

## Key Takeaways (the “cheat‑sheet” you can actually cheat on)

| ✅ | What you need to remember |
|---|----------------------------|
| 1️⃣ | **Short straddle = sell ATM Call **and** ATM Put** (same underlying, same expiry, same strike). |
| 2️⃣ | You’re *betting on a range*: the market stays near the strike, so both options expire worthless. |
| 3️⃣ | **Maximum profit = total credit received** (net premium). It occurs *exactly* at the strike you sold. |
| 4️⃣ | **Break‑even points** are **strike ± net premium** (e.g., 7,600 ± 165). |
| 5️⃣ | **Combined delta = 0** at entry → direction‑neutral, but it will drift as the market moves. |
| 6️⃣ | **High IV at entry** (premium is rich) and **IV decay** after the trade are your best friends. |
| 7️⃣ | Use the strategy **around big events** (earnings, RBI announcements, etc.) when you expect IV to *spike* then *crash*. |
| 8️⃣ | **Losses are unlimited** – a runaway market can blow up the trade, so size your position carefully. |
| 9️⃣ | You can *manage* the delta with futures or by rolling the strikes, but that adds complexity (and transaction costs). |
| 🔟 | The short straddle is the **inverse** of the long straddle: *quiet markets* = profit, *big moves* = pain. |

---

### Want a quick‑calc cheat sheet?  

Download the **Short Straddle Excel Sheet** (link in the original Varsity module) – it’ll let you plug in spot, premium, and expiry to instantly see your break‑even, max profit, and risk‑reward profile.

Now go forth, sell those ATM legs when the market is jittery, and may your range‑bound bets be ever in your favor. 🍻