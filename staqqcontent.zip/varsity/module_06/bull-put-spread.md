# 3. Bull Put Spread  

**Source:** <https://zerodha.com/varsity/chapter/bull-put-spread/>  

---  

##  

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/12/M6-C3-cartoon.png)  

## 3.1 – Why Bull Put Spread?  

Think of the Bull Call Spread and the Bull Put Spread as two twins who dress alike but have opposite personalities. Both aim for a *moderately bullish* outlook, and both give you that classic “up‑side‑limited, down‑side‑capped” payoff curve. The only real difference is **which option you use to build the spread**.  

- **Bull Call** = two *calls* (you’re buying the right to go long).  
- **Bull Put** = two *puts* (you’re buying the right to go short, but you sell the other side).  

You might be thinking, “If the payoff diagrams look the same, why bother picking one over the other?” The answer is hidden in the price tags on those options—i.e., the *premiums*.  

| Situation | What’s happening to premiums? | Which spread feels comfier? |
|-----------|------------------------------|-----------------------------|
| Markets have taken a tumble and put premiums have **inflated** like balloons at a birthday party | You get a **big credit** for selling the ITM put | **Bull Put** (you collect cash up front) |
| Volatility is high (think roller‑coaster) | Premiums on both sides are generous, but the *sell* side is especially juicy | **Bull Put** again – you like cash in hand |
| Plenty of time until expiry (you’ve got months, not minutes) | Time value is still significant, making the *sell* leg premium attractive | **Bull Put** – you pocket the credit and wait |

In short, when you’re in a market that has **fallen hard**, **volatility is cranked up**, and you still think “it’ll bounce back a bit”, the Bull Put Spread lets you **receive a net credit** instead of paying a net debit (as you would with a Bull Call). Personally, I’m a fan of “get paid first, hope later” – net‑credit strategies just feel nicer on the wallet.  

---

## 3.2 – Strategy Notes  

The classic Bull Put Spread is a **two‑leg spread** made up of an **ITM put** (the one you *sell*) and an **OTM put** (the one you *buy*). You can, of course, play with other strike combos, but the usual recipe is:

1. **Buy** 1 OTM put – this is your safety net (you’ll lose at most the premium you paid).  
2. **Sell** 1 ITM put – this is where the credit comes from (you collect premium, but you’re on the hook if the market dives).  

Make sure:  

- Both options are on the **same underlying** (e.g., Nifty).  
- They share the **same expiry** (no mixing March with June).  
- The **quantity** matches (1‑for‑1, 2‑for‑2, etc.).  

### Worked‑out Example (so you can picture it with a cold beer)

| Detail | Value |
|--------|-------|
| **Date** | 7 December 2015 |
| **Market outlook** | Moderately bullish (think “slowly but surely”). |
| **Nifty spot** | 7 805 |
| **Leg 1 – Buy** | 7 700 PE @ ₹72 (OTM, you pay this) |
| **Leg 2 – Sell** | 7 900 PE @ ₹163 (ITM, you receive this) |
| **Net cash flow** |  ₹163 – ₹72 = **+₹91** (a credit!) |

Because you **receive** ₹91 up front, the whole construction is called a **Credit Spread**. From here the market can go any which way, so let’s walk through a few “what‑if” scenarios to see how the numbers dance.

### Scenario 1 – Spot ends at 7 600 (below the lower strike, i.e., the OTM put is still OTM)

| Option | Intrinsic value at expiry | P/L (intrinsic – premium) |
|--------|--------------------------|--------------------------|
| 7 700 PE (long) | Max[7 700 – 7 600, 0] = ₹100 | 100 – 72 = **+₹28** |
| 7 900 PE (short) | Max[7 900 – 7 600, 0] = ₹300 | 163 – 300 = **–₹137** |

**Total payoff:** +₹28 – ₹137 = **–₹109** (your worst‑case loss).

### Scenario 2 – Spot ends at 7 700 (exactly the lower strike)

- 7 700 PE is now ATM → intrinsic = 0 → you lose the full premium **₹72**.  
- 7 900 PE is ITM with intrinsic = 7 900 – 7 700 = ₹200.  

**Total payoff:** 163 – 200 – 72 = **–₹109** (same loss as Scenario 1 – the loss floor is flat).

### Scenario 3 – Spot ends at 7 900 (right on the higher strike, i.e., the short put is ATM)

Both puts are ATM → intrinsic = 0 for each, so both expire worthless.  

**Total payoff:** 163 – 72 = **+₹91** (the full credit you collected).

### Scenario 4 – Spot ends at 8 000 (well above the higher strike)

Again, both puts are OTM → expire worthless.  

**Total payoff:** 163 – 72 = **+₹91** (same max profit).

#### TL;DR of the four scenarios

| Spot at expiry | Payoff |
|----------------|--------|
| ≤ 7 600 | –₹109 (max loss) |
| 7 600 → 7 700 | –₹109 (still max loss) |
| 7 700 → 7 900 | climbs linearly up to +₹91 |
| ≥ 7 900 | +₹91 (max profit) |

### What does that teach us?

1. **Higher markets = profit** – the spread loves it when Nifty climbs.  
2. **Downside risk is capped** – the most you can lose is the **spread width minus the credit** (here, 200 – 91 = ₹109).  
3. **Upside profit is capped** – you can’t earn more than the credit you collected (₹91).  

#### Formal definitions  

- **Spread** = Higher strike – Lower strike (here, 7 900 – 7 700 = 200).  
- **Net Credit** = Premium received (higher strike) – Premium paid (lower strike) = ₹163 – ₹72 = ₹91.  

Therefore  

- **Max Loss** = Spread – Net Credit = 200 – 91 = ₹109.  
- **Max Profit** = Net Credit = ₹91.  

Here’s a quick‑drawn payoff diagram (just like the one in the original notes):

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/12/Image-2_Breakeven.png)

**Three things to read off the graph**

1. **Loss zone** – if Nifty finishes **below 7 700**, you lose, but never more than ₹109.  
2. **Breakeven** – occurs when the market ends at **Higher Strike – Net Credit** = 7 900 – ₹91 = 7 809.  
3. **Profit zone** – any spot **above 7 809** yields a profit, capped at the net credit (₹91).  

---

## 3.3 – Other Strike Combinations  

The “spread” is simply the **distance between the two strikes**. While the textbook version uses a *single* OTM put and a *single* ITM put, you can mix‑and‑match any OTM/ITM pair you like. The farther apart the strikes, the **wider the spread**, and consequently:

- **Reward** (max profit) stays the same – it’s always the net credit you collect.  
- **Risk** (max loss) grows because the spread width widens.  

Let’s play with a different underlying spot: **7 612**.

| Example | Lower (OTM) strike | Upper (ITM) strike | Spread width |
|---------|-------------------|-------------------|--------------|
| A | 7 500 PE | 7 700 PE | 200 |
| B | 7 400 PE | 7 800 PE | 400 |
| C | 7 500 PE | 7 800 PE | 300 |

If you’re **super‑confident** that the market will rise a bit, you might stretch to a 400‑point spread (example B) to boost the credit you collect. If you’re **cautious**, stick to a tighter spread (example A). The math works the same:

- **Max loss** = Spread – Net credit (bigger spread → bigger potential loss).  
- **Max profit** = Net credit (doesn’t change with spread width).  

**Bottom line:** Pick your strikes based on how strong your bullish conviction is and how much risk you’re willing to shoulder.

---

### Key take‑aways from this chapter  

- The **Bull Put Spread** is the put‑option counterpart to the Bull Call Spread – both target a *moderately bullish* market view.  
- It **generates a net credit** up front, so you start the trade with cash in hand.  
- Ideal market conditions:  
  - The market has **dropped**, inflating put premiums.  
  - **Volatility** is high (big premiums to collect).  
  - You expect the market to **hold steady or rise modestly**.  
- Construction: **Buy an OTM put** + **Sell an ITM put** (same underlying, same expiry, same lot size).  
- **Maximum profit** = the net credit you receive.  
- **Maximum loss** = *(Higher strike – Lower strike) – Net credit* (i.e., spread width minus credit).  
- **Breakeven point** = **Higher strike – Net credit**.  
- You can use **any OTM‑ITM pair**; wider spreads boost potential reward but also raise the breakeven and max‑loss levels.  
- **Higher spread → higher profit potential** (still capped at the credit) and **higher breakeven** (you need the market to move further up to start making money).  

**Download the Bull Put Spread Excel Sheet** – a handy spreadsheet to plug in your own strikes, premiums, and expiries, and see the payoff instantly.  

---  