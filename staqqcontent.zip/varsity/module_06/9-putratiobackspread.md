# 9. Put‑Ratio‑Back‑Spread  

**Source:** <https://zerodha.com/varsity/chapter/put-ratio-back-spread/>  

---  

## 9.1 – Background  

Remember the “Call Ratio Back‑spread” we dissected back in chapter 4? Think of the Put Ratio Back‑spread as its gloomy twin – you pull this one out when you’re wearing a bearish outlook like a raincoat in a monsoon.  

At a glance, here’s what the trade feels like in your wallet:  

| Market move | What happens to your P&L |
|-------------|--------------------------|
| **Big drop** | Unlimited profit – the market keeps falling and your payoff goes to the moon (or at least to the bank). |
| **Big rise** | Small, capped profit – you still earn something because you collected a net credit when you opened the spread. |
| **Sideways** | A predefined loss – the market hangs out in a range and you lose the “maximum‑pain” amount. |

In plain English: you make money **as long as the market decides to move**, but the trade is happiest when the market is heading south.  

![Cartoon of a trader grinning while the market slides down](http://zerodha.com/varsity/wp-content/uploads/2016/03/M6-C9-cartoon-1.png)  

Usually you set this up as a **net‑credit** trade – the moment you click “execute” the broker’s system pops cash into your account. That credit is the profit you pocket if the market *doesn’t* do what you wanted (i.e., if it climbs instead of falls). If the market does fall, you get the real party‑favor: an uncapped upside.  

That’s why the put‑ratio‑back‑spread usually beats a plain‑vanilla long put – you collect premium up‑front and still have the chance to ride a falling market to infinity.

---

## 9.2 – Strategy Notes  

The Put Ratio Back‑spread is a **three‑leg** construction:  

1. **Sell** 1 ITM (in‑the‑money) put  
2. **Buy** 2 OTM (out‑of‑the‑money) puts  

That’s the classic **2 : 1** ratio. You can also do 4 : 2, 6 : 3, etc., but the proportion must stay the same – two longs for every short.  

### A worked‑out example  

Suppose Nifty is chilling at **7,506** and you’re convinced it will tumble to **7,000** by expiry. Here’s how you’d build the spread:  

| Action | Strike | Lots | Premium (₹) | Cash flow |
|--------|--------|------|--------------|-----------|
| **Sell** | 7,500 PE (ITM) | 1 | **+134** (you receive) | +₹134 |
| **Buy** | 7,200 PE (OTM) | 2 | **‑46** each (you pay) | –₹92 (2 × 46) |
| **Net** | – | – | – | **+₹42** (net credit) |

**Key checklist**  

* Same expiry for all three options.  
* Same underlying (Nifty, in this case).  
* The 2 : 1 ratio is respected.  

Now let’s see how the payoff behaves at different expiry levels. Remember, the payoff graph is a bit of a roller‑coaster – we’ll ride it together.

### Scenario 1 – Expiry at 7,600 (above the short strike)

Both puts are out‑of‑the‑money, so they expire worthless.  

* **7200 PE** – you lose the entire ₹92 premium you paid.  
* **7500 PE** – you keep the ₹134 you collected.  

**Net payoff = 134 – 92 = ₹42** – exactly the net credit you received.  

> *Moral*: When the market stays above your short strike, you just walk away with the credit.

### Scenario 2 – Expiry at 7,500 (right on the short strike)

Again, both options have zero intrinsic value, so the same math applies: **₹42 net credit**.  

> *Fact*: Anything **above** 7,500 yields the same ₹42 profit.

### Scenario 3 – Expiry at 7,458 (upper breakeven)

The put ratio back‑spread, like its call counterpart, has **two breakeven points**. The upper one sits at **7,458**. Let’s crunch the numbers:  

* **7500 PE** intrinsic value = Max[7,500 – 7,458, 0] = **₹42**.  
  * You sold it for ₹134, so you keep **₹134 – 42 = ₹92**.  
* **7200 PE** is still OTM → you lose the full ₹92 you paid.  

Result: **+₹92 – ₹92 = ₹0** → breakeven.  

### Scenario 4 – Expiry at 7,200 (the “pain” point)

This is the point of **maximum loss**.  

* **7500 PE** intrinsic value = 7,500 – 7,200 = **₹300**.  
  * You collected only ₹134, so you lose **₹300 – 134 = –₹166**.  
* **7200 PE** expires worthless → you lose the ₹92 premium you paid.  

**Total loss = –₹166 – ₹92 = –₹258**.  

> *Why “maximum pain”?* Both legs are screaming at you at the same time.

### Scenario 5 – Expiry at 6,942 (lower breakeven)

Now we’re on the **lower** breakeven.  

* **7500 PE** intrinsic = 7,500 – 6,942 = **₹558** → payoff = 134 – 558 = **–₹424**.  
* **7200 PE** intrinsic per lot = 7,200 – 6,942 = **₹258**.  
  * Two lots = **₹516**; after subtracting the ₹92 premium you paid, the payoff = **+₹424**.  

Net = –₹424 + ₹424 = **₹0** – another breakeven!  

### Scenario 6 – Expiry at 6,800 (deep down‑the‑well)

Below the lower breakeven the trade becomes a profit machine.  

* **7500 PE** intrinsic = 7,500 – 6,800 = **₹700** → payoff = 134 – 700 = **–₹566**.  
* **7200 PE** intrinsic per lot = 7,200 – 6,800 = **₹400**.  
  * Two lots = **₹800**; after the ₹92 premium, payoff = **+₹708**.  

**Net payoff = +₹708 – ₹566 = +₹142**.  

As the market keeps sliding, that +₹142 balloons without bound.  

The table below (taken from Zerodha) summarises the payoff at a handful of price levels; you can recreate it in Excel for fun.

![Payoff table for the put‑ratio‑back‑spread](http://zerodha.com/varsity/wp-content/uploads/2016/03/Image-1_payoff-table.png)  

And the classic “mountain‑valley‑plateau” graph looks like this:

![Payoff graph for the put‑ratio‑back‑spread](http://zerodha.com/varsity/wp-content/uploads/2016/03/Image-2_payoff-graph.png)  

**Take‑away from the graph:**  

* **Downward moves → unlimited upside**.  
* **Two breakeven points** (≈ 6,942 and 7,458 in our example).  
* **Maximum loss at the middle strike (7,200)**.  
* **Upward moves → you just keep the net credit**.

---

## 9.3 – Strategy Generalisation  

Let’s turn the messy numbers into a tidy cheat‑sheet you can scribble on a napkin.  

| Symbol | Meaning |
|--------|---------|
| **Spread** | Higher Strike – Lower Strike = 7,500 – 7,200 = **300** |
| **Net Credit** | Premium received – 2 × Premium paid = 134 – 2 × 46 = **₹42** |
| **Max Loss** | Spread – Net Credit = 300 – 42 = **₹258** |
| **Max‑Loss Spot** | Lower strike = **7,200** |
| **Lower Breakeven** | Lower Strike – Max Loss = 7,200 – 258 = **6,942** |
| **Upper Breakeven** | Lower Strike + Max Loss = 7,200 + 258 = **7,458** |

You’ll notice the same numbers appear twice in the original text – that’s just the author being extra thorough. The formulas above work for any 2 : 1 put‑ratio‑back‑spread, no matter the underlying.

---

## 9.4 – Delta, Strike Selection & Volatility  

### Delta check  

Because the trade is **directionally bearish**, the aggregate delta should be slightly negative. Using the same strikes as before:  

| Leg | Position | Delta (approx) | Contribution |
|-----|----------|----------------|--------------|
| 7500 PE (short) | –1 | –0.55 | **+0.55** (short flips the sign) |
| 7200 PE (long) | +2 | –0.29 each | **–0.58** (2 × –0.29) |
| **Total** | – | – | **–0.03** |

A delta of **‑0.03** tells us the spread is *barely* bearish (close to neutral), but the sign is the right one – you profit when the index falls.

### Picking the strikes  

* **ITM short put** (the “higher” strike) – gives you a decent premium to collect.  
* **OTM long puts** (the “lower” strike) – give you the upside if the market crashes.  

Always aim for a **net credit**; if you end up paying cash to open the spread, you’ve built the opposite of what you wanted.

### Volatility’s role  

Volatility is the secret sauce that can spice up or dilute the payoff, depending on how much time you have left. The chart below (again from Zerodha) shows three volatility‑sensitivity lines:

![Volatility impact on the put‑ratio‑back‑spread](http://zerodha.com/varsity/wp-content/uploads/2016/03/Image-5_volatility2.png)  

* **Blue line (≈ 30 days to expiry)** – When there’s plenty of time, a jump from 15 % to 30 % IV lifts the strategy’s value from **‑₹57** to **+₹10**. So higher IV is a friend *if* you have a month or more left.  
* **Green line (≈ 15 days to expiry)** – The same IV boost improves the payoff, but only from **‑₹77** to **‑₹47**. Still better, just not as dramatic.  
* **Red line (≈ 5 days to expiry)** – Near expiration, IV changes barely budge the payoff. You’re essentially playing a pure directional game at that point.  

**Bottom line:** When you have a long‑dated spread, keep an eye on IV. When you’re close to expiry, IV is mostly noise – just watch the price.

---

### Key take‑aways (in bar‑talk style)

* **Bearish vibe:** Use this spread when you think the market will slide.  
* **Construction:** Sell **1 ITM** put, buy **2 OTM** puts – keep the 2 : 1 ratio.  
* **Cash‑flow:** Aim for a **net credit** at entry.  
* **Profit profile:** Limited profit if the market rallies (you keep the credit); **unlimited profit** if it crashes.  
* **Two breakeven points:** Lower = *lower strike – max loss*; Upper = *lower strike + max loss*.  
* **Spread = Higher – Lower** (e.g., 300 points in our Nifty example).  
* **Net credit = Premium received – 2 × Premium paid**.  
* **Max loss = Spread – Net credit**, occurring exactly at the **lower strike**.  
* **Delta** is slightly negative (≈ ‑0.03) – a whisper of bearishness.  
* **Strike choice:** Stick with an ITM short and an OTM long; don’t try to get fancy.  
* **Volatility:** Helpful when you have a month or more left; irrelevant in the final few days.  

---

**Want to play with numbers yourself?** Grab the **Put Ratio Back‑Spread Excel sheet** (link in the original Zerodha module) and start fiddling – it’s like a cocktail recipe, but for options. Cheers!  