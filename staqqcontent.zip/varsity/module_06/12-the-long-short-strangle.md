# 12. The Long & Short Strangle  

**Source:** <https://zerodha.com/varsity/chapter/the-long-short-strangle/>

---  

## 12.1 – Background  

If you’ve already survived the straddle party, the strangle is just the cooler cousin who shows up in a hoodie and says, “Hey, I’ll do the same trick but with a smaller entrance fee.”  
Both strategies start with the same brain‑wave: *the market will move big, but we have no idea which way.* The straddle does that by buying the **at‑the‑money (ATM)** call and put; the strangle does it by buying the **out‑of‑the‑money (OTM)** call and put, thereby slashing the upfront cash‑outlay.  

Picture this: Nifty is chilling at **5 921**. The ATM strike is the round‑number **5 900**. If you go full‑straddle, you’d snap up the 5 900 CE (premium = 66) and the 5 900 PE (premium = 57).  

| Item | Premium |
|------|---------|
| 5 900 CE | 66 |
| 5 900 PE | 57 |
| **Total cash outlay** | **123** |

*Breakeven* is simply the spot plus or minus that 123‑point ticket price:  

- Upper breakeven = 5 921 + 123 = **6 044**  
- Lower breakeven = 5 921 − 123 = **5 798**

So you’ve paid **123 points** to be delta‑neutral (i.e., you don’t care if the market goes north or south). The hope is a *big* move, but you’ve just dropped a decent chunk of cash into the pot.  

Now imagine you could get the same “big‑move‑any‑direction” vibe **for a lot less cash**. Enter the **strangle**—the budget‑friendly version of the straddle, with a slightly wider runway to profitability.

> ![Cartoon of a strangle vs. straddle](http://zerodha.com/varsity/wp-content/uploads/2016/04/M6-C12-cartoon.png)

---

## 12.2 – Strategy Notes  

The strangle is basically the straddle’s “lite” version. You still buy a call and a put, but you pick **OTM strikes** instead of ATM. OTM options are cheaper, so your pocket feels lighter—yet you pay the price of a larger distance to the breakeven points.  

### The mechanics  

* Straddle → buy ATM call + ATM put.  
* Strangle → buy **OTM call** + **OTM put** (same expiry, same underlying, same lot‑size ratio).  

**Same‑ratio rule**: you must buy the *same number* of calls and puts. 1 lot + 1 lot, 5 lots + 5 lots, etc. Anything like 2 calls + 3 puts is **not** a strangle (or a straddle) – it becomes a weird hybrid that we’ll not discuss here.  

### Example time  

Let’s say Nifty is dancing at **7 921**. I like a tidy 200‑point buffer, so I pick:

| Strike | Type | Premium |
|--------|------|---------|
| 7 700 | Put (PE) | 28 |
| 8 100 | Call (CE) | 32 |

Both are **OTM** (7 700 < 7 921 < 8 100). The total cash outlay is **28 + 32 = 60 points**, dramatically lower than the 123 points we burned for the straddle.

Now, let’s run through a few “what‑if” scenarios. (Feel free to picture a little profit‑and‑loss roller‑coaster.)

| Scenario | Underlying at expiry | What happens | Profit/Loss (points) |
|----------|---------------------|--------------|----------------------|
| **1** | **7 500** (well below the put strike) | Call expires worthless (‑32). Put is deep ITM: intrinsic = 7 700 − 7 500 = 200. Net = 200 − 28 − 32 = **+140** | **+140** |
| **2** | **7 640** (lower breakeven) | Put intrinsic = 7 700 − 7 640 = 60. That exactly offsets the 60 total premium. | **0** |
| **3** | **7 700** (right on the put strike) | Both options expire worthless → lose the whole premium **‑60**. This is also the *maximum loss* for the long strangle. | **‑60** |
| **4** | **7 900** or **8 100** (ATM or call strike) | Both expire worthless again → lose **‑60**. |
| **5** | **8 160** (upper breakeven) | Call intrinsic = 8 160 − 8 100 = 60, wiping out the 60‑point premium. | **0** |
| **6** | **8 300** (well above the call strike) | Call intrinsic = 8 300 − 8 100 = 200 → profit = 200 − 60 = **+140**. Symmetry, anyone? | **+140** |

> ![Payoff table for the strangle](http://zerodha.com/varsity/wp-content/uploads/2016/04/Image-1_payoff-table.png)

If you prefer a picture over a table, the payoff curve looks like a “V” with its tip cut off at the breakeven points:

> ![Strangle payoff graph](http://zerodha.com/varsity/wp-content/uploads/2016/04/Image-2_graph.png)

### Quick cheat‑sheet  

- **Maximum loss** = total premium paid (here, 60 points).  
- **Losses** are capped between the two strike prices (the region where both options expire worthless).  
- **Upper breakeven** = Call strike + total premium.  
- **Lower breakeven** = Put strike − total premium.  
- **Profit potential** = theoretically unlimited (the further the market runs past a breakeven, the fatter the profit).  

Bottom line: as long as the market makes a *big* move—direction irrelevant—you’re in the money.

---

## 12.3 – Delta and Vega  

Straddles and strangles are cousins, so they share a lot of Greek DNA. Because we’re dealing with **OTM** options, each leg’s delta is modest—roughly **±0.3** (or less).  

| Leg | Approx. Δ |
|-----|-----------|
| 7 700 PE | –0.3 |
| 8 100 CE | +0.3 |

Add ’em together: **–0.3 + 0.3 ≈ 0**. In practice the numbers won’t be perfectly symmetrical, but the net delta stays *close* to neutral, meaning the position isn’t heavily tilted one way or the other.

**Vega (volatility)** behaves the same way for both strategies:  

- **Low volatility** when you open the trade → cheaper premiums (good for buying).  
- **Rising volatility** while you hold → premiums swell, boosting the value of your long strangle.  

In short, you want a *quiet* market at entry and a *storm* later. For a deeper dive, revisit Chapter 10, Section 10.3 (the one that makes you love the Vega curve).

#### Greeks in a nutshell  

- **Volatility**: low at entry, high during holding period.  
- **Market move**: big, fast, and direction‑agnostic (think earnings blast, RBI rate decision, etc.).  
- **Time‑bound**: the big move should happen well before expiry—otherwise time decay will eat you alive.  
- **Event‑driven**: long strangles love major news because the outcome often deviates sharply from market expectations.  

If any of that sounds fuzzy, a quick reread of Chapter 10 will clear it up faster than a caffeine‑infused night‑owl.

---

## 12.4 – Short Strangle  

Now flip the script. A **short strangle** is the *opposite* of the long version: you *sell* the same OTM call and put, collecting the premium up front. In other words, you’re betting the market will stay *inside* the two strikes until expiry.  

Using the same strikes as before (7 700 PE & 8 100 CE) and the same premiums (28 + 32 = 60), you receive **+60 points** right away.  

> ![Short strangle payoff table](http://zerodha.com/varsity/wp-content/uploads/2016/04/Image-3_payoff.png)

What does the payoff look like?  

- If the underlying ends **between 7 640 and 8 160**, you keep the whole 60 points (the *max profit*).  
- As soon as it wanders outside that window, you start losing money, and the losses can grow without bound (since the sold options can become deeply ITM).  

So the short strangle is essentially a *range‑bound* play. If you can spot a stock that’s stuck in a tight trading range—think double‑top/bottom patterns—you can write a strangle just outside that range and pocket the premium.  

I’ve done this many times on **Reliance** when it was bouncing between **₹850** and **₹1 000** for months. Every time it respected those bounds, the short strangle smiled back at me.  

Here’s the visual proof:

> ![Short strangle payoff graph](http://zerodha.com/varsity/wp-content/uploads/2016/04/Image-4_graph.png)

Key observations:

- The graph is a mirror image of the long‑strangle “V” (upside‑down).  
- **Profit** = premium received, capped at **+60 points**.  
- **Profit zone** = any price between the two strikes (7 640 – 8 160).  
- **Losses** are theoretically unlimited (the market can sprint far beyond either strike).  

Breakeven calculations are identical to the long side (just flip the sign):  

- Upper breakeven = 8 160  
- Lower breakeven = 7 640  

---

### Key takeaways from this chapter  

- The **strangle** is a cost‑effective spin on the **straddle**—you pay less, but you need a bigger move to break even.  
- Both long and short strangles are *approximately* delta‑neutral, keeping you insulated from directional risk (unless you stray far from the “same‑ratio” rule).  
- **Long strangle**: buy OTM call + OTM put. Max loss = premium paid; profit potential = unlimited.  
- **Short strangle**: sell OTM call + OTM put. Max profit = premium received; loss potential = unlimited.  
- Greeks affect strangles just like they affect straddles: low initial volatility, rising volatility later, and a big, quick market move are your best friends.  
- Use long strangles around big events (earnings, policy announcements). Use short strangles when you spot a calm, range‑bound market.  

> **Download the Long‑Short Strangle Excel sheet** – your new best friend for crunching the numbers and visualizing payoffs.  

Happy strangling! (Just don’t get too tangled.)