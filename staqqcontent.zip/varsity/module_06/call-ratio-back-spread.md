# 4. Call Ratio Back‑Spread  

**Source:** <https://zerodha.com/varsity/chapter/call-ratio-back-spread/>

---  

## 4.1 – Background  

The Call Ratio Back‑Spread is one of those options tricks that feels like a magic trick you can actually *do* on a trading screen.  I call it “interesting” because you can set it up with almost no math gymnastics and the payoff looks like a roller‑coaster that only goes up (or at worst, flat‑lines a little).  If you’re *genuinely* bullish on a stock or an index—think “I’m ready to shout ‘to the moon!’” rather than the cautious “maybe it’ll crawl up a bit”—this strategy belongs in your toolbox.  

At a glance, a Call Ratio Back‑Spread gives you:  

- **Unlimited profit** if the market rockets upward.  
- **Limited profit** (actually a small credit) if the market slides down.  
- **A predefined loss** if the market decides to sit politely in a narrow band.  

In plain English: you get to make money whether the market moves up **or** down—just not when it refuses to move at all.  

![Cartoon illustration of the strategy](https://zerodha.com/varsity/wp-content/uploads/2015/12/M6-Ch4-cartoon.png)

Most traders run this spread for a **net‑credit**. That means you see cash hit your account *immediately* when you press the “enter” key. The credit is your safety net if the market disappoints (i.e., it goes down). If the market does what you hoped—shoots up—your profit potential is, well, *unlimited*. That’s why many seasoned bulls prefer a Call Ratio Back‑Spread to a plain‑vanilla long call; the former gives you a built‑in cushion plus upside that can stretch to infinity.  

Ready to see the mechanics? Let’s dive in.  

## 4.2 – Strategy Notes  

A Call Ratio Back‑Spread is a **three‑leg** construction:  

1️⃣ **Sell** one *in‑the‑money* (ITM) call.  
2️⃣ **Buy** two *out‑of‑the‑money* (OTM) calls.  

That’s the classic **2 : 1** ratio—two longs for every short. You can scale it (4 long, 2 short, etc.) as long as the ratio stays intact.  

### Example (Nifty style)  

Assume Nifty is chilling at **7,743** and you’re convinced it’ll be strutting at **8,100** by expiry. That’s a bullish vibe, so let’s set the spread:  

| Action | Strike | Lots | Premium (₹) | Cash flow |
|--------|--------|------|-------------|-----------|
| **Sell** | 7,600 CE (ITM) | 1 lot | **+201** | +201 |
| **Buy** | 7,800 CE (OTM) | 2 lots | **‑78** each → **‑156** total | –156 |

**Key checks**  

- Same expiry date for every leg.  
- Same underlying (Nifty, in this case).  
- The 2 : 1 ratio is respected.  

**Net cash flow** = Premium received – Premium paid = **201 – 156 = ₹45 credit**.  

You’ve just launched a Call Ratio Back‑Spread. Now, what happens when expiry rolls around at different spot levels? Spoiler: the payoff graph looks like a smile with a little dip.

> **Note:** We evaluate the payoff at several expiry spots because the shape is *very* versatile.

### Scenario 1 – Spot = **7,400** (below the lower strike)

Intrinsic value of a call = **max(Spot – Strike, 0)**.  

- 7,600 CE: max(7,400 – 7,600, 0) = **0** → you keep the whole **₹201** you collected.  
- 7,800 CE (both lots): also **0**, so you lose the **₹156** you paid.  

**Net** = 201 – 156 = **₹45 credit** (exactly what you started with).  

### Scenario 2 – Spot = **7,600** (right on the short strike)

Both calls are out‑of‑the‑money, so they expire worthless.  

- Keep the **₹201** premium.  
- Lose the **₹156** you paid.  

**Net** = **₹45 credit** again.  

### Scenario 3 – Spot = **7,645** (lower strike + net credit)

Why this weird number? It’s the **break‑even** on the downside.  

- 7,600 CE intrinsic = 7,645 – 7,600 = **₹45**.  
  You sold it for **₹201**, so you keep **201 – 45 = ₹156**.  
- Both 7,800 CEs stay worthless, costing you the **₹156** you paid.  

**Net** = 156 – 156 = **₹0** → you’ve just broken even.  

### Scenario 4 – Spot = **7,700** (midway between strikes)

- 7,600 CE intrinsic = **₹100** → you keep **201 – 100 = ₹101**.  
- 7,800 CEs are still worthless → lose **₹156**.  

**Net** = 101 – 156 = **‑₹55** (a small loss).  

### Scenario 5 – Spot = **7,800** (exactly the long strike)

Now the drama kicks in:  

- 7,600 CE intrinsic = **₹200** → you surrender the full **₹201** you received (200 + 1 rounding).  
- Both 7,800 CEs are ATM, but you bought them, so they’re *worth* **₹78 each** → you actually *gain* **₹156** on the long side, but you already paid that amount, so net loss on them is **‑₹156**.  

Putting it together:  

`Net = 201 – 200 – 156 = -₹155`  

That’s the **maximum loss** for this spread, occurring right at the higher strike.  

### Scenario 6 – Spot = **7,955** (higher strike + max loss)

You’ll notice a second break‑even point, this time on the upside.  

- 7,600 CE intrinsic = 7,955 – 7,600 = **₹355**.  
- Each 7,800 CE intrinsic = 7,955 – 7,800 = **₹155** → with two lots you get **₹310**.  

Net payoff:  

```
201 – 355 + 310 – 156 = 0
```  

Boom—break‑even again.  

### Scenario 7 – Spot = **8,100** (your target)

- 7,600 CE intrinsic = **₹500**.  
- Each 7,800 CE intrinsic = **₹300**, total **₹600**.  

Net payoff:  

```
201 – 500 + 600 – 156 = ₹145
```  

You’re now in the profit zone, and because the long side is **2×** the short, any further rise adds **₹2** of profit for every **₹1** of spot increase—hence the “unlimited upside”.  

Below is the classic payoff diagram (the happy‑face curve you love to stare at).  

![Payoff diagram](https://zerodha.com/varsity/wp-content/uploads/2015/12/Image-1_Payoff.png)

> **Bottom line:** As the market climbs, profit climbs steeply; as it falls, you still pocket the original credit (₹45 in our example), but you won’t lose more than the maximum loss at the higher strike.  

## 4.3 – Strategy Generalization  

From the scenarios above we can distill a few handy formulas (keep them on a cheat‑sheet).  

| Symbol | Meaning |
|--------|---------|
| **Spread** | Higher Strike – Lower Strike |
| **Net Credit** | Premium received (lower strike) – 2 × Premium paid (higher strike) |
| **Max Loss** | Spread – Net Credit |
| **Max‑Loss Spot** | Exactly the higher strike |
| **Down‑side Payoff** | Equals the Net Credit (flat line) |
| **Lower Breakeven** | Lower Strike + Net Credit |
| **Upper Breakeven** | Higher Strike + Max Loss |

And here’s the visual that ties everything together:  

![Payoff graph with key points highlighted](https://zerodha.com/varsity/wp-content/uploads/2015/12/Image-2_Payoff-graph.png)

Notice the flat plateau on the left (your credit), the dip at the higher strike (the max loss), and the rocket‑like ascent once you cross the upper breakeven.  

## 4.4 – Welcome back the Greeks  

Now that you’ve got the shape down, let’s see how **time** and **volatility** (the two big Greeks we care about here) warp that picture.  

![Greeks‑impact charts](https://zerodha.com/varsity/wp-content/uploads/2021/08/Image-3_start-of-the-series_1.png)

**Assumptions behind the charts**  

- Nifty spot = **8,000**.  
- “Start of the series” = any day in the first 15‑day window of the option series.  
- “End of the series” = any day in the last 15‑day window.  
- The spread width = **300 points** (so, 7,800 CE vs 8,100 CE in the example).  

The underlying hypothesis: the index will jump roughly **6.25 %** (≈ 800 → 850).  

### What the top‑left & top‑right graphs say  

If you’re at the **beginning** of the expiry cycle and you expect the move to happen **within the next 5‑15 days**, the sweet‑spot strikes are **7,800 CE (slightly ITM)** and **8,100 CE (slightly OTM)**. Sell the 7,800, buy two 8,100s.  

Why not go deeper OTM? Because the farther you drift, the more you gamble on *price* rather than *time‑value*, and the spread’s profit evaporates.  

### Bottom‑left & bottom‑right graphs  

Same recommendation, but now you’re looking **25 days ahead** (or right on expiry). The 7,800/8,100 combo still dominates.  

> **Takeaway:** Regardless of how many days are left, the “ITM‑plus‑OTM” combo (sell a little‑ITM, buy a little‑OTM) tends to be the most robust.  

### Second‑half‑of‑series charts  

Now we flip the clock: the anticipated move happens **in the latter half** of the series.  

- **Top‑left & top‑right** (move within a day or 5 days): The optimal pair becomes **7,600 CE (deep‑ITM short)** and **7,900 CE (slightly‑ITM long)**. This is a *both‑ITM* spread—no OTM leg at all!  
- **Bottom‑left & bottom‑right** (move within 10 days or on expiry): Same deep‑ITM / slightly‑ITM combo reigns supreme.  

So when you’re squeezing the move into the *last* few days, you abandon the classic ITM‑OTM mix and go for two ITM legs.  

### Volatility’s mood swings  

Volatility is the wild card that can turn a smile into a grimace—or the other way around.  

![Volatility impact chart](https://zerodha.com/varsity/wp-content/uploads/2021/08/Image-5_volatility.png)

Three coloured lines show **net premium** (i.e., the spread’s payoff) as volatility changes, for three different times‑to‑expiry:

| Line | Time to expiry | What happens when vol jumps from 15 % → 30 %? |
|------|----------------|----------------------------------------------|
| **Blue** | 30 days (ample time) | Payoff climbs from **‑₹67** to **+₹43** → volatility *helps* big time. |
| **Green** | 15 days | Payoff improves from **‑₹77** to **‑₹47** → still helpful, just less dramatic. |
| **Red** | < 5 days (very short) | Payoff falls from **‑₹30** to **‑₹80** → volatility *hurts* you. |

Why? With lots of time left, higher volatility inflates the price of the long OTM calls faster than it erodes the short ITM call, giving you a net boost. With very little time, higher volatility just makes the OTM calls cheaper (they’re less likely to finish ITM), so you lose the premium you paid.  

**Bottom line:** If you’re bullish **and** expect volatility to surge, launch this spread *early* (30‑day window). If you’re bullish **and** volatility is expected to stay tame, you can afford to wait a bit. If you’re bullish **and** volatility is about to spike *right before expiry*, think twice—this spread will bite you.  

### Quick recap of the Greeks lesson  

- Early‑series → ITM + OTM combo works best.  
- Late‑series → go deep‑ITM on the short leg, slightly‑ITM on the long leg.  
- More time + higher vol = profit boost.  
- Less time + higher vol = profit drain.  

## 4.5 – Key Takeaways (the “cheat‑sheet” you’ll actually read)

- **Bullish outlook** = ideal candidate.  
- **Structure:** Sell **1** ITM call, buy **2** OTM calls (2 : 1 ratio).  
- **Net credit** is the usual entry – you get cash up‑front.  
- **Down‑side payoff** = the net credit (limited profit).  
- **Upside payoff** = unlimited (each point above the upper breakeven adds ₹2).  
- **Two breakeven points:**  
  - Lower = Lower strike + Net credit.  
  - Upper = Higher strike + Max loss.  
- **Formulas** (keep handy):  
  - Spread = Higher – Lower.  
  - Net Credit = Premium(Lower) – 2 × Premium(Higher).  
  - Max Loss = Spread – Net Credit (occurs at the higher strike).  
- **Strike selection:** Slightly ITM short + slightly OTM long works for *most* time‑frames. For the *very last* half of the series, switch to a deep‑ITM short + slightly‑ITM long.  
- **Volatility:**  
  - Good when you have > 10 days left.  
  - Bad when you’re down to a few days.  

---

### Want to play with numbers yourself?  

Download the **Call Ratio Back‑Spread Excel Sheet** (link provided in the original Zerodha chapter) and start tinkering. Trust me—nothing beats seeing the profit‑loss curve dance on a spreadsheet while you sip your coffee.  

Happy spreading, and may your upside be as limitless as your optimism! 🚀📈  