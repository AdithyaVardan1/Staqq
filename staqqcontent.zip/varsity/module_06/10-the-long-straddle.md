# 10. The Long Straddle  

**Source:** https://zerodha.com/varsity/chapter/the-long-straddle/  

---  

## 10.1 – The directional dilemma  

Ever walked into a bar, shouted “Buy the dip!” or “Short this rally!” and then watched the market do a perfect 180° turn just seconds after you hit *Enter*? Yeah, we’ve all been there – the feeling that your carefully‑crafted chart, the sleepless night of back‑testing, and the whole‑shebang of capital you threw in have just been tossed into a windy abyss.  

Because of moments like that, the pros have learned to stop betting on “which way the wind blows” and start betting on “how hard the wind will blow”. Those strategies that don’t care whether the market goes up or down are called **Market‑Neutral** (or **Delta‑Neutral**) strategies. In the next few sections we’ll meet a handful of these, and we’ll kick things off with the *Long Straddle* – the most straightforward way to become market‑direction‑agnostic while still having a chance at some sweet profits.  

![Cartoon – “Which way is the market going?”](http://zerodha.com/varsity/wp-content/uploads/2016/03/M6-C10-Cartoon.png)  

---

## 10.2 – Long Straddle  

If you could describe the Long Straddle in one sentence, it would be: **Buy the ATM call **and** buy the ATM put – same underlying, same expiry, same strike**. That’s it. No fancy spreads, no exotic Greeks, just a double‑dip in the options market.  

Because you own **both** sides of the trade, the direction of the underlying becomes irrelevant – the market just has to *move* somewhere, anywhere, for you to start making money. Think of it as placing a bet on the market saying “I’m pretty sure something big is going to happen, but I have no idea whether it’ll be a bull or a bear”.  

### How to set it up (the “cook‑book”)

1. **Buy a Call** (CE) on the underlying.  
2. **Buy a Put** (PE) on the same underlying.  

Make sure:  

- Both options are on the **same stock/index**.  
- Both expire on the **same day**.  
- Both share the **same strike price** (usually the “At‑The‑Money”, or ATM, strike).  

### A live‑market example  

At the time of writing the Nifty is trading around **7,579**. The nearest ATM strike is **7,600**.  

| Symbol | Premium (₹) |
|--------|------------|
| 7,600 CE | 77 |
| 7,600 PE | 88 |

If you buy **both** you pay a **net debit of ₹165** (77 + 88). You’re now long a 7,600 call **and** a 7,600 put. No matter which way Nifty swings, one of those options will start to gain value faster than the other loses premium.

![Long Straddle setup screenshot](http://zerodha.com/varsity/wp-content/uploads/2016/03/Image-1_Setup.png)  

### What happens when the market decides to move?

| Market at Expiry | Call payoff | Put payoff | Net P/L |
|------------------|------------|-----------|----------|
| **7,200** (big drop) | 0 (worthless) | 7,600 – 7,200 = 400 intrinsic → 400 – 88 = 312 | **+235** |
| **7,435** (lower breakeven) | 0 | 7,600 – 7,435 = 165 → 165 – 88 = 77 | **0** |
| **7,600** (ATM) | 0 | 0 | **‑165** (you lose the whole premium) |
| **7,765** (upper breakeven) | 7,765 – 7,600 = 165 → 165 – 77 = 88 | 0 | **0** |
| **8,000** (big rally) | 8,000 – 7,600 = 400 → 400 – 77 = 323 | 0 (worthless) | **+235** |

Let’s walk through each scenario in plain English (with a dash of bar‑room storytelling).  

#### Scenario 1 – Market ends at **7,200** (the put saves the day)  
Your call is a sad, flat pancake (worth ₹0). The put, however, is now **in‑the‑money** by ₹400. After you subtract the ₹88 you paid for it, you’re left with **₹312** profit on the put. Subtract the ₹77 you lost on the call, and you walk away with **₹235** net.  

#### Scenario 2 – Market ends at **7,435** (the lower breakeven)  
The put has exactly enough intrinsic value (₹165) to cover the whole ₹165 you spent on both legs. No profit, no loss – you break even.  

#### Scenario 3 – Market ends at **7,600** (right on the strike)  
Both options expire worthless; you lose the entire **₹165** you paid. That’s the **maximum loss** – it happens when the market is the most indecisive of all.  

#### Scenario 4 – Market ends at **7,765** (the upper breakeven)  
Mirror of Scenario 2. The call is now worth exactly ₹165, wiping out the total premium you paid. Break even again.  

#### Scenario 5 – Market ends at **8,000** (the call rescues you)  
Your put is toast (worth ₹0). The call is deep‑in‑the‑money by ₹400. After paying back the ₹77 you spent on the call and the ₹88 you lost on the put, you end up **₹235** ahead.  

These numbers give us the classic **V‑shaped payoff diagram**:  

- **Maximum loss** = total premium paid (₹165) and it occurs at the ATM strike.  
- **Profit potential** is theoretically unlimited in either direction.  

![Payoff table image](http://zerodha.com/varsity/wp-content/uploads/2016/03/Image-2_payofftable.png)  

And the graph that makes it look like a happy smiley face:  

![V‑shaped payoff graph](http://zerodha.com/varsity/wp-content/uploads/2016/03/Image-3_Payoff.png)  

Key observations from the graph:  

- The strategy makes money **both** if the market rockets up **or** crashes down.  
- The **worst‑case** is when the market stays exactly where you entered (the ATM).  
- Two breakeven points sit symmetrically around the strike:  

  * **Upper breakeven** = ATM + net premium = 7,600 + 165 = 7,765  
  * **Lower breakeven** = ATM – net premium = 7,600 – 165 = 7,435  

In short, a Long Straddle is the financial equivalent of “I’ll take the market’s money whichever way it decides to swing”. The direction *doesn’t* matter – **volatility** does.  

---

## 10.3 – Volatility Matters  

If you think volatility is just a fancy word for “the market being jumpy”, you’re half‑right. Volatility is the **fuel** that powers a straddle’s profitability. The higher the volatility when you **enter**, the more you **pay** for the premium; the lower the volatility at entry, the cheaper the ticket.  

Picture the chart below: the Y‑axis is the **cost of the straddle** (i.e., the combined premium), the X‑axis is **implied volatility**. The three coloured lines are for **30‑day**, **15‑day**, and **5‑day** expiries. All three are essentially straight lines – as volatility climbs, the cost climbs proportionally.  

![Volatility vs. cost graph](http://zerodha.com/varsity/wp-content/uploads/2016/03/Image-4_volatility.png)  

**Takeaway:**  

- At **15 %** volatility, a 30‑day straddle costs roughly **₹160** (close to our example’s ₹165).  
- Double the volatility to **30 %** and the same straddle now costs about **₹340**.  

So, if you **buy** a straddle when volatility is **low** and it **spikes** later, you stand to make a *lot* of money (your entry cost was cheap, the market later values the options higher). Conversely, buying when volatility is already **high** and then watching it **collapse** will almost certainly leave you in the red.  

### Delta – the “direction bias” check  

Because you’re long an ATM call (Δ ≈ +0.5) and an ATM put (Δ ≈ ‑0.5), the **net delta is essentially zero**. A delta of zero means the position has **no directional bias** – it’s truly *delta‑neutral*. That’s why the strategy is insulated from market direction and why we call it a **Market‑Neutral** or **Delta‑Neutral** play.  

---

## 10.4 – What can go wrong with the straddle?  

On paper the Long Straddle looks like a win‑win: “Profit if it moves, lose only the premium if it doesn’t”. But the real world loves to sprinkle a few potholes on the road. Two major villains typically sabotage the trade:  

### 1️⃣ Theta Decay (time‑value erosion)  

Options are **time‑decaying assets**. All else equal, each day that passes chips away a little of the option’s value. The decay is **exponential** as you get into the final week before expiry. If you hang onto an ATM straddle into that last week, you’ll watch the premiums melt like ice‑cream on a hot day, even if the underlying hasn’t moved much. Bottom line: **don’t be a glutton – exit before the decay monster devours you**.  

### 2️⃣ Large breakeven distance  

In our example the breakeven points are **165 points** away from the ATM strike (≈ 2.2 % of the index). That means the market has to swing **at least 2.2 %** either way *and* it has to do it **inside the life of the option** (usually ≤ 30 days). If you’re hoping for a 1 % profit on top of that, you actually need a **≈ 3.2 %** move. That’s a tall order for many indices, especially in quiet market periods.  

### The “volatility‑event” recipe  

Putting the two villains together, a Long Straddle will only shine when **all three** of the following line up:  

| Condition | Why it matters |
|-----------|----------------|
| **Low volatility at entry** | Keeps the premium (your cost) cheap. |
| **Volatility spikes after entry** | Inflates the option values, giving you a bigger upside. |
| **A sizeable, rapid market move** | Must be big enough to clear the breakeven distance before decay eats the profit. |

In practice, the best playgrounds for this combo are **major market events** – earnings releases, RBI announcements, budget speeches, etc. But there’s a twist: the **actual outcome must be *surprisingly* different from the market’s expectation**.  

### Real‑world illustration: Infosys results  

1. **Event**: Infosys quarterly earnings.  
2. **Market expectation**: “Revenue will be flat to muted”.  
3. **Outcome A (meh)**: Company says exactly that.  

   - Volatility spikes *before* the announcement (everyone’s nervous).  
   - After the result, volatility collapses (the news was “as expected”).  
   - Your straddle, bought at a **high premium**, now loses value – you’re basically “bought high, sold low”.  

4. **Outcome B (boom)**: Infosys surprises with *aggressive* growth guidance.  

   - Volatility spikes before the release (as usual).  
   - Post‑announcement, the market *re‑prices* sharply, pushing the index well beyond the breakeven points.  
   - Your straddle, bought cheap **if volatility was low pre‑event**, now rides the wave and makes money.  

So, the **event‑vs‑expectation gap** is crucial. You need to be *better* than the crowd at predicting the surprise (or at least have a good hunch it’ll be bigger than the consensus).  

### Quick checklist for a “good” straddle  

- ✅ Volatility **low** when you open the trade.  
- ✅ Volatility **rises** while you hold it.  
- ✅ The underlying makes a **large move** (≥ breakeven distance).  
- ✅ The move occurs **well before expiry** (so decay can’t eat your gains).  
- ✅ You set the trade **around a big event** whose outcome you expect to **beat the market consensus**.  

If you tick most of those boxes, you’re in a decent position. If not, you might want to consider the “short” version of the strategy (the Short Straddle) – a whole different beast that we’ll dissect in the next chapter.  

---

### Key takeaways from this chapter  

- **Market‑Neutral / Delta‑Neutral** strategies don’t care about direction, only about *how much* the market moves.  
- A **Long Straddle** is the simplest way to go market‑neutral: buy the ATM call **and** the ATM put, same underlying, same expiry, same strike.  
- The **maximum loss** equals the total premium paid (₹165 in our example) and occurs if the underlying stays exactly at the strike.  
- **Breakeven points** are symmetrically placed:  
  * Upper breakeven = **ATM + net premium** (7,600 + 165 = 7,765)  
  * Lower breakeven = **ATM – net premium** (7,600 – 165 = 7,435)  
- The **combined delta** is ~0 (‑0.5 + +0.5), giving the strategy a neutral directional bias.  
- **Volatility** is the lifeblood: low at entry, high later → profit. High at entry + falling later → loss.  
- **Theta decay** can erode value quickly, especially in the final week.  
- The market must make a **large, rapid move** (≈ 2 %+ in our example) *before* decay wipes out the premium.  
- Ideal setup times are **around big events** where you expect the actual outcome to **surprise the consensus**.  

---

*Feel free to download the handy **Bull Call Spread Excel Sheet** (link in the original Varsity page) for some quick calculations, but remember: the straddle’s magic lives in the dance between volatility, time, and price movement.*