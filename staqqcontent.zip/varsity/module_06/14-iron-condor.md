# 14.    Iron Condor  

**Source:** https://zerodha.com/varsity/chapter/iron-condor/  

---  

## 14.1 – New margin framework  

Welcome to the golden age of Indian options‑trading – it’s like the 80’s, but with fewer mullets and more margin‑talk. 🚀  

On **1 June 2020** the NSE switched on its brand‑new margin framework. In plain English: if you **hedge** you get to keep more of your hard‑earned cash in your pocket instead of watching it sit idle in the broker’s vault.  

### What the heck is a “hedged position”?  

We’ve already chatted about it a few times, but let’s give it a quick refresher (because repetition is the mother of retention, right?).  

Picture this: you’re on a motorbike, tearing down the highway at **75 km/h** with absolutely **no helmet**. Suddenly, a pothole appears. You slam the brakes, but—boom!—you’re on the pavement. What’s the chance you’ll crack your skull? Pretty darn high.  

Now, same scenario, but you’re wearing a **helmet**. You still hit the pothole, you still fall, but the odds of a serious head injury plummet. The helmet is your **hedge** against the worst‑case crash.  

![Helmet = Hedge](https://zerodha.com/varsity/wp-content/uploads/2020/06/M6-C14-300x200.png)  

In the market, a **naked futures or options** position is the biker without the helmet: you’re exposed to the full wrath of a sudden market swing.  

If you **hedge** (buy a protective instrument, sell a correlated one, etc.), you dramatically trim the probability of a catastrophic loss. And when **your** loss probability goes down, **your broker’s** risk goes down, and so does the **exchange’s** risk.  

> **Moral of the story:** Lower risk → lower margin.  

That’s precisely what the NSE’s new margin regime is trying to reward: **hedged strategies** get a slimmer margin tag, while naked, “I‑do‑what‑I‑want‑today” positions see a **margin hike**.  

You can skim the official NSE presentation if you love PowerPoint drama, but the three key take‑aways are already nicely summarized in a single slide (see below).  

![NSE Margin Snapshot](https://zerodha.com/varsity/wp-content/uploads/2020/06/Image-1_nse-300x168.png)  

**From the top down:**  

| Portfolio | What changed? | Old margin | New margin |
|-----------|----------------|------------|------------|
| **1** – Naked, un‑hedged positions | ↑ margin | 16.7 % | **18.5 %** |
| **2** – Market‑neutral (think spreads, straddles) | **‑70 %** | — | — |
| **3** – Spread positions (think iron condor, butterfly) | **‑80 %** | — | — |

### Why does a spread get a bigger discount than a market‑neutral “plain‑vanilla” position?  

That’s a brain‑teaser for the comments section—think about the risk profile, then drop your answer like it’s hot. 🌶️  

Because the new rules make the **Iron Condor** (and friends) suddenly affordable, let’s dive into the strategy that was once **“too‑expensive‑to‑trade”** but now lives comfortably in the retail trader’s toolbox.  

---  

## 14.2 – Iron Condor  

The Iron Condor is essentially a **four‑legged** option sandwich built on top of a **short strangle**. If a short strangle is a “cheap beer”, the Iron Condor is that same beer with a **premium garnish** that prevents it from spilling over.  

### The raw short‑strangle picture  

Take a peek at the Sensibull Options Strategy Builder (shoutout to the UI designers).  

![Strangle snapshot](https://zerodha.com/varsity/wp-content/uploads/2020/06/Image-2_ss-300x115.png)  

Current Nifty is **9 972.9**. We want to **sell** an OTM put and an OTM call:  

| Leg | Strike | Premium (₹) |
|-----|--------|--------------|
| **9800 PE** | 165.25 |
| **10100 CE** | 145.25 |

Because we **sell** (write) both, we pocket a **total credit** of **165.25 + 145.25 = 310.5** points, i.e. **₹23 288** (multiply by the lot size of 75).  

If you’re new to strangles, skim the earlier chapter – it’s just a “sell OTM call, sell OTM put” combo hoping the underlying hangs out in the middle.  

#### Pay‑off diagram of the naked short strangle  

![Short strangle P&L](https://zerodha.com/varsity/wp-content/uploads/2020/06/Image-3_ssp-300x151.png)  

**Why we love it:** As long as Nifty stays within a comfortable corridor (which it usually does), we keep the premium. It’s also a nifty way to **sell volatility**—when big events (elections, budget, earnings season) puff up option prices, we become the greedy seller and grab the extra crumbs.  

But there’s a catch—**the open ends**. If Nifty rockets past the sold call or tanks below the sold put, the strategy starts bleeding.  

Our example gives a **breakeven band** of **9 490 – 10 411**. That’s a decent 921‑point width, but the market loves drama. Remember the COVID‑19 crash‑and‑rebound in early 2020? It proved that a “wide” band can still be breached in a heartbeat.  

When the market rockets out of that band, **losses become unlimited** (theoretically infinite) and that scares both you **and** the broker. Consequently, the **margin** you must lock up is huge:  

![Short strangle margin](https://zerodha.com/varsity/wp-content/uploads/2020/06/Image-5_mar-300x258.png)  

**≈ ₹1.45 L** – a number that would make many retail traders weep.  

### Enter the Iron Condor – the strangle with a safety net  

Think of an Iron Condor as a **short strangle** that has **bought protection** on both tails. In three bite‑size steps:  

1. **Sell** a slightly OTM call and put (the original short strangle).  
2. **Buy** a further OTM call to cap the upside risk.  
3. **Buy** a further OTM put to cap the downside risk.  

That gives us **four legs**. Here’s the concrete trade:  

| Leg | Action | Strike | Premium (₹) |
|-----|--------|--------|--------------|
| 1 | **Sell** 9800 PE | 165.25 |
| 2 | **Sell** 10100 CE | 145.25 |
| 3 | **Buy** 10300 CE | 77.00 |
| 4 | **Buy** 9600 PE | 105.05 |

Collectively we **receive** a net credit of **310.5 – (77 + 105.05) = 128.45** points → **₹9 634**.  

Visually:  

![Iron Condor layout](https://zerodha.com/varsity/wp-content/uploads/2020/06/Image-6_ic-300x103.png)  

Notice how the **short premium** funds the **long legs**. You’re essentially borrowing from the market to buy your own insurance—smart, right?  

#### Profit‑loss shape  

Because the long OTM options cap the extremes, the **max profit** shrinks but becomes **realistic**:  

![Iron Condor profit](https://zerodha.com/varsity/wp-content/uploads/2020/06/Image-7_profit-300x65.png)  

- **Maximum profit:** **₹9 634** (the net credit).  
- **Maximum loss:** **₹5 366** (the difference between the width of the spread and the credit).  

Now the profit band is **9672 – 10 228**, a tighter corridor than the naked strangle, but the **risk is fully defined**—no nasty surprise “infinite loss” monster lurking.  

#### Pay‑off diagram  

![Iron Condor P&L](https://zerodha.com/varsity/wp-content/uploads/2020/06/Image-8_icpf-300x150.png)  

With a **finite worst‑case** the broker can relax, and **margin drops dramatically**.  

#### New‑era margin requirement  

| Strategy | Required margin (₹) |
|----------|--------------------|
| Short Strangle | **≈ 1,45,000** |
| Iron Condor | **≈ 44,300** |

That’s a **~ 70 %** reduction! Before the NSE’s new framework, an Iron Condor for these strikes would have needed **₹2 – 2.2 L**, making it a “rich‑people‑only” play.  

---  

## 14.3 – Max P&L (the nitty‑gritty)  

When you build an Iron Condor, keep these golden rules in mind:  

1. **Even strike spacing** – The distance between the sold strike and the protective long strike should be **the same** on both sides.  
   *Example:* Sold 9800 PE and 10100 CE; bought 9600 PE and 10300 CE → both spreads are **200** points.  
   *Bad:* Buying 9700 PE (100‑point gap) while buying 10300 CE (200‑point gap) creates an asymmetric risk profile and defeats the purpose.  

2. **Maximum loss** occurs when Nifty ends **above the long call** (≥ 10300) **or below the long put** (≤ 9600).  

3. **Spread width** = 200 (the distance between each short‑long pair).  

4. **Maximum profit** = Net credit received. In our example: **128.45 points** → **₹9 634** (divide by lot size 75 to get per‑point value).  

5. **Maximum loss** = Spread – Net credit = **200 – 128.45 = 71.55 points** → **₹5 366**.  

The accompanying Excel sheet (updated two days after the chapter went live) walks you through each calculation step‑by‑step—feel free to tinker with the numbers.  

---  

## 14.4 – ROI and Logistics  

Let’s do some quick math to see why the Iron Condor is the **smart‑aleck’s favourite** despite its lower absolute premium.  

| Strategy | Credit (₹) | Margin (₹) | ROI |
|----------|-----------|------------|------|
| Short Strangle | 23 288 | 1 45 090 | **16 %** |
| Iron Condor | 9 643 | 44 303 | **21 %** |

**Higher ROI** despite a smaller pocket‑money inflow, because the **capital tied up** is far lower.  

### How to actually place the trade (the “order‑of‑operations” dance)  

1. **Buy** the far OTM call (e.g., 10300 CE).  
2. **Sell** the nearer OTM call (10100 CE).  
3. **Buy** the far OTM put (9600 PE).  
4. **Sell** the nearer OTM put (9800 PE).  

**Why buy first?** The short leg is a **margin‑guzzler**. When you already own the protective long leg, the clearing system knows your risk is capped and therefore **asks for less margin** on the short side.  

*Note:* The ROI numbers above consider **only the blocked margin**, not the cash outlay to purchase the long legs or the cash received from selling the short legs.  

### Your homework  

- Swap the long strikes (e.g., try 10200 CE / 9700 PE) and watch how the net credit, breakeven points, and max loss morph.  
- Drop your findings, questions, or witty one‑liners in the comments.  

---  

### Key take‑aways from this chapter  

- The NSE’s new margin framework **slashes margins** for market‑neutral and hedged strategies.  
- A **short strangle** is attractive but suffers from **open ends** and potentially unlimited loss.  
- The **Iron Condor** is essentially a short strangle **with a safety net** on both sides.  
- Long OTM calls & puts **protect** the short legs, turning an open‑ended gamble into a **defined‑risk** play.  
- Because risk is defined, **margin requirements** for an Iron Condor are **dramatically lower** than for a naked short strangle.  

> **Download the Iron Condor Excel Sheet** and start experimenting—your future self (and your broker) will thank you.  



---  



*Disclaimer: All numbers are based on a lot size of 75 and the market snapshot used in the examples. Real‑world results will vary; always do your own due‑diligence.*