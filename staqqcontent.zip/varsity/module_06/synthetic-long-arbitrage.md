# 6. Synthetic Long & Arbitrage  

**Source:** <https://zerodha.com/varsity/chapter/synthetic-long-arbitrage/>

---  

## 6.1 – Background  

Picture this: you’re asked to hold **both** a long *and* a short position on the same Nifty Futures contract that expires in the same month.  
- **How** on earth would you pull that off?  
- **Why** on earth would you even want to?  

We’ll answer the “how” first (because it’s the fun part) and then get to the “why” (spoiler: it’s all about arbitrage).  

You may already suspect that options are the Swiss‑army knife of derivatives – they can be sliced, diced, and re‑assembled into almost any payoff you fancy, even the payoff of a futures contract (both long and short).  

In this chapter we’ll **synthetically replicate a long futures payoff using plain‑vanilla options**. Before we dive in, you might want to give the classic linear futures payoff a quick refresher (click the link if you need a reminder).  

Or just skim this cartoon‑ish sketch:  

![Long Futures Payoff](http://zerodha.com/varsity/wp-content/uploads/2016/01/Image-1_fut-payoff.png)  

**What you see:**  
- The long futures trade is entered at 2360.  
- That entry price is the *break‑even* – you’re neither winning nor losing at that exact level.  
- Every point the index climbs above 2360 adds the same amount to your profit; every point it falls below subtracts the same amount.  
- Because the profit‑loss line is a straight line, futures are called **linear instruments**.  

Our mission with a **Synthetic Long** is to *mimic* that straight‑line payoff, but using only options.  

---

## 6.2 – Strategy Notes  

Putting together a Synthetic Long is easier than convincing your friends to split the pizza bill. All you need to do is:  

1. **Buy the ATM (at‑the‑money) Call**  
2. **Sell the ATM Put**  

…and make sure:  

- Both options sit on the **same underlying** (Nifty, in our example).  
- Both expire on the **same date** (same series).  

### Walk‑through with real numbers  

Let’s say Nifty is trading at **7,389**. The nearest ATM strike is **7,400**.  

| Action | Symbol | Premium (₹) |
|--------|--------|--------------|
| Buy Call | 7,400 CE | 107 |
| Sell Put | 7,400 PE | 80 |

**Net cash outflow** = Call premium – Put premium = **₹27** (you’re paying 27 rupees to set up the spread).  

Now, let’s see how the trade behaves under a few different expiry scenarios.  

### Scenario 1 – Market closes at **7,200** (well below ATM)  

- **Call** (7,400 CE) expires worthless → you lose the full premium **‑₹107**.  
- **Put** (7,400 PE) is deep‑in‑the‑money. Its intrinsic value = max(Strike – Spot, 0) = **200** points.  
  - Since you sold it, you owe the buyer 200 points, but you only received a premium of 80 → **loss = 80 – 200 = ‑₹120**.  

**Total payoff** = ‑107 ‑ 120 = **‑₹227**.  

---

### Scenario 2 – Market closes exactly at **7,400** (right on the ATM)  

Both options expire worthless:  

- Call loss = **‑₹107** (premium paid).  
- Put gain = **+₹80** (premium received).  

Net result = **‑₹27**, which is exactly the cash you initially spent.  

---

### Scenario 3 – Market closes at **7,427** (ATM + net premium)  

Why 7,427? Because it’s the **break‑even** for the spread:  

> **Break‑even = ATM strike + net cash outflow**  
> 7,400 + 27 = **7,427**  

At 7,427:  

- Call is ITM by 27 points → intrinsic value = **27**. You paid 107, so **‑₹80** net on the call.  
- Put is OTM → you keep the full **₹80** premium.  

The **‑80 + 80 = 0** → you break even.  

---

### Scenario 4 – Market closes at **7,600** (well above ATM)  

- Call intrinsic = 7,600 – 7,400 = **200** points → profit = 200 ‑ 107 = **+₹93**.  
- Put expires worthless → you keep the **₹80** premium.  

**Total payoff** = 93 + 80 = **₹173**.  

---

### Does the payoff really look linear?  

We’ve seen four points, but to be sure the synthetic long truly mirrors a futures contract, we should test symmetry around the break‑even. Let’s check 200 points up and down from 7,427.  

| Spot | Call P/L | Put P/L | Net P/L |
|------|----------|---------|---------|
| **7,627** (break‑even + 200) | Intrinsic = 227 → 227 ‑ 107 = **+₹120** | OTM → **+₹80** | **+₹200** |
| **7,227** (break‑even ‑ 200) | OTM → **‑₹107** | Intrinsic = 173 → 80 ‑ 173 = **‑₹93** | **‑₹200** |

The payoff is **perfectly symmetric**: +200 points when the index is 200 points above break‑even, and –200 points when it’s 200 points below. That’s the hallmark of a **linear** payoff – exactly what a long futures contract delivers.  

A quick visual recap (same images as the original, just for illustration):  

![Different Payoffs](http://zerodha.com/varsity/wp-content/uploads/2016/01/Image-2_different-payoff.png)  

![Synthetic Long Payoff Curve](http://zerodha.com/varsity/wp-content/uploads/2016/01/Image-3_payoff.png)  

**Bottom line:** By buying an ATM call and selling an ATM put (same strike, same expiry) you’ve built a **Synthetic Long Futures** position.  

Now that we know *how* to set it up, let’s explore *when* it becomes useful.  

---

## 6.3 – The Fish‑Market Arbitrage  

Before we get back to the charts, let’s warm up with a good‑old-fashioned arbitrage story—this time starring fish, not futures.  

### The setup  

- **Town A** (your seaside hometown): fresh fish = **₹100/kg** (supply is abundant).  
- **Town B** (125 km inland, high demand): same fish = **₹150/kg**.  

If you can buy in A, truck it to B, and sell it there, you pocket **₹50 per kg**. Subtract a modest **₹20/kg** for transport, and you’re still laughing with **₹30/kg** of risk‑free profit.  

![Fish Arbitrage Cartoon](http://zerodha.com/varsity/wp-content/uploads/2016/01/M6-C7-cartoon.png)  

Sounds like a dream, right? Keep doing it daily and you’ve got a **cash‑cow**.  

### But life isn’t that simple – the risks  

| Risk type | What could go wrong? | Effect on profit |
|-----------|----------------------|------------------|
| **Opportunity risk** (no fish) | The market runs out of fish on a given day. | You can’t buy → no trade, no profit. |
| **Liquidity risk** (no buyers) | You bring your haul to Town B and the market is empty. | Stale fish = loss (or at best, zero). |
| **Execution risk** (bad bargaining) | You end up paying ₹110/kg and still sell at ₹150/kg. After ₹20 transport, profit shrinks to **₹20/kg**. | Profit erodes, may become uninteresting. |
| **Transaction‑cost risk** (expensive transport) | Fuel price spikes, transport rises to ₹30/kg. | Profit drops to **₹0/kg** (break‑even). |
| **Competition risk** (price war) | A rival copies you, both lower prices to win customers. The price may tumble to ₹120/kg (cost + transport). | No arbitrage left; everyone ends up with zero margin. |

In a perfectly competitive market, the arbitrage disappears and the price in Town B converges to **₹120/kg** (cost + transport).  

Mathematically, the arbitrage condition is simply:  

\[
\underbrace{\text{Selling price in B}}_{\text{₹150}} \;-\; \underbrace{\text{Buying price in A}}_{\text{₹100}} \;-\; \underbrace{\text{Transport cost}}_{\text{₹20}} \;=\; \text{Profit}
\]

If the left‑hand side > 0, you have an arbitrage. This simple arithmetic holds in fish markets, grain markets, FX, and of course, the stock market.  

---

## 6.4 – The Options Arbitrage  

Arbitrage in the equity derivatives world is a bit more glamorous (and a lot less smelly) than fish‑trading, but the principle is the same: lock in a profit that **doesn’t care which way the market moves**.  

The classic tool here is **Put‑Call Parity (PCP)**. You don’t need a PhD to get the gist—just remember that a **synthetic forward** (long call + short put) should be priced the same as the actual forward/futures contract.  

The parity can be written as:  

\[
\text{Long Synthetic Long} \;+\; \text{Short Futures} \;=\; 0
\]

Or expanded:  

\[
\text{Long ATM Call} \;+\; \text{Short ATM Put} \;+\; \text{Short Futures} \;=\; 0
\]

If the left‑hand side **doesn’t equal zero**, the mismatch is an **arbitrage opportunity**.  

### Real‑world example (Nifty, Jan 2016)  

| Date | Spot Nifty | Futures price |
|------|------------|---------------|
| 21 Jan 2016 | 7,304 | 7,316 |

ATM options (strike = 7,300) were priced as:  

- **7,300 CE** = **₹79.5**  
- **7,300 PE** = **₹73.85**  

All contracts belong to the **January 2016** expiry series.  

**Arbitrage trade** (according to the equation):  

1. **Long** 7,300 CE @ 79.5  
2. **Short** 7,300 PE @ 73.85  
3. **Short** Nifty Futures @ 7,316  

The first two legs create a **Synthetic Long**; the third leg is the **short futures** that should offset it.  

Let’s test the P/L at three different expiry outcomes.  

### Scenario 1 – Index settles at **7,200**  

- Call expires worthless → **‑₹79.5**.  
- Put intrinsic = 7,300 – 7,200 = **100** points → you’re short, so loss = 73.85 ‑ 100 = **‑₹26.15**.  
- Short futures: you sold at 7,316, buy back at 7,200 → profit = **+₹116**.  

**Net P/L** = ‑79.5 ‑ 26.15 + 116 = **+₹10.35**.  

### Scenario 2 – Index settles at **7,300** (exact ATM)  

- Call loss = **‑₹79.5**.  
- Put expires worthless → you keep the **₹73.85** premium.  
- Futures profit = 7,316 ‑ 7,300 = **+₹16**.  

**Net P/L** = ‑79.5 + 73.85 + 16 = **+₹10.35**.  

### Scenario 3 – Index settles at **7,400** (above ATM)  

- Call intrinsic = 7,400 ‑ 7,300 = **100** → profit = 100 ‑ 79.5 = **+₹20.5**.  
- Put expires worthless → keep **₹73.85**.  
- Futures loss = 7,316 ‑ 7,400 = **‑₹84**.  

**Net P/L** = 20.5 + 73.85 ‑ 84 = **+₹10.35**.  

**Result:** No matter where the index lands, you pocket **≈ 10.35 points**. The parity is *off* by that amount, giving you a clean arbitrage.  

The payoff diagram looks like a flat line at +10.35 points across all possible expiries:  

![Arbitrage Payoff](http://zerodha.com/varsity/wp-content/uploads/2016/01/Image-6_Arb-payoff.png)  

### The real‑world catch – transaction costs  

A theoretical +10.35‑point profit is sweet, but the market is a *price‑eating* beast. You need to subtract:  

| Cost | How it hurts you |
|------|-------------------|
| **Brokerage** (percentage‑based brokers) | Could chew up 8–10 points, wiping out the arbitrage. Discount brokers (e.g., Zerodha) bring the breakeven down to ~4–5 points. |
| **STT (Securities Transaction Tax)** | Since you’ll be long an ITM option at expiry, you’ll owe STT on the exercised amount, further shaving the profit. |
| **Other levies** (stamp duty, GST, etc.) | Small but additive – every rupee counts when the edge is thin. |

If after all deductions the net is still **positive**, the trade is worth doing. In practice, you’d look for a larger mispricing (say 15–20 points) or try to close the positions **just before expiry** to avoid the STT bite, accepting a few points of slippage.  

---

### Key take‑aways  

- **Options can mimic futures** – a long futures payoff can be built from options.  
- **Synthetic Long** = *Buy ATM Call* + *Sell ATM Put* (same strike, same expiry).  
- **Break‑even** for the synthetic long = ATM strike **+** net premium outflow (call premium ‑ put premium).  
- **Arbitrage** appears when *Synthetic Long + Short Futures* yields a **non‑zero** P/L at expiry.  
- **Only execute** if the expected P/L **exceeds** all transaction costs (brokerage, STT, taxes).  

> **Pro tip:** Keep an eye on the **Put‑Call Parity** line in your screen‑feed. When it drifts, a low‑risk, high‑certainty arbitrage might be knocking at your door.  

---  

**Download:** *Synthetic Long & Arbitrage* Excel sheet (for quick calculations).  

---  

*And remember: whether you’re trading futures, cooking up a synthetic position, or hauling fish across state lines, the secret sauce is spotting price mismatches and making sure the costs don’t eat your profit. Happy arbitraging!*