# 8. Bear Call Spread  

**Source:** <https://zerodha.com/varsity/chapter/bear-call-spread/>  

---  

## 8.1 – Choosing Calls over Puts  

If you’ve ever watched a bear trying to put on a sweater, you know the *bear‑put* spread is a bit of a fashion disaster. The **Bear Call Spread** is the more sensible cousin – it’s a two‑leg option play you pull out when you think the market is going to take a modest tumble, but you don’t want to wear a full‑body bear costume.  

Structurally it looks a lot like a Bear Put Spread: the payoff diagram is practically twins. The difference? We swap **puts** for **calls** and change a few execution details.  

### “Why bother with calls if the payoff is the same?”  

Great question, dear options‑enthusiast. The answer lives in the **premium kitchen**.  

| Bear Put Spread | Bear Call Spread |
|-----------------|------------------|
| Executed **debit** (you pay money up‑front) | Executed **credit** (you receive money up‑front) |
| Works best when puts are cheap | Works best when calls are *expensive* |

If the market has been on a bull‑run, call premiums usually puff up like a hot air balloon—perfect for a credit‑oriented strategy. Add in a nice slice of favorable volatility and enough time until expiry, and the Bear Call Spread becomes the slick, cash‑in‑your‑pocket version of the bearish play.  

> **Personal note:** I’m a fan of strategies that hand me money at the start. It feels a little like getting a tip before you even serve the drink.

---

## 8.2 – Strategy Notes  

A classic Bear Call Spread uses one **in‑the‑money (ITM)** call that you **sell** and one **out‑of‑the‑money (OTM)** call that you **buy**. Think of it as “sell the pricey call, buy the cheaper call”—the distance between the strikes decides how big your profit ceiling is.  

**How to set it up**

1. **Buy** 1 OTM Call (Leg 1)  
2. **Sell** 1 ITM Call (Leg 2)  

Make sure:  

- Both legs are on the **same underlying** (e.g., NIFTY).  
- Both have the **same expiry**.  
- The **quantity** (number of contracts) matches on each leg.  

### Walk‑through example (February 2016)  

| Item | Value |
|------|-------|
| **Market outlook** | Moderately bearish |
| **Nifty spot** | 7 222 |
| **Leg 1 – Long Call** | Buy 7 400 CE @ ₹38 (OTM) – this is a **debit** |
| **Leg 2 – Short Call** | Sell 7 100 CE @ ₹136 (ITM) – this is a **credit** |
| **Net cash flow** | ₹136 – ₹38 = **+₹98** (credit) |

Because we receive more premium than we pay, the whole spread is called a **credit spread**. After we open the trade, the market can wander wherever it wants. Let’s see what happens at different expiry levels.

### Scenario 1 – Expiry at 7 500 (above the long call)  

Both calls finish **in‑the‑money**.

| Leg | Intrinsic value | Premium paid/received | P/L |
|-----|----------------|-----------------------|-----|
| 7 400 CE (long) | 7 500 – 7 400 = **₹100** | Paid ₹38 | **+₹62** |
| 7 100 CE (short) | 7 500 – 7 100 = **₹400** | Received ₹136 | **‑₹264** |

**Net loss** = –₹264 + ₹62 = **‑₹202**.  

### Scenario 2 – Expiry at 7 400 (exactly at the long call)  

The long call expires **worthless**; the short call is ITM.

| Leg | Intrinsic value | Premium paid/received | P/L |
|-----|----------------|-----------------------|-----|
| 7 400 CE (long) | 0 | Paid ₹38 | **‑₹38** |
| 7 100 CE (short) | 7 400 – 7 100 = **₹300** | Received ₹136 | **‑₹164** |

**Net loss** = –₹164 – ₹38 = **‑₹202**.  
Notice the loss is the same as in Scenario 1 – the spread caps loss at **₹202** once the underlying crosses a certain level.

### Scenario 3 – Expiry at 7 198 (breakeven)  

Here the payoff is exactly zero.

| Leg | Intrinsic value | Premium paid/received | P/L |
|-----|----------------|-----------------------|-----|
| 7 400 CE (long) | 0 | Paid ₹38 | **‑₹38** |
| 7 100 CE (short) | 7 198 – 7 100 = **₹98** | Received ₹136 | **+₹38** |

**Net P/L** = +₹38 – ₹38 = **₹0** → breakeven point.  

### Scenario 4 – Expiry at 7 100 (short call strike)  

Both calls are out‑of‑the‑money.

| Leg | Value | Result |
|-----|-------|--------|
| 7 400 CE (long) | Worthless → lose premium **‑₹38** |
| 7 100 CE (short) | Worthless → keep premium **+₹136** |

**Net profit** = ₹136 – ₹38 = **+₹98**.  

### Scenario 5 – Expiry at 7 000 (well below the short call)  

Again both expire worthless, so the outcome is identical to Scenario 4:

**Net profit** = **+₹98** (capped).  

---

### Payoff summary  

| Underlying at expiry | Net P/L |
|----------------------|---------|
| ≥ 7 500 | –₹202 (max loss) |
| 7 400 – 7 500 | –₹202 (loss stays capped) |
| 7 198 | ₹0 (breakeven) |
| ≤ 7 100 | +₹98 (max profit) |

Below is the classic “mountain‑shaped” payoff diagram (the one that looks like a bear with a tiny smile):

![Payoff diagram](http://zerodha.com/varsity/wp-content/uploads/2016/02/Image-1_Payoff-edit.png)

And the same data plotted as a graph:

![Graph](http://zerodha.com/varsity/wp-content/uploads/2016/02/Image-2_graph1.png)

Just like the Bear Put Spread, the Bear Call Spread gives you **defined profit** *and* **defined loss**—no nasty surprises.

---

## 8.3 – Strategy Generalization  

From the numbers above we can pull out the handy‑handy formulas that work for any Bear Call Spread.

| Symbol | Meaning | Formula |
|--------|---------|---------|
| **Spread** | Distance between strikes | *Higher strike* – *Lower strike* = 7 400 – 7 100 = **300** |
| **Net Credit** | Premium received minus premium paid | 136 – 38 = **₹98** |
| **Breakeven** | Lower strike + Net Credit | 7 100 + 98 = **7 198** |
| **Max Profit** | Same as Net Credit | **₹98** |
| **Max Loss** | Spread – Net Credit | 300 – 98 = **₹202** |

### Delta check (how the spread reacts to a tiny move in the underlying)  

Using a Black‑Scholes calculator we got:  

- 7 400 CE (OTM) → **Δ = +0.32**  
- 7 100 CE (ITM) → **Δ = +0.89**  

Because we are **short** the 7 100 CE, its delta flips sign: –0.89.  

**Overall position delta** = +0.32 – 0.89 = **‑0.57**  

A negative delta tells us the spread makes money when the underlying drops (exactly what a bearish trader wants) and loses money when it climbs.

---

## 8.4 – Strike Selection and Impact of Volatility  

Choosing the right strikes is a bit like picking a pair of shoes for a hike: you want enough “room” (distance between strikes) for comfort, but not so much that you trip over your own feet. The graphs below show the sweet‑spot strikes depending on where you are in the option series.

### First half of the series (lots of time left)

![First‑half strikes](http://zerodha.com/varsity/wp-content/uploads/2016/02/Image-3_start-of-the-series_BCS.png)

### Second half of the series (getting close to expiry)

![Second‑half strikes](http://zerodha.com/varsity/wp-content/uploads/2016/02/Image-4_2nd-half-BCS.png)

### How volatility moves the *price* of the spread  

The next chart demonstrates how the **cost (or credit) of the spread** reacts to changes in implied volatility (IV) at three different time‑to‑expiry buckets.

![Vol vs Cost](http://zerodha.com/varsity/wp-content/uploads/2016/02/Image-5_Bearish-Call-Spread-price-vs-Volatility.png)

* **Blue line (≈ 30 days left)** – the spread’s credit hardly moves even if IV jumps. Plenty of time = “volatility can take a breather”.  
* **Green line (≈ 15 days left)** – a moderate swing in IV nudges the credit a bit.  
* **Red line (≈ 5 days left)** – volatility spikes yank the credit up or down dramatically. With little time, the market is jittery.

**Takeaway:** If you have a lot of days left, you don’t need to obsess over IV. But in the latter half of the series, keep an eye on whether you expect volatility to **rise** (good for a credit spread) or **fall** (might make the spread cheaper, reducing your potential credit).  

---

### Key takeaways from this chapter  

- **When to use:** Moderately bearish outlook on the underlying.  
- **Why calls over puts?** When call premiums are richer than put premiums, a credit spread feels like free money.  
- **Risk/reward:** Both profit and loss are capped—perfect for the risk‑averse (or the risk‑conscious).  
- **Construction:** Sell an ITM call, buy an OTM call, same expiry, same underlying, equal contract size.  
- **Cash flow:** Usually a **net credit** (you collect cash at the start).  
- **Formulas** (keep them on a cheat‑sheet):  
  - Net Credit = Premium received – Premium paid  
  - Breakeven = Lower strike + Net Credit  
  - Max Profit = Net Credit  
  - Max Loss = Spread – Net Credit  
- **Strike picking:** Depends on where you are in the option series (first half vs. second half).  
- **Volatility:** Favor the spread when you **expect IV to rise**, especially in the second half of the series.  

**Bonus:** Want to play with numbers without pulling out a calculator? Grab the **Bear Call Spread Excel Sheet** (link in the original Zerodha page) and let the spreadsheet do the heavy lifting while you sip your coffee.  

---  

*That’s it, fellow option‑junkie! Remember, the Bear Call Spread is the “short‑selling” of call premiums with a built‑in safety net. Treat it like a well‑engineered sandwich: a little meat (short ITM call), a little cheese (long OTM call), and a tasty credit sauce on top. Happy trading!*