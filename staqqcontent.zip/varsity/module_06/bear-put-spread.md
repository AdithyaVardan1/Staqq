# 7. Bear Put Spread  

**Source:** <https://zerodha.com/varsity/chapter/bear-put-spread/>  

---  

## 7.1 – Spreads versus naked positions  

If you’ve survived the last five chapters you’ve already met the whole “option‑leg party” – bullish spreads, ratio spreads, you‑name‑it. One thing that should have sunk into your brain (along with the coffee you’ve been sipping) is that pros **almost always** reach for a spread before they go full‑naked on a single option.  

Why? Because a spread is like buying a ticket to a movie where you already know the ending – the profit ceiling is smaller, but you also know exactly how much you could lose if the plot goes sideways. Professional traders love *risk visibility* more than they love “oh‑my‑god‑I‑made‑a‑million‑in‑5‑minutes”. In plain English: “Give me a tiny profit if I’m right, but at least tell me the worst‑case loss up‑front.”  

Another perk of spreads is that they are *self‑financing*: you fund the pricey leg by selling a cheaper one. That financing bit is the secret sauce that separates a spread from a plain‑vanilla, naked directional bet.  

In the next few sections we’ll walk through bearish spreads that work when you think the market will slide a bit (think “moderately bearish”) all the way to “full‑blown bear”. Their anatomy mirrors the bullish spreads we already dissected – just flipped upside‑down.  

The first beast we’ll tame is the **Bear Put Spread**, the bearish sibling of the Bull Call Spread.  

![Cartoon of a bear putting a spread on a table](http://zerodha.com/varsity/wp-content/uploads/2016/02/M6-C7-Cartoon1.png)  

---

## 7.2 – Strategy notes  

Just like its bullish cousin, the Bear Put Spread is a **two‑leg, same‑expiry, same‑underlying** play that’s as easy to set up as ordering a pizza. You pull it off when you think the market will dip, but not plunge into the abyss – roughly a 4‑5 % correction feels about right.  

If the market does the expected little stumble, you pocket a modest gain. If it decides to climb instead, your loss is capped (and, let’s be honest, not catastrophic).  

### The textbook (conservative) recipe  

1. **Buy** an **in‑the‑money (ITM) put** – this is your “insurance” that will make money if the market drops.  
2. **Sell** an **out‑of‑the‑money (OTM) put** – you collect a premium that helps pay for the expensive ITM leg.  

> **Side note:** The spread *doesn’t* have to be ITM vs OTM. You can pick any two strikes you like, as long as they share the same expiry and underlying. The distance between the strikes determines how aggressive (or lazy) you are.  

### Numbers‑time (with Nifty as our playground)  

- Spot today: **7,485**  
- ITM put: **7,600 PE** (costs **₹165**)  
- OTM put: **7,400 PE** (you sell it for **₹73**)  

| Action | Option | Premium (₹) |
|--------|--------|------------|
| **Buy** | 7,600 PE | –165 |
| **Sell**| 7,400 PE | +73 |
| **Net** |          | **–92** (a *debit* of ₹92) |

So you’re out **₹92** today, but that’s the most you can ever lose – the “worst‑case” we promised.  

Now, let’s walk through the possible futures (remember, we assume you hold till expiry).  

### Scenario 1 – Market ends at **7,800** (above both strikes)  

Both puts are out‑of‑the‑money, so they expire worthless.  

- You lose the **₹165** you paid for the 7,600 PE.  
- You keep the **₹73** you received for the 7,400 PE.  

Net loss = **‑165 + 73 = –92** (exactly the debit you paid).  

### Scenario 2 – Market ends at **7,600** (right on the long‑put strike)  

Even at the long‑put strike the 7,600 PE has *zero* intrinsic value (it’s “at‑the‑money”). The short 7,400 PE is also OTM, so both die.  

Result: same **‑92** loss.  

### Scenario 3 – Market ends at **7,508** (the breakeven point)  

Why 7,508? It sits exactly **₹92** below the higher strike (7,600 – 92).  

- Intrinsic value of 7,600 PE = **7,600 – 7,508 = 92**.  
- You paid **₹165**, so you’re left with a **₹73** shortfall on that leg (165 – 92).  
- The short 7,400 PE still expires worthless, so you keep the **₹73** you collected.  

Net = **+73 – 73 = 0**. No profit, no loss – the breakeven.  

### Scenario 4 – Market ends at **7,400** (right on the short‑put strike)  

Now the short leg is at‑the‑money, the long leg is deep ITM.  

- 7,600 PE intrinsic = **7,600 – 7,400 = 200**. After recouping the premium you paid (165), you walk away with **₹35** profit on that leg.  
- 7,400 PE expires worthless (you sold it, so you keep the **₹73** premium).  

Net profit = **35 + 73 = ₹108**.  

### Scenario 5 – Market ends at **7,200** (well below the short‑put)  

Both puts are now ITM.  

- 7,600 PE intrinsic = **7,600 – 7,200 = 400** → after subtracting the 165 you paid, you keep **₹235**.  
- 7,400 PE intrinsic = **7,400 – 7,200 = 200** → but you *sold* this for 73, so you owe **200 – 73 = ₹127** to the buyer.  

Net = **235 – 127 = ₹108** (same max profit as before).  

> **Takeaway:** No matter how far the market falls, your profit caps at **₹108**.  

Below is the payoff summary (premiums already baked in):

| Expiry Spot | Net P/L (₹) |
|-------------|------------|
| ≥ 7,800 | –92 |
| 7,600 | –92 |
| 7,508 | 0 |
| 7,400 | +108 |
| ≤ 7,200 | +108 |

The picture below (from Zerodha) visualises exactly that – a flat loss line at –92 on the upside and a flat profit line at +108 on the downside.  

![Payoff diagram of Bear Put Spread](http://zerodha.com/varsity/wp-content/uploads/2016/02/Image-1_payoff1.png)  

---

## 7.3 – Strategy critical levels  

From the scenarios we can extract the “cheat sheet” for any Bear Put Spread:  

| Metric | Formula | Numerical Example |
|--------|---------|-------------------|
| **Spread** (distance between strikes) | Higher – Lower | 7,600 – 7,400 = 200 |
| **Net debit** (what you pay up‑front) | Premium Paid – Premium Received | 165 – 73 = 92 |
| **Breakeven** | Higher strike – Net debit | 7,600 – 92 = 7,508 |
| **Max profit** | Spread – Net debit | 200 – 92 = 108 |
| **Max loss** | Net debit | 92 |

All these numbers sit nicely on the payoff graph we just saw:  

![Graph with critical points highlighted](http://zerodha.com/varsity/wp-content/uploads/2016/02/Image-2_graph.png)  

---

## 7.4 – Quick note on Delta  

I *forgot* to sprinkle some delta talk earlier – better late than never, right? Whenever you stitch together a multi‑leg option play, **add up the deltas**. It’s the fastest way to see whether you’re leaning bullish, bearish, or are truly neutral.  

Using the Black‑Scholes calculator (or any broker’s delta sheet):  

- **Δ of 7,600 PE** = **‑0.618**  
- **Δ of 7,400 PE** = **‑0.342** (but remember you’re **short** this put)  

Since you sold the 7,400 PE, its delta flips sign: **+0.342**.  

Now combine:  

\[
\text{Combined Δ} = -0.618 + (+0.342) = -0.276
\]

A negative overall delta tells us the spread’s value **rises when the market falls** – exactly what a bearish strategy should do.  

For reference, the Bull Call Spread you learned earlier would have a *positive* net delta, confirming its bullish bias.  

When you start juggling three, four, or five legs, eyeballing the net delta becomes a lifesaver. If the sum is zero, the structure is **Delta‑Neutral** – it won’t care whether the market climbs or slides, but it will be sensitive to volatility and time decay. Those are the “Volatility‑based” strategies we’ll meet later.  

---

## 7.5 – Strike selection and effect of volatility  

Choosing strikes for a Bear Put Spread mirrors the process for a Bull Call Spread. If you’ve already read the “first‑half vs second‑half of the series” section (2.3), you’ll feel right at home.  

### First half of the series (lots of time left)  

When you have, say, **30 days** to expiry and you anticipate a ~4 % dip, you might pick strikes like this (example numbers):  

| Underlying | Long Put (ITM) | Short Put (OTM) |
|------------|----------------|-----------------|
| 7,500      | 7,600 (cost ₹160) | 7,400 (credit ₹70) |

The wider the time horizon, the cheaper the spread because **time value** cushions the price of the OTM leg.  

### Second half of the series (mid‑expiry)  

When you’re down to **15 days** or less, you’ll generally move the strikes tighter (or pick a higher OTM premium) because time decay is accelerating.  

| Underlying | Long Put (ITM) | Short Put (OTM) |
|------------|----------------|-----------------|
| 7,500      | 7,620 (cost ₹140) | 7,380 (credit ₹60) |

### Volatility’s role  

The graph below (again from Zerodha) shows how the *cost* of a Bear Put Spread reacts to changes in implied volatility (IV) at three different points to expiry.  

![Volatility effect on Bear Put Spread](http://zerodha.com/varsity/wp-content/uploads/2016/02/Image-7_volatility-effect.png)  

- **Blue line** = ~30 days left – cost barely moves with IV.  
- **Green line** = ~15 days left – moderate sensitivity.  
- **Red line** = ~5 days left – cost jumps a lot when IV spikes.  

**Bottom line:** If you have a lot of time left, you can mostly ignore short‑term IV swings. In the latter half of the series, however, a *rise* in volatility can *inflate* the premium you pay for the long put more than the credit you receive from the short put, making the spread pricier.  

**Practical tip:**  
- **Enter a Bear Put Spread when you *expect* volatility to **rise** (or at least stay steady) in the second half of the series.**  
- If you think IV will *fall*, the spread’s price may drop, and you could end up paying more than necessary – better to wait or pick a different strategy.  

---

### Key takeaways from this chapter  

- **Spreads give you crystal‑clear risk** (you know the max loss) *at the expense of a smaller upside*.  
- The premium you collect from the short leg *partially* (or fully) funds the long leg – that’s the “financing” magic of spreads.  
- **Bear Put Spread** = “I’m mildly bearish, I want a modest profit if the market slides, but I don’t want to lose my shirt if it climbs.”  
- Both profit **and loss are capped** (profit ≈ ₹108, loss ≈ ₹92 in our example).  
- Classic construction: **Buy ITM put + Sell OTM put** (same expiry, same underlying).  
- Usually results in a **net debit** = Premium Paid – Premium Received.  
- **Breakeven** = Higher strike – Net debit.  
- **Max profit** = Spread – Net debit.  
- **Max loss** = Net debit.  
- Pick strikes based on **time‑to‑expiry** (first vs second half of series).  
- **Volatility matters most in the second half**; ideally you want IV to be rising or at least stable.  

> **Pro tip:** Download the handy Excel sheet (linked on the original page) to plug in your own numbers and see the payoff instantly.  

Happy spreading, and may your bears be gentle!  