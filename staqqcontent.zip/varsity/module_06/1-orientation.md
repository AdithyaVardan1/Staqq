# 1. Orientation  

**Source:** <https://zerodha.com/varsity/chapter/orientation/>  

---  

## 1.1 – Setting the context  

Alright, grab a cold one and settle in – before we dive head‑first into the jungle of option strategies I want to tell you about a little Behavioral Finance piece I stumbled on a couple of years back. The title was **“Why Winning Is Addictive.”** (Yes, you read that right – it’s not a self‑help book for slot‑machine addicts, it’s about the brain’s love‑affair with a win.)

The article was penned by B. Venkatesh, a regular column‑cutter for *HBL*. Here’s the gist, in my own “bar‑friend” style:

> “Buying a lottery ticket is something most of us avoid because we *know* the odds of hitting the jackpot are about as good as a unicorn winning a sprint race. Yet, if you *do* win, the next thing you know you’re standing in line at the clerk, clutching another ticket, whispering ‘Just one more…’  
> 
> The same thing happens with money. Our lives are ruled by **anticipation** – the thrill of thinking, ‘What if I win?’ is often more intoxicating than the actual win itself. Neuroscience even shows that the *anticipation* of a win lights up the brain more than the win does.  
> 
> Once you’ve tasted that dopamine‑rich victory, your **reflexive brain** (the part that feels, reacts, and wants instant gratification) screams “Buy another ticket!” while your **reflective brain** (the logical, calculator‑type part) mutters, “Buddy, the odds of winning twice are basically zero.”  
> 
> Fast‑forward to equity options. You know buying calls and puts is risky – they can expire worthless like a birthday cake left out in the rain. Still, after a big win, many traders keep buying them like they’re at an all‑you‑can‑eat buffet. That reflexive brain is at it again.  
> 
> Options have an extra twist: they can *lose* you money if the underlying stock moves opposite to your bet. Losing money makes a win feel **even sweeter** – it’s the classic “I survived a shark attack, now I can conquer the world” vibe. Lotteries are pure chance; options, we like to think, blend chance with a dash of skill.”

*— End of article —*  

You’re probably wondering why I’m tossing a lottery‑story into a serious options module. Simple: it mirrors what I see every day in the trenches of options trading. The article nails a behavioral truth that I’ve seen a hundred times – **most options traders treat every trade like a “hit‑or‑miss” lottery ticket**. The moment they click *buy* they get a little giggle, a “what‑the‑heck‑am‑I‑doing?” feeling, and then… **boom**, reality slaps them with a P&L that looks like a crime scene.

Picture this: a trader buying a fresh batch of options every month, dreaming they’ll double their account each time. That mindset is the culinary equivalent of adding a teaspoon of salt to every dish and hoping it’ll magically turn into a gourmet feast. Spoiler: it won’t. The result? **A spectacular, self‑inflicted capital wipe‑out** that would make even the most hardened gambler weep.

> **Bottom line:** If you want to play in the options arena, you **must** do it with a plan, not with the reckless optimism of someone buying a lottery ticket because “maybe today’s the day.” Otherwise, you’ll watch the gambling‑style attitude eat up your bankroll faster than you can say “margin call.”  

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/11/M6-C1-cartoon.png)

Now, let’s bust a myth that every rookie seems to repeat: **“limited risk, unlimited profit potential.”** On paper it sounds like a unicorn – glorious and unattainable. In practice, it’s a silent P&L assassin. New traders get dazzled by the *theoretical* perfection, then slowly, inexorably, bleed money until the account looks like a dried‑up riverbed.  

So yes, trading options without a strategy is a **“dangerous but irresistible pastime.”** (Shout‑out to Pink Floyd for that line.) I’m not trying to give you a horror story; I’m just setting the stage. In the previous module on Options Theory you probably already sensed that options are *heavy‑duty science* – not the “just add water” type of stuff. It can feel like trying to understand quantum physics after a few beers, but trust me: the only way to master it is to blend **theory + practice** in the right proportions.

In this module I’ll give you a **tour de force** of the most useful, practical strategies. I’ll keep the boring, mind‑twisting theory at bay and focus on what you can actually **use** on a screen.  

There are, rumor has it, **about 475** publicly documented options strategies. Add another 100‑ish that live in the secret vaults of proprietary desks, and you’ve got a veritable zoo. Do you need to memorize every single animal? **Nope.** The answer is a resounding **no**.

## 1.2 – What should you know?  

You don’t need the entire zoo; you just need a **handful of well‑trained beasts**. Master a few solid strategies, then you’ll be able to look at any market condition, pick the right “weapon” from your quiver, and execute with confidence.

With that mindset, let’s list the ones we’ll actually spend time on. (Don’t worry – I’ll keep the pictures, because a visual is worth a thousand boring paragraphs.)

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/11/bullish-strategies.png)

### Bullish‑oriented strategies  

- **Bull Call Spread** – buy a call, sell a higher‑strike call.  
- **Bull Put Spread** – sell a put, buy a lower‑strike put.  
- **Call Ratio Back Spread** – sell a call, buy more calls at a higher strike (think “go long the upside”).  
- **Bear Call Ladder** – a multi‑legged play that caps profit but gives you a safety net.  
- **Call Butterfly** – three‑legged combo that profits from limited movement around a target price.  
- **Synthetic Call** – replicate a long call using a long stock + long put.  
- **Straps** – long call + two long puts (double‑down on downside volatility while staying bullish).

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/11/bearish-strategies.png)

### Bearish‑oriented strategies  

- **Bear Call Spread** – sell a call, buy a higher‑strike call.  
- **Bear Put Spread** – buy a put, sell a lower‑strike put.  
- **Bull Put Ladder** – a laddered version of the put spread that gives you extra premium.  
- **Put Ratio Back Spread** – sell a put, buy more puts at a lower strike (the mirror of the call ratio back spread).  
- **Strip** – long put + two long calls (the opposite of a strap).  
- **Synthetic Put** – replicate a long put using a short stock + long call.

![Image](http://zerodha.com/varsity/wp-content/uploads/2015/11/neutral-strategies.png)

### Neutral‑oriented strategies  

- **Long & Short Straddles** – buy (or sell) a call and a put at the same strike.  
- **Long & Short Strangles** – similar to straddles but with OTM strikes, cheaper to enter.  
- **Long & Short Iron Condor** – two vertical spreads that profit from low volatility.  
- **Long & Short Butterfly** – a tighter version of the condor, higher reward‑to‑risk.  
- **Box** – a synthetic long‑stock position made with options only (buy a call + sell a put, and the opposite on a different strike).

Besides those, I’ll also dive into two “special sauce” topics that many traders overlook:  

- **Max Pain** for option writers – a practical look at where the market tends to settle to hurt option buyers the most.  
- **Volatility Arbitrage using Dynamic Delta‑Hedging** – a fancy way of saying “let’s chase the volatility smile while keeping our delta neutral.”

### How we’ll roll it out  

I’m planning **one strategy per chapter**. That way you get a crystal‑clear view of each play without the mental clutter of trying to juggle ten at once. Roughly 20 chapters in total – think of it as a 20‑episode binge‑watch series, each episode short enough to finish over a coffee break but packed with enough detail to keep you from dozing off.

For each strategy we’ll cover:

1. **Background** – why the strategy exists and when traders love it.  
2. **Implementation** – step‑by‑step on how to put together the legs.  
3. **Payoff diagram** – the good‑old visual that shows you profit zones.  
4. **Breakeven points** – where you stop losing money (and start hoping).  
5. **Strike selection** – how to pick the right strikes given time‑to‑expiry, volatility, and your market view.  

I’ll also drop a **ready‑to‑use Excel model** (yes, a spreadsheet you can actually open and play with) so you can plug in your own numbers and see the math in real time.

> **Pro tip:** Even though I’ll use the **Nifty Index** as my running example, everything translates 1:1 to any individual stock option. Just swap the ticker and you’re good to go.

#### A reality check  

Don’t expect a **holy grail** hidden somewhere in these pages. No strategy is a guaranteed money‑printing press. The markets are *not* a vending machine where you press “buy” and get cash. The goal is to give you **a toolbox** of robust, repeatable plays that, when used with discipline and market sense, *can* be profitable.

Think of it like this: you own a sleek sports car. If you floor it on a crowded city street, you’ll cause chaos (and probably get a ticket). But if you respect the road, obey the signs, and drive responsibly, you’ll enjoy smooth rides and impress onlookers. Options work the same way – they’re powerful, but you must handle them with care.

My job? To be your **driving instructor**. I’ll teach you the gears, the steering, the brakes, and the moments when you should *actually* hit the gas. Whether you end up cruising or crashing is ultimately up to you – it hinges on **discipline, risk management, and continual market reading**. The more “quality time” you spend with the charts, the better you’ll get at spotting the right moment to deploy a strategy.

So, strap in. Starting with the next chapter we’ll roll out the **Bullish strategies**, and the very first star of the show is the **Bull Call Spread**.  

Stay tuned, keep the drinks flowing, and let’s make those options work for you—not against you.  