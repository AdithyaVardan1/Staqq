# 13. Max Pain & PCR Ratio  

**Source:** <https://zerodha.com/varsity/chapter/max-pain-pcr-ratio/>  

---  

## 13.1 – My experience with Option‑Pain theory  

Every market‑theory lover has that one “cult‑classic” that either makes them cheer or cringe. For options, the star‑player is **Option‑Pain**, also called **Max‑Pain**. It has a legion of devotees and an equally vocal anti‑fan club. Guess what? I’ve sat on both sides of the fence.  

When I first stumbled onto Max‑Pain, my account looked more like a roller‑coaster that only went *down*. I was buying the “pain” instead of selling it, and my bankroll didn’t like it. After a few months of trial‑and‑error (and a lot of coffee), I tweaked the idea to match my own risk appetite, and suddenly the numbers stopped looking like a horror movie. I’ll spill the beans on those tweaks later in the chapter.  

For now, consider this a quick‑and‑dirty crash‑course on the core Max‑Pain concept, plus a few things I love and a few I don’t. Feel free to take whatever resonates and leave the rest to the haters.  

**Pro‑tip:** All of this hinges on one simple but powerful metric – **Open Interest (OI)**. If you don’t know what that is, just think of it as the “crowd size” for each strike. Bigger crowd = bigger impact on the pain‑calculation.  

Let’s dive in, shall we?  

---  

## 13.2 – Max Pain Theory  

The idea of Option‑Pain first showed up in a 2004 blog post, so it’s still a baby compared to, say, the Efficient Market Hypothesis. No peer‑reviewed papers have taken it seriously yet – academia must be busy counting citations for other stuff.  

The whole theory rests on a single, slightly grim observation:  

> **“About 90 % of options expire worthless, so option writers (the sellers) cash‑in more often than the buyers.”**  

If that’s true, we can chain together a few logical steps (think of it as a domino effect, but with money).  

| # | Logical deduction | What it means for the market |
|---|-------------------|------------------------------|
| 1 | Only one side of the trade can win – either the buyers or the sellers. | Since sellers win most of the time, they’re the “winning side”. |
| 2 | Sellers want the *least* loss on expiry, so the underlying price will gravitate toward a point that minimizes their pain. | The price at expiry gets nudged toward a “sweet spot”. |
| 3 | If the price can be nudged, then **some** manipulation must be possible – at least on expiry day. | Traders with enough muscle can move the needle. |
| 4 | The only group that benefits from that manipulation is the **seller‑club**. | The sellers become the puppet‑masters. |
| 5 | Consequently there exists a *single* price where the total loss for all sellers is at its minimum. | That price is the **Max‑Pain** point. |

If you can compute that price, you’ve basically guessed where the market *wants* to close on expiry. That’s the whole point of the Max‑Pain theory: **find the price that hurts option buyers the most (and comforts sellers the most).**  

> **Formal definition (from optionspain.com):**  
> “In the options market, wealth transfer between option buyers and sellers is a zero‑sum game. On option expiration days, the underlying stock price often moves toward a point that brings maximum loss to option buyers. This specific price, calculated based on all outstanding options in the market, is called **Option Pain**. Option Pain is a proxy for the stock‑price manipulation target by the option‑selling group.”  

---

## 13.3 – Max Pain Calculation  

Alright, time to roll up those sleeves. Below is a step‑by‑step recipe for cooking up the Max‑Pain number. It looks messy at first, but once you see an example it clicks like a light‑bulb in a dark bar.  

### The recipe  

1. **List every strike** that has open interest for the underlying you care about. Jot down the OI for both calls (CE) **and** puts (PE).  
2. **Assume** the underlying will settle *exactly* at each strike – one at a time.  
3. For each assumed settlement price, **calculate the loss** that would hit the option *writers* (both call‑writers and put‑writers). Remember:  
   * Call writers lose when the underlying ends **above** the strike.  
   * Put writers lose when the underlying ends **below** the strike.  
4. **Add** the call‑writer loss and the put‑writer loss for that settlement price.  
5. **Pick the strike** where the combined loss is *smallest*. That’s your Max‑Pain point – the price that hurts buyers the most (and spares sellers the most).  

### A toy example (3‑strike Nifty)  

Suppose, just for illustration, Nifty only has three strikes with the following open interest (OI) numbers:  

| Strike | Call OI | Put OI |
|--------|--------|-------|
| 7700   | 1,823,400 | 2,559,375 |
| 7800   | 3,448,575 | 4,864,125 |
| 7900   | 2,823,400 | 2,559,375 |

(Those numbers are deliberately made‑up for the example; the math that follows uses them.)  

### Scenario 1 – Expiry at **7700**  

*Calls:* Any call with a strike **> 7700** expires OTM, so the writers keep their premium. No call‑writer loss.  

*Puts:*  
* 7900‑PE writers lose **200** points each → loss = 200 × 2,559,375 = **₹511,875,000**  
* 7800‑PE writers lose **100** points each → loss = 100 × 4,864,125 = **₹486,412,500**  
* 7700‑PE writers break even.  

**Total loss** = 0 (calls) + 511,875,000 + 486,412,500 = **₹998,287,500**  

---

### Scenario 2 – Expiry at **7800**  

*Calls:*  
* 7700‑CE writers lose **100** points → loss = 100 × 1,823,400 = **₹182,340,000**  
* 7800‑CE & 7900‑CE writers keep their premiums.  

*Puts:*  
* 7700‑PE and 7800‑PE writers are fine.  
* 7900‑PE writers lose **100** points → loss = 100 × 2,559,375 = **₹255,937,500**  

**Total loss** = 182,340,000 + 255,937,500 = **₹438,277,500**  

---

### Scenario 3 – Expiry at **7900**  

*Calls:*  
* 7700‑CE writers lose **200** points → 200 × 1,823,400 = **₹364,680,000**  
* 7800‑CE writers lose **100** points → 100 × 3,448,575 = **₹344,857,500**  
* 7900‑CE writers keep premium.  

*Puts:* All put writers are happy (OTM).  

**Total loss** = 364,680,000 + 344,857,500 = **₹709,537,500**  

---

### Putting it together  

| Expiry price | Call‑writer loss | Put‑writer loss | **Total loss** |
|--------------|------------------|----------------|----------------|
| 7700 | 0 | ₹998,287,500 | **₹998,287,500** |
| 7800 | ₹182,340,000 | ₹255,937,500 | **₹438,277,500** |
| 7900 | ₹709,537,500 | 0 | **₹709,537,500** |

The **minimum** total loss is at **7800**, so Max‑Pain says “Hey, Nifty will probably settle around 7800 on expiry.”  

In real life you’ll have **dozens** (or hundreds) of strikes, especially for Nifty, so you’ll need Excel, Python, or a good calculator to crunch the numbers.  

Below is a screenshot of a real‑world calculation I did on **10 May 2016** (just for nostalgia).  

![Computation screenshot](http://zerodha.com/varsity/wp-content/uploads/2016/05/Image-1_comuputation.png)  

The last column, **Total Value**, is the combined loss for that strike. If you plot those values as a bar‑graph you get something like this:  

![Bar‑graph of total loss](http://zerodha.com/varsity/wp-content/uploads/2016/05/Image-2_max-pain.png)  

The lowest bar points to the Max‑Pain strike (7800 in the example).  

### How to use it?  

Most traders treat the Max‑Pain level as a **magnet** for writing options:  

* Write **calls** *above* the Max‑Pain strike (they’re OTM and likely to expire worthless).  
* Write **puts** *below* the Max‑Pain strike (same reasoning).  

Collect the premium, sit back, and hope the market respects the “pain‑point”.  

---  

## 13.4 – A Few Modifications  

When I first got giddy about Max‑Pain, I behaved like a kid with a new video game – I played every level, wrote every possible strike, and expected instant riches. Reality, however, had a different script: the market would sometimes close at 7700, sometimes at 7950, leaving my account in the red and my ego bruised.  

So I added a few safety nets to the vanilla theory:  

| Modification | Why I added it | What it looks like in practice |
|--------------|----------------|--------------------------------|
| **Freeze OI snapshot** | OI changes every day; the “optimal” strike can swing wildly. | I take a snapshot **15 days before expiry** (when OI stabilises a bit). |
| **5 % safety buffer** | Pure Max‑Pain gave a single number, but the market is a chaotic beast. | If Max‑Pain = 7,800, I add 5 % → **7,800 + 390 ≈ 8,190** (round to nearest strike, e.g., 8,200). |
| **Create an expiry range** | Markets rarely land on a single point; they wander. | I assume the underlying will close somewhere between **7,800 and 8,200**. |
| **Prefer writing calls, avoid puts** | “Panic spreads faster than greed.” In a crash, puts can explode. | I sell **calls** beyond the upper buffer (e.g., 8,300+). |
| **Hold till expiry, no averaging** | Averaging into a losing position often kills the profit margin. | I keep the short leg until the contracts die, unless a massive move forces a stop‑loss. |

With this “buffered Max‑Pain” approach, my win‑rate jumped noticeably. I didn’t keep a tidy spreadsheet of results, so I can’t quote exact percentages, but the anecdotal evidence is solid enough to keep using it.  

If you love code, fire up a back‑tester and see how a **5 % buffer** performs over a year. In my own informal checks, that buffer roughly translates to a **1.5‑2 %** move in terms of standard deviations – which, for a normal distribution, corresponds to about a **34 %** chance of the market ending beyond the buffer.  

Not sure what that means? Skim the chapter on **Standard Deviation and Distribution of Returns** – it’s the “why‑does‑this‑matter” section.  

You can download my Excel sheet (the one that generated the screenshots above) from the Zerodha Varsity site.  

---  

## 13.5 – The Put‑Call Ratio  

Now let’s talk about a cousin of Max‑Pain that’s a bit simpler, yet equally chatty: the **Put‑Call Ratio (PCR)**.  

At its core, PCR is just:  

\[
\text{PCR} = \frac{\text{Total OI of Puts}}{\text{Total OI of Calls}}
\]

It’s a **contrarian** vibe‑meter. When PCR spikes **above 1**, the market is *overly bearish* (lots of puts). When it plunges **below 0.5**, the market is *overly bullish* (lots of calls). The sweet‑spot (0.5‑1) is just “normal trading”.  

### Example (10 May 2016)  

| | OI |
|---|---|
| Calls (CE) | 42,874,200 |
| Puts (PE) | 37,016,925 |

\[
\text{PCR} = \frac{37,016,925}{42,874,200} \approx 0.86
\]

A PCR of **0.86** tells us the market is modestly **bullish** (more calls than puts) but not at extreme levels.  

#### How to interpret  

| PCR range | Typical market sentiment | What a contrarian might do |
|-----------|---------------------------|----------------------------|
| **> 1.3** (e.g., 1.5) | Heavy put buying → bearish crowd | Expect a **reversal up** – go long or buy calls. |
| **< 0.5** (e.g., 0.3) | Heavy call buying → bullish crowd | Expect a **reversal down** – consider selling calls or buying puts. |
| **0.5 – 1** | Balanced activity | No strong contrarian signal. |

**Caveat:** The absolute thresholds vary by instrument. A PCR of **1.3** may be extreme for Nifty, but for a volatile tech stock like Infosys, the “extreme‑bearish” line could be **1.2**. The best practice is to plot the PCR for the specific underlying over a 1‑2 year window, spot the historical extremes, and then use those as your reference points.  

Why is PCR contrarian? Think of a crowded party: when everyone shouts “Don’t go left!”, the crowd is already moving left. There’s nobody left to push the party in that direction, so eventually the crowd drifts the other way. In markets, when *everyone* is bearish (lots of puts), the “buyers” (the ones who can move the market) are exhausted, so the price tends to bounce back.  

There are many flavours of PCR – you can substitute **traded volume**, **dollar value**, or even **open‑interest‑adjusted for delta**. In practice, the plain OI‑based PCR works fine; don’t over‑engineer it unless you love spreadsheet gymnastics.  

---  

## 13.6 – Final thoughts  

And that, dear reader, wraps up the **Options** saga that has spanned **two modules** and **36 chapters**. We’ve covered roughly **15 distinct strategies** – enough to get a retail trader comfortable with the basics and a little bit of the exotic.  

You’ll inevitably meet friends who flaunt fancy multi‑leg constructions (think “Iron Condor on steroids”). Remember: **complex ≠ profitable**. The most reliable money‑makers are often the **simple, elegant, and repeatable** setups.  

The purpose of Modules 5 & 6 was to give you a **clear, no‑fluff picture** of what options can and cannot do. We’ve stripped away the hype, kept the math honest, and highlighted the practical limits.  

Take your time, reread sections that feel fuzzy, and experiment on a paper‑trading account before risking real capital. The more you internalise these concepts, the better you’ll be at spotting the “pain points” and the “contrarian signals” that the market leaves for us.  

I hope you enjoyed the ride as much as I enjoyed writing it. May your trades be profitable, your max‑pain calculations be spot‑on, and your PCR never lead you into a black‑hole.  

**Good luck, stay witty, and stay profitable!**  

---  

### Key takeaways from this chapter  

- **Option‑Pain theory** assumes option **writers** (sellers) earn more consistently than buyers.  
- The theory posits that writers can **influence** the underlying price **on expiry**, nudging it toward a point that minimises their loss.  
- By calculating the **combined loss** of all writers at each possible settlement price, you can locate the **price with least pain** – the **Max‑Pain** level.  
- The **strike with the smallest writer loss** is the most likely **expiry price** for the underlying.  
- The **Put‑Call Ratio (PCR)** is simply **Put OI ÷ Call OI** and acts as a **contrarian indicator**.  
- **PCR > 1.3** generally signals **extreme bearishness** (look for a bounce); **PCR < 0.5** signals **extreme bullishness** (watch for a pull‑back).  
- Always contextualise PCR thresholds to the specific asset (different securities have different “extreme” levels).  

---  