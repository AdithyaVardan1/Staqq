# 5. Bear Call Ladder  

**Source:** <https://zerodha.com/varsity/chapter/bear-call-ladder/>  

---  

##  

![Image](http://zerodha.com/varsity/wp-content/uploads/2016/01/M6-C5-cartoon.png)  

## 5.1 – Background  

Don’t let the word **“Bear”** scare you into thinking this is a gloomy, down‑trend play. The Bear Call Ladder is actually an *up‑beat* twist on the classic **call‑ratio back‑spread** – in other words, you use it when you’re **bullish** on the underlying stock or index.  

The trick is simple: the cash you need to buy the two long call legs is **financed** by selling an **in‑the‑money (ITM) call**. Most traders set it up for a **net credit**, which usually gives you a fatter pocket of premium than the plain call‑ratio back‑spread.  

Both strategies look alike on the payoff diagram, but the **risk profile** is a shade different – the Ladder adds an extra safety net (and a little extra drama).  

---

## 5.2 – Strategy Notes  

A Bear Call Ladder is a **three‑leg** option play, normally entered for a **net credit**. The legs are:

| Leg | What you do | Typical strike |
|-----|-------------|----------------|
| 1️⃣ | **Sell** 1 ITM call | deep in the money |
| 2️⃣ | **Buy** 1 ATM (at‑the‑money) call | right at the money |
| 3️⃣ | **Buy** 1 OTM (out‑of‑the‑money) call | a little out of the money |

We usually run them **1 : 1 : 1** (one contract of each). Nothing stops you from scaling to 2 : 2 : 2, 3 : 3 : 3, etc., as long as the ratio stays equal.  

### Walk‑through example  

Assume the **Nifty** spot is **7,790** and you think it will sprint up to **8,100** by expiry – a classic bullish vibe. Here’s how you’d lay the ladder:

1. **Sell** 1 ITM call  
2. **Buy** 1 ATM call  
3. **Buy** 1 OTM call  

**Don’t forget:**  

* All three options must share the **same expiry**.  
* They must be on the **same underlying** (Nifty in this case).  
* Keep the **1 : 1 : 1 ratio** intact.  

The actual trade sheet looks like this:  

| Leg | Symbol | Position | Premium (₹) |
|-----|--------|----------|-------------|
| Short ITM | 7600 CE | **‑1 lot** | **+247** |
| Long ATM | 7800 CE | **+1 lot** | **‑117** |
| Long OTM | 7900 CE | **+1 lot** | **‑70** |

Net credit = **247 – 117 – 70 = 60** points.  

Now let’s see what the universe (or the expiry price) does to this setup.

### Scenario 1 – Expiry at **7,600** (below the lowest strike)

Intrinsic value of a call = **max(Spot – Strike, 0)**  

* 7600 CE → max(7,600 – 7,600, 0) = **0**  
* 7800 CE → 0  
* 7900 CE → 0  

Since we **sold** the 7600 CE, we keep the whole premium **₹247**. The two longs lose the premiums we paid (**₹117 + ₹70**).  

**Net cash flow = 247 – 117 – 70 = 60** points – exactly our initial credit.  

---

### Scenario 2 – Expiry at **7,660** (lower strike + net credit)

* 7600 CE intrinsic = max(7,660 – 7,600, 0) = **60**  
  *We’re short, so we lose 60 of the 247 we collected → 247 – 60 = **187** remaining.*  

* 7800 CE & 7900 CE both expire worthless → lose ₹117 and ₹70.*  

**Total payoff = 187 – 117 – 70 = 0**.  

That’s the **lower breakeven** (strike + credit).  

---

### Scenario 3 – Expiry at **7,700** (between lower breakeven and middle strike)

* 7600 CE intrinsic = 7,700 – 7,600 = **100**  
  *Net from short = 247 – 100 = **147**.*  

* 7800 CE & 7900 CE still OTM → lose ₹117 + ₹70.*  

**Result = 147 – 117 – 70 = –40** points.  
So we’re a bit in the red here.  

---

### Scenario 4 – Expiry at **7,800** (right on the ATM strike)

* 7600 CE intrinsic = 7,800 – 7,600 = **200**  
  *Loss on short = 247 – 200 = **47** (still keep some credit).*  

* 7800 CE and 7900 CE are both worthless → lose premiums **117 + 70**.  

**Total = 47 – 117 – 70 = –140** points.  
This is where the “tragedy” starts to bite.  

---

### Scenario 5 – Expiry at **7,900** (right on the OTM strike)

* 7600 CE intrinsic = 7,900 – 7,600 = **300**  
  *Net on short = 247 – 300 = **–53** (we’re out‑of‑pocket on this leg).*  

* 7800 CE intrinsic = 7,900 – 7,800 = **100**  
  *Long payoff = 100 – 117 = **–17**.*  

* 7900 CE expires flat → lose ₹70.*  

**Overall = –53 – 17 – 70 = –140** points.  
Notice the loss at 7,800 and 7,900 is identical – a quirky symmetry.  

---

### Scenario 6 – Expiry at **8,040** (upper breakeven)

The upper breakeven formula is:  

\[
\text{Upper BE} = (\text{Long Strike 1} + \text{Long Strike 2}) - \text{Short Strike} - \text{Net Credit}
\]  

Plug‑in the numbers:  

\[
(7,900 + 7,800) - 7,600 - 60 = 15,700 - 7,600 - 60 = 8,040
\]

Now compute intrinsic values:

| Leg | Intrinsic (Spot‑Strike) | Net payoff |
|-----|------------------------|------------|
| Short 7600 CE | 8,040 – 7,600 = **440** | 247 – 440 = **–193** |
| Long 7800 CE | 8,040 – 7,800 = **240** | 240 – 117 = **+123** |
| Long 7900 CE | 8,040 – 7,900 = **140** | 140 – 70 = **+70** |

**Total = –193 + 123 + 70 = 0** → perfect breakeven.  

---

### Scenario 7 – Expiry at **8,300** (well above the upper BE)

| Leg | Intrinsic | Net payoff |
|-----|-----------|------------|
| Short 7600 CE | 8,300 – 7,600 = **700** | 247 – 700 = **–453** |
| Long 7800 CE | 8,300 – 7,800 = **500** | 500 – 117 = **+383** |
| Long 7900 CE | 8,300 – 7,900 = **400** | 400 – 70 = **+330** |

**Grand total = –453 + 383 + 330 = **+260** points**.  

Higher the market, fatter the profit – and there’s **no cap** on the upside.  

Below is the payoff snapshot from Zerodha’s original chart:

![Image](http://zerodha.com/varsity/wp-content/uploads/2016/01/Image-1_Payoff-1024x352.png)

**Takeaway:** When the market drifts down you pocket a modest **₹60** credit, but when it rockets up the profit potential is **unlimited**.  

---

## 5.3 – Strategy Generalization  

From the scenarios we can distill a handful of handy formulas:

| Concept | How to think about it |
|---------|-----------------------|
| **Spread** | Not a “spread” in the usual sense, but the distance between the two short‑leg strikes (here 7,800 – 7,600 = **200**). |
| **Net Credit** | Premium received from the ITM sale **minus** premiums paid for the ATM & OTM buys. |
| **Max Loss** | *Spread* – *Net Credit*. |
| **Max‑Loss Location** | Happens when the underlying settles **between the two long strikes** (i.e., around 7,800‑7,900). |
| **Payoff on a down‑move** | Equals the **Net Credit** (you keep the cash). |
| **Lower Breakeven** | *Lower strike* + *Net Credit*. |
| **Upper Breakeven** | (Sum of the two long strikes) – *Short strike* – *Net Credit*. |

The graph below highlights all these key points:

![Image](http://zerodha.com/varsity/wp-content/uploads/2016/01/Image-2_graph.png)

**What you see:** a dip (loss) between **7,660** and **8,040**, a flat line at **+60** when the market collapses, and a soaring line to the right once you cross the upper breakeven.  

**Practical advice:** Only roll out a Bear Call Ladder when you’re **confident the market will move—big—** (doesn’t matter up or down). If the price just sits still, you’ll be the one feeling the sting.  

From experience, this setup shines on **individual stocks** around **quarterly earnings** – when you expect a big move but aren’t sure which way.  

---

## 5.4 – Effect of Greeks  

The Greek sensitivities for the Bear Call Ladder mimic those of the Call Ratio Back‑Spread, especially the **volatility** piece. Here’s a quick refresher (taken from the previous chapter):  

![Image](http://zerodha.com/varsity/wp-content/uploads/2016/01/Image-3_volatility-1024x537.png)

Three coloured lines chart **net premium** (i.e., strategy payoff) versus **implied volatility**, with time‑to‑expiry as the backdrop.

| Line | Time to expiry | What it tells us |
|------|----------------|------------------|
| **Blue** | ~30 days (plenty of time) | **Higher vol = higher payoff**. Moving from 15 % to 30 % vol lifts the payoff from **‑67** to **+43** points. So, when you have a month or more, you want volatility to rise *and* you’re bullish. |
| **Green** | ~15 days | Still **positive** but muted: payoff climbs from **‑77** to **‑47** points as vol doubles. |
| **Red** | < 5 days (very short) | **Higher vol hurts**. Near expiry, extra volatility pushes the options closer to OTM, eroding premiums. If you’re bullish with only a few days left, **don’t** count on a volatility surge. |

Bottom line: **Volatility matters**. When you have ample time, a volatility spike can actually *help* you; when you’re racing against the clock, it can be your worst enemy.  

---

### Key takeaways from this chapter  

- The **Bear Call Ladder** is a bullish‑flavoured twist on the Call Ratio Spread.  
- It usually costs **less** (higher net credit) than the plain ratio spread, but you need the underlying to move **far enough** to hit the upper breakeven.  
- Construction: **Sell 1 ITM CE**, **Buy 1 ATM CE**, **Buy 1 OTM CE** (1 : 1 : 1 ratio).  
- **Net Credit** = Premium received from the ITM sale – premiums paid for the ATM & OTM legs.  
- **Max Loss** = (Spread between the two short strikes) – Net Credit.  
- Max loss materialises when the spot lands **between the two long strikes**.  
- When the market slides down, you pocket the **Net Credit** (a modest profit).  
- **Lower breakeven** = Lower strike + Net Credit.  
- **Upper breakeven** = (Long‑strike 1 + Long‑strike 2) – Short strike – Net Credit.  
- Deploy this only when you’re **sure the market will swing hard**, regardless of direction.  

> **Pro‑tip:** Quarterly earnings season on individual stocks is the perfect playground for the Bear Call Ladder – you expect a big move, but the direction? That’s a mystery even Sherlock would love.  

---

**Download the Bear Call Ladder Excel Sheet** (link as in the original).  

*Happy ladder‑climbing, and may your premiums be ever in your favour!*